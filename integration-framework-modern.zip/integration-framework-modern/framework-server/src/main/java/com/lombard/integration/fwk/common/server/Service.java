package com.lombard.integration.fwk.common.server;

@Deprecated
public abstract class Service {
	
	protected String getUser() {
		return null;
	}
	
}
