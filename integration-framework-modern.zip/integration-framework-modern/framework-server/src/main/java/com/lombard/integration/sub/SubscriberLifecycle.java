package com.lombard.integration.sub;

import com.lombard.integration.sub.InvocationContextFactory.InvocationContext;

/**
 * Lifecycle for message subscribers.
 * 
 * @author wvandenberghe
 * 
 * @param <T>
 *            invocation result type
 */
public interface SubscriberLifecycle< T > {

    /**
     * Call before subscriber service invocation.
     * 
     * @param message
     *            target of the invocation
     */
    void beforeInvocation(InvocationContext < T > message);

    /**
     * Call after subscriber service invocation.
     * 
     * @param message
     *            target of the invocation
     */
    void afterInvocation(InvocationContext < T > message);

    /**
     * Call in case invocation result in a thrown exception.
     * 
     * @param message
     *            target of the invocation
     * @param exception
     *            thrown exception
     */
    void onInvocationException(InvocationContext < T > message, Throwable exception);
}
