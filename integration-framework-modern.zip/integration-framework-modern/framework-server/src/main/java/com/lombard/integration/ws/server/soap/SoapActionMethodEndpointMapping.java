package com.lombard.integration.ws.server.soap;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

import jakarta.jws.WebMethod;
import javax.xml.transform.TransformerException;

import org.springframework.util.ClassUtils;
import org.springframework.util.ReflectionUtils;
import org.springframework.util.StringUtils;
import org.springframework.ws.context.MessageContext;
import org.springframework.ws.server.endpoint.mapping.AbstractMethodEndpointMapping;
import org.springframework.ws.soap.SoapMessage;

/**
 * Endpoint mapper based on SoapAction.
 * 
 * @author wvandenberghe
 * 
 */
public class SoapActionMethodEndpointMapping extends AbstractMethodEndpointMapping<String> {

    private Object[] endpoints;

    /**
     * Get endpoints
     * 
     * @return
     */
    public Object[] getEndpoints() {
        return endpoints;
    }

    /**
     * Sets the endpoints. The endpoint methods that start with <code>methodPrefix</code> and end with
     * <code>methodSuffix</code> will be registered.
     */
    public void setEndpoints(Object[] endpoints) {
        if (endpoints != null) {
            final Object[] copy = endpoints.clone();

            final Object[] newEndpoints = (getEndpoints() != null) ? diff(getEndpoints(), copy) : copy;
            for (Object endpoint : newEndpoints) {
                registerMethods(endpoint);
            }

            this.endpoints = copy;
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    protected String getLookupKeyForMethod(Method method) {
        Class<?> endpointClass = method.getDeclaringClass();
        Class<?>[] interfaces = ClassUtils.getAllInterfacesForClass(endpointClass);

        for (Class<?> clazz : interfaces) {
            final Method m = ReflectionUtils.findMethod(clazz, method.getName(), method.getParameterTypes());
            if (m != null) {
                WebMethod webMethod = m.getAnnotation(WebMethod.class);
                if (webMethod != null) {
                    return webMethod.action();
                }
            }
        }

        return null;
    }

    /** Returns the local part of the payload root element of the request. */
    @Override
    protected String getLookupKeyForMessage(MessageContext messageContext) throws TransformerException {
        if (messageContext.getRequest() instanceof SoapMessage request) {
            String soapAction = request.getSoapAction();
            if (StringUtils.hasLength(soapAction) && soapAction.charAt(0) == '"'
                    && soapAction.charAt(soapAction.length() - 1) == '"') {
                return soapAction.substring(1, soapAction.length() - 1);
            } else {
                return soapAction;
            }
        }
        return null;
    }

    Object[] diff(Object[] left, Object[] right) {
        if (left == null) {
            throw new IllegalArgumentException("Argument [left] cannot be null");
        }
        if (right == null) {
            throw new IllegalArgumentException("Argument [right] cannot be null");
        }

        List<Object> returnAsList = new ArrayList<>();
        for (Object rightObj : right) {
            boolean found = false;
            for (Object leftObj : left) {
                if (rightObj == leftObj || rightObj.equals(leftObj)) {
                    found = true;
                    break;
                }
            }
            if (!found) {
                returnAsList.add(rightObj);
            }
        }

        return returnAsList.toArray(Object[]::new);
    }
}
