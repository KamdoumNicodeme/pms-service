/**
 * Support for configuration by annotation.
 * <p>
 * It works in accordance with the configuration by annotation:
 * <pre>
 * &lt;intfwk:init-service destination="REQ.TRAX.MANDATE.MANDATESERVICE"/>
 * </pre>
 * It scans classes annotated by {@link ServiceDefinition} and create a framework compliant service endpoint. 
 */
package com.lombard.integration.ws.server.support;