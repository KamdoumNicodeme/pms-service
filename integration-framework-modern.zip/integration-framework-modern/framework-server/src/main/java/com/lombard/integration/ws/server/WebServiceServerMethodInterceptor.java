package com.lombard.integration.ws.server;

import static com.lombard.apm.logger.ApmLoggerConstants.*;

import jakarta.jws.WebService;

import org.aopalliance.intercept.MethodInterceptor;
import org.aopalliance.intercept.MethodInvocation;

import com.lombard.apm.ApmLoggerContextFactory;
import com.lombard.apm.logger.ApmLogger;
import com.lombard.apm.logger.ApmLoggerContext;
import com.lombard.apm.logger.ApmLoggerFactory;
import com.lombard.integration.util.ModelUtils;

/**
 * 
 * @author wvandenberghe
 * 
 */
public class WebServiceServerMethodInterceptor implements MethodInterceptor {

    private static final ApmLogger APM_LOGGER = ApmLoggerFactory.getApmLogger();

    /**
     * 
     */
    public Object invoke(MethodInvocation methodInvocation) throws Throwable {

        return doInvoke(methodInvocation, true);
    }

    private Object doInvoke(MethodInvocation methodInvocation, boolean doApm) throws Throwable {

        Object proceed;
        final ApmLoggerContext apmLoggerContext;

        try {
            apmLoggerContext = ApmLoggerContextFactory.getInstance().createApmLoggerContext(methodInvocation);
        } catch (Exception e) {
            // Issue with Spring context --> just execute the next interceptor and return.
            return doInvoke(methodInvocation);
        }

        try {
            // Start timer
            apmLoggerContext.startWatch();

            // Call service
            proceed = doInvoke(methodInvocation);

            apmLoggerContext.addParam(PARAM_ACTIVITY_STATUS, ACTIVITY_STATUS_SUCCESS);

        } catch (Exception e) {
            apmLoggerContext.addParam(PARAM_ACTIVITY_STATUS, ACTIVITY_STATUS_FAILED);
            apmLoggerContext.addParam(PARAM_ERROR_MESSAGE, e);
            throw e;
        } finally {
            // Stop timer + log
            apmLoggerContext.stopWatch();
            APM_LOGGER.trace(apmLoggerContext);

        }

        return proceed;
    }

    private Object doInvoke(MethodInvocation methodInvocation) throws Throwable {

        Object[] parameters = methodInvocation.getArguments();
        Object request = null;
        if (parameters.length == 1) {
            request = parameters[0];
        }

        Object result = methodInvocation.proceed();

        if (result == null || !isWebServiceOperation(methodInvocation)) {
            return result;
        } else {
            return ModelUtils.copyCorrelationHandler(request, result);
        }
    }

    /**
     * 
     * @param invocation
     * @return
     */
    private boolean isWebServiceOperation(MethodInvocation invocation) {

        return invocation.getMethod().getDeclaringClass().isAnnotationPresent(WebService.class);
    }
}
