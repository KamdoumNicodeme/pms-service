package com.lombard.integration.sub;

import java.util.Map;

public interface ResponseManager {

    void processResponse(Object response, Map<String,String> headers);

}
