package com.lombard.integration.ws.server.soap;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.Properties;

import org.springframework.beans.factory.InitializingBean;
import org.springframework.ws.soap.server.endpoint.SoapFaultDefinition;
import org.springframework.ws.soap.server.endpoint.SoapFaultDefinitionEditor;
import org.springframework.ws.soap.server.endpoint.SoapFaultMappingExceptionResolver;

public class DefaultSoapExceptionResolver extends SoapFaultMappingExceptionResolver implements InitializingBean {

    private static final String TECHNICAL_EXCEPTION = "TechnicalException";
    private static final String BUSINESS_EXCEPTION = "BusinessException";

    private static final String TECHNICAL_ERROR = "TechnicalError";
    private static final String BUSINESS_ERROR = "BusinessError";

    public void afterPropertiesSet() throws Exception {
        final Properties properties = new Properties();
        properties.setProperty(BUSINESS_EXCEPTION, BUSINESS_ERROR);
        properties.setProperty(TECHNICAL_EXCEPTION, TECHNICAL_ERROR);
        setExceptionMappings(properties);
    }

    @Override
    protected SoapFaultDefinition getFaultDefinition(Object endpoint, Exception ex) {
        SoapFaultDefinition definition = super.getFaultDefinition(endpoint, ex);
        if (definition == null) {
            return getFaultDefinition(TECHNICAL_ERROR, ex);
        }

        final String faultCode = definition.getFaultCode().toString();

        return getFaultDefinition(faultCode, ex);
    }

    private SoapFaultDefinition getFaultDefinition(String faultCode, Exception ex) {
        SoapFaultDefinitionEditor editor = new SoapFaultDefinitionEditor();
        editor.setAsText(String.format("{SOAPENV}:%s,%s\n%s", faultCode, faultCode, getExceptionAsString(ex)));
        return (SoapFaultDefinition) editor.getValue();
    }

    private String getExceptionAsString(Throwable cause) {
        if (cause == null) {
            throw new IllegalArgumentException("Argument 'cause' cannot be null");
        }

        StringBuilder builder = new StringBuilder();

        if (cause.getCause() == null || cause.getCause() == cause) {
            builder.append(cause.getMessage());
            builder.append("\n");

            StringWriter writer = new StringWriter();
            cause.printStackTrace(new PrintWriter(writer, true));

            builder.append(writer.toString());

            return builder.toString();
        } else {
            return builder.append(getExceptionAsString(cause.getCause())).toString();
        }
    }
}
