/**
 * Create framework compliant service endpoint.
 * 
 * <h2>XML based</h2>
 * 
 * The service container must be defined from a destination and a list of service implementation as following:
 *
 * <pre>
 * &lt;intfwk:service-definitions destination="REQ.TRAX.MANDATE.MANDATESERVICE">
 *      &lt;intfwk:service class="com.lombard.integration.framework.service.server.MandateServiceImpl"/>
 * &lt;/intfwk:service-definitions>
 * </pre>
 *
 * <h2>Annotation based</h2>
 * 
 * Only the service container configuration must be done in Spring configuration file: 
 *
 * <pre>
 * &lt;intfwk:init-service destination="REQ.TRAX.MANDATE.MANDATESERVICE"/>
 * </pre>
 * It is based on annotation {@link ServiceDefinition} that is handled by Spring component scan capabilities.
 * 
 * <h2>Configuration</h2>
 * 
 * The following attributes are available for both elements:
 * <dl>
 * <dt>destination</dt>
 * <dd>queue on which service endpoints must listen messages</dd>
 * <dt>connection-factory</dt>
 * <dd>connection factory to use. Use svcConnectionFactory by default</dd>
 * <dt>timeout</dt>
 * <dd>receiving timeout</dd>
 * <dt>concurrency</dt>
 * <dd>thread number to listen messages. With the syntax: [a-b], a means min number of thread, and b means max number of thread</dd>
 * </dl>
 */
package com.lombard.integration.ws.server;