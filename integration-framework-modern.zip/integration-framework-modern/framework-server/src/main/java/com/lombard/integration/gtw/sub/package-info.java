/**
 * Consume gateway output.
 */
package com.lombard.integration.gtw.sub;