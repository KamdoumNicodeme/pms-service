package com.lombard.integration.fwk.common.server.notification;

import java.io.StringReader;
import java.lang.reflect.InvocationTargetException;

import jakarta.annotation.Resource;
import jakarta.xml.bind.JAXBContext;
import jakarta.xml.bind.JAXBElement;
import jakarta.xml.bind.JAXBException;
import jakarta.xml.bind.UnmarshalException;

import org.apache.commons.beanutils.PropertyUtils;

public abstract class AbstractNotificationListener implements NotificationListener {

    @Resource(name = "jaxbContextCDM")
    private JAXBContext jaxbContext;

    public AbstractNotificationListener() {

    }

    /**
     * <p>
     * Method parses notification sent by integration framework. Method expects the notification to be CSM (2.1 or
     * 2.2) element wrapped into Message (2.1 or 2.2) xml element.
     * </p>
     * 
     * @param <T>
     * 
     * @param aXML
     *            the content of notification message. The message usually is jms TextMessage.
     * @return parsed object in the wanted type.
     * @throws UnmarshalException
     */
    @SuppressWarnings("unchecked")
	protected < T > T parseNotification(String aXML, Class<T> to) throws UnmarshalException {
        try {
        	JAXBElement < ? > messageElement =
                (JAXBElement < ? >) jaxbContext.createUnmarshaller().unmarshal(new StringReader(aXML));

            Object obj = messageElement.getValue();
            Object objBody = PropertyUtils.getProperty(obj, "body");
            Object objAny = PropertyUtils.getProperty(objBody, "any");
            JAXBElement < ? > csmElement = (JAXBElement < ? >) objAny;
            
            return (T) csmElement.getValue();
        } catch (IllegalAccessException e) {
        	throw new UnmarshalException("Error while unmarshalling notification: \n" + aXML, e);
        } catch (InvocationTargetException e) {
        	throw new UnmarshalException("Error while unmarshalling notification: \n" + aXML, e);
        } catch (NoSuchMethodException e) {
        	throw new UnmarshalException("Error while unmarshalling notification: \n" + aXML, e);
        } catch (JAXBException e) {
        	throw new UnmarshalException("Error while unmarshalling notification: \n" + aXML, e);
		}
    }

}
