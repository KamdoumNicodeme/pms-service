package com.lombard.integration.ws.server.config;

import java.util.List;

import jakarta.xml.bind.annotation.XmlType;

import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.beans.factory.support.AbstractBeanDefinition;
import org.springframework.beans.factory.support.BeanDefinitionBuilder;
import org.springframework.beans.factory.support.BeanDefinitionValidationException;
import org.springframework.beans.factory.support.ManagedList;
import org.springframework.beans.factory.xml.ParserContext;
import org.springframework.jms.listener.DefaultMessageListenerContainer;
import org.springframework.util.xml.DomUtils;
import org.springframework.ws.server.endpoint.adapter.DefaultMethodEndpointAdapter;
import org.springframework.ws.server.endpoint.interceptor.PayloadLoggingInterceptor;
import org.springframework.ws.soap.server.SoapMessageDispatcher;
import org.springframework.ws.soap.server.endpoint.interceptor.SoapEnvelopeLoggingInterceptor;
import org.w3c.dom.Element;

import com.lombard.integration.ws.config.AbstractServiceDefinitionParser;
import com.lombard.integration.ws.server.WebServiceServerFactoryBean;
import com.lombard.integration.ws.server.jaxb.SimpleJaxbPayloadMethodProcessor;
import com.lombard.integration.ws.server.jaxb.XmlTypePayloadMethodProcessor;
import com.lombard.integration.ws.server.soap.DefaultSoapExceptionResolver;
import com.lombard.integration.ws.server.soap.SoapActionMethodEndpointMapping;
import com.lombard.integration.ws.server.tibco.TibcoWebServiceMessageListener;

/**
 * Parse the definition of a SOAP message listener and create a message container to dispatch message based on SOAP
 * action.
 * 
 * @author wvandenberghe
 * 
 */
public class ServiceDefinitionsDefinitionParser extends AbstractServiceDefinitionParser {

    private static final String SERVICE_EL = "service";

    private static final String DEFAULT_CONNECTION_FACTORY = "svcConnectionFactory";

    /**
     * {@inheritDoc}
     */
    @Override
    protected AbstractBeanDefinition parseInternal(Element element, ParserContext parserContext) {
        BeanDefinitionBuilder factory =
                BeanDefinitionBuilder.genericBeanDefinition(DefaultMessageListenerContainer.class);

        String destination = element.getAttribute(DESTINATION_ATT);
        if (destination == null || destination.trim().length() == 0) {
            throw new BeanDefinitionValidationException("[destination] attribute is mandatory");
        }
        factory.addPropertyValue("destinationName", destination);

        String timeout = element.getAttribute(TIMEOUT_ATT);
        factory.addPropertyValue("receiveTimeout", Long.parseLong(timeout));

        String connectionFactory = element.getAttribute(CONNECTION_FACTORY_ATT);
        if (connectionFactory.trim().length() == 0) {
            connectionFactory = getDefaultConnectionFactoryReference();
        }
        factory.addPropertyReference("connectionFactory", connectionFactory);

        final String concurrency = element.getAttribute(CONCURRENCY_ATT);
        if (concurrency.trim().length() > 0) {
            factory.addPropertyValue("concurrency", concurrency);
        }

        BeanDefinition messageListener = parseMessageListener(element, parserContext);
        factory.addPropertyValue("messageListener", messageListener);

        return factory.getBeanDefinition();
    }

    @Override
    protected String getDefaultConnectionFactoryReference() {
        return DEFAULT_CONNECTION_FACTORY;
    }

    /**
     * Create a message listener based on a message dispatcher.
     * 
     * @param element
     * @param parserContext
     * @return
     */
    private BeanDefinition parseMessageListener(Element element, ParserContext parserContext) {
        BeanDefinitionBuilder builder =
                BeanDefinitionBuilder.genericBeanDefinition(TibcoWebServiceMessageListener.class);

        String messageFactory = getMessageFactory(parserContext);
        builder.addPropertyReference("messageFactory", messageFactory);

        BeanDefinition messageReceiver = parseMessageDispatcher(element);
        builder.addPropertyValue("messageReceiver", messageReceiver);

        return builder.getBeanDefinition();
    }

    /**
     * Create a SOAP message dispatcher.
     * 
     * @param element
     * @return
     */
    private BeanDefinition parseMessageDispatcher(Element element) {
        BeanDefinitionBuilder builder = BeanDefinitionBuilder.genericBeanDefinition(SoapMessageDispatcher.class);

        BeanDefinition endpointAdapters = getEndpointAdapters();
        builder.addPropertyValue("endpointAdapters", endpointAdapters);

        BeanDefinitionBuilder endpointMappings = parseEndpointMappings();

        // register declared services
        final List<Element> services = DomUtils.getChildElementsByTagName(element, SERVICE_EL);
        final ManagedList<BeanDefinition> endpoints = new ManagedList<>(services.size());
        for (Element currentElement : services) {
            BeanDefinition service = parseService(currentElement);
            endpoints.add(service);
        }
        endpointMappings.addPropertyValue("endpoints", endpoints);

        builder.addPropertyValue("endpointMappings", endpointMappings.getBeanDefinition());

        BeanDefinitionBuilder exceptionResolver = getEndpointExceptionResolver();
        ManagedList<BeanDefinition> excpetionResolvers = new ManagedList<>(1);
        excpetionResolvers.add(exceptionResolver.getBeanDefinition());
        builder.addPropertyValue("endpointExceptionResolvers", excpetionResolvers);

        return builder.getBeanDefinition();
    }

    private BeanDefinitionBuilder getEndpointExceptionResolver() {
        return BeanDefinitionBuilder.genericBeanDefinition(DefaultSoapExceptionResolver.class);
    }

    /**
     * Create and configure a SOAP action based endpoint mapper.
     * 
     * @param element
     * @return
     */
    private BeanDefinitionBuilder parseEndpointMappings() {
        BeanDefinitionBuilder builder =
                BeanDefinitionBuilder.genericBeanDefinition(SoapActionMethodEndpointMapping.class);

        ManagedList<BeanDefinition> interceptors = new ManagedList<>(2);
        interceptors.add(getSaopEnvelopeInterceptor());
        interceptors.add(getPayloadInterceptor());
        builder.addPropertyValue("interceptors", interceptors);

        return builder;
    }

    /**
     * Parse the service class and define it as service implementation (endpoint).
     * 
     * @param element
     * @return
     */
    private BeanDefinition parseService(Element element) {
        final String classFullName = element.getAttribute(CLASS_ATT);
        final BeanDefinitionBuilder builder =
                BeanDefinitionBuilder.genericBeanDefinition(WebServiceServerFactoryBean.class);

        BeanDefinitionBuilder endpointBuilder = BeanDefinitionBuilder.genericBeanDefinition(classFullName);
        builder.addPropertyValue("endpoint", endpointBuilder.getBeanDefinition());

        return builder.getBeanDefinition();
    }

    /**
     * Get the SOAP envelope logging interceptor.
     * 
     * @return
     */
    private BeanDefinition getSaopEnvelopeInterceptor() {
        BeanDefinitionBuilder builder =
                BeanDefinitionBuilder.genericBeanDefinition(SoapEnvelopeLoggingInterceptor.class);
        return builder.getBeanDefinition();
    }

    /**
     * Get the payload logging interceptor.
     * 
     * @return
     */
    private BeanDefinition getPayloadInterceptor() {
        BeanDefinitionBuilder builder = BeanDefinitionBuilder.genericBeanDefinition(PayloadLoggingInterceptor.class);
        return builder.getBeanDefinition();
    }

    /**
     * Get the endpoint adapter used to resolve argument and return value.
     * 
     * @return
     */
    private BeanDefinition getEndpointAdapters() {
        BeanDefinitionBuilder builder =
                BeanDefinitionBuilder.genericBeanDefinition(DefaultMethodEndpointAdapter.class);

        BeanDefinition payloadMethodProcessor = getPayloadMethodProcessor();
        builder.addPropertyValue("methodArgumentResolvers", payloadMethodProcessor);
        builder.addPropertyValue("methodReturnValueHandlers", payloadMethodProcessor);

        return builder.getBeanDefinition();
    }

    /**
     * Get the payload method processor.
     * 
     * @return
     */
    private BeanDefinition getPayloadMethodProcessor() {
        BeanDefinitionBuilder builder =
                BeanDefinitionBuilder.genericBeanDefinition(SimpleJaxbPayloadMethodProcessor.class);

        BeanDefinition delegate = getPayloadMethodProcessorDelegate();
        builder.addPropertyValue("argumentResolverDelegate", delegate);
        builder.addPropertyValue("returnValueDelegate", delegate);

        return builder.getBeanDefinition();
    }

    /**
     * Get the delegate method payload processor based on {@link XmlType} annotation.
     * 
     * @return
     */
    private BeanDefinition getPayloadMethodProcessorDelegate() {
        BeanDefinitionBuilder builder =
                BeanDefinitionBuilder.genericBeanDefinition(XmlTypePayloadMethodProcessor.class);

        BeanDefinition jaxbListener = getJaxbListener();
        builder.addPropertyValue("marshallerListener", jaxbListener);

        return builder.getBeanDefinition();
    }

}
