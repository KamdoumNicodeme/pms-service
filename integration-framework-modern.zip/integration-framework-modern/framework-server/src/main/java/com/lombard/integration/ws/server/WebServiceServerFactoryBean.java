package com.lombard.integration.ws.server;

import jakarta.jws.WebService;

import org.springframework.aop.framework.AopProxyUtils;
import org.springframework.aop.framework.ProxyFactory;
import org.springframework.aop.support.AopUtils;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.FactoryBean;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.core.annotation.AnnotationUtils;
import org.springframework.util.Assert;

/**
 * 
 * @author wvandenberghe
 * 
 */
public class WebServiceServerFactoryBean extends WebServiceServerMethodInterceptor implements
        ApplicationContextAware, FactoryBean<Object> {

    private Class<?> endpointClass;

    private Object endpoint;

    private Object proxy;

    private ConfigurableApplicationContext beanFactory;

    /**
     * 
     */
    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
        if (applicationContext instanceof ConfigurableApplicationContext configurableApplicationContext) {
            this.beanFactory = configurableApplicationContext;
        }

        final WebService webService = AnnotationUtils.findAnnotation(endpointClass, WebService.class);
        Assert.isTrue(webService != null, "Endpoint [" + endpointClass.getName() + "] is not a web service");

        final ProxyFactory proxyFactory = new ProxyFactory();

        // in case of AOP proxy, some of them are final, so cannot be proxied
        proxyFactory.setTarget(endpoint);
        proxyFactory.addAdvice(this);

        // force usage of CGLIB proxy
        // proxyFactory.setOptimize(true);

        proxy = proxyFactory.getProxy(beanFactory.getClassLoader());
    }

    /**
     * 
     * @param endpoint
     */
    public void setEndpoint(Object endpoint) {
        if (AopUtils.isAopProxy(endpoint)) {
            this.endpointClass = AopProxyUtils.ultimateTargetClass(endpoint);
        } else {
            this.endpointClass = endpoint.getClass();
        }

        this.endpoint = endpoint;
    }

    /**
     * 
     */
    public Object getObject() throws Exception {
        return proxy;
    }

    /**
     * 
     */
    public Class<?> getObjectType() {
        return endpointClass;
    }

    /**
     * 
     */
    public boolean isSingleton() {
        return true;
    }

}
