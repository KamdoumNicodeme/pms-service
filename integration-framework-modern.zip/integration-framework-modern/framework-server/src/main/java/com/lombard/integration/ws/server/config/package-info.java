/**
 * Contains classes to parse XML elements (init-service and service-definitions).
 * <p>
 * The following elements are available:
 *
 * <pre>
 * &lt;intfwk:service-definitions destination="REQ.TRAX.MANDATE.MANDATESERVICE">
 *      &lt;intfwk:service class="com.lombard.integration.framework.service.server.MandateServiceImpl"/>
 * &lt;/intfwk:service-definitions>
 * </pre>
 * </p>
 * <p>
 * And:
 * <pre>
 * &lt;intfwk:init-service destination="REQ.TRAX.MANDATE.MANDATESERVICE"/>
 * </pre>
 * </p>
 * <p>
 * The following attributes are common to both elements:
 * <dl>
 * <dt>destination</dt>
 * <dd>queue on which service endpoints must listen messages</dd>
 * <dt>connection-factory</dt>
 * <dd>connection factory to use. Use svcConnectionFactory by default</dd>
 * <dt>timeout</dt>
 * <dd>receiving timeout</dd>
 * <dt>concurrency</dt>
 * <dd>thread number to listen messages. With the syntax: [a-b], a means min number of thread, and b means max number of thread</dd>
 * </dl>
 */
package com.lombard.integration.ws.server.config;