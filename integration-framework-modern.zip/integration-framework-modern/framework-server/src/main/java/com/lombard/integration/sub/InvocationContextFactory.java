package com.lombard.integration.sub;

import java.util.Map;

import jakarta.jms.Message;

import com.lombard.cdm.IdType;

/**
 * 
 * @author wvandenberghe
 * 
 * @param <T>
 */
public interface InvocationContextFactory< T > {

    /**
     * 
     * @param message
     * @param invokedOn
     * @return
     */
    InvocationContext < T > create(Message message, T invokedOn);

    /**
     * Represents an execution context when invoking a subscriber.
     * 
     * @author wvandenberghe
     * 
     * @param <T>
     *            type of the invocation
     */
    public interface InvocationContext< T > {

        /**
         * Get correlation ID
         * 
         * @return
         */
        String getCorrelationId();

        /**
         * Get initiator name
         * 
         * @return
         */
        IdType getInitiatorName();

        /**
         * Get initiator node
         * 
         * @return
         */
        String getInitiatorNode();

        /**
         * Get destination name
         * 
         * @return
         */
        String getDestinationName();

        /**
         * Get flow name, i.e. the business context, channel name, etc...
         * 
         * @return
         */
        String getFlowName();

        /**
         * The parameter of the invocation
         * 
         * @return
         */
        T getInvokedOn();

        /**
         * Get the message payload. </p> Should be equal to <code>getInvokedOn</code> in case of its return type is
         * <code>String</code>.
         * 
         * @return
         */
        String getPayload();

        /**
         * Get user defined message properties
         * 
         * @return user defined message properties
         */
        Map<String, String> getProperties();
    }

}
