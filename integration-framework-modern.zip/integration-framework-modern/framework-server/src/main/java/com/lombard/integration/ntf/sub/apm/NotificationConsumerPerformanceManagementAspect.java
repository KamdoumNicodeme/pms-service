package com.lombard.integration.ntf.sub.apm;

import static com.lombard.apm.logger.ApmLoggerConstants.*;

import jakarta.jms.JMSException;
import jakarta.jms.Message;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.Ordered;

import com.lombard.apm.logger.ApmLogger;
import com.lombard.apm.logger.ApmLoggerContext;
import com.lombard.apm.logger.ApmLoggerContextFactory;
import com.lombard.apm.logger.ApmLoggerFactory;

@Aspect
public class NotificationConsumerPerformanceManagementAspect implements Ordered {

    private static final ApmLogger APM_LOGGER = ApmLoggerFactory.getApmLogger();
    private static final Logger LOGGER = LoggerFactory.getLogger(NotificationConsumerPerformanceManagementAspect.class);

    @Autowired
    ApmLoggerContextFactory apmLoggerContextFactory;

    @Pointcut("execution(public * com.lombard.integration.sub.DefaultInvokerExporter.onMessage(..))")
    private void esbNotification() {

    }

    @Pointcut("within(com.lombard.integration.sub.*)")
    private void inServicePackage() {

    }

    /**
     */
    @Around("inServicePackage() && esbNotification()")
    public final Object profileNotificationConsumer(final ProceedingJoinPoint pjp) throws Throwable {

        // due to the pointcut configuration, there must be one argument of type
        // Notification
        if (!"onMessage".equals(pjp.getSignature().getName()) || pjp.getArgs().length != 2
                || !(pjp.getArgs()[0] instanceof Message requestMessage)) {
            return pjp.proceed();
        }

        Object result = null;

        final ApmLoggerContext apmLoggerContext;

        try {
            apmLoggerContext = getApmLoggerContext(requestMessage, pjp);
        } catch (Exception e) {
            // Issue with Spring context --> just execute the next interceptor
            // and return.
            return pjp.proceed();
        }

        try {
            // Start timer
            apmLoggerContext.startWatch();

            // Call notification consumer service
            result = pjp.proceed();

            // Stop timer + log
            apmLoggerContext.stopWatch();
            apmLoggerContext.addParam(PARAM_ACTIVITY_STATUS, ACTIVITY_STATUS_SUCCESS);
        } catch (Exception e) {
            apmLoggerContext.addParam(PARAM_ACTIVITY_STATUS, ACTIVITY_STATUS_FAILED);
            apmLoggerContext.addParam(PARAM_ERROR_MESSAGE, e);
            throw e;
        } finally {
            APM_LOGGER.trace(apmLoggerContext);
        }

        return result;
    }

    private ApmLoggerContext getApmLoggerContext(Message requestMessage, final ProceedingJoinPoint pjp) {

        ApmLoggerContext loggerContext;

        loggerContext = apmLoggerContextFactory.createApmLoggerContext("INTEGRATION");

        loggerContext.addParam(PARAM_ACTIVITY_NAME, "CONSUME_NOTIFICATION");
        if (requestMessage != null) {
            setContextParameterFromJmsProperty(requestMessage, loggerContext, PARAM_CORRELATION_ID, "CorrelationID");
            setContextParameterFromJmsProperty(requestMessage, loggerContext, PARAM_INITIATOR_NAME, "InitiatorName");
            setContextParameterFromJmsProperty(requestMessage, loggerContext, PARAM_INITIATOR_NODE, "InititatorNode");
            setContextParameterFromJmsProperty(requestMessage, loggerContext, PARAM_TASK_NAME, "NotificationBusinessContext");
        }

        return loggerContext;
    }

    private void setContextParameterFromJmsProperty(Message requestMessage, ApmLoggerContext loggerContext, String paramName,
            String jmsPropertyName) {

        try {
            String jmsPropertyValue = requestMessage.getStringProperty(jmsPropertyName);
            if (jmsPropertyValue != null) {
                loggerContext.addParam(paramName, jmsPropertyValue);
            }

        } catch (JMSException e) {
            // JMS Exception occurred: the property isn't present in the message
            LOGGER.warn("No property '{}' could be found in the incoming notification {}", jmsPropertyName, requestMessage.toString());
        }

    }

    public int getOrder() {

        return Ordered.HIGHEST_PRECEDENCE;
    }

}
