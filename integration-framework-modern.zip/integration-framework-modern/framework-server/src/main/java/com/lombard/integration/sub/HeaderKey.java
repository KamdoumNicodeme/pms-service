package com.lombard.integration.sub;

public enum HeaderKey {
    CORRELATION_ID("GTWCorrelationId"), INITIATOR_NODE("GTWInitiatorNode"), INITIATOR_NAME("GTWInitiatorName"), CHANNEL("GTWChannel"),
    FILE_NAME("GTWFile_name");

    private final String key;

    private HeaderKey(final String key) {

        this.key = key;
    }

    public String getKey() {

        return key;
    }

}
