package com.lombard.integration.fwk.common.server;


/**
 * <p>Class contains transport and target service's configuration.</p> 
 * 
 * <p>Usualy object instanes of the class are retreived from spring context 
 * during framework initialization, but they can also be created on the fly.
 * </p>
 * 
 * <p>Spring context example:</p>
 * <code>
 *   <bean id="ExampleServiceConfig" 
 *   		class="lu.lombard.integration.fwk.common.ServiceConfig">
 *    	<property name="name" value="ExampleService" /> *     
 *    	<property name="auto" value="true" />
 *    	<property name="serviceBean" value="ExampleImpl" />
 *    	<property name="destination" value="lia.dev.example" />
 *    	<property name="interfaceClass" 
 *                   value="com.lombard.integration.fwk.services.Example" />
 *    </bean>
 * </code>
 * 
 * @author Aleksandar Valchev
 */
@Deprecated
public class ServiceConfig {

	/**
	 * <p>Field contains the name of the target bean, which implements the 
	 * service interface. A bean with such name must be defined into spring
	 * context configuration in order to create service properly.
	 * The type Object is temporarily used instead of IService because of problems with the xjc-plugin.</p>
	 * 
	 * <p>Corresponding name of the property in spring context is 
	 * <code>serviceBean</code>.
	 */
	private Object	serviceBean;
	/**
	 * <p>Name of the service. With this field framework is able to start, 
	 * restart or stop the service.</p>
	 */
	private String 	name;
	/**
	 * <p>Indicates if framework has to start the service during the 
	 * initialization.</p>
	 * 
	 * <p>If <code>false</code> the service is not started during framework 
	 * intialization<p>
	 */
	private Boolean auto;
	/**
	 * <p>The name of the interface class for the service.<p>. 
	 * 
	 * <p>Usualy the interface sould be automatically generated from WSDL.</p> 
	 */
	private String 	interfaceClass;
	
	/**
	 * <p>The name of the JMS destination that is going to be used for 
	 * accepting service requests.</p>
	 */
	private String destination;
	
	/**
	 * <p>Type of the JMS message.</p>
	 * 
	 * <p>Allowed values are:</p>
	 * <ul>
	 *   <li><b>binary</b> - for using </code>ByteMessage</code> for 
	 *   communication.</li>
	 *   <li><b>text</b> - for using </code>TextMessage</code> for 
	 *   communication.</li>
	 * </ul>
	 */	
	private String messageType;
	
	private int concurrentConsumers = 1;
	
	public ServiceConfig() {
		super();
	}
	
	public String getMessageType() {
		return messageType;
	}
	
	public void setMessageType(String messageType) {
		this.messageType = messageType;
	}
	
	public String getDestination() {
		return destination;
	}
	
	public void setDestination(String destination) {
		this.destination = destination;
	}
	
	public String getInterfaceClass() {
		return interfaceClass;
	}
	
	public void setInterfaceClass(String interfaceClass) {
		this.interfaceClass = interfaceClass;
	}
	
	public Boolean getAuto() {
		return auto;
	}
	
	public void setAuto(Boolean auto) {
		this.auto = auto;
	}
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public Object getServiceBean() {
		return serviceBean;
	}
	
	public void setServiceBean(Object serviceBean) {
		this.serviceBean = serviceBean;
	}

	public void setConcurrentConsumers(int concurrentConsumers) {
		this.concurrentConsumers = concurrentConsumers;
	}

	public int getConcurrentConsumers() {
		return concurrentConsumers;
	}
	
	
}
