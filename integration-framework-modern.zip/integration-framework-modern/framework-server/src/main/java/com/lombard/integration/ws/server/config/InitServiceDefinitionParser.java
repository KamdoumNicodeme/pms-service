package com.lombard.integration.ws.server.config;

import org.springframework.beans.factory.support.AbstractBeanDefinition;
import org.springframework.beans.factory.support.BeanDefinitionBuilder;
import org.springframework.beans.factory.support.BeanDefinitionRegistry;
import org.springframework.beans.factory.xml.ParserContext;
import org.w3c.dom.Element;

import com.lombard.integration.config.AbstractIntfwkDefinitionParser;
import com.lombard.integration.ws.server.support.ServiceDefinitionPostProcessor;

/**
 * Parser dedicated to <code>init-service</code> element.
 * 
 * @author wvandenberghe
 * 
 */
public class InitServiceDefinitionParser extends AbstractIntfwkDefinitionParser {

    /**
     * {@inheritDoc}
     */
    @Override
    protected AbstractBeanDefinition parseInternal(Element element, ParserContext parserContext) {
        // register the bean processor
        BeanDefinitionBuilder builder =
                BeanDefinitionBuilder.rootBeanDefinition(ServiceDefinitionPostProcessor.class);
        BeanDefinitionRegistry registry = parserContext.getRegistry();

        // delegate the parsing
        AbstractBeanDefinition bean = builder.getBeanDefinition();
        String beanName = resolveId(element, bean, parserContext);
        registry.registerBeanDefinition(beanName, bean);

        ServiceDefinitionsDefinitionParser parser = new ServiceDefinitionsDefinitionParser();
        AbstractBeanDefinition beanDefinition = parser.parseInternal(element, parserContext);

        String id = resolveId(element, beanDefinition, parserContext);
        builder.addPropertyReference("messageListenerContainer", id);

        return beanDefinition;
    }

    @Override
    protected String getDefaultConnectionFactoryReference() {
        return null;
    }
}
