package com.lombard.integration.gtw.sub;

import java.util.Map;

import com.lombard.integration.sub.ArgumentGenerator;
import com.lombard.integration.sub.InvocationContextFactory.InvocationContext;
import com.lombard.integration.sub.mapping.EndpointMapper.EndpointMapping;

public class GatewayArgumentGenerator implements ArgumentGenerator<String> {

    public Object[] getArguments(final EndpointMapping endpointMapping, final InvocationContext<String> invocationContext) {

        final Class<?>[] types = endpointMapping.getMethod().getParameterTypes();
        final Object[] args = new Object[types.length];

        for (int i = 0; i < types.length; i++) {
            args[i] = getValueFromType(types[i], invocationContext);
        }

        return args;
    }

    private Object getValueFromType(final Class<?> type, final InvocationContext<String> invocationContext) {

        return Map.class.equals(type) ? invocationContext.getProperties() : invocationContext.getPayload();
    }

}
