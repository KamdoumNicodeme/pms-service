package com.lombard.integration.ws.server.support;

import java.util.Arrays;
import java.util.LinkedHashSet;
import java.util.Set;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.BeanCreationException;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.config.BeanPostProcessor;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.jms.listener.AbstractMessageListenerContainer;
import org.springframework.util.Assert;
import org.springframework.ws.server.EndpointExceptionResolver;
import org.springframework.ws.server.EndpointMapping;
import org.springframework.ws.server.endpoint.AbstractEndpointExceptionResolver;
import org.springframework.ws.soap.server.SoapMessageDispatcher;
import org.springframework.ws.transport.WebServiceMessageReceiver;
import org.springframework.ws.transport.jms.WebServiceMessageListener;

import com.lombard.integration.fwk.service.annotation.ServiceDefinition;
import com.lombard.integration.ws.server.WebServiceServerFactoryBean;
import com.lombard.integration.ws.server.soap.SoapActionMethodEndpointMapping;

/**
 * Processor that react on {@link ServiceDefinition} annotated bean.
 * <p>
 * It creates service endpoints framework compliant by adding them as candidate to the endpoint mapping (based on
 * SOAP action). Consequences are:
 * <ul>
 * <li>wrap bean in a proxy</li>
 * <li>register service endpoint to the exception resolvers</li>
 * </ul>
 * 
 * @author wvandenberghe
 * @see com.lombard.integration.ws.server.WebServiceServerMethodInterceptor
 * @see WebServiceServerFactoryBean
 */
public class ServiceDefinitionPostProcessor implements BeanPostProcessor, InitializingBean, ApplicationContextAware {

    private static final Log logger = LogFactory.getLog(ServiceDefinitionPostProcessor.class);

    private ConfigurableApplicationContext applicationContext;

    private SoapMessageDispatcher messageDispatcher;

    /**
     * Extract message receiver from the message listener container.
     * 
     * @param messageListenerContainer
     * @see WebServiceMessageListener
     * @see SoapMessageDispatcher
     */
    public void setMessageListenerContainer(AbstractMessageListenerContainer messageListenerContainer) {
        Object messageListener = messageListenerContainer.getMessageListener();
        if (messageListener instanceof WebServiceMessageListener wsMessageListener) {
            WebServiceMessageReceiver wsMessageReceiver = wsMessageListener.getMessageReceiver();
            if (wsMessageReceiver instanceof SoapMessageDispatcher soapMessageDispatcher) {
                messageDispatcher = soapMessageDispatcher;
            } else {
                throw new BeanCreationException("Container does not contains SOAP message receiver");
            }
        } else {
            throw new BeanCreationException("Container does not contains web service message listener");
        }
    }

    /**
     * {@inheritDoc}
     */
    public void afterPropertiesSet() throws Exception {
        Assert.notNull(messageDispatcher, "Property [messageListenerContainer] is mandatory");
    }

    /**
     * {@inheritDoc}
     */
    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
        if (applicationContext instanceof ConfigurableApplicationContext configurableApplicationContext) {
            this.applicationContext = configurableApplicationContext;
        } else {
            throw new IllegalArgumentException(
                    "Application context is not instance of ConfigurableApplicationContext");
        }
    }

    /**
     * {@inheritDoc}
     */
    public Object postProcessBeforeInitialization(Object bean, String beanName) throws BeansException {
        Class<?> beanClass = bean.getClass();
        if (beanClass.isAnnotationPresent(ServiceDefinition.class)) {
            if (logger.isDebugEnabled()) {
                logger.debug("Bean " + beanName + " is declared as a service definition");
            }

            // get SOAP action endpoint mapping
            SoapActionMethodEndpointMapping endpointMapping = getMethodEndpointMapping();
            if (endpointMapping == null) {
                throw new BeanCreationException(beanName,
                        "No 'SoapActionMethodEndpointMapping' registered by the message receiver");
            }

            // get the declared endpoints...
            Object[] endpoints = endpointMapping.getEndpoints();
            Object proxyBean = createServiceEndpoint(bean, beanName);

            // and add the newly detected
            Object[] newEndpoints;
            if (endpoints == null) {
                // if there is not yet an endpoint
                newEndpoints = new Object[] {proxyBean};
            } else {
                // if there is already some endpoint
                newEndpoints = Arrays.copyOf(endpoints, endpoints.length + 1);
                newEndpoints[endpoints.length] = proxyBean;
            }
            endpointMapping.setEndpoints(newEndpoints);

            // register endpoints to exception resolver
            registerEndpointExceptionResolver(newEndpoints);

            logger.info("[" + beanName + "] service definition registered");

            return proxyBean;
        }

        return bean;
    }

    private SoapActionMethodEndpointMapping getMethodEndpointMapping() {
        for (EndpointMapping em : messageDispatcher.getEndpointMappings()) {
            if (em instanceof SoapActionMethodEndpointMapping soapActionMethodEndpointMapping) {
                return soapActionMethodEndpointMapping;
            }
        }

        return null;
    }

    /**
     * Register endpoint to the exception resolvers.
     * <p>
     * Override this method to implement another exception resolver strategy.
     * 
     * @param endpoints
     *            service endpoints
     */
    private void registerEndpointExceptionResolver(Object[] endpoints) {
        final Set<Object> endpointSet = new LinkedHashSet<>(Arrays.asList(endpoints));

        for (EndpointExceptionResolver resolver : messageDispatcher.getEndpointExceptionResolvers()) {
            if (resolver instanceof AbstractEndpointExceptionResolver abstractEndpointExceptionResolver) {
                abstractEndpointExceptionResolver.setMappedEndpoints(endpointSet);
            }
        }
    }

    /**
     * Create the service endpoint in a usable manner by the framework.
     * <p>
     * Override this method to implement another service endpoint creation strategy.
     * 
     * @param bean
     *            service endpoint
     * @param beanName
     *            service nedpoint name
     * @return a framework compliant service endpoint
     * @throws BeansException
     * @see WebServiceServerFactoryBean
     */
    private Object createServiceEndpoint(Object bean, String beanName) throws BeansException {
        final WebServiceServerFactoryBean factoryBean = new WebServiceServerFactoryBean();
        factoryBean.setEndpoint(bean);
        factoryBean.setApplicationContext(applicationContext);

        try {
            return factoryBean.getObject();
        } catch (Exception e) {
            throw new BeanCreationException(beanName, "Error occured while exporting Web Service", e);
        }
    }

    /**
     * {@inheritDoc}
     */
    public Object postProcessAfterInitialization(Object bean, String beanName) throws BeansException {
        return bean;
    }

}
