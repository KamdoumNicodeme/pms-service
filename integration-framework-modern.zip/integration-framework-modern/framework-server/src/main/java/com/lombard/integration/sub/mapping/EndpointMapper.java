package com.lombard.integration.sub.mapping;

import java.lang.reflect.Method;
import java.util.Map;

import com.lombard.csm.Notification;

/**
 * Maintains the endpoints that can serve a {@link Notification}. Endpoints are plain old Java object.
 * 
 * @author wvandenberghe
 * 
 * @see com.lombard.integration.fwk.notification.annotation.BusinessKeys
 * @see com.lombard.integration.fwk.notification.annotation.BusinessKey
 * @see com.lombard.integration.fwk.notification.annotation.Selector
 */
public interface EndpointMapper {

    /**
     * Get endpoints
     * 
     * @return
     */
    Object[] getEndpoints();

    /**
     * Set endpoints
     * 
     * @param endpoint
     */
    void setEndpoints(Object[] endpoint);

    /**
     * Get the mapping for the {@link Notification}.
     * 
     * @param flowName
     *            execution flow name
     * @return endpoint corresponding to this notification if it exists, else, return null
     */
    EndpointMapping getEndpointMapping(String flowName);

    /**
     * Describes an endpoint mapping, i.e. the relation between endpoint, its methods and metadata such as consumed
     * business context, and business keys for tracing.
     * 
     * @author wvandenberghe
     * 
     */
    public interface EndpointMapping {

        /**
         * Get business keys
         * 
         * @return
         */
        Map<String, String> getBusinessKeys();

        /**
         * Get the object containing the endpoint
         * 
         * @return
         */
        Object getEndpoint();

        /**
         * Get the method implementing the endpoint
         * 
         * @return
         */
        Method getMethod();

        /**
         * Get the argument type
         * 
         * @return service method argument
         */
        Class<?> getArgumentType();
    }

}
