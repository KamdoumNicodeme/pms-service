package com.lombard.integration.tntf.hospital;

import org.springframework.jms.remoting.JmsInvokerProxyFactoryBean;

/**
 * Default JMS proxy factory bean for {@link HospitalService}
 * 
 * @author wvandenberghe
 * 
 */
public class HospitalServiceProxyFactoryBean extends JmsInvokerProxyFactoryBean {

    private static final String DEFAULT_DESTINATION_NAME = "TNTF.HOSPITAL";

    /**
     * Default constructor.
     * <p>
     * Apply default settings such as service interface and queue name.
     */
    public HospitalServiceProxyFactoryBean() {
        setServiceInterface(HospitalService.class);
        setReceiveTimeout(1);
        setQueueName(DEFAULT_DESTINATION_NAME);
    }
}
