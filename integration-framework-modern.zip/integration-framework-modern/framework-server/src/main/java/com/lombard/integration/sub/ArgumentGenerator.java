package com.lombard.integration.sub;

import com.lombard.integration.sub.InvocationContextFactory.InvocationContext;
import com.lombard.integration.sub.mapping.EndpointMapper.EndpointMapping;

public interface ArgumentGenerator< T > {

    Object[] getArguments(EndpointMapping endpointMapping, InvocationContext<T> invocationContext);

}
