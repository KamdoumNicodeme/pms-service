package com.lombard.integration.fwk.common.server;

import java.util.List;

import jakarta.annotation.PostConstruct;
import jakarta.annotation.Resource;
import jakarta.jms.ConnectionFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;

/**
 * <p>
 * Class is framework's entry point with <code>configure()</code> method. Also the class act as a holder for resoures
 * like jms connection factories, services, spring context and configuration parameters. All methods are static which
 * allows access to the resoures from the clients.
 * </p>
 * 
 * <p>
 * For more information about the starting process see <code>configure()</code>.
 * </p>
 * 
 * @author Aleksandar Valchev
 */
public class ServiceEnvironment {

    @Autowired
    private ApplicationContext ctx;

    @Resource(name = "Services")
    private List<ServiceWrapper> services;

    @Qualifier("connectionFactory")
    private ConnectionFactory queueConnectionFactory;

    @Autowired
    @Qualifier("connectionFactory")
    private ConnectionFactory topicConnectionFactory;

    @Deprecated
    public ConnectionFactory getQueueConnectionFactory() {
        return queueConnectionFactory;
    }

    public ConnectionFactory getTopicConnectionFactory() {
        return topicConnectionFactory;
    }

    public List<ServiceWrapper> getServices() {
        return services;
    }

    /**
     * <p>
     * Method is responsible for:
     * </p>
     * 
     * <ul>
     * <li>Creating spring context.</li>
     * <li>Retreiving JMS queue and topic connection factories.</li>
     * <li>Starting services.</li>
     * </ul>
     * 
     * @throws Exception
     */
    @PostConstruct
    public void configure() {
        autoStartServices();

        ((ConfigurableApplicationContext) ctx).registerShutdownHook();

    }

    private void autoStartServices() {
        for (ServiceWrapper s : services) {
            if (s.getConfig().getAuto()) {
                try {
                    s.configure();
                    s.startService();
                } catch (ClassNotFoundException e) {
                    continue;
                }
            }
        }
    }

}
