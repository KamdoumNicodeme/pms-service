package com.lombard.integration.sub.mapping;

import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.Map;

import org.apache.commons.lang.ArrayUtils;
import org.springframework.util.ReflectionUtils;

/**
 * Abstract implementation of the {@link EndpointMapper}.
 * 
 * @author wvandenberghe
 * 
 */
public abstract class AbstractEndpointMapper implements EndpointMapper {

    private Object[] endpoints = new Object[0];

    /**
     * {@inheritDoc}
     */
    public Object[] getEndpoints() {
        return endpoints;
    }

    /**
     * {@inheritDoc}
     */
    public void setEndpoints(Object[] endpoints) {
        for (Object endpoint : endpoints) {
            int index = ArrayUtils.indexOf(getEndpoints(), endpoint);
            if (index == ArrayUtils.INDEX_NOT_FOUND) {
                registerEndpoint(endpoint);
            }
        }

        this.endpoints = endpoints.clone();
    }

    /**
     * Register this endpoint.
     * 
     * @param endpoint
     *            potential notification consumer
     */
    public void registerEndpoint(final Object endpoint) {
        ReflectionUtils.doWithMethods(endpoint.getClass(),
                method -> registerEndpointMethodMapping(endpoint, method),
                PUBLIC_USER_DEFINED_FILTER);
    }

    /**
     * Register methods endpoint mapping.
     * 
     * @param endpoint
     *            notification endpoint
     * @param method
     *            defined by endpoint
     */
    protected abstract void registerEndpointMethodMapping(Object endpoint, Method method);

    /**
     * Filter public, non static and user defined methods.
     */
    private static final ReflectionUtils.MethodFilter PUBLIC_USER_DEFINED_FILTER =
            method -> !Modifier.isStatic(method.getModifiers()) && Modifier.isPublic(method.getModifiers())
                    && method.getDeclaringClass() != Object.class;

    /**
     * 
     * @author wvandenberghe
     * 
     */
    public class DefaultEndpointMapping implements EndpointMapping {

        private final Map<String, String> businessKeys;
        private final Object endpoint;
        private final Method method;
        private final Class<?> argumentType;

        /**
         * Constructor for immutable definition.
         * 
         * @param endpoint
         * @param method
         * @param argumentType
         */
        public DefaultEndpointMapping(Map<String, String> businessKeys, Object endpoint, Method method,
                Class<?> argumentType) {
            this.businessKeys = businessKeys;
            this.endpoint = endpoint;
            this.method = method;
            this.argumentType = argumentType;
        }

        /**
         * {@inheritDoc}
         */
        public Map<String, String> getBusinessKeys() {
            return businessKeys;
        }

        /**
         * {@inheritDoc}
         */
        public Object getEndpoint() {
            return endpoint;
        }

        /**
         * {@inheritDoc}
         */
        public Method getMethod() {
            return method;
        }

        public Class<?> getArgumentType() {
            return argumentType;
        }

        /**
         * {@inheritDoc}
         */
        @Override
        public String toString() {
            return getEndpoint().getClass().getSimpleName() + "." + getMethod().getName() + "("
                    + getArgumentType().getSimpleName() + ")";
        }
    }
}
