/**
 * 
 */
package com.lombard.integration.ntf.sub.config;