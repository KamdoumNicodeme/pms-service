package com.lombard.integration.ntf.sub;

import java.beans.PropertyDescriptor;
import java.lang.reflect.Method;

import org.springframework.beans.BeanUtils;
import org.springframework.util.ReflectionUtils;

import com.lombard.csm.Notification;
import com.lombard.integration.sub.ArgumentGenerator;
import com.lombard.integration.sub.InvocationContextFactory.InvocationContext;
import com.lombard.integration.sub.mapping.EndpointMapper.EndpointMapping;

public class NotificationArgumentGenerator implements ArgumentGenerator<Notification> {

    public Object[] getArguments(final EndpointMapping endpointMapping, final InvocationContext<Notification> invocationContext) {

        final Object[] res = new Object[1];
        // if argument and invocation result are not the same type
        if (!endpointMapping.getArgumentType().isAssignableFrom(invocationContext.getInvokedOn().getClass())) {
            // search at the first property level if something can satisfy
            PropertyDescriptor[] descriptors = BeanUtils.getPropertyDescriptors(invocationContext.getInvokedOn().getClass());
            for (PropertyDescriptor descriptor : descriptors) {
                if (endpointMapping.getArgumentType().isAssignableFrom(descriptor.getPropertyType())) {
                    // it is the case, get the value
                    Method readMethod = descriptor.getReadMethod();
                    res[0] = ReflectionUtils.invokeMethod(readMethod, invocationContext.getInvokedOn());
                }
            }
        } else {
            // by default, return the invocation result
            res[0] = invocationContext.getInvokedOn();
        }
        return res;
    }

}
