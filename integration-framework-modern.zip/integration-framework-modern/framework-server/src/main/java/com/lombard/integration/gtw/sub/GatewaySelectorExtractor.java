package com.lombard.integration.gtw.sub;

import java.lang.reflect.Method;

import org.springframework.core.annotation.AnnotationUtils;

import com.lombard.integration.fwk.notification.annotation.Selector;
import com.lombard.integration.sub.mapping.MethodEndpointMapper.SelectorExtractor;

/**
 * 
 * @author wvandenberghe
 * 
 */
public class GatewaySelectorExtractor implements SelectorExtractor {

    /**
     * {@inheritDoc}
     */
    public String extract(Method method) {
        Selector selector = AnnotationUtils.findAnnotation(method, Selector.class);
        if (selector != null) {
            return selector.channel();
        }
        return null;
    }

}
