/**
 * Contains classes to deal with {@link com.lombard.csm.Notification} consumption.
 */
package com.lombard.integration.ntf.sub;