package com.lombard.integration.sub.config;

import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.beans.factory.config.BeanDefinitionHolder;
import org.springframework.beans.factory.support.AbstractBeanDefinition;
import org.springframework.beans.factory.support.BeanDefinitionBuilder;
import org.springframework.beans.factory.xml.ParserContext;
import org.springframework.jms.listener.SimpleMessageListenerContainer;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.w3c.dom.Element;

import com.lombard.integration.ntf.config.AbstractMessagingDefinitionParser;
import com.lombard.integration.sub.DefaultInvokerExporter;
import com.lombard.integration.sub.mapping.MethodEndpointMapper;
import com.lombard.integration.sub.support.SubscriberBeanPostProcessor;
import com.lombard.integration.tntf.hospital.AsyncHospitalService;

/**
 * 
 * @author wvandenberghe
 * 
 */
public abstract class AbstractMessageSubscriberDefinitionParser extends AbstractMessagingDefinitionParser {

    /**
     * 
     */
    @Override
    protected AbstractBeanDefinition parseInternal(Element element, ParserContext parserContext) {

        BeanDefinitionBuilder builder = BeanDefinitionBuilder.genericBeanDefinition(SimpleMessageListenerContainer.class);

        String connectionFactory = element.getAttribute(CONNECTION_FACTORY_ATT);
        if (connectionFactory.trim().length() == 0) {
            connectionFactory = getDefaultConnectionFactoryReference();
        }
        builder.addPropertyReference("connectionFactory", connectionFactory);

        String destination = element.getAttribute(DESTINATION_ATT);
        builder.addPropertyValue("destinationName", destination);

        String concurrency = element.getAttribute(CONCURRENCY_ATT);
        if (concurrency.trim().length() > 0) {
            builder.addPropertyValue("concurrency", concurrency);
        }

        BeanDefinition messageListener = parseMessageListener(element, parserContext);
        builder.addPropertyValue("messageListener", messageListener);

        return builder.getBeanDefinition();
    }

    /**
     * Parse a message listener.
     * 
     * @param element
     * @param parserContext
     * @return
     */
    private BeanDefinition parseMessageListener(Element element, ParserContext parserContext) {

        BeanDefinitionBuilder builder = BeanDefinitionBuilder.genericBeanDefinition(DefaultInvokerExporter.class);

        BeanDefinition messageConverter = parseMessageConverter(element, parserContext);
        builder.addPropertyValue("messageConverter", messageConverter);

        BeanDefinition hospitalService = parseHospitalService(element, parserContext);
        builder.addPropertyValue("hospitalService", hospitalService);

        BeanDefinition businessKeyEvaluator = getBusinessKeyEvaluator();
        builder.addPropertyValue("businessKeyEvaluator", businessKeyEvaluator);

        String idType = element.getAttribute(ID_TYPE_ATT);
        builder.addPropertyValue("idType", idType);

        String beanId = registerEndpointMapper(element, parserContext);
        builder.addPropertyReference("endpointMapper", beanId);

        BeanDefinition invocationContextFactory = getInvocationContextFactory();
        builder.addPropertyValue("invocationContextFactory", invocationContextFactory);

        builder.addPropertyValue("argumentGenerator", getArgumentGenerator());

        builder.addPropertyValue("responseManager", getResponseManager(parserContext));

        String service = element.getAttribute(CLASS_ATT);
        if (service != null && service.trim().length() > 0) {
            builder.addPropertyValue("serviceInterface", getServiceInterface());

            BeanDefinition serviceBean = parseConsumer(element);
            builder.addPropertyValue("service", serviceBean);
        } else {
            registerPostProcessor(beanId, element, parserContext);
        }

        return builder.getBeanDefinition();
    }

    /**
     * 
     * @param element
     * @param parserContext
     * @return
     */
    private String registerEndpointMapper(Element element, ParserContext parserContext) {

        BeanDefinitionBuilder builder = BeanDefinitionBuilder.genericBeanDefinition(MethodEndpointMapper.class);

        builder.addPropertyValue("consumedType", getConsumedType());

        BeanDefinition selectorExtractor = getSelectorExtractor();
        builder.addPropertyValue("selectorExtractor", selectorExtractor);

        String beanId = resolveId(element, builder.getBeanDefinition(), parserContext);
        registerBeanDefinition(new BeanDefinitionHolder(builder.getBeanDefinition(), beanId), parserContext.getRegistry());

        return beanId;
    }

    /**
     * 
     * @param element
     * @param parserContext
     * @return
     */
    private BeanDefinition parseHospitalService(Element element, ParserContext parserContext) {

        BeanDefinitionBuilder builder = BeanDefinitionBuilder.genericBeanDefinition(AsyncHospitalService.class);

        BeanDefinition taskExecutor = getTaskExecutor();
        builder.addPropertyValue("taskExecutor", taskExecutor);

        builder.addPropertyReference("connectionFactory", "ntiConnectionFactory");

        builder.addPropertyValue("queueName", "TNTF.HOSPITAL");

        // just to be sure the default one will be used
        BeanDefinition messageConverter = super.parseMessageConverter(element, parserContext);
        builder.addPropertyValue("messageConverter", messageConverter);

        return builder.getBeanDefinition();
    }

    /**
     * 
     * @return
     */
    private BeanDefinition getTaskExecutor() {

        BeanDefinitionBuilder builder = BeanDefinitionBuilder.genericBeanDefinition(ThreadPoolTaskExecutor.class);

        builder.addPropertyValue("waitForTasksToCompleteOnShutdown", true);

        return builder.getBeanDefinition();
    }

    /**
     * Parse for consumer.
     * 
     * @param element
     * @return
     */
    private BeanDefinition parseConsumer(Element element) {

        String service = element.getAttribute(CLASS_ATT);
        return BeanDefinitionBuilder.genericBeanDefinition(service).getBeanDefinition();
    }

    /**
     * 
     * @param endpointMapperId
     * @param element
     * @param parserContext
     */
    private void registerPostProcessor(String endpointMapperId, Element element, ParserContext parserContext) {

        BeanDefinitionBuilder postProcessor = getPostProcessorBuilder();
        postProcessor.addPropertyReference("endpointMapper", endpointMapperId);

        String beanId = resolveId(element, postProcessor.getBeanDefinition(), parserContext);
        registerBeanDefinition(new BeanDefinitionHolder(postProcessor.getBeanDefinition(), beanId), parserContext.getRegistry());
    }

    /**
     * 
     * @return
     */
    private BeanDefinitionBuilder getPostProcessorBuilder() {

        BeanDefinitionBuilder builder = BeanDefinitionBuilder.genericBeanDefinition(SubscriberBeanPostProcessor.class);

        builder.addPropertyValue("annotationType", getAnnotationType());

        return builder;
    }

    /**
     * Get the invocation context factory
     * 
     * @return
     */
    protected abstract BeanDefinition getInvocationContextFactory();

    /**
     * The selector extractor
     * 
     * @return
     */
    protected abstract BeanDefinition getSelectorExtractor();

    /**
     * The type resulting from the message conversion
     * 
     * @return
     */
    protected abstract Class<?> getConsumedType();

    /**
     * Marker annotation for classes implementing any consumption logic.
     * 
     * @return
     */
    protected abstract Class<?> getAnnotationType();

    /**
     * Get the service interface exported by this invoker
     * 
     * @return
     */
    protected abstract Class<?> getServiceInterface();

    protected abstract BeanDefinition getArgumentGenerator();

    protected abstract BeanDefinition getResponseManager(ParserContext parserContext);
}
