package com.lombard.integration.ntf.sub.config;

import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.beans.factory.support.BeanDefinitionBuilder;
import org.springframework.beans.factory.xml.ParserContext;

import com.lombard.csm.Notification;
import com.lombard.integration.fwk.notification.annotation.Consumer;
import com.lombard.integration.ntf.NotificationService;
import com.lombard.integration.ntf.sub.NotificationArgumentGenerator;
import com.lombard.integration.ntf.sub.NotificationInvocationContextFactory;
import com.lombard.integration.ntf.sub.NotificationSelectorExtractor;
import com.lombard.integration.sub.config.AbstractMessageSubscriberDefinitionParser;

/**
 * Parser dedicated to <code>notif-consumer</code> definition.
 * 
 * @author wvandenberghe
 * 
 */
public class NotificationConsumerDefinitionParser extends AbstractMessageSubscriberDefinitionParser {

    private static final String DEFAULT_CONNECTION_FACTORY = "ntiConnectionFactory";

    /**
     * {@inheritDoc}
     */
    @Override
    protected Class<?> getAnnotationType() {

        return Consumer.class;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    protected Class<?> getConsumedType() {

        return Notification.class;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    protected String getDefaultConnectionFactoryReference() {

        return DEFAULT_CONNECTION_FACTORY;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    protected BeanDefinition getSelectorExtractor() {

        return BeanDefinitionBuilder.genericBeanDefinition(NotificationSelectorExtractor.class).getBeanDefinition();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    protected Class<?> getServiceInterface() {

        return NotificationService.class;
    }

    @Override
    protected BeanDefinition getInvocationContextFactory() {

        return BeanDefinitionBuilder.genericBeanDefinition(NotificationInvocationContextFactory.class).getBeanDefinition();
    }

    @Override
    protected BeanDefinition getArgumentGenerator() {

        return BeanDefinitionBuilder.genericBeanDefinition(NotificationArgumentGenerator.class).getBeanDefinition();
    }

    @Override
    protected BeanDefinition getResponseManager(final ParserContext parserContext) {

        return null;
    }
}
