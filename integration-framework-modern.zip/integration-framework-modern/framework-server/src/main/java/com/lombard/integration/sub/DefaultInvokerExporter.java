package com.lombard.integration.sub;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import jakarta.jms.IllegalStateException;
import jakarta.jms.JMSException;
import jakarta.jms.Message;
import jakarta.jms.Session;

import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.jms.remoting.JmsInvokerServiceExporter;
import org.springframework.remoting.support.RemoteInvocation;
import org.springframework.remoting.support.RemoteInvocationResult;
import org.springframework.util.Assert;
import org.springframework.util.ReflectionUtils;

import com.lombard.cdm.ActivityHandler;
import com.lombard.cdm.IdType;
import com.lombard.cdm.StatusType;
import com.lombard.integration.fwk.utils.ActivityHandlerBuilder;
import com.lombard.integration.fwk.utils.CorrelationHandlerBuilder;
import com.lombard.integration.ntf.properties.BusinessKeyEvaluator;
import com.lombard.integration.sub.InvocationContextFactory.InvocationContext;
import com.lombard.integration.sub.mapping.EndpointMapper;
import com.lombard.integration.sub.mapping.EndpointMapper.EndpointMapping;
import com.lombard.integration.tntf.hospital.HospitalService;
import com.lombard.integration.tntf.trace.TraceService;
import com.lombard.integration.util.TracerUtils;

/**
 * Abstract invoker exporter that provided additional functionalities such as tracing and hospital linked to the
 * lifecycle management.
 * <p>
 * Tracing is used:
 * <ul>
 * <li>before invocation PROCESS_START status</li>
 * <li>after invocation PROCESS_ENDED status</li>
 * <li>when an exception is thrown PROCESS_FAILED status</li>
 * </ul>
 * Hospital is used to send notification to hospital when an exception is thrown.
 */
public class DefaultInvokerExporter< T > extends JmsInvokerServiceExporter implements SubscriberLifecycle<T>, ApplicationContextAware {

    private static final String RECEIVE_MSG = "Receive message [%s]";

    private Object proxy;

    private ApplicationContext applicationContext;

    private HospitalService hospitalService;

    private IdType idType;

    private EndpointMapper endpointMapper;

    private BusinessKeyEvaluator businessKeyEvaluator;

    private InvocationContextFactory<T> invocationContextFactory;

    private ArgumentGenerator<T> argumentGenerator;

    private ResponseManager responseManager;

    /**
     * {@inheritDoc}
     */
    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {

        this.applicationContext = applicationContext;
    }

    /**
     * Set hospital service
     * 
     * @param hospitalService
     *            hospital service
     */
    public void setHospitalService(HospitalService hospitalService) {

        this.hospitalService = hospitalService;
    }

    /**
     * 
     * @param idType
     */
    public void setIdType(IdType idType) {

        this.idType = idType;
    }

    /**
     * Set endpoint mapper
     * 
     * @param endpointMapper
     */
    public void setEndpointMapper(EndpointMapper endpointMapper) {

        this.endpointMapper = endpointMapper;
    }

    /**
     * Set business key evaluator
     * 
     * @param businessKeyEvaluator
     */
    public void setBusinessKeyEvaluator(BusinessKeyEvaluator businessKeyEvaluator) {

        this.businessKeyEvaluator = businessKeyEvaluator;
    }

    /**
     * Set invocation context factory
     * 
     * @param invocationContextFactory
     */
    public void setInvocationContextFactory(InvocationContextFactory<T> invocationContextFactory) {

        this.invocationContextFactory = invocationContextFactory;
    }

    public void setArgumentGenerator(final ArgumentGenerator<T> argumentGenerator) {

        this.argumentGenerator = argumentGenerator;
    }

    public void setResponseManager(final ResponseManager responseManager) {

        this.responseManager = responseManager;
    }

    /**
     * Override the behaviour to get the proxy reference.
     */
    @Override
    public void afterPropertiesSet() {

        Assert.notNull(hospitalService, "Property 'hospitalService' is mandatory");
        Assert.notNull(idType, "Property 'idType' is mandatory");
        Assert.notNull(endpointMapper, "Property 'endpointMapper' is mandatory");
        Assert.notNull(businessKeyEvaluator, "Property 'businessKeyEvaluator' is mandatory");
        Assert.notNull(invocationContextFactory, "Property 'invocationContextFactory' is mandatory");

        if (this.getService() != null) {
            this.proxy = getProxyForService();
            super.afterPropertiesSet();
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void onMessage(Message requestMessage, Session session) throws JMSException {

        final RemoteInvocation invocation = readRemoteInvocation(requestMessage);

        Object[] args = invocation.getArguments();
        if (args.length != 1) {
            throw new IllegalStateException("Invocation occured for (" + args.length + ") arguments");
        }

        @SuppressWarnings("unchecked")
        InvocationContext<T> invocationContext = invocationContextFactory.create(requestMessage, (T) args[0]);

        beforeInvocation(invocationContext);

        try {
            invoke(invocationContext, invocation);
        } catch (Throwable thrown) {
            logger.error("Error while invoking", thrown);
            onInvocationException(invocationContext, thrown);

            return;
        }

        afterInvocation(invocationContext);
    }

    /**
     * 
     * @param endpointMapping
     * @param inocationContext
     * @throws Exception
     */
    private void invoke(InvocationContext<T> invocationContext, RemoteInvocation invocation) throws Throwable {

        // in case of service has been reach, execute invocation
        if (this.getService() != null) {
            RemoteInvocationResult result = invokeAndCreateResult(invocation, this.proxy);

            if (result.hasException()) {
                throw result.getException();
            }
        } else {
            EndpointMapping endpointMapping = endpointMapper.getEndpointMapping(invocationContext.getFlowName());

            if (endpointMapping == null) {
                throw new IllegalStateException("Flow of type [" + invocationContext.getFlowName() + "] cannot be executed");
            }

            if (logger.isDebugEnabled()) {
                logger.debug("Flow redirected to " + endpointMapping.toString());
            }

            final Object result = ReflectionUtils.invokeMethod(endpointMapping.getMethod(), endpointMapping.getEndpoint(),
                    argumentGenerator.getArguments(endpointMapping, invocationContext));

            if (result != null && responseManager != null) {
                responseManager.processResponse(result, invocationContext.getProperties());
            }
        }
    }

    /**
     * Send the activity handler provided by the builder to tracing system.
     * 
     * @param builder
     */
    protected void trace(ActivityHandler handler) {

        try {
            final TraceService tracer = TracerUtils.getTracer(applicationContext);

            if (tracer != null) {
                tracer.trace(handler);
            } else {
                logger.error("Error while retrieving tracer");
            }
        } catch (Exception e) {
            logger.error("Error occured while tracing activity", e);
        }
    }

    /**
     * Send {@link ActivityHandler} to hospital.
     * 
     * @param builder
     */
    protected void urgencyAdmission(ActivityHandler handler) {

        try {
            hospitalService.hospitalize(handler);
        } catch (Exception e) {
            logger.error("Error occured while sending activity to hospital", e);
        }
    }

    /**
     * Evaluate each business key and capture exception if one is thrown.
     * 
     * @param notification
     * @param endpointMapping
     * @return neither null
     */
    private Map<String, String> evaluate(Object notification, EndpointMapping endpointMapping) {

        final Map<String, String> result = new HashMap<>();

        for (Entry<String, String> entry : endpointMapping.getBusinessKeys().entrySet()) {
            String value = businessKeyEvaluator.evaluate(notification, entry.getValue());

            if (value == null) {
                logger.warn("Error occured while evaluating expression " + entry.getValue());
            } else {
                result.put(entry.getKey(), value);
            }
        }

        return result;
    }

    /**
     * {@inheritDoc}
     */
    public void beforeInvocation(InvocationContext<T> invocationContext) {

        final ActivityHandlerBuilder builder = createActivityHandlerBuilder(invocationContext, StatusType.PROCESS_STARTED);

        trace(builder.build());
    }

    /**
     * {@inheritDoc}
     */
    public void afterInvocation(InvocationContext<T> invocationContext) {

        ActivityHandlerBuilder builder = createActivityHandlerBuilder(invocationContext, StatusType.PROCESS_ENDED);

        trace(builder.build());
    }

    /**
     * {@inheritDoc}
     */
    public void onInvocationException(InvocationContext<T> invocationContext, Throwable exception) {

        ActivityHandlerBuilder builderTrace = createActivityHandlerBuilder(invocationContext, StatusType.PROCESS_FAILED).exception(exception)
                .queueName(invocationContext.getDestinationName()).context(invocationContext.getPayload());

        // send tracing
        trace(builderTrace.build());

        ActivityHandlerBuilder builderHospital = createActivityHandlerBuilder(invocationContext, StatusType.PROCESS_FAILED).exception(exception)
                .queueName(invocationContext.getDestinationName()).context(invocationContext.getPayload());

        // fill replay context with properties
        for (Entry<String, String> entry : invocationContext.getProperties().entrySet()) {
            builderHospital.replayProperty(entry.getKey(), entry.getValue());
        }

        // send notification to hospital
        urgencyAdmission(builderHospital.build());
    }

    /**
     * Create activity handler builder from the remote invocation.
     * 
     * @param invocationContext
     *            method invocation context
     * @param status
     * @return activity handler builder from the notification contained in the invocation.
     * @see StatusType
     */
    protected ActivityHandlerBuilder createActivityHandlerBuilder(InvocationContext<T> invocationContext, StatusType status) {

        // create correlation handler
        CorrelationHandlerBuilder cBuilder = CorrelationHandlerBuilder.from(invocationContext.getCorrelationId());
        cBuilder.name(invocationContext.getInitiatorName()).node(invocationContext.getInitiatorNode());

        // create activity handler
        ActivityHandlerBuilder builder = ActivityHandlerBuilder.from(cBuilder.build())
                .activityName(String.format(RECEIVE_MSG, invocationContext.getFlowName())).activityStatus(status).applicationName(idType);

        // fill properties
        final EndpointMapping endpointMapping = endpointMapper.getEndpointMapping(invocationContext.getFlowName());
        if (endpointMapping != null) {

            Map<String,String> evaluationResult = evaluate(argumentGenerator.getArguments(endpointMapping, invocationContext)[0], endpointMapping);
            for (Entry<String, String> entry : evaluationResult.entrySet()) {
                builder.property(entry.getKey(), entry.getValue());
            }
        }

        return builder;
    }
}
