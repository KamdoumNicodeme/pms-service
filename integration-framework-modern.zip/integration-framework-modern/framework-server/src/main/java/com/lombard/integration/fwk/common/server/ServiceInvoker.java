package com.lombard.integration.fwk.common.server;

import org.apache.cxf.message.Exchange;
import org.apache.cxf.service.invoker.AbstractInvoker;


/**
 * <p>Class is used to invoke target object, that implements service 
 * interface. During service creation and configuration this class should be
 * initialized the with target object.</p>
 * 
 * <p>Implemented abstract class is provided by CXF.</p>
 * 
 * @author Aleksndar Valchev
 */
@Deprecated
public class ServiceInvoker extends AbstractInvoker {

	/**
	 * <p>The object that implements service interface.
	 * The type Object is temporarily used instead of IService because of problems with the xjc-plugin.</p>
	 */
	private Object target;
	
	
	public ServiceInvoker(Object aImpl) {
		target = aImpl;
	}
	
	/**
	 * <p>Method is invoked by the CXF on service request and returns service
	 * response.</p>
	 */
	@Override
	public Object invoke(Exchange exchange, Object o) {
		
		return super.invoke(exchange, o);
	}
	
	@Override
	public Object getServiceObject(Exchange exchange) {
		return target;
	}
}
