package com.lombard.integration.fwk.service.server;

public class TechnicalException extends RuntimeException {

    public TechnicalException() {
        super();
        // TODO Auto-generated constructor stub
    }

    public TechnicalException(String message, Throwable cause) {
        super(message, cause);
        // TODO Auto-generated constructor stub
    }

    public TechnicalException(String message) {
        super(message);
        // TODO Auto-generated constructor stub
    }

    public TechnicalException(Throwable cause) {
        super(cause);
        // TODO Auto-generated constructor stub
    }

}
