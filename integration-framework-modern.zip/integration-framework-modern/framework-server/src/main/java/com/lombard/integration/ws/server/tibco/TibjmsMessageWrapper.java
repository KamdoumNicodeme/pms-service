package com.lombard.integration.ws.server.tibco;

import java.lang.reflect.Field;

import jakarta.jms.IllegalStateException;
import jakarta.jms.JMSException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.util.ReflectionUtils;

import com.tibco.tibjms.TibjmsBytesMessage;

/**
 * Wrapper for Tibco JMS message implementation.
 * 
 * @author wvandenberghe
 * 
 */
class TibjmsMessageWrapper {

    private static final Log logger = LogFactory.getLog(TibjmsMessageWrapper.class);

    /**
     * Field <code>_propsReadOnly</code> that should be set to false to write beans properties.
     */
    private static final Field FIELD;
    static {
        Class<?> clazz = TibjmsBytesMessage.class;
        FIELD = ReflectionUtils.findField(clazz, "_propsReadOnly");
        if (FIELD != null) {
            ReflectionUtils.makeAccessible(FIELD);
        } else {
            logger.error("Cannot find property '_propsReadOnly' on type [com.tibco.tibjms.TibjmsBytesMessage]");
        }
    }

    /**
     * The current message.
     */
    private TibjmsBytesMessage message;

    /**
     * Construct the wrapper.
     * 
     * @param message
     *            Tibco JMS message implementation
     */
    public TibjmsMessageWrapper(TibjmsBytesMessage message) {
        this.message = message;
    }

    /**
     * Check if property exists
     * 
     * @param name
     *            property name
     * @return true if property exists
     * @throws JMSException
     *             in case of any errors
     */
    public boolean propertyExists(String name) throws JMSException {
        return message.propertyExists(name);
    }

    /**
     * Get the property value as a string
     * 
     * @param name
     *            property name
     * @return property value as string
     * @throws JMSException
     *             in case of any errors
     */
    public String getStringProperty(String name) throws JMSException {
        return message.getStringProperty(name);
    }

    /**
     * Set the property value as a string
     * 
     * @param name
     *            property name
     * @param value
     *            property value
     * @throws JMSException
     *             in case of any errors
     */
    public void setStringProperty(String name, String value) throws JMSException {
        if (FIELD == null) {
            throw new IllegalStateException("Property '_propsReadOnly' has not been found ");
        }

        // get the current field value
        final boolean isReadOnly = (Boolean) ReflectionUtils.getField(FIELD, message);
        // set to false in case the field is true
        if (isReadOnly) {
            ReflectionUtils.setField(FIELD, message, false);
        }
        // modify the property
        message.setStringProperty(name, value);
        // and restore the filed value
        ReflectionUtils.setField(FIELD, message, isReadOnly);
    }

}
