package com.lombard.integration.gtw.sub;

import jakarta.jms.Message;

import com.lombard.cdm.IdType;
import com.lombard.integration.sub.HeaderKey;
import com.lombard.integration.sub.InvocationContextDelegate;
import com.lombard.integration.sub.InvocationContextFactory;

/**
 * 
 * @author wvandenberghe
 * 
 */

public class GatewayInvocationContextFactory implements InvocationContextFactory<String> {

    /**
     * {@inheritDoc}
     */
    public InvocationContext<String> create(Message message, String invokedOn) {

        return new InvocationContextDelegate<>(message, invokedOn) {

            public String getFlowName() {

                return getProperty(HeaderKey.CHANNEL.getKey());
            }

            public IdType getInitiatorName() {

                return IdType.valueOf(getProperty(HeaderKey.INITIATOR_NAME.getKey()));
            }

            public String getInitiatorNode() {

                return getProperty(HeaderKey.INITIATOR_NODE.getKey());
            }

            public String getCorrelationId() {

                return getProperty(HeaderKey.CORRELATION_ID.getKey());
            }
        };
    }

}
