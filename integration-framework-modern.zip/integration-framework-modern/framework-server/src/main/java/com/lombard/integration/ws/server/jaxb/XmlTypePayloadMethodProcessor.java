package com.lombard.integration.ws.server.jaxb;

import java.lang.reflect.Method;

import jakarta.jws.WebResult;
import jakarta.jws.WebService;
import jakarta.xml.bind.JAXBElement;
import jakarta.xml.bind.JAXBException;
import jakarta.xml.bind.MarshalException;
import jakarta.xml.bind.annotation.XmlType;
import javax.xml.namespace.QName;

import org.springframework.core.MethodParameter;
import org.springframework.util.ClassUtils;
import org.springframework.util.ReflectionUtils;
import org.springframework.ws.context.MessageContext;

/**
 * Payload that can be marshalled based on element annotated by {@link XmlType}.
 * 
 * @author wvandenberghe
 * 
 */
public class XmlTypePayloadMethodProcessor extends AbstractJaxb2PayloadMethodProcessor {

    /**
     * {@inheritDoc}
     */
    @Override
    protected boolean supportsRequestPayloadParameter(MethodParameter parameter) {
        Class<?> parameterType = parameter.getParameterType();
        return parameterType.isAnnotationPresent(XmlType.class);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    protected boolean supportsResponsePayloadReturnType(MethodParameter returnType) {
        Class<?> parameterType = returnType.getParameterType();
        return parameterType.isAnnotationPresent(XmlType.class);
    }

    /**
     * {@inheritDoc}
     */
    public void handleReturnValue(MessageContext messageContext, MethodParameter returnType, Object returnValue)
            throws JAXBException {
        Class<?> declaringClass = returnType.getDeclaringClass();
        Method method = returnType.getMethod();
        Class<?>[] interfaces = ClassUtils.getAllInterfacesForClass(declaringClass);

        Method webServiceMethod = null;
        for (Class<?> interfaceClass : interfaces) {
            if (interfaceClass.isAnnotationPresent(WebService.class)) {
                Method annotatedMethod =
                        ReflectionUtils.findMethod(interfaceClass, method.getName(), method.getParameterTypes());
                if (annotatedMethod != null && annotatedMethod.isAnnotationPresent(WebResult.class)) {
                    webServiceMethod = annotatedMethod;
                    break;
                }
            }
        }

        // in case method is found and is annotated by WebResult
        if (webServiceMethod != null) {
            WebResult webResult = webServiceMethod.getAnnotation(WebResult.class);
            QName qName = new QName(webResult.targetNamespace(), webResult.name());

            @SuppressWarnings({"rawtypes", "unchecked"})
            JAXBElement < ? > element = new JAXBElement(qName, returnValue.getClass(), returnValue);
            marshalToResponsePayload(messageContext, returnType.getParameterType(), element);
        } else {
            throw new MarshalException("Result cannot be marshalled as the method [" + method.getName()
                    + "] is not a web service operation");
        }
    }

    /**
     * {@inheritDoc}
     */
    public Object resolveArgument(MessageContext messageContext, MethodParameter parameter) throws JAXBException {
        Class<?> parameterType = parameter.getParameterType();
        JAXBElement < ? > element = unmarshalElementFromRequestPayload(messageContext, parameterType);
        return element != null ? element.getValue() : null;
    }

}
