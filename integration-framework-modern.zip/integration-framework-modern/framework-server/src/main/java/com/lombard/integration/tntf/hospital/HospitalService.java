package com.lombard.integration.tntf.hospital;

import com.lombard.cdm.ActivityHandler;

/**
 * Service to send {@link ActivityHandler} to hospital.
 * 
 * @author wvandenberghe
 * 
 */
public interface HospitalService {

    public void hospitalize(ActivityHandler toSendOrReceive);
}
