package com.lombard.integration.fwk.common.server;

import org.apache.cxf.endpoint.Server;
import org.apache.cxf.jaxws.JaxWsServerFactoryBean;
import org.apache.cxf.transport.jms.JMSConfiguration;
import org.apache.cxf.transport.jms.JMSDestination;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * <p>
 * Server class encapsulates the logic for starting, stopping and configuring a service.
 * </p>
 * 
 * @author Aleksandar Valchev
 */
@Deprecated
public class ServiceWrapper {

	@Autowired
	private JMSConfiguration jmsConfiguration;
	
	@Autowired
	private JaxWsServerFactoryBean svrFactory;
	
    /**
     * <p>
     * CXF's service proxy interface.
     * </p>
     */
    private Server server;
    /**
     * <p>
     * Service configuration.
     * </p>
     */
    private ServiceConfig config;
    /**
     * <p>
     * Target object, which implements service interface. The type Object is temporarily used instead of IService
     * because of problems with the xjc-plugin.
     * </p>
     */
    private Object target;
    
    private Boolean started;

    public ServiceWrapper() {
        super();

    }

    public Server getServer() {
        return server;
    }

    public Boolean isStarted() {
        return started;
    }

    /**
     * <p>
     * Configure's a service. Configuration is retreived from spring context.
     * </p>
     */
    public void configure() throws ClassNotFoundException {
        //JaxWsServerFactoryBean svrFactory = new JaxWsServerFactoryBean();
        target = getConfig().getServiceBean();

        svrFactory.setServiceClass(getInterfaceClass());
        svrFactory.setInvoker(new ServiceInvoker(target));
        //svrFactory.setAddress("jms://");

        //svrFactory.getInInterceptors().add(new FWKPropertiesInInterceptor());
        //svrFactory.getOutInterceptors().add(new FWKPropertiesOutInterceptor());

        //svrFactory.setStart(false);
        server = svrFactory.create();

        JMSDestination jmsDestination = (JMSDestination) server.getDestination();
        jmsConfiguration.setMaxConcurrentConsumers(config.getConcurrentConsumers());
        jmsConfiguration.setConcurrentConsumers(config.getConcurrentConsumers());
        jmsConfiguration.setTargetDestination(config.getDestination());
        jmsDestination.setJmsConfig(jmsConfiguration);

    }

    /**
     * <p>
     * Returns CXF configuration for the service's transport.
     * </p>
     * 
     * @return
     */
//    private JMSConfiguration getJMSConfig() {
//        JMSConfiguration cfg = new JMSConfiguration();
//
//        cfg.setConnectionFactory(queueConnectionFactory);
//        cfg.setTargetDestination(config.getDestination());
//        cfg.setUseJms11(true);
//        cfg.setMessageType("binary");
//        cfg.setJmsProviderTibcoEms(true);
//        cfg.setPubSubDomain(false);
//        cfg.setUsingEndpointInfo(false);
//        cfg.setSubscriptionDurable(false);
//        cfg.setReconnectOnException(true);
//        cfg.setMaxConcurrentConsumers(1);
//
//        return cfg;
//    }

    /**
     * <p>
     * Searches for the service interface class into target object.
     * </p>
     * 
     * @return the interface class, otherwise <code>null</code>.
     * @throws Exception
     */
    private Class<?> getInterfaceClass() throws ClassNotFoundException {
        Class<?> serviceItf = Class.forName(config.getInterfaceClass());

        if (!serviceItf.isAssignableFrom(target.getClass())) {
            throw new IllegalArgumentException("Service class " + serviceItf.getName() + " is not assignable from target class "
                    + target.getClass().getName());
        }

        return serviceItf;
    }

    public void startService() {
        server.start();
        started = true;
    }

    public void stopSerice() {
        server.stop();
        started = false;
    }

    public ServiceConfig getConfig() {
        return config;
    }

    public void setConfig(ServiceConfig config) {
        this.config = config;
    }
}
