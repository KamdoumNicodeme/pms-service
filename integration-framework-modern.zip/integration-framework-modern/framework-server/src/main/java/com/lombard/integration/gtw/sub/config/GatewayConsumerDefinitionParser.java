package com.lombard.integration.gtw.sub.config;

import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.beans.factory.support.BeanDefinitionBuilder;
import org.springframework.beans.factory.support.BeanDefinitionRegistry;
import org.springframework.beans.factory.xml.ParserContext;
import org.springframework.jms.core.JmsTemplate;
import org.w3c.dom.Element;

import com.lombard.integration.gtw.GatewayService;
import com.lombard.integration.gtw.sub.Consumer;
import com.lombard.integration.gtw.sub.GatewayArgumentGenerator;
import com.lombard.integration.gtw.sub.GatewayInvocationContextFactory;
import com.lombard.integration.gtw.sub.GatewayMessageConverter;
import com.lombard.integration.gtw.sub.GatewayResponseManager;
import com.lombard.integration.gtw.sub.GatewaySelectorExtractor;
import com.lombard.integration.sub.config.AbstractMessageSubscriberDefinitionParser;

/**
 * 
 * @author wvandenberghe
 * 
 */
public class GatewayConsumerDefinitionParser extends AbstractMessageSubscriberDefinitionParser {

    private static final String DEFAULT_CONNECTION_FACTORY = "ntiConnectionFactory";
    private static final String GTW_RESPONSE_JMS_TEMPLATE = "gtwResponseJmsTemplate";
    public static final String RESPONSE_DESTINATION = "gtw.queue.response.destination";
    public static final String RESPONSE_CHANNEL = "gtw.queue.response.channel";

    /**
     * {@inheritDoc}
     */
    @Override
    protected String getDefaultConnectionFactoryReference() {

        return DEFAULT_CONNECTION_FACTORY;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    protected BeanDefinition getSelectorExtractor() {

        return BeanDefinitionBuilder.genericBeanDefinition(GatewaySelectorExtractor.class).getBeanDefinition();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    protected BeanDefinition parseMessageConverter(Element element, ParserContext parserContext) {

        BeanDefinitionBuilder builder = BeanDefinitionBuilder.genericBeanDefinition(GatewayMessageConverter.class);

        return builder.getBeanDefinition();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    protected Class<?> getAnnotationType() {

        return Consumer.class;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    protected Class<?> getConsumedType() {

        return String.class;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    protected Class<?> getServiceInterface() {

        return GatewayService.class;
    }

    @Override
    protected BeanDefinition getInvocationContextFactory() {

        return BeanDefinitionBuilder.genericBeanDefinition(GatewayInvocationContextFactory.class).getBeanDefinition();
    }

    @Override
    protected BeanDefinition getArgumentGenerator() {

        return BeanDefinitionBuilder.genericBeanDefinition(GatewayArgumentGenerator.class).getBeanDefinition();
    }

    @Override
    protected BeanDefinition getResponseManager(final ParserContext parserContext) {

        final BeanDefinitionBuilder builder = BeanDefinitionBuilder.genericBeanDefinition(GatewayResponseManager.class);
        builder.addPropertyValue("gtwResponseJmsTemplate", createJmsTemplate(parserContext));
        builder.addPropertyValue("channel", makeOptionalPropertyValue(RESPONSE_CHANNEL));
        return builder.getBeanDefinition();
    }

    private BeanDefinition createJmsTemplate(final ParserContext parserContext) {

        final BeanDefinitionRegistry registry = parserContext.getRegistry();
        BeanDefinition beanDefinition;
        if (!registry.containsBeanDefinition(GTW_RESPONSE_JMS_TEMPLATE)) {
            final BeanDefinitionBuilder builder = BeanDefinitionBuilder.genericBeanDefinition(JmsTemplate.class);
            builder.addConstructorArgReference(DEFAULT_CONNECTION_FACTORY);
            builder.addPropertyValue("defaultDestinationName", makeOptionalPropertyValue(RESPONSE_DESTINATION));
            beanDefinition = builder.getBeanDefinition();
            registry.registerBeanDefinition(GTW_RESPONSE_JMS_TEMPLATE, beanDefinition);
        } else {
            beanDefinition = registry.getBeanDefinition(GTW_RESPONSE_JMS_TEMPLATE);
        }
        return beanDefinition;
    }

    private String makeOptionalPropertyValue(final String property) {

        return "${" + property + ":#{null}}";
    }

}
