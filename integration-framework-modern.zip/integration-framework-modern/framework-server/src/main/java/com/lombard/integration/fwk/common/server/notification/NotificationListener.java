package com.lombard.integration.fwk.common.server.notification;

import jakarta.jms.MessageListener;

public interface NotificationListener extends MessageListener {

}
