package com.lombard.integration.ws.server;

import org.junit.Test;
import org.springframework.aop.framework.ProxyFactory;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.beans.factory.support.BeanDefinitionBuilder;
import org.springframework.context.support.GenericApplicationContext;

public class WebServiceServerFactoryBeanTest {

    @Test
    public void testProxyCreation() throws Exception {
        GenericApplicationContext applicationContext = new GenericApplicationContext();
        BeanDefinition beanDefinition =
                BeanDefinitionBuilder.genericBeanDefinition(WebServiceImpl.class).getBeanDefinition();
        applicationContext.registerBeanDefinition("webServiceTest", beanDefinition);

        ProxyFactory pf = new ProxyFactory(applicationContext.getBean(WebServiceImpl.class));
        // force to CGLIB proxy
        pf.setOptimize(true);

        Object proxy = pf.getProxy();

        WebServiceServerFactoryBean fb = new WebServiceServerFactoryBean();
        fb.setEndpoint(proxy);
        fb.setApplicationContext(applicationContext);
    }

}
