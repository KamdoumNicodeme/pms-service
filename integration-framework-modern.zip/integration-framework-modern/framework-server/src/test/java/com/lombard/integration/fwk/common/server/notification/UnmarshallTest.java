package com.lombard.integration.fwk.common.server.notification;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.StringWriter;

import jakarta.jms.Message;

import junit.framework.Assert;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.lombard.integration.fwk.schema.csm.v2_1.BankAccountBody;
import com.lombard.integration.fwk.schema.csm.v2_2.InboxMessageType;
import com.lombard.integration.fwk.schema.csm.v2_2.PushInboxMessagesRequest;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:fwk-service-config.xml"})
public class UnmarshallTest extends AbstractNotificationListener {

    @Test
    public void testPushInboxMessage() throws Exception {
        Resource resource = new ClassPathResource("notification/pushInboxMessageRequest.xml");
        String xml = streamToString(resource.getInputStream());
        PushInboxMessagesRequest req = parseNotification(xml, PushInboxMessagesRequest.class);

        Assert.assertTrue("com.lombard.integration.fwk.schema.csm.v2_2.PushInboxMessagesRequest".equals(req
                .getClass().getName()));
        // PushInboxMessagesRequest req = (PushInboxMessagesRequest) o;
        Assert.assertTrue(req.getBusinessContext().getInboxMessageList().getInboxMessage().get(0)
                .getInboxMessageType() == InboxMessageType.REPORT);
    }

    @Test
    public void testBankAccountBody() throws Exception {
        Resource resource = new ClassPathResource("notification/bankAccountBody.xml");
        String xml = streamToString(resource.getInputStream());
        BankAccountBody req = parseNotification(xml, BankAccountBody.class);

        Assert.assertTrue("com.lombard.integration.fwk.schema.csm.v2_1.BankAccountBody".equals(req.getClass()
                .getName()));
        // BankAccountBody req = (BankAccountBody) o;
        Assert.assertTrue("someID".equals(req.getBankAccountList().getBankAccount().get(0).getId()));
    }

    public void onMessage(Message message) {
        // For test purpose, no need to implement
    }

    private String streamToString(InputStream stream) {
        Reader reader = new InputStreamReader(stream);
        StringWriter writer = new StringWriter();

        try {
            char[] buffer = new char[4096];
            int length = 0;
            while ((length = reader.read(buffer)) != -1) {
                writer.write(buffer, 0, length);
            }
            writer.flush();
            return writer.toString();
        } catch (IOException e) {
            return null;
        } finally {
            try {
                reader.close();
            } catch (IOException e) {
                // do nothing
            }

            try {
                writer.close();
            } catch (IOException e) {
                // do nothing
            }
        }
    }

}
