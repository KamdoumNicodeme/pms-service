package com.lombard.integration.ws.server.soap;

import org.junit.Assert;
import org.junit.Test;

public class SoapActionMethodEndpointMappingTest {

    private SoapActionMethodEndpointMapping endpointMapping = new SoapActionMethodEndpointMapping();

    @Test
    public void testDiffEmptyArray() {
        Object[] result = endpointMapping.diff(new Object[0], new Object[0]);

        Assert.assertNotNull(result);
        Assert.assertEquals(0, result.length);
    }

    @Test
    public void testDiff1() {
        final Object[] left = new Object[2];
        left[0] = new Object();
        left[1] = new Object();
        final Object[] right = new Object[2];
        right[0] = new Object();
        right[1] = new Object();

        Object[] result = endpointMapping.diff(left, right);
        Assert.assertNotNull(result);
        Assert.assertEquals(2, result.length);
        Assert.assertArrayEquals(result, right);
    }

    @Test
    public void testDiff2() {
        final Object[] left = new Object[2];
        left[0] = new Object();
        left[1] = new Object();
        final Object[] right = new Object[2];
        right[0] = new Object();
        right[1] = left[1];

        Object[] result = endpointMapping.diff(left, right);
        Assert.assertNotNull(result);
        Assert.assertEquals(1, result.length);
        Assert.assertEquals(right[0], result[0]);
    }
}
