package com.lombard.integration.sub.mapping;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

import com.lombard.csm.CorporateActionConfirmationBusinessContext;
import com.lombard.csm.Notification;
import com.lombard.csm.TradeConfirmationBusinessContext;
import com.lombard.csm.TradeOrderBusinessContext;
import com.lombard.integration.ntf.sub.NotificationSelectorExtractor;
import com.lombard.integration.sub.mapping.EndpointMapper.EndpointMapping;

public class NotificationEndpointMapperTest {

    private static MethodEndpointMapper mapper;

    @BeforeClass
    public static void setUp() {
        mapper = new MethodEndpointMapper();
        mapper.setConsumedType(Notification.class);
        mapper.setSelectorExtractor(new NotificationSelectorExtractor());
        Endpoint endpoint = new Endpoint();
        mapper.setEndpoints(new Object[] {endpoint});
    }

    @Test
    public void testBusinessContext() {
        EndpointMapping mapping = mapper.getEndpointMapping(TradeConfirmationBusinessContext.class.getSimpleName());

        Assert.assertEquals(TradeConfirmationBusinessContext.class, mapping.getArgumentType());
        Assert.assertEquals("method2", mapping.getMethod().getName());
    }

    @Test
    public void testDefault() {
        EndpointMapping mapping = mapper.getEndpointMapping(TradeOrderBusinessContext.class.getSimpleName());

        Assert.assertEquals(Notification.class, mapping.getArgumentType());
        Assert.assertEquals("method2", mapping.getMethod().getName());
    }

    @Test
    public void testSelector() {
        EndpointMapping mapping =
                mapper.getEndpointMapping(CorporateActionConfirmationBusinessContext.class.getSimpleName());

        Assert.assertEquals(Notification.class, mapping.getArgumentType());
        Assert.assertEquals("method4", mapping.getMethod().getName());
    }

}
