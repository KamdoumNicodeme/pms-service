package com.lombard.integration.gtw.sub.config;

import com.lombard.integration.gtw.GatewayService;

public class GatewayServiceImpl implements GatewayService {

    public void processContent(String content) {

        // nothing to do

    }

}
