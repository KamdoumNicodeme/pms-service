package com.lombard.integration.ws.server.config;

import com.lombard.integration.fwk.schema.csm.v2_2.GetMandateGroupByUserRequest;
import com.lombard.integration.fwk.schema.csm.v2_2.GetMandateGroupByUserResponse;
import com.lombard.integration.fwk.schema.csm.v2_2.GetMandateListRequest;
import com.lombard.integration.fwk.schema.csm.v2_2.GetMandateListResponse;
import com.lombard.integration.fwk.service.annotation.ServiceDefinition;
import com.lombard.integration.fwk.services.mandate.MandateService;

@ServiceDefinition
public class MandateServiceImplWithAnnotation implements MandateService {

    public GetMandateListResponse getMandateList(GetMandateListRequest getMandateListRequestPart) {
        return null;
    }

    public GetMandateGroupByUserResponse getMandateGroupByUser(
            GetMandateGroupByUserRequest getMandateGroupByUserRequestPart) {
        return null;
    }

}
