package com.lombard.integration.ws.server;

import jakarta.jws.WebService;

@WebService
public interface WebServiceInterface {

}
