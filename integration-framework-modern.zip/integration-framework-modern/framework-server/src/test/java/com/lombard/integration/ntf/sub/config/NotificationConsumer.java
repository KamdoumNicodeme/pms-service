package com.lombard.integration.ntf.sub.config;

import com.lombard.csm.AssetDescriptionBusinessContext;
import com.lombard.csm.CorporateActionConfirmationBusinessContext;
import com.lombard.csm.FundBusinessContext;
import com.lombard.csm.Notification;
import com.lombard.csm.TradeConfirmationBusinessContext;
import com.lombard.csm.TradeOrderBusinessContext;
import com.lombard.integration.fwk.notification.annotation.BusinessKey;
import com.lombard.integration.fwk.notification.annotation.BusinessKeys;
import com.lombard.integration.fwk.notification.annotation.Consumer;
import com.lombard.integration.fwk.notification.annotation.Selector;

@Consumer
public class NotificationConsumer {

    // default case
    public void defaultConsumer(Notification notification) {

    }

    // based on selector
    @Selector(businessContext = TradeConfirmationBusinessContext.class)
    public void selectorBasedConsumer(Notification notification) {

    }

    // based on argument type
    public void argumentBasedConsumer(TradeOrderBusinessContext businessContext) {

    }

    // only one business key
    @BusinessKey(name = "businessKey", expression = "'CorporateActionConfirmation'")
    public void oneBusinessKeyConsumer(CorporateActionConfirmationBusinessContext businessContext) {

    }

    // business key bundle
    @BusinessKeys({@BusinessKey(name = "bk1", expression = "'bk1'"),
            @BusinessKey(name = "bk2", expression = "'bk2'")})
    public void businessKeyBundleConsumer(FundBusinessContext businessContext) {

    }

    // agglomerate business key
    @BusinessKeys({@BusinessKey(name = "bk1", expression = "'bk1'"),
            @BusinessKey(name = "bk2", expression = "'bk2'")})
    @BusinessKey(name = "bk", expression = "'bk'")
    public void agglomerateBusinessKeysConsumer(AssetDescriptionBusinessContext businessContext) {

    }
}
