package com.lombard.integration.ws.server;

public class WebServiceImpl implements WebServiceInterface {

}
