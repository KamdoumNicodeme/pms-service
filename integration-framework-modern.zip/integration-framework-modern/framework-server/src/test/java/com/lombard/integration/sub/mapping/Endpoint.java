package com.lombard.integration.sub.mapping;

import com.lombard.csm.CorporateActionConfirmationBusinessContext;
import com.lombard.csm.Notification;
import com.lombard.csm.TradeConfirmationBusinessContext;
import com.lombard.integration.fwk.notification.annotation.Selector;

public class Endpoint {

    public static void method1(Notification notification) {

    }

    public void method2(Notification notification) {

    }

    public void method2(TradeConfirmationBusinessContext businessContext) {

    }

    @SuppressWarnings("unused")
    private void method3(Notification notification) {

    }

    @Selector(businessContext = CorporateActionConfirmationBusinessContext.class)
    public void method4(Notification notification) {

    }
}
