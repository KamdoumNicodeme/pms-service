package com.lombard.integration.gtw.sub;

import static org.mockito.Matchers.any;
import static org.mockito.Mockito.RETURNS_DEFAULTS;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.UUID;

import jakarta.jms.JMSException;
import jakarta.jms.Queue;
import jakarta.jms.Session;
import jakarta.jms.TextMessage;

import org.junit.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;
import org.springframework.context.ApplicationContext;

import com.lombard.cdm.ActivityHandler;
import com.lombard.cdm.IdType;
import com.lombard.cdm.KeyValues;
import com.lombard.cdm.KeyValues.KeyValue;
import com.lombard.cdm.ReplayContext;
import com.lombard.integration.sub.DefaultInvokerExporter;
import com.lombard.integration.sub.HeaderKey;
import com.lombard.integration.sub.InvocationContextFactory.InvocationContext;
import com.lombard.integration.sub.mapping.EndpointMapper;
import com.lombard.integration.sub.mapping.EndpointMapper.EndpointMapping;
import com.lombard.integration.tntf.hospital.HospitalService;
import com.lombard.integration.tntf.trace.TraceService;

import junit.framework.Assert;

public class GatewayInvokerExporterTest {

    @Test
    public void testDoOnExceptionInvocation() throws JMSException {

        // configure gateway
        DefaultInvokerExporter<String> invoker = new DefaultInvokerExporter<String>();
        invoker.setIdType(IdType.ETIS);

        HospitalService hospitalService = mock(HospitalService.class);
        doAnswer(RETURNS_DEFAULTS).when(hospitalService).hospitalize(any(ActivityHandler.class));
        invoker.setHospitalService(hospitalService);

        TraceService traceService = mock(TraceService.class);
        doAnswer(RETURNS_DEFAULTS).when(traceService).trace(any(ActivityHandler.class));

        ApplicationContext context = mock(ApplicationContext.class);
        when(context.getBean(TraceService.class)).thenReturn(traceService);
        invoker.setApplicationContext(context);

        EndpointMapper endpointMapper = mock(EndpointMapper.class);
        EndpointMapping mapping = mock(EndpointMapping.class);
        when(mapping.getBusinessKeys()).thenReturn(new HashMap<String,String>());
        when(mapping.getArgumentType()).then(new Answer() {

            public Object answer(InvocationOnMock invocation) throws Throwable {

                return String.class;
            }
        });
        when(endpointMapper.getEndpointMapping("DealBatchUpload")).thenReturn(mapping);
        invoker.setEndpointMapper(endpointMapper);

        GatewayMessageConverter messageConverter = new GatewayMessageConverter();
        invoker.setMessageConverter(messageConverter);

        GatewayInvocationContextFactory factory = new GatewayInvocationContextFactory();
        invoker.setInvocationContextFactory(factory);

        GatewayArgumentGenerator argGen = mock(GatewayArgumentGenerator.class);
        when(argGen.getArguments(any(EndpointMapping.class), any(InvocationContext.class))).thenReturn(new Object[] { "Dummy" });
        invoker.setArgumentGenerator(argGen);
        // configure message
        TextMessage message = mock(TextMessage.class);
        when(message.getText()).thenReturn("Just a few");
        when(message.getStringProperty(HeaderKey.CHANNEL.getKey())).thenReturn("DealBatchUpload");
        when(message.getStringProperty(HeaderKey.CORRELATION_ID.getKey())).thenReturn(UUID.randomUUID().toString());
        when(message.getStringProperty(HeaderKey.FILE_NAME.getKey())).thenReturn("deal_batch_upload.csv");
        when(message.getStringProperty(HeaderKey.INITIATOR_NAME.getKey())).thenReturn(IdType.EFAGATEWAY.name());
        when(message.getStringProperty(HeaderKey.INITIATOR_NODE.getKey())).thenReturn("LIA-PC728");
        when(message.getPropertyNames()).thenReturn(new Enumeration<String>() {

            private String[] names = new String[] { HeaderKey.CHANNEL.getKey(), HeaderKey.FILE_NAME.getKey(), HeaderKey.CORRELATION_ID.getKey(),
                    HeaderKey.INITIATOR_NAME.getKey(), HeaderKey.INITIATOR_NODE.getKey() };

            private int index = 0;

            public boolean hasMoreElements() {

                return index < names.length;
            }

            public String nextElement() {

                String name = names[index];
                index++;
                return name;
            }
        });

        Queue queue = mock(Queue.class);
        when(queue.getQueueName()).thenReturn("GTW.ETIS");
        when(message.getJMSDestination()).thenReturn(queue);

        // execute method
        invoker.onMessage(message, mock(Session.class));

        // verify trace service
        ArgumentCaptor<ActivityHandler> captor = ArgumentCaptor.forClass(ActivityHandler.class);
        verify(traceService, Mockito.times(2)).trace(captor.capture());

        // verify hospital
        verify(hospitalService).hospitalize(captor.capture());
        testActivityHandler(captor.getValue());
    }

    private void testActivityHandler(ActivityHandler activityHandler) {

        Assert.assertNotNull(activityHandler.getReplayContext());

        ReplayContext replayContext = activityHandler.getReplayContext();
        Assert.assertEquals(1, replayContext.getHeaderKeyValue().size());
        KeyValues keyValues = replayContext.getHeaderKeyValue().get(0);
        Assert.assertEquals(5, keyValues.getKeyValue().size());

        testReplayContextProperties(keyValues.getKeyValue(), HeaderKey.CHANNEL.getKey(), "DealBatchUpload");
        testReplayContextProperties(keyValues.getKeyValue(), HeaderKey.FILE_NAME.getKey(), "deal_batch_upload.csv");
        testReplayContextProperties(keyValues.getKeyValue(), HeaderKey.INITIATOR_NAME.getKey(), IdType.EFAGATEWAY.name());
        testReplayContextProperties(keyValues.getKeyValue(), HeaderKey.INITIATOR_NODE.getKey(), "LIA-PC728");
    }

    private void testReplayContextProperties(List<KeyValue> keyValues, String key, String value) {

        for (KeyValue keyValue : keyValues) {
            if (key.equals(keyValue.getKey())) {
                Assert.assertEquals("Error on key " + key, value, keyValue.getValue());
                return;
            }
        }

        Assert.fail("Cannot find key " + key);
    }
}
