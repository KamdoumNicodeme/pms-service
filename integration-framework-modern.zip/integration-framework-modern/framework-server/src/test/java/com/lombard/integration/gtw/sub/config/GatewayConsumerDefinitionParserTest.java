package com.lombard.integration.gtw.sub.config;

import org.hamcrest.CoreMatchers;
import org.junit.Assert;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.jms.listener.SimpleMessageListenerContainer;

import com.lombard.integration.sub.DefaultInvokerExporter;

public class GatewayConsumerDefinitionParserTest {

    @Test
    public void testGtwDefinition() {
        ApplicationContext applicationContext =
                new ClassPathXmlApplicationContext(
                        "/com/lombard/integration/gtw/sub/config/gtw_consumer-context.xml");

        SimpleMessageListenerContainer container = applicationContext.getBean(SimpleMessageListenerContainer.class);
        Assert.assertEquals("Destination name must be 'TEST.WS'", "TEST.WS", container.getDestinationName());
        Assert.assertThat("Message listener must be 'DefaultInvokerExporter'", container.getMessageListener(),
                CoreMatchers.instanceOf(DefaultInvokerExporter.class));
    }
}
