package com.lombard.integration.ntf.pub.config;

import com.lombard.csm.BusinessContext;
import com.lombard.csm.CorporateActionConfirmationBusinessContext;
import com.lombard.csm.FinancialMessage;
import com.lombard.csm.Notification;
import com.lombard.csm.TradeConfirmationBusinessContext;
import com.lombard.csm.TradeOrderBusinessContext;
import com.lombard.integration.fwk.notification.annotation.BusinessContextAware;
import com.lombard.integration.fwk.notification.annotation.BusinessKey;
import com.lombard.integration.fwk.notification.annotation.BusinessKeys;
import com.lombard.integration.fwk.notification.annotation.Publisher;

@Publisher
public interface NotifPublisher {

    @BusinessKeys({@BusinessKey(name = "swiftType", expression = "'MT502'"),
            @BusinessKey(name = "semeCode", expression = "generalInformation.externalReference")})
    void publish(TradeOrderBusinessContext businessContext);

    @BusinessKey(name = "swiftType", expression = "'MT515'")
    void publish(TradeConfirmationBusinessContext bc);

    @BusinessKeys({@BusinessKey(name = "swiftType", expression = "'MT566'"),
            @BusinessKey(name = "seme", expression = "generalInformation.externalReference")})
    void publish(CorporateActionConfirmationBusinessContext businessContext);

    void publish(BusinessContext businessContext);

    @BusinessContextAware
    void publish(Notification notification);

    @BusinessContextAware
    @BusinessKey(name = "seme", expression = "generalInformation.externalReference")
    void publish(FinancialMessage message);
}
