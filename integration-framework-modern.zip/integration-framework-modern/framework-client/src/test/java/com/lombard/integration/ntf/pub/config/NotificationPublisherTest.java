package com.lombard.integration.ntf.pub.config;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.aop.support.AopUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.lombard.integration.ntf.pub.NotificationPublisherProxyFactoryBean;

@ContextConfiguration("/com/lombard/integration/ntf/pub/config/notif_pub-context.xml")
@RunWith(SpringJUnit4ClassRunner.class)
public class NotificationPublisherTest {

    @Autowired
    ApplicationContext applicationContext;

    @Test
    public void testNotifPublisherConfig() {
        NotificationPublisherProxyFactoryBean proxyFactoryBean =
                applicationContext.getBean(NotificationPublisherProxyFactoryBean.class);
        Assert.assertEquals(NotifPublisher.class, proxyFactoryBean.getObjectType());

        NotifPublisher publisher = applicationContext.getBean(NotifPublisher.class);
        Assert.assertTrue(AopUtils.isAopProxy(publisher));
    }

}
