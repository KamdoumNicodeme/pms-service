/**
 * Contains needed classes to deal with web services as a client.
 * <p>
 * Some Spring configuration files must be imported (provided by frameworks-client and framework-interfaces-* jars): 
 * <pre>
 * &lt;import resource="classpath:intfwk-client-context.xml"/>
 * &lt;import resource="classpath*:fwk-catalog-context.xml"/>
 * </pre></p>
 * <p>The first import provides a JMS connection factory and a SOAP message factory.
 * The second import provides a JAXB marshaller and configure the ServiceLocator class.
 * The third import take every <b>fwk-catalog-context.xml</b> from every framework interfaces jar in the classpath. These files contain a default configuration:
 * </p>
 * <ul>
 * <li>timeout: 10s</li> 
 * <li>request validation: false</li>
 * <li>destination: WS.ESB.CORE</li> 
 * </ul>
 * 
 * <h2>Configuration</h2>
 * 
 * <p>
 * The configuration can be overriden by this way: 
 * <pre>
 * &lt;intfwk:client
 *     name="com.lombard.integration.fwk.services.mandate.MandateService"
 *     class="com.lombard.integration.fwk.services.mandate.MandateService"
 *     destination="WS.ESB.CORE"
 *     timeout="20000"
 *     validate="true"/>
 * </pre>
 * In case of the annotation injection usage, Integration Framework provides annotation {@link com.lombard.integration.fwk.service.annotation.ClientConfig}.
 * This annotation allows to configure the timeout and the validation of the request before sending it to ESB. It is only available for fields and is only about client configuration. Annotation {@link org.springframework.beans.factory.annotation.Autowired} is still needed.
 * For application using ServiceLocator, it brings possiblity to modify the timeout.
 * </p>
 * 
 * <h2>General behaviour</h2>
 * 
 * <h3>Exception management</h3>
 * 
 * <p>When timeout is reached, exception {@link com.lombard.integration.ws.client.OperationTimeoutException} is thrown. The timeout is propagated to ESB and to client.</p>
 * <p>If an exception occured in the ESB, a {@link com.lombard.integration.ws.client.TechnicalException} is thrown with, in the message, the stack trace provided by the ESB.</p>
 * <p>If an exception occured on server side, a {@link com.lombard.integration.ws.client.BusinessException} is thrown in the same way than the {@link com.lombard.integration.ws.client.TechnicalException}.</p>
 * 
 * <h3>Request enrichment</h3>
 * 
 * <p>If the request object has a correlation handler, the correlation ID is automatically filled.
 * The {@link com.lombard.cdm.ApplicationContext} is filled by the framework. To do so, a property file must be provided with a property: <b>client.id</b>.
 * Its value must be part of the enumerated type (CDM/CSM): {@link com.lombard.cdm.IdType}.
 * </p>
 * <img src="http://yuml.me/16649c0a" >
 */
package com.lombard.integration.ws.client;