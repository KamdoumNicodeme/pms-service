/**
 * This package aims to provides mechanisms to publish {@link com.lombard.csm.Notification}.
 * <p>
 * The main mechanism is provided through {@link com.lombard.integration.fwk.notification.NotificationService}.
 * </p>
 * <p>
 * This interface, based on JMS Spring remote service, can be injected by declaring it in the application context:
 * <pre>
 * &lt;intfwk:notif-publisher 
 *      id-type="ELOMBARD"
 *      destination="NTF.PUB"
 *      validate="true" 
 *      schemas="classpath:/schemas/CSM/EntryPoint.xsd"
 *      connection-factory="legConnectionFactory" 
 *      marshaller="jaxbMarshaller"
 *      unmarshaller="jaxbUnmarshaller"
 *      base-package="com.lombard.integration.publisher"/>
 * </pre>
 * This element is part of the Integration Framework namespace and defines the following attributes:
 * <dl>
 * <dt>id-type</dt>
 * <dd>Must be one of the {@link com.lombard.cdm.IdType} enumeration value</dd>
 * <dt>destination</dt>
 * <dd>queue name. The default one is <b>NTF.ESB.CORE</b></dd>
 * <dt>validate</dt>
 * <dd>notification XML validation. Default set to false.</dd>
 * <dt>schemas</dt>
 * <dd>Resource location for validation. By default, set to <b>classpath:/schemas/CSM/EntryPoint.xsd</b></dd>
 * <dt>connection-factory</dt>
 * <dd>connection factory reference. Default is <b>ntiConnectionFactory</b> defined in context <b>intfwk-common-context.xml</b></dd>
 * <dt>marshaller</dd>
 * <dd>XML marshaller. Default is a reference to <b>jaxb2Marshaller</b> defined in context <b>intfwk-common-context.xml</b></dd>
 * <dt>umarshaller</dt>
 * <dd>XML unmarshaller. Default is a reference to <b>jaxb2Marshaller</b> defined in context <b>intfwk-common-context.xml</b></dd>
 * <dt>base-package</dt>
 * <dd>an optional package name where to find interfaces annotated by {@link com.lombard.integration.fwk.notification.annotation.Publisher}</dd>
 * </dl>
 * </p>
 * <p>
 * Integration Framework is in charge to populate the {@link com.lombard.cdm.CorrelationContext} for every notifications, to enrich JMS properties and to send trace.
 * The populated JMS properties are:
 * <ul>
 * <li>CorrelationID: a unique ID to follow the notification through the systems</li>
 * <li>InitiatorID: the notification publisher ID</li>
 * <li>NotificationBusinessContext: the full class name of the notification business context</li>
 * </ul>
 * </p>
 * <p>
 * A supplementary mechanism is provided through interfaces annotated by {@link com.lombard.integration.fwk.notification.annotation.Publisher}.
 * These interfaces must define methods with only one argument that must be of type {@link com.lombard.csm.Notification} or {@link com.lombard.cdm.BusinessContext}.
 * That allows too business keys definition that is used for tracing:
 * <pre>
 * &#64;Publisher
 * public interface NotifPublisher {
 *
 *    &#64;BusinessKeys({&#64;BusinessKey(name = &quot;swiftType&quot;, expression = &quot;'MT566'&quot;),
 *            &#64;BusinessKey(name = &quot;semeCode&quot;, expression = &quot;businessContext.generalInformation.externalReference&quot;)})
 *    void publish(Notification notification);
 * }
 * </pre>  
 * </p>
 * <p>
 * <img src="http://yuml.me/3455ff4a" >
 * </p>
 */
package com.lombard.integration.ntf.pub;