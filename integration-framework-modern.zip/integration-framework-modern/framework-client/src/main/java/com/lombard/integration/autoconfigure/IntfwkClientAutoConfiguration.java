package com.lombard.integration.autoconfigure;

import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.context.annotation.Bean;

import com.lombard.integration.fwk.common.client.service.ServiceLocator;
import com.lombard.integration.ws.client.support.ClientConfigPostProcessor;

@AutoConfiguration
public class IntfwkClientAutoConfiguration {

    @Bean
    @ConditionalOnMissingBean
    ServiceLocator serviceLocator() {
        return new ServiceLocator();
    }

    @Bean
    @ConditionalOnMissingBean
    ClientConfigPostProcessor clientConfigPostProcessor() {
        return new ClientConfigPostProcessor();
    }
}
