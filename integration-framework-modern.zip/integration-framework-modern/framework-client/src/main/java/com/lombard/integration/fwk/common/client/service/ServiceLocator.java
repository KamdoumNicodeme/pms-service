package com.lombard.integration.fwk.common.client.service;

import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.util.Assert;

/**
 * Implementation of the service locator design pattern providing client service instance.
 * <p>
 * As it is Spring container managed, it can be injected. And as clients service are also Spring container managed,
 * them can be direclty injected in any bean without ServiceLocator usage.
 * 
 * @author wvandenberghe
 * 
 */
@Deprecated
public class ServiceLocator implements ApplicationContextAware {

    private static ApplicationContext applicationContext;

    /**
     * {@inheritDoc}
     */
    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
        ServiceLocator.applicationContext = applicationContext;
    }

    /**
     * Get a service instance of type T.
     * <p>
     * Default timeout is 10 seconds.
     * 
     * @param <T>
     *            service type
     * @param serviceClass
     *            service class to return
     * @return service client instance
     * @throws IllegalStateException
     *             if application is not yet initialized
     * @throws IllegalArgumentException
     *             if serviceClass is null
     * @throws BeansException
     *             if serviceClass does not exist
     */
    public static < T > T getService(final Class<T> serviceClass) {
        Assert.state(applicationContext != null, "Application context not initialized");
        Assert.notNull(serviceClass, "serviceClass must not be null");

        return applicationContext.getBean(serviceClass.getName(), serviceClass);
    }

    /**
     * Get a service instance of type T.
     * 
     * @param <T>
     *            service type
     * @param serviceClass
     *            service class to return
     * @param timeout
     *            timeout to apply when a call is done
     * @return service client instance
     * @throws IllegalStateException
     *             if application is not yet initialized
     * @throws IllegalArgumentException
     *             if serviceClass is null or if timeout is lower than 0
     * @throws BeansException
     *             if serviceClass does not exist
     */
    public static < T > T getService(final Class<T> serviceClass, final long timeout) {
        Assert.isTrue(timeout >= 0, "Timeout must be greater or equal to 0");

        T service = getService(serviceClass);

        // WebServiceClientUtils.setTimeout(service, timeout);

        return service;
    }

}
