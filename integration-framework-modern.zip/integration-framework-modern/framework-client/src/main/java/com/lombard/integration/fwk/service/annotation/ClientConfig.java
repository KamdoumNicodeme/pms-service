package com.lombard.integration.fwk.service.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Annotation dedicated to web service client runtime configuration.
 * 
 * @author wvandenberghe
 * 
 */
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.FIELD)
public @interface ClientConfig {

    /**
     * The client timeout. Default set to 10s.
     * 
     * @return client timeout
     */
    long timeout() default 10000l;

    /**
     * Validate the client request. Default to false.
     * 
     * @return client request validation
     */
    boolean validate() default false;
}
