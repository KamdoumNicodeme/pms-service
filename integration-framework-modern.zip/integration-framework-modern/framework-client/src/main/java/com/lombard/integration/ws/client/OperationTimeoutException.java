package com.lombard.integration.ws.client;

import org.springframework.ws.client.WebServiceFaultException;

/**
 * Exception thrown when a operation does not respond in less than timeout.
 * 
 * @author wvandenberghe
 * 
 */
public class OperationTimeoutException extends WebServiceFaultException {

    private static final long serialVersionUID = 1L;

    public OperationTimeoutException(String message) {
        super(message);
    }
}
