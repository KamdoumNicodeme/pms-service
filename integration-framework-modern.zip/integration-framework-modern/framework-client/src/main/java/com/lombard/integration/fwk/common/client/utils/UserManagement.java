package com.lombard.integration.fwk.common.client.utils;

import com.lombard.integration.fwk.properties.FWKPropertiesManagement;
import com.lombard.integration.fwk.properties.FWKProperty;

@Deprecated
public final class UserManagement {

    private UserManagement() {

    }

    /**
     * <p>
     * Registers user. The user will be added as transport specific header into request messages.
     * </p>
     * 
     * @param aUser
     */
    public static void registerUser(String aUser) {
        FWKPropertiesManagement.putProperty(FWKProperty.FWKUser, aUser);
    }

    public static String getUser() {
        final String user = FWKPropertiesManagement.getProperty(FWKProperty.FWKUser);
        if (user == null) {
            throw new IllegalArgumentException(
                    "No user previously registered.\nUserManagement.registerUser() must be call before service call.");
        }

        return user;
    }
}
