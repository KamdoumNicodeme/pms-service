package com.lombard.integration.autoconfigure;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.core.env.Environment;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import org.springframework.util.Assert;
import org.springframework.util.StringUtils;

import com.lombard.integration.config.AbstractIntfwkDefinitionParser;
import com.lombard.integration.ntf.pub.NotificationSignatureManager;
import com.lombardinternational.crypto.dsig.KeystoreAccessor;

@AutoConfiguration(afterName = "com.lombard.integration.autoconfigure.IntfwkCommonAutoConfiguration")
@EnableConfigurationProperties(IntfwkProperties.class)
@ConditionalOnProperty(prefix = "intfwk.security", name = "enabled", havingValue = "true")
public class IntfwkSecurityAutoConfiguration {

    @Bean(name = "keyStoreAccessor")
    @ConditionalOnClass(KeystoreAccessor.class)
    @ConditionalOnMissingBean(name = "keyStoreAccessor")
    KeystoreAccessor keyStoreAccessor(Environment environment, IntfwkProperties properties) {
        String path = properties.getSecurity().getKeystoreConfigFilePath();
        if (!StringUtils.hasText(path)) {
            path = environment.getProperty("keystoreConfigFilePath");
        }
        Assert.hasText(path, "Property 'intfwk.security.keystore-config-file-path' or legacy 'keystoreConfigFilePath' is required");
        return new KeystoreAccessor(path);
    }

    @Bean(name = "notificationSignatureManager")
    @ConditionalOnMissingBean(name = "notificationSignatureManager")
    NotificationSignatureManager notificationSignatureManager(
            KeystoreAccessor keyStoreAccessor,
            @Qualifier(AbstractIntfwkDefinitionParser.DEFAULT_MODEL_MARSHALLER) Jaxb2Marshaller defaultModelMarshaller)
            throws Exception {
        return new NotificationSignatureManager(keyStoreAccessor, defaultModelMarshaller);
    }
}
