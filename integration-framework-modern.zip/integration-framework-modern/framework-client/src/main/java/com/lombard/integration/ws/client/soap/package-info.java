/**
 * Contains SOAP specific classes.
 * <p>
 * Defines how to handle exception. It only handle to kind of fault code:
 * <ul>
 * <li>BusinessError</li>
 * <li>TechnicalError</li>
 * </ul>
 * Business error results in a {@link com.lombard.integration.ws.client.BusinessException}, and technical error results 
 * in a {@link com.lombard.integration.ws.client.TechnicalException}. Stack trace of the original exception is set to 
 * the exception message. 
 */
package com.lombard.integration.ws.client.soap;

