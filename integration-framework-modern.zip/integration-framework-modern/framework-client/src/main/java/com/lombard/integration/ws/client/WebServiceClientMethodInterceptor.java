package com.lombard.integration.ws.client;

import static com.lombard.apm.logger.ApmLoggerConstants.*;

import java.lang.annotation.Annotation;
import java.lang.reflect.Method;

import jakarta.jws.WebMethod;
import jakarta.jws.WebParam;
import jakarta.xml.bind.JAXBElement;
import javax.xml.namespace.QName;

import org.aopalliance.intercept.MethodInterceptor;
import org.aopalliance.intercept.MethodInvocation;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.aop.support.AopUtils;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.util.Assert;
import org.springframework.ws.client.core.WebServiceTemplate;
import org.springframework.ws.soap.client.core.SoapActionCallback;
import org.springframework.ws.transport.WebServiceMessageSender;
import org.springframework.ws.transport.jms.JmsMessageSender;

import com.lombard.apm.ApmLoggerContextFactory;
import com.lombard.apm.logger.ApmLogger;
import com.lombard.apm.logger.ApmLoggerContext;
import com.lombard.apm.logger.ApmLoggerFactory;
import com.lombard.integration.util.ModelUtils;

/**
 * It wraps the web service interface and implements it as a client.
 * <p>
 * Implementation is based on JAX-WS annotations present in the interface.
 * 
 * @author wvandenberghe
 * @see WebServiceTemplate
 * @see WebMethod
 * @see WebParam
 */
public abstract class WebServiceClientMethodInterceptor implements MethodInterceptor, InitializingBean {

    private String idType;

    private WebServiceTemplate webServiceTemplate;

    private static final ApmLogger APM_LOGGER = ApmLoggerFactory.getApmLogger();

    public void setIdType(String idType) {

        this.idType = idType;
    }

    /**
     * Get the {@link WebServiceTemplate}.
     * 
     * @return
     */
    protected WebServiceTemplate getWebServiceTemplate() {

        return webServiceTemplate;
    }

    /**
     * Set the {@link WebServiceTemplate}.
     * 
     * @return
     */
    public void setWebServiceTemplate(WebServiceTemplate webServiceTemplate) {

        this.webServiceTemplate = webServiceTemplate;
    }

    /**
     * {@inheritDoc}
     */
    public void afterPropertiesSet() throws Exception {

        Assert.notNull(webServiceTemplate, "'webServiceTemplate' must not be null");
    }

    /**
     * {@inheritDoc}
     */
    public Object invoke(MethodInvocation methodInvocation) throws Throwable {

        if (AopUtils.isToStringMethod(methodInvocation.getMethod())) {
            return "Web Service invoker on [" + methodInvocation.getClass().getName() + "]";
        }

        Object[] parameters = beforeInvoke(methodInvocation);

        // as in case of timeout, webServiceTemplate return null
        // so, timeout exception must be managed manually
        long time = System.currentTimeMillis();

        Object result = doInvoke(methodInvocation, parameters, true);

        long timestamp = System.currentTimeMillis() - time;
        if (result == null && timestamp > getTimeout()) {
            Method m = methodInvocation.getMethod();
            Class<?> declaringClass = m.getDeclaringClass();
            throw new OperationTimeoutException("Timeout [" + getTimeout() + " ms] while executing operation " + declaringClass.getSimpleName()
                    + "." + m.getName());
        }

        return result;
    }

    private Object[] beforeInvoke(MethodInvocation methodInvocation) {

        Object[] arguments = methodInvocation.getArguments();

        if (arguments.length == 1) {
            Object arg = arguments[0];

            return new Object[] { ModelUtils.addCorrelationHandler(arg, idType) };
        }

        return arguments;
    }

    private Object doInvoke(MethodInvocation methodInvocation, Object[] parameters, boolean doApm) {

        Object proceed;
        final ApmLoggerContext apmLoggerContext;

        try {
            apmLoggerContext = ApmLoggerContextFactory.getInstance().createApmLoggerContext(methodInvocation);
        } catch (Exception e) {
            // Issue with Spring context --> just execute the next interceptor and return.
            return doInvoke(methodInvocation, parameters);
        }

        try {
            // Start timer
            apmLoggerContext.startWatch();

            // Call service
            proceed = doInvoke(methodInvocation, parameters);

            apmLoggerContext.addParam(PARAM_ACTIVITY_STATUS, ACTIVITY_STATUS_SUCCESS);

        } catch (RuntimeException e) {
            apmLoggerContext.addParam(PARAM_ACTIVITY_STATUS, ACTIVITY_STATUS_FAILED);
            apmLoggerContext.addParam(PARAM_ERROR_MESSAGE, e);
            throw e;
        } finally {
            // Stop timer + log
            apmLoggerContext.stopWatch();
            APM_LOGGER.trace(apmLoggerContext);

        }

        return proceed;
    }

    /**
     * 
     * @param methodInvocation
     * @return
     */
    private Object doInvoke(MethodInvocation methodInvocation, Object[] parameters) {

        WebMethod webMethod = methodInvocation.getMethod().getAnnotation(WebMethod.class);

        // check in case some none WS operations are called (toString, equals...)
        if (webMethod == null) {
            Log log = LogFactory.getLog(methodInvocation.getClass());
            log.warn("Method '" + methodInvocation.getMethod().getName() + "' from [" + methodInvocation.getClass().getName()
                    + "] is not exposed as a valid web service operation");

            return null;
        }

        // update timeout
        for (WebServiceMessageSender sender : webServiceTemplate.getMessageSenders()) {
            if (sender instanceof JmsMessageSender jmsSender) {
                jmsSender.setReceiveTimeout(getTimeout());
            }
        }

        // get the parameter, if it exists, as a JAXB element
        JAXBElement<?> paramElement = parameterAsJaxbElement(methodInvocation, parameters);
        // execute client call and get result
        JAXBElement<?> resultElement =
                (JAXBElement<?>) webServiceTemplate.marshalSendAndReceive(paramElement, new SoapActionCallback(webMethod.action()));

        // convert JAXB element to object
        return (resultElement != null) ? resultElement.getValue() : null;
    }

    /**
     * Find WebParam annotation on method parameter if there is one.
     * 
     * @param methodInvocation
     * @return WebParam annotation if there is a parameter, else, null
     * @throws IllegalStateException
     *             in case there is more than one parameter or no annoation but a parameter
     */
    private WebParam findWebParam(MethodInvocation methodInvocation) {

        Method method = methodInvocation.getMethod();
        // get every annotations for every parameters
        Annotation[][] annotations = method.getParameterAnnotations();

        if (annotations.length > 1) {
            throw new IllegalStateException("Web service client method must have at most one parameter");
        }

        // supported case
        if (annotations.length == 1) {
            Annotation[] annotationParam = annotations[0];
            // get the annotation
            WebParam webParam = null;
            for (Annotation annotation : annotationParam) {
                if (annotation instanceof WebParam currentWebParam) {
                    if (webParam == null) {
                        webParam = currentWebParam;
                    } else {
                        throw new IllegalStateException("Web service client method must be annotated only once by @WebParam");
                    }
                }
            }

            if (webParam == null) {
                throw new IllegalStateException("Web service client method must be annotated by @WebParam");
            }

            return webParam;
        } else {
            return null;
        }
    }

    /**
     * Convert parameter to a {@link JAXBElement}.
     * 
     * @param methodInvocation
     * @return the parameter as a {@link JAXBElement} or null if there is no parameter
     * @throws IllegalStateException
     *             in case of the method has more than one parameter
     */
    @SuppressWarnings({ "unchecked", "rawtypes" })
    private JAXBElement<?> parameterAsJaxbElement(MethodInvocation methodInvocation, Object[] arguments) {

        if (arguments.length == 1) {
            WebParam webParam = findWebParam(methodInvocation);
            return new JAXBElement(new QName(webParam.targetNamespace(), webParam.name()), arguments[0].getClass(), arguments[0]);
        }
        if (arguments.length == 0) {
            return null;
        }

        throw new IllegalStateException("Web service method at most one parameter");
    }

    /**
     * 
     * @return
     */
    protected abstract long getTimeout();

}
