package com.lombard.integration.ws.client;

import java.net.URI;

import jakarta.jws.WebService;

import org.springframework.beans.factory.InitializingBean;
import org.springframework.core.annotation.AnnotationUtils;
import org.springframework.util.Assert;
import org.springframework.ws.client.support.destination.DestinationProvider;

/**
 * 
 * @author wvandenberghe
 * 
 */
public class DefaultDestinationProvider implements DestinationProvider, InitializingBean {

    private static final String DESTINATION_TEMPLATE =
            "jms:%s?deliveryMode=NON_PERSISTENT&amp;messageType=byte&amp;timeToLive=%d";

    private String destinationName;

    private long defaultTimeout;

    private WebService webService;

    /**
     * 
     * @param destinationName
     */
    public void setDestinationName(String destinationName) {
        this.destinationName = destinationName;
    }

    /**
     * 
     * @param timeout
     */
    public void setDefaultTimeout(long defaultTimeout) {
        this.defaultTimeout = defaultTimeout;
    }

    /**
     * 
     * @param webServiceInterface
     */
    public void setWebServiceInterface(Class<?> webServiceInterface) {
        if (webServiceInterface == null) {
            throw new IllegalArgumentException("Property [webServiceInterface] must not be null");
        }

        if (!webServiceInterface.isInterface()) {
            throw new IllegalArgumentException("Property [webServiceInterface] must be an interface");
        }

        webService = AnnotationUtils.findAnnotation(webServiceInterface, WebService.class);
    }

    /**
     * 
     */
    public void afterPropertiesSet() throws Exception {
        Assert.notNull(webService, "Property [webServiceInterface] is mandatory");

    }

    /**
     * 
     */
    public URI getDestination() {
        if (WebServiceClientMetadataRegistry.instance().getTimeoutMetadata(webService) < defaultTimeout) {
            WebServiceClientMetadataRegistry.instance().setTimeoutMetadata(webService, defaultTimeout);
        }

        return URI.create(String.format(DESTINATION_TEMPLATE, destinationName, WebServiceClientMetadataRegistry
                .instance().getTimeoutMetadata(webService)));
    }

}
