/**
 * Contains classes to support web service client usage, such as annotation based configuration.
 * <p>
 * The following snippet must be added:
 * <pre>
 * &lt;import resource="classpath:intfwk-client-context.xml"/>
 * </pre>
 * It imports directly a post processor responsible to fill web service client meta data such as:
 * <ul>
 * <li>timeout</li>
 * <li>request validation</li>
 * </ul>
 * It is based on annotation {@link com.lombard.integration.fwk.service.annotation.ClientConfig}.
 */
package com.lombard.integration.ws.client.support;