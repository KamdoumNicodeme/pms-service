package com.lombard.integration.ntf.pub;

import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.aopalliance.intercept.MethodInterceptor;
import org.aopalliance.intercept.MethodInvocation;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;

import com.lombard.cdm.ActivityHandler;
import com.lombard.cdm.IdType;
import com.lombard.cdm.StatusType;
import com.lombard.csm.BusinessContext;
import com.lombard.csm.Notification;
import com.lombard.integration.fwk.notification.annotation.BusinessKey;
import com.lombard.integration.fwk.notification.annotation.Secured;
import com.lombard.integration.fwk.utils.ActivityHandlerBuilder;
import com.lombard.integration.fwk.utils.CorrelationHandlerBuilder;
import com.lombard.integration.ntf.NotificationMessagingException;
import com.lombard.integration.ntf.NotificationService;
import com.lombard.integration.ntf.properties.BusinessKeyEvaluator;
import com.lombard.integration.tntf.trace.TraceService;
import com.lombard.integration.util.TracerUtils;

/**
 * Wrap call to publisher interface method.
 * 
 * @author wvandenberghe
 * 
 */
public abstract class NotificationPublisherMethodInterceptor implements MethodInterceptor, ApplicationContextAware {

    protected static final Log logger = LogFactory.getLog(NotificationPublisherMethodInterceptor.class);

    private static final String ACTIVITY_NAME_TEMPLATE = "Send notification [%s]";

    private static final int BC_LENGTH = "BusinessContext".length();

    private ApplicationContext applicationContext;

    private NotificationService notificationService;

    private BusinessKeyEvaluator businessKeyEvaluator;

    private IdType idType;

    /**
     * {@inheritDoc}
     */
    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {

        this.applicationContext = applicationContext;
    }

    /**
     * Set notification service to send effectively {@link Notification}
     * 
     * @param notificationService
     */
    public void setNotificationService(NotificationService notificationService) {

        this.notificationService = notificationService;
    }

    /**
     * 
     * @param businessKeyEvaluator
     */
    public void setBusinessKeyEvaluator(BusinessKeyEvaluator businessKeyEvaluator) {

        this.businessKeyEvaluator = businessKeyEvaluator;
    }

    public IdType getIdType() {

        return idType;
    }

    public void setIdType(IdType idType) {

        this.idType = idType;
    }

    public Object invoke(MethodInvocation invocation) throws Throwable {

        Object[] arguments = invocation.getArguments();

        if (arguments.length != 1) {
            throw new IllegalArgumentException("Method must have only one argument");
        }

        Notification notification = getNotification(arguments);

        if (invocation.getMethod().isAnnotationPresent(Secured.class)) {
            final NotificationSignatureManager bean = applicationContext.getBean(NotificationSignatureManager.class);
            if (bean == null) {
                throw new NullPointerException("You specified the method " + invocation.getMethod().getName()
                        + " as secured but there is no signature manager in the Spring context. Please check if you import the intfwk-security-context.xml in your context configuration files!");
            }

            notification.setCorrelationHandler(CorrelationHandlerBuilder.from(getIdType()).build());

            notification = bean.sign(notification);
        }

        // notify
        notificationService.sendOrReceive(notification);

        // evaluate business key values
        Method method = invocation.getMethod();
        Map<String,String> keyValues = evaluate(getBusinessKeys(method, notification.getBusinessContext()), arguments[0]);

        // create builder based on the sent notification
        String businessContextName = notification.getBusinessContext().getClass().getSimpleName();
        ActivityHandlerBuilder builder = ActivityHandlerBuilder.from(notification.getCorrelationHandler())
                .activityName(String.format(ACTIVITY_NAME_TEMPLATE, businessContextName.substring(0, businessContextName.length() - BC_LENGTH)))
                .activityStatus(StatusType.PROCESS_NOTIFIED);

        // fill properties
        for (Entry<String,String> entry : keyValues.entrySet()) {
            builder.property(entry.getKey(), entry.getValue());
        }

        // trace activity
        trace(builder);

        return null;
    }

    /**
     * 
     * @param publisher
     */
    protected abstract void registerBusinessKeyMapping(Class<?> publisher);

    /**
     * 
     * @param method
     * @param businessContext
     * @return
     */
    protected abstract List<BusinessKey> getBusinessKeys(Method method, BusinessContext businessContext);

    /**
     * 
     * @param businessKeys
     * @param argument
     * @return
     */
    private Map<String, String> evaluate(List<BusinessKey> businessKeys, Object argument) {

        final Map<String, String> result = new HashMap<>();

        if (businessKeys != null) {
            for (BusinessKey businessKey : businessKeys) {
                String value = null;
                if (argument instanceof Notification notification) {
                    value = businessKeyEvaluator.evaluate(notification, businessKey.expression());
                } else {
                    value = businessKeyEvaluator.evaluate((BusinessContext) argument, businessKey.expression());
                }

                if (value == null) {
                    logger.warn(String.format("Error while evaluating expression [%s]", businessKey.expression()));
                } else {
                    result.put(businessKey.name(), value);
                }
            }
        }

        return result;
    }

    /**
     * 
     * @param builder
     */
    private void trace(ActivityHandlerBuilder builder) {

        try {
            ActivityHandler activityHandler = builder.build();

            TraceService traceService = TracerUtils.getTracer(applicationContext);
            traceService.traceSynchronous(activityHandler);
        } catch (Exception e) {
            logger.error("Error while tracing", e);
        }
    }

    /**
     * 
     * @param arguments
     * @return
     * @throws Throwable
     */
    private Notification getNotification(Object[] arguments) {

        if (arguments[0] instanceof Notification notification) {
            return notification;
        } else if (arguments[0] instanceof BusinessContext businessContext) {
            Notification notification = new Notification();
            notification.setBusinessContext(businessContext);
            return notification;
        } else {
            throw new NotificationMessagingException("Argument is not of type [Notification]");
        }
    }

}
