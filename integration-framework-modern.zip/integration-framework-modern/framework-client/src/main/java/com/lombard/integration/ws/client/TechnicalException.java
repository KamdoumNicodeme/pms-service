package com.lombard.integration.ws.client;

import org.springframework.ws.soap.SoapMessage;
import org.springframework.ws.soap.client.SoapFaultClientException;

/**
 * Exception to throw technical error on ESB.
 * 
 * @author wvandenberghe
 * 
 */
public class TechnicalException extends SoapFaultClientException {

    private static final long serialVersionUID = 1L;

    /**
     * Constructor from a response message
     * 
     * @param faultMessage
     */
    public TechnicalException(SoapMessage faultMessage) {
        super(faultMessage);
    }

}
