/**
 * Contains parser for XML defined notification publisher.
 * <p>
 * XML definition is described as following: 
 * <pre>
 * &lt;intfwk:notif-publisher 
 *      id-type="ELOMBARD"
 *      destination="NTF.PUB"
 *      validate="true" 
 *      schemas="classpath:/schemas/CSM/EntryPoint.xsd"
 *      connection-factory="legConnectionFactory" 
 *      marshaller="jaxbMarshaller"
 *      unmarshaller="jaxbUnmarshaller"
 *      base-package="com.lombard.integration.publisher"/>
 * </pre>
 * This element is part of the Integration Framework namespace and defines the following attributes:
 * <dl>
 * <dt>id-type</dt>
 * <dd>Must be one of the {@link com.lombard.cdm.IdType} enumeration value</dd>
 * <dt>destination</dt>
 * <dd>queue name. The default one is <b>NTF.ESB.CORE</b></dd>
 * <dt>validate</dt>
 * <dd>notification XML validation. Default set to false.</dd>
 * <dt>schemas</dt>
 * <dd>Resource location for validation. By default, set to <b>classpath:/schemas/CSM/EntryPoint.xsd</b></dd>
 * <dt>connection-factory</dt>
 * <dd>connection factory reference. Default is <b>ntiConnectionFactory</b> defined in context <b>intfwk-common-context.xml</b></dd>
 * <dt>marshaller</dd>
 * <dd>XML marshaller. Default is a reference to <b>jaxb2Marshaller</b> defined in context <b>intfwk-common-context.xml</b></dd>
 * <dt>umarshaller</dt>
 * <dd>XML unmarshaller. Default is a reference to <b>jaxb2Marshaller</b> defined in context <b>intfwk-common-context.xml</b></dd>
 * <dt>base-package</dt>
 * <dd>an optional package name where to find interfaces annotated by {@link com.lombard.integration.fwk.notification.annotation.Publisher}</dd>
 * </dl>
 * </p>
 */
package com.lombard.integration.ntf.pub.config;