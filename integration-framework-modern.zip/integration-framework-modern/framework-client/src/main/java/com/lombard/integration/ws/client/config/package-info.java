/**
 * Contains parser for XML defined web service client.
 * <p>
 * XML definition is described as following: 
 * <pre>
 * &lt;intfwk:client
 *     name="com.lombard.integration.fwk.services.mandate.MandateService"
 *     class="com.lombard.integration.fwk.services.mandate.MandateService"
 *     destination="WS.ESB.CORE"
 *     timeout="20000"
 *     validate="true"/>
 * </pre>
 * This element is part of the Integration Framework namespace and defines the following attributes:
 * <dl>
 * <dt>name</dt>
 * <dd>bean name.</dd>
 * <dt>class</dt>
 * <dd>client interface full class name.</dd>
 * <dt>destination</dt>
 * <dd>queue name where to send request.</dd>
 * <dt>timeout</dt>
 * <dd>max time to get the response in milli seconds. Optional, default set to 10s.</dd>
 * <dt>validate</dt>
 * <dd>activate/deactivate request validation. Optional, default value set to false.</dd>
 * </dl>
 */
package com.lombard.integration.ws.client.config;