package com.lombard.integration.ws.client;

import org.springframework.ws.soap.SoapMessage;
import org.springframework.ws.soap.client.SoapFaultClientException;

/**
 * Exception to be thrown when something goes wrong on connectors.
 * 
 * @author wvandenberghe
 * 
 */
public class BusinessException extends SoapFaultClientException {

    private static final long serialVersionUID = 1L;

    /**
     * Constructor from a response message.
     * 
     * @param faultMessage
     */
    public BusinessException(SoapMessage faultMessage) {
        super(faultMessage);
    }

}
