/**
 * Contains Tibco specific classes.
 * <p>
 * Management of SOAP over JMS specific header properties.
 */
package com.lombard.integration.ws.client.tibco;