package com.lombard.integration.fwk.common.client.service;

/**
 * <p>Class contains transport service client configuration.</p> 
 * 
 * <p>Usualy object instanes of the class are retreived from spring context 
 * during framework initialization, but they can also be created on the fly.
 * </p>
 * 
 * <p>Spring context example:</p>
 * <code>
 * <bean id="lu.lombard.integration.fwk.TestInterface" 
 *              class="lu.lombard.integration.fwk.common.client.ClientConfig">
 *   <property name="interfaceClass" 
 *              value="lu.lombard.integration.fwk.TestInterface" />
 *   <property name="destination" value="lia.dev.test" />
 * </bean>
 * </code>
 * 
 * @author Aleksandar Valchev
 */
@Deprecated
public class ServiceConfiguration {

	/** Name of the interface that represnets the service. */
	private String interfaceClass;	
	/** Name of the JMS destination that is going to be used. */
	private String destination;
	/** <p>Type of the JMS message. Currently "text","binary" and "byte" types are 
	 * supported by CXF. TIBCO supports only "text" and "byte".</p>
	 */
	private String messageType = "byte"; 
	/** <p>Time in milliseconds that client waits for response.</p> */	
	private Long receiveTimeout = 60000L;
	
	public Long getReceiveTimeout() {
		return receiveTimeout;
	}
	
	public void setReceiveTimeout(Long receiveTimeout) {
		this.receiveTimeout = receiveTimeout;
	}
	
	public String getMessageType() {
		return messageType;
	}
	
	public void setMessageType(String messageType) {
		this.messageType = messageType;
	}
	
	public String getInterfaceClass() {
		return interfaceClass;
	}
	
	public void setInterfaceClass(String interfaceClass) {
		this.interfaceClass = interfaceClass;
	}

	public String getDestination() {
		return destination;
	}
	
	public void setDestination(String destination) {
		this.destination = destination;
	}
	
}
