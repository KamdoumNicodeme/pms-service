# Integration Framework Modern

Migration Java 21 / Spring Boot 3.5.13 du projet `integration-framework`.

Objectif: conserver le comportement historique du framework d'integration tout en modernisant le socle technique.

## Modules

- `framework-common`: namespace Spring `intfwk`, JAXB, notifications, validation, tracing, remoting JMS de compatibilite.
- `framework-client`: proxies client SOAP/JMS, publishers de notifications, signature.
- `framework-server`: listeners serveur SOAP/JMS, consumers notification/gateway, hospitalisation.
- `framework-config`: fichiers de configuration environnementale.

## Compatibilite comportementale

Le namespace XML reste `http://www.lombard.lu/schema/intfwk`.
Les elements `client`, `service-definitions`, `init-service`, `notif-publisher`, `notif-consumer`, `tracer` et `gtw-consumer` sont conserves.

Spring Framework 6 ne fournit plus les anciennes classes de remoting JMS utilisees par ce framework. Le module `framework-common` contient donc une couche de compatibilite volontairement minimale sous les anciens packages publics `org.springframework.remoting.support` et `org.springframework.jms.remoting`. Elle existe pour conserver les noms de classes et la forme des objets echanges, notamment `RemoteInvocation` et `RemoteInvocationResult`.

## Preconditions importantes

Spring Boot 3 utilise Jakarta EE. Les artefacts internes CDM/CSM, TIBCO EMS et XML security doivent etre disponibles en variantes compatibles Jakarta:

- JMS provider compatible `jakarta.jms`.
- Modeles JAXB compatibles `jakarta.xml.bind`.
- Annotations JAX-WS compatibles `jakarta.jws`.

Sans ces artefacts internes modernises, le projet source est migre mais un build complet ne pourra pas etre garanti.


## Configuration moderne

Les anciens XML sont conserves pour compatibilite, mais les beans internes sont aussi disponibles via auto-configuration Spring Boot.

Noms de beans conserves:

- `connectionFactory`, `legConnectionFactory`, `tecConnectionFactory`, `svcConnectionFactory`, `ntiConnectionFactory`
- `ntiTibcoXAConnectionFactory`, `tecTibcoXAConnectionFactory` quand `intfwk.jms.xa.enabled=true`
- `defaultModelMarshaller`
- `serviceLocator`, `clientConfigPostProcessor`
- `keyStoreAccessor`, `notificationSignatureManager` quand `intfwk.security.enabled=true`

Les proprietes historiques comme `svc.connection.url` restent supportees. Les variantes Boot modernes utilisent le prefixe `intfwk.*`.
