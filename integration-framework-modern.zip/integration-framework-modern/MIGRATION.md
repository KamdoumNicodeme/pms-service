# Notes de migration

## Ce qui a ete conserve

- Meme decoupage fonctionnel: common, client, server, config.
- Meme namespace Spring XML: `http://www.lombard.lu/schema/intfwk`.
- Meme logique de parsing XML pour clients, services, notifications, trace, gateway.
- Meme modele de correlation handler, business keys, tracing et hospitalisation.
- Meme politique JMS publish-and-forget pour notifications, trace et hospital.

## Ce qui a ete modernise

- Parent Maven Spring Boot `3.5.13`.
- Compilation Java `21` via `maven.compiler.release`.
- Migration selective `javax.jms`, `javax.jws`, `javax.xml.bind`, `javax.annotation` vers `jakarta.*`.
- Remplacement des dependances Spring 3 par Spring Boot / Spring Framework 6.
- Conservation d'une couche de compatibilite pour le remoting JMS retire de Spring 6.

## Points a valider avec les artefacts internes

- Disponibilite d'un client TIBCO EMS compatible `jakarta.jms`.
- Disponibilite des jars CDM/CSM generes avec `jakarta.xml.bind`.
- Disponibilite de `lib-xmlsec` compatible Jakarta JAXB.
- Compatibilite des anciennes definitions XML Spring avec Spring Framework 6.

## Strategie recommandee

1. Publier ou installer les artefacts internes en variantes Jakarta.
2. Compiler d'abord `framework-common`.
3. Compiler `framework-server`, puis `framework-client`.
4. Rejouer les tests de parsing Spring XML.
5. Rejouer les tests JMS avec broker local, puis avec TIBCO EMS.


## Conversion des beans XML

La conversion est additive et non destructive:

- Les fichiers `intfwk-common-context.xml`, `intfwk-common-xa-context.xml`, `intfwk-client-context.xml` et `intfwk-security-context.xml` restent presents.
- Les memes beans sont exposes en `@AutoConfiguration` Spring Boot.
- Les beans modernes utilisent `@ConditionalOnMissingBean`, donc les definitions XML ou applicatives gardent la priorite.
- Les beans XA et signature restent opt-in pour reproduire le caractere optionnel des XML historiques.
