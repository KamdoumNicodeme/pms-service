package com.lombard.integration.jaxb;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import jakarta.xml.bind.annotation.XmlIDREF;
import jakarta.xml.bind.annotation.XmlList;

import org.junit.Assert;
import org.junit.Test;

import com.lombard.cdm.AbstractEntity;

public class CollectionJaxBListenerTest {

    private CollectionJaxBListener listener = new CollectionJaxBListener();

    @Test
    public void testBeforeMarshall() {
        Dummy dummy = new Dummy();
        listener.beforeMarshal(dummy);

        Assert.assertNull(dummy.getStrList());

        dummy.setStr("test");
        dummy.setStrList(Collections.singletonList("testList"));

        listener.beforeMarshal(dummy);

        Assert.assertNotNull(dummy.getStrList());
        Assert.assertEquals("test", dummy.getStr());
    }

    class Dummy extends AbstractEntity {

        @XmlIDREF
        @XmlList
        private String str;

        private String anotherStr;

        @XmlIDREF
        @XmlList
        private List<String> strList = new ArrayList<String>();

        public String getStr() {
            return str;
        }

        public void setStr(String str) {
            this.str = str;
        }

        public String getAnotherStr() {
            return anotherStr;
        }

        public void setAnotherStr(String anotherStr) {
            this.anotherStr = anotherStr;
        }

        public List<String> getStrList() {
            return strList;
        }

        public void setStrList(List<String> strList) {
            this.strList = strList;
        }
    }
}
