package com.lombard.integration.ntf.properties;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.GregorianCalendar;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.junit.Assert;
import org.junit.Ignore;
import org.junit.Test;
import org.springframework.expression.spel.standard.SpelExpressionParser;

import com.lombard.cdm.IdType;
import com.lombard.csm.GeneralInformation;
import com.lombard.csm.Notification;
import com.lombard.csm.TradeOrderBusinessContext;
import com.lombard.integration.fwk.utils.CorrelationHandlerBuilder;
import com.lombard.integration.ntf.properties.transformer.BusinessKeyValueTransformer;
import com.lombard.integration.ntf.properties.transformer.CalendarBusinessKeyValueTransformer;
import com.lombard.integration.ntf.properties.transformer.DateBusinessKeyValueTransformer;
import com.lombard.integration.ntf.properties.transformer.DefaultBusinessKeyValueTransformer;

/**
 * 
 * @author JZAPADKA
 * 
 */
public class SimpleBusinessKeyEvaluatorTest {

    private static final Log logger = LogFactory.getLog(SimpleBusinessKeyEvaluatorTest.class);

    @Ignore
    @Test
    public void evaluateObjectTest() {

        logger.info("-- Evaluate Object --");
        Notification notif = new Notification();
        notif.setCorrelationHandler(CorrelationHandlerBuilder.newBuilder().name(IdType.ELOMBARD).build());
        List<BusinessKeyValueTransformer<?>> classTypeList = new ArrayList<BusinessKeyValueTransformer<?>>();
        classTypeList.add(new DefaultBusinessKeyValueTransformer());
        classTypeList.add(new DateBusinessKeyValueTransformer());
        classTypeList.add(new CalendarBusinessKeyValueTransformer());

        SimpleBusinessKeyEvaluator simple = new SimpleBusinessKeyEvaluator();
        simple.setExpressionParser(new SpelExpressionParser());
        simple.setTransformers(classTypeList);

        Assert.assertEquals(notif.getCorrelationHandler().getId(), simple.evaluate(notif, "correlationHandler.id"));
        Assert.assertEquals(notif.getCorrelationHandler().getInitiator().getName().toString(),
                simple.evaluate(notif, "correlationHandler.initiator.name"));
    }

    @Ignore
    @Test
    public void evaluateDateTest() {

        logger.info("-- Evaluate Date --");
        Notification notif = new Notification();

        TradeOrderBusinessContext trade = new TradeOrderBusinessContext();
        GeneralInformation generalInformation = new GeneralInformation();
        generalInformation.setExternalReference("External reference");
        generalInformation.setMessageType("Message type");
        generalInformation.setExpirationDate(GregorianCalendar.getInstance());
        trade.setGeneralInformation(generalInformation);
        notif.setBusinessContext(trade);

        DateBusinessKeyValueTransformer date = new DateBusinessKeyValueTransformer();
        DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss.SSS");
        date.setDateFormat(dateFormat);

        CalendarBusinessKeyValueTransformer calendar = new CalendarBusinessKeyValueTransformer();
        calendar.setDelegate(date);

        List<BusinessKeyValueTransformer<?>> transformers = new ArrayList<BusinessKeyValueTransformer<?>>();
        transformers.add(calendar);
        transformers.add(date);

        SimpleBusinessKeyEvaluator simple = new SimpleBusinessKeyEvaluator();
        simple.setExpressionParser(new SpelExpressionParser());
        simple.setTransformers(transformers);

        Assert.assertEquals(dateFormat.format(trade.getGeneralInformation().getExpirationDate().getTime()),
                simple.evaluate(notif, "businessContext.generalInformation.expirationDate"));

    }

    @Ignore
    @Test
    public void sortListClassTypeTest() {

        logger.info("-- Sort list transformers --");
        List<BusinessKeyValueTransformer<?>> transformers = new ArrayList<BusinessKeyValueTransformer<?>>();

        transformers.add(new DateBusinessKeyValueTransformer());
        transformers.add(new DefaultBusinessKeyValueTransformer());
        transformers.add(new CalendarBusinessKeyValueTransformer());
        String expected = "[Date][Calendar][Object]";
        String result = "";
        // logger.info("--BEFORE SORT--");
        for (BusinessKeyValueTransformer<?> bkvt : transformers) {
            result += "[" + bkvt.getClassType().getSimpleName() + "]";
        }
        // logger.info(result);

        SimpleBusinessKeyEvaluator simple = new SimpleBusinessKeyEvaluator();
        simple.setTransformers(transformers);

        // logger.info("--AFTER SORT--");
        result = "";
        for (BusinessKeyValueTransformer<?> bkvt : simple.getTransformers()) {
            result += "[" + bkvt.getClassType().getSimpleName() + "]";
        }
        // logger.info(result);
        Assert.assertEquals(expected, result);
    }

    @Test
    public void evaluateWithoutTransformers() {

        logger.info("-- Evaluate without transfomers --");

        Notification notif = new Notification();
        notif.setCorrelationHandler(CorrelationHandlerBuilder.newBuilder().name(IdType.ELOMBARD).build());

        SimpleBusinessKeyEvaluator simple = new SimpleBusinessKeyEvaluator();
        simple.setExpressionParser(new SpelExpressionParser());
        try {
            simple.afterPropertiesSet();
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        Assert.assertEquals(notif.getCorrelationHandler().getId(), simple.evaluate(notif, "correlationHandler.id"));
    }
}
