package com.lombard.integration.ntf.properties.transformer;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.junit.Assert;
import org.junit.Test;

/**
 * 
 * @author JZAPADKA
 * 
 */
public class BusinessKeyValueTransformerTest {

    private static final Log logger = LogFactory.getLog(BusinessKeyValueTransformerTest.class);
    public final String pattern = new String("dd/MM/yyyy HH:mm:ss.SSS");

    // @Ignore
    @Test
    public void testDefaultTransform() {
        logger.info("--Test Default Transform--");
        Object obj = new String("Test success");
        BusinessKeyValueTransformer < Object > bkvtDefault = new DefaultBusinessKeyValueTransformer();
        Assert.assertEquals(bkvtDefault.getClassType(), Object.class);
        Assert.assertNotNull(obj);
        Assert.assertEquals(obj.toString(), bkvtDefault.transform(obj));
        // logger.info("Test Default Transform result : " + bkvtDefault.transform(obj));
    }

    // @Ignore
    @Test
    public void testCalendarTransform() {
        logger.info("--Test Calendar Transform--");
        BusinessKeyValueTransformer < Calendar > bkvtCalendar = new CalendarBusinessKeyValueTransformer();
        Assert.assertEquals(bkvtCalendar.getClassType(), Calendar.class);
        Calendar c = Calendar.getInstance();
        SimpleDateFormat sdf = new SimpleDateFormat(pattern);
        DateBusinessKeyValueTransformer dkvt = new DateBusinessKeyValueTransformer();
        dkvt.setDateFormat(sdf);
        ((CalendarBusinessKeyValueTransformer) bkvtCalendar).setDelegate(dkvt);
        Assert.assertNotNull(c);
        Assert.assertEquals(((CalendarBusinessKeyValueTransformer) bkvtCalendar).transform(c), sdf.format(c
                .getTime()));
        // logger.info("Test Calendar Transform result : " + bkvtCalendar.transform(c));
    }

    // @Ignore
    @Test
    public void testGregorianCalendarTransform() {
        logger.info("--Test Gregorian Calendar Transform--");
        BusinessKeyValueTransformer < Calendar > bkvtCalendar = new CalendarBusinessKeyValueTransformer();
        Assert.assertEquals(bkvtCalendar.getClassType(), Calendar.class);
        GregorianCalendar c = new GregorianCalendar();
        SimpleDateFormat sdf = new SimpleDateFormat(pattern);
        DateBusinessKeyValueTransformer dkvt = new DateBusinessKeyValueTransformer();
        dkvt.setDateFormat(sdf);
        ((CalendarBusinessKeyValueTransformer) bkvtCalendar).setDelegate(dkvt);
        Assert.assertNotNull(c);
        Assert.assertEquals(((CalendarBusinessKeyValueTransformer) bkvtCalendar).transform(c), sdf.format(c
                .getTime()));
        // logger.info("Test Greogrian Calendar Transform result : " + bkvtCalendar.transform(c));
    }

    // @Ignore
    @Test
    public void testDateTransform() {
        logger.info("--Test Date Transform--");
        BusinessKeyValueTransformer < Date > bkvtDate = new DateBusinessKeyValueTransformer();
        Assert.assertEquals(bkvtDate.getClassType(), Date.class);
        Date date = new Date();
        SimpleDateFormat sdf = new SimpleDateFormat(pattern);
        ((DateBusinessKeyValueTransformer) bkvtDate).setDateFormat(sdf);
        Assert.assertNotNull(date);
        Assert
                .assertEquals(((DateBusinessKeyValueTransformer) bkvtDate).transform(date), sdf.format(date
                        .getTime()));
        // logger.info("Test Date Transform result : " + bkvtDate.transform(date));
    }
}
