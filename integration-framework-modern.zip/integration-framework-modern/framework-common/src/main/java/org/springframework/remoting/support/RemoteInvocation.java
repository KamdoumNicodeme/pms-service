package org.springframework.remoting.support;

import java.io.Serializable;
import java.lang.reflect.Method;
import java.util.Arrays;

/**
 * Compatibility replacement for the legacy Spring remoting type removed from Spring Framework 6.
 *
 * <p>The package and public class name are intentionally kept to preserve serialized JMS payload compatibility with
 * the historical integration framework protocol.</p>
 */
public class RemoteInvocation implements Serializable {

    private static final long serialVersionUID = 6876024250231820554L;

    private String methodName;
    private Class<?>[] parameterTypes;
    private Object[] arguments;

    public RemoteInvocation() {
    }

    public RemoteInvocation(String methodName, Class<?>[] parameterTypes, Object[] arguments) {
        this.methodName = methodName;
        this.parameterTypes = parameterTypes != null ? parameterTypes.clone() : new Class<?>[0];
        this.arguments = arguments != null ? arguments.clone() : new Object[0];
    }

    public String getMethodName() {
        return methodName;
    }

    public void setMethodName(String methodName) {
        this.methodName = methodName;
    }

    public Class<?>[] getParameterTypes() {
        return parameterTypes != null ? parameterTypes.clone() : new Class<?>[0];
    }

    public void setParameterTypes(Class<?>[] parameterTypes) {
        this.parameterTypes = parameterTypes != null ? parameterTypes.clone() : new Class<?>[0];
    }

    public Object[] getArguments() {
        return arguments != null ? arguments.clone() : new Object[0];
    }

    public void setArguments(Object[] arguments) {
        this.arguments = arguments != null ? arguments.clone() : new Object[0];
    }

    public Method getMethod(Class<?> targetClass) throws NoSuchMethodException {
        return targetClass.getMethod(methodName, getParameterTypes());
    }

    @Override
    public String toString() {
        return "RemoteInvocation{" +
                "methodName='" + methodName + '\'' +
                ", parameterTypes=" + Arrays.toString(parameterTypes) +
                '}';
    }
}
