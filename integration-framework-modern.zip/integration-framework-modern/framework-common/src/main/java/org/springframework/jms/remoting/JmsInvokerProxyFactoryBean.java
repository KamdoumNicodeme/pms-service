package org.springframework.jms.remoting;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;

import jakarta.jms.Connection;
import jakarta.jms.ConnectionFactory;
import jakarta.jms.Destination;
import jakarta.jms.JMSException;
import jakarta.jms.Message;
import jakarta.jms.MessageConsumer;
import jakarta.jms.MessageProducer;
import jakarta.jms.Queue;
import jakarta.jms.Session;
import jakarta.jms.TemporaryQueue;

import org.springframework.beans.factory.FactoryBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.jms.support.JmsUtils;
import org.springframework.jms.support.converter.MessageConverter;
import org.springframework.jms.support.converter.SimpleMessageConverter;
import org.springframework.remoting.support.RemoteInvocation;
import org.springframework.remoting.support.RemoteInvocationResult;
import org.springframework.util.Assert;

/**
 * Small compatibility implementation of the removed Spring JMS invoker proxy.
 *
 * <p>It is intentionally limited to the behavior used by the integration framework: queue based calls, optional
 * request/reply, and publish-and-forget when receiveTimeout is less than or equal to one millisecond.</p>
 */
public class JmsInvokerProxyFactoryBean implements FactoryBean<Object>, InitializingBean {

    private ConnectionFactory connectionFactory;
    private MessageConverter messageConverter = new SimpleMessageConverter();
    private Class<?> serviceInterface;
    private String queueName;
    private long receiveTimeout = 10000L;
    private Object proxy;

    public void setConnectionFactory(ConnectionFactory connectionFactory) {
        this.connectionFactory = connectionFactory;
    }

    public ConnectionFactory getConnectionFactory() {
        return connectionFactory;
    }

    public void setMessageConverter(MessageConverter messageConverter) {
        this.messageConverter = messageConverter;
    }

    protected MessageConverter getMessageConverter() {
        return messageConverter;
    }

    public void setServiceInterface(Class<?> serviceInterface) {
        this.serviceInterface = serviceInterface;
    }

    protected Class<?> getServiceInterface() {
        return serviceInterface;
    }

    public void setQueueName(String queueName) {
        this.queueName = queueName;
    }

    protected String getQueueName() {
        return queueName;
    }

    public void setReceiveTimeout(long receiveTimeout) {
        this.receiveTimeout = receiveTimeout;
    }

    protected long getReceiveTimeout() {
        return receiveTimeout;
    }

    @Override
    public void afterPropertiesSet() {
        Assert.notNull(connectionFactory, "Property 'connectionFactory' is required");
        Assert.notNull(serviceInterface, "Property 'serviceInterface' is required");
        Assert.hasText(queueName, "Property 'queueName' is required");
        this.proxy = Proxy.newProxyInstance(
                serviceInterface.getClassLoader(),
                new Class<?>[] {serviceInterface},
                new JmsInvokerInvocationHandler());
    }

    @Override
    public Object getObject() {
        return proxy;
    }

    @Override
    public Class<?> getObjectType() {
        return serviceInterface;
    }

    @Override
    public boolean isSingleton() {
        return true;
    }

    protected RemoteInvocationResult executeRequest(RemoteInvocation invocation) throws JMSException {
        Connection connection = null;
        Session session = null;
        try {
            connection = connectionFactory.createConnection();
            session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
            Queue queue = resolveQueue(session);
            Message requestMessage = createRequestMessage(session, invocation);
            Message responseMessage = doExecuteRequest(session, queue, requestMessage);
            return extractInvocationResult(responseMessage);
        } finally {
            JmsUtils.closeSession(session);
            JmsUtils.closeConnection(connection);
        }
    }

    protected Queue resolveQueue(Session session) throws JMSException {
        return session.createQueue(queueName);
    }

    protected Message createRequestMessage(Session session, RemoteInvocation invocation) throws JMSException {
        return messageConverter.toMessage(invocation, session);
    }

    protected Message doExecuteRequest(Session session, Queue queue, Message requestMessage) throws JMSException {
        MessageProducer producer = null;
        TemporaryQueue responseQueue = null;
        MessageConsumer consumer = null;
        try {
            producer = session.createProducer(queue);
            if (receiveTimeout > 1L) {
                responseQueue = session.createTemporaryQueue();
                requestMessage.setJMSReplyTo(responseQueue);
                consumer = session.createConsumer(responseQueue);
            }
            producer.send(requestMessage);
            if (consumer == null) {
                return null;
            }
            return consumer.receive(receiveTimeout);
        } finally {
            JmsUtils.closeMessageConsumer(consumer);
            JmsUtils.closeMessageProducer(producer);
            deleteTemporaryDestination(responseQueue);
        }
    }

    protected RemoteInvocationResult extractInvocationResult(Message responseMessage) throws JMSException {
        if (responseMessage == null) {
            return new RemoteInvocationResult(null);
        }
        Object converted = messageConverter.fromMessage(responseMessage);
        if (converted instanceof RemoteInvocationResult result) {
            return result;
        }
        return new RemoteInvocationResult(converted);
    }

    private void deleteTemporaryDestination(Destination destination) throws JMSException {
        if (destination instanceof TemporaryQueue temporaryQueue) {
            temporaryQueue.delete();
        }
    }

    private class JmsInvokerInvocationHandler implements InvocationHandler {

        @Override
        public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
            if (method.getDeclaringClass() == Object.class) {
                return method.invoke(this, args);
            }
            RemoteInvocation invocation = new RemoteInvocation(method.getName(), method.getParameterTypes(), args);
            return executeRequest(invocation).recreate();
        }
    }
}
