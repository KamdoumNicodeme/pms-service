package org.springframework.jms.remoting;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;

import jakarta.jms.JMSException;
import jakarta.jms.Message;
import jakarta.jms.MessageListener;
import jakarta.jms.MessageProducer;
import jakarta.jms.Session;

import org.springframework.beans.factory.InitializingBean;
import org.springframework.jms.support.JmsUtils;
import org.springframework.jms.support.converter.MessageConverter;
import org.springframework.jms.support.converter.SimpleMessageConverter;
import org.springframework.remoting.support.RemoteInvocation;
import org.springframework.remoting.support.RemoteInvocationResult;
import org.springframework.util.Assert;

/**
 * Small compatibility implementation of the removed Spring JMS invoker service exporter.
 */
public class JmsInvokerServiceExporter implements MessageListener, InitializingBean {

    private Object service;
    private Class<?> serviceInterface;
    private MessageConverter messageConverter = new SimpleMessageConverter();

    public void setService(Object service) {
        this.service = service;
    }

    protected Object getService() {
        return service;
    }

    public void setServiceInterface(Class<?> serviceInterface) {
        this.serviceInterface = serviceInterface;
    }

    protected Class<?> getServiceInterface() {
        return serviceInterface;
    }

    public void setMessageConverter(MessageConverter messageConverter) {
        this.messageConverter = messageConverter;
    }

    protected MessageConverter getMessageConverter() {
        return messageConverter;
    }

    @Override
    public void afterPropertiesSet() {
        if (service != null) {
            Assert.notNull(serviceInterface, "Property 'serviceInterface' is required when 'service' is set");
        }
    }

    @Override
    public void onMessage(Message message) {
        throw new UnsupportedOperationException("A JMS Session is required to process invoker messages");
    }

    public void onMessage(Message requestMessage, Session session) throws JMSException {
        RemoteInvocation invocation = readRemoteInvocation(requestMessage);
        RemoteInvocationResult result = invokeAndCreateResult(invocation, getProxyForService());
        if (requestMessage.getJMSReplyTo() != null) {
            MessageProducer producer = null;
            try {
                producer = session.createProducer(requestMessage.getJMSReplyTo());
                producer.send(messageConverter.toMessage(result, session));
            } finally {
                JmsUtils.closeMessageProducer(producer);
            }
        }
    }

    protected RemoteInvocation readRemoteInvocation(Message requestMessage) throws JMSException {
        Object converted = messageConverter.fromMessage(requestMessage);
        if (!(converted instanceof RemoteInvocation invocation)) {
            throw new jakarta.jms.IllegalStateException("Message does not contain a RemoteInvocation");
        }
        return invocation;
    }

    protected RemoteInvocationResult invokeAndCreateResult(RemoteInvocation invocation, Object targetObject) {
        try {
            Method method = invocation.getMethod(serviceInterface);
            Object value = method.invoke(targetObject, invocation.getArguments());
            return new RemoteInvocationResult(value);
        } catch (InvocationTargetException ex) {
            return new RemoteInvocationResult(ex.getTargetException());
        } catch (Throwable ex) {
            return new RemoteInvocationResult(ex);
        }
    }

    protected Object getProxyForService() {
        if (service == null || serviceInterface == null) {
            return service;
        }
        return Proxy.newProxyInstance(
                serviceInterface.getClassLoader(),
                new Class<?>[] {serviceInterface},
                (proxy, method, args) -> method.invoke(service, args));
    }
}
