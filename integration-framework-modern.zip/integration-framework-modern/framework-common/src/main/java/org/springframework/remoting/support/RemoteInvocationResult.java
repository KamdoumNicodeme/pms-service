package org.springframework.remoting.support;

import java.io.Serializable;

/**
 * Compatibility replacement for the legacy Spring remoting result type removed from Spring Framework 6.
 */
public class RemoteInvocationResult implements Serializable {

    private static final long serialVersionUID = 2138555143707773549L;

    private Object value;
    private Throwable exception;

    public RemoteInvocationResult() {
    }

    public RemoteInvocationResult(Object value) {
        this.value = value;
    }

    public RemoteInvocationResult(Throwable exception) {
        this.exception = exception;
    }

    public Object getValue() {
        return value;
    }

    public void setValue(Object value) {
        this.value = value;
    }

    public Throwable getException() {
        return exception;
    }

    public void setException(Throwable exception) {
        this.exception = exception;
    }

    public boolean hasException() {
        return exception != null;
    }

    public Object recreate() throws Throwable {
        if (exception != null) {
            throw exception;
        }
        return value;
    }
}
