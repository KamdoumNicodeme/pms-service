package com.lombard.integration.fwk.utils;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.UUID;

import com.lombard.cdm.ActivityContext;
import com.lombard.cdm.ActivityHandler;
import com.lombard.cdm.ApplicationContext;
import com.lombard.cdm.CorrelationHandler;
import com.lombard.cdm.IdType;
import com.lombard.cdm.StatusType;
import com.lombard.csm.Notification;

public class AHB {

    interface OnCorrelation {

        OnCorrelation by(IdType name);

        OnActivity in(IdType name);
    }

    interface OnError {
        OnError on(Notification notification);

        OnError where(String destination);

        OnCorrelation raise(Throwable throwable);
    }

    interface OnActivity {

        OnActivity when(String activity);

        Build props(Prop prop, Prop... props);
    }

    interface Build {
        ActivityHandler build();
    }

    public static OnCorrelation notified() {
        return null;
    }

    public static OnCorrelation start() {
        return new OnCorrelationImpl(StatusType.PROCESS_STARTED);
    }

    public static OnCorrelation stop() {
        return null;
    }

    public static OnError fail() {
        return null;
    }

    static class Prop {

        private final String key;
        private final String value;

        private Prop(final String key, final String value) {
            this.key = key;
            this.value = value;
        }

        public String getKey() {
            return key;
        }

        public String getValue() {
            return value;
        }

        public static Prop create(String key, String value) {
            return new Prop(key, value);
        }

        public static Prop create(String key, int value) {
            return new Prop(key, Integer.toString(value));
        }

        public static Prop create(String key, long value) {
            return new Prop(key, Long.toString(value));
        }

        public static Prop create(String key, float value) {
            return new Prop(key, Float.toString(value));
        }

        public static Prop create(String key, double value) {
            return new Prop(key, Double.toString(value));
        }

        public static Prop create(String key, boolean value) {
            return new Prop(key, Boolean.toString(value));
        }

        public static Prop create(String key, Object value) {
            return new Prop(key, value.toString());
        }
    }

    public static void main(String[] args) {
        AHB.fail().on(new Notification()).where("").raise(new RuntimeException()).in(IdType.BIIM).when("activity")
                .props(Prop.create("", "")).build();
    }

    private static class OnCorrelationImpl implements OnCorrelation {

        private ActivityHandler activityHandler = new ActivityHandler();

        public OnCorrelationImpl(StatusType statusType) {
            CorrelationHandler correlationHandler = new CorrelationHandler();
            activityHandler.setCorrelation(correlationHandler);

            correlationHandler.setId(UUID.randomUUID().toString());

            ApplicationContext initiator = new ApplicationContext();
            correlationHandler.setInitiator(initiator);

            try {
                initiator.setNode(InetAddress.getLocalHost().getHostName());
            } catch (UnknownHostException e) {
                // ignored
            }

            ActivityContext activityContext = new ActivityContext();
            activityHandler.setActivityContext(activityContext);

            activityContext.setActivityStatus(statusType);

            ApplicationContext application = new ApplicationContext();
            activityHandler.setApplication(application);

            application.setNode(initiator.getNode());
        }

        public OnCorrelation by(IdType name) {
            activityHandler.getCorrelation().getInitiator().setName(name);
            return this;
        }

        public OnActivity in(IdType name) {
            activityHandler.getApplication().setName(name);
            return null;
        }
    }
}
