package com.lombard.integration.ntf.properties.transformer;

import java.lang.reflect.ParameterizedType;


/**
 * A basic businessKeyValueTransformer abstraction
 * 
 * @author JZAPADKA
 * 
 * @param <T>
 */
public abstract class AbstractBusinessKeyValueTransformer< T > implements BusinessKeyValueTransformer<T> {

    private Class<T> classType;

    /**
     * Get the class type from the generic superclass
     */
    @SuppressWarnings("unchecked")
    public AbstractBusinessKeyValueTransformer() {
        ParameterizedType genericSuperclass = (ParameterizedType) getClass().getGenericSuperclass();
        this.classType = (Class<T>) genericSuperclass.getActualTypeArguments()[0];
    }

    /**
     * Return the class type
     */
    public final Class<T> getClassType() {
        return classType;
    }

}
