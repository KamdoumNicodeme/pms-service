package com.lombard.integration.fwk.schema;

/**
 * Resolver used to retrieve the root element name for a given CDM / CSM type.
 */
public interface ElementNameResolver {

	/**
	 * Return the XML element name for a given CDM / CSM type.
	 * 
	 * @param cdmOrCsmType the CDM / CSM type.
	 * @return the element name for the given CDM / CSM type.
	 */
	String resolveElementName(Class<?> cdmOrCsmType);

}
