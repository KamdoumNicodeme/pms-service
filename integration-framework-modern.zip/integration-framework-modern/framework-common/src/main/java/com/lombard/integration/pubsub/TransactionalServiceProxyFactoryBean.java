package com.lombard.integration.pubsub;

import jakarta.jms.Connection;
import jakarta.jms.JMSException;
import jakarta.jms.Message;
import jakarta.jms.MessageProducer;
import jakarta.jms.Queue;
import jakarta.jms.Session;

import org.springframework.jms.connection.ConnectionFactoryUtils;
import org.springframework.jms.connection.JmsResourceHolder;
import org.springframework.jms.remoting.JmsInvokerProxyFactoryBean;
import org.springframework.jms.support.JmsUtils;
import org.springframework.remoting.support.RemoteInvocation;
import org.springframework.remoting.support.RemoteInvocationResult;

public class TransactionalServiceProxyFactoryBean extends JmsInvokerProxyFactoryBean {

    @Override
    protected RemoteInvocationResult executeRequest(RemoteInvocation invocation) throws JMSException {

        Connection conToClose = null;
        Session sessionToClose = null;

        try {
            Session sessionToUse =
                    ConnectionFactoryUtils.doGetTransactionalSession(getConnectionFactory(), new JmsTemplateResourceFactory(), false);

            if (sessionToUse == null) {
                conToClose = getConnectionFactory().createConnection();
                sessionToClose = conToClose.createSession(true, 1);
                sessionToUse = sessionToClose;
            }

            final Queue queue = resolveQueue(sessionToUse);

            final MessageProducer producer = sessionToUse.createProducer(queue);
            producer.setDisableMessageID(true);
            producer.setDisableMessageTimestamp(true);

            try {
                final Message requestMessage = createRequestMessage(sessionToUse, invocation);
                final Message responseMessage = doExecuteRequest(sessionToUse, queue, requestMessage);

                // Check commit - avoid commit call within a JTA transaction.
                if (sessionToUse.getTransacted() && isSessionLocallyTransacted(sessionToUse)) {
                    // Transacted session created by this template -> commit.
                    JmsUtils.commitIfNecessary(sessionToUse);
                }

                return extractInvocationResult(responseMessage);
            } finally {
                JmsUtils.closeMessageProducer(producer);
            }

        } catch (JMSException ex) {
            throw ex;
        } finally {
            JmsUtils.closeSession(sessionToClose);
            ConnectionFactoryUtils.releaseConnection(conToClose, getConnectionFactory(), false);
        }
    }

    protected boolean isSessionLocallyTransacted(Session session) {

        return !ConnectionFactoryUtils.isSessionTransactional(session, getConnectionFactory());
    }

    /**
     * ResourceFactory implementation that delegates to this template's protected callback methods.
     */
    private class JmsTemplateResourceFactory implements ConnectionFactoryUtils.ResourceFactory {

        public Connection getConnection(JmsResourceHolder holder) {

            return holder.getConnection();
        }

        public Session getSession(JmsResourceHolder holder) {

            return holder.getSession();
        }

        public Connection createConnection() throws JMSException {

            return getConnectionFactory().createConnection();
        }

        public Session createSession(Connection con) throws JMSException {

            return con.createSession(true, 1);
        }

        public boolean isSynchedLocalTransactionAllowed() {

            return true;
        }
    }

}
