package com.lombard.integration.fwk.cxf.binders;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.apache.commons.lang.time.DateFormatUtils;
import org.apache.commons.lang.time.FastDateFormat;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public final class DataTypeBinder {
	
	private static final Log LOG = LogFactory.getLog(DataTypeBinder.class);

	// Use DateFormatUtils to get thread-safe format
	private static FastDateFormat dateTime = DateFormatUtils.ISO_DATETIME_FORMAT; 
	private static FastDateFormat date = DateFormatUtils.ISO_DATE_FORMAT; 
	

	private DataTypeBinder() {
		
	}
	
    public static Calendar unmarshalDate(String value) {
    	if (value == null || value.length() == 0) {
    		return null;
    	}
    	Date d = null;
    	
    	try {
    		SimpleDateFormat format = new SimpleDateFormat(date.getPattern());
    		d = format.parse(value);
    	} catch (ParseException e) {
    		LOG.error("Unable to parse date " + value, e);
    		
    		return null;
		} 
    	Calendar c = Calendar.getInstance();
    	c.setTime(d);
    	return c;
    }

    public static  String marshalDate(Calendar value) {
        if (value == null) {
            return null;
        }
        
        return date.format(value.getTime());
    }	
	
	
    public static Calendar unmarshalDateTime(String value) {
    	if (value == null || value.length() == 0) {
    		return null;
    	}
    	Date d = null;
    	
    	try {
    		SimpleDateFormat format = new SimpleDateFormat(dateTime.getPattern());
    		d = format.parse(value);
    	} catch (ParseException e) {
    		LOG.error("Unable to parse date " + value, e);
    		
    		return null;
		} 
    	Calendar c = Calendar.getInstance();
    	c.setTime(d);
    	return c;
    }

    public static  String marshalDateTime(Calendar value) {
        if (value == null) {
            return null;
        }
        
        return dateTime.format(value.getTime());
    }	
	
    public static  BigDecimal unmarshalBigDecimal(String value) {
        return new BigDecimal(value);
    }

    public static String marshalBigDecimal(BigDecimal value) {
        if (value == null) {
            return null;
        }
        
        return value.toPlainString();
    }

}
