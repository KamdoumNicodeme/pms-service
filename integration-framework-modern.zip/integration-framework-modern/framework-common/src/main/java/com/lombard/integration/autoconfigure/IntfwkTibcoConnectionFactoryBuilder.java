package com.lombard.integration.autoconfigure;

import jakarta.jms.ConnectionFactory;

import org.springframework.beans.BeanWrapperImpl;
import org.springframework.core.env.Environment;
import org.springframework.util.StringUtils;

final class IntfwkTibcoConnectionFactoryBuilder {

    private IntfwkTibcoConnectionFactoryBuilder() {
    }

    static ConnectionFactory queueConnectionFactory(
            Environment environment,
            IntfwkProperties properties,
            String legacyPrefix,
            IntfwkProperties.Endpoint endpoint) {
        return connectionFactory(
                "com.tibco.tibjms.TibjmsQueueConnectionFactory",
                environment,
                properties,
                legacyPrefix,
                endpoint);
    }

    static ConnectionFactory xaQueueConnectionFactory(
            Environment environment,
            IntfwkProperties properties,
            String legacyPrefix,
            IntfwkProperties.Endpoint endpoint) {
        return connectionFactory(
                "com.tibco.tibjms.TibjmsXAQueueConnectionFactory",
                environment,
                properties,
                legacyPrefix,
                endpoint);
    }

    private static ConnectionFactory connectionFactory(
            String className,
            Environment environment,
            IntfwkProperties properties,
            String legacyPrefix,
            IntfwkProperties.Endpoint endpoint) {
        try {
            Object factory = Class.forName(className).getDeclaredConstructor().newInstance();
            BeanWrapperImpl wrapper = new BeanWrapperImpl(factory);

            IntfwkProperties.Attempts attempts = properties.getJms().getAttempts();
            set(wrapper, "connAttemptCount", attempts.getConnAttemptCount());
            set(wrapper, "connAttemptDelay", attempts.getConnAttemptDelay());
            set(wrapper, "connAttemptTimeout", attempts.getConnAttemptTimeout());
            set(wrapper, "reconnAttemptCount", attempts.getReconnAttemptCount());
            set(wrapper, "reconnAttemptDelay", attempts.getReconnAttemptDelay());
            set(wrapper, "reconnAttemptTimeout", attempts.getReconnAttemptTimeout());

            set(wrapper, "serverUrl", property(environment, endpoint.getUrl(), legacyPrefix + ".url"));
            set(wrapper, "userName", property(environment, endpoint.getUsername(), legacyPrefix + ".username"));
            set(wrapper, "userPassword", property(environment, endpoint.getPassword(), legacyPrefix + ".password"));

            return (ConnectionFactory) factory;
        } catch (ReflectiveOperationException e) {
            throw new IllegalStateException("Cannot create TIBCO connection factory " + className, e);
        }
    }

    private static void set(BeanWrapperImpl wrapper, String property, Object value) {
        if (wrapper.isWritableProperty(property) && value != null) {
            wrapper.setPropertyValue(property, value);
        }
    }

    private static String property(Environment environment, String modernValue, String legacyKey) {
        if (StringUtils.hasText(modernValue)) {
            return modernValue;
        }
        return environment.getProperty(legacyKey);
    }
}
