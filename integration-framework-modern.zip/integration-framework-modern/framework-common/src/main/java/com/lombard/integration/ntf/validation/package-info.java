/**
 * Contains validations facilities for {@link com.lombard.csm.Notification} and {@link com.lombard.csm.BusinessContext}.
 * 
 * <img src="http://yuml.me/bb22a17d" >
 */
package com.lombard.integration.ntf.validation;