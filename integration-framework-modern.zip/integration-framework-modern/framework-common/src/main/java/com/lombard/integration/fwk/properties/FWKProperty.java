package com.lombard.integration.fwk.properties;

public enum FWKProperty {

	FWKUser,
	FWKRequestTime,
	FWKResponseTime,
	FWKMaxResults;

}
