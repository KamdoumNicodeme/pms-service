package com.lombard.integration.fwk.properties;

import java.util.HashMap;
import java.util.Map;

@Deprecated
public final class FWKPropertiesManagement {

    public static final String USER_PROPERTY = "FWKUser";

    private static final ThreadLocal<Map<FWKProperty, String>> localProperties =
            ThreadLocal.withInitial(HashMap::new);

    private FWKPropertiesManagement() {

    }

    public static Map<FWKProperty, String> getProperties() {
        Map<FWKProperty, String> properties = localProperties.get();
        if (properties == null) {
            properties = new HashMap<>();
            localProperties.set(properties);
        }
        return properties;
    }

    public static void setProperties(Map<FWKProperty, String> aProperties) {
        localProperties.set(aProperties);
    }

    public static String getProperty(FWKProperty aKey) {
        return getProperties().get(aKey);
    }

    public static void putProperty(FWKProperty aKey, String aValue) {
        getProperties().put(aKey, aValue);
    }
}
