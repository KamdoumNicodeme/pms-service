package com.lombard.integration.fwk.schema;

/**
 * Exception used for element name resolving problems.
 */
public class ElementNameResolverException extends RuntimeException {

	private static final long serialVersionUID = 2682840460794065604L;

	/**
	 * Create an element name resolver exception with the given error message.
	 * 
	 * @param message the error message.
	 */
	public ElementNameResolverException(String message) {
		super(message);
	}
	
	/**
	 * Create an element name resolver exception with the given error message
	 * and cause.
	 * 
	 * @param message the error message.
	 * @param cause the cause.
	 */
	public ElementNameResolverException(String message, Throwable cause) {
		super(message, cause);
	}

}
