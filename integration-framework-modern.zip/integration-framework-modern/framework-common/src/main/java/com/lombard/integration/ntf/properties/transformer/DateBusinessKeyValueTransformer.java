package com.lombard.integration.ntf.properties.transformer;

import java.text.DateFormat;
import java.util.Date;


/**
 * 
 * @author JZAPADKA
 * 
 */
public class DateBusinessKeyValueTransformer extends AbstractBusinessKeyValueTransformer < Date > {

    private DateFormat dateFormat;

    /**
     * @return the dateFormatter
     */
    public DateFormat getDateFormat() {
        return dateFormat;
    }

    /**
     * @param dateFormatter
     *            the dateFormatter to set
     */
    public void setDateFormat(DateFormat dateFormat) {
        this.dateFormat = dateFormat;
    }

    /**
     * {@inheritDoc}
     */
    public < O extends Date > String transform(O obj) {
        return getDateFormat().format(obj);
    }
}
