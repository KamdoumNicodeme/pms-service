package com.lombard.integration.ntf.validation;

import jakarta.jms.Message;

import com.lombard.integration.ntf.NotificationException;

/**
 * A basic notification validator abstraction
 * 
 * @author wvandenberghe
 * 
 */
public abstract class AbstractNotificationValidator implements NotificationValidator {

    private boolean publicationValidate;

    private boolean consumptionValidate;

    /**
     * Get flag to validate notification when publishing
     * 
     * @return
     */
    public boolean isPublicationValidate() {
        return publicationValidate;
    }

    /**
     * Set flag to validate notification when publishing.
     * 
     * @param publicationValidate
     */
    public void setPublicationValidate(boolean publicationValidate) {
        this.publicationValidate = publicationValidate;
    }

    /**
     * Get flag to validate notification when consuming
     * 
     * @return
     */
    public boolean isConsumptionValidate() {
        return consumptionValidate;
    }

    /**
     * Set flag to validate notification when consuming.
     * 
     * @param consumptionValidate
     */
    public void setConsumptionValidate(boolean consumptionValidate) {
        this.consumptionValidate = consumptionValidate;
    }

    /**
     * {@inheritDoc}
     */
    public boolean handleOnPublish(Message message) throws NotificationException {
        if (isPublicationValidate()) {
            return doHandleOnPublish(message);
        }

        return true;
    }

    /**
     * Execute handler on notification publication.
     * 
     * @param message
     * @return
     * @throws NotificationException
     */
    protected abstract boolean doHandleOnPublish(Message message) throws NotificationException;

    /**
     * {@inheritDoc}
     */
    public boolean handleOnConsume(Message message) throws NotificationException {
        if (isConsumptionValidate()) {
            return doHandleOnConsume(message);
        }

        return true;
    }

    /**
     * Execute handler when receiving message.
     * 
     * @param message
     * @return
     * @throws NotificationException
     */
    protected abstract boolean doHandleOnConsume(Message message) throws NotificationException;
}
