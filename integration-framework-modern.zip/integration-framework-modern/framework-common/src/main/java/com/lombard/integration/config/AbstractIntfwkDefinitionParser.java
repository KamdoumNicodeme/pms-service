package com.lombard.integration.config;

import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.beans.factory.support.BeanDefinitionBuilder;
import org.springframework.beans.factory.support.BeanDefinitionRegistry;
import org.springframework.beans.factory.xml.AbstractBeanDefinitionParser;
import org.springframework.beans.factory.xml.ParserContext;

import com.lombard.integration.jaxb.CollectionJaxBListener;
import com.lombard.integration.jaxb.JaxbMarshallerFactoryBean;

/**
 * Describe a generic definition parser for Integration Framework namespace elements.
 * 
 * @author wvandenberghe
 * 
 */
public abstract class AbstractIntfwkDefinitionParser extends AbstractBeanDefinitionParser {

    /**
     * 
     */
    protected static final String CONCURRENCY_ATT = "concurrency";

    /**
     * 
     */
    protected static final String CONNECTION_FACTORY_ATT = "connection-factory";

    /**
     * 
     */
    protected static final String DESTINATION_ATT = "destination";

    /**
     * 
     */
    protected static final String ID_TYPE_ATT = "id-type";

    /**
     * 
     */
    protected static final String CLASS_ATT = "class";

    /**
     * 
     */
    protected static final String TIMEOUT_ATT = "timeout";

    /**
     * 
     */
    protected static final String VALIDATE_ATT = "validate";

    /**
     * 
     */
    protected static final String SCHEMAS_ATT = "schemas";

    /**
     * 
     */
    protected static final String UNMARSHALLER_ATT = "unmarshaller";

    /**
     * 
     */
    protected static final String MARSHALLER_ATT = "marshaller";

    public static final String DEFAULT_MODEL_MARSHALLER = "defaultModelMarshaller";

    /**
     * Default constructor.
     */
    public AbstractIntfwkDefinitionParser() {
        super();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    protected boolean shouldGenerateIdAsFallback() {
        return true;
    }

    protected String getJaxbMarshaller(ParserContext parserContext) {
        BeanDefinitionRegistry registry = parserContext.getRegistry();

        if (!registry.isBeanNameInUse(DEFAULT_MODEL_MARSHALLER)) {
            BeanDefinitionBuilder builder =
                    BeanDefinitionBuilder.genericBeanDefinition(JaxbMarshallerFactoryBean.class);

            BeanDefinition jaxbListener = getJaxbListener();
            builder.addPropertyValue("marshallerListener", jaxbListener);

            registry.registerBeanDefinition(DEFAULT_MODEL_MARSHALLER, builder.getBeanDefinition());
        }

        return DEFAULT_MODEL_MARSHALLER;
    }

    protected BeanDefinition getJaxbListener() {
        BeanDefinitionBuilder builder = BeanDefinitionBuilder.genericBeanDefinition(CollectionJaxBListener.class);

        return builder.getBeanDefinition();
    }

    protected abstract String getDefaultConnectionFactoryReference();

}
