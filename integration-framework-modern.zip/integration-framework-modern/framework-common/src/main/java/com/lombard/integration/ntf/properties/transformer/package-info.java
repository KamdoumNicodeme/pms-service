/**
 * Contains facilities to deal with {@link com.lombard.integration.fwk.notification.annotation.BusinessKey} type transformation.
 * 
 * <img src="http://yuml.me/42404a88">
 */
package com.lombard.integration.ntf.properties.transformer;