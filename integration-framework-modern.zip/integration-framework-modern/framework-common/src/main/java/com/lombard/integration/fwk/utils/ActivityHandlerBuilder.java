package com.lombard.integration.fwk.utils;

import static com.lombard.cdm.ErrorLevelType.ERROR;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.lombard.cdm.ActivityContext;
import com.lombard.cdm.ActivityHandler;
import com.lombard.cdm.ApplicationContext;
import com.lombard.cdm.CorrelationHandler;
import com.lombard.cdm.ErrorHandler;
import com.lombard.cdm.IdType;
import com.lombard.cdm.KeyValues;
import com.lombard.cdm.KeyValues.KeyValue;
import com.lombard.cdm.ReplayContext;
import com.lombard.cdm.StatusType;

/**
 * 
 * @author wvandenberghe
 * 
 */
public final class ActivityHandlerBuilder {

    private final ActivityHandler activityHandler;

    private CorrelationHandlerBuilder correlationHandlerBuilder;

    /**
     * 
     */
    private ActivityHandlerBuilder() {
        correlationHandlerBuilder = CorrelationHandlerBuilder.newBuilder();
        activityHandler = new ActivityHandler();

        final ActivityContext activityContext = new ActivityContext();
        activityHandler.setActivityContext(activityContext);
    }

    /**
     * 
     * @param correlationHandler
     */
    private ActivityHandlerBuilder(CorrelationHandler correlationHandler) {
        this();

        if (correlationHandler != null) {
            correlationHandlerBuilder = CorrelationHandlerBuilder.from(correlationHandler);
            if (correlationHandler != null && correlationHandler.getInitiator() != null
                    && correlationHandler.getInitiator().getName() != null) {
                applicationName(correlationHandler.getInitiator().getName());
            }
        }
    }

    /**
     * 
     * @return
     */
    public static ActivityHandlerBuilder newBuilder() {
        return new ActivityHandlerBuilder();
    }

    /**
     * 
     * @param correlationHandler
     * @return
     */
    public static ActivityHandlerBuilder from(CorrelationHandler correlationHandler) {
        return new ActivityHandlerBuilder(correlationHandler);
    }

    /**
     * 
     * @param idType
     * @return
     */
    public ActivityHandlerBuilder initiatorName(IdType idType) {
        if (idType == null) {
            throw new IllegalArgumentException("Argument 'idType' cannot be null or empty");
        }

        correlationHandlerBuilder.name(idType);

        return this;
    }

    /**
     * 
     * @param node
     * @return
     */
    public ActivityHandlerBuilder initiatorNode(String node) {
        correlationHandlerBuilder.node(node);

        return this;
    }

    /**
     * 
     * @param idType
     * @return
     */
    public ActivityHandlerBuilder applicationName(IdType idType) {
        if (idType == null) {
            throw new IllegalArgumentException("Argument 'idType' cannot be null or empty");
        }

        ApplicationContext applicationContext = new ApplicationContext();
        activityHandler.setApplication(applicationContext);
        applicationContext.setName(idType);

        return this;
    }

    /**
     * 
     * @param activityName
     * @return
     */
    public ActivityHandlerBuilder activityName(String activityName) {
        if (activityName == null || activityName.trim().length() == 0) {
            throw new IllegalArgumentException("Argument 'activityName' cannot be null or empty");
        }

        final ActivityContext activityContext = activityHandler.getActivityContext();
        activityContext.setActivityName(activityName);

        return this;
    }

    /**
     * 
     * @param activityStatus
     * @return
     */
    public ActivityHandlerBuilder activityStatus(StatusType activityStatus) {
        if (activityStatus == null) {
            throw new IllegalArgumentException("Argument 'activityStatus' cannot be null");
        }

        final ActivityContext activityContext = activityHandler.getActivityContext();
        activityContext.setActivityStatus(activityStatus);

        return this;
    }

    /**
     * 
     * @param description
     * @return
     */
    public ActivityHandlerBuilder description(String description) {
        final ActivityContext activityContext = activityHandler.getActivityContext();
        activityContext.setDescription(description);

        return this;
    }

    /**
     * Get the cause of the provided exception, create an {@link ErrorHandler} object and fill it.
     * <p>
     * Error handler is filled as following:
     * <ul>
     * <li><u>message:</u> cause exception message</li>
     * <li><u>stack trace:</u> cause exception stack trace</li>
     * <li><u>category:</u> 'Technical'</li>
     * <li><u>level:</u> 'ERROR'</li>
     * </ul>
     * 
     * ActivityStatus is set to {@link StatusType#PROCESS_FAILED}
     * 
     * @param cause
     * @return this
     */
    public ActivityHandlerBuilder exception(Throwable cause) {
        if (cause == null) {
            throw new IllegalArgumentException("Argument 'cause' cannot be null");
        }

        if (cause.getCause() == null || cause.getCause() == cause) {
            final ActivityContext activityContext = activityHandler.getActivityContext();
            ErrorHandler errorHandler = null;
            if (activityContext.getError() == null) {
                errorHandler = new ErrorHandler();
                activityContext.setError(errorHandler);
            } else {
                errorHandler = activityContext.getError();
            }

            activityHandler.getActivityContext().setError(errorHandler);

            errorHandler.setMessage("Exception [" + cause.getClass().getSimpleName() + "] raised");
            StringWriter writer = new StringWriter();
            writer.append(cause.getMessage());
            writer.append("\n");
            cause.printStackTrace(new PrintWriter(writer, true));

            errorHandler.setStackTrace(writer.toString());

            errorHandler.setCategory("Technical");
            errorHandler.setHospitalRouted(true);
            errorHandler.setLevel(ERROR);
            activityStatus(StatusType.PROCESS_FAILED);

            return this;
        } else {
            return this.exception(cause.getCause());
        }
    }

    public ActivityHandlerBuilder context(String context) {
        final ActivityContext activityContext = activityHandler.getActivityContext();
        ErrorHandler errorHandler = null;
        if (activityContext.getError() == null) {
            errorHandler = new ErrorHandler();
            activityContext.setError(errorHandler);
        } else {
            errorHandler = activityContext.getError();
        }

        errorHandler.setContext(context);

        return this;
    }

    /**
     * Set the queue name to the {@link ReplayContext}
     * 
     * @param queueName
     * @return this
     */
    public ActivityHandlerBuilder queueName(String queueName) {
        if (queueName == null || queueName.trim().length() == 0) {
            throw new IllegalArgumentException("Argument 'queueName' cannot be null or empty");
        }

        ReplayContext replayContext = null;
        if (activityHandler.getReplayContext() == null) {
            replayContext = new ReplayContext();
            activityHandler.setReplayContext(replayContext);
        } else {
            replayContext = activityHandler.getReplayContext();
        }

        replayContext.setQueueName(queueName);

        return this;
    }

    public ActivityHandlerBuilder replayProperty(String key, String value) {
        if (key == null || key.trim().length() == 0) {
            throw new IllegalArgumentException("Argument 'key' cannot be null or empty");
        }

        if (value == null || value.trim().length() == 0) {
            throw new IllegalArgumentException("Argument 'value' cannot be null or empty");
        }

        ReplayContext replayContext = null;
        if (activityHandler.getReplayContext() == null) {
            replayContext = new ReplayContext();
            activityHandler.setReplayContext(replayContext);
        } else {
            replayContext = activityHandler.getReplayContext();
        }

        List<KeyValues> headerKeyValues = replayContext.getHeaderKeyValue();
        if (headerKeyValues.isEmpty()) {
            KeyValues keyValues = new KeyValues();
            headerKeyValues.add(keyValues);
        }

        KeyValue keyValue = new KeyValue();
        keyValue.setKey(key);
        keyValue.setValue(value);
        headerKeyValues.get(0).getKeyValue().add(keyValue);

        return this;
    }

    public ActivityHandlerBuilder property(String key, String value) {
        if (key == null || key.trim().length() == 0) {
            throw new IllegalArgumentException("Argument 'key' cannot be null or empty");
        }

        if (value == null || value.trim().length() == 0) {
            throw new IllegalArgumentException("Argument 'value' cannot be null or empty");
        }

        final ActivityContext activityContext = activityHandler.getActivityContext();

        if (activityContext.getProperties() == null) {
            activityContext.setProperties(new HashMap<>());
        }
        Map<String, String> properties = activityContext.getProperties();
        properties.put(key, value);

        return this;
    }

    /**
     * 
     * @return
     */
    public ActivityHandler build() {
        activityHandler.setCorrelation(correlationHandlerBuilder.build());

        if (activityHandler.getActivityContext() == null) {
            throw new IllegalStateException("Fields 'activityName', 'activityStatus' and 'properties' are mandatory");
        }

        final ActivityContext activityContext = activityHandler.getActivityContext();

        final String activityName = activityContext.getActivityName();
        if (activityName == null || activityName.trim().length() == 0) {
            throw new IllegalStateException("Field 'activityName' is mandatory");
        }

        if (activityContext.getActivityStatus() == null) {
            throw new IllegalStateException("Field 'activityStatus' is mandatory");
        }

        if (activityHandler.getApplication() == null || activityHandler.getApplication().getName() == null) {
            throw new IllegalStateException("Field 'applicationName' is mandatory");
        }

        final Calendar now = Calendar.getInstance();
        now.setTimeInMillis(System.currentTimeMillis());
        activityHandler.setTimestamp(now);

        return activityHandler;
    }
}
