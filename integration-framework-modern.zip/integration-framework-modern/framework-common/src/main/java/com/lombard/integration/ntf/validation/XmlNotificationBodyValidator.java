package com.lombard.integration.ntf.validation;

import jakarta.jms.JMSException;
import jakarta.jms.Message;
import jakarta.jms.TextMessage;
import javax.xml.transform.Source;

import org.springframework.util.StringUtils;
import org.springframework.xml.transform.StringSource;

import com.lombard.integration.ntf.NotificationMessagingException;

/**
 * Validator based on the notification body as XML.
 * 
 * @author wvandenberghe
 * 
 */
public class XmlNotificationBodyValidator extends AbstractXmlNotificationValidator {

    /**
     * {@inheritDoc}
     */
    protected Source getValidationSource(Message message) {
        if (message instanceof TextMessage textMessage) {

            try {
                final String text = textMessage.getText();
                if (StringUtils.hasLength(text)) {
                    return new StringSource(text);
                }
            } catch (JMSException e) {
                throw new NotificationMessagingException("Cannot read message content", e);
            }
        }

        throw new NotificationMessagingException(
                "Cannot get message content. Check if message is a text message and if it is not empty");
    }

}
