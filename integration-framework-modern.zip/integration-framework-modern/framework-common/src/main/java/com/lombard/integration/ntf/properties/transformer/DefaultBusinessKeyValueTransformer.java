package com.lombard.integration.ntf.properties.transformer;


/**
 * 
 * @author JZAPADKA
 * 
 */
public class DefaultBusinessKeyValueTransformer extends AbstractBusinessKeyValueTransformer < Object > {

    /**
     * {@inheritDoc}
     */
    public < O extends Object > String transform(O obj) {
        return obj.toString();
    }

}
