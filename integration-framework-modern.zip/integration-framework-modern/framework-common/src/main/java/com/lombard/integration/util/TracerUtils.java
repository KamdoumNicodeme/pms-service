package com.lombard.integration.util;

import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;

import com.lombard.integration.tntf.trace.TraceServiceImpl;
import com.lombard.integration.tntf.trace.TraceServiceHolder;
import com.lombard.integration.tntf.trace.TraceService;

/**
 * Utility class to deal with {@link TraceService}.
 * 
 * @author wvandenberghe
 * 
 */
public final class TracerUtils {

    private TracerUtils() {
        // nothing to do
    }

    /**
     * Get the trace service
     * 
     * @param applicationContext
     * @return trace service from this applicationContext or from {@link TraceServiceHolder}
     * @see TraceServiceImpl
     */
    public static TraceService getTracer(ApplicationContext applicationContext) {
        try {
            return applicationContext.getBean(TraceService.class);
        } catch (BeansException e) {
            try {
                return TraceServiceHolder.getInstance(applicationContext).getObject();
            } catch (Exception e1) {
                return null;
            }
        }
    }
}
