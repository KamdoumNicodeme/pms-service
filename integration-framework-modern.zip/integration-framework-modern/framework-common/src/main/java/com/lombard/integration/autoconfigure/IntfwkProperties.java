package com.lombard.integration.autoconfigure;

import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties(prefix = "intfwk")
public class IntfwkProperties {

    private final Client client = new Client();

    private final Jms jms = new Jms();

    private final Security security = new Security();

    public Client getClient() {
        return client;
    }

    public Jms getJms() {
        return jms;
    }

    public Security getSecurity() {
        return security;
    }

    public static class Client {

        private String id;

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }
    }

    public static class Security {

        private boolean enabled;

        private String keystoreConfigFilePath;

        public boolean isEnabled() {
            return enabled;
        }

        public void setEnabled(boolean enabled) {
            this.enabled = enabled;
        }

        public String getKeystoreConfigFilePath() {
            return keystoreConfigFilePath;
        }

        public void setKeystoreConfigFilePath(String keystoreConfigFilePath) {
            this.keystoreConfigFilePath = keystoreConfigFilePath;
        }
    }

    public static class Jms {

        private final Attempts attempts = new Attempts();

        private final Endpoint connection = new Endpoint();

        private final Endpoint legacy = new Endpoint();

        private final Endpoint technical = new Endpoint();

        private final Endpoint service = new Endpoint();

        private final Endpoint notification = new Endpoint();

        private final Xa xa = new Xa();

        public Attempts getAttempts() {
            return attempts;
        }

        public Endpoint getConnection() {
            return connection;
        }

        public Endpoint getLegacy() {
            return legacy;
        }

        public Endpoint getTechnical() {
            return technical;
        }

        public Endpoint getService() {
            return service;
        }

        public Endpoint getNotification() {
            return notification;
        }

        public Xa getXa() {
            return xa;
        }
    }

    public static class Xa {

        private boolean enabled;

        public boolean isEnabled() {
            return enabled;
        }

        public void setEnabled(boolean enabled) {
            this.enabled = enabled;
        }
    }

    public static class Attempts {

        private int connAttemptCount = 5;

        private int connAttemptDelay = 2000;

        private int connAttemptTimeout = 10000;

        private int reconnAttemptCount = 60;

        private int reconnAttemptDelay = 5000;

        private int reconnAttemptTimeout = 10000;

        public int getConnAttemptCount() {
            return connAttemptCount;
        }

        public void setConnAttemptCount(int connAttemptCount) {
            this.connAttemptCount = connAttemptCount;
        }

        public int getConnAttemptDelay() {
            return connAttemptDelay;
        }

        public void setConnAttemptDelay(int connAttemptDelay) {
            this.connAttemptDelay = connAttemptDelay;
        }

        public int getConnAttemptTimeout() {
            return connAttemptTimeout;
        }

        public void setConnAttemptTimeout(int connAttemptTimeout) {
            this.connAttemptTimeout = connAttemptTimeout;
        }

        public int getReconnAttemptCount() {
            return reconnAttemptCount;
        }

        public void setReconnAttemptCount(int reconnAttemptCount) {
            this.reconnAttemptCount = reconnAttemptCount;
        }

        public int getReconnAttemptDelay() {
            return reconnAttemptDelay;
        }

        public void setReconnAttemptDelay(int reconnAttemptDelay) {
            this.reconnAttemptDelay = reconnAttemptDelay;
        }

        public int getReconnAttemptTimeout() {
            return reconnAttemptTimeout;
        }

        public void setReconnAttemptTimeout(int reconnAttemptTimeout) {
            this.reconnAttemptTimeout = reconnAttemptTimeout;
        }
    }

    public static class Endpoint {

        private String url;

        private String username;

        private String password;

        public String getUrl() {
            return url;
        }

        public void setUrl(String url) {
            this.url = url;
        }

        public String getUsername() {
            return username;
        }

        public void setUsername(String username) {
            this.username = username;
        }

        public String getPassword() {
            return password;
        }

        public void setPassword(String password) {
            this.password = password;
        }
    }
}
