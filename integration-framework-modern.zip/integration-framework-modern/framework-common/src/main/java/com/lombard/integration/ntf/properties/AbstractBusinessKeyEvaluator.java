package com.lombard.integration.ntf.properties;

import org.springframework.expression.EvaluationContext;
import org.springframework.expression.spel.support.StandardEvaluationContext;

/**
 * 
 * @author wvandenberghe
 * 
 */
public abstract class AbstractBusinessKeyEvaluator implements BusinessKeyEvaluator {

    /**
     * {@inheritDoc}
     */
    public String evaluate(Object content, String expression) {
        EvaluationContext context = new StandardEvaluationContext(content);

        return evaluate(context, expression);
    }

    /**
     * Evaluate this expression against the context as a string.
     * 
     * @param context
     * @param expression
     * @return evaluation result as a string
     */
    protected abstract String evaluate(EvaluationContext context, String expression);

}
