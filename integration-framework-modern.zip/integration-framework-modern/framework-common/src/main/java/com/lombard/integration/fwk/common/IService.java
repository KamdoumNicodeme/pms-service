package com.lombard.integration.fwk.common;

public interface IService {

}
