package com.lombard.integration.pubsub;

/**
 * Generic service which consume or publish messages.
 * 
 * @author wvandenberghe
 * 
 * @param <T>
 *            result type of the message content conversion
 */
public interface GenericService< T > {

    /**
     * Method to call to send or to implement for receiving.
     * 
     * @param toSendOrReceive
     */
    void sendOrReceive(T toSendOrReceive);
}
