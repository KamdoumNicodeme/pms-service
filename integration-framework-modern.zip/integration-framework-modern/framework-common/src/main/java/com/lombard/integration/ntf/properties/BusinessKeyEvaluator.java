package com.lombard.integration.ntf.properties;

import com.lombard.integration.fwk.notification.annotation.BusinessKey;

/**
 * Evaluator of business key expression
 * 
 * @author wvandenberghe
 * @see BusinessKey
 */
public interface BusinessKeyEvaluator {

    /**
     * Evaluate this expression on this target as a string.
     * 
     * @param target
     * @param expression
     * @return evaluation result as a string
     */
    String evaluate(Object target, String expression);

}
