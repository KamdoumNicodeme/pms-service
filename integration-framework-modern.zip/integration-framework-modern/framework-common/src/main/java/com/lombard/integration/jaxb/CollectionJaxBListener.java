package com.lombard.integration.jaxb;

import java.util.List;

import jakarta.xml.bind.Marshaller.Listener;
import jakarta.xml.bind.annotation.XmlIDREF;
import jakarta.xml.bind.annotation.XmlList;

import org.springframework.util.ReflectionUtils;

import com.lombard.cdm.AbstractEntity;
import com.lombard.integration.util.ModelUtils;

/**
 * Check The collection with xmlIDRef and XMLList that are null or empty and set it up to null;
 * 
 * We want to avoid <bankAccounts></bankAccounts> empty when we marshall the class.
 * 
 * @author CLONFILS
 * 
 */
public class CollectionJaxBListener extends Listener {

    /**
     * {@inheritDoc}
     */
    @Override
    public void beforeMarshal(final Object source) {

        if (ModelUtils.isCdmPresent() && source instanceof AbstractEntity) {
            try {
                ReflectionUtils.doWithFields(source.getClass(), field -> {
                    ReflectionUtils.makeAccessible(field);
                    Object value = field.get(source);
                    if (value instanceof List<?> list && list.isEmpty()) {
                        field.set(source, null);
                    }
                }, field -> field.isAnnotationPresent(XmlIDREF.class) && field.isAnnotationPresent(XmlList.class));
            } catch (IllegalArgumentException e) {
                throw new IllegalStateException(e);
            }
        }
        super.beforeMarshal(source);
    }

}
