package com.lombard.integration.fwk.notification.annotation;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Specify a business key for evaluation at tracing time.
 * 
 * @author wvandenberghe
 * 
 */
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.METHOD)
@Documented
public @interface BusinessKey {

    /**
     * Business key name.
     * 
     * @return
     */
    String name();

    /**
     * Expression to be evaluated (Spel).
     * 
     * @return
     */
    String expression();
}
