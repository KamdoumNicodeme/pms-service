package com.lombard.integration.util;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.UUID;

import org.springframework.util.ClassUtils;
import org.springframework.util.ReflectionUtils;

/**
 * Utility class to deal with CDM/CSM.
 * 
 * @author wvandenberghe
 * 
 */
public final class ModelUtils {

    private static final String HOSTNAME = getHostname();

    private static String getHostname() {
        try {
            return InetAddress.getLocalHost().getHostName();
        } catch (UnknownHostException e) {
            return null;
        }
    }

    /**
     * Enumeration used to manage CDM/CSM versions.
     * 
     * @author wvandenberghe
     * 
     */
    private enum ModelVersion {
        V22("com.lombard.integration.fwk.schema.csm.v2_2", "com.lombard.integration.fwk.schema.cdm.v2_2"),
        NO_VERSION("com.lombard.csm", "com.lombard.cdm");

        /**
         * 
         */
        private final String csmPackageName;

        /**
         * 
         */
        private final String cdmPackageName;

        /**
         * 
         * @param csmPackageName
         * @param cdmPackageName
         */
        private ModelVersion(String csmPackageName, String cdmPackageName) {
            this.csmPackageName = csmPackageName;
            this.cdmPackageName = cdmPackageName;
        }

        /**
         * 
         * @return
         */
        public Class<?> getCorrelationHandlerClass() {
            return org.springframework.util.ClassUtils.resolveClassName(cdmPackageName + ".CorrelationHandler",
                    org.springframework.util.ClassUtils.getDefaultClassLoader());
        }

        /**
         * 
         * @return
         */
        public Class<?> getAbstractRequestClass() {
            return org.springframework.util.ClassUtils.resolveClassName(csmPackageName + ".AbstractRequest",
                    org.springframework.util.ClassUtils.getDefaultClassLoader());
        }

        /**
         * 
         * @return
         */
        public Class<?> getAbstractResponseClass() {
            return org.springframework.util.ClassUtils.resolveClassName(csmPackageName + ".AbstractResponse",
                    org.springframework.util.ClassUtils.getDefaultClassLoader());
        }

        /**
         * 
         * @return
         */
        public Class<?> getApplicationContextClass() {
            return org.springframework.util.ClassUtils.resolveClassName(cdmPackageName + ".ApplicationContext",
                    org.springframework.util.ClassUtils.getDefaultClassLoader());
        }

        /**
         * 
         * @return
         */
        public Class<?> getIdTypeClass() {
            return org.springframework.util.ClassUtils.resolveClassName(cdmPackageName + ".IdType",
                    org.springframework.util.ClassUtils.getDefaultClassLoader());
        }

        /**
         * 
         * @param payload
         * @return
         */
        public static ModelVersion fromPayload(Object payload) {
            for (ModelVersion version : values()) {
                try {
                    if (version.getAbstractRequestClass().isAssignableFrom(payload.getClass())) {
                        return version;
                    }
                } catch (IllegalArgumentException e) {
                    // ignore exception
                }
            }

            return null;
        }

    }

    private static final boolean csmPresent = ClassUtils.isPresent("com.lombard.csm.ObjectFactory",
            ClassUtils.getDefaultClassLoader());

    private static final boolean csm2_2Present = ClassUtils.isPresent(
            "com.lombard.integration.fwk.schema.csm.v2_2.ObjectFactory", ClassUtils.getDefaultClassLoader());

    private static final boolean cdmPresent = ClassUtils.isPresent("com.lombard.cdm.ObjectFactory",
            ClassUtils.getDefaultClassLoader());

    private static final boolean cdm2_2Present = ClassUtils.isPresent(
            "com.lombard.integration.fwk.schema.cdm.v2_2.ObjectFactory", ClassUtils.getDefaultClassLoader());
    
    private static final boolean documentsPresent =
            ClassUtils.isPresent("com.lombard.documents.ObjectFactory", ClassUtils.getDefaultClassLoader());

    private ModelUtils() {
        // nothing to do
    }

    /**
     * Is CSM jar present in classpath.
     * 
     * @return
     */
    public static boolean isCsmPresent() {
        return csmPresent;
    }

    /**
     * Is CSM 2.2 jar present in classpath.
     * 
     * @return
     */
    public static boolean isCsm22Present() {
        return csm2_2Present;
    }

    /**
     * Is CDM jar present in classpath.
     * 
     * @return
     */
    public static boolean isCdmPresent() {
        return cdmPresent;
    }

    /**
     * Is CSM 2.2 jar present in classpath.
     * 
     * @return
     */
    public static boolean isCdm22Present() {
        return cdm2_2Present;
    }
    
    /**
     * Is Documents jar present in classpath.
     * 
     * @return
     */
    public static boolean isDocumentsPresent() {

        return documentsPresent;
    }

    /**
     * 
     * @param requestPayload
     * @param responsePayload
     * @return
     */
    public static Object copyCorrelationHandler(Object requestPayload, Object responsePayload) {
        if (responsePayload == null) {
            throw new IllegalArgumentException("[responsePayload] must not be null ");
        }

        if (requestPayload == null) {
            return responsePayload;
        }

        final ModelVersion version = ModelVersion.fromPayload(requestPayload);

        if (version != null && hasCorrelationHandler(requestPayload)) {
            // get correlation handler
            Class<?> requestPayloadClass = version.getAbstractRequestClass();
            Method getCorrelationHandler = ReflectionUtils.findMethod(requestPayloadClass, "getCorrelationHandler");
            if (getCorrelationHandler == null) {
                return responsePayload;
            }

            Object correlationHandler = ReflectionUtils.invokeMethod(getCorrelationHandler, requestPayload);
            if (correlationHandler == null) {
                return responsePayload;
            }

            // set correlation handler
            Class<?> responsePayloadClass = version.getAbstractResponseClass();
            Class<?> correlationHandlerClass = version.getCorrelationHandlerClass();
            Method setCorrelationHandler =
                    ReflectionUtils.findMethod(responsePayloadClass, "setCorrelationHandler",
                            correlationHandlerClass);
            if (setCorrelationHandler != null) {
                ReflectionUtils.invokeMethod(setCorrelationHandler, responsePayload, correlationHandler);
            }
        }

        return responsePayload;
    }

    /**
     * 
     * @param payload
     * @param applicationId
     * @return
     */
    public static Object addCorrelationHandler(Object payload, String applicationId) {
        if (payload == null) {
            throw new IllegalArgumentException("[payload] must not be null");
        }

        if (applicationId == null || applicationId.trim().length() == 0) {
            throw new IllegalArgumentException("[applicationId] must not be null or empty");
        }

        ModelVersion version = ModelVersion.fromPayload(payload);
        if (version != null && !hasCorrelationHandler(payload)) {
            Object correlationHandler = newCorrelationHandler(version, applicationId);
            if (correlationHandler != null) {
                Method setCorrelationHandler =
                        ReflectionUtils.findMethod(version.getAbstractRequestClass(), "setCorrelationHandler",
                                version.getCorrelationHandlerClass());
                if (setCorrelationHandler != null) {
                    ReflectionUtils.invokeMethod(setCorrelationHandler, payload, correlationHandler);
                }
            }
        }

        return payload;
    }

    /**
     * 
     * @param version
     * @param applicationId
     * @return
     */
    public static Object newCorrelationHandler(ModelVersion version, String applicationId) {
        Class<?> correlationHandlerClass = version.getCorrelationHandlerClass();

        Object correlationHandler = create(correlationHandlerClass);

        // set correlation id
        String uuid = UUID.randomUUID().toString();
        Method setId = ReflectionUtils.findMethod(correlationHandlerClass, "setId", String.class);
        if (setId != null) {
            ReflectionUtils.invokeMethod(setId, correlationHandler, uuid);
        }

        // set application context
        Class<?> applicationContextClass = version.getApplicationContextClass();
        Object applicationContext = newApplicationContext(version, applicationId);
        Method setApplicationContext =
                ReflectionUtils.findMethod(correlationHandlerClass, "setInitiator", applicationContextClass);
        if (setApplicationContext != null) {
            ReflectionUtils.invokeMethod(setApplicationContext, correlationHandler, applicationContext);
        }

        return correlationHandler;
    }

    /**
     * 
     * @param version
     * @param applicationId
     * @return
     */
    private static Object newApplicationContext(ModelVersion version, String applicationId) {
        Class<?> applicationContextClass = version.getApplicationContextClass();
        Object applicationContext = create(applicationContextClass);

        Class<?> idTypeClass = version.getIdTypeClass();
        @SuppressWarnings({"unchecked", "rawtypes"})
        Object idType = Enum.valueOf((Class) idTypeClass, applicationId.toUpperCase());

        Method setName = ReflectionUtils.findMethod(applicationContextClass, "setName", idTypeClass);
        if (setName != null) {
            ReflectionUtils.invokeMethod(setName, applicationContext, idType);
        }

        Method setNode = ReflectionUtils.findMethod(applicationContextClass, "setNode", String.class);
        if (setNode != null) {
            ReflectionUtils.invokeMethod(setNode, applicationContext, HOSTNAME);
        }

        return applicationContext;
    }

    /**
     * 
     * @param request
     * @return
     */
    public static boolean hasCorrelationHandler(Object request) {
        ModelVersion version = ModelVersion.fromPayload(request);

        if (version == null) {
            return false;
        }

        Field field =
                ReflectionUtils.findField(version.getAbstractRequestClass(), null,
                        version.getCorrelationHandlerClass());
        ReflectionUtils.makeAccessible(field);

        return ReflectionUtils.getField(field, request) != null;
    }

    private static Object create(Class<?> clazz) {
        try {
            if (org.springframework.util.ClassUtils.hasConstructor(clazz)) {
                return clazz.getDeclaredConstructor().newInstance();
            } else {
                throw new IllegalStateException("No default constructor define");
            }
        } catch (ReflectiveOperationException e) {
            ReflectionUtils.handleReflectionException(e);
            throw new IllegalStateException("Unexpected reflection exception - " + e.getClass().getName() + ": "
                    + e.getMessage(), e);
        }
    }
}
