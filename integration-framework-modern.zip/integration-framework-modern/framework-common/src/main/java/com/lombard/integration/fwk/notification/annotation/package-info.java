/**
 * Annotations to deal with {@link com.lombard.csm.Notification} and configure publishers and consumers.
 */
package com.lombard.integration.fwk.notification.annotation;

