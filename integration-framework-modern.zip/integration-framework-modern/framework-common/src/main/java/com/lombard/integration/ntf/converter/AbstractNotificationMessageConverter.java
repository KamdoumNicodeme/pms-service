package com.lombard.integration.ntf.converter;

import jakarta.jms.JMSException;
import jakarta.jms.Message;
import jakarta.jms.Session;
import jakarta.jms.TextMessage;
import jakarta.xml.bind.JAXBElement;

import org.springframework.beans.factory.InitializingBean;
import org.springframework.jms.support.converter.MarshallingMessageConverter;
import org.springframework.jms.support.converter.MessageConversionException;
import org.springframework.jms.support.converter.MessageType;
import org.springframework.remoting.support.RemoteInvocation;
import org.springframework.remoting.support.RemoteInvocationResult;

import com.lombard.csm.Notification;
import com.lombard.integration.ntf.validation.NotificationValidator;

/**
 * Message converter dedicated to {@link Notification}.
 * 
 * @author wvandenberghe
 * 
 */
public abstract class AbstractNotificationMessageConverter extends MarshallingMessageConverter implements InitializingBean {

    private static final String NOTIF_SERVICE_METHOD_NAME = "sendOrReceive";

    private NotificationValidator validator;

    /**
     * Get notification validator
     * 
     * @return
     */
    public NotificationValidator getValidator() {

        return validator;
    }

    /**
     * Set notification validator
     * 
     * @param validator
     */
    public void setValidator(NotificationValidator validator) {

        this.validator = validator;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void afterPropertiesSet() {

        setTargetType(MessageType.TEXT);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Message toMessage(Object object, Session session) throws JMSException, MessageConversionException {

        if (object instanceof RemoteInvocation remoteInvocation) {
            return handleRemoteInvocation(remoteInvocation, session);
        }

        if (object instanceof RemoteInvocationResult remoteInvocationResult) {
            handleRemoteInvocationResult(remoteInvocationResult, session);
        }

        return super.toMessage(object, session);
    }

    /**
     * Handle object as a {@link RemoteInvocation}.
     * 
     * @param object
     *            object to handle
     * @param session
     *            JMS session
     * @return message containing a converted version of object
     * @throws JMSException
     *             if message cannot be created
     * @throws MessageConversionException
     *             if object cannot be convert to message
     */
    protected abstract Message handleRemoteInvocation(Object object, Session session) throws JMSException, MessageConversionException;

    /**
     * Handle object as a {@link RemoteInvocationResult}.
     * 
     * @param object
     *            object to handle
     * @param session
     *            JMS session
     * @return message containing a converted version of object
     * @throws JMSException
     *             if message cannot be created
     * @throws MessageConversionException
     *             if object cannot be convert to message
     */
    protected abstract Message handleRemoteInvocationResult(Object object, Session session) throws JMSException, MessageConversionException;

    /**
     * {@inheritDoc}
     */
    @Override
    public Object fromMessage(Message message) throws JMSException, MessageConversionException {

        // there is no answer in publish and forget policy
        // but a result must be returned
        if (message == null) {
            return new RemoteInvocationResult(null);
        }

        // execute validation
        if (getValidator() != null && !getValidator().handleOnConsume(message)) {
            return new RemoteInvocationResult(null);
        }

        // extract the content and transform it to an object
        if (message instanceof TextMessage) {
            final Object object = super.fromMessage(message);

            if (object instanceof JAXBElement<?> jaxbElement) {
                @SuppressWarnings("unchecked")
                JAXBElement<Notification> notificationEl = (JAXBElement<Notification>) jaxbElement;
                final RemoteInvocation remoteInvocation =
                        new RemoteInvocation(NOTIF_SERVICE_METHOD_NAME, new Class<?>[] { Notification.class },
                                new Object[] { notificationEl.getValue() });
                return remoteInvocation;
            }
        }

        return super.fromMessage(message);
    }
}
