package com.lombard.integration.ntf.properties.transformer;

import org.springframework.beans.factory.InitializingBean;
import org.springframework.util.Assert;


public abstract class AbstractBusinessKeyValueTransformerDelegate< T, O > extends
        AbstractBusinessKeyValueTransformer<T> implements InitializingBean {

    private BusinessKeyValueTransformer < O > delegate;

    public void setDelegate(BusinessKeyValueTransformer < O > delegate) {
        this.delegate = delegate;
    }

    public void afterPropertiesSet() throws Exception {
        Assert.notNull(delegate, "Property [delegate] is mandatory");
    }

    public final < P extends T > String transform(P obj) {
        return delegate.transform(doTransform(obj));
    }

    protected abstract O doTransform(T object);
}
