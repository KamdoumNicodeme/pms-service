package com.lombard.integration.ntf.converter;

import jakarta.jms.JMSException;
import jakarta.jms.Message;
import jakarta.jms.Session;

import org.springframework.jms.support.converter.MessageConversionException;
import org.springframework.remoting.support.RemoteInvocation;
import org.springframework.remoting.support.RemoteInvocationResult;

import com.lombard.cdm.ActivityHandler;
import com.lombard.csm.Notification;
import com.lombard.integration.ntf.NotificationUtils;

/**
 * Default implementation for a notification message converter.
 * 
 * @author wvandenberghe
 * 
 */
public class DefaultNotificationMessageConverter extends AbstractNotificationMessageConverter {

    private static final String NOTIFICATION_BUSINESS_CONTEXT = "NotificationBusinessContext";
    private static final String INITITATOR_NODE = "InititatorNode";
    private static final String INITIATOR_NAME = "InitiatorName";
    private static final String INITIATOR_ID = "InitiatorID";
    private static final String CORRELATION_ID = "CorrelationID";
    private static final String PRESERVE_UNDELIVERED = "JMS_TIBCO_PRESERVE_UNDELIVERED";

    /**
     * {@inheritDoc}
     */
    protected Message handleRemoteInvocation(Object object, Session session) throws JMSException,
            MessageConversionException {
        RemoteInvocation remoteInvocation = (RemoteInvocation) object;
        Object[] arguments = remoteInvocation.getArguments();

        if (arguments.length != 1) {
            return super.toMessage(object, session);
        }

        Object argument = arguments[0];
        if (argument instanceof Notification notification) {

            Message message = super.toMessage(notification, session);

            fillJmsProperties(message, notification);

            // execute validation
            if (getValidator() != null) {
                getValidator().handleOnPublish(message);
            }

            return message;
        }

        if (argument instanceof ActivityHandler activityHandler) {

            return super.toMessage(activityHandler, session);
        }

        return super.toMessage(object, session);
    }

    /**
     * {@inheritDoc}
     */
    protected Message handleRemoteInvocationResult(Object object, Session session) throws JMSException,
            MessageConversionException {
        RemoteInvocationResult remoteInvocationResult = (RemoteInvocationResult) object;
        Object value = remoteInvocationResult.getValue();

        if (value == null) {
            return session.createMessage();
        }

        return super.toMessage(object, session);
    }

    /**
     * Fill JMS header properties from notification message.
     * 
     * @param message
     * @param notification
     * @throws JMSException
     */
    private void fillJmsProperties(Message message, Notification notification) throws JMSException {
        // set correlation ID
        String correlationId = NotificationUtils.getCorrelationID(notification);
        message.setStringProperty(CORRELATION_ID, correlationId);

        // set initiator ID
        String initiatorId = NotificationUtils.getInitiatorID(notification);
        message.setStringProperty(INITIATOR_ID, initiatorId);
        message.setStringProperty(INITIATOR_NAME, initiatorId);

        // set initiator node
        String initiaorNode = NotificationUtils.getInitiatorNode(notification);
        message.setStringProperty(INITITATOR_NODE, initiaorNode);

        // set notification business context
        String notificationBusinessContext = NotificationUtils.getNotificationBusinessContext(notification);
        message.setStringProperty(NOTIFICATION_BUSINESS_CONTEXT, notificationBusinessContext);

        // set preserve undelivered
        message.setBooleanProperty(PRESERVE_UNDELIVERED, true);
    }

}
