package com.lombard.integration.fwk.cxf.interceptors.tibco;

import java.util.Collections;
import java.util.List;
import java.util.Map;

import org.apache.cxf.binding.soap.SoapMessage;
import org.apache.cxf.binding.soap.interceptor.AbstractSoapInterceptor;
import org.apache.cxf.binding.soap.jms.interceptor.SoapJMSConstants;
import org.apache.cxf.helpers.CastUtils;
import org.apache.cxf.interceptor.AttachmentInInterceptor;
import org.apache.cxf.interceptor.Fault;
import org.apache.cxf.message.Message;
import org.apache.cxf.phase.Phase;

public class TIBCOInInterceptor extends AbstractSoapInterceptor {

	public TIBCOInInterceptor() {
        super(Phase.RECEIVE);
        addBefore(AttachmentInInterceptor.class.getName());	
    }
	
	
	public void handleMessage(SoapMessage aMessage) 
	throws Fault {
		
		Map<String, List<String>> headers = CastUtils.cast((Map<?, ?>) aMessage.get(Message.PROTOCOL_HEADERS));
		if (headers != null) {
			changeContentType(aMessage, headers);
			
			checkRequestURI(headers);
		}
	}
	
    private void changeContentType(SoapMessage message, Map<String, List<String>> headers) {
    	
        List<String> ct = headers.get("Content_Type");
        
        if (ct != null && ct.size() > 0) {
            String contentType = ct.get(0);
            List<String> clt = Collections.singletonList(contentType);
            headers.put(SoapJMSConstants.CONTENTTYPE_FIELD, clt);
            message.put(Message.CONTENT_TYPE, contentType);
        }
    }
    
    private void checkRequestURI(Map<String, List<String>> headers) {
            headers.put(SoapJMSConstants.REQUESTURI_FIELD, Collections.singletonList("jms:queue:"));
    }
    
	
}
