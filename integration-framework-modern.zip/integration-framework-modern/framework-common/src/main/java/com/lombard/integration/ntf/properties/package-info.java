/**
 * Contains classes to deal with {@link com.lombard.integration.fwk.notification.annotation.BusinessKey}.
 * 
 * <img src="http://yuml.me/46c1f95a">
 */
package com.lombard.integration.ntf.properties;