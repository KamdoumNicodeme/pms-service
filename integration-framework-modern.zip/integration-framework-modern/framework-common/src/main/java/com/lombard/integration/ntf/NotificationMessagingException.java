package com.lombard.integration.ntf;

/**
 * 
 * @author wvandenberghe
 * 
 */
public class NotificationMessagingException extends NotificationException {

    private static final long serialVersionUID = 1L;

    /**
     * 
     * @param message
     * @param cause
     */
    public NotificationMessagingException(String message, Throwable cause) {
        super(message, cause);
    }

    /**
     * 
     * @param message
     */
    public NotificationMessagingException(String message) {
        super(message);
    }

}
