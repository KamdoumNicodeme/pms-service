package com.lombard.integration.gtw;

/**
 * A service to publish/subscribe a message as a String.
 * 
 * @author wvandenberghe
 * 
 */
public interface GatewayService {

    public void processContent(String toSendOrReceive);
}
