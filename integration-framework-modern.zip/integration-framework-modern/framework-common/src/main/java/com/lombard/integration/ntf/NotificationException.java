package com.lombard.integration.ntf;

import org.springframework.core.NestedRuntimeException;

/**
 * 
 * @author wvandenberghe
 * 
 */
public abstract class NotificationException extends NestedRuntimeException {

    private static final long serialVersionUID = 1L;

    /**
     * 
     * @param message
     * @param cause
     */
    public NotificationException(String message, Throwable cause) {
        super(message, cause);
    }

    /**
     * 
     * @param message
     */
    public NotificationException(String message) {
        super(message);
    }

}
