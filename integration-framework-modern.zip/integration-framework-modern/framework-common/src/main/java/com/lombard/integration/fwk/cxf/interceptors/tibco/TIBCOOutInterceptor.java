package com.lombard.integration.fwk.cxf.interceptors.tibco;

import org.apache.cxf.binding.soap.SoapBindingConstants;
import org.apache.cxf.binding.soap.SoapMessage;
import org.apache.cxf.binding.soap.interceptor.AbstractSoapInterceptor;
import org.apache.cxf.binding.soap.model.SoapOperationInfo;
import org.apache.cxf.interceptor.Fault;
import org.apache.cxf.message.Message;
import org.apache.cxf.phase.Phase;
import org.apache.cxf.service.model.BindingOperationInfo;
import org.apache.cxf.transport.jms.JMSConstants;
import org.apache.cxf.transport.jms.JMSMessageHeadersType;
import org.apache.cxf.transport.jms.JMSPropertyType;

public class TIBCOOutInterceptor extends AbstractSoapInterceptor {

	public TIBCOOutInterceptor() {
		super(Phase.SEND);
	}

	public void handleMessage(SoapMessage aMessage) throws Fault {
		makeClientHeaders(aMessage);
		makeServerHeaders(aMessage);
	}
	
	private void makeServerHeaders(SoapMessage aMessage) {
		String ct = (String) aMessage.get(Message.CONTENT_TYPE);

		JMSMessageHeadersType messageProperties = (JMSMessageHeadersType) aMessage
				.get(JMSConstants.JMS_SERVER_RESPONSE_HEADERS);
		if (messageProperties == null) {
			messageProperties = new JMSMessageHeadersType();
			aMessage.put(JMSConstants.JMS_SERVER_RESPONSE_HEADERS,
					messageProperties);
		}
		JMSPropertyType p = new JMSPropertyType();

		p.setName("Content_Type");
		p.setValue(ct);
		messageProperties.getProperty().add(p);

		// Code from SoapPreProtocolOutInterceptor
		p = new JMSPropertyType();
		p.setName("SoapAction");

		p.setValue(getAction(aMessage));
		messageProperties.getProperty().add(p);
		
	}
	

	private void makeClientHeaders(SoapMessage aMessage) {
		String ct = (String) aMessage.get(Message.CONTENT_TYPE);

		JMSMessageHeadersType messageProperties = (JMSMessageHeadersType) aMessage
				.get(JMSConstants.JMS_CLIENT_REQUEST_HEADERS);
		if (messageProperties == null) {
			messageProperties = new JMSMessageHeadersType();
			aMessage.put(JMSConstants.JMS_CLIENT_REQUEST_HEADERS,
					messageProperties);
		}
		JMSPropertyType p = new JMSPropertyType();

		p.setName("Content_Type");
		p.setValue(ct);
		messageProperties.getProperty().add(p);

		// Code from SoapPreProtocolOutInterceptor
		p = new JMSPropertyType();
		p.setName("SoapAction");

		p.setValue(getAction(aMessage));
		messageProperties.getProperty().add(p);
		
	}
	
	// Code from SoapPreProtocolOutInterceptor	
	private String getAction(SoapMessage message) {
        BindingOperationInfo boi = message.getExchange().getBindingOperationInfo();
        
        // The soap action is set on the wrapped operation.
        if (boi != null && boi.isUnwrapped()) {
            boi = boi.getWrappedOperation();
        }
        
        String action = getSoapAction(message, boi);        

        return action;
	}

	// Code from SoapPreProtocolOutInterceptor
	private String getSoapAction(SoapMessage message, BindingOperationInfo boi) {
		// allow an interceptor to override the SOAPAction if need be
		String action = (String) message.get(SoapBindingConstants.SOAP_ACTION);

		// Fall back on the SOAPAction in the operation info
		if (action == null) {
			if (boi == null) {
				action = "\"\"";
			} else {
				SoapOperationInfo soi = (SoapOperationInfo) boi
						.getExtensor(SoapOperationInfo.class);
				action = soi == null ? "\"\""
						: soi.getAction() == null ? "\"\"" : soi.getAction();
			}
		}

		if (!action.startsWith("\"")) {
			action = new StringBuilder().append("\"").append(action)
					.append("\"").toString();
		}

		return action;
	}

}
