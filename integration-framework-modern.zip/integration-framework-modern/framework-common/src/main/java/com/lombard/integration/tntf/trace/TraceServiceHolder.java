package com.lombard.integration.tntf.trace;

import jakarta.jms.ConnectionFactory;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.FactoryBean;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import com.lombard.integration.config.AbstractIntfwkDefinitionParser;
import com.lombard.integration.jaxb.JaxbMarshallerFactoryBean;
import com.lombard.integration.ntf.converter.DefaultNotificationMessageConverter;

/**
 * A holder to provide a ready to use {@link TraceService} implementation in an asynchronous manner.
 * 
 * @author wvandenberghe
 * 
 */
public final class TraceServiceHolder implements FactoryBean<TraceService>, ApplicationContextAware {

    private static final String DEFAULT_CONNECTION_FACTORY = "tecConnectionFactory";

    /**
     * Singleton holder to warranty uniqueness of the holded instance.
     * 
     * @author wvandenberghe
     * 
     */
    private static final class SingletonHolder {

        private static final TraceServiceHolder INSTANCE = new TraceServiceHolder();

        private SingletonHolder() {
        }
    }

    private static final Log log = LogFactory.getLog(TraceServiceHolder.class);

    private TraceServiceImpl traceService;

    private ApplicationContext applicationContext;

    /**
     * Default constructor.
     */
    private TraceServiceHolder() {
    }

    /**
     * Get a holder instance configured by the provided {@link ApplicationContext}
     * 
     * @param applicationContext
     *            settings
     * @return a unique configured instance
     */
    public static TraceServiceHolder getInstance(ApplicationContext applicationContext) {
        if (applicationContext == null) {
            throw new IllegalArgumentException("'applicationContext' is mandatory");
        }

        TraceServiceHolder holder = SingletonHolder.INSTANCE;
        holder.setApplicationContext(applicationContext);

        return holder;
    }

    /**
     * {@inheritDoc}
     */
    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
        this.applicationContext = applicationContext;
    }

    /**
     * {@inheritDoc}
     */
    public TraceServiceImpl getObject() throws Exception {
        if (traceService == null) {
            traceService = new TraceServiceImpl();

            // get connection factory from context
            if (log.isDebugEnabled()) {
                log.debug("Get technical notification connection factory");
            }
            final ConnectionFactory connectionFactory =
                    applicationContext.getBean(DEFAULT_CONNECTION_FACTORY, ConnectionFactory.class);
            traceService.setConnectionFactory(connectionFactory);

            // create default message converter
            if (log.isDebugEnabled()) {
                log.debug("Create message converter");
            }
            final DefaultNotificationMessageConverter messageConverter = new DefaultNotificationMessageConverter();
            traceService.setMessageConverter(messageConverter);

            // get JAXB marshaller
            if (log.isDebugEnabled()) {
                log.debug("Get JAXB marshaller");
            }

            Jaxb2Marshaller marshaller = null;
            try {
                marshaller =
                        applicationContext.getBean(AbstractIntfwkDefinitionParser.DEFAULT_MODEL_MARSHALLER,
                                Jaxb2Marshaller.class);
            } catch (BeansException e) {
                if (log.isDebugEnabled()) {
                    log.debug("Creating JAXB marshaller...");
                }
                JaxbMarshallerFactoryBean factoryBean = new JaxbMarshallerFactoryBean();
                factoryBean.afterPropertiesSet();
                marshaller = factoryBean.getObject();
            }
            messageConverter.setMarshaller(marshaller);
            messageConverter.afterPropertiesSet();

            // create task executor
            ThreadPoolTaskExecutor taskExecutor = new ThreadPoolTaskExecutor();
            taskExecutor.setWaitForTasksToCompleteOnShutdown(true);
            traceService.setTaskExecutor(taskExecutor);

            try {
                if (log.isInfoEnabled()) {
                    log.info("Configuring tracer...");
                }
                traceService.afterPropertiesSet();
            } catch (Exception e) {
                traceService = null;
                log.error("Error occured while initializing tracer", e);
            }
        }

        return traceService;
    }

    /**
     * {@inheritDoc}
     */
    public Class<?> getObjectType() {
        return TraceServiceImpl.class;
    }

    /**
     * {@inheritDoc}
     */
    public boolean isSingleton() {
        return true;
    }

}
