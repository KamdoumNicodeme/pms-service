package com.lombard.integration.tntf.trace.config;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.beans.factory.support.AbstractBeanDefinition;
import org.springframework.beans.factory.support.BeanDefinitionBuilder;
import org.springframework.beans.factory.xml.ParserContext;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.w3c.dom.Element;

import com.lombard.integration.ntf.config.AbstractMessagingDefinitionParser;
import com.lombard.integration.tntf.trace.TraceServiceImpl;
import com.lombard.integration.tntf.trace.TraceService;

/**
 * Parser for <code>tracer</code> element.
 * <p>
 * Inject {@link TraceService} in Spring context.
 * 
 * <pre>
 * &lt;intfwk:tracer connection-factory="tecConnectionFactory" destination="TNT.TRACE" />
 * </pre>
 * 
 * @author wvandenberghe
 * 
 */
public class TracerDefinitionParser extends AbstractMessagingDefinitionParser {

    private static final String DEFAULT_CONNECTION_FACTORY = "tecConnectionFactory";

    private static final String XA_CONNECTION_FACTORY_ATT = "xa-connection-factory";

    /**
     * {@inheritDoc}
     */
    @Override
    protected AbstractBeanDefinition parseInternal(Element element, ParserContext parserContext) {

        BeanDefinitionBuilder builder = BeanDefinitionBuilder.genericBeanDefinition(TraceServiceImpl.class);

        String connectionFactory = element.getAttribute(CONNECTION_FACTORY_ATT);
        if (connectionFactory.trim().length() == 0) {
            connectionFactory = getDefaultConnectionFactoryReference();
        }
        builder.addPropertyReference("connectionFactory", connectionFactory);

        String xaConnectionFactory = element.getAttribute(XA_CONNECTION_FACTORY_ATT);
        if (StringUtils.isNotBlank(xaConnectionFactory)) {
            builder.addPropertyReference("syncConnectionFactory", xaConnectionFactory);
        }

        String destinationName = element.getAttribute(DESTINATION_ATT);
        if (destinationName != null && destinationName.trim().length() != 0) {
            builder.addPropertyValue("queueName", destinationName);
        }

        BeanDefinition messageConverter = parseMessageConverter(element, parserContext);
        builder.addPropertyValue("messageConverter", messageConverter);

        BeanDefinition taskExecutor = getTaskExecutor();
        builder.addPropertyValue("taskExecutor", taskExecutor);

        // builder.setAutowireMode(AutowireCapableBeanFactory.AUTOWIRE_BY_TYPE);

        return builder.getBeanDefinition();
    }

    private BeanDefinition getTaskExecutor() {

        BeanDefinitionBuilder builder = BeanDefinitionBuilder.genericBeanDefinition(ThreadPoolTaskExecutor.class);

        builder.addPropertyValue("waitForTasksToCompleteOnShutdown", true);

        return builder.getBeanDefinition();
    }

    @Override
    protected String getDefaultConnectionFactoryReference() {

        return DEFAULT_CONNECTION_FACTORY;
    }

}
