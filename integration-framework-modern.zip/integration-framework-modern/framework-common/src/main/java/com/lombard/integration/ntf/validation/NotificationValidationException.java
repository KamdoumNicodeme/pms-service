package com.lombard.integration.ntf.validation;

import org.xml.sax.SAXParseException;

import com.lombard.integration.ntf.NotificationException;

public class NotificationValidationException extends NotificationException {

    private static final long serialVersionUID = 1L;

    private final SAXParseException[] validationErrors;

    /**
     * Create a new instance of the <code>NotificationValidationException</code> class.
     */
    public NotificationValidationException(SAXParseException[] validationErrors) {
        super(createMessage(validationErrors));
        this.validationErrors = validationErrors.clone();
    }

    private static String createMessage(SAXParseException[] validationErrors) {
        StringBuilder builder = new StringBuilder("XML validation error on response: ");

        for (SAXParseException validationError : validationErrors) {
            builder.append(validationError.getMessage());
        }
        return builder.toString();
    }

    /** Returns the validation errors. */
    public SAXParseException[] getValidationErrors() {
        return validationErrors;
    }
}
