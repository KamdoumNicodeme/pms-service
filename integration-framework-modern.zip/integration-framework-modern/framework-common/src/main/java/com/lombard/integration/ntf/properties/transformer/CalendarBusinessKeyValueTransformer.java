package com.lombard.integration.ntf.properties.transformer;

import java.util.Calendar;
import java.util.Date;


/**
 * 
 * @author JZAPADKA
 * 
 */
public class CalendarBusinessKeyValueTransformer extends
        AbstractBusinessKeyValueTransformerDelegate < Calendar, Date > {

    @Override
    protected Date doTransform(Calendar object) {
        if (object != null) {
            return object.getTime();
        }

        return null;
    }
}
