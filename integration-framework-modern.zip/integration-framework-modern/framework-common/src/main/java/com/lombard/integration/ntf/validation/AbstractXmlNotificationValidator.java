package com.lombard.integration.ntf.validation;

import java.io.IOException;

import jakarta.jms.Message;
import javax.xml.transform.Source;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.core.io.Resource;
import org.springframework.util.Assert;
import org.springframework.util.ObjectUtils;
import org.springframework.util.StringUtils;
import org.springframework.xml.validation.XmlValidator;
import org.springframework.xml.validation.XmlValidatorFactory;
import org.xml.sax.SAXParseException;

import com.lombard.integration.ntf.NotificationException;
import com.lombard.integration.ntf.NotificationMessagingException;

/**
 * Validator abstraction based on a notification as XML.
 * <p>
 * Validation must be done by a schema. W3C XML schema and Relax NG are supported. W3C XML schema is the default
 * value.
 * 
 * @author wvandenberghe
 * 
 */
public abstract class AbstractXmlNotificationValidator extends AbstractNotificationValidator implements
        InitializingBean {

    private static final Log logger = LogFactory.getLog(AbstractXmlNotificationValidator.class);

    private String schemaLanguage = XmlValidatorFactory.SCHEMA_W3C_XML;

    private Resource[] schemas;

    private XmlValidator validator;

    /**
     * Get the schema language.
     * <p>
     * Possible schema language: {@link XmlValidatorFactory}
     * 
     * @return
     */
    public String getSchemaLanguage() {
        return schemaLanguage;
    }

    /**
     * Set the schema language
     * 
     * @param schemaLanguage
     */
    public void setSchemaLanguage(String schemaLanguage) {
        this.schemaLanguage = schemaLanguage;
    }

    /**
     * Get schema list as a resource
     * 
     * @return
     */
    public Resource[] getSchemas() {
        return schemas;
    }

    /**
     * Set schemas as resources
     * 
     * @param schemas
     */
    public void setSchemas(Resource[] schemas) {
        Assert.notEmpty(schemas, "'schemas' must not be empty");
        for (Resource schema : schemas) {
            Assert.notNull(schema, "schema must not be null");
            Assert.isTrue(schema.exists(), "schema \"" + schema + "\" does not exit");
        }
        this.schemas = schemas.clone();
    }

    /**
     * Set schema as a resource
     * 
     * @param schema
     */
    public void setSchema(Resource schema) {
        setSchemas(new Resource[] {schema});
    }

    /**
     * {@inheritDoc}
     */
    public void afterPropertiesSet() throws Exception {
        if (validator == null && !ObjectUtils.isEmpty(schemas)) {
            Assert.hasLength(schemaLanguage, "schemaLanguage is required");
            for (Resource schema : schemas) {
                Assert.isTrue(schema.exists(), "schema [" + schema + "] does not exist");
            }
            if (logger.isInfoEnabled()) {
                logger.info("Validating using " + StringUtils.arrayToCommaDelimitedString(schemas));
            }
            validator = XmlValidatorFactory.createValidator(schemas, schemaLanguage);
        }
        Assert.notNull(validator, "Setting 'schema', 'schemas', 'xsdSchema', or 'xsdSchemaCollection' is required");
    }

    /**
     * {@inheritDoc}
     */
    @Override
    protected boolean doHandleOnConsume(Message message) throws NotificationException {
        return doHandle(message);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    protected boolean doHandleOnPublish(Message message) throws NotificationException {
        return doHandle(message);
    }

    /**
     * Execute the validation
     * 
     * @param message
     *            input message
     * @return true if validate, else, false
     * @throws NotificationException
     *             if any error
     */
    protected boolean doHandle(Message message) throws NotificationException {
        Source requestSource = getValidationSource(message);
        if (requestSource != null) {
            SAXParseException[] errors;
            try {
                errors = validator.validate(requestSource);
            } catch (IOException e) {
                throw new NotificationMessagingException("Could not validate notification: " + e.getMessage(), e);
            }
            if (!ObjectUtils.isEmpty(errors)) {
                return handleValidationErrors(message, errors);
            } else if (logger.isDebugEnabled()) {
                logger.debug("Request message validated");
            }
        }

        return true;
    }

    /**
     * Handle validation errors
     * 
     * @param message
     *            source message
     * @param errors
     *            error list
     * @return
     */
    protected boolean handleValidationErrors(Message message, SAXParseException[] errors) {
        for (SAXParseException error : errors) {
            logger.error("XML validation error on notification: " + error.getMessage());
        }
        throw new NotificationValidationException(errors);
    }

    /**
     * Get XML to validate as a {@link Source}
     * 
     * @param message
     * @return
     */
    protected abstract Source getValidationSource(Message message);
}
