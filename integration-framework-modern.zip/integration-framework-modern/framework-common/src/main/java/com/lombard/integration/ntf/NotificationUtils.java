package com.lombard.integration.ntf;

import com.lombard.csm.Notification;

/**
 * Utility class around {@link Notification}. Avoid to pollute code with null check.
 * 
 * @author wvandenberghe
 * 
 */
public final class NotificationUtils {

    /**
     * Default constructor.
     */
    private NotificationUtils() {
    }

    /**
     * Get the correlation ID if it exists.
     * 
     * @param notification
     * @return
     */
    public static String getCorrelationID(Notification notification) {
        if (notification.getCorrelationHandler() != null) {
            return notification.getCorrelationHandler().getId();
        }

        return null;
    }

    /**
     * Get the initiator ID if it exists.
     * 
     * @param notification
     * @return
     */
    public static String getInitiatorID(Notification notification) {
        if (notification.getCorrelationHandler() != null
                && notification.getCorrelationHandler().getInitiator() != null
                && notification.getCorrelationHandler().getInitiator().getName() != null) {
            return notification.getCorrelationHandler().getInitiator().getName().name();
        }

        return null;
    }

    /**
     * Get initiator node.
     * 
     * @param notification
     * @return
     */
    public static String getInitiatorNode(Notification notification) {
        if (notification.getCorrelationHandler() != null
                && notification.getCorrelationHandler().getInitiator() != null
                && notification.getCorrelationHandler().getInitiator().getNode() != null) {
            return notification.getCorrelationHandler().getInitiator().getNode();
        }

        return null;
    }

    /**
     * Get the business context name.
     * 
     * @param notification
     * @return
     */
    public static String getNotificationBusinessContext(Notification notification) {
        if (notification.getBusinessContext() != null) {
            return notification.getBusinessContext().getClass().getSimpleName();
        }

        return null;
    }
}
