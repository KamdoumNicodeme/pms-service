package com.lombard.integration.tntf.trace;

import com.lombard.integration.pubsub.TransactionalServiceProxyFactoryBean;

/**
 * Dedicated JMS invoker to tracing purpose.
 * 
 * @author wvandenberghe
 * 
 */
public class TraceServiceProxyFactoryBean extends TransactionalServiceProxyFactoryBean {

    private static final String DEFAULT_DESTINATION_NAME = "TNTF.TRACE";

    /**
     * Default constructor.
     * <p>
     * Apply default settings such as service interface and queue name.
     */
    public TraceServiceProxyFactoryBean() {

        setServiceInterface(TraceService.class);
        setReceiveTimeout(1);
        setQueueName(DEFAULT_DESTINATION_NAME);
    }

}
