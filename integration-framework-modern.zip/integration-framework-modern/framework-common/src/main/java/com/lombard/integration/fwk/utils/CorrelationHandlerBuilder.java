package com.lombard.integration.fwk.utils;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.UUID;

import com.lombard.cdm.ApplicationContext;
import com.lombard.cdm.CorrelationHandler;
import com.lombard.cdm.IdType;

/**
 * 
 * @author wvandenberghe
 * 
 */
public final class CorrelationHandlerBuilder {

    private static final String HOSTNAME = getHostname();

    private final CorrelationHandler correlationHandler;

    private static String getHostname() {
        try {
            return InetAddress.getLocalHost().getHostName();
        } catch (UnknownHostException e) {
            return null;
        }
    }

    /**
     * 
     */
    private CorrelationHandlerBuilder() {
        correlationHandler = new CorrelationHandler();
        correlationHandler.setId(UUID.randomUUID().toString());

        ApplicationContext applicationContext = new ApplicationContext();
        applicationContext.setNode(HOSTNAME);
        correlationHandler.setInitiator(applicationContext);
    }

    /**
     * 
     * @param correlationHandler
     */
    private CorrelationHandlerBuilder(final CorrelationHandler correlationHandler) {
        this();

        this.correlationHandler.setId(correlationHandler.getId());

        final ApplicationContext applicationContext = correlationHandler.getInitiator();
        this.name(applicationContext.getName());
    }

    private CorrelationHandlerBuilder(final String id) {
        this();

        correlationHandler.setId(id);
    }

    /**
     * 
     * @return
     */
    public static CorrelationHandlerBuilder newBuilder() {
        return new CorrelationHandlerBuilder();
    }

    /**
     * 
     * @param correlationHandler
     * @return
     */
    public static CorrelationHandlerBuilder from(final CorrelationHandler correlationHandler) {
        return new CorrelationHandlerBuilder(correlationHandler);
    }

    /**
     * 
     * @param idType
     * @return
     */
    public static CorrelationHandlerBuilder from(final IdType idType) {
        final CorrelationHandlerBuilder correlationHandlerBuilder = new CorrelationHandlerBuilder();
        correlationHandlerBuilder.name(idType);

        return correlationHandlerBuilder;
    }

    public static CorrelationHandlerBuilder from(final String id) {
        return new CorrelationHandlerBuilder(id);
    }

    /**
     * 
     * @param idType
     * @return
     */
    public CorrelationHandlerBuilder name(final IdType idType) {
        final ApplicationContext applicationContext = correlationHandler.getInitiator();
        applicationContext.setName(idType);

        return this;
    }

    /**
     * 
     * @param node
     * @return
     */
    public CorrelationHandlerBuilder node(final String node) {
        final ApplicationContext applicationContext = correlationHandler.getInitiator();
        applicationContext.setNode(node);

        return this;
    }

    /**
     * 
     * @return
     */
    public CorrelationHandler build() {
        if (correlationHandler.getInitiator().getName() == null) {
            throw new IllegalStateException("Field 'ApplicationHandler.name' is mandatory");
        }

        return correlationHandler;
    }
}
