package com.lombard.integration.tntf.trace;

import com.lombard.cdm.ActivityHandler;
import com.lombard.integration.fwk.utils.ActivityHandlerBuilder;

/**
 * Provides an interface to trace activity.
 * 
 * @author wvandenberghe
 * @see ActivityHandlerBuilder
 */
public interface TraceService {

    public void trace(ActivityHandler toSendOrReceive);

    public void traceSynchronous(ActivityHandler toSendOrReceive);
}
