package com.lombard.integration.fwk.schema;

import java.io.IOException;
import java.util.Properties;

/**
 * Default implementation for the root element name resolver.
 */
public class ElementNameResolverImpl implements ElementNameResolver {
	
	/* SINGLETON */
	
	public static ElementNameResolverImpl getInstance() {
		return SingletonHolder.INSTANCE;
	}
	
	private static class SingletonHolder {
		private static final ElementNameResolverImpl INSTANCE = new ElementNameResolverImpl();
		
		private SingletonHolder() {
			
		}
	}
	
	/* ATTRIBUTES */
	
	private final Properties cdm21Mapping;
	private final Properties cdm22Mapping;
	private final Properties csm21Mapping;
	private final Properties csm22Mapping;
	
	/* CONSTRUCTOR */
	
	private ElementNameResolverImpl() {
		// Instantiate the mapping properties.
		cdm21Mapping = new Properties();
		cdm22Mapping = new Properties();
		csm21Mapping = new Properties();
		csm22Mapping = new Properties();
		
		// Load all mappings.
		final String propertiesFileName = "cdm-xsd-mapping.properties";
		try {
			cdm21Mapping.load(ElementNameResolverImpl.class.getResourceAsStream(
					"/schemas/CDM/V2.1/" + propertiesFileName));
			cdm22Mapping.load(ElementNameResolverImpl.class.getResourceAsStream(
					"/schemas/CDM/V2.2/" + propertiesFileName));
			csm21Mapping.load(ElementNameResolverImpl.class.getResourceAsStream(
					"/schemas/CSM/V2.1/" + propertiesFileName));
			csm22Mapping.load(ElementNameResolverImpl.class.getResourceAsStream(
					"/schemas/CSM/V2.2/" + propertiesFileName));
		} catch (IOException e) {
			throw new ElementNameResolverException("Error while loading mapping between"
					+ " CDM / CSM types and XSD element names.", e);
		}
		
		
	}
	
	/* METHODS */

	public String resolveElementName(Class<?> cdmOrCsmType) {
		// Handle a null CDM / CSM type.
		if (cdmOrCsmType == null) {
			return "";
		}
		
		// Resolve the element name, depending on the CDM / CSM package and class name.
		final String packageName = cdmOrCsmType.getPackage().getName();
		final String className = cdmOrCsmType.getSimpleName();
		return resolveElementName(packageName, className);
	}

	/**
	 * Resolve the XML element name for a given CDM / CSM package name
	 * and class name.
	 * 
	 * @param packageName the CDM / CSM package name.
	 * @param className the CDM / CSM class name.
	 * @return the XML element name.
	 */
	protected String resolveElementName(String packageName, String className) {
		// Return the appropriate mapping value, depending on the object type (CDM / CSM).
		if (packageName.contains("cdm")) {
			// Take the CDM version into account.
			if (packageName.contains("v2_1")) {
				return cdm21Mapping.getProperty(className);
			} else if (packageName.contains("v2_2")) {
				return cdm22Mapping.getProperty(className);
			} else {
				throw new ElementNameResolverException(packageName + " is not a valid CDM version.");
			}
		} else if (packageName.contains("csm")) {
			// Take the CSM version into account.
			if (packageName.contains("v2_1")) {
				return csm21Mapping.getProperty(className);
			} else if (packageName.contains("v2_2")) {
				return csm22Mapping.getProperty(className);
			} else {
				throw new ElementNameResolverException(packageName + " is not a valid CSM version.");
			}
		} else {
			throw new ElementNameResolverException(packageName + " is not a valid CDM / CSM package.");
		}
	}

}
