/**
 * Package dedicated to JAXB stuff such as listeners and custom factories. 
 */
package com.lombard.integration.jaxb;