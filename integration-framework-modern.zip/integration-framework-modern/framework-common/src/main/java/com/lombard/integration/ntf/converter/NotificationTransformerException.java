package com.lombard.integration.ntf.converter;

import com.lombard.integration.ntf.NotificationException;

/**
 * 
 * @author wvandenberghe
 * 
 */
public class NotificationTransformerException extends NotificationException {

    private static final long serialVersionUID = 1L;

    /**
     * 
     * @param message
     * @param cause
     */
    public NotificationTransformerException(String message, Throwable cause) {
        super(message, cause);
    }

    /**
     * 
     * @param message
     */
    public NotificationTransformerException(String message) {
        super(message);
    }

}
