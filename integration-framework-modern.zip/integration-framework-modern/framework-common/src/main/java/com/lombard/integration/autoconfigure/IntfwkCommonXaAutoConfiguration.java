package com.lombard.integration.autoconfigure;

import jakarta.jms.ConnectionFactory;

import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.core.env.Environment;

@AutoConfiguration(after = IntfwkCommonAutoConfiguration.class)
@ConditionalOnProperty(prefix = "intfwk.jms.xa", name = "enabled", havingValue = "true")
public class IntfwkCommonXaAutoConfiguration {

    @Bean(name = "ntiTibcoXAConnectionFactory")
    @ConditionalOnClass(name = "com.tibco.tibjms.TibjmsXAQueueConnectionFactory")
    @ConditionalOnMissingBean(name = "ntiTibcoXAConnectionFactory")
    ConnectionFactory ntiTibcoXAConnectionFactory(Environment environment, IntfwkProperties properties) {
        return IntfwkTibcoConnectionFactoryBuilder.xaQueueConnectionFactory(
                environment, properties, "nti.connection", properties.getJms().getNotification());
    }

    @Bean(name = "tecTibcoXAConnectionFactory")
    @ConditionalOnClass(name = "com.tibco.tibjms.TibjmsXAQueueConnectionFactory")
    @ConditionalOnMissingBean(name = "tecTibcoXAConnectionFactory")
    ConnectionFactory tecTibcoXAConnectionFactory(Environment environment, IntfwkProperties properties) {
        return IntfwkTibcoConnectionFactoryBuilder.xaQueueConnectionFactory(
                environment, properties, "tec.connection", properties.getJms().getTechnical());
    }
}
