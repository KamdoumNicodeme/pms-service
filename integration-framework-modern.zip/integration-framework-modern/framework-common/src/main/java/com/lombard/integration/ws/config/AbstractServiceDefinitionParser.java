package com.lombard.integration.ws.config;

import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.beans.factory.support.BeanDefinitionBuilder;
import org.springframework.beans.factory.support.BeanDefinitionRegistry;
import org.springframework.beans.factory.xml.ParserContext;
import org.springframework.ws.WebServiceMessageFactory;
import org.springframework.ws.soap.saaj.SaajSoapMessageFactory;

import com.lombard.integration.config.AbstractIntfwkDefinitionParser;
import com.sun.xml.messaging.saaj.soap.ver1_1.SOAPMessageFactory1_1Impl;

/**
 * Definition parser specific to web service.
 * 
 * @author wvandenberghe
 * 
 */
public abstract class AbstractServiceDefinitionParser extends AbstractIntfwkDefinitionParser {

    private static final String DEFAULT_SOAP_MESSAGE_FACTORY = "defaultSoapMessageFactory";

    /**
     * Get the {@link WebServiceMessageFactory} from the current context.
     * 
     * @param parserContext
     * @return
     */
    protected String getMessageFactory(ParserContext parserContext) {
        BeanDefinitionRegistry registry = parserContext.getRegistry();

        if (!registry.isBeanNameInUse(DEFAULT_SOAP_MESSAGE_FACTORY)) {
            BeanDefinitionBuilder builder =
                    BeanDefinitionBuilder.genericBeanDefinition(SaajSoapMessageFactory.class);

            builder.addPropertyValue("langAttributeOnSoap11FaultString", false);

            BeanDefinition messageFactory = getMessageFactoryImpl();
            builder.addPropertyValue("messageFactory", messageFactory);

            registry.registerBeanDefinition(DEFAULT_SOAP_MESSAGE_FACTORY, builder.getBeanDefinition());
        }

        return DEFAULT_SOAP_MESSAGE_FACTORY;
    }

    /**
     * Needed by CLASS as it is running on JBoss.
     * 
     * @return
     */
    private BeanDefinition getMessageFactoryImpl() {
        BeanDefinitionBuilder builder = BeanDefinitionBuilder.genericBeanDefinition(SOAPMessageFactory1_1Impl.class);

        return builder.getBeanDefinition();
    }
}
