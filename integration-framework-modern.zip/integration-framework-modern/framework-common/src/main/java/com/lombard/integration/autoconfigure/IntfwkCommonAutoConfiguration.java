package com.lombard.integration.autoconfigure;

import jakarta.jms.ConnectionFactory;

import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;

import com.lombard.integration.config.AbstractIntfwkDefinitionParser;
import com.lombard.integration.jaxb.CollectionJaxBListener;
import com.lombard.integration.jaxb.JaxbMarshallerFactoryBean;

@AutoConfiguration
@EnableConfigurationProperties(IntfwkProperties.class)
@PropertySource(value = "classpath:/intfwk/env-config.properties", ignoreResourceNotFound = true)
public class IntfwkCommonAutoConfiguration {

    @Bean
    @ConditionalOnMissingBean
    CollectionJaxBListener collectionJaxBListener() {
        return new CollectionJaxBListener();
    }

    @Bean(AbstractIntfwkDefinitionParser.DEFAULT_MODEL_MARSHALLER)
    @ConditionalOnMissingBean(name = AbstractIntfwkDefinitionParser.DEFAULT_MODEL_MARSHALLER)
    JaxbMarshallerFactoryBean defaultModelMarshaller(CollectionJaxBListener collectionJaxBListener) {
        JaxbMarshallerFactoryBean factoryBean = new JaxbMarshallerFactoryBean();
        factoryBean.setMarshallerListener(collectionJaxBListener);
        return factoryBean;
    }

    @Bean(name = "connectionFactory")
    @ConditionalOnClass(name = "com.tibco.tibjms.TibjmsQueueConnectionFactory")
    @ConditionalOnMissingBean(name = "connectionFactory")
    ConnectionFactory connectionFactory(Environment environment, IntfwkProperties properties) {
        return IntfwkTibcoConnectionFactoryBuilder.queueConnectionFactory(
                environment, properties, "jms.connection", properties.getJms().getConnection());
    }

    @Bean(name = "legConnectionFactory")
    @ConditionalOnClass(name = "com.tibco.tibjms.TibjmsQueueConnectionFactory")
    @ConditionalOnMissingBean(name = "legConnectionFactory")
    ConnectionFactory legConnectionFactory(Environment environment, IntfwkProperties properties) {
        return IntfwkTibcoConnectionFactoryBuilder.queueConnectionFactory(
                environment, properties, "leg.connection", properties.getJms().getLegacy());
    }

    @Bean(name = "tecConnectionFactory")
    @ConditionalOnClass(name = "com.tibco.tibjms.TibjmsQueueConnectionFactory")
    @ConditionalOnMissingBean(name = "tecConnectionFactory")
    ConnectionFactory tecConnectionFactory(Environment environment, IntfwkProperties properties) {
        return IntfwkTibcoConnectionFactoryBuilder.queueConnectionFactory(
                environment, properties, "tec.connection", properties.getJms().getTechnical());
    }

    @Bean(name = "svcConnectionFactory")
    @ConditionalOnClass(name = "com.tibco.tibjms.TibjmsQueueConnectionFactory")
    @ConditionalOnMissingBean(name = "svcConnectionFactory")
    ConnectionFactory svcConnectionFactory(Environment environment, IntfwkProperties properties) {
        return IntfwkTibcoConnectionFactoryBuilder.queueConnectionFactory(
                environment, properties, "svc.connection", properties.getJms().getService());
    }

    @Bean(name = "ntiConnectionFactory")
    @ConditionalOnClass(name = "com.tibco.tibjms.TibjmsQueueConnectionFactory")
    @ConditionalOnMissingBean(name = "ntiConnectionFactory")
    ConnectionFactory ntiConnectionFactory(Environment environment, IntfwkProperties properties) {
        return IntfwkTibcoConnectionFactoryBuilder.queueConnectionFactory(
                environment, properties, "nti.connection", properties.getJms().getNotification());
    }

    @Bean(name = "apmLoggerContextFactory")
    @ConditionalOnClass(name = "com.lombard.apm.logger.impl.ApmLoggerContextFactory")
    @ConditionalOnMissingBean(name = "apmLoggerContextFactory")
    Object apmLoggerContextFactory(Environment environment, IntfwkProperties properties) {
        try {
            Object factory = Class.forName("com.lombard.apm.logger.impl.ApmLoggerContextFactory")
                    .getDeclaredConstructor()
                    .newInstance();
            String applicationName = properties.getClient().getId();
            if (applicationName == null) {
                applicationName = environment.getProperty("client.id");
            }
            if (applicationName != null) {
                new org.springframework.beans.BeanWrapperImpl(factory)
                        .setPropertyValue("applicationName", applicationName);
            }
            return factory;
        } catch (ReflectiveOperationException e) {
            throw new IllegalStateException("Cannot create APM logger context factory", e);
        }
    }
}
