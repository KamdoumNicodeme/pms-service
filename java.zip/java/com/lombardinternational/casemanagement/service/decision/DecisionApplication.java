package com.lombardinternational.casemanagement.service.decision;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;

@SpringBootApplication
@EnableFeignClients(basePackages = "com.lombardinternational.clients.classapp.client")
public class DecisionApplication {

    public static void main(String[] args) {

        SpringApplication.run(DecisionApplication.class, args);
    }

}
