package com.lombardinternational.casemanagement.service.decision.domain.service.taskscreen.common.groups;

import org.springframework.stereotype.Service;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Group;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Tab;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.taskscreen.TaskScreenGroupBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.taskscreen.common.fields.CommonIcPreliminaryPolicyTypeFieldsBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.utils.RulesUtils;

import lombok.AllArgsConstructor;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.TaskScreenConstants.PRELIMINARY_TYPE_GROUP;

@Service
@AllArgsConstructor
public class CommonPreliminaryPolicyTypeGroupBuilderService implements TaskScreenGroupBuilderService {

    private CommonIcPreliminaryPolicyTypeFieldsBuilderService service;

    @Override
    public void buildGroup(
            final WebForm webForm,
            final ScreenDescription screenCheckList,
            final ScreenDescription screenToFill,
            final Tab parentTab) {

        var checklistDataGroup = RulesUtils.getGroupInTab(parentTab, PRELIMINARY_TYPE_GROUP);
        if (checklistDataGroup == null) {
            checklistDataGroup = Group.builder().groupId(PRELIMINARY_TYPE_GROUP).build();
            parentTab.getGroups().add(checklistDataGroup);
        }
        checklistDataGroup.setIsActive(true);
        checklistDataGroup.incrementOrder();
        checklistDataGroup.setTitle("Preliminary Policy Type Under CAA Rules (If Required)");
        service.buildField(webForm, screenCheckList, screenToFill, checklistDataGroup);
    }
}
