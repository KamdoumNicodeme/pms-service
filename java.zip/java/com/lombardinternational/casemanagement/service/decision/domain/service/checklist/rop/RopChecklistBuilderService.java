package com.lombardinternational.casemanagement.service.decision.domain.service.checklist.rop;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ChecklistFieldConstants.*;

import java.util.*;

import org.springframework.stereotype.Service;

import com.lombardinternational.casemanagement.service.decision.domain.model.policy.Policy;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Group;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Tab;
import com.lombardinternational.casemanagement.service.decision.domain.model.transaction.BusinessTransaction;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.checklist.ChecklistBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.checklist.GroupBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.checklist.rop.group.*;
import com.lombardinternational.casemanagement.service.decision.domain.utils.RulesUtils;
import com.lombardinternational.casemanagement.service.decision.domain.utils.constants.RulesConstants;

import lombok.AllArgsConstructor;

@Service
@AllArgsConstructor
public class RopChecklistBuilderService implements ChecklistBuilderService {

    private final GeneralDetailsRopGroupBuilderService generalDetailsRopGroupBuilderService;
    private final TransactionDetailsRopGroupBuilderService transactionDetailsRopGroupBuilderService;
    private final ThirdPartyRopGroupBuilderService thirdPartyRopGroupBuilderService;
    private final CaseRiskRopGroupBuilderService caseRiskRopGroupBuilderService;

    @Override
    public ScreenDescription buildChecklist(final WebForm webForm, final ScreenDescription screenDescription, final Policy policy,
            final BusinessTransaction transaction) {

        final var checklist = Optional.ofNullable(RulesUtils.getTabInScreenDescription(screenDescription, CHECKLIST_TAB))
                .orElse(Tab.builder().tabId(CHECKLIST_TAB).order(1).type("FormTab").label("Checklist").build());
        checklist.setIsActive(true);

        screenDescription.setTabs(Collections.singletonList(checklist));

        Group.resetGroupId();
        Map<String,List<String>> overallCaseRisk = Map.of(RulesConstants.PROHIBITED, new ArrayList<>(), RulesConstants.HIGH, new ArrayList<>(),
                RulesConstants.EXCEPTION, new ArrayList<>(), RulesConstants.MEDIUM, new ArrayList<>(), RulesConstants.STANDARD, new ArrayList<>(),
                RulesConstants.BLOCKED, new ArrayList<>());
        List<GroupBuilderService> groupBuilderServices = Arrays.asList(generalDetailsRopGroupBuilderService,
                transactionDetailsRopGroupBuilderService, thirdPartyRopGroupBuilderService, caseRiskRopGroupBuilderService);
        groupBuilderServices.forEach(groupBuilderService -> groupBuilderService.buildGroup(webForm, screenDescription, checklist, policy,
                transaction, overallCaseRisk));
        return screenDescription;
    }
}
