package com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ControlDefinition;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.AbstractControlBuilderService;
import org.springframework.stereotype.Service;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ControlConstants.CHECK_ACCOUNT_OPEN_NAME;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ControlConstants.CHECK_ACCOUNT_OPEN_TYPE;

@Service
public class CheckAccountOpenControlBuilderService extends AbstractControlBuilderService {

    @Override
    public ControlDefinition buildControl(WebForm webForm, ScreenDescription screenDescription) {
        return buildControlDefinition();
    }

    @Override
    protected String getControlName() {
        return CHECK_ACCOUNT_OPEN_NAME;
    }

    @Override
    protected String getControlType() {
        return CHECK_ACCOUNT_OPEN_TYPE;
    }
}
