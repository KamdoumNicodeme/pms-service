package com.lombardinternational.casemanagement.service.decision.domain.service.taskscreen.rop.subtask;

import java.util.List;

import org.springframework.stereotype.Service;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Group;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Tab;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.taskscreen.SubTaskScreenBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.taskscreen.common.groups.CommonAssetsInadmissibleGroupBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.taskscreen.common.groups.CommonAssetsNotPermittedGroupBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.taskscreen.common.groups.CommonComplexAssetsGroupBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.taskscreen.common.groups.CommonDistressedGroupBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.taskscreen.common.groups.CommonDocumentationGroupBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.taskscreen.common.groups.CommonIdentificationOfAssetsGroupBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.taskscreen.common.groups.CommonIdentificationOfRegulatedBusinessGroupBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.taskscreen.common.groups.CommonIdentificationOfSmallCapGroupBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.taskscreen.common.groups.CommonInadmissibleGroupBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.taskscreen.common.groups.CommonNtaGroupBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.taskscreen.common.groups.CommonPreliminaryPolicyTypeGroupBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.taskscreen.rop.groups.icrop.IcGeneralInformationGroupBuilderService;

import lombok.AllArgsConstructor;

@Service
@AllArgsConstructor
public class IcRopSubTaskScreenBuilderService implements SubTaskScreenBuilderService {

    public static String SUB_TASK_SCREEN_ID = "IC_ROP";

    private final IcGeneralInformationGroupBuilderService icGeneralInformationGroupBuilderService;
    private final CommonPreliminaryPolicyTypeGroupBuilderService commonPreliminaryPolicyTypeGroupBuilderService;
    private final CommonNtaGroupBuilderService commonNtaGroupBuilderService;
    private final CommonDistressedGroupBuilderService commonDistressedGroupBuilderService;
    private final CommonInadmissibleGroupBuilderService commonInadmissibleGroupBuilderService;
    private final CommonAssetsInadmissibleGroupBuilderService commonAssetsInadmissibleGroupBuilderService;
    private final CommonAssetsNotPermittedGroupBuilderService commonAssetsNotPermittedGroupBuilderService;
    private final CommonComplexAssetsGroupBuilderService commonComplexAssetsGroupBuilderService;
    private final CommonIdentificationOfAssetsGroupBuilderService commonIdentificationOfAssetsGroupBuilderService;
    private final CommonIdentificationOfSmallCapGroupBuilderService commonIdentificationOfSmallCapGroupBuilderService;
    private final CommonIdentificationOfRegulatedBusinessGroupBuilderService commonIdentificationOfRegulatedBusinessGroupBuilderService;
    private final CommonDocumentationGroupBuilderService commonDocumentationGroupBuilderService;

    @Override
    public ScreenDescription buildSubTaskScreen(
            final WebForm webForm,
            final ScreenDescription screenCheckList,
            final ScreenDescription screenToFill,
            final Tab parentTab) {
        Group.resetGroupId();

        var services = List.of(icGeneralInformationGroupBuilderService, commonPreliminaryPolicyTypeGroupBuilderService,
                commonNtaGroupBuilderService, commonDistressedGroupBuilderService, commonInadmissibleGroupBuilderService,
                commonAssetsInadmissibleGroupBuilderService, commonAssetsNotPermittedGroupBuilderService,
                commonComplexAssetsGroupBuilderService, commonIdentificationOfAssetsGroupBuilderService,
                commonIdentificationOfSmallCapGroupBuilderService, commonIdentificationOfRegulatedBusinessGroupBuilderService,
                commonDocumentationGroupBuilderService);
        services.forEach(service -> service.buildGroup(webForm, screenCheckList, screenToFill, parentTab));

        return screenToFill;
    }


    @Override
    public Boolean filterService(final String subTaskScreenId) {
        return SUB_TASK_SCREEN_ID.equals(subTaskScreenId);
    }
}
