package com.lombardinternational.casemanagement.service.decision.domain.spi.web;

import java.util.List;

import com.lombardinternational.casemanagement.service.decision.domain.model.policy.EboPolicyNav;
import com.lombardinternational.casemanagement.service.decision.domain.model.policy.RiskFactorResult;

public interface ComplianceWebService {

    List<RiskFactorResult> evaluateRiskFactors(final String transactionNumber, final List<String> factorIds) throws Exception;

    EboPolicyNav getSameEboPolicyNav(final String policyNumber, final String transactionNumber, final String currency) throws Exception;
}
