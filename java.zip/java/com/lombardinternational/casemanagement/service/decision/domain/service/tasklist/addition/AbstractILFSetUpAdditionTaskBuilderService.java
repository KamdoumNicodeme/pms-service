package com.lombardinternational.casemanagement.service.decision.domain.service.tasklist.addition;

import com.lombardinternational.casemanagement.service.decision.domain.service.tasklist.AbstractTaskBuilderService;

public abstract class AbstractILFSetUpAdditionTaskBuilderService extends AbstractTaskBuilderService {

    @Override
    public String getTaskName() {

        return "ILF Set up";
    }

    @Override
    public String getTaskDynamicScreenId() {

        return "";
    }
}
