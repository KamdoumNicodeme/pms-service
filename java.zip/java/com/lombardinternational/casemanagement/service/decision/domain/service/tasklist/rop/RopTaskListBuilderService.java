package com.lombardinternational.casemanagement.service.decision.domain.service.tasklist.rop;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.lombardinternational.casemanagement.service.decision.domain.service.tasklist.rop.task.ILFSetUpRopTaskBuilderService;
import org.springframework.stereotype.Service;

import com.lombardinternational.casemanagement.service.decision.domain.model.policy.Policy;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.TaskDefinition;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.tasklist.AbstractTaskBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.tasklist.TaskListBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.tasklist.common.task.CommonAMLSignOffTaskBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.tasklist.common.task.CommonFreeTaskTaskBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.tasklist.rop.task.dot.AssetTransferDOTRopTaskBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.tasklist.rop.task.dot.DefaultOptionalDOTRopTaskBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.tasklist.rop.task.ic.AssetTransferICRopTaskBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.tasklist.rop.task.ic.DefaultOptionalICRopTaskBuilderService;

import lombok.AllArgsConstructor;

@Service
@AllArgsConstructor
public class RopTaskListBuilderService implements TaskListBuilderService {

    private final AssetTransferICRopTaskBuilderService assetTransferICTaskBuilderService;
    private final DefaultOptionalICRopTaskBuilderService defaultOptionalICTaskBuilderService;
    private final AssetTransferDOTRopTaskBuilderService assetTransferDOTTaskBuilderService;
    private final DefaultOptionalDOTRopTaskBuilderService defaultOptionalDOTTaskBuilderService;
    private final PremiumChasingTaskRopTaskBuilderService premiumChasingTaskRopTaskBuilderService;
    private final CommonFreeTaskTaskBuilderService commonFreeTaskTaskBuilderService;
    private final CommonAMLSignOffTaskBuilderService commonAmlSignOffTaskBuilderService;
    private final ILFSetUpRopTaskBuilderService ilfSetUpRopTaskBuilderService;

    @Override
    public List<TaskDefinition> buildTaskList(final Policy policy, final WebForm webForm, final ScreenDescription screenDescription) {

        TaskDefinition.resetTaskOrder();
        List<AbstractTaskBuilderService> taskBuilderServices = Arrays.asList(defaultOptionalICTaskBuilderService,
                assetTransferICTaskBuilderService, defaultOptionalDOTTaskBuilderService, assetTransferDOTTaskBuilderService,
                premiumChasingTaskRopTaskBuilderService, commonFreeTaskTaskBuilderService, commonAmlSignOffTaskBuilderService,
                ilfSetUpRopTaskBuilderService);
        final var taskDefinitions = new ArrayList<TaskDefinition>();
        taskBuilderServices.forEach(service -> service.buildTask(policy, webForm, screenDescription, taskDefinitions));
        return taskDefinitions;
    }
}
