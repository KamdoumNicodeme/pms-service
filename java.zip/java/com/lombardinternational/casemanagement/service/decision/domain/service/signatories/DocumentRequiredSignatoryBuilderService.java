package com.lombardinternational.casemanagement.service.decision.domain.service.signatories;

import java.util.List;

import com.lombardinternational.casemanagement.service.decision.domain.model.policy.Policy;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.DocumentRequiredSignatory;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.RequiredSignatory;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;

public interface DocumentRequiredSignatoryBuilderService {

    void buildRequiredSignatory(final WebForm webForm, final Policy policy, final List<DocumentRequiredSignatory> documentRequiredSignatories,
            final List<RequiredSignatory> signatories);
}
