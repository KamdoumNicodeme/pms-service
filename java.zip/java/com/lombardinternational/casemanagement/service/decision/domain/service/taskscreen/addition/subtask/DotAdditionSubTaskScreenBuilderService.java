package com.lombardinternational.casemanagement.service.decision.domain.service.taskscreen.addition.subtask;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Group;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Tab;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.taskscreen.SubTaskScreenBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.taskscreen.addition.groups.ChecklistControlsDataGroupBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.taskscreen.common.groups.CommonDotGeneralInformationGroupBuilderService;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@AllArgsConstructor
public class DotAdditionSubTaskScreenBuilderService implements SubTaskScreenBuilderService {

    public static String SUB_TASK_SCREEN_ID = "DOT_ADDITION";

    private final CommonDotGeneralInformationGroupBuilderService commonDotGeneralInformationGroupBuilderService;
    private final ChecklistControlsDataGroupBuilderService checklistControlsDataGroupBuilderService;


    @Override
    public ScreenDescription buildSubTaskScreen(WebForm webForm, ScreenDescription screenCheckList, ScreenDescription screenToFill,
            Tab parentTab) {

        Group.resetGroupId();
        commonDotGeneralInformationGroupBuilderService.buildGroup(webForm, screenCheckList, screenToFill, parentTab);
        checklistControlsDataGroupBuilderService.buildGroup(webForm, screenCheckList, screenToFill, parentTab);

        return screenToFill;
    }

    public Boolean filterService(String subTaskScreenId) {

        return SUB_TASK_SCREEN_ID.equals(subTaskScreenId);
    }
}
