package com.lombardinternational.casemanagement.service.decision.domain.service;

import java.time.LocalDate;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.function.Supplier;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.lombardinternational.casemanagement.service.decision.domain.model.policy.AbstractPerson;
import com.lombardinternational.casemanagement.service.decision.domain.model.policy.Beneficiary;
import com.lombardinternational.casemanagement.service.decision.domain.model.policy.CessionHolder;
import com.lombardinternational.casemanagement.service.decision.domain.model.policy.EconomicBeneficiary;
import com.lombardinternational.casemanagement.service.decision.domain.model.policy.Holder;
import com.lombardinternational.casemanagement.service.decision.domain.model.policy.LifeAssured;
import com.lombardinternational.casemanagement.service.decision.domain.model.policy.Policy;
import com.lombardinternational.casemanagement.service.decision.domain.model.policy.PolicyLink;
import com.lombardinternational.casemanagement.service.decision.domain.model.policy.PolicyRole;
import com.lombardinternational.casemanagement.service.decision.domain.model.policy.PolicyValues;
import com.lombardinternational.casemanagement.service.decision.domain.model.policy.Proxy;
import com.lombardinternational.casemanagement.service.decision.domain.model.policy.Settlor;
import com.lombardinternational.casemanagement.service.decision.domain.model.policy.Trust;
import com.lombardinternational.casemanagement.service.decision.domain.model.policy.Trustee;
import com.lombardinternational.casemanagement.service.decision.domain.model.transaction.BusinessTransaction;
import com.lombardinternational.casemanagement.service.decision.domain.spi.web.PolicyWebService;

import lombok.AllArgsConstructor;

@Service
@AllArgsConstructor
public class PolicyService {

    private static final String DISTRIBUTION_NETWORK = "DISTRIBUTION_NETWORK";
    private static final String CHANGE_PARTNER_STRUCTURE = "CHANGE_PARTNER_STRUCTURE";
    private final PolicyWebService policyService;
    private final FundService fundService;

    public Policy getPolicyDetails(final String policyNumber) throws Exception {

        var policy = policyService.getPolicyDetails(policyNumber);
        if (policy != null) {
            policy.setBlocks(policyService.getBlocks(policyNumber));
            policy.setHeldILF(fundService.containsILFFund(policyNumber));
            policy.setBrokerChangeWithinLast3Months(hasMadeChangeWithinLast3Months(policyNumber));
            PolicyValues policyValues = policyService.getPolicyValues(policyNumber);
            policy.setNavInPolicyCurrency(policyValues.getActuarialValue());
            policy.setSurrenderLiquidValue(policyValues.getSurrenderLiquidValue());
            policy.setNavInEurCurrency(
                    policyValues.getActuarialValueInEur() == null ? policyValues.getActuarialValue() : policyValues.getActuarialValueInEur());

            buildPolicyRole(policy);
            buildPolicyLink(policy);
            policy.setHolderAndEBODifferent(policyRoleAreDifferent(policy.getHolders(), policy.getEconomicBeneficiaries()));
            policy.setHolderAndLifeAssuredDifferent(policyRoleAreDifferent(policy.getHolders(), policy.getLifeAssureds()));
            policy.setBeneficiaryAndLifeAssuredDifferent(policyRoleAreDifferent(policy.getBeneficiaries(), policy.getLifeAssureds()));
        }
        return policy;
    }

    private Boolean hasMadeChangeWithinLast3Months(final String policyNumber) throws Exception {

        var transactions = policyService.getBusinessTransactions(policyNumber);

        var currentDate = LocalDate.now().minusMonths(3);
        return transactions.stream()
                .filter(transaction -> DISTRIBUTION_NETWORK.equals(transaction.getCategory())
                        && CHANGE_PARTNER_STRUCTURE.equals(transaction.getSubCategory()))
                .map(BusinessTransaction::getClosingDate).filter(Objects::nonNull).anyMatch(currentDate::isAfter);
    }

    private void buildPolicyRole(final Policy policy) throws Exception {

        var policyRoles = policyService.getPolicyRoles(policy.getNumber());

        policy.setHolders(getSpecificRole(Holder.class, policyRoles));
        policy.setCessionHolders(getSpecificRole(CessionHolder.class, policyRoles));
        policy.setLifeAssureds(getSpecificRole(LifeAssured.class, policyRoles));
        policy.setEconomicBeneficiaries(getSpecificRole(EconomicBeneficiary.class, policyRoles));
        policy.setTrustees(getSpecificRole(Trustee.class, policyRoles));
        policy.setTrusts(getSpecificRole(Trust.class, policyRoles));
        policy.setProxies(getSpecificRole(Proxy.class, policyRoles));
        policy.setSettlors(getSpecificRole(Settlor.class, policyRoles));
        List<Beneficiary> beneficiaries = getSpecificRole(Beneficiary.class, policyRoles);
        policy.setBeneficiaries(beneficiaries.stream().filter(beneficiary -> !beneficiary.getIrrevocableFlag()).toList());
        policy.setIrrevocableBeneficiaries(beneficiaries.stream().filter(Beneficiary::getIrrevocableFlag).toList());

        policy.setThirdParties(
                policyRoles.stream().map(PolicyRole::getThirdParties).filter(Objects::nonNull).distinct().flatMap(Collection::stream).toList());
    }

    private void buildPolicyLink(final Policy policy) throws Exception {

        Collection<AbstractPerson> linkedThirdParties = policyService.getPolicyLinks(policy.getNumber());

        PolicyLink policyLink = new PolicyLink();
        policyLink.setThirdParties(linkedThirdParties.stream().toList());
        policy.setPolicyLinks(Collections.singletonList(policyLink));
    }

    private < T extends PolicyRole > List<T> getSpecificRole(final Class<T> classType, List<PolicyRole> roles) {

        return roles.stream().filter(classType::isInstance).map(classType::cast).toList();
    }

    private Boolean policyRoleAreDifferent(final List<? extends PolicyRole> policyRolesA, final List<? extends PolicyRole> policyRolesB) {

        final Supplier<Stream<? extends PolicyRole>> streamRoleA =
                () -> Optional.ofNullable(policyRolesA).map(Collection::stream).orElseGet(Stream::empty);
        final Supplier<Stream<? extends PolicyRole>> streamRoleB =
                () -> Optional.ofNullable(policyRolesB).map(Collection::stream).orElseGet(Stream::empty);

        final List<String> roleAIds = streamRoleA.get().map(PolicyRole::getThirdParties).filter(Objects::nonNull).flatMap(Collection::stream)
                .map(AbstractPerson::getThirdPartyId).toList();

        final List<String> roleBIds = streamRoleB.get().map(PolicyRole::getThirdParties).filter(Objects::nonNull).flatMap(Collection::stream)
                .map(AbstractPerson::getThirdPartyId).collect(Collectors.toList());

        roleBIds.removeAll(roleAIds);
        return !CollectionUtils.isEmpty(roleBIds);
    }
}
