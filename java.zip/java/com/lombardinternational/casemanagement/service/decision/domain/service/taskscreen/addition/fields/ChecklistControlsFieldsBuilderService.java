package com.lombardinternational.casemanagement.service.decision.domain.service.taskscreen.addition.fields;

import org.springframework.stereotype.Service;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Field;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Group;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.SelectInputField;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.TextAreaField;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.taskscreen.TaskScreenFieldBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.spi.repository.ReferenceDataRepositoryService;
import com.lombardinternational.casemanagement.service.decision.domain.utils.ChecklistUtils;

import lombok.AllArgsConstructor;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ReferenceConstants.YES_NO_DOMAIN;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.TaskScreenConstants.ADDITIONAL_RESEARCH_FIELD;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.TaskScreenConstants.PCS_CHECKS_COMMENTS_FIELD;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.TaskScreenConstants.PCS_CHECKS_PERFORMED_FIELD;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.TaskScreenConstants.RISK_ASSESSMENT_FIELD;

@Service
@AllArgsConstructor
public class ChecklistControlsFieldsBuilderService implements TaskScreenFieldBuilderService {

    private final ReferenceDataRepositoryService referenceDataRepositoryService;

    @Override
    public void buildField(final WebForm webForm, final ScreenDescription screenCheckList, final ScreenDescription screenToFill,
            final Group group) {

        Field.resetFieldId();
        evaluatePcsChecksPerformed(group);
        evaluatePcsChecksComments(group);
        evaluateAdditionalResearch(group);
        evaluateRiskAssessment(group);
    }

    private void evaluatePcsChecksPerformed(Group group) {

        var pcsChecksPerformed = (SelectInputField) ChecklistUtils.getFieldInGroup(group, PCS_CHECKS_PERFORMED_FIELD);
        if (pcsChecksPerformed == null) {
            pcsChecksPerformed = SelectInputField.builder().fieldId(PCS_CHECKS_PERFORMED_FIELD).build();
            group.getFields().add(pcsChecksPerformed);
        }
        pcsChecksPerformed.setIsActive(true);
        pcsChecksPerformed.incrementOrder();
        pcsChecksPerformed.setEnabled(Boolean.TRUE);
        pcsChecksPerformed.setMandatory(Boolean.TRUE);
        pcsChecksPerformed.setLabel("PCS checks performed on client(s) verification completed");
        pcsChecksPerformed.setOptions(referenceDataRepositoryService.getReferenceDataOptionsByDomain(YES_NO_DOMAIN));
    }

    private void evaluatePcsChecksComments(Group group) {

        var pcsChecksComments = (TextAreaField) ChecklistUtils.getFieldInGroup(group, PCS_CHECKS_COMMENTS_FIELD);
        if (pcsChecksComments == null) {
            pcsChecksComments = TextAreaField.builder().fieldId(PCS_CHECKS_COMMENTS_FIELD).build();
            group.getFields().add(pcsChecksComments);
        }
        pcsChecksComments.setIsActive(true);
        pcsChecksComments.incrementOrder();
        pcsChecksComments.setLabel("Comments");
        pcsChecksComments.setEnabled(Boolean.TRUE);
        pcsChecksComments.setDisplayIf("#" + PCS_CHECKS_PERFORMED_FIELD + "# == \"NO\"");
    }

    private void evaluateAdditionalResearch(Group group) {

        var additionalResearch = (TextAreaField) ChecklistUtils.getFieldInGroup(group, ADDITIONAL_RESEARCH_FIELD);
        if (additionalResearch == null) {
            additionalResearch = TextAreaField.builder().fieldId(ADDITIONAL_RESEARCH_FIELD).build();
            group.getFields().add(additionalResearch);
        }
        additionalResearch.setIsActive(true);
        additionalResearch.incrementOrder();
        additionalResearch.setLabel("Compliance additional research");
        additionalResearch.setEnabled(Boolean.TRUE);
    }

    private void evaluateRiskAssessment(Group group) {

        var riskAssessment = (TextAreaField) ChecklistUtils.getFieldInGroup(group, RISK_ASSESSMENT_FIELD);
        if (riskAssessment == null) {
            riskAssessment = TextAreaField.builder().fieldId(RISK_ASSESSMENT_FIELD).build();
            group.getFields().add(riskAssessment);
        }
        riskAssessment.setIsActive(true);
        riskAssessment.incrementOrder();
        riskAssessment.setLabel("Compliance risk assessment");
        riskAssessment.setEnabled(Boolean.TRUE);
    }
}
