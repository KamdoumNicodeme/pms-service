package com.lombardinternational.casemanagement.service.decision.domain.model.transaction;

import java.util.List;

import com.lombardinternational.casemanagement.service.decision.domain.model.policy.Amount;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class BusinessTransactionProductComponent {

    private Amount expectedAmountInPolicyCurrency;
    private List<Payment> payments;
}
