package com.lombardinternational.casemanagement.service.decision.domain.service.signatories.addition;

import java.util.List;

import org.springframework.stereotype.Component;

import com.lombardinternational.casemanagement.service.decision.domain.service.signatories.AbstractDocumentRequiredSignatoryBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.signatories.addition.procuration.ProcurationCONT3048;
import com.lombardinternational.casemanagement.service.decision.domain.service.signatories.addition.procuration.ProcurationCONT3198;
import com.lombardinternational.casemanagement.service.decision.domain.service.signatories.addition.procuration.ProcurationCONT3199;
import com.lombardinternational.casemanagement.service.decision.domain.service.signatories.addition.procuration.ProcurationCONT4549;
import com.lombardinternational.casemanagement.service.decision.domain.service.signatories.addition.procuration.ProcurationCONT4874;
import com.lombardinternational.casemanagement.service.decision.domain.service.signatories.addition.procuration.ProcurationCONT4875;

import lombok.RequiredArgsConstructor;

@Component
@RequiredArgsConstructor
public class AdditionSignatoriesProcurationProvider {

    private final ProcurationCONT4874 procurationCONT4874;
    private final ProcurationCONT4875 procurationCONT4875;
    private final ProcurationCONT4549 procurationCONT4549;
    private final ProcurationCONT3198 procurationCONT3198;
    private final ProcurationCONT3199 procurationCONT3199;
    private final ProcurationCONT3048 procurationCONT3048;

    public List<AbstractDocumentRequiredSignatoryBuilderService> getAll() {

        return List.of(procurationCONT4874, procurationCONT4875, procurationCONT4549, procurationCONT3198, procurationCONT3199,
                procurationCONT3048);
    }
}
