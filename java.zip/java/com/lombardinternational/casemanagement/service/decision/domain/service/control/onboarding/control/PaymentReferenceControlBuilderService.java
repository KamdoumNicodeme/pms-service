package com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control;

import java.util.List;

import org.springframework.stereotype.Service;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ControlDefinition;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.AbstractControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.utils.Constraint;
import com.lombardinternational.casemanagement.service.decision.domain.utils.FieldConstraint;

import static com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control.common.Constants.BROK_ACCO;
import static com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control.common.Constants.TAX_AUTH;
import static com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control.common.Constants.TRANSF_COMP;
import static com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control.common.Utils.createConstraintWithMultipleAndExactMatch;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ChecklistFieldConstants.LINK_THIRD_PARTY_PH;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ControlConstants.PAYMENT_REFERENCE_NAME;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ControlConstants.PAYMENT_REFERENCE_TYPE;

@Service(value = "onboardingPaymentReferenceControlBuilderService")
public class PaymentReferenceControlBuilderService extends AbstractControlBuilderService {

    @Override
    public ControlDefinition buildControl(WebForm webForm, ScreenDescription screenDescription) {

        final List<FieldConstraint> constraints = List.of(createConstraintWithMultipleAndExactMatch(LINK_THIRD_PARTY_PH, Constraint.IN,
                Boolean.TRUE, Boolean.FALSE, List.of(TAX_AUTH, TRANSF_COMP, BROK_ACCO)));

        if (constraints.stream().allMatch(constraint -> constraint.test(screenDescription))) {
            return buildControlDefinition();
        }
        return null;
    }

    @Override
    protected String getControlName() {

        return PAYMENT_REFERENCE_NAME;
    }

    @Override
    protected String getControlType() {

        return PAYMENT_REFERENCE_TYPE;
    }
}
