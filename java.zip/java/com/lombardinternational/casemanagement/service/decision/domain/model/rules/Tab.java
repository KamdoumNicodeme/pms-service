package com.lombardinternational.casemanagement.service.decision.domain.model.rules;

import java.util.ArrayList;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class Tab {

    private String tabId;
    private String label;
    private String i18NLabelKey;
    private int order;
    private boolean triggersRecomputeScreen;
    private String type;
    @Builder.Default
    private List<Group> groups = new ArrayList<>();
    private String displayIf;
    @Builder.Default
    private Boolean isActive = Boolean.FALSE;

    @Override
    public String toString() {

        return "Tab [tabId=" + tabId + ", label=" + label + ", i18NLabelKey=" + i18NLabelKey + ", order=" + order + ", triggersRecomputeScreen="
                + triggersRecomputeScreen + ", type=" + type + ", groups=" + groups + "]";
    }

}
