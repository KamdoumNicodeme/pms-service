package com.lombardinternational.casemanagement.service.decision.domain.service.tasklist;

import java.util.List;
import java.util.Optional;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.TaskDefinition;

public abstract class AbstractTaskBuilderService implements TaskBuilderService {

    public void buildTaskDefinition(final List<TaskDefinition> taskList) {

        final var taskDefinition = taskList.stream().filter(task -> getTaskName().equals(task.getMainTaskName())).findFirst();
        final TaskDefinition finalTaskDefinition;
        if (taskDefinition.isEmpty()) {
            finalTaskDefinition = TaskDefinition.builder().mainTaskName(getTaskName()).mainTaskDynamicScreenId(getTaskDynamicScreenId())
                    .mainTaskExpectedDurationSeconds(getMainTaskExpectedDurationSeconds())
                    .signoffTaskExpectedDurationSeconds(getSignoffExpectedDurationSeconds()).mandatory(getMandatory()).suggested(getSuggested())
                    .rulePriority(getRulePriority()).build();
            finalTaskDefinition.incrementOrder();
            taskList.add(finalTaskDefinition);
        } else {
            /* If task already exists, update the properties if current rule priority is greater than the one of the task */
            finalTaskDefinition = taskDefinition.get();
            if (getRulePriority() > finalTaskDefinition.getRulePriority()) {
                finalTaskDefinition.setMainTaskExpectedDurationSeconds(getMainTaskExpectedDurationSeconds());
                finalTaskDefinition.setSignoffTaskExpectedDurationSeconds(getSignoffExpectedDurationSeconds());
                finalTaskDefinition.setMandatory(getMandatory());
                finalTaskDefinition.setSuggested(getSuggested());
                finalTaskDefinition.setRulePriority(getRulePriority());
            }
        }
        addDecisionReasons(finalTaskDefinition);
    }

    protected abstract String getTaskName();

    protected int getRulePriority() {

        return 0;
    }

    protected boolean getMandatory() {

        return false;
    }

    protected boolean getSuggested() {

        return false;
    }

    protected Optional<String> getDecisionReason() {

        return Optional.empty();
    }

    protected String getTaskDynamicScreenId() {

        return "";
    }

    protected int getMainTaskExpectedDurationSeconds() {

        return 60 * 60 * 24 * 2;
    }

    protected int getSignoffExpectedDurationSeconds() {

        return 60 * 60 * 24;
    }

    protected void addDecisionReasons(TaskDefinition finalTaskDefinition) {

        getDecisionReason().map(decisionStr -> decisionStr.split("\n"))
                .ifPresent(reasons -> finalTaskDefinition.getDecisionReasons().addAll(List.of(reasons)));
    }
}
