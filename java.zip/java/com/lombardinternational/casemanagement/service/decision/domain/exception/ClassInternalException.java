package com.lombardinternational.casemanagement.service.decision.domain.exception;

public class ClassInternalException extends RuntimeException {

    public ClassInternalException(final String message) {

        super(message);
    }
}
