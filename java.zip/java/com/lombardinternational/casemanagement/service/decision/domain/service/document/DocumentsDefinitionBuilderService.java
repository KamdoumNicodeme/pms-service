package com.lombardinternational.casemanagement.service.decision.domain.service.document;

import java.util.List;

import com.lombardinternational.casemanagement.service.decision.domain.model.policy.Policy;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.DocumentDefinition;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;

public interface DocumentsDefinitionBuilderService {

    List<DocumentDefinition> buildDocumentsDefinition(Policy policy, WebForm webForm, ScreenDescription screenDescription,
            String transactionNumber) throws Exception;
}
