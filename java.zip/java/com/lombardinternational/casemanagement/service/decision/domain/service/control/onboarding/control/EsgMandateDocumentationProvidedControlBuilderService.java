package com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control;

import java.util.List;

import org.springframework.stereotype.Service;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ControlDefinition;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.AbstractControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.utils.Constraint;
import com.lombardinternational.casemanagement.service.decision.domain.utils.FieldConstraint;

import static com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control.common.Utils.createConstraintWithMultiple;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ChecklistFieldConstants.ESG_MANDATE_SELECTED;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ControlConstants.ESG_MANDATE_DOCUMENTATION_PROVIDED_NAME;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ControlConstants.ESG_MANDATE_DOCUMENTATION_PROVIDED_TYPE;

@Service
public class EsgMandateDocumentationProvidedControlBuilderService extends AbstractControlBuilderService {

    private static final String YES_PRE_VALIDATED = "YES_PRE_VALIDATED";
    private static final String YES_TO_BE_REVIEWED = "YES_TO_BE_REVIEWED";

    @Override
    public ControlDefinition buildControl(WebForm webForm, ScreenDescription screenDescription) {

        final List<FieldConstraint> constraints = List.of(
                createConstraintWithMultiple(ESG_MANDATE_SELECTED, Constraint.IN, Boolean.TRUE, List.of(YES_PRE_VALIDATED, YES_TO_BE_REVIEWED)));

        if (constraints.stream().anyMatch(constraint -> constraint.test(screenDescription))) {
            return buildControlDefinition();
        }
        return null;
    }

    @Override
    protected String getControlName() {

        return ESG_MANDATE_DOCUMENTATION_PROVIDED_NAME;
    }

    @Override
    protected String getControlType() {

        return ESG_MANDATE_DOCUMENTATION_PROVIDED_TYPE;
    }
}
