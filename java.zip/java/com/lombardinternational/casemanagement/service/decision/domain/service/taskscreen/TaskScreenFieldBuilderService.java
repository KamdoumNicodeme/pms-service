package com.lombardinternational.casemanagement.service.decision.domain.service.taskscreen;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Group;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;

public interface TaskScreenFieldBuilderService {

    void buildField(final WebForm webForm, final ScreenDescription screenCheckList, final ScreenDescription screenToFill, final Group group);
}
