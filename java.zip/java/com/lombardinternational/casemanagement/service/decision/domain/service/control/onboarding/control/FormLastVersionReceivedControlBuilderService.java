package com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ControlDefinition;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.AbstractControlBuilderService;
import org.springframework.stereotype.Service;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ControlConstants.FORM_LAST_VERSION_RECEIVED_NAME;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ControlConstants.FORM_LAST_VERSION_RECEIVED_TYPE;

@Service
public class FormLastVersionReceivedControlBuilderService extends AbstractControlBuilderService {
    @Override
    public ControlDefinition buildControl(final WebForm webForm, final ScreenDescription screenDescription) {
        return buildControlDefinition();
    }

    @Override
    protected String getControlName() {
        return FORM_LAST_VERSION_RECEIVED_NAME;
    }

    @Override
    protected String getControlType() {
        return FORM_LAST_VERSION_RECEIVED_TYPE;
    }
}
