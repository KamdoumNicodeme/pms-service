package com.lombardinternational.casemanagement.service.decision.domain.service.factory;

import com.lombardinternational.casemanagement.service.decision.domain.model.policy.Policy;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ControlDefinition;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.DocumentDefinition;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.SignatoryResult;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.TaskDefinition;
import com.lombardinternational.casemanagement.service.decision.domain.model.transaction.BusinessTransaction;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.checklist.onboarding.OnboardingChecklistBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.OnboardingControlDefinitionBuilderService;
import java.util.List;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@AllArgsConstructor
public class OnboardingRulesBuilderService implements RulesBuilderService {

    private final OnboardingChecklistBuilderService checklistBuilderService;
    private final OnboardingControlDefinitionBuilderService controlDefinitionBuilderService;

    @Override
    public ScreenDescription buildCheckList(final WebForm webForm, final ScreenDescription screenDescription, final Policy policy,
            final BusinessTransaction transaction) {

        return checklistBuilderService.buildChecklist(webForm, screenDescription, policy, transaction);
    }

    @Override
    public List<TaskDefinition> buildTaskList(final WebForm webForm, final ScreenDescription screenDescription, final Policy policy) {

        return null;
    }

    @Override
    public ScreenDescription buildTaskScreen(final WebForm webForm, final ScreenDescription screenCheckList,
            final ScreenDescription screenToFill) {

        return null;
    }

    @Override
    public List<DocumentDefinition> buildDocumentsDefinition(final WebForm webForm, final ScreenDescription screenDescription, final Policy policy,
            final String transactionNumber) {

        return null;
    }

    @Override
    public List<ControlDefinition> buildControlDefinition(final WebForm webForm, final ScreenDescription screenDescription) {

        return controlDefinitionBuilderService.buildControlDefinition(webForm, screenDescription);
    }

    @Override
    public SignatoryResult buildSignatories(final WebForm webForm, final Policy policy) {

        return null;
    }
}
