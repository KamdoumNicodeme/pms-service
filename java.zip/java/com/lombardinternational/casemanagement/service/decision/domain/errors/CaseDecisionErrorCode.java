package com.lombardinternational.casemanagement.service.decision.domain.errors;

public class CaseDecisionErrorCode {

    public static final String CLASS_VALIDATION_ERROR = "N400";
    public static final String CLASS_NOT_FOUND = "N404";
    public static final String CLASS_TIMEOUT = "N408";

    public static final String CLASS_INTERNAL_ERROR = "N501";
    public static final String CLASS_UNAVAILABLE = "N503";

    public CaseDecisionErrorCode() {

    }
}
