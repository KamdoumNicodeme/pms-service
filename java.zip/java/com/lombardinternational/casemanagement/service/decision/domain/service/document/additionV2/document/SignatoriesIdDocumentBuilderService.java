package com.lombardinternational.casemanagement.service.decision.domain.service.document.additionV2.document;

import java.util.List;

import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Service;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.DocumentDefinition;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebFormGroup;
import com.lombardinternational.casemanagement.service.decision.domain.service.document.AbstractDocumentBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.utils.DocumentUtils;
import com.lombardinternational.casemanagement.service.decision.domain.utils.WebformUtils;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.DocumentConstants.CLIENT_I18N_DOCUMENT_RELATED_TO;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.DocumentConstants.ID_DESCRIPTION;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.DocumentConstants.ID_I18N_DESCRIPTION;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.DocumentConstants.TP_DOCS_CMS_DOC_TYPE;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.DocumentConstants.TP_DOCS_DOC_TYPE;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.RulesConstants.BROKER;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.WebFormFieldConstants.CONTACT_TYPE_WF;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.WebFormFieldConstants.FIRST_NAME_WF;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.WebFormFieldConstants.ID_WF;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.WebFormFieldConstants.LAST_NAME_WF;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.WebFormFieldConstants.POLICY_NUMBER_WF;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.WebFormFieldConstants.SIGNATORIES_WF;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.WebFormFieldConstants.SIGNING_WF;

@Service
public class SignatoriesIdDocumentBuilderService extends AbstractDocumentBuilderService {

    @Override
    public void buildDocument(WebForm webForm, ScreenDescription screenDescription, String transactionNumber, List<DocumentDefinition> documents) {

        var signingGroup = WebformUtils.getFirstWebFormGroupById(webForm, SIGNING_WF);
        if (signingGroup != null && CollectionUtils.isNotEmpty(signingGroup.getGroups())) {
            var signatoriesGroup = WebformUtils.getGroupInGroup(signingGroup, SIGNATORIES_WF);
            if (signatoriesGroup != null && CollectionUtils.isNotEmpty(signatoriesGroup.getGroups())) {
                for (WebFormGroup group : signatoriesGroup.getGroups()) {
                    if (!BROKER.equals(WebformUtils.getWebFormFieldValueById(group, CONTACT_TYPE_WF))) {
                        var clientNumber = WebformUtils.getWebFormFieldValueById(group, ID_WF);
                        var firstName = WebformUtils.getWebFormFieldValueById(group, FIRST_NAME_WF);
                        var lastName = WebformUtils.getWebFormFieldValueById(group, LAST_NAME_WF);
                        var relatedToBuilder = new StringBuilder();
                        DocumentUtils.buildRelatedTo(relatedToBuilder, "Client", lastName, firstName, clientNumber);
                        var relatedToPolicy = WebformUtils.getWebFormFieldValueById(webForm, POLICY_NUMBER_WF);
                        var relatedTo = relatedToBuilder.toString();
                        var i18nRelatedToParam = firstName + " " + lastName;
                        buildDocumentDefinition(relatedTo, relatedToPolicy, i18nRelatedToParam, clientNumber, documents);
                    }
                }
            }
        }

    }

    @Override
    protected String getDocumentType() {

        return TP_DOCS_DOC_TYPE;
    }

    @Override
    protected String getCmsDocumentType() {

        return TP_DOCS_CMS_DOC_TYPE;
    }

    @Override
    protected String getDescription() {

        return ID_DESCRIPTION;
    }

    @Override
    protected String getI18NDescription() {

        return ID_I18N_DESCRIPTION;
    }

    @Override
    protected String getI18NDocumentRelatedTo() {

        return CLIENT_I18N_DOCUMENT_RELATED_TO;
    }

    @Override
    protected boolean getDocumentVisibleOnConnect() {

        return true;
    }

    @Override
    protected boolean getDocumentRequired() {

        return true;
    }

}
