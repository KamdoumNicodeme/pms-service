package com.lombardinternational.casemanagement.service.decision.domain.utils;

import java.util.List;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ChecklistFieldConstants.EBO_COUNTRY;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ChecklistFieldConstants.EBO_RESIDENCE_COUNTRY_RISK;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ChecklistFieldConstants.LA_RESIDENCE_COUNTRY;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ChecklistFieldConstants.LA_RESIDENCE_COUNTRY_RISK;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ChecklistFieldConstants.PH_RESIDENCE_COUNTRY;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ChecklistFieldConstants.PH_RESIDENCE_COUNTRY_RISK;

public class ControlUtils {

    public static List<FieldConstraint> verifyPhEboLaResidenceCountryOnMarkets(List<String> markets, boolean negate) {

        return List.of(
                FieldConstraint.builder().fieldId(PH_RESIDENCE_COUNTRY).constraint(Constraint.DISJOINT).negate(negate).split(true).tokenizer(" ")
                        .values(markets).build(),
                FieldConstraint.builder().fieldId(EBO_COUNTRY).constraint(Constraint.DISJOINT).negate(negate).split(true).tokenizer(" ")
                        .values(markets).build(),
                FieldConstraint.builder().fieldId(LA_RESIDENCE_COUNTRY).constraint(Constraint.DISJOINT).negate(negate).split(true).tokenizer(" ")
                        .values(markets).build());
    }

    public static List<FieldConstraint> verifyPhEboLaResidenceCountryRiskOnMarkets(List<String> markets, boolean negate) {

        return List.of(
                FieldConstraint.builder().fieldId(PH_RESIDENCE_COUNTRY_RISK).constraint(Constraint.DISJOINT).negate(negate).split(true)
                        .tokenizer(" ").values(markets).build(),
                FieldConstraint.builder().fieldId(EBO_RESIDENCE_COUNTRY_RISK).constraint(Constraint.DISJOINT).negate(negate).split(true)
                        .tokenizer(" ").values(markets).build(),
                FieldConstraint.builder().fieldId(LA_RESIDENCE_COUNTRY_RISK).constraint(Constraint.DISJOINT).negate(negate).split(true)
                        .tokenizer(" ").values(markets).build());
    }
}
