package com.lombardinternational.casemanagement.service.decision.domain.model.rules;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.Map;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class SignatoryResult {

    private List<DocumentRequiredSignatory> documentRequiredSignatories;
    private Map<String,String> responseMessages;
}
