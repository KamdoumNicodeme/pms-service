package com.lombardinternational.casemanagement.service.decision.domain.model.policy;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder
@NoArgsConstructor
@EqualsAndHashCode(callSuper = true)
public class PhysicalPerson extends AbstractPerson {

    private String firstName;
    private String lastName;
    private String title;
    private String language;
    private Profession profession;
}
