package com.lombardinternational.casemanagement.service.decision.domain.service.taskscreen.common.groups;

import org.springframework.stereotype.Service;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Group;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Tab;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.taskscreen.TaskScreenGroupBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.taskscreen.common.fields.CommonIdentificationOfRegulatedBusinessFieldsBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.utils.RulesUtils;

import lombok.AllArgsConstructor;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.TaskScreenConstants.IDENTIFICATION_OF_REGULATED_BUSINESS_GROUP;

@Service
@AllArgsConstructor
public class CommonIdentificationOfRegulatedBusinessGroupBuilderService implements TaskScreenGroupBuilderService {

    private final CommonIdentificationOfRegulatedBusinessFieldsBuilderService service;

    @Override
    public void buildGroup(final WebForm webForm, final ScreenDescription screenCheckList, final ScreenDescription screenToFill,
            final Tab parentTab) {

        var identificationOfRegulatedBusinessGroup = RulesUtils.getGroupInTab(parentTab, IDENTIFICATION_OF_REGULATED_BUSINESS_GROUP);
        if (identificationOfRegulatedBusinessGroup == null) {
            identificationOfRegulatedBusinessGroup = Group.builder().groupId(IDENTIFICATION_OF_REGULATED_BUSINESS_GROUP).build();
            parentTab.getGroups().add(identificationOfRegulatedBusinessGroup);
        }
        identificationOfRegulatedBusinessGroup.setIsActive(true);
        identificationOfRegulatedBusinessGroup.incrementOrder();
        identificationOfRegulatedBusinessGroup.setTitle("Identification of regulated business activity?");
        service.buildField(webForm, screenCheckList, screenToFill, identificationOfRegulatedBusinessGroup);
    }
}
