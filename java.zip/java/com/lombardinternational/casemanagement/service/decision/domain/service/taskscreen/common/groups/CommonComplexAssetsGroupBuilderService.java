package com.lombardinternational.casemanagement.service.decision.domain.service.taskscreen.common.groups;

import org.springframework.stereotype.Service;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Group;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Tab;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.taskscreen.TaskScreenGroupBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.taskscreen.common.fields.CommonComplexAssetsFieldsBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.utils.RulesUtils;

import lombok.AllArgsConstructor;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.TaskScreenConstants.COMPLEX_ASSETS_GROUP;

@Service
@AllArgsConstructor
public class CommonComplexAssetsGroupBuilderService implements TaskScreenGroupBuilderService {

    private final CommonComplexAssetsFieldsBuilderService service;

    @Override
    public void buildGroup(final WebForm webForm, final ScreenDescription screenCheckList, final ScreenDescription screenToFill,
            final Tab parentTab) {

        var complexAssets = RulesUtils.getGroupInTab(parentTab, COMPLEX_ASSETS_GROUP);
        if (complexAssets == null) {
            complexAssets = Group.builder().groupId(COMPLEX_ASSETS_GROUP).build();
            parentTab.getGroups().add(complexAssets);
        }
        complexAssets.setIsActive(true);
        complexAssets.incrementOrder();
        complexAssets.setTitle("Complex assets not permitted under limited IMA");
        service.buildField(webForm, screenCheckList, screenToFill, complexAssets);
    }
}
