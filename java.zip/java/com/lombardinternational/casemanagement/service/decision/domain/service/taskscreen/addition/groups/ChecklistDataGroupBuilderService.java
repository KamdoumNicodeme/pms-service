package com.lombardinternational.casemanagement.service.decision.domain.service.taskscreen.addition.groups;

import org.springframework.stereotype.Service;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Group;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Tab;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.taskscreen.TaskScreenGroupBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.taskscreen.addition.fields.ChecklistDataFieldsBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.utils.RulesUtils;

import lombok.AllArgsConstructor;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.TaskScreenConstants.CHECKLIST_DATA_GROUP;

@Service
@AllArgsConstructor
public class ChecklistDataGroupBuilderService implements TaskScreenGroupBuilderService {

    private final ChecklistDataFieldsBuilderService service;

    @Override
    public void buildGroup(final WebForm webForm, final ScreenDescription screenCheckList, final ScreenDescription screenToFill,
            final Tab parentTab) {

        var checklistDataGroup = RulesUtils.getGroupInTab(parentTab, CHECKLIST_DATA_GROUP);
        if (checklistDataGroup == null) {
            checklistDataGroup = Group.builder().groupId(CHECKLIST_DATA_GROUP).build();
            parentTab.getGroups().add(checklistDataGroup);
        }
        checklistDataGroup.setIsActive(true);
        checklistDataGroup.incrementOrder();
        checklistDataGroup.setTitle("General information");
        service.buildField(webForm, screenCheckList, screenToFill, checklistDataGroup);
    }
}
