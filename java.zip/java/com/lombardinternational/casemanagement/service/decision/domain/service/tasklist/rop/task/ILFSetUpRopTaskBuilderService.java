package com.lombardinternational.casemanagement.service.decision.domain.service.tasklist.rop.task;

import com.lombardinternational.casemanagement.service.decision.domain.model.policy.Policy;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.TaskDefinition;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.tasklist.AbstractTaskBuilderService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ILFSetUpRopTaskBuilderService extends AbstractTaskBuilderService {

    @Override
    public void buildTask(Policy policy, WebForm webForm, ScreenDescription screenDescription, List<TaskDefinition> taskList) {
        buildTaskDefinition(taskList);
    }

    @Override
    protected String getTaskName() {
        return "ILF Set up";
    }
}
