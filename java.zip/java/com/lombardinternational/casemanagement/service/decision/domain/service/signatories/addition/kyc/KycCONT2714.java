package com.lombardinternational.casemanagement.service.decision.domain.service.signatories.addition.kyc;

import java.util.Collections;
import java.util.List;

import org.springframework.stereotype.Service;

import com.lombardinternational.casemanagement.service.decision.domain.model.policy.Policy;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.DocumentRequiredSignatory;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.RequiredSignatory;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control.common.Utils;
import com.lombardinternational.casemanagement.service.decision.domain.utils.Constraint;
import com.lombardinternational.casemanagement.service.decision.domain.utils.FieldConstraint;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.SignatoryConstants.*;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.WebFormFieldConstants.*;

@Service
public class KycCONT2714 extends KycCont {

    @Override
    public void buildRequiredSignatory(final WebForm webForm, final Policy policy,
            final List<DocumentRequiredSignatory> documentRequiredSignatories, final List<RequiredSignatory> signatories) {

        final List<FieldConstraint> constraints =
                List.of(Utils.createConstraint(COUNTRY_OF_LAW, Constraint.EQUALS, Collections.singletonList("ES")),
                        Utils.createConstraintWithNegate(TARGET_MARKET, Constraint.EQUALS, Collections.singletonList("NT"), true));

        if (constraints.stream().allMatch(constraint -> constraint.test(webForm))) {
            buildDocumentRequiredSignatoryEntity(webForm, documentRequiredSignatories, signatories);
        }
    }

    @Override
    protected String getDocumentType() {

        return CONT2714;
    }
}
