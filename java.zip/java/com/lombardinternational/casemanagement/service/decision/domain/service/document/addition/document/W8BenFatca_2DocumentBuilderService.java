package com.lombardinternational.casemanagement.service.decision.domain.service.document.addition.document;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.DocumentDefinition;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Field;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.document.AbstractDocumentBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.utils.ChecklistUtils;
import com.lombardinternational.casemanagement.service.decision.domain.utils.Constraint;
import com.lombardinternational.casemanagement.service.decision.domain.utils.FieldConstraint;
import com.lombardinternational.casemanagement.service.decision.domain.utils.WebformUtils;
import org.springframework.stereotype.Service;

import java.util.*;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ChecklistFieldConstants.*;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.DocumentConstants.*;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.WebFormFieldConstants.POLICY_NUMBER_WF;

@Service
public class W8BenFatca_2DocumentBuilderService extends AbstractDocumentBuilderService {

    @Override
    public void buildDocument(final WebForm webForm, final ScreenDescription screenDescription, String transactionNumber,
            List<DocumentDefinition> documents) {

        final var constraints = new ArrayList<FieldConstraint>();
        constraints.add(
                FieldConstraint.builder().fieldId(NEW_US_INDICIA).constraint(Constraint.EQUALS).values(Collections.singletonList("YES")).build());
        constraints.add(
                FieldConstraint.builder().fieldId(BAC_APPROVAL).constraint(Constraint.EQUALS).values(Collections.singletonList("YES")).build());
        if (constraints.stream().allMatch(constraint -> constraint.test(screenDescription))) {

            Optional<Field> phResidenceCountriesOpt = ChecklistUtils.getFieldById(screenDescription, PH_RESIDENCE_COUNTRY);
            Optional<Field> eboCountriesOpt = ChecklistUtils.getFieldById(screenDescription, EBO_COUNTRY);
            Optional<Field> laResidenceCountriesOpt = ChecklistUtils.getFieldById(screenDescription, LA_RESIDENCE_COUNTRY);
            Optional<Field> ibCountriesOpt = ChecklistUtils.getFieldById(screenDescription, IRREVOCABLE_BEN_COUNTRY);
            Optional<Field> sendingAddressOpt = ChecklistUtils.getFieldById(screenDescription, SENDING_ADDRESS_COUNTRY);
            Optional<Field> countryOfApplicableLawOpt = ChecklistUtils.getFieldById(screenDescription, COUNTRY_OF_APPLICABLE_LAW);

            var phResidenceCountries = phResidenceCountriesOpt.filter(field -> field.getSelectedValue() != null)
                    .map(field -> Arrays.stream(field.getSelectedValue().split(" ")).toList()).orElse(new ArrayList<>());
            var eboCountries = eboCountriesOpt.filter(field -> field.getSelectedValue() != null)
                    .map(field -> Arrays.stream(field.getSelectedValue().split(" ")).toList()).orElse(new ArrayList<>());
            var laResidenceCountries = laResidenceCountriesOpt.filter(field -> field.getSelectedValue() != null)
                    .map(field -> Arrays.stream(field.getSelectedValue().split(" ")).toList()).orElse(new ArrayList<>());
            var ibCountries = ibCountriesOpt.filter(field -> field.getSelectedValue() != null)
                    .map(field -> Arrays.stream(field.getSelectedValue().split(" ")).toList()).orElse(new ArrayList<>());
            var sendingAddressCountry =
                    sendingAddressOpt.filter(field -> field.getSelectedValue() != null).map(Field::getSelectedValue).orElse(null);
            var countryOfApplicableLaw =
                    countryOfApplicableLawOpt.filter(field -> field.getSelectedValue() != null).map(Field::getSelectedValue).orElse(null);

            List<String> staticList = Arrays.asList("MX", "BE", "CH");
            List<String> staticList2 =
                    Arrays.asList("BE", "BR", "CL", "CO", "CY", "DE", "ES", "FI", "FR", "GB", "GG", "GI", "IL", "IT", "LU", "MT", "MX", "NO", "PE",
                            "PT", "SE", "TR");

            if ((phResidenceCountries.contains(countryOfApplicableLaw) || ibCountries.contains(countryOfApplicableLaw) || eboCountries.contains(
                    countryOfApplicableLaw)) && (Collections.disjoint(phResidenceCountries, staticList) || Collections.disjoint(ibCountries,
                    staticList) || Collections.disjoint(eboCountries, staticList)) && (eboCountries.contains(
                    sendingAddressCountry) || laResidenceCountries.contains(sendingAddressCountry) || phResidenceCountries.contains(
                    sendingAddressCountry)) && !Collections.disjoint(laResidenceCountries, staticList2)) {
                var relatedTo = WebformUtils.getWebFormFieldValueById(webForm, POLICY_NUMBER_WF);
                buildDocumentDefinition(relatedTo, relatedTo, null, null, documents);
            }
        }
    }

    @Override
    protected String getDocumentType() {

        return AEOI_FORM_DOC_TYPE;
    }

    @Override
    protected String getCmsDocumentType() {

        return AEOI_FORM_CMS_DOC_TYPE;
    }

    @Override
    protected String getDescription() {

        return W8BEN_FATCA_2_FORM_DESCRIPTION;
    }

    @Override
    protected String getI18NDescription() {

        return W8BEN_FATCA_2_FORM_I18N_DESCRIPTION;
    }

    @Override
    protected String getCmtRelatedToPrefix() {

        return W8BEN_FATCA_2_FORM_CMT_RELATED_TO_PREFIX_DESCRIPTION;
    }
}
