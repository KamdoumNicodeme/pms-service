package com.lombardinternational.casemanagement.service.decision.domain.model.transaction;

import java.time.LocalDate;
import java.util.List;

import com.lombardinternational.casemanagement.service.decision.domain.model.policy.Amount;
import com.lombardinternational.casemanagement.service.decision.domain.model.policy.EboPolicyNav;
import com.lombardinternational.casemanagement.service.decision.domain.model.policy.RiskFactorResult;
import com.lombardinternational.casemanagement.service.decision.domain.model.policy.TransactionAmounts;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class BusinessTransaction {

    private String identifier;
    private String type;
    private String category;
    private String subCategory;
    private String policyNumber;
    private String policyIsoCurrencyCode;

    private Amount transactionAmountEur;
    private TransactionAmounts transactionAmounts;

    private List<BusinessTransactionProductComponent> productComponentPayments;

    private List<RiskFactorResult> riskFactorResults;

    private EboPolicyNav eboPolicyNav;
    private Boolean isInRemediationList;
    private Boolean isPolicyRemediated;
    private LocalDate closingDate;
    private Amount expectedAmountEur;
    private Amount expectedAmount;

}
