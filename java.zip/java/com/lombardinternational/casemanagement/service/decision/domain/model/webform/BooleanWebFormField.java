package com.lombardinternational.casemanagement.service.decision.domain.model.webform;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@EqualsAndHashCode(callSuper = true)
@SuperBuilder
@NoArgsConstructor
public class BooleanWebFormField extends WebFormField {

    private Boolean value;
}
