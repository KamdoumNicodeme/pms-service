package com.lombardinternational.casemanagement.service.decision.domain.service.control;

import java.util.List;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ControlDefinition;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;

public interface ControlDefinitionBuilderService {

    List<ControlDefinition> buildControlDefinition(final WebForm webForm, final ScreenDescription screenDescription);
}
