package com.lombardinternational.casemanagement.service.decision.domain.model.transaction;

import com.lombardinternational.casemanagement.service.decision.domain.model.policy.Amount;
import com.lombardinternational.casemanagement.service.decision.domain.model.policy.Country;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder
@NoArgsConstructor
public abstract class Payment {

    private Amount paymentAmount;
    private Country paymentCountry;
    private PaymentDetails paymentDetails;
}
