package com.lombardinternational.casemanagement.service.decision.domain.service.taskscreen.common.groups;

import org.springframework.stereotype.Service;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Group;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Tab;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.taskscreen.TaskScreenGroupBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.taskscreen.common.fields.CommonInadmissibleFieldsBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.utils.RulesUtils;

import lombok.AllArgsConstructor;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.TaskScreenConstants.INADMISSIBLE_GROUP;

@Service
@AllArgsConstructor
public class CommonInadmissibleGroupBuilderService implements TaskScreenGroupBuilderService {

    private final CommonInadmissibleFieldsBuilderService service;

    @Override
    public void buildGroup(final WebForm webForm, final ScreenDescription screenCheckList, final ScreenDescription screenToFill,
            final Tab parentTab) {

        var inadmissibleGroup = RulesUtils.getGroupInTab(parentTab, INADMISSIBLE_GROUP);
        if (inadmissibleGroup == null) {
            inadmissibleGroup = Group.builder().groupId(INADMISSIBLE_GROUP).build();
            parentTab.getGroups().add(inadmissibleGroup);
        }
        inadmissibleGroup.setIsActive(true);
        inadmissibleGroup.incrementOrder();
        inadmissibleGroup.setTitle("Inadmissible Assets in accordance with CAA Rules - inform PCS.");
        service.buildField(webForm, screenCheckList, screenToFill, inadmissibleGroup);
    }
}
