package com.lombardinternational.casemanagement.service.decision.domain.service.tasklist.common.task;

import com.lombardinternational.casemanagement.service.decision.domain.service.tasklist.AbstractTaskBuilderService;

public abstract class CommonAbstractDOTTaskBuilderService extends AbstractTaskBuilderService {

    @Override
    public String getTaskName() {

        return "Daily Operations Team";
    }
}
