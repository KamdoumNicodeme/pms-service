package com.lombardinternational.casemanagement.service.decision.domain.service.factory;

import java.util.List;

import org.springframework.stereotype.Service;

import com.lombardinternational.casemanagement.service.decision.domain.model.policy.Policy;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ControlDefinition;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.DocumentDefinition;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.SignatoryResult;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.TaskDefinition;
import com.lombardinternational.casemanagement.service.decision.domain.model.transaction.BusinessTransaction;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.checklist.addition.AdditionChecklistBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.addition.AdditionControlDefinitionBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.document.addition.AdditionDocumentsDefinitionBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.document.additionV2.AdditionV2DocumentsDefinitionBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.signatories.addition.AdditionSignatoriesBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.tasklist.addition.AdditionTaskListBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.taskscreen.addition.AdditionTaskScreenBuilderService;

import lombok.AllArgsConstructor;

@Service
@AllArgsConstructor
public class AdditionRulesBuilderService implements RulesBuilderService {

    private final AdditionChecklistBuilderService checklistBuilderService;
    private final AdditionTaskListBuilderService tasklistBuilderService;
    private final AdditionTaskScreenBuilderService taskscreenBuilderService;
    private final AdditionControlDefinitionBuilderService controlDefinitionBuilderService;
    private final AdditionDocumentsDefinitionBuilderService documentsDefinitionBuilderService;
    private final AdditionV2DocumentsDefinitionBuilderService documentsV2DefinitionBuilderService;
    private final AdditionSignatoriesBuilderService signatoriesBuilderService;

    @Override
    public ScreenDescription buildCheckList(final WebForm webForm, final ScreenDescription screenDescription, final Policy policy,
            final BusinessTransaction transaction) {

        return checklistBuilderService.buildChecklist(webForm, screenDescription, policy, transaction);
    }

    @Override
    public List<TaskDefinition> buildTaskList(final WebForm webForm, final ScreenDescription screenDescription, final Policy policy) {

        return tasklistBuilderService.buildTaskList(policy, webForm, screenDescription);
    }

    @Override
    public ScreenDescription buildTaskScreen(final WebForm webForm, final ScreenDescription screenCheckList,
            final ScreenDescription screenToFill) {

        return taskscreenBuilderService.buildTaskScreen(webForm, screenCheckList, screenToFill);
    }

    @Override
    public List<DocumentDefinition> buildDocumentsDefinition(final WebForm webForm, final ScreenDescription screenDescription, final Policy policy,
            final String transactionNumber) throws Exception {

        if ("ADDITION_V2".equals(webForm.getWebFormId())) {
            return documentsV2DefinitionBuilderService.buildDocumentsDefinition(policy, webForm, screenDescription, transactionNumber);
        }
        return documentsDefinitionBuilderService.buildDocumentsDefinition(policy, webForm, screenDescription, transactionNumber);
    }

    @Override
    public List<ControlDefinition> buildControlDefinition(final WebForm webForm, final ScreenDescription screenDescription) {

        return controlDefinitionBuilderService.buildControlDefinition(webForm, screenDescription);
    }

    @Override
    public SignatoryResult buildSignatories(final WebForm webForm, final Policy policy) {

        return signatoriesBuilderService.buildSignatories(policy, webForm);
    }
}
