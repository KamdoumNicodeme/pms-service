package com.lombardinternational.casemanagement.service.decision.domain.spi.repository;

import java.util.List;

public interface CountryDataRepositoryService {

    List<String> getCountryIsoCodeByType(String countryType);

    List<String> getCountryByTypeAndValue(String countryType, String countryValue);
}
