package com.lombardinternational.casemanagement.service.decision.domain.model.webform;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class WebForm {

    private String webFormId;
    private UserDetail userDetail;
    private CompanyDetail companyDetail;
    private String webFormWorkFlow;
    private List<WebFormGroup> groups;

}
