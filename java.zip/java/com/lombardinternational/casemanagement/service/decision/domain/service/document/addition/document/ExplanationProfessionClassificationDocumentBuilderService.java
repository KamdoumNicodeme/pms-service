package com.lombardinternational.casemanagement.service.decision.domain.service.document.addition.document;

import com.lombardinternational.casemanagement.service.decision.domain.model.policy.RiskFactorResult;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.DocumentDefinition;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.document.AbstractDocumentBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.spi.web.ComplianceWebService;
import com.lombardinternational.casemanagement.service.decision.domain.utils.WebformUtils;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.DocumentConstants.*;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.WebFormFieldConstants.POLICY_NUMBER_WF;

@Service
@RequiredArgsConstructor
public class ExplanationProfessionClassificationDocumentBuilderService extends AbstractDocumentBuilderService {

    private final ComplianceWebService complianceWebService;
    private final String INDUSTRY_RISK = "INT_RF_003";
    private final String STANDARD_RISK = "STANDARD";

    @Override
    public void buildDocument(final WebForm webForm, final ScreenDescription screenDescription, String transactionNumber,
            List<DocumentDefinition> documents) throws Exception {

        List<RiskFactorResult> riskFactorResults = complianceWebService.evaluateRiskFactors(transactionNumber, List.of(INDUSTRY_RISK));
        String industryRiskLevel = riskFactorResults.stream().filter(riskFactorResult -> INDUSTRY_RISK.equals(riskFactorResult.getReference()))
                .map(RiskFactorResult::getRiskLevel).findFirst().orElse(null);

        if (industryRiskLevel != null && !STANDARD_RISK.equals(industryRiskLevel)) {
            var relatedTo = WebformUtils.getWebFormFieldValueById(webForm, POLICY_NUMBER_WF);
            buildDocumentDefinition(relatedTo, relatedTo, null, null, documents);
        }
    }

    @Override
    protected String getDocumentType() {

        return KYC_DOCUMENT_DOC_TYPE;
    }

    @Override
    protected String getCmsDocumentType() {

        return KYC_DOCUMENT_CMS_DOC_TYPE;
    }

    @Override
    protected String getDescription() {

        return EXPLANATION_PROFESSION_CLASSIFICATION_FORM_DESCRIPTION;
    }

    @Override
    protected String getI18NDescription() {

        return EXPLANATION_PROFESSION_CLASSIFICATION_FORM_I18N_DESCRIPTION;
    }
}
