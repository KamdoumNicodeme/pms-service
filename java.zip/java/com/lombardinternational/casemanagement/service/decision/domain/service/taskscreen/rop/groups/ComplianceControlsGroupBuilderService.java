package com.lombardinternational.casemanagement.service.decision.domain.service.taskscreen.rop.groups;

import org.springframework.stereotype.Service;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Group;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Tab;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.taskscreen.TaskScreenGroupBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.taskscreen.rop.fields.ChecklistComplianceControlsFieldsBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.utils.RulesUtils;

import lombok.AllArgsConstructor;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.TaskScreenConstants.*;

@Service
@AllArgsConstructor
public class ComplianceControlsGroupBuilderService implements TaskScreenGroupBuilderService {

    private final ChecklistComplianceControlsFieldsBuilderService service;

    @Override
    public void buildGroup(final WebForm webForm, final ScreenDescription screenCheckList, final ScreenDescription screenToFill,
            final Tab parentTab) {

        var checklistControlsGroup = RulesUtils.getGroupInTab(parentTab, COMPLIANCE_CONTROLS_GROUP);
        if (checklistControlsGroup == null) {
            checklistControlsGroup = Group.builder().groupId(COMPLIANCE_CONTROLS_GROUP).build();
            parentTab.getGroups().add(checklistControlsGroup);
        }
        checklistControlsGroup.setIsActive(true);
        checklistControlsGroup.incrementOrder();
        checklistControlsGroup.setTitle("Compliance Controls");
        service.buildField(webForm, screenCheckList, screenToFill, checklistControlsGroup);
    }

}
