package com.lombardinternational.casemanagement.service.decision.domain.service.tasklist.addition;

import com.lombardinternational.casemanagement.service.decision.domain.service.tasklist.AbstractTaskBuilderService;

public abstract class AbstractUnquotedAdditionTaskBuilderService extends AbstractTaskBuilderService {

    @Override
    public String getTaskName() {

        return "Unquoted";
    }

    @Override
    public String getTaskDynamicScreenId() {

        return "UNQUOTED_ADDITION";
    }

    @Override
    public int getMainTaskExpectedDurationSeconds() {

        return 60 * 60 * 24 * 30;
    }
}
