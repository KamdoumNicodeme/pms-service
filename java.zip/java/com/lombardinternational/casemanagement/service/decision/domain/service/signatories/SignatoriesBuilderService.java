package com.lombardinternational.casemanagement.service.decision.domain.service.signatories;

import com.lombardinternational.casemanagement.service.decision.domain.model.policy.Policy;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.SignatoryResult;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;

public interface SignatoriesBuilderService {

    SignatoryResult buildSignatories(Policy policy, WebForm webForm);
}
