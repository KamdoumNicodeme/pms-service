package com.lombardinternational.casemanagement.service.decision.domain.utils;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.function.Predicate;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Field;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebFormField;

import lombok.Builder;
import lombok.Value;

@Value
@Builder
public class FieldConstraint {

    String fieldId;
    Constraint constraint;
    @Builder.Default
    boolean multiple = false;
    @Builder.Default
    boolean or = true;
    @Builder.Default
    boolean negate = false;
    @Builder.Default
    boolean exactMatch = true;
    @Builder.Default
    boolean split = false;
    String tokenizer;
    List<String> values;

    public boolean test(ScreenDescription screenDescription) {

        final var fields = multiple ? ChecklistUtils.getFieldsById(screenDescription, fieldId)
                : ChecklistUtils.getFieldById(screenDescription, fieldId).map(List::of).orElseGet(Collections::emptyList);
        final var streamedFields = isNullFieldValueAllowed() ? fields.stream() : fields.stream().filter(v -> v.getSelectedValue() != null);
        var predicate = createChecklistPredicate();
        predicate = negate ? predicate.negate() : predicate;
        return or ? streamedFields.anyMatch(predicate) : streamedFields.allMatch(predicate);
    }

    public boolean test(WebForm webForm) {

        final var fields = WebformUtils.getWebFormFieldsById(webForm, fieldId);
        final var streamedFields =
                isNullFieldValueAllowed() ? fields.stream() : fields.stream().filter(v -> (WebformUtils.getValueForWebFormField(v) != null));
        var predicate = createWebFormPredicate();
        predicate = negate ? predicate.negate() : predicate;
        return or ? streamedFields.anyMatch(predicate) : streamedFields.allMatch(predicate);
    }

    // This check is mandatory to be done outside of the predicate, as it would otherwise be negated by the negate property
    private boolean isNullFieldValueAllowed() {

        return switch (constraint) {
        case LESS, MORE, CONTAINS, IN -> false;
        default -> true;
        };
    }

    private Predicate<Field> createChecklistPredicate() {

        return switch (constraint) {
        case EQUALS -> field -> values.getFirst().equals(field.getSelectedValue());
        case LESS -> field -> Double.parseDouble(field.getSelectedValue()) < Double.parseDouble(values.getFirst());
        case MORE -> field -> Double.parseDouble(field.getSelectedValue()) > Double.parseDouble(values.getFirst());
        case IN ->
            field -> exactMatch ? values.contains(field.getSelectedValue()) : values.stream().anyMatch(v -> field.getSelectedValue().contains(v));
        case CONTAINS -> field -> field.getSelectedValue().contains(values.getFirst());
        case DISJOINT -> field -> split
                ? disjoint(field.getSelectedValue() != null ? Arrays.asList(field.getSelectedValue().split(tokenizer)) : Collections.emptyList(),
                        values)
                : disjoint(Collections.singletonList(field.getSelectedValue()), values);
        };
    }

    private Predicate<WebFormField> createWebFormPredicate() {

        return switch (constraint) {
        case EQUALS -> field -> values.getFirst().equals(WebformUtils.getValueForWebFormField(field));
        case LESS -> field -> Double.parseDouble(Objects.requireNonNull(WebformUtils.getValueForWebFormField(field))) < Double
                .parseDouble(values.getFirst());
        case MORE -> field -> Double.parseDouble(Objects.requireNonNull(WebformUtils.getValueForWebFormField(field))) > Double
                .parseDouble(values.getFirst());
        case IN -> field -> exactMatch ? values.contains(WebformUtils.getValueForWebFormField(field))
                : values.stream().anyMatch(v -> WebformUtils.getValueForWebFormField(field).contains(v));
        case CONTAINS -> field -> WebformUtils.getValueForWebFormField(field).contains(values.getFirst());
        case DISJOINT -> field -> split
                ? disjoint(WebformUtils.getValueForWebFormField(field) != null
                        ? Arrays.asList(WebformUtils.getValueForWebFormField(field).split(tokenizer)) : Collections.emptyList(), values)
                : disjoint(Collections.singletonList(WebformUtils.getValueForWebFormField(field)), values);
        };
    }

    private boolean disjoint(List<String> list1, List<String> list2) {

        return Collections.disjoint(list1, list2);
    }

}
