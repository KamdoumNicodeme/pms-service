package com.lombardinternational.casemanagement.service.decision.domain.service.tasklist.addition;

import com.lombardinternational.casemanagement.service.decision.domain.service.tasklist.common.task.CommonAbstractDOTTaskBuilderService;

public abstract class AbstractDOTAdditionTaskBuilderService extends CommonAbstractDOTTaskBuilderService {

    @Override
    public String getTaskDynamicScreenId() {

        return "DOT_ADDITION";
    }
}
