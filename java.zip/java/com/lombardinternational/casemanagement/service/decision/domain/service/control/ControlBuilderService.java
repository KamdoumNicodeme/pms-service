package com.lombardinternational.casemanagement.service.decision.domain.service.control;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ControlDefinition;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;

public interface ControlBuilderService {

    ControlDefinition buildControl(final WebForm webForm, final ScreenDescription screenDescription);
}
