package com.lombardinternational.casemanagement.service.decision.domain.service.signatories;

import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

@Service
public class ResponseMessageBuilderService {

    public Map<String,String> buildResponseMessage() {

        Map<String,String> responseMessages = new HashMap<>();
        responseMessages.put("MESSAGE", "");
        responseMessages.put("STATUS", "OK");
        responseMessages.put("MESSAGE_I18N", "");
        return responseMessages;
    }
}
