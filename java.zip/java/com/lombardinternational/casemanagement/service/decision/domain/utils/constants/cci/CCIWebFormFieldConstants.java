package com.lombardinternational.casemanagement.service.decision.domain.utils.constants.cci;

public class CCIWebFormFieldConstants {

    public static final String CLIENT_PHYSICAL = "CLIENT_PHYSICAL";
    public static final String CLIENT_COMPANY = "CLIENT_COMPANY";
    public static final String CLIENT_NUMBER = "CLIENT_NUMBER";

    public static final String FIRST_NAME = "FIRSTNAME";
    public static final String LAST_NAME = "SURNAME";
    public static final String BIRTH_DATE = "BIRTHDATE";
    public static final String COMPANY_NAME = "COMPANYNAME";
}
