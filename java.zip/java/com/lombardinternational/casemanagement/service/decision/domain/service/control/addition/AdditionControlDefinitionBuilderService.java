package com.lombardinternational.casemanagement.service.decision.domain.service.control.addition;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ControlDefinition;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.AbstractControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.ControlDefinitionBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.addition.control.AdditionFormSignedIbControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.addition.control.AeoiMrlControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.addition.control.AeoiPassiveControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.addition.control.AeoiSelfControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.addition.control.AeoiTrustControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.addition.control.AllocationRateToAmendAndBecMatchingControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.addition.control.ApprovedAnnualAccountsControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.addition.control.ArtAssocFiduciaryControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.addition.control.BankAccountEvidenceControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.addition.control.BankStatementWithAmountControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.addition.control.BrokerAuthorisedInCountrySignatureControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.addition.control.BrokerAuthorisedInPhCountryControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.addition.control.BusinessHandbookControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.addition.control.CertifiedIdEboControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.addition.control.CertifiedPorEboControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.addition.control.CertifiedTrustDeedControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.addition.control.ClearIdIbControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.addition.control.ClearIdPoaControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.addition.control.ClientIdentificationOnFileControlAdditionBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.addition.control.CopyOfArtAssocStatutesControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.addition.control.CopyOfIdAuthSignatoriesControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.addition.control.CopyOfIdEboControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.addition.control.CopyOfIdEboFiduciaryControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.addition.control.CopyOfIdFiduciaryControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.addition.control.CopyOfIdPolicyRoleControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.addition.control.CopyOfListDirAuthSignatoriesControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.addition.control.CopyOfPorAuthSignatoriesControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.addition.control.CopyOfPorEboControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.addition.control.CopyOfPorEboFiduciaryControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.addition.control.CopyOfPorPolicyRoleControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.addition.control.CopyOfShrRegisterMemberControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.addition.control.CopyOfTradeCertificateControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.addition.control.CopyPoaControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.addition.control.CopyProofResidenceIbControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.addition.control.DeedAppointmentTrusteesControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.addition.control.DeviationSuitabilityProfileControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.addition.control.DocumentationOriginFundControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.addition.control.EBacApprovalNonCoreMarketControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.addition.control.EBacApprovalPhEboControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.addition.control.EbacApprovalComplianceControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.addition.control.EntityPartnerControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.addition.control.ExtractCentralRegisterBoControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.addition.control.ExtractCentralRegisterBoFiduciaryControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.addition.control.ExtractCentralRegisterFidTrustControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.addition.control.ExtractTradeRegisterCorpTrusteeControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.addition.control.ExtractTradeRegisterFiduciaryControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.addition.control.FiduciaryMandateControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.addition.control.IdAndPorCorpTrusteeControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.addition.control.IdAndPorEboCorpTrusteeControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.addition.control.InformationRenditekennzifferControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.addition.control.InternetResearchEvidenceControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.addition.control.InvestmentProfileRequestedControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.addition.control.InvestmentProfileSignedControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.addition.control.InvestmentStrategySignedControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.addition.control.KycSignedControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.addition.control.ListAuthSignCorpTrusteeControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.addition.control.ListAuthorisedSignatoriesFiduciaryControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.addition.control.ListDirShrFiduciaryControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.addition.control.NegativePressFindingControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.addition.control.ObtainWssAdviceNonCoreMarketControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.addition.control.OfficeInStandardCountryControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.addition.control.OriginalSignedDocumentControlAdditionBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.addition.control.OwnershipStructureChartFiduciaryControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.addition.control.OwnershipStructureCorpTrusteeControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.addition.control.PaymentReferenceControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.addition.control.PaymentReferenceNameControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.addition.control.PermitBOrLControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.addition.control.PhTaxCountryDifferentApplicableLawControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.addition.control.PotentialConflictOfInterestControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.addition.control.PremiumRationaleControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.addition.control.ProofBeneficialOwnershipControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.addition.control.ProofFamilyMemberControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.addition.control.ProofSettlorEboControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.addition.control.RejectionProcedureControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.addition.control.ShrRegisterAndTradeRegisterControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.addition.control.ShrRegisterCorpTrusteeControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.addition.control.ShrTradeRegisterCorpTrusteeControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.addition.control.SignedOwnershipStructureChartControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.addition.control.StatutesCorpTrusteeControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.addition.control.SustainabilityPreferenceRequestedControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.addition.control.ThirdPartyFormControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.addition.control.ThirdPartyIdAndProofControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.addition.control.VerificationDataSynchronizationBeforeCompletionControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.addition.control.VerificationDocumentsBenControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.addition.control.VerificationDocumentsCertifAndPoaControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.addition.control.VerificationInvestmentProfileControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.addition.control.VerificationSustainabilityPreferenceControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.addition.control.WarningPricingControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.addition.control.WorldCheckScreeningControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.addition.control.WssFeasibilityEBacSubmissionControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.common.NtaAcceptanceReceivedControlBuilderService;

import lombok.AllArgsConstructor;

@Service
@AllArgsConstructor
public class AdditionControlDefinitionBuilderService implements ControlDefinitionBuilderService {

    private final EBacApprovalNonCoreMarketControlBuilderService eBacApprovalNonCoreMarket;
    private final ObtainWssAdviceNonCoreMarketControlBuilderService obtainWssAdviceNonCoreMarket;
    private final RejectionProcedureControlBuilderService rejectionProcedure;
    private final WssFeasibilityEBacSubmissionControlBuilderService wssFeasibilityEBacSubmission;
    private final EBacApprovalPhEboControlBuilderService eBacApprovalPhEbo;
    private final PermitBOrLControlBuilderService permitBOrL;
    private final NegativePressFindingControlBuilderService negativePressFinding;
    private final VerificationDataSynchronizationBeforeCompletionControlBuilderService verificationDataSynchronizationBeforeCompletionControlBuilderService;
    private final CopyOfIdPolicyRoleControlBuilderService copyOfIdPolicyRoleControlBuilderService;
    private final CopyOfPorPolicyRoleControlBuilderService copyOfPorPolicyRoleControlBuilderService;
    private final CopyOfArtAssocStatutesControlBuilderService copyOfArtAssocStatutesControlBuilderService;
    private final CopyOfTradeCertificateControlBuilderService copyOfTradeCertificateControlBuilderService;
    private final CopyOfListDirAuthSignatoriesControlBuilderService copyOfListDirAuthSignatoriesControlBuilderService;
    private final CopyOfIdAuthSignatoriesControlBuilderService copyOfIdAuthSignatoriesControlBuilderService;
    private final CopyOfPorAuthSignatoriesControlBuilderService copyOfPorAuthSignatoriesControlBuilderService;
    private final CopyOfShrRegisterMemberControlBuilderService copyOfShrRegisterMemberControlBuilderService;
    private final ExtractCentralRegisterBoControlBuilderService extractCentralRegisterBoControlBuilderService;
    private final SignedOwnershipStructureChartControlBuilderService signedOwnershipStructureChartControlBuilderService;
    private final ShrRegisterAndTradeRegisterControlBuilderService shrRegisterAndTradeRegisterControlBuilderService;
    private final ProofBeneficialOwnershipControlBuilderService proofBeneficialOwnershipControlBuilderService;
    private final CopyOfIdEboControlBuilderService copyOfIdEboControlBuilderService;
    private final CopyOfPorEboControlBuilderService copyOfPorEboControlBuilderService;
    private final ApprovedAnnualAccountsControlBuilderService approvedAnnualAccountsControlBuilderService;
    private final FiduciaryMandateControlBuilderService fiduciaryMandateControlBuilderService;
    private final ArtAssocFiduciaryControlBuilderService artAssocFiduciaryControlBuilderService;
    private final ExtractTradeRegisterFiduciaryControlBuilderService extractTradeRegisterFiduciaryControlBuilderService;
    private final ListDirShrFiduciaryControlBuilderService listDirShrFiduciaryControlBuilderService;
    private final ExtractCentralRegisterBoFiduciaryControlBuilderService extractCentralRegisterBoFiduciaryControlBuilderService;
    private final OwnershipStructureChartFiduciaryControlBuilderService ownershipStructureChartFiduciaryControlBuilderService;
    private final ListAuthorisedSignatoriesFiduciaryControlBuilderService listAuthorisedSignatoriesFiduciaryControlBuilderService;
    private final CopyOfIdFiduciaryControlBuilderService copyOfIdFiduciaryControlBuilderService;
    private final CopyOfIdEboFiduciaryControlBuilderService copyOfIdEboFiduciaryControlBuilderService;
    private final CopyOfPorEboFiduciaryControlBuilderService copyOfPorEboFiduciaryControlBuilderService;
    private final CertifiedTrustDeedControlBuilderService certifiedTrustDeedControlBuilderService;
    private final DeedAppointmentTrusteesControlBuilderService deedAppointmentTrusteesControlBuilderService;
    private final CertifiedIdEboControlBuilderService certifiedIdEboControlBuilderService;
    private final CertifiedPorEboControlBuilderService certifiedPorEboControlBuilderService;
    private final ExtractCentralRegisterFidTrustControlBuilderService extractCentralRegisterFidTrustControlBuilderService;
    private final StatutesCorpTrusteeControlBuilderService statutesCorpTrusteeControlBuilderService;
    private final ExtractTradeRegisterCorpTrusteeControlBuilderService extractTradeRegisterCorpTrusteeControlBuilderService;
    private final ShrRegisterCorpTrusteeControlBuilderService shrRegisterCorpTrusteeControlBuilderService;
    private final ListAuthSignCorpTrusteeControlBuilderService listAuthSignCorpTrusteeControlBuilderService;
    private final IdAndPorCorpTrusteeControlBuilderService idAndPorCorpTrusteeControlBuilderService;
    private final OwnershipStructureCorpTrusteeControlBuilderService ownershipStructureCorpTrusteeControlBuilderService;
    private final ShrTradeRegisterCorpTrusteeControlBuilderService shrTradeRegisterCorpTrusteeControlBuilderService;
    private final IdAndPorEboCorpTrusteeControlBuilderService idAndPorEboCorpTrusteeControlBuilderService;
    private final PotentialConflictOfInterestControlBuilderService potentialConflictOfInterestControlBuilderService;
    private final DocumentationOriginFundControlBuilderService documentationOriginFundControlBuilderService;
    private final BankAccountEvidenceControlBuilderService bankAccountEvidenceControlBuilderService;
    private final AdditionFormSignedIbControlBuilderService additionFormSignedIbControlBuilderService;
    private final AllocationRateToAmendAndBecMatchingControlBuilderService allocationRateToAmendAndBecMatchingControlBuilderService;
    private final BrokerAuthorisedInCountrySignatureControlBuilderService brokerAuthorisedInCountrySignatureControlBuilderService;
    private final BrokerAuthorisedInPhCountryControlBuilderService brokerAuthorisedInPhCountryControlBuilderService;
    private final ClearIdIbControlBuilderService clearIdIbControlBuilderService;
    private final ClearIdPoaControlBuilderService clearIdPoaControlBuilderService;
    private final CopyPoaControlBuilderService copyPoaControlBuilderService;
    private final CopyProofResidenceIbControlBuilderService copyProofResidenceIbControlBuilderService;
    private final DeviationSuitabilityProfileControlBuilderService deviationSuitabilityProfileControlBuilderService;
    private final EbacApprovalComplianceControlBuilderService ebacApprovalComplianceControlBuilderService;
    private final InformationRenditekennzifferControlBuilderService informationRenditekennzifferControlBuilderService;
    private final InternetResearchEvidenceControlBuilderService internetResearchEvidenceControlBuilderService;
    private final InvestmentProfileRequestedControlBuilderService investmentProfileRequestedControlBuilderService;
    private final InvestmentProfileSignedControlBuilderService investmentProfileSignedControlBuilderService;
    private final InvestmentStrategySignedControlBuilderService investmentStrategySignedControlBuilderService;
    private final KycSignedControlBuilderService kycSignedControlBuilderService;
    private final NtaAcceptanceReceivedControlBuilderService ntaAcceptanceReceivedControlBuilderService;
    private final PhTaxCountryDifferentApplicableLawControlBuilderService phTaxCountryDifferentApplicableLawControlBuilderService;
    private final SustainabilityPreferenceRequestedControlBuilderService sustainabilityPreferenceRequestedControlBuilderService;
    private final VerificationDocumentsBenControlBuilderService verificationDocumentsBenControlBuilderService;
    private final VerificationDocumentsCertifAndPoaControlBuilderService verificationDocumentsCertifAndPoaControlBuilderService;
    private final VerificationInvestmentProfileControlBuilderService verificationInvestmentProfileControlBuilderService;
    private final VerificationSustainabilityPreferenceControlBuilderService verificationSustainabilityPreferenceControlBuilderService;
    private final WarningPricingControlBuilderService warningPricingControlBuilderService;
    private final WorldCheckScreeningControlBuilderService worldCheckScreeningControlBuilderService;
    private final AeoiMrlControlBuilderService aeoiMrlControlBuilderService;
    private final AeoiPassiveControlBuilderService aeoiPassiveControlBuilderService;
    private final AeoiSelfControlBuilderService aeoiSelfControlBuilderService;
    private final AeoiTrustControlBuilderService aeoiTrustControlBuilderService;
    private final BankStatementWithAmountControlBuilderService bankStatementWithAmountControlBuilderService;
    private final BusinessHandbookControlBuilderService businessHandbookControlBuilderService;
    private final EntityPartnerControlBuilderService entityPartnerControlBuilderService;
    private final ThirdPartyFormControlBuilderService thirdPartyFormControlBuilderService;
    private final ThirdPartyIdAndProofControlBuilderService thirdPartyIdAndProofControlBuilderService;
    private final ProofFamilyMemberControlBuilderService proofFamilyMemberControlBuilderService;
    private final ProofSettlorEboControlBuilderService proofSettlorEboControlBuilderService;
    private final PremiumRationaleControlBuilderService premiumRationaleControlBuilderService;
    private final PaymentReferenceControlBuilderService paymentReferenceControlBuilderService;
    private final PaymentReferenceNameControlBuilderService paymentReferenceNameControlBuilderService;
    private final OfficeInStandardCountryControlBuilderService officeInStandardCountryControlBuilderService;
    private final ClientIdentificationOnFileControlAdditionBuilderService clientIdentificationOnFileControlAdditionBuilderService;
    private final OriginalSignedDocumentControlAdditionBuilderService originalSignedDocumentControlAdditionBuilderService;

    @Override
    public List<ControlDefinition> buildControlDefinition(final WebForm webForm, final ScreenDescription screenDescription) {

        ControlDefinition.resetControlOrder();
        List<AbstractControlBuilderService> controlBuilderServices = Arrays.asList(eBacApprovalNonCoreMarket, obtainWssAdviceNonCoreMarket,
                rejectionProcedure, wssFeasibilityEBacSubmission,
                // Physical BAC approval - 50€ is not relevant anymore
                eBacApprovalPhEbo,
                // eBAC approval upon compliance decision (PH/EBO country of residence) needs to be checked by David H.
                permitBOrL, copyOfIdPolicyRoleControlBuilderService, copyOfPorPolicyRoleControlBuilderService,
                copyOfArtAssocStatutesControlBuilderService, copyOfTradeCertificateControlBuilderService,
                copyOfListDirAuthSignatoriesControlBuilderService, copyOfIdAuthSignatoriesControlBuilderService,
                copyOfPorAuthSignatoriesControlBuilderService, copyOfShrRegisterMemberControlBuilderService,
                extractCentralRegisterBoControlBuilderService, signedOwnershipStructureChartControlBuilderService,
                shrRegisterAndTradeRegisterControlBuilderService, proofBeneficialOwnershipControlBuilderService, copyOfIdEboControlBuilderService,
                copyOfPorEboControlBuilderService, approvedAnnualAccountsControlBuilderService, fiduciaryMandateControlBuilderService,
                artAssocFiduciaryControlBuilderService, extractTradeRegisterFiduciaryControlBuilderService,
                listDirShrFiduciaryControlBuilderService, extractCentralRegisterBoFiduciaryControlBuilderService,
                ownershipStructureChartFiduciaryControlBuilderService, listAuthorisedSignatoriesFiduciaryControlBuilderService,
                copyOfIdFiduciaryControlBuilderService, copyOfIdEboFiduciaryControlBuilderService, copyOfPorEboFiduciaryControlBuilderService,
                certifiedTrustDeedControlBuilderService, deedAppointmentTrusteesControlBuilderService, certifiedIdEboControlBuilderService,
                certifiedPorEboControlBuilderService, extractCentralRegisterFidTrustControlBuilderService,
                statutesCorpTrusteeControlBuilderService, extractTradeRegisterCorpTrusteeControlBuilderService,
                shrRegisterCorpTrusteeControlBuilderService, listAuthSignCorpTrusteeControlBuilderService,
                idAndPorCorpTrusteeControlBuilderService, ownershipStructureCorpTrusteeControlBuilderService,
                shrTradeRegisterCorpTrusteeControlBuilderService, idAndPorEboCorpTrusteeControlBuilderService,
                potentialConflictOfInterestControlBuilderService, documentationOriginFundControlBuilderService,
                bankAccountEvidenceControlBuilderService, additionFormSignedIbControlBuilderService,
                allocationRateToAmendAndBecMatchingControlBuilderService, brokerAuthorisedInCountrySignatureControlBuilderService,
                brokerAuthorisedInPhCountryControlBuilderService, clearIdIbControlBuilderService, clearIdPoaControlBuilderService,
                copyPoaControlBuilderService, copyProofResidenceIbControlBuilderService, deviationSuitabilityProfileControlBuilderService,
                ebacApprovalComplianceControlBuilderService, informationRenditekennzifferControlBuilderService,
                internetResearchEvidenceControlBuilderService, investmentProfileRequestedControlBuilderService,
                investmentProfileSignedControlBuilderService, investmentStrategySignedControlBuilderService, kycSignedControlBuilderService,
                ntaAcceptanceReceivedControlBuilderService, phTaxCountryDifferentApplicableLawControlBuilderService,
                sustainabilityPreferenceRequestedControlBuilderService, negativePressFinding,
                verificationDataSynchronizationBeforeCompletionControlBuilderService, verificationDocumentsBenControlBuilderService,
                verificationDocumentsCertifAndPoaControlBuilderService, verificationInvestmentProfileControlBuilderService,
                verificationSustainabilityPreferenceControlBuilderService, warningPricingControlBuilderService,
                worldCheckScreeningControlBuilderService, aeoiMrlControlBuilderService, aeoiPassiveControlBuilderService,
                aeoiSelfControlBuilderService, aeoiTrustControlBuilderService, bankStatementWithAmountControlBuilderService,
                businessHandbookControlBuilderService, entityPartnerControlBuilderService, thirdPartyFormControlBuilderService,
                thirdPartyIdAndProofControlBuilderService, proofSettlorEboControlBuilderService, proofFamilyMemberControlBuilderService,
                premiumRationaleControlBuilderService, paymentReferenceControlBuilderService, paymentReferenceNameControlBuilderService,
                officeInStandardCountryControlBuilderService, clientIdentificationOnFileControlAdditionBuilderService,
                originalSignedDocumentControlAdditionBuilderService);
        final var controls = new ArrayList<ControlDefinition>();
        controlBuilderServices.forEach(service -> Optional.ofNullable(service.buildControl(webForm, screenDescription)).ifPresent(controls::add));
        return controls;
    }
}
