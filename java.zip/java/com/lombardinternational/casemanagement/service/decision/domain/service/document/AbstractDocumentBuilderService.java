package com.lombardinternational.casemanagement.service.decision.domain.service.document;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.DocumentDefinition;

import java.util.List;

public abstract class AbstractDocumentBuilderService implements DocumentBuilderService {

    protected void buildDocumentDefinition(final String relatedTo, final String relatedToPolicyNumber, final String i18NRelatedToParam,
            final String relatedToThirdParty, final List<DocumentDefinition> documents) {

        if (!relatedTo.isBlank()) {
            final var documentDefinition = DocumentDefinition.builder().documentType(getDocumentType()).cmsDocumentType(getCmsDocumentType())
                    .documentRequired(getDocumentRequired()).documentVisibleOnConnect(getDocumentVisibleOnConnect()).description(getDescription())
                    .i18NDescription(getI18NDescription()).documentRelatedTo(getCmtRelatedToPrefix() + " - " + relatedTo)
                    .relatedToPolicyNumber(relatedToPolicyNumber).i18NDocumentRelatedToParam(i18NRelatedToParam)
                    .i18NDocumentRelatedTo(getI18NDocumentRelatedTo()).relatedToThirdpartyId(relatedToThirdParty)
                    .neverDisplayExternally(getNeverDisplayExternally()).build();
            documentDefinition.incrementOrder();
            documents.add(documentDefinition);
        }
    }

    protected abstract String getDocumentType();

    protected abstract String getCmsDocumentType();

    protected boolean getDocumentRequired() {

        return false;
    }

    protected boolean getDocumentVisibleOnConnect() {

        return false;
    }

    protected abstract String getDescription();

    protected abstract String getI18NDescription();

    protected String getCmtRelatedToPrefix() {

        return getDescription();
    }

    protected String getI18NDocumentRelatedTo() {

        return null;
    }

    protected boolean getNeverDisplayExternally() {

        return false;
    }
}
