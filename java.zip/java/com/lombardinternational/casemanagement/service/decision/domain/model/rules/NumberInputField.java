package com.lombardinternational.casemanagement.service.decision.domain.model.rules;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.RequiredArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder
@RequiredArgsConstructor
@EqualsAndHashCode(callSuper = true)
public class NumberInputField extends Field {

    private Integer min;
    private Integer max;
    private Integer decimals;
    private Integer size;
}
