package com.lombardinternational.casemanagement.service.decision.domain.service.taskscreen.common.groups;

import org.springframework.stereotype.Service;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Group;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Tab;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.taskscreen.TaskScreenGroupBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.taskscreen.common.fields.CommonIdentificationOfSmallCapFieldsBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.utils.RulesUtils;

import lombok.AllArgsConstructor;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.TaskScreenConstants.IDENTIFICATION_OF_SMALL_CAP_GROUP;

@Service
@AllArgsConstructor
public class CommonIdentificationOfSmallCapGroupBuilderService implements TaskScreenGroupBuilderService {

    private final CommonIdentificationOfSmallCapFieldsBuilderService service;

    @Override
    public void buildGroup(final WebForm webForm, final ScreenDescription screenCheckList, final ScreenDescription screenToFill,
            final Tab parentTab) {

        var identificationOfSmallCapGroup = RulesUtils.getGroupInTab(parentTab, IDENTIFICATION_OF_SMALL_CAP_GROUP);
        if (identificationOfSmallCapGroup == null) {
            identificationOfSmallCapGroup = Group.builder().groupId(IDENTIFICATION_OF_SMALL_CAP_GROUP).build();
            parentTab.getGroups().add(identificationOfSmallCapGroup);
        }
        identificationOfSmallCapGroup.setIsActive(true);
        identificationOfSmallCapGroup.incrementOrder();
        identificationOfSmallCapGroup.setTitle("Identification of small cap (market capitalisation lower than €300 Mios)?");
        service.buildField(webForm, screenCheckList, screenToFill, identificationOfSmallCapGroup);
    }
}
