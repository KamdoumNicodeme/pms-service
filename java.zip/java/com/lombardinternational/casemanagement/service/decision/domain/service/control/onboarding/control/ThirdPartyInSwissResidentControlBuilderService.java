package com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control;

import java.util.Collections;
import java.util.List;

import org.springframework.stereotype.Service;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ControlDefinition;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.AbstractControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control.common.Constants;
import com.lombardinternational.casemanagement.service.decision.domain.utils.Constraint;
import com.lombardinternational.casemanagement.service.decision.domain.utils.FieldConstraint;

import static com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control.common.Constants.CH;
import static com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control.common.Utils.createConstraintWithMultiple;
import static com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control.common.Utils.createConstraintWithNegate;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ChecklistFieldConstants.COUNTRY_OF_LAW;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ChecklistFieldConstants.THIRD_PARTY_SUB_TYPE_PH;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ControlConstants.THIRD_PARTY_IN_SWISS_RESIDENT_NAME;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ControlConstants.THIRD_PARTY_IN_SWISS_RESIDENT_TYPE;

@Service
public class ThirdPartyInSwissResidentControlBuilderService extends AbstractControlBuilderService {

    @Override
    public ControlDefinition buildControl(WebForm webForm, ScreenDescription screenDescription) {

        final List<FieldConstraint> constraints = List.of(
                createConstraintWithNegate(COUNTRY_OF_LAW, Constraint.EQUALS, Collections.singletonList(CH), Boolean.TRUE),
                createConstraintWithMultiple(THIRD_PARTY_SUB_TYPE_PH, Constraint.IN, Boolean.TRUE, Collections.singletonList(Constants.TRUST)));

        if (constraints.stream().allMatch(constraint -> constraint.test(screenDescription))) {
            return buildControlDefinition();
        }
        return null;
    }

    @Override
    protected String getControlName() {

        return THIRD_PARTY_IN_SWISS_RESIDENT_NAME;
    }

    @Override
    protected String getControlType() {

        return THIRD_PARTY_IN_SWISS_RESIDENT_TYPE;
    }
}
