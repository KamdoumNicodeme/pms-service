package com.lombardinternational.casemanagement.service.decision.domain.utils;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

import com.lombardinternational.casemanagement.service.decision.domain.model.policy.AbstractPerson;
import com.lombardinternational.casemanagement.service.decision.domain.model.policy.EconomicBeneficiary;
import com.lombardinternational.casemanagement.service.decision.domain.model.policy.Policy;
import com.lombardinternational.casemanagement.service.decision.domain.model.policy.PolicyRole;
import com.lombardinternational.casemanagement.service.decision.domain.model.policy.SourceOfFunds;
import com.lombardinternational.casemanagement.service.decision.domain.model.policy.SourcesOfWealth;

public class PolicyUtils {

    public static List<AbstractPerson> getThirdPartiesByRole(final Policy policy, List<String> roles) {

        List<PolicyRole> policyRoles = new ArrayList<>();
        for (String role : roles) {
            switch (role) {
            case "HLR":
                policyRoles.addAll(Optional.ofNullable(policy.getHolders()).stream().flatMap(Collection::stream).toList());
                break;
            case "EBO":
                policyRoles.addAll(Optional.ofNullable(policy.getEconomicBeneficiaries()).stream().flatMap(Collection::stream).toList());
                break;
            case "LA":
                policyRoles.addAll(Optional.ofNullable(policy.getLifeAssureds()).stream().flatMap(Collection::stream).toList());
                break;
            case "BEN":
                policyRoles.addAll(Optional.ofNullable(policy.getBeneficiaries()).stream().flatMap(Collection::stream).toList());
                break;
            case "IB":
                policyRoles.addAll(Optional.ofNullable(policy.getIrrevocableBeneficiaries()).stream().flatMap(Collection::stream).toList());
                break;
            case "TRUST":
                policyRoles.addAll(Optional.ofNullable(policy.getTrusts()).stream().flatMap(Collection::stream).toList());
                break;
            case "TRUSTEE":
                policyRoles.addAll(Optional.ofNullable(policy.getTrustees()).stream().flatMap(Collection::stream).toList());
                break;
            case "SETTLOR":
                policyRoles.addAll(Optional.ofNullable(policy.getSettlors()).stream().flatMap(Collection::stream).toList());
                break;
            case "PROXY":
                policyRoles.addAll(Optional.ofNullable(policy.getProxies()).stream().flatMap(Collection::stream).toList());
                break;
            case "CESSIONH":
                policyRoles.addAll(Optional.ofNullable(policy.getCessionHolders()).stream().flatMap(Collection::stream).toList());
                break;
            default:
                break;
            }
        }
        return policyRoles.stream().map(PolicyRole::getThirdParties).filter(Objects::nonNull).flatMap(Collection::stream).distinct().toList();
    }

    public static List<SourcesOfWealth> getFilteredSourcesOfWealthByPerson(final AbstractPerson person, final String pattern) {

        return getSourceOfWealthByPerson(person).stream().filter(sow -> sow.getDeleted() == null || !sow.getDeleted())
                .filter(sow -> sow.getDescription() != null && sow.getDescription().matches(pattern))
                .filter(sow -> sow.getSplitPercentage() != null).toList();
    }

    public static List<SourcesOfWealth> getSourceOfWealthByPerson(final AbstractPerson person) {

        return Optional.ofNullable(person.getSourceOfFunds()).stream().map(SourceOfFunds::getSourcesOfWealth).filter(Objects::nonNull)
                .flatMap(Collection::stream).toList();
    }

    public static Optional<AbstractPerson> getPerson(PolicyRole role) {

        return role.getThirdParties().stream().filter(Objects::nonNull).findFirst();
    }

    public static List<AbstractPerson> getPersons(List<EconomicBeneficiary> roles) {

        return roles.stream().map(PolicyRole::getThirdParties).filter(Objects::nonNull).flatMap(Collection::stream).toList();
    }
}
