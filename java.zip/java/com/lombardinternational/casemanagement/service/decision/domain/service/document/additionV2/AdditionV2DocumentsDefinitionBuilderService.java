package com.lombardinternational.casemanagement.service.decision.domain.service.document.additionV2;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Service;

import com.lombardinternational.casemanagement.service.decision.domain.exception.ClassInternalException;
import com.lombardinternational.casemanagement.service.decision.domain.model.policy.Policy;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.DocumentDefinition;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebFormGroup;
import com.lombardinternational.casemanagement.service.decision.domain.service.document.AbstractDocumentBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.document.DocumentsDefinitionBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.document.additionV2.document.AuthorisedSignatoriesDocumentBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.document.additionV2.document.DealingRequestFormDocumentBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.document.additionV2.document.DifferentStrategyDocumentBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.document.additionV2.document.FactFindDocumentBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.document.additionV2.document.FasAdvisoryMandateDocumentBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.document.additionV2.document.HaveUnquotedProductDocumentBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.document.additionV2.document.InvestmentStrategyToAttachDocumentBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.document.additionV2.document.PremiumAssetTransferPortfolioDocumentBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.document.additionV2.document.SignatoriesIdDocumentBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.document.additionV2.document.kyc.moral.AgmMinutesDocumentBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.document.additionV2.document.kyc.moral.BankStatementEntityDocumentBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.document.additionV2.document.kyc.moral.CompanyAccountsDividendDocumentBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.document.additionV2.document.kyc.moral.CompanyIdentificationLessThan3MonthsDocumentBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.document.additionV2.document.kyc.moral.CopyDeedOfSaleSignedDocumentBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.document.additionV2.document.kyc.moral.CopyLegalPublicationsDividendDocumentBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.document.additionV2.document.kyc.moral.DeedOfTransferOfSharesDocumentBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.document.additionV2.document.kyc.moral.ExtractSubscriberBankAccountDocumentBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.document.additionV2.document.kyc.moral.FinancialStatementsSaleDocumentBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.document.additionV2.document.kyc.physical.CertificateOfOwnershipDocumentBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.document.additionV2.document.kyc.physical.ConfirmationLetterGamblingDocumentBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.document.additionV2.document.kyc.physical.CopyAssetPortfolioDocumentBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.document.additionV2.document.kyc.physical.CopyDeedOfSaleDocumentBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.document.additionV2.document.kyc.physical.CopyEmploymentContractDocumentBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.document.additionV2.document.kyc.physical.CopyLatestTaxReturnDocumentBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.document.additionV2.document.kyc.physical.CopyLegalPublicationsDocumentBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.document.additionV2.document.kyc.physical.CopyOfChequeGamblingDocumentBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.document.additionV2.document.kyc.physical.CopyPaySlipDocumentBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.document.additionV2.document.kyc.physical.CopyRemunerationSheetDocumentBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.document.additionV2.document.kyc.physical.DeedOfSaleDocumentBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.document.additionV2.document.kyc.physical.DeedOfSalesSignedDocumentBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.document.additionV2.document.kyc.physical.DivorceCertificateDocumentBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.document.additionV2.document.kyc.physical.FinancialStatementsDocumentBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.document.additionV2.document.kyc.physical.InvestmentSoldNameDocumentBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.document.additionV2.document.kyc.physical.LetterIdentifyingRecipientDocumentBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.document.additionV2.document.kyc.physical.NotarisedDeedDocumentBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.document.additionV2.document.kyc.physical.NotarisedDeedOfSuccessionDocumentBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.document.additionV2.document.kyc.physical.ProofOfPaymentDivorceDocumentBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.document.additionV2.document.kyc.physical.ProofOfPaymentDocumentBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.document.additionV2.document.kyc.physical.ProofOfPaymentGamblingDocumentBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.utils.WebformUtils;

import lombok.AllArgsConstructor;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.WebFormFieldConstants.DETAILS_WF;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.WebFormFieldConstants.EBO_KYCS_WF;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.WebFormFieldConstants.EBO_TYPE_ENTITY;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.WebFormFieldConstants.EBO_TYPE_GLOBAL_LIST;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.WebFormFieldConstants.EBO_TYPE_WF;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.WebFormFieldConstants.IS_KYC_REQUIRED_WF;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.WebFormFieldConstants.KYC_WF;

@Service
@AllArgsConstructor
public class AdditionV2DocumentsDefinitionBuilderService implements DocumentsDefinitionBuilderService {

    private final SignatoriesIdDocumentBuilderService signatoriesIdDocumentBuilderService;
    private final PremiumAssetTransferPortfolioDocumentBuilderService premiumAssetTransferPortfolioDocumentBuilderService;
    private final AuthorisedSignatoriesDocumentBuilderService authorisedSignatoriesDocumentBuilderService;
    private final FactFindDocumentBuilderService factFindDocumentBuilderService;
    private final CopyPaySlipDocumentBuilderService copyPaySlipDocumentBuilderService;
    private final CopyLatestTaxReturnDocumentBuilderService copyLatestTaxReturnDocumentBuilderService;
    private final CopyRemunerationSheetDocumentBuilderService copyRemunerationSheetDocumentBuilderService;
    private final CopyEmploymentContractDocumentBuilderService copyEmploymentContractDocumentBuilderService;
    private final DeedOfSalesSignedDocumentBuilderService deedOfSalesSignedDocumentBuilderService;
    private final ProofOfPaymentDocumentBuilderService proofOfPaymentDocumentBuilderService;
    private final CopyAssetPortfolioDocumentBuilderService copyAssetPortfolioDocumentBuilderService;
    private final InvestmentSoldNameDocumentBuilderService investmentSoldNameDocumentBuilderService;
    private final CertificateOfOwnershipDocumentBuilderService certificateOfOwnershipDocumentBuilderService;
    private final DeedOfSaleDocumentBuilderService deedOfSaleDocumentBuilderService;
    private final CopyDeedOfSaleDocumentBuilderService copyDeedOfSaleDocumentBuilderService;
    private final FinancialStatementsDocumentBuilderService financialStatementsDocumentBuilderService;
    private final CopyLegalPublicationsDocumentBuilderService copyLegalPublicationsDocumentBuilderService;
    private final NotarisedDeedOfSuccessionDocumentBuilderService notarisedDeedOfSuccessionDocumentBuilderService;
    private final LetterIdentifyingRecipientDocumentBuilderService letterIdentifyingRecipientDocumentBuilderService;
    private final NotarisedDeedDocumentBuilderService notarisedDeedDocumentBuilderService;
    private final DivorceCertificateDocumentBuilderService divorceCertificateDocumentBuilderService;
    private final ProofOfPaymentDivorceDocumentBuilderService proofOfPaymentDivorceDocumentBuilderService;
    private final ConfirmationLetterGamblingDocumentBuilderService confirmationLetterGamblingDocumentBuilderService;
    private final CopyOfChequeGamblingDocumentBuilderService copyOfChequeGamblingDocumentBuilderService;
    private final ProofOfPaymentGamblingDocumentBuilderService proofOfPaymentGamblingDocumentBuilderService;
    private final DeedOfTransferOfSharesDocumentBuilderService deedOfTransferOfSharesDocumentBuilderService;
    private final BankStatementEntityDocumentBuilderService bankStatementEntityDocumentBuilderService;
    private final AgmMinutesDocumentBuilderService agmMinutesDocumentBuilderService;
    private final CompanyIdentificationLessThan3MonthsDocumentBuilderService companyIdentificationLessThan3MonthsDocumentBuilderService;
    private final ExtractSubscriberBankAccountDocumentBuilderService extractSubscriberBankAccountDocumentBuilderService;
    private final CompanyAccountsDividendDocumentBuilderService companyAccountsDividendDocumentBuilderService;
    private final CopyLegalPublicationsDividendDocumentBuilderService copyLegalPublicationsDividendDocumentBuilderService;
    private final CopyDeedOfSaleSignedDocumentBuilderService copyDeedOfSaleSignedDocumentBuilderService;
    private final FinancialStatementsSaleDocumentBuilderService financialStatementsSaleDocumentBuilderService;
    private final InvestmentStrategyToAttachDocumentBuilderService investmentStrategyToAttachDocumentBuilderService;
    private final HaveUnquotedProductDocumentBuilderService haveUnquotedProductDocumentBuilderService;
    private final DifferentStrategyDocumentBuilderService differentStrategyDocumentBuilderService;
    private final FasAdvisoryMandateDocumentBuilderService fasAdvisoryMandateDocumentBuilderService;
    private final DealingRequestFormDocumentBuilderService dealingRequestFormDocumentBuilderService;

    @Override
    public List<DocumentDefinition> buildDocumentsDefinition(Policy policy, WebForm webForm, ScreenDescription screenDescription,
        String transactionNumber) {

        final var documents = new ArrayList<DocumentDefinition>();
        List<AbstractDocumentBuilderService> services = new ArrayList<>(List.of(signatoriesIdDocumentBuilderService,
            premiumAssetTransferPortfolioDocumentBuilderService, authorisedSignatoriesDocumentBuilderService, factFindDocumentBuilderService,
            investmentStrategyToAttachDocumentBuilderService, haveUnquotedProductDocumentBuilderService,
            differentStrategyDocumentBuilderService, fasAdvisoryMandateDocumentBuilderService, dealingRequestFormDocumentBuilderService));

        // Get document linked to KYC
        services.addAll(getKycDocumentBuilderService(webForm));

        services.forEach(service -> {
            try {
                service.buildDocument(webForm, screenDescription, transactionNumber, documents);
            } catch (Exception e) {
                throw new ClassInternalException(e.getMessage());
            }
        });

        return documents;
    }

    List<AbstractDocumentBuilderService> getKycDocumentBuilderService(WebForm webForm) {

        List<AbstractDocumentBuilderService> servicesList = new ArrayList<>();
        boolean isGlobalKycDocumentsAdded = false;
        boolean isEntityKycDocumentsAdded = false;

        var isKycRequired = WebformUtils.getWebFormFieldValueById(webForm, IS_KYC_REQUIRED_WF);

        if ("true".equalsIgnoreCase(isKycRequired)) {
            var kyc = WebformUtils.getFirstWebFormGroupById(webForm, KYC_WF);
            if (kyc != null && CollectionUtils.isNotEmpty(kyc.getGroups())) {
                var details = WebformUtils.getGroupInGroup(kyc, DETAILS_WF);
                if (details != null && CollectionUtils.isNotEmpty(details.getGroups())) {
                    var ebosKycs = WebformUtils.getGroupInGroup(details, EBO_KYCS_WF);
                    if (ebosKycs != null && CollectionUtils.isNotEmpty(ebosKycs.getGroups())) {
                        for (WebFormGroup eboKycGroup : ebosKycs.getGroups()) {
                            var eboType = WebformUtils.getWebFormFieldValueById(eboKycGroup, EBO_TYPE_WF);
                            if (EBO_TYPE_GLOBAL_LIST.contains(eboType) && !isGlobalKycDocumentsAdded) {
                                servicesList.addAll(getMoralPhysicalDocumentBuilderService());
                                isGlobalKycDocumentsAdded = true;
                            } else if (EBO_TYPE_ENTITY.equalsIgnoreCase(eboType) && !isEntityKycDocumentsAdded) {
                                servicesList.addAll(getEntityDocumentBuilderService());
                                isEntityKycDocumentsAdded = true;
                            }
                        }
                    }
                }
            }
        }
        return servicesList;
    }

    List<AbstractDocumentBuilderService> getEntityDocumentBuilderService() {

        return List.of(deedOfTransferOfSharesDocumentBuilderService, bankStatementEntityDocumentBuilderService, agmMinutesDocumentBuilderService,
            companyIdentificationLessThan3MonthsDocumentBuilderService, extractSubscriberBankAccountDocumentBuilderService,
            companyAccountsDividendDocumentBuilderService, copyLegalPublicationsDividendDocumentBuilderService,
            copyDeedOfSaleSignedDocumentBuilderService, financialStatementsSaleDocumentBuilderService);
    }

    List<AbstractDocumentBuilderService> getMoralPhysicalDocumentBuilderService() {

        return List.of(copyPaySlipDocumentBuilderService, copyLatestTaxReturnDocumentBuilderService, copyRemunerationSheetDocumentBuilderService,
            copyEmploymentContractDocumentBuilderService, deedOfSalesSignedDocumentBuilderService, proofOfPaymentDocumentBuilderService,
            copyAssetPortfolioDocumentBuilderService, investmentSoldNameDocumentBuilderService, certificateOfOwnershipDocumentBuilderService,
            deedOfSaleDocumentBuilderService, copyDeedOfSaleDocumentBuilderService, financialStatementsDocumentBuilderService,
            copyLegalPublicationsDocumentBuilderService, notarisedDeedOfSuccessionDocumentBuilderService,
            letterIdentifyingRecipientDocumentBuilderService, notarisedDeedDocumentBuilderService, divorceCertificateDocumentBuilderService,
            proofOfPaymentDivorceDocumentBuilderService, confirmationLetterGamblingDocumentBuilderService,
            copyOfChequeGamblingDocumentBuilderService, proofOfPaymentGamblingDocumentBuilderService);
    }
}
