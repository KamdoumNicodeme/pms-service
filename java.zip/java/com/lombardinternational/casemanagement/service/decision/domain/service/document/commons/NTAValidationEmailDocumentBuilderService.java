package com.lombardinternational.casemanagement.service.decision.domain.service.document.commons;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.springframework.stereotype.Service;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.DocumentDefinition;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.document.AbstractDocumentBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.utils.Constraint;
import com.lombardinternational.casemanagement.service.decision.domain.utils.FieldConstraint;
import com.lombardinternational.casemanagement.service.decision.domain.utils.WebformUtils;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ChecklistFieldConstants.*;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.DocumentConstants.*;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.WebFormFieldConstants.*;

@Service
public class NTAValidationEmailDocumentBuilderService extends AbstractDocumentBuilderService {

    @Override
    public void buildDocument(final WebForm webForm, final ScreenDescription screenDescription, String transactionNumber,
            List<DocumentDefinition> documents) {

        final var constraints = new ArrayList<FieldConstraint>();
        constraints.add(
                FieldConstraint.builder().fieldId(PREMIUM_WITH_UNQ_ASSETS).constraint(Constraint.EQUALS).values(Collections.singletonList("YES"))
                        .build());
        if (constraints.stream().allMatch(constraint -> constraint.test(screenDescription))) {
            var relatedTo = WebformUtils.getWebFormFieldValueById(webForm, POLICY_NUMBER_WF);
            buildDocumentDefinition(relatedTo, relatedTo, null, null, documents);
        }
    }

    @Override
    protected String getDocumentType() {

        return EMAIL_DOC_TYPE;
    }

    @Override
    protected String getCmsDocumentType() {

        return EMAIL_CMS_DOC_TYPE;
    }

    @Override
    protected String getDescription() {

        return NTA_VALIDATION_EMAIL_FORM_DESCRIPTION;
    }

    @Override
    protected String getI18NDescription() {

        return NTA_VALIDATION_EMAIL_FORM_I18N_DESCRIPTION;
    }
}
