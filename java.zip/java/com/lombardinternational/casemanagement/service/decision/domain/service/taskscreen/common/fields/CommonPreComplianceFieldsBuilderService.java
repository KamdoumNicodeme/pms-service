package com.lombardinternational.casemanagement.service.decision.domain.service.taskscreen.common.fields;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Group;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.SelectInputField;
import com.lombardinternational.casemanagement.service.decision.domain.spi.repository.ReferenceDataRepositoryService;
import com.lombardinternational.casemanagement.service.decision.domain.utils.ChecklistUtils;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ReferenceConstants.*;

public class CommonPreComplianceFieldsBuilderService {


    public static void evaluateContainedInPortfolio(Group group, ReferenceDataRepositoryService referenceDataRepositoryService, String fieldId) {

        var containedInPortfolio = (SelectInputField) ChecklistUtils.getFieldInGroup(group, fieldId);
        if (containedInPortfolio == null) {
            containedInPortfolio = SelectInputField.builder().fieldId(fieldId).build();
            group.getFields().add(containedInPortfolio);
        }
        containedInPortfolio.setIsActive(true);
        containedInPortfolio.incrementOrder();
        containedInPortfolio.setEnabled(true);
        containedInPortfolio.setMandatory(true);
        containedInPortfolio.setLabel("Contained in the portfolio");
        containedInPortfolio.setOptions(referenceDataRepositoryService.getReferenceDataOptionsByDomain(YES_NO_DOMAIN));
    }


}
