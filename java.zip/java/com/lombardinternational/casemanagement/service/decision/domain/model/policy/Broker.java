package com.lombardinternational.casemanagement.service.decision.domain.model.policy;

import lombok.Data;

@Data
public class Broker {

    private String number;
    private String name;
    private String locationCode;
    private String serviceTeam;
    private String globalPartnerCode;
    private String distanceSellingApprovalStatus;
    private String partnerType;
}
