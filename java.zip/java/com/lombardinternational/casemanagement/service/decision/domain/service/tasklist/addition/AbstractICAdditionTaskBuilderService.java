package com.lombardinternational.casemanagement.service.decision.domain.service.tasklist.addition;

import com.lombardinternational.casemanagement.service.decision.domain.service.tasklist.common.task.CommonAbstractICTaskBuilderService;

public abstract class AbstractICAdditionTaskBuilderService extends CommonAbstractICTaskBuilderService {

    @Override
    public String getTaskDynamicScreenId() {

        return "IC_ADDITION";
    }
}
