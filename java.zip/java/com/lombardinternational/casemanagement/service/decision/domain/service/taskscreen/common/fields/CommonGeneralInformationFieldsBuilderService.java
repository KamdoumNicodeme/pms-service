package com.lombardinternational.casemanagement.service.decision.domain.service.taskscreen.common.fields;


import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Group;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.NumberInputField;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.SelectInputField;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.TextInputField;
import com.lombardinternational.casemanagement.service.decision.domain.spi.repository.ReferenceDataRepositoryService;
import com.lombardinternational.casemanagement.service.decision.domain.utils.ChecklistUtils;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ChecklistFieldConstants.*;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ReferenceConstants.*;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.TaskScreenConstants.*;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.TaskScreenConstants.PORTFOLIO_VALUE_FIELD;

public class CommonGeneralInformationFieldsBuilderService {


    public static void evaluatePolicyNumber(Group group, ScreenDescription screen) {

        var policyNumber = (TextInputField) ChecklistUtils.getFieldInGroup(group, POLICY_NUMBER_FIELD);
        if (policyNumber == null) {
            policyNumber = TextInputField.builder().fieldId(POLICY_NUMBER_FIELD).build();
            group.getFields().add(policyNumber);
        }
        policyNumber.setIsActive(true);
        policyNumber.incrementOrder();
        policyNumber.setLabel("Policy number");
        var policy = ChecklistUtils.getFieldById(screen, POLICY_NUMBER).orElse(null);
        if (policy != null) {
            policyNumber.setSelectedValue(policy.getSelectedValue());
        }
    }

    public static void evaluateDateStatement(Group group) {

        var dateStatement = (TextInputField) ChecklistUtils.getFieldInGroup(group, DATE_STATEMENT_FIELD);
        if (dateStatement == null) {
            dateStatement = TextInputField.builder().fieldId(DATE_STATEMENT_FIELD).build();
            group.getFields().add(dateStatement);
        }
        dateStatement.setIsActive(true);
        dateStatement.incrementOrder();
        dateStatement.setEnabled(true);
        dateStatement.setMandatory(true);
        dateStatement.setLabel("Date of portfolio statement");
    }

    public static void evaluatePortfolioValue(Group group) {

        var portfolioValue = (NumberInputField) ChecklistUtils.getFieldInGroup(group, PORTFOLIO_VALUE_FIELD);
        if (portfolioValue == null) {
            portfolioValue = NumberInputField.builder().fieldId(PORTFOLIO_VALUE_FIELD).build();
            group.getFields().add(portfolioValue);
        }
        portfolioValue.setIsActive(true);
        portfolioValue.incrementOrder();
        portfolioValue.setMandatory(true);
        portfolioValue.setEnabled(true);
        portfolioValue.setLabel("Portfolio value as per bank statement");
    }

    public static void evaluateExpectedPremiumValue(Group group) {

        var expectedPremiumValue = (NumberInputField) ChecklistUtils.getFieldInGroup(group, EXPECTED_PREMIUM_VALUE_FIELD);
        if (expectedPremiumValue == null) {
            expectedPremiumValue = NumberInputField.builder().fieldId(EXPECTED_PREMIUM_VALUE_FIELD).build();
            group.getFields().add(expectedPremiumValue);
        }
        expectedPremiumValue.setIsActive(true);
        expectedPremiumValue.incrementOrder();
        expectedPremiumValue.setMandatory(true);
        expectedPremiumValue.setEnabled(true);
        expectedPremiumValue.setLabel("Expected Premium if different from portfolio Value");
    }

    public static void evaluateMarketAndTeam(Group group) {

        var marketAndTeam = (TextInputField) ChecklistUtils.getFieldInGroup(group, MARKET_AND_TEAM_FIELD);
        if (marketAndTeam == null) {
            marketAndTeam = TextInputField.builder().fieldId(MARKET_AND_TEAM_FIELD).build();
            group.getFields().add(marketAndTeam);
        }
        marketAndTeam.setIsActive(true);
        marketAndTeam.incrementOrder();
        marketAndTeam.setEnabled(true);
        marketAndTeam.setMandatory(true);
        marketAndTeam.setLabel("Market and PCS Team");
    }

    public static void evaluateProfessionalInvestorForm(Group group, ReferenceDataRepositoryService referenceDataRepositoryService) {

        var professionalInvestorForm = (SelectInputField) ChecklistUtils.getFieldInGroup(group, PROFESSIONAL_INVESTOR_FORM_FIELD);
        if (professionalInvestorForm == null) {
            professionalInvestorForm = SelectInputField.builder().fieldId(PROFESSIONAL_INVESTOR_FORM_FIELD).build();
            group.getFields().add(professionalInvestorForm);
        }
        professionalInvestorForm.setIsActive(true);
        professionalInvestorForm.incrementOrder();
        professionalInvestorForm.setMandatory(true);
        professionalInvestorForm.setEnabled(true);
        professionalInvestorForm.setLabel("Professional Investor Form signed");
        professionalInvestorForm.setOptions(referenceDataRepositoryService.getReferenceDataOptionsByDomain(
                YES_NO_DOMAIN));
    }

    public static void evaluateInvestmentManagerDenomination(Group group) {

        var investmentManagerDenomination = (TextInputField) ChecklistUtils.getFieldInGroup(group, INVESTMENT_MANAGER_DENOMINATION_FIELD);
        if (investmentManagerDenomination == null) {
            investmentManagerDenomination = TextInputField.builder().fieldId(INVESTMENT_MANAGER_DENOMINATION_FIELD).build();
            group.getFields().add(investmentManagerDenomination);
        }
        investmentManagerDenomination.setIsActive(true);
        investmentManagerDenomination.incrementOrder();
        investmentManagerDenomination.setMandatory(true);
        investmentManagerDenomination.setEnabled(true);
        investmentManagerDenomination.setLabel("Investment Manager denomination");
    }

    public static void evaluateInvestmentManagerMandate(Group group, ReferenceDataRepositoryService referenceDataRepositoryService) {

        var investmentManagerMandate = (SelectInputField) ChecklistUtils.getFieldInGroup(group, INVESTMENT_MANAGER_MANDATE_FIELD);
        if (investmentManagerMandate == null) {
            investmentManagerMandate = SelectInputField.builder().fieldId(INVESTMENT_MANAGER_MANDATE_FIELD).build();
            group.getFields().add(investmentManagerMandate);
        }
        investmentManagerMandate.setIsActive(true);
        investmentManagerMandate.incrementOrder();
        investmentManagerMandate.setMandatory(true);
        investmentManagerMandate.setEnabled(true);
        investmentManagerMandate.setLabel("Investment Manager mandate");
        investmentManagerMandate.setOptions(referenceDataRepositoryService.getReferenceDataOptionsByDomain(MANAGER_TYPE_DOMAIN));
    }

    public static void evaluateCustodian(Group group) {
        var custodian = (TextInputField) ChecklistUtils.getFieldInGroup(group, CUSTODIAN_BANK_DENOMINATION_FIELD);
        if (custodian == null) {
            custodian = TextInputField.builder().fieldId(CUSTODIAN_BANK_DENOMINATION_FIELD).build();
            group.getFields().add(custodian);
        }
        custodian.incrementOrder();
        custodian.setMandatory(true);
        custodian.setEnabled(true);
        custodian.setIsActive(true);
        custodian.setLabel("Custodian bank denomination");
    }


}
