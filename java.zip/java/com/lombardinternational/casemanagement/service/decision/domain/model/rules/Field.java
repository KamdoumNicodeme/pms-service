package com.lombardinternational.casemanagement.service.decision.domain.model.rules;

import java.util.concurrent.atomic.AtomicInteger;

import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder
@RequiredArgsConstructor
public class Field {

    private static final AtomicInteger currentOrder = new AtomicInteger(1);

    private String fieldId;
    private String label;
    private String i18NLabelKey;
    private int order;
    @Builder.Default
    private Boolean enabled = false;
    @Builder.Default
    private Boolean mandatory = false;
    private Boolean multiple;
    private Integer maxMultiple;
    private String selectedValue;
    private String displayIf;
    private String enableIf;
    @Builder.Default
    private Boolean labelBold = false;
    private String sourceSystem;
    @Builder.Default
    private Boolean isActive = Boolean.FALSE;

    public static void resetFieldId() {

        currentOrder.set(1);
    }

    public void incrementOrder() {

        this.order = currentOrder.getAndIncrement();
    }
}
