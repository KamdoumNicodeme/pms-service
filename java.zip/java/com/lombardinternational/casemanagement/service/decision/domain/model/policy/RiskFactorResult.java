package com.lombardinternational.casemanagement.service.decision.domain.model.policy;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class RiskFactorResult {

    private String reference;
    private String description;
    private String data;
    private String answerReference;
    private String answerDescription;
    private String riskLevel;
    private Integer score;
    private String stackTrace;
}
