package com.lombardinternational.casemanagement.service.decision.domain.spi.repository;

import java.util.List;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.SelectInputFieldOption;

public interface ReferenceDataRepositoryService {

    List<SelectInputFieldOption> getReferenceDataOptionsByDomain(String domain);

    List<SelectInputFieldOption> getReferenceDataOptionsByDomainAndSelectedValue(String domain, String selectedValue);
}
