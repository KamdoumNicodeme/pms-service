package com.lombardinternational.casemanagement.service.decision.domain.model.webform;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder
@NoArgsConstructor
public abstract class WebFormField {

    private String fieldId;
    private String label;
}
