package com.lombardinternational.casemanagement.service.decision.domain.service.taskscreen.common.fields;

import org.springframework.stereotype.Service;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Field;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Group;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.taskscreen.TaskScreenFieldBuilderService;

import lombok.AllArgsConstructor;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.TaskScreenConstants.*;

@Service
@AllArgsConstructor
public class CommonInadmissibleFieldsBuilderService implements TaskScreenFieldBuilderService {

    private final CommonAssetsFieldsService service;

    @Override
    public void buildField(WebForm webForm, ScreenDescription screenCheckList, ScreenDescription screenToFill, Group group) {

        Field.resetFieldId();
        service.evaluateContainedInPortfolio(group, CONTAINED_IN_PORTFOLIO_FIELD + "_3");
        service.evaluateListOfAssets(group, LIST_OF_ASSETS_FIELD + "_3");
        service.evaluateNtaOrPcsInformed(group, NTA_OR_PCS_INFORMED_FIELD + "_3");
    }
}
