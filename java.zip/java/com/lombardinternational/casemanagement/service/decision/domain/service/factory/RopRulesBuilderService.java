package com.lombardinternational.casemanagement.service.decision.domain.service.factory;

import java.util.List;

import org.springframework.stereotype.Service;

import com.lombardinternational.casemanagement.service.decision.domain.model.policy.Policy;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ControlDefinition;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.DocumentDefinition;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.SignatoryResult;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.TaskDefinition;
import com.lombardinternational.casemanagement.service.decision.domain.model.transaction.BusinessTransaction;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.checklist.rop.RopChecklistBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.rop.RopControlDefinitionBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.document.rop.RopDocumentsDefinitionBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.tasklist.rop.RopTaskListBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.taskscreen.rop.RopTaskScreenBuilderService;

import lombok.AllArgsConstructor;

@Service
@AllArgsConstructor
public class RopRulesBuilderService implements RulesBuilderService {

    private final RopChecklistBuilderService checklistBuilderService;
    private final RopTaskListBuilderService ropTaskListBuilderService;
    private final RopDocumentsDefinitionBuilderService documentsDefinitionBuilderService;
    private final RopControlDefinitionBuilderService controlDefinitionBuilderService;
    private final RopTaskScreenBuilderService ropTaskScreenBuilderService;

    @Override
    public ScreenDescription buildCheckList(final WebForm webForm, final ScreenDescription screenDescription, final Policy policy,
            final BusinessTransaction transaction) {

        return checklistBuilderService.buildChecklist(webForm, screenDescription, policy, transaction);
    }

    @Override
    public List<TaskDefinition> buildTaskList(final WebForm webForm, final ScreenDescription screenDescription, final Policy policy) {

        return ropTaskListBuilderService.buildTaskList(policy, webForm, screenDescription);
    }

    @Override
    public ScreenDescription buildTaskScreen(final WebForm webForm, final ScreenDescription screenCheckList,
            final ScreenDescription screenToFill) {

        return ropTaskScreenBuilderService.buildTaskScreen(webForm, screenCheckList, screenToFill);
    }

    @Override
    public List<DocumentDefinition> buildDocumentsDefinition(final WebForm webForm, final ScreenDescription screenDescription, final Policy policy,
            final String transactionNumber) throws Exception {

        return documentsDefinitionBuilderService.buildDocumentsDefinition(policy, webForm, screenDescription, transactionNumber);
    }

    @Override
    public List<ControlDefinition> buildControlDefinition(final WebForm webForm, final ScreenDescription screenDescription) {

        return controlDefinitionBuilderService.buildControlDefinition(webForm, screenDescription);
    }

    @Override
    public SignatoryResult buildSignatories(final WebForm webForm, final Policy policy) {

        return null;
    }
}
