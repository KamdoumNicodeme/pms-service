package com.lombardinternational.casemanagement.service.decision.domain.service.signatories.addition.procuration;

import java.util.Collection;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.lombardinternational.casemanagement.service.decision.domain.model.policy.Policy;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.DocumentRequiredSignatory;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.RequiredSignatory;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebFormGroup;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control.common.Utils;
import com.lombardinternational.casemanagement.service.decision.domain.service.signatories.AbstractDocumentRequiredSignatoryBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.utils.Constraint;
import com.lombardinternational.casemanagement.service.decision.domain.utils.FieldConstraint;
import com.lombardinternational.casemanagement.service.decision.domain.utils.WebformUtils;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.WebformUtils.*;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.RulesConstants.*;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.SignatoryConstants.*;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.WebFormFieldConstants.*;

@Service
public class ProcurationCONT3199 extends AbstractDocumentRequiredSignatoryBuilderService {

    @Override
    public void buildRequiredSignatory(final WebForm webForm, final Policy policy,
            final List<DocumentRequiredSignatory> documentRequiredSignatories, final List<RequiredSignatory> signatories) {

        final List<FieldConstraint> constraints = List.of(Utils.createConstraint(COUNTRY_OF_LAW, Constraint.EQUALS, List.of("LU")),
                Utils.createConstraint(TARGET_MARKET, Constraint.EQUALS, List.of("LU")));

        boolean allConstraintsPassed = constraints.stream().allMatch(c -> c.test(webForm));

        if (allConstraintsPassed && INVESTMENT_POLICY.equals(policy.getPolicyType())) {
            Optional.ofNullable(getFirstWebFormGroupById(webForm, SPECIALISED_ASSURANCE_FUNDS)).map(WebFormGroup::getGroups).stream()
                    .flatMap(Collection::stream).forEach(safGroup -> {
                        var isNew = WebformUtils.getWebFormFieldValueById(safGroup, IS_NEW);
                        var fasManager = WebformUtils.getWebFormFieldValueById(safGroup, FAS_MANAGER);
                        if ("true".equals(isNew) && "SELF".equals(fasManager)) {
                            var fundId = WebformUtils.getWebFormFieldValueById(safGroup, FUND_ID);
                            List<RequiredSignatory> requiredSignatories =
                                    buildRequiredSignatories(signatories, List.of("INTERMEDIATE", "POLICY_HOLDER", "SIGNATORY"));
                            buildDocumentRequiredSignatory(documentRequiredSignatories, requiredSignatories, fundId);
                        }
                    });
        }
    }

    @Override
    protected String getDocumentType() {

        return CONT3199;
    }
}
