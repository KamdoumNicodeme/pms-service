package com.lombardinternational.casemanagement.service.decision.domain.service.document.addition.document;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.DocumentDefinition;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.document.AbstractDocumentBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.utils.Constraint;
import com.lombardinternational.casemanagement.service.decision.domain.utils.FieldConstraint;
import com.lombardinternational.casemanagement.service.decision.domain.utils.WebformUtils;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ChecklistFieldConstants.BUSINESS_ORIGIN;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ChecklistFieldConstants.FORM_SIGNER;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.DocumentConstants.*;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.WebFormFieldConstants.POLICY_NUMBER_WF;

@Service
public class QuestionarioAdeguatezzaDocumentBuilderService extends AbstractDocumentBuilderService {

    @Override
    public void buildDocument(final WebForm webForm, final ScreenDescription screenDescription, String transactionNumber,
            List<DocumentDefinition> documents) {

        final var constraints = new ArrayList<FieldConstraint>();
        constraints.add(
                FieldConstraint.builder().fieldId(BUSINESS_ORIGIN).constraint(Constraint.EQUALS).values(Collections.singletonList("IT")).build());
        constraints.add(
                FieldConstraint.builder().fieldId(FORM_SIGNER).constraint(Constraint.EQUALS).values(Collections.singletonList("INTERNAL_AGENT"))
                        .build());
        if (constraints.stream().allMatch(constraint -> constraint.test(screenDescription))) {
            var relatedTo = WebformUtils.getWebFormFieldValueById(webForm, POLICY_NUMBER_WF);
            buildDocumentDefinition(relatedTo, relatedTo, null, null, documents);
        }
    }

    @Override
    protected String getDocumentType() {

        return MEDICAL_DOCUMENT_DOC_TYPE;
    }

    @Override
    protected String getCmsDocumentType() {

        return MEDICAL_DOCUMENT_CMS_DOC_TYPE;
    }

    @Override
    protected String getDescription() {

        return QUESTIONARIO_ADEGUATEZZA_FORM_DESCRIPTION;
    }

    @Override
    protected String getI18NDescription() {

        return QUESTIONARIO_ADEGUATEZZA_FORM_I18N_DESCRIPTION;
    }

    @Override
    protected boolean getNeverDisplayExternally() {

        return true;
    }
}
