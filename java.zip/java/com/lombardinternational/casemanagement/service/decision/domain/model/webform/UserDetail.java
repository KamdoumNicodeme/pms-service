package com.lombardinternational.casemanagement.service.decision.domain.model.webform;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class UserDetail {

    private String userId;
    private String login;
    private String firstName;
    private String lastName;
    private String userRole;
    private String clientNumber;
    private Boolean authorizedSigntory;
    private String phoneNumber;
    private String email;
}
