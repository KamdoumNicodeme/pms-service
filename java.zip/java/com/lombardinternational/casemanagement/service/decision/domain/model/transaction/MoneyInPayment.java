package com.lombardinternational.casemanagement.service.decision.domain.model.transaction;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder
@NoArgsConstructor
@EqualsAndHashCode(callSuper = true)
public class MoneyInPayment extends Payment {

    private PaymentDetails expectedPaymentDetails;
}
