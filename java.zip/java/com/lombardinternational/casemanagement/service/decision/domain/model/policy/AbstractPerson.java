package com.lombardinternational.casemanagement.service.decision.domain.model.policy;

import java.util.List;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder
@NoArgsConstructor
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class AbstractPerson {

    @EqualsAndHashCode.Include
    private String thirdPartyId;
    private Address address;
    private String fatcaStatus;
    private String subType;
    private SourceOfFunds sourceOfFunds;
    private List<PersistedBlock> persistedBlocks;
    private ProfessionIndustrySector professionIndustrySector;
}
