package com.lombardinternational.casemanagement.service.decision.domain.service.tasklist.common.task;

import java.util.List;

import org.springframework.stereotype.Service;

import com.lombardinternational.casemanagement.service.decision.domain.model.policy.Policy;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.TaskDefinition;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.tasklist.AbstractTaskBuilderService;

@Service
public class CommonAMLSignOffTaskBuilderService extends AbstractTaskBuilderService {

    @Override
    public void buildTask(final Policy policy, final WebForm webForm, final ScreenDescription screenDescription,
            final List<TaskDefinition> taskList) {

        buildTaskDefinition(taskList);
    }

    @Override
    public String getTaskName() {

        return "AML sign-off";
    }

    @Override
    protected boolean getMandatory() {

        return true;
    }
}
