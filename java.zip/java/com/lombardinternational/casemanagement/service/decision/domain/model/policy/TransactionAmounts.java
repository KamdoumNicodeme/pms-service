package com.lombardinternational.casemanagement.service.decision.domain.model.policy;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class TransactionAmounts {

    private Amount grossAmount;
    private Amount expectedAmount;
    private Amount expectedAmountEur;
}
