package com.lombardinternational.casemanagement.service.decision.domain.service.signatories;

import java.util.ArrayList;
import java.util.List;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.DocumentRequiredSignatory;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.RequiredSignatory;

public abstract class AbstractDocumentRequiredSignatoryBuilderService implements DocumentRequiredSignatoryBuilderService {

    private static final List<String> DEFAULT_ALLOWED_ACTION = List.of("DOWNLOAD");

    protected void buildDocumentRequiredSignatory(final List<DocumentRequiredSignatory> documentRequiredSignatories,
            final List<RequiredSignatory> requiredSignatories) {

        final var documentRequiredSignatory = buildDocumentRequiredSignatory(requiredSignatories).build();
        documentRequiredSignatory.incrementOrder();
        documentRequiredSignatories.add(documentRequiredSignatory);
    }

    protected void buildDocumentRequiredSignatory(final List<DocumentRequiredSignatory> documentRequiredSignatories,
            final List<RequiredSignatory> requiredSignatories, final String iterableIndex) {

        final var documentRequiredSignatory = buildDocumentRequiredSignatory(requiredSignatories).iterableIndex(iterableIndex).build();
        documentRequiredSignatory.incrementOrder();
        documentRequiredSignatories.add(documentRequiredSignatory);
    }

    private DocumentRequiredSignatory.DocumentRequiredSignatoryBuilder buildDocumentRequiredSignatory(
            final List<RequiredSignatory> requiredSignatories) {

        return DocumentRequiredSignatory.builder().documentType(getDocumentType()).documentRelatedTo(getDocumentRelatedTo())
                .documentMustBeGenerated(isDocumentMustBeGenerated()).documentRequiredOnConnect(isDocumentRequiredOnConnect())
                .description(getDescription()).i18NDescription(getI18NDescription()).cmsDocumentType(getCmsDocumentType())
                .iterableIndex(iterableIndex()).requiredSignatories(requiredSignatories);
    }

    protected static List<RequiredSignatory> buildRequiredSignatories(final List<RequiredSignatory> signatories, final List<String> contactsType,
            final String identifier) {

        final List<RequiredSignatory> requiredSignatories = new ArrayList<>();
        var signerIndex = 1;
        for (final RequiredSignatory requiredSignatory : signatories) {
            if (identifier != null && !identifier.equalsIgnoreCase(requiredSignatory.getThirdPartyId())) {
                continue;
            }
            if (contactsType.contains(requiredSignatory.getType())) {
                if (requiredSignatory.getSignerId() == null) {
                    requiredSignatory.setSignerId("signer" + signerIndex++);
                }
                requiredSignatories.add(requiredSignatory);
            }
        }
        return requiredSignatories;
    }

    protected static List<RequiredSignatory> buildRequiredSignatories(final List<RequiredSignatory> signatories, final List<String> contactsType) {

        return buildRequiredSignatories(signatories, contactsType, null);
    }

    protected abstract String getDocumentType();

    protected String getI18NDescription() {

        return null;
    }

    protected String getDocumentRelatedTo() {

        return "";
    }

    protected boolean isDocumentMustBeGenerated() {

        return true;
    }

    protected boolean isDocumentRequiredOnConnect() {

        return true;
    }

    protected String getDescription() {

        return null;
    }

    protected String getCmsDocumentType() {

        return "Addition request";
    }

    protected String iterableIndex() {

        return null;
    }

}
