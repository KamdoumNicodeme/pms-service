package com.lombardinternational.casemanagement.service.decision.domain.service.taskscreen;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Tab;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;

public interface TaskScreenGroupBuilderService {

    void buildGroup(final WebForm webForm, final ScreenDescription screenCheckList, final ScreenDescription screenToFill, final Tab parentTab);
}
