package com.lombardinternational.casemanagement.service.decision.domain.service.document.addition.document;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.DocumentDefinition;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.document.AbstractDocumentBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.utils.Constraint;
import com.lombardinternational.casemanagement.service.decision.domain.utils.FieldConstraint;
import com.lombardinternational.casemanagement.service.decision.domain.utils.WebformUtils;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ChecklistFieldConstants.TCC_IN_FOLDER;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ChecklistFieldConstants.TCC_SIGNED;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.DocumentConstants.*;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.WebFormFieldConstants.POLICY_NUMBER_WF;

@Service
public class TaxComplianceCertificationEBODocumentBuilderService extends AbstractDocumentBuilderService {

    @Override
    public void buildDocument(final WebForm webForm, final ScreenDescription screenDescription, String transactionNumber,
            List<DocumentDefinition> documents) {

        final var constraints = new ArrayList<FieldConstraint>();
        constraints.add(
                FieldConstraint.builder().fieldId(TCC_IN_FOLDER).constraint(Constraint.EQUALS).values(Collections.singletonList("YES")).build());
        constraints.add(
                FieldConstraint.builder().fieldId(TCC_SIGNED).constraint(Constraint.EQUALS).values(Collections.singletonList("NO")).build());

        final var constraints2 = new ArrayList<FieldConstraint>();
        constraints2.add(
                FieldConstraint.builder().fieldId(TCC_IN_FOLDER).constraint(Constraint.EQUALS).values(Collections.singletonList("NO")).build());

        if (constraints.stream().allMatch(constraint -> constraint.test(screenDescription)) || constraints2.stream()
                .allMatch(constraint -> constraint.test(screenDescription))) {
            var relatedTo = WebformUtils.getWebFormFieldValueById(webForm, POLICY_NUMBER_WF);
            buildDocumentDefinition(relatedTo, relatedTo, null, null, documents);
        }
    }

    @Override
    protected String getDocumentType() {

        return TRANSACTION_DOCUMENT_DOC_TYPE;
    }

    @Override
    protected String getCmsDocumentType() {

        return TAX_COMPLIANCE_CERTIFICATE_CMS_DOC_TYPE;
    }

    @Override
    protected String getDescription() {

        return TAX_COMPLIANCE_CERTIFICATION_EBO_FORM_DESCRIPTION;
    }

    @Override
    protected String getI18NDescription() {

        return TAX_COMPLIANCE_CERTIFICATION_EBO_FORM_I18N_DESCRIPTION;
    }
}
