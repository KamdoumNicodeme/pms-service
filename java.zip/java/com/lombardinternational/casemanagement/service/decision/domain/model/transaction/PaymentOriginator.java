package com.lombardinternational.casemanagement.service.decision.domain.model.transaction;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PaymentOriginator {

    private String externalId;
    private String label;
}
