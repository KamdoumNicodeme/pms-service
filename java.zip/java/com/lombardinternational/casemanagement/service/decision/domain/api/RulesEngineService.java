package com.lombardinternational.casemanagement.service.decision.domain.api;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.*;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;

import java.util.List;

public interface RulesEngineService {

    ScreenDescription buildCheckList(final WebForm webForm, final ScreenDescription screenDescription, final String policyNumber,
            final String transactionNumber) throws Exception;

    List<TaskDefinition> buildTaskList(final WebForm webForm, final ScreenDescription screenDescription, final String policyNumber)
            throws Exception;

    ScreenDescription buildTaskScreen(final WebForm webForm, final ScreenDescription screenCheckList, final ScreenDescription screenToFill);

    List<DocumentDefinition> buildDocumentsDefinition(final WebForm webForm, final ScreenDescription screenDescription, final String policyNumber,
            final String transactionNumber) throws Exception;

    List<ControlDefinition> buildControlDefinition(final WebForm webForm, final ScreenDescription screenDescription);

    SignatoryResult buildSignatories(final WebForm webForm, final String policyNumber) throws Exception;
}
