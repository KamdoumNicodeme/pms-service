package com.lombardinternational.casemanagement.service.decision.domain.model.rules;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder
@AllArgsConstructor
@EqualsAndHashCode(callSuper = true)
public class SelectInputField extends Field {

    private Integer minWidthPct;
    private Integer minWidthPx;
    private List<SelectInputFieldOption> options;
}
