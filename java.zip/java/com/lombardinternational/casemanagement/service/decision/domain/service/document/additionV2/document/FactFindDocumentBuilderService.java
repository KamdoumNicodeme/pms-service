package com.lombardinternational.casemanagement.service.decision.domain.service.document.additionV2.document;

import java.util.List;

import org.springframework.stereotype.Service;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.DocumentDefinition;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.document.AbstractDocumentBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.utils.WebformUtils;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.DocumentConstants.FACT_FIND_FORM_DESCRIPTION;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.DocumentConstants.FACT_FIND_FORM_I18N_DESCRIPTION;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.DocumentConstants.REASON_WHY_LET_CMS_DOC_TYPE;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.DocumentConstants.REASON_WHY_LET_DOC_TYPE;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.RulesConstants.AGENT;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.WebFormFieldConstants.POLICY_NUMBER_WF;

@Service
public class FactFindDocumentBuilderService extends AbstractDocumentBuilderService {

    @Override
    public void buildDocument(final WebForm webForm, final ScreenDescription screenDescription, String transactionNumber,
            List<DocumentDefinition> documents) {

        if (webForm.getCompanyDetail() != null) {
            var partnerType = webForm.getCompanyDetail().getPartnerType();
            if (AGENT.equals(partnerType)) {
                var relatedTo = WebformUtils.getWebFormFieldValueById(webForm, POLICY_NUMBER_WF);
                buildDocumentDefinition(relatedTo, relatedTo, null, null, documents);
            }
        }
    }

    @Override
    protected String getDocumentType() {

        return REASON_WHY_LET_DOC_TYPE;
    }

    @Override
    protected String getCmsDocumentType() {

        return REASON_WHY_LET_CMS_DOC_TYPE;
    }

    @Override
    protected String getDescription() {

        return FACT_FIND_FORM_DESCRIPTION;
    }

    @Override
    protected String getI18NDescription() {

        return FACT_FIND_FORM_I18N_DESCRIPTION;
    }

    @Override
    protected boolean getDocumentVisibleOnConnect() {

        return true;
    }
}
