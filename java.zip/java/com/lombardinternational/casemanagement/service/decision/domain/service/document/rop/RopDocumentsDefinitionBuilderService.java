package com.lombardinternational.casemanagement.service.decision.domain.service.document.rop;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.lombardinternational.casemanagement.service.decision.domain.model.policy.Policy;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.DocumentDefinition;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.document.DocumentsDefinitionBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.document.commons.DisposizionProdottiFinanziariDocumentBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.document.commons.FifFormDocumentBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.document.commons.NTAValidationEmailDocumentBuilderService;

import lombok.AllArgsConstructor;

@Service
@AllArgsConstructor
public class RopDocumentsDefinitionBuilderService implements DocumentsDefinitionBuilderService {

    private final FifFormDocumentBuilderService fifFormService;
    private final DisposizionProdottiFinanziariDocumentBuilderService disposizionProdottiFinanziariService;
    private final NTAValidationEmailDocumentBuilderService ntaValidationEmailService;

    @Override
    public List<DocumentDefinition> buildDocumentsDefinition(Policy policy, WebForm webForm, ScreenDescription screenDescription,
            String transactionNumber) throws Exception {
        DocumentDefinition.resetDocumentOrder();
        final var documents = new ArrayList<DocumentDefinition>();
        fifFormService.buildDocument(webForm, screenDescription, transactionNumber, documents);
        disposizionProdottiFinanziariService.buildDocument(webForm, screenDescription, transactionNumber, documents);
        ntaValidationEmailService.buildDocument(webForm, screenDescription, transactionNumber, documents);
        return documents;
    }
}
