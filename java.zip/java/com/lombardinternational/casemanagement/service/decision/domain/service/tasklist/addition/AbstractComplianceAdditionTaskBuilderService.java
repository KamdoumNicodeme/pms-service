package com.lombardinternational.casemanagement.service.decision.domain.service.tasklist.addition;

import com.lombardinternational.casemanagement.service.decision.domain.service.tasklist.AbstractTaskBuilderService;

public abstract class AbstractComplianceAdditionTaskBuilderService extends AbstractTaskBuilderService {

    @Override
    public String getTaskName() {

        return "Compliance check";
    }

    @Override
    public String getTaskDynamicScreenId() {

        return "COMPLIANCE_ADDITION";
    }
}
