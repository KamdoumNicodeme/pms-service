package com.lombardinternational.casemanagement.service.decision.domain.service.signatories.addition.kyc;

import java.util.Collections;
import java.util.List;

import org.springframework.stereotype.Service;

import com.lombardinternational.casemanagement.service.decision.domain.model.policy.Policy;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.DocumentRequiredSignatory;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.RequiredSignatory;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control.common.Utils;
import com.lombardinternational.casemanagement.service.decision.domain.utils.Constraint;
import com.lombardinternational.casemanagement.service.decision.domain.utils.FieldConstraint;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.SignatoryConstants.*;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.WebFormFieldConstants.*;

@Service
public class KycCONT4073 extends KycCont {

    @Override
    public void buildRequiredSignatory(final WebForm webForm, final Policy policy,
            final List<DocumentRequiredSignatory> documentRequiredSignatories, final List<RequiredSignatory> signatories) {

        final List<FieldConstraint> constraints =
                List.of(Utils.createConstraint(COUNTRY_OF_LAW, Constraint.EQUALS, Collections.singletonList("IT")),
                        Utils.createConstraint(B_CODE, Constraint.EQUALS, List.of(MEDIOLANUM_BROKER)));

        if (constraints.stream().allMatch(constraint -> constraint.test(webForm))) {
            buildDocumentRequiredSignatoryPhysical(webForm, documentRequiredSignatories, signatories);
        }
    }

    @Override
    protected String getDocumentType() {

        return CONT4073;
    }
}
