package com.lombardinternational.casemanagement.service.decision.domain.utils.constants;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public final class RulesConstants {

    // REFERENCE DATA ID
    public static final String BLOCKED = "BLOCKED";
    public static final String PROHIBITED = "PROHIBITED";
    public static final String EXCEPTION = "EXCEPTION";
    public static final String VERY_HIGH = "VERY_HIGH";
    public static final String HIGH = "HIGH";
    public static final String MEDIUM = "MEDIUM";
    public static final String STANDARD = "STANDARD";
    public static final String YES = "YES";
    public static final String NO = "NO";
    public static final String TRUE = "TRUE";

    public static final String DIVIDEND = "DIVIDEND";
    public static final String CESSION = "CESSION";
    public static final String SALE = "SALE";
    public static final String SALE_LIQ = "SALE_LIQ";
    public static final String SALE_RE = "SALE_RE";
    public static final String GAMBLING = "GAMBLING";
    public static final String MORAL = "MORAL";
    public static final String DIFFERENT = "DIFFERENT";
    public static final String AGENT = "AGENT";
    public static final String BROKER = "BROKER";

    public static final String INVESTMENT_POLICY = "Investment policy";
    public static final String CAPITALISED_POLICY = "Capitalised policy";

    // FIELD VALUE
    public static final String TP_SUB_TYPE_TRUST_FIELD_VALUE = "Trust";
    public static final String TP_SUB_TYPE_INDIVIDUAL_FIELD_VALUE = "Individual";
    public static final String TRUE_FIELD_VALUE = "true";
    public static final String THIRD_PARTY_GROUP = "THIRD_PARTY_GROUP";
    public static final String MISSING = "MISSING";

    // PCS VALUE
    public static final String PCS_STANDARD = "STANDARD";
    public static final String PCS_SENIOR = "SENIOR";
    public static final String PCS_COMPLIANCE = "COMPLIANCE";

    // RISK FACTOR REFERENCES
    public static final String ESC_RF_001 = "ESC_RF_001";
    public static final String INT_RF_002 = "INT_RF_002";
    public static final String INT_RF_003 = "INT_RF_003";
    public static final String INT_RF_005 = "INT_RF_005";
    public static final String INT_RF_006 = "INT_RF_006";
    public static final String INT_RF_007 = "INT_RF_007";
    public static final String INT_RF_010 = "INT_RF_010";
    public static final String INT_RF_012 = "INT_RF_012";
    public static final String INT_RF_013 = "INT_RF_013";
    public static final String INT_RF_014 = "INT_RF_014";
    public static final String INT_RF_016 = "INT_RF_016";
    public static final String ESC_RF_0016 = "ESC_RF_0016";

}
