package com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ControlDefinition;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.AbstractControlBuilderService;
import org.springframework.stereotype.Service;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ControlConstants.CLIENT_RISK_SCORE_MANDATORY_IN_CLASS_NAME;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ControlConstants.CLIENT_RISK_SCORE_MANDATORY_IN_CLASS_TYPE;

@Service
public class ClientRiskScoreMandatoryInClassControlBuilderService extends AbstractControlBuilderService {
    @Override
    public ControlDefinition buildControl(WebForm webForm, ScreenDescription screenDescription) {
        return buildControlDefinition();
    }

    @Override
    protected String getControlName() {
        return CLIENT_RISK_SCORE_MANDATORY_IN_CLASS_NAME;
    }

    @Override
    protected String getControlType() {
        return CLIENT_RISK_SCORE_MANDATORY_IN_CLASS_TYPE;
    }
}
