package com.lombardinternational.casemanagement.service.decision.domain.service.document;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.DocumentDefinition;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;

import java.util.List;

public interface DocumentBuilderService {

    void buildDocument(WebForm webForm, ScreenDescription screenDescription, String transactionNumber, List<DocumentDefinition> documents)
            throws Exception;
}
