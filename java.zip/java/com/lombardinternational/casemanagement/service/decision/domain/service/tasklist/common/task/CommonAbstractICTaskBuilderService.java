package com.lombardinternational.casemanagement.service.decision.domain.service.tasklist.common.task;

import com.lombardinternational.casemanagement.service.decision.domain.service.tasklist.AbstractTaskBuilderService;

public abstract class CommonAbstractICTaskBuilderService extends AbstractTaskBuilderService {

    @Override
    public String getTaskName() {

        return "IC-Asset";
    }
}
