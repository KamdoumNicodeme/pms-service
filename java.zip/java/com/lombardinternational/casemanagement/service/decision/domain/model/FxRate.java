package com.lombardinternational.casemanagement.service.decision.domain.model;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalTime;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@ToString
@EqualsAndHashCode
public class FxRate {

    private String fromCcy;
    private String toCcy;
    private BigDecimal bareRate;
    private BigDecimal buyRate;
    private BigDecimal sellRate;
    private String source;
    private LocalDate fxRateDate;
    private LocalTime fxRateTime;
}
