package com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control;

import java.util.Collections;
import java.util.List;

import org.springframework.stereotype.Service;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ControlDefinition;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.AbstractControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.utils.Constraint;
import com.lombardinternational.casemanagement.service.decision.domain.utils.FieldConstraint;

import static com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control.common.Constants.FIDUCIARY;
import static com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control.common.Utils.createConstraintWithMultiple;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ChecklistFieldConstants.THIRD_PARTY_SUB_TYPE_PH;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ControlConstants.EXTRACT_TRADE_REGISTER_FIDUCIARY_NAME_NBD;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ControlConstants.EXTRACT_TRADE_REGISTER_FIDUCIARY_TYPE;

@Service(value = "onboardingExtractTradeRegisterFiduciaryControlBuilderService")
public class ExtractTradeRegisterFiduciaryControlBuilderService extends AbstractControlBuilderService {

    @Override
    public ControlDefinition buildControl(WebForm webForm, ScreenDescription screenDescription) {

        final List<FieldConstraint> constraints =
                List.of(createConstraintWithMultiple(THIRD_PARTY_SUB_TYPE_PH, Constraint.IN, Boolean.TRUE, Collections.singletonList(FIDUCIARY)));

        if (constraints.stream().allMatch(constraint -> constraint.test(screenDescription))) {
            return buildControlDefinition();
        }
        return null;
    }

    @Override
    protected String getControlName() {

        return EXTRACT_TRADE_REGISTER_FIDUCIARY_NAME_NBD;
    }

    @Override
    protected String getControlType() {

        return EXTRACT_TRADE_REGISTER_FIDUCIARY_TYPE;
    }
}
