package com.lombardinternational.casemanagement.service.decision.domain.service.document.additionV2.document;

import java.util.List;

import org.springframework.stereotype.Service;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.DocumentDefinition;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.document.AbstractDocumentBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.utils.WebformUtils;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.DocumentConstants.PAYMENT_DETAILS_CMS_DOC_TYPE;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.DocumentConstants.PAYMENT_DETAILS_DOC_TYPE;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.DocumentConstants.PREMIUM_ASSET_PORTFOLIO_FORM_DESCRIPTION;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.DocumentConstants.PREMIUM_ASSET_PORTFOLIO_FORM_I18N_DESCRIPTION;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.RulesConstants.TRUE;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.WebFormFieldConstants.IS_ASSET_TRANSFER_WF;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.WebFormFieldConstants.POLICY_NUMBER_WF;

@Service
public class PremiumAssetTransferPortfolioDocumentBuilderService extends AbstractDocumentBuilderService {

    @Override
    public void buildDocument(final WebForm webForm, final ScreenDescription screenDescription, String transactionNumber,
            List<DocumentDefinition> documents) {

        var isAssetTransfer = WebformUtils.getWebFormFieldValueById(webForm, IS_ASSET_TRANSFER_WF);
        if (TRUE.equalsIgnoreCase(isAssetTransfer)) {
            var relatedTo = WebformUtils.getWebFormFieldValueById(webForm, POLICY_NUMBER_WF);
            buildDocumentDefinition(relatedTo, relatedTo, null, null, documents);
        }
    }

    @Override
    protected String getDocumentType() {

        return PAYMENT_DETAILS_DOC_TYPE;
    }

    @Override
    protected String getCmsDocumentType() {

        return PAYMENT_DETAILS_CMS_DOC_TYPE;
    }

    @Override
    protected String getDescription() {

        return PREMIUM_ASSET_PORTFOLIO_FORM_DESCRIPTION;
    }

    @Override
    protected String getI18NDescription() {

        return PREMIUM_ASSET_PORTFOLIO_FORM_I18N_DESCRIPTION;
    }

    @Override
    protected boolean getDocumentVisibleOnConnect() {

        return true;
    }

    @Override
    protected boolean getDocumentRequired() {

        return true;
    }
}
