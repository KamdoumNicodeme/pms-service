package com.lombardinternational.casemanagement.service.decision.domain.service.document.addition.document;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.DocumentDefinition;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.document.AbstractDocumentBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.utils.Constraint;
import com.lombardinternational.casemanagement.service.decision.domain.utils.FieldConstraint;
import com.lombardinternational.casemanagement.service.decision.domain.utils.WebformUtils;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ChecklistFieldConstants.NEW_US_INDICIA;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.DocumentConstants.*;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.WebFormFieldConstants.POLICY_NUMBER_WF;

@Service
public class W8BenFatcaDocumentBuilderService extends AbstractDocumentBuilderService {

    @Override
    public void buildDocument(final WebForm webForm, final ScreenDescription screenDescription, String transactionNumber,
            List<DocumentDefinition> documents) {

        final var constraints = new ArrayList<FieldConstraint>();
        constraints.add(
                FieldConstraint.builder().fieldId(NEW_US_INDICIA).constraint(Constraint.EQUALS).values(Collections.singletonList("YES")).build());
        if (constraints.stream().allMatch(constraint -> constraint.test(screenDescription))) {
            var relatedTo = WebformUtils.getWebFormFieldValueById(webForm, POLICY_NUMBER_WF);
            buildDocumentDefinition(relatedTo, relatedTo, null, null, documents);
        }
    }

    @Override
    protected String getDocumentType() {

        return AEOI_FORM_DOC_TYPE;
    }

    @Override
    protected String getCmsDocumentType() {

        return AEOI_FORM_CMS_DOC_TYPE;
    }

    @Override
    protected String getDescription() {

        return W8BEN_FATCA_FORM_DESCRIPTION;
    }

    @Override
    protected String getI18NDescription() {

        return W8BEN_FATCA_FORM_I18N_DESCRIPTION;
    }

    @Override
    protected String getCmtRelatedToPrefix() {

        return W8BEN_FATCA_FORM_CMT_RELATED_TO_PREFIX_DESCRIPTION;
    }
}
