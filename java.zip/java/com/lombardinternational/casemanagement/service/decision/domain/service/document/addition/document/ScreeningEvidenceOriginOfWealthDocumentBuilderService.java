package com.lombardinternational.casemanagement.service.decision.domain.service.document.addition.document;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.DocumentDefinition;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.document.AbstractDocumentBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.utils.Constraint;
import com.lombardinternational.casemanagement.service.decision.domain.utils.FieldConstraint;
import com.lombardinternational.casemanagement.service.decision.domain.utils.WebformUtils;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ChecklistFieldConstants.*;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.DocumentConstants.*;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.WebFormFieldConstants.POLICY_NUMBER_WF;

@Service
public class ScreeningEvidenceOriginOfWealthDocumentBuilderService extends AbstractDocumentBuilderService {

    @Override
    public void buildDocument(final WebForm webForm, final ScreenDescription screenDescription, String transactionNumber,
            List<DocumentDefinition> documents) {

        final var constraints = new ArrayList<FieldConstraint>();
        constraints.add(FieldConstraint.builder().fieldId(NEGATIVE_FINDING).constraint(Constraint.EQUALS).values(Collections.singletonList("YES"))
                .build());
        constraints.add(
                FieldConstraint.builder().fieldId(INFO_PROVIDED_VERIFIED).constraint(Constraint.EQUALS).values(Collections.singletonList("NO"))
                        .build());
        constraints.add(
                FieldConstraint.builder().fieldId(NEW_KYC_IN_LINE).constraint(Constraint.EQUALS).values(Collections.singletonList("NO")).build());
        if (constraints.stream().allMatch(constraint -> constraint.test(screenDescription))) {
            var relatedTo = WebformUtils.getWebFormFieldValueById(webForm, POLICY_NUMBER_WF);
            buildDocumentDefinition(relatedTo, relatedTo, null, null, documents);
        }
        ;
    }

    @Override
    protected String getDocumentType() {

        return KYC_DOCUMENT_DOC_TYPE;
    }

    @Override
    protected String getCmsDocumentType() {

        return KYC_DOCUMENT_CMS_DOC_TYPE;
    }

    @Override
    protected String getDescription() {

        return SCREENING_EVIDENCE_ORIGIN_OF_WEALTH_FORM_DESCRIPTION;
    }

    @Override
    protected String getI18NDescription() {

        return SCREENING_EVIDENCE_ORIGIN_OF_WEALTH_FORM_I18N_DESCRIPTION;
    }
}
