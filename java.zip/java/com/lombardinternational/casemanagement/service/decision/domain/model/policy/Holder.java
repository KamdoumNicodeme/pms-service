package com.lombardinternational.casemanagement.service.decision.domain.model.policy;

import java.math.BigDecimal;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder
@NoArgsConstructor
@EqualsAndHashCode(callSuper = true)
public class Holder extends PolicyRole {

    private String taxIsoCountryCode;
    private BigDecimal riskScore;
    private Address sendingAddress;
}
