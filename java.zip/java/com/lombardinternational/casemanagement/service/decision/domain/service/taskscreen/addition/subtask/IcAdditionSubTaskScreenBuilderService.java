package com.lombardinternational.casemanagement.service.decision.domain.service.taskscreen.addition.subtask;

import java.util.List;

import org.springframework.stereotype.Service;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Group;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Tab;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.taskscreen.SubTaskScreenBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.taskscreen.common.groups.CommonAssetsInadmissibleGroupBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.taskscreen.common.groups.CommonAssetsNotPermittedGroupBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.taskscreen.addition.groups.icaddition.ChecklistDataIcAdditionGroupBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.taskscreen.common.groups.CommonComplexAssetsGroupBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.taskscreen.common.groups.CommonDistressedGroupBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.taskscreen.common.groups.CommonDocumentationGroupBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.taskscreen.common.groups.CommonIdentificationOfAssetsGroupBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.taskscreen.common.groups.CommonIdentificationOfRegulatedBusinessGroupBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.taskscreen.common.groups.CommonIdentificationOfSmallCapGroupBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.taskscreen.common.groups.CommonInadmissibleGroupBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.taskscreen.common.groups.CommonNtaGroupBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.taskscreen.common.groups.CommonPreliminaryPolicyTypeGroupBuilderService;

import lombok.AllArgsConstructor;

@Service
@AllArgsConstructor
public class IcAdditionSubTaskScreenBuilderService implements SubTaskScreenBuilderService {

    public static String SUB_TASK_SCREEN_ID = "IC_ADDITION";

    private final ChecklistDataIcAdditionGroupBuilderService checklistDataIcAdditionGroupBuilderService;
    private final CommonPreliminaryPolicyTypeGroupBuilderService commonPreliminaryPolicyTypeGroupBuilderService;
    private final CommonNtaGroupBuilderService commonNtaGroupBuilderService;
    private final CommonDistressedGroupBuilderService commonDistressedGroupBuilderService;
    private final CommonInadmissibleGroupBuilderService commonInadmissibleGroupBuilderService;
    private final CommonAssetsInadmissibleGroupBuilderService commonAssetsInadmissibleGroupBuilderService;
    private final CommonAssetsNotPermittedGroupBuilderService commonAssetsNotPermittedGroupBuilderService;
    private final CommonComplexAssetsGroupBuilderService commonComplexAssetsGroupBuilderService;
    private final CommonIdentificationOfAssetsGroupBuilderService commonIdentificationOfAssetsGroupBuilderService;
    private final CommonIdentificationOfSmallCapGroupBuilderService commonIdentificationOfSmallCapGroupBuilderService;
    private final CommonIdentificationOfRegulatedBusinessGroupBuilderService commonIdentificationOfRegulatedBusinessGroupBuilderService;
    private final CommonDocumentationGroupBuilderService commonDocumentationGroupBuilderService;

    @Override
    public ScreenDescription buildSubTaskScreen(WebForm webForm, ScreenDescription screenCheckList, ScreenDescription screenToFill,
            Tab parentTab) {

        Group.resetGroupId();
        var services = List.of(checklistDataIcAdditionGroupBuilderService, commonPreliminaryPolicyTypeGroupBuilderService,
                commonNtaGroupBuilderService, commonDistressedGroupBuilderService, commonInadmissibleGroupBuilderService,
                commonAssetsInadmissibleGroupBuilderService, commonAssetsNotPermittedGroupBuilderService,
                commonComplexAssetsGroupBuilderService, commonIdentificationOfAssetsGroupBuilderService,
                commonIdentificationOfSmallCapGroupBuilderService, commonIdentificationOfRegulatedBusinessGroupBuilderService,
                commonDocumentationGroupBuilderService);
        services.forEach(service -> service.buildGroup(webForm, screenCheckList, screenToFill, parentTab));
        return screenToFill;
    }

    public Boolean filterService(String subTaskScreenId) {

        return SUB_TASK_SCREEN_ID.equals(subTaskScreenId);
    }
}
