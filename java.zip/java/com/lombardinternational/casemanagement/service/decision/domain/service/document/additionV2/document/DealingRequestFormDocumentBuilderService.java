package com.lombardinternational.casemanagement.service.decision.domain.service.document.additionV2.document;

import java.util.Arrays;
import java.util.List;

import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Service;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.DocumentDefinition;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebFormGroup;
import com.lombardinternational.casemanagement.service.decision.domain.service.document.AbstractDocumentBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.utils.WebformUtils;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.DocumentConstants.DEALING_REQUEST_FORM_DESCRIPTION;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.DocumentConstants.DEALING_REQUEST_FORM_I18N_DESCRIPTION;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.DocumentConstants.FUND_I18N_DOCUMENT_RELATED_TO;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.DocumentConstants.TP_DOCS_CMS_DOC_TYPE;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.DocumentConstants.TP_DOCS_DOC_TYPE;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.WebFormFieldConstants.COUNTRY_OF_LAW_WF;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.WebFormFieldConstants.FUND_ID_WF;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.WebFormFieldConstants.POLICY_NUMBER_WF;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.WebFormFieldConstants.SPECIALISED_ASSURANCE_FUNDS_WF;

@Service
public class DealingRequestFormDocumentBuilderService extends AbstractDocumentBuilderService {

    @Override
    public void buildDocument(final WebForm webForm, final ScreenDescription screenDescription, String transactionNumber,
            List<DocumentDefinition> documents) {

        var countryOfLaw = WebformUtils.getWebFormFieldValueById(webForm, COUNTRY_OF_LAW_WF);
        if (Arrays.asList("DE", "ES").contains(countryOfLaw)) {
            var saf = WebformUtils.getFirstWebFormGroupById(webForm, SPECIALISED_ASSURANCE_FUNDS_WF);
            if (saf != null && CollectionUtils.isNotEmpty(saf.getGroups())) {
                for (WebFormGroup group : saf.getGroups()) {
                    var fundId = WebformUtils.getWebFormFieldValueById(group, FUND_ID_WF);
                    var relatedToPolicy = WebformUtils.getWebFormFieldValueById(webForm, POLICY_NUMBER_WF);
                    var relatedTo = "Fund " + fundId;
                    buildDocumentDefinition(relatedTo, relatedToPolicy, fundId, fundId, documents);
                }
            }
        }
    }

    @Override
    protected String getDocumentType() {

        return TP_DOCS_DOC_TYPE;
    }

    @Override
    protected String getCmsDocumentType() {

        return TP_DOCS_CMS_DOC_TYPE;
    }

    @Override
    protected String getDescription() {

        return DEALING_REQUEST_FORM_DESCRIPTION;
    }

    @Override
    protected String getI18NDescription() {

        return DEALING_REQUEST_FORM_I18N_DESCRIPTION;
    }

    @Override
    protected String getI18NDocumentRelatedTo() {

        return FUND_I18N_DOCUMENT_RELATED_TO;
    }

    @Override
    protected boolean getDocumentVisibleOnConnect() {

        return true;
    }

    @Override
    protected boolean getDocumentRequired() {

        return true;
    }
}
