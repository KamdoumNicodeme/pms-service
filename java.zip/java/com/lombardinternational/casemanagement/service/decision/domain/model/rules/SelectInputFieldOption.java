package com.lombardinternational.casemanagement.service.decision.domain.model.rules;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

@Data
@AllArgsConstructor
@Builder
public class SelectInputFieldOption {

    private String key;
    private String value;
}
