package com.lombardinternational.casemanagement.service.decision.domain.model.rules;

import java.util.concurrent.atomic.AtomicInteger;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class DocumentDefinition {

    private static final AtomicInteger currentOrder = new AtomicInteger(1);

    private String documentType;
    private String cmsDocumentType;
    private int documentOrder;
    @Builder.Default
    private boolean documentRequired = false;
    @Builder.Default
    private boolean documentVisibleOnConnect = false;
    private String description;
    private String i18NDescription;
    private String i18NDocumentRelatedTo;
    @Builder.Default
    private boolean neverDisplayExternally = false;
    private String i18NDocumentRelatedToParam;
    private String documentRelatedTo;
    private String relatedToThirdpartyId;
    private String relatedToPolicyNumber;

    public static void resetDocumentOrder() {

        currentOrder.set(1);
    }

    public void incrementOrder() {

        this.documentOrder = currentOrder.getAndIncrement();
    }
}
