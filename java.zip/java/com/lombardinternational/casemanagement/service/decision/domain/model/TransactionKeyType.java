package com.lombardinternational.casemanagement.service.decision.domain.model;

// Record created to differentiate onboarding transactions from non-digital transactions
public record TransactionKeyType(String screenId, String webFormId) {
}
