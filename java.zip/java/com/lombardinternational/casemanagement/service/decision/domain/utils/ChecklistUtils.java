package com.lombardinternational.casemanagement.service.decision.domain.utils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

import com.lombardinternational.casemanagement.service.decision.domain.model.policy.AbstractPerson;
import com.lombardinternational.casemanagement.service.decision.domain.model.policy.Address;
import com.lombardinternational.casemanagement.service.decision.domain.model.policy.Country;
import com.lombardinternational.casemanagement.service.decision.domain.model.policy.Policy;
import com.lombardinternational.casemanagement.service.decision.domain.model.policy.PolicyRole;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Field;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Group;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Tab;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.TextInputField;
import com.lombardinternational.casemanagement.service.decision.domain.model.transaction.BusinessTransaction;
import com.lombardinternational.casemanagement.service.decision.domain.model.transaction.BusinessTransactionProductComponent;
import com.lombardinternational.casemanagement.service.decision.domain.model.transaction.MoneyInPayment;
import com.lombardinternational.casemanagement.service.decision.domain.model.transaction.Payment;
import com.lombardinternational.casemanagement.service.decision.domain.model.transaction.PaymentDetails;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class ChecklistUtils {

    public static final String countryDelimiter = " ";

    public static boolean checkFieldInGroup(Group group, String fieldId) {

        return Optional.ofNullable(group.getFields()).stream().flatMap(Collection::stream).anyMatch(field -> fieldId.equals(field.getFieldId()));
    }

    public static boolean checkGroupInTab(Tab tab, String groupId) {

        return Optional.ofNullable(tab.getGroups()).stream().flatMap(Collection::stream).anyMatch(group -> groupId.equals(group.getGroupId()));
    }

    public static boolean checkTabInChecklist(ScreenDescription screenDescription, String tabId) {

        return Optional.ofNullable(screenDescription.getTabs()).stream().flatMap(Collection::stream).anyMatch(tab -> tabId.equals(tab.getTabId()));
    }

    public static Tab getTabInScreenDescription(ScreenDescription screenDescription, String tabId) {

        return Optional.ofNullable(screenDescription.getTabs()).stream().flatMap(Collection::stream).filter(tab -> tabId.equals(tab.getTabId()))
                .findFirst().orElse(null);
    }

    public static Group getGroupInTab(Tab tab, String groupId) {

        return Optional.ofNullable(tab.getGroups()).stream().flatMap(Collection::stream).filter(group -> groupId.equals(group.getGroupId()))
                .findFirst().orElse(null);
    }

    public static Field getFieldInGroup(Group group, String fieldId) {

        return Optional.ofNullable(group.getFields()).stream().flatMap(Collection::stream).filter(field -> fieldId.equals(field.getFieldId()))
                .findFirst().orElse(null);
    }

    public static Group getGroupById(ScreenDescription screenDescription, String groupId) {

        return Optional.of(screenDescription.getTabs()).stream().flatMap(Collection::stream).map(Tab::getGroups).filter(Objects::nonNull)
                .flatMap(Collection::stream).filter(group -> groupId.equals(group.getGroupId())).findFirst().orElse(null);
    }

    public static Optional<Field> getFieldById(ScreenDescription screenDescription, String fieldId) {

        return Optional.ofNullable(screenDescription).map(ScreenDescription::getTabs).stream().flatMap(Collection::stream).map(Tab::getGroups)
                .filter(Objects::nonNull).flatMap(Collection::stream).map(Group::getFields).filter(Objects::nonNull).flatMap(Collection::stream)
                .filter(group -> fieldId.equals(group.getFieldId())).findFirst();
    }

    public static String getFieldValue(Field field) {

        return field != null ? field.getSelectedValue() != null ? field.getSelectedValue() : "N/A" : "N/A";
    }

    public static List<Field> getFieldsById(ScreenDescription screenDescription, String fieldId) {

        return Optional.ofNullable(screenDescription).map(ScreenDescription::getTabs).stream().flatMap(Collection::stream).map(Tab::getGroups)
                .filter(Objects::nonNull).flatMap(Collection::stream).map(Group::getFields).filter(Objects::nonNull).flatMap(Collection::stream)
                .filter(field -> field.getFieldId() != null && field.getFieldId().startsWith(fieldId)).toList();
    }

    public static String getPayerCountry(BusinessTransaction transaction) {

        List<String> countries = Optional.of(transaction.getProductComponentPayments()).stream().filter(Objects::nonNull)
                .flatMap(Collection::stream).map(BusinessTransactionProductComponent::getPayments).filter(Objects::nonNull)
                .flatMap(Collection::stream).map(Payment::getPaymentDetails).filter(Objects::nonNull).map(PaymentDetails::getPayerBankCountry)
                .filter(Objects::nonNull).map(Country::getCountryName).filter(Objects::nonNull).toList();
        return String.join(" ", countries);
    }

    public static String getThirdPartiesRolesInfoCountry(List<String> valueList, Policy policy) {

        List<AbstractPerson> thirdParties = getThirdPartiesByRole(policy, valueList);
        return thirdParties.stream().map(AbstractPerson::getAddress).filter(Objects::nonNull).map(Address::getCountry).filter(Objects::nonNull)
                .map(Country::getIsoCountryCode).filter(Objects::nonNull).distinct().collect(Collectors.joining(countryDelimiter));
    }

    public static boolean isThirdPartyRoleAvailable(List<String> valueList, Policy policy) {

        for (String role : valueList) {
            switch (role) {
            case "HLR":
                if (policy.getHolders() != null && !policy.getHolders().isEmpty()) {
                    return true;
                }
                break;
            case "TRUST":
                if (policy.getTrusts() != null && !policy.getTrusts().isEmpty()) {
                    return true;
                }
                break;
            case "TRUSTEE":
                if (policy.getTrustees() != null && !policy.getTrustees().isEmpty()) {
                    return true;
                }
                break;
            case "SETTLOR":
                if (policy.getSettlors() != null && !policy.getSettlors().isEmpty()) {
                    return true;
                }
                break;
            case "CESSIONH":
                if (policy.getCessionHolders() != null && !policy.getCessionHolders().isEmpty()) {
                    return true;
                }
                break;
            case "PROXY":
                if (policy.getProxies() != null && !policy.getProxies().isEmpty()) {
                    return true;
                }
                break;
            case "LA":
                if (policy.getLifeAssureds() != null && !policy.getLifeAssureds().isEmpty()) {
                    return true;
                }
                break;
            case "BEN":
                if (policy.getBeneficiaries() != null && !policy.getBeneficiaries().isEmpty()) {
                    return true;
                }
                break;
            case "IB":
                if (policy.getIrrevocableBeneficiaries() != null && !policy.getIrrevocableBeneficiaries().isEmpty()) {
                    return true;
                }
                break;
            case "EBO":
                if (policy.getEconomicBeneficiaries() != null && !policy.getEconomicBeneficiaries().isEmpty()) {
                    return true;
                }
                break;
            }
        }
        return false;
    }

    public static List<AbstractPerson> getThirdPartiesByRole(Policy policy, List<String> roles) {

        List<PolicyRole> policyRoles = new ArrayList<>();
        for (String role : roles) {
            switch (role) {
            case "HLR":
                policyRoles.addAll(Optional.ofNullable(policy.getHolders()).stream().flatMap(Collection::stream).toList());
                break;
            case "EBO":
                policyRoles.addAll(Optional.ofNullable(policy.getEconomicBeneficiaries()).stream().flatMap(Collection::stream).toList());
                break;
            case "LA":
                policyRoles.addAll(Optional.ofNullable(policy.getLifeAssureds()).stream().flatMap(Collection::stream).toList());
                break;
            case "BEN":
                policyRoles.addAll(Optional.ofNullable(policy.getBeneficiaries()).stream().flatMap(Collection::stream).toList());
                break;
            case "IB":
                policyRoles.addAll(Optional.ofNullable(policy.getIrrevocableBeneficiaries()).stream().flatMap(Collection::stream).toList());
                break;
            case "TRUST":
                policyRoles.addAll(Optional.ofNullable(policy.getTrusts()).stream().flatMap(Collection::stream).toList());
                break;
            case "TRUSTEE":
                policyRoles.addAll(Optional.ofNullable(policy.getTrustees()).stream().flatMap(Collection::stream).toList());
                break;
            case "SETTLOR":
                policyRoles.addAll(Optional.ofNullable(policy.getSettlors()).stream().flatMap(Collection::stream).toList());
                break;
            case "PROXY":
                policyRoles.addAll(Optional.ofNullable(policy.getProxies()).stream().flatMap(Collection::stream).toList());
                break;
            case "CESSIONH":
                policyRoles.addAll(Optional.ofNullable(policy.getCessionHolders()).stream().flatMap(Collection::stream).toList());
                break;
            case "LINK":
                policyRoles.addAll(Optional.ofNullable(policy.getPolicyLinks()).stream().flatMap(Collection::stream).toList());
            default:
                break;
            }
        }

        return policyRoles.stream().map(PolicyRole::getThirdParties).filter(Objects::nonNull).flatMap(Collection::stream).distinct().toList();
    }

    public static boolean isOffShoreIndiciaFound(BusinessTransaction transaction, Policy policy, boolean isMoneyIn) {

        Boolean isInRemediationList = transaction.getIsInRemediationList();
        if (!isInRemediationList) {
            List<String> rolesAndLinks = new ArrayList<>(Arrays.asList("HLR", "EBO", "BEN", "IB", "LINK"));
            String rolesAndLinkCountries = getThirdPartiesRolesInfoCountry(rolesAndLinks, policy);
            if (!rolesAndLinkCountries.isEmpty() && !"BE".equals(rolesAndLinkCountries.trim())) {
                return true;
            } else {
                String countryOfWealthRFD = RulesUtils.getRiskFactorData(transaction, "ESC_RF_001");
                boolean countryOfWealthBE = Arrays.stream(countryOfWealthRFD.split(";")).map(thirdParties -> thirdParties.split(","))
                        .filter(thirdParty -> thirdParty.length > 1).map(thirdParty -> thirdParty[1]).map(String::trim).allMatch("BE"::equals);

                if (!countryOfWealthRFD.isEmpty() && !countryOfWealthRFD.toUpperCase().startsWith("MISSING") && !countryOfWealthBE) {
                    return true;
                } else {
                    List<BusinessTransactionProductComponent> productComponents = transaction.getProductComponentPayments();
                    if (productComponents != null && !productComponents.isEmpty()) {
                        List<PaymentDetails> paymentDetails = new ArrayList<>();
                        if (isMoneyIn) {
                            List<MoneyInPayment> payments = productComponents.stream().map(BusinessTransactionProductComponent::getPayments)
                                    .filter(Objects::nonNull).flatMap(Collection::stream).filter(MoneyInPayment.class::isInstance)
                                    .map(MoneyInPayment.class::cast).toList();
                            for (MoneyInPayment payment : payments) {
                                if (payment.getPaymentDetails() != null && payment.getPaymentDetails().getPayerID() != null
                                        && payment.getPaymentDetails().getPayerBankCountry() != null
                                        && payment.getPaymentDetails().getPayerBankName() != null) {
                                    paymentDetails.add(payment.getPaymentDetails());
                                } else {
                                    paymentDetails.add(payment.getExpectedPaymentDetails());
                                }
                            }
                        } else {
                            paymentDetails =
                                    productComponents.stream().map(BusinessTransactionProductComponent::getPayments).filter(Objects::nonNull)
                                            .flatMap(Collection::stream).map(Payment::getPaymentDetails).filter(Objects::nonNull).toList();
                        }
                        for (PaymentDetails payment : paymentDetails) {
                            if (payment.getPayerBankCountry() != null && payment.getPayerBankCountry().getIsoCountryCode() != null
                                    && !"BE".equals(payment.getPayerBankCountry().getIsoCountryCode())) {
                                return true;
                            }
                        }
                    }
                    return false;
                }
            }
        } else {
            return true;
        }
    }

    public static void computeThirdPartyRoleValueAndDisplay(final TextInputField inputField, final Policy policy,
            final List<String> rolesAndLinks) {

        String forcedValue = null;
        var forcedDisplayIf = "false";
        if (isThirdPartyRoleAvailable(rolesAndLinks, policy)) {
            forcedDisplayIf = "true";
            forcedValue = getThirdPartiesRolesInfoCountry(rolesAndLinks, policy);
        }
        inputField.setDisplayIf(forcedDisplayIf);
        inputField.setSelectedValue(forcedValue);
    }

    public static List<PaymentDetails> getMoneyInTransactionPaymentDetails(final BusinessTransaction transaction) {

        List<MoneyInPayment> payments = transaction.getProductComponentPayments().stream().filter(Objects::nonNull)
                .map(BusinessTransactionProductComponent::getPayments).filter(Objects::nonNull).flatMap(Collection::stream)
                .filter(MoneyInPayment.class::isInstance).map(MoneyInPayment.class::cast).toList();

        return payments.stream().map(payment -> {
            PaymentDetails paymentDetails = payment.getPaymentDetails();
            if (paymentDetails != null && paymentDetails.getPayerID() != null && paymentDetails.getPayerLegalAddressCountry() != null
                    && paymentDetails.getOriginator() != null) {
                return paymentDetails;
            } else {
                return payment.getExpectedPaymentDetails();
            }
        }).toList();
    }

}
