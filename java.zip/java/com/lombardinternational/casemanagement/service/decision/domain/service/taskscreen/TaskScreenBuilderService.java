package com.lombardinternational.casemanagement.service.decision.domain.service.taskscreen;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;

public interface TaskScreenBuilderService {

    ScreenDescription buildTaskScreen(WebForm webForm, ScreenDescription screenCheckList, ScreenDescription screenToFill);
}
