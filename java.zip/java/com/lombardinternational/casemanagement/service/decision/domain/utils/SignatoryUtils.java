package com.lombardinternational.casemanagement.service.decision.domain.utils;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

import org.apache.commons.lang3.StringUtils;

import com.lombardinternational.casemanagement.service.decision.domain.model.policy.Policy;
import com.lombardinternational.casemanagement.service.decision.domain.model.policy.PolicyHolder;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.RequiredSignatory;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.UserDetail;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebFormGroup;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.RulesUtils.*;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.WebformUtils.*;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.WebFormFieldConstants.*;
import static org.apache.commons.lang3.StringUtils.*;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class SignatoryUtils {

    public static final List<String> BFFM_BROKER_CODE = List.of(B_018, B_2000, B_2110, B_2172, B_2435, B_2436, B_3080);
    public static final List<String> LATAM_TARGET_MARKET = List.of("VE", "PE", "ME", "EC", "CO", "CL", "BR");
    private static final List<String> DEFAULT_ALLOWED_ACTION = List.of("DOWNLOAD");
    public static final LocalDate PRIOR_EFFECTIVE_DATE = LocalDate.of(2023, 7, 1);

    public static List<String> buildBFFMBrokerCode() {

        return BFFM_BROKER_CODE;
    }

    public static boolean isFOE(WebForm webForm) {

        final var constraints = new ArrayList<FieldConstraint>();
        constraints.add(
                FieldConstraint.builder().fieldId(BRANCH_TYPE).constraint(Constraint.EQUALS).values(Collections.singletonList("FOE")).build());

        return constraints.stream().allMatch(constraint -> constraint.test(webForm));
    }

    public static boolean isFOS(WebForm webForm) {

        final var constraints = new ArrayList<FieldConstraint>();
        constraints.add(
                FieldConstraint.builder().fieldId(BRANCH_TYPE).constraint(Constraint.EQUALS).values(Collections.singletonList("FOS")).build());

        return constraints.stream().allMatch(constraint -> constraint.test(webForm));
    }

    public static boolean isPolicyHolderExpectedLanguage(Policy policy, String expectedLang) {

        return Optional.ofNullable(policy.getPolicyHolder()).map(PolicyHolder::getLanguages).stream().flatMap(Collection::stream)
                .anyMatch(expectedLang::equals);
    }

    public static List<RequiredSignatory> buildSignatories(WebForm webForm) {

        final List<RequiredSignatory> signatories = new ArrayList<>();

        // Build default intermediary signatory
        buildIntermediarySignatory(webForm.getUserDetail(), signatories);

        // Build signatories based on contact details given by user in Connect
        final var signingGroup = getFirstWebFormGroupById(webForm, CONTACT_DETAILS);
        if (signingGroup != null && signingGroup.getGroups() != null) {
            for (WebFormGroup subGroup : signingGroup.getGroups()) {
                final var contactType = WebformUtils.getWebFormFieldValueById(subGroup, CONTACT_TYPE);
                final var id = WebformUtils.getWebFormFieldValueById(subGroup, ID);
                final var firstName = WebformUtils.getWebFormFieldValueById(subGroup, FIRST_NAME);
                final var lastName = WebformUtils.getWebFormFieldValueById(subGroup, LAST_NAME);
                final var email = WebformUtils.getWebFormFieldValueById(subGroup, EMAIL);
                final var phoneNumber = WebformUtils.getWebFormFieldValueById(subGroup, PHONE_NUMBER);
                final String label = StringUtils.normalizeSpace((firstName + " " + lastName).replaceAll("'", " "));

                RequiredSignatory signatory = new RequiredSignatory();
                signatory.setType(contactType);
                signatory.setThirdPartyId(id);
                signatory.setLastName(lastName);
                signatory.setFirstName(firstName);
                signatory.setLabel(label);
                signatory.setPhoneNumber(phoneNumber);
                signatory.setEmail(email);
                signatory.setAllowedActions(DEFAULT_ALLOWED_ACTION);
                signatories.add(signatory);
            }
        }
        return signatories;
    }

    public static List<RequiredSignatory> buildingRequiredSignatory(List<RequiredSignatory> requiredSignatories, WebForm webForm,
            String contactTypeRequired) {

        final var signingGroup = getFirstWebFormGroupById(webForm, CONTACT_DETAILS);

        if (signingGroup != null && signingGroup.getGroups() != null) {
            int indexSigner = 1;
            for (WebFormGroup subGroup : signingGroup.getGroups()) {
                final var contactType = WebformUtils.getWebFormFieldValueById(subGroup, CONTACT_TYPE);
                if (contactTypeRequired.equalsIgnoreCase(contactType)) {
                    final var id = WebformUtils.getWebFormFieldValueById(subGroup, ID);
                    final var firstName = WebformUtils.getWebFormFieldValueById(subGroup, FIRST_NAME);
                    final var lastName = WebformUtils.getWebFormFieldValueById(subGroup, LAST_NAME);
                    final var email = WebformUtils.getWebFormFieldValueById(subGroup, EMAIL);
                    final var phoneNumber = WebformUtils.getWebFormFieldValueById(subGroup, PHONE_NUMBER);
                    final String label = StringUtils.normalizeSpace((firstName + " " + lastName).replaceAll("'", " "));

                    RequiredSignatory signatory = new RequiredSignatory();
                    signatory.setType(contactTypeRequired);
                    signatory.setThirdPartyId(id);
                    signatory.setLastName(lastName);
                    signatory.setFirstName(firstName);
                    signatory.setLabel(label);
                    signatory.setPhoneNumber(phoneNumber);
                    signatory.setEmail(email);
                    signatory.setSignerId("signer" + indexSigner++);
                    signatory.setAllowedActions(DEFAULT_ALLOWED_ACTION);
                    requiredSignatories.add(signatory);
                }
            }
        }

        return requiredSignatories;
    }

    private static void buildIntermediarySignatory(final UserDetail userDetail, final List<RequiredSignatory> requiredSignatories) {

        final var userId = StringUtils.normalizeSpace(userDetail.getUserId());
        final var lastName = StringUtils.normalizeSpace(userDetail.getLastName());
        final var firstName = StringUtils.normalizeSpace(userDetail.getFirstName());
        final var email = StringUtils.normalizeSpace(userDetail.getEmail());
        final var phoneNumber = StringUtils.normalizeSpace(userDetail.getPhoneNumber());

        final var signatory = new RequiredSignatory();
        signatory.setType("INTERMEDIATE");
        signatory.setThirdPartyId(userId);
        signatory.setLastName(lastName);
        signatory.setFirstName(firstName);
        signatory.setLabel(StringUtils.normalizeSpace((firstName + " " + lastName).replaceAll("'", " ")));
        signatory.setPhoneNumber(phoneNumber);
        signatory.setEmail(email);
        signatory.setSignerId("signer0");
        signatory.setAllowedActions(DEFAULT_ALLOWED_ACTION);
        requiredSignatories.add(signatory);
    }

    /**
     * Checks if there is a new SAF
     *
     * @param webForm
     *            The webForm
     * @return true if there is a new SAF
     */
    public static boolean isNewSaf(WebForm webForm) {

        return Optional.ofNullable(getFirstWebFormGroupById(webForm, "SPECIALISED_ASSURANCE_FUNDS")).map(WebFormGroup::getGroups).stream()
                .flatMap(Collection::stream).map(WebFormGroup::getBooleanFields).flatMap(Collection::stream)
                .anyMatch(field -> "IS_NEW".equals(field.getFieldId()) && Boolean.TRUE.equals(field.getValue()));
    }

    public static boolean isNewIdf(WebForm webForm) {

        return Optional.ofNullable(getFirstWebFormGroupById(webForm, "INTERNAL_DEDICATED_FUNDS")).map(WebFormGroup::getGroups).stream()
                .flatMap(Collection::stream).map(WebFormGroup::getBooleanFields).flatMap(Collection::stream)
                .anyMatch(field -> "IS_NEW".equals(field.getFieldId()) && Boolean.TRUE.equals(field.getValue()));
    }

    /**
     * Checks if there is a new SAF for which the management type (such as "self", "advised", "buy & hold") is the one provided. Or at contrary,
     * using the negate, checks if there is a new SAF for which the management type is not the one provided.
     *
     * @param webForm
     *            The webForm
     * @param managements
     *            The management types
     * @param negate
     *            True to search for if the management type is not the one provided
     * @return true if there is a new SAF with/without the provided management type
     */
    public static boolean isNewSafWithManagement(WebForm webForm, List<String> managements, boolean negate) {

        return Optional.ofNullable(getFirstWebFormGroupById(webForm, "SPECIALISED_ASSURANCE_FUNDS")).map(WebFormGroup::getGroups).stream()
                .flatMap(Collection::stream)
                .anyMatch(g -> g.getBooleanFields().stream().anyMatch(f -> "IS_NEW".equals(f.getFieldId()) && Boolean.TRUE.equals(f.getValue()))
                        && g.getTextFields().stream().filter(f -> "FAS_MANAGER".equals(f.getFieldId()))
                                .anyMatch(f -> negate != managements.contains(f.getValue())));
    }

    public static boolean isRtoRepresentative(WebForm webForm) {

        return Optional.ofNullable(getFirstWebFormGroupById(webForm, "RTO_REPRESENTATIVE")).map(WebFormGroup::getBooleanFields).stream()
                .flatMap(Collection::stream).anyMatch(f -> "IS_DIFFERENT".equals(f.getFieldId()) && Boolean.TRUE.equals(f.getValue()));

    }

    public static boolean isHolderSpecificType(WebForm webForm, String holderSpecificType) {

        String[] types = holderSpecificType.split("\\|");

        return Optional.ofNullable(WebformUtils.getFirstWebFormGroupById(webForm, "POLICY_HOLDER")).stream()
                .map(group -> getFieldInGroup(group, "TYPE")).filter(Objects::nonNull).map(WebformUtils::getValueForWebFormField)
                .anyMatch(type -> ("physical".equals(type) && equalsAny("PP", types))
                        || (isHolderTypeMoralNotSC(webForm) && equalsAny("PM", types)) || (isHolderTypeSC(webForm) && equalsAny("SC", types)));
    }

    public static boolean isHolderTypeSC(WebForm webForm) {

        return Optional.ofNullable(getFirstWebFormGroupById(webForm, "POLICY_HOLDER")).map(WebFormGroup::getBooleanFields).stream()
                .flatMap(Collection::stream).anyMatch(f -> "IS_SC".equals(f.getFieldId()) && Boolean.TRUE.equals(f.getValue()));
    }

    private static boolean isHolderTypeMoralNotSC(final WebForm webForm) {

        return isHolderType(webForm, "moral") && !isHolderTypeSC(webForm);
    }

    public static boolean isHolderType(WebForm webForm, String expectedType) {

        return Optional.ofNullable(WebformUtils.getFirstWebFormGroupById(webForm, "POLICY_HOLDER")).stream()
                .map(group -> getFieldInGroup(group, "TYPE")).filter(Objects::nonNull).map(WebformUtils::getValueForWebFormField)
                .anyMatch(expectedType::equals);
    }
}
