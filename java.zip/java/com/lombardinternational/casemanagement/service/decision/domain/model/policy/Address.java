package com.lombardinternational.casemanagement.service.decision.domain.model.policy;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class Address {

    private Long addressId;
    private String residenceName;
    private String streetName;
    private String streetNumber;
    private String apartmentNumber;
    private String postalBox;
    private String postCode;
    private String townName;
    private Country country;
}
