package com.lombardinternational.casemanagement.service.decision.domain.service.taskscreen;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Tab;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;

public interface SubTaskScreenBuilderService {

    ScreenDescription buildSubTaskScreen(WebForm webForm, ScreenDescription screenCheckList, ScreenDescription screenToFill, final Tab parentTab);

    Boolean filterService(String screenId);
}
