package com.lombardinternational.casemanagement.service.decision.domain.service.factory;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Component;

import com.lombardinternational.casemanagement.service.decision.domain.model.TransactionKeyType;

@Component
public class TransactionFactory {

    Map<TransactionKeyType,RulesBuilderService> services = new HashMap<>();

    public TransactionFactory(AdditionRulesBuilderService additionRulesBuilderService, OnboardingRulesBuilderService onboardingRulesBuilderService,
            CCIRulesBuilderService cciRulesBuilderService, RopRulesBuilderService ropRulesBuilderService) {

        this.services.put(new TransactionKeyType("ADDITION_V2_SIGNATORY", "ADDITION_V2"), additionRulesBuilderService);
        this.services.put(new TransactionKeyType(null, "ADDITION_V2"), additionRulesBuilderService);
        this.services.put(new TransactionKeyType(null, "ROP"), ropRulesBuilderService);
        this.services.put(new TransactionKeyType("ROP_CHECKLIST", "ROP"), ropRulesBuilderService);
        this.services.put(new TransactionKeyType("REST_OF_PREMIUM_CHECKLIST", "ROP"), ropRulesBuilderService); // For cmt checklist
        this.services.put(new TransactionKeyType("ADDITION_CHECKLIST", "ADDITION_V2"), additionRulesBuilderService);
        this.services.put(new TransactionKeyType("ADDITION_CHECKLIST", "ADDITION"), additionRulesBuilderService);
        this.services.put(new TransactionKeyType("NEW_BUSINESS_CHECKLIST", "ONBOARDING"), onboardingRulesBuilderService);
        this.services.put(new TransactionKeyType("CHANGE_CLIENT_INFORMATION_CHECKLIST", "CHANGE_CLIENT_INFORMATION"), cciRulesBuilderService);
    }

    public RulesBuilderService getService(TransactionKeyType key) {

        return services.get(key);
    }
}
