package com.lombardinternational.casemanagement.service.decision.domain.exception;

public class ClassInternalNotFoundException extends RuntimeException {

    public ClassInternalNotFoundException(final String message) {

        super(message);
    }
}
