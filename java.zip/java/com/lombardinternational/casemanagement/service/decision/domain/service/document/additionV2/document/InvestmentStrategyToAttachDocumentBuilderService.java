package com.lombardinternational.casemanagement.service.decision.domain.service.document.additionV2.document;

import java.util.List;

import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Service;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.DocumentDefinition;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.document.AbstractDocumentBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.utils.WebformUtils;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.DocumentConstants.INVESTMENT_STRATEGY_CMS_DOC_TYPE;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.DocumentConstants.INVESTMENT_STRATEGY_DOC_TYPE;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.DocumentConstants.INVESTMENT_STRATEGY_TO_ATTACH_FORM_DESCRIPTION;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.DocumentConstants.INVESTMENT_STRATEGY_TO_ATTACH_FORM_I18N_DESCRIPTION;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.RulesConstants.DIFFERENT;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.WebFormFieldConstants.INVESTMENT_STRATEGY_WF;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.WebFormFieldConstants.POLICY_NUMBER_WF;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.WebFormFieldConstants.TYPE_WF;

@Service
public class InvestmentStrategyToAttachDocumentBuilderService extends AbstractDocumentBuilderService {

    @Override
    public void buildDocument(final WebForm webForm, final ScreenDescription screenDescription, String transactionNumber,
            List<DocumentDefinition> documents) {

        var investmentStrategy = WebformUtils.getFirstWebFormGroupById(webForm, INVESTMENT_STRATEGY_WF);
        if (investmentStrategy != null && CollectionUtils.isNotEmpty(investmentStrategy.getTextFields())) {
            var strategyType = WebformUtils.getWebFormFieldValueById(investmentStrategy, TYPE_WF);
            if (DIFFERENT.equals(strategyType)) {
                var relatedTo = WebformUtils.getWebFormFieldValueById(webForm, POLICY_NUMBER_WF);
                buildDocumentDefinition(relatedTo, relatedTo, null, null, documents);
            }
        }
    }

    @Override
    protected String getDocumentType() {

        return INVESTMENT_STRATEGY_DOC_TYPE;
    }

    @Override
    protected String getCmsDocumentType() {

        return INVESTMENT_STRATEGY_CMS_DOC_TYPE;
    }

    @Override
    protected String getDescription() {

        return INVESTMENT_STRATEGY_TO_ATTACH_FORM_DESCRIPTION;
    }

    @Override
    protected String getI18NDescription() {

        return INVESTMENT_STRATEGY_TO_ATTACH_FORM_I18N_DESCRIPTION;
    }

    @Override
    protected boolean getDocumentVisibleOnConnect() {

        return true;
    }

    @Override
    protected boolean getDocumentRequired() {

        return true;
    }
}
