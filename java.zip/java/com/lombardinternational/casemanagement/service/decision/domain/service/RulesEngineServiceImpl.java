package com.lombardinternational.casemanagement.service.decision.domain.service;

import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.lombardinternational.casemanagement.service.decision.domain.api.RulesEngineService;
import com.lombardinternational.casemanagement.service.decision.domain.model.TransactionKeyType;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ControlDefinition;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.DocumentDefinition;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Field;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Group;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.SignatoryResult;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Tab;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.TaskDefinition;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.factory.TransactionFactory;

import lombok.AllArgsConstructor;

@Service
@AllArgsConstructor
public class RulesEngineServiceImpl implements RulesEngineService {

    private final TransactionFactory transactionFactory;
    private final PolicyService policyService;
    private final BusinessTransactionService businessTransactionService;

    @Override
    public ScreenDescription buildCheckList(final WebForm webForm, final ScreenDescription screenDescription, final String policyNumber,
            final String transactionNumber) throws Exception {

        final var service = transactionFactory.getService(new TransactionKeyType(screenDescription.getScreenId(), webForm.getWebFormId()));
        final var checklist = service.buildCheckList(webForm, screenDescription, policyService.getPolicyDetails(policyNumber),
                businessTransactionService.getBusinessTransactionDetails(transactionNumber));
        this.cleanChecklist(checklist);
        return checklist;
    }

    @Override
    public List<TaskDefinition> buildTaskList(final WebForm webForm, final ScreenDescription screenDescription, final String policyNumber)
            throws Exception {

        final var service = transactionFactory.getService(new TransactionKeyType(screenDescription.getScreenId(), webForm.getWebFormId()));
        return service.buildTaskList(webForm, screenDescription, policyService.getPolicyDetails(policyNumber));
    }

    @Override
    public ScreenDescription buildTaskScreen(final WebForm webForm, final ScreenDescription screenCheckList,
            final ScreenDescription screenToFill) {

        final var service = transactionFactory.getService(new TransactionKeyType(screenCheckList.getScreenId(), webForm.getWebFormId()));
        final var taskScreen = service.buildTaskScreen(webForm, screenCheckList, screenToFill);
        this.cleanChecklist(taskScreen);
        return taskScreen;
    }

    @Override
    public List<DocumentDefinition> buildDocumentsDefinition(final WebForm webForm, final ScreenDescription screenDescription,
            final String policyNumber, final String transactionNumber) throws Exception {

        final var service = transactionFactory.getService(new TransactionKeyType(
                Optional.ofNullable(screenDescription).map(ScreenDescription::getScreenId).orElse(null), webForm.getWebFormId()));
        return service.buildDocumentsDefinition(webForm, screenDescription, policyService.getPolicyDetails(policyNumber), transactionNumber);
    }

    @Override
    public List<ControlDefinition> buildControlDefinition(final WebForm webForm, final ScreenDescription screenDescription) {

        final var service = transactionFactory.getService(new TransactionKeyType(screenDescription.getScreenId(), webForm.getWebFormId()));
        return service.buildControlDefinition(webForm, screenDescription);
    }

    @Override
    public SignatoryResult buildSignatories(final WebForm webForm, final String policyNumber) throws Exception {

        final var service = transactionFactory.getService(new TransactionKeyType("ADDITION_V2_SIGNATORY", webForm.getWebFormId()));

        return service.buildSignatories(webForm, policyService.getPolicyDetails(policyNumber));
    }

    private void cleanChecklist(final ScreenDescription screenDescription) {

        if (screenDescription != null && screenDescription.getTabs() != null) {
            // Filter obsolete tabs
            List<Tab> tabs = screenDescription.getTabs().stream().filter(Objects::nonNull).filter(Tab::getIsActive).map(this::filterObsoleteGroups)
                    .collect(Collectors.toList());

            screenDescription.setTabs(tabs);
        }
    }

    private Tab filterObsoleteGroups(final Tab tab) {

        if (tab.getGroups() == null) {
            return tab;
        }

        // Filter obsolete groups
        List<Group> groups = tab.getGroups().stream().filter(Objects::nonNull).filter(Group::getIsActive).map(this::filterObsoleteFields)
                .collect(Collectors.toList());
        tab.setGroups(groups);
        return tab;
    }

    private Group filterObsoleteFields(final Group group) {

        if (group.getFields() == null) {
            return group;
        }

        // Filter obsolete fields
        List<Field> fields = group.getFields().stream().filter(Objects::nonNull).filter(Field::getIsActive).collect(Collectors.toList());
        group.setFields(fields);
        return group;
    }
}
