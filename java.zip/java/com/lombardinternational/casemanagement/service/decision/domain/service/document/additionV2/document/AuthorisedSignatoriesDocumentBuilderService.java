package com.lombardinternational.casemanagement.service.decision.domain.service.document.additionV2.document;

import java.util.List;

import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Service;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.DocumentDefinition;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.TextWebFormField;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.document.AbstractDocumentBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.utils.WebformUtils;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.DocumentConstants.*;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.RulesConstants.*;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.WebFormFieldConstants.*;

@Service
public class AuthorisedSignatoriesDocumentBuilderService extends AbstractDocumentBuilderService {

    @Override
    public void buildDocument(final WebForm webForm, final ScreenDescription screenDescription, String transactionNumber,
            List<DocumentDefinition> documents) {

        var policyHolderGroup = WebformUtils.getFirstWebFormGroupById(webForm, POLICY_HOLDER_WF);
        if (policyHolderGroup != null && CollectionUtils.isNotEmpty(policyHolderGroup.getTextFields())) {
            var phType = (TextWebFormField) WebformUtils.getWebFormGroupFieldsById(policyHolderGroup, TYPE_WF).getFirst();
            if (MORAL.equalsIgnoreCase(phType.getValue())) {
                var relatedTo = WebformUtils.getWebFormFieldValueById(webForm, POLICY_NUMBER_WF);
                buildDocumentDefinition(relatedTo, relatedTo, null, null, documents);
            }
        }
    }

    @Override
    protected String getDocumentType() {

        return TP_DOCS_DOC_TYPE;
    }

    @Override
    protected String getCmsDocumentType() {

        return TP_DOCS_CMS_DOC_TYPE;
    }

    @Override
    protected String getDescription() {

        return AUTHORISED_SIGNATORIES_FORM_DESCRIPTION;
    }

    @Override
    protected String getI18NDescription() {

        return AUTHORISED_SIGNATORIES_FORM_I18N_DESCRIPTION;
    }

    @Override
    protected boolean getDocumentVisibleOnConnect() {

        return true;
    }

    @Override
    protected boolean getDocumentRequired() {

        return false;
    }
}
