package com.lombardinternational.casemanagement.service.decision.domain.utils.constants;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public final class ControlConstants {

    public static final String YES = "YES";
    public static final String NO = "NO";

    public static final String THIRD_PARTY_FORM_NAME =
            "3rd PP - 3rd p.p. form signed by origination bank + link with PH and reason of 3rd party payment";
    public static final String THIRD_PARTY_FORM_TYPE = "THIRD_PARTY_FORM";

    public static final String AEOI_MRL_NAME =
            "(Existing or new) Complete - valid and consistent with data in the app form AEOI self-certification for the MRL trustee";
    public static final String AEOI_MRL_TYPE = "AEOI_MRL";

    public static final String AEOI_PASSIVE_NAME =
            "(Existing or new) Complete - valid and consistent with data in the app form AEOI self-certification(s) for the entity and the controlling person(s) if passive NFE";
    public static final String AEOI_PASSIVE_TYPE = "AEOI_PASSIVE";

    public static final String AEOI_SELF_NAME = "(New) Complete - valid and consistent with data in the app form AEOI self-certification";
    public static final String AEOI_SELF_TYPE = "AEOI_SELF";

    public static final String AEOI_TRUST_NAME =
            "(New) Complete - valid and consistent with data in the app form AEOI self-certifications for the trust and for the controlling person(s) if any";
    public static final String AEOI_TRUST_TYPE = "AEOI_TRUST";

    public static final String EBAC_APPROVAL_NON_CORE_NAME = "eBAC approval (non core market)";
    public static final String EBAC_APPROVAL_NON_CORE_TYPE = "EBAC_APPROVAL_NON_CORE";

    public static final String EBAC_APPROVAL_PH_EBO_NAME = "eBAC approval (PH/EBO country of residence)";
    public static final String EBAC_APPROVAL_PH_EBO_TYPE = "EBAC_APPROVAL_PH_EBO";

    public static final String WSS_ADVICE_NAME = "Obtain WSS advice (non core market)";
    public static final String WSS_ADVICE_TYPE = "WSS_ADVICE";

    public static final String PERMIT_B_L_NAME = "Permit B or L within the validity of the permit (if C permit - addition not allowed)";
    public static final String PERMIT_B_L_TYPE = "PERMIT_B_L";

    public static final String REJECTION_PROCEDURE_NAME = "Rejection procedure fulfilled";
    public static final String REJECTION_PROCEDURE_TYPE = "REJECTION_PROCEDURE";

    public static final String CHECK_FEASIBILITY_WSS_NAME = "Check with WSS feasibility of addition and submission to eBAC";
    public static final String CHECK_FEASIBILITY_WSS_TYPE = "CHECK_FEASIBILITY_WSS";

    public static final String THIRD_PARTY_ID_AND_PROOF_NAME =
            "3rd PP - 3rd party Id and proof of residence/constitutional documents on file (not older than 6 months)";
    public static final String THIRD_PARTY_ID_AND_PROOF_TYPE = "THIRD_PARTY_ID_AND_PROOF";

    public static final String BANK_STATEMENT_WITH_AMOUNT_NAME =
            "3rd PP - Certified copy of EBO’s bank statement identifying the amount transferred";
    public static final String BANK_STATEMENT_WITH_AMOUNT_TYPE = "BANK_STATEMENT_WITH_AMOUNT";

    public static final String BROKER_AUTHORISED_IN_COUNTRY_SIGNATURE_NAME = "Broker authorised in country of signature";
    public static final String BROKER_AUTHORISED_IN_COUNTRY_SIGNATURE_TYPE = "BROKER_AUTHORISED_IN_COUNTRY_SIGNATURE";

    public static final String BROKER_AUTHORISED_IN_PH_COUNTRY_NAME = "Broker authorised in PH country of residence";
    public static final String BROKER_AUTHORISED_IN_PH_COUNTRY_TYPE = "BROKER_AUTHORISED_IN_PH_COUNTRY";

    public static final String PREMIUM_RATIONALE_NAME =
            "3rd PP - Detailed rationale as to why premium coming from partner account with appropriate documentation to support the rationale";
    public static final String PREMIUM_RATIONALE_TYPE = "PREMIUM_RATIONALE";

    public static final String ENTITY_PARTNER_NAME =
            "3rd PP - The entity must be an approved cooperation partner of Utmost Luxembourg S.A. (i.e. insurance intermediary / business introducer / investment manager or custodian bank) regulated in a Luxembourg equivalent jurisdiction";
    public static final String ENTITY_PARTNER_TYPE = "ENTITY_PARTNER";

    public static final String PAYMENT_REFERENCE_NAME = "3rd PP - Payment must be made with a reference to the name of the policyholder";
    public static final String PAYMENT_REFERENCE_TYPE = "PAYMENT_REFERENCE";

    public static final String PAYMENT_REFERENCE_NAME_NAME = "3rd PP - Payment must be made with reference to the Policyholder name";
    public static final String PAYMENT_REFERENCE_NAME_TYPE = "PAYMENT_REFERENCE_NAME";

    public static final String BUSINESS_HANDBOOK_NAME = "3rd PP - Please refer to Business handbook for SIPP/SASS 3rd party payment";
    public static final String BUSINESS_HANDBOOK_TYPE = "BUSINESS_HANDBOOK";

    public static final String OFFICE_IN_STANDARD_COUNTRY_NAME =
            "3rd PP - Relevant office must be established in a standard country of payment - licensed or registered with the competent authorities in the jurisdiction";
    public static final String OFFICE_IN_STANDARD_COUNTRY_TYPE = "OFFICE_IN_STANDARD_COUNTRY";

    public static final String PROOF_FAMILY_MEMBER_NAME = "3rd PP - Valid ID/proof of residence not older than 6 months of the family member";
    public static final String PROOF_FAMILY_MEMBER_TYPE = "PROOF_FAMILY_MEMBER";

    public static final String PROOF_SETTLOR_EBO_NAME = "3rd PP - Valid ID/proof of residence not older than 6 months of the settlor/EBO";
    public static final String PROOF_SETTLOR_EBO_TYPE = "PROOF_SETTLOR_EBO";

    public static final String NEGATIVE_PRESS_FINDING_NAME = "Update the negative press finding in CLASS";
    public static final String NEGATIVE_PRESS_FINDING_TYPE = "NEGATIVE_PRESS_FINDING";

    public static final String VERIFICATION_DATA_SYNCHRONIZATION_BEFORE_COMPLETION_NAME =
            "Verify synchronization with latest CLASS data before completion : please Regenerate & Save in the Overview tab, control escalation rules triggered then check pending Tasks tab)";
    public static final String VERIFICATION_DATA_SYNCHRONIZATION_BEFORE_COMPLETION_TYPE = "VERIFICATION_DATA_SYNCHRONIZATION_BEFORE_COMPLETION";

    public static final String COPY_ID_POLICY_ROLE_NAME = "Certified copy of valid ID for PH(s) / EBO(s) / LA(s) (when required) / POA(s) on file";
    public static final String COPY_ID_POLICY_ROLE_NAME_NBD = "Certified copy of valid ID for PH(s) / EBO(s) / LA(s) (when required) / POA(s)";
    public static final String COPY_ID_POLICY_ROLE_TYPE = "COPY_ID_POLICY_ROLE";

    public static final String COPY_POR_POLICY_ROLE_NAME =
            "Certified proof of residence (not older than 6 months) for PH(s) / EBO(s) / LA(s) (when required) / POA(s) on file";

    public static final String COPY_POR_POLICY_ROLE_NAME_NBD =
            "Certified proof of residence (not older than 6 months) for PH(s) / EBO(s) / LA(s) (when required) / POA(s)";
    public static final String COPY_POR_POLICY_ROLE_TYPE = "COPY_POR_POLICY_ROLE";

    public static final String COPY_ART_ASSOC_STATUTES_NAME =
            "Certified copy of Art. of inc. - Art. of Association - Statutes (if available, notarised copies) on file";

    public static final String COPY_ART_ASSOC_STATUTES_NAME_NBD =
            "Certified copy of Art. of inc. - Art. of Association - Statutes (if available, notarised copies)";
    public static final String COPY_ART_ASSOC_STATUTES_TYPE = "COPY_ART_ASSOC_STATUTES";

    public static final String COPY_TRADE_CERTIFICATE_NAME =
            "Certified copy of Trade/Commercial Register Extracts/certificate of incumbency (not older than 6 months) on file";

    public static final String COPY_TRADE_CERTIFICATE_NAME_NBD =
            "Certified copy of Trade/Commercial Register Extracts/certificate of incumbency (not older than 6 months)";
    public static final String COPY_TRADE_CERTIFICATE_TYPE = "COPY_TRADE_CERTIFICATE";

    public static final String COPY_LIST_DIR_AUTH_SIGNATORIES_NAME =
            "Certified copy of List of directors/authorised signatories (not older than a year) on file";

    public static final String COPY_LIST_DIR_AUTH_SIGNATORIES_NAME_NBD =
            "Certified copy of List of directors/authorised signatories (not older than a year)";
    public static final String COPY_LIST_DIR_AUTH_SIGNATORIES_TYPE = "COPY_LIST_DIR_AUTH_SIGNATORIES";

    public static final String COPY_ID_AUTH_SIGNATORIES_NAME =
            "Certified copy of valid ID for the authorised signatories (the ones acting on behalf of the legal entity within the scope of the policy) on file";
    public static final String COPY_ID_AUTH_SIGNATORIES_NAME_NBD =
            "Certified copy of valid ID for the authorised signatories (the ones acting on behalf of the legal entity within the scope of the policy)";
    public static final String COPY_ID_AUTH_SIGNATORIES_TYPE = "COPY_ID_AUTH_SIGNATORIES";

    public static final String COPY_POR_AUTH_SIGNATORIES_NAME =
            "Certified proof of residence (not older than 6 months) for the authorised signatories (the ones acting on behalf of the legal entity within the scope of the policy) on file";
    public static final String COPY_POR_AUTH_SIGNATORIES_NAME_NBD =
            "Certified proof of residence (not older than 6 months) for the authorised signatories (the ones acting on behalf of the legal entity within the scope of the policy)";
    public static final String COPY_POR_AUTH_SIGNATORIES_TYPE = "COPY_POR_AUTH_SIGNATORIES";

    public static final String COPY_SHR_REGISTER_MEMBER_NAME =
            "Certified copy of Shareholder Register/Register of Member (not older than 6 months) on file";
    public static final String COPY_SHR_REGISTER_MEMBER_NAME_NBD =
            "Certified copy of Shareholder Register/Register of Member (not older than 6 months)";
    public static final String COPY_SHR_REGISTER_MEMBER_TYPE = "COPY_SHR_REGISTER_MEMBER";

    public static final String EXTRACT_CENTRAL_REGISTER_BO_NAME =
            "Extract of the central register of beneficial owner if located in an EU member state (not older than 6 months) on file";
    public static final String EXTRACT_CENTRAL_REGISTER_BO_NAME_NBD =
            "Extract of the central register of beneficial owner if located in an EU member state (not older than 6 months)";
    public static final String EXTRACT_CENTRAL_REGISTER_BO_TYPE = "EXTRACT_CENTRAL_REGISTER_BO";

    public static final String SIGNED_OWNERSHIP_STRUCTURE_CHART_NAME =
            "Ownership structure chart in the case of multiple layers of ownership (i.e. more than 2 layers) - signed & certified (dated within the last 6 months) on file";
    public static final String SIGNED_OWNERSHIP_STRUCTURE_CHART_NAME_NBD =
            "Ownership structure chart in the case of multiple layers of ownership (i.e. more than 2 layers) - signed & certified (dated within the last 6 months)";
    public static final String SIGNED_OWNERSHIP_STRUCTURE_CHART_TYPE = "SIGNED_OWNERSHIP_STRUCTURE_CHART";

    public static final String SHR_REGISTER_AND_TRADE_REGISTER_NAME =
            "In case of multiple layers of ownership, shareholder register and up to date extract of trade register (not older than 6 months) for each corporate shareholder until the beneficial owner on file";
    public static final String SHR_REGISTER_AND_TRADE_REGISTER_NAME_NBD =
            "In case of multiple layers of ownership, shareholder register and up to date extract of trade register (not older than 6 months) for each corporate shareholder until the beneficial owner";
    public static final String SHR_REGISTER_AND_TRADE_REGISTER_TYPE = "SHR_REGISTER_AND_TRADE_REGISTER";

    public static final String PROOF_BENEFICIAL_OWNERSHIP_NAME =
            "Proof of ultimate beneficial ownership (if applicable for complex structure, nominee shareholder) on file";
    public static final String PROOF_BENEFICIAL_OWNERSHIP_NAME_NBD =
            "Proof of ultimate beneficial ownership (if applicable for complex structure, nominee shareholder)";
    public static final String PROOF_BENEFICIAL_OWNERSHIP_TYPE = "PROOF_BENEFICIAL_OWNERSHIP";

    public static final String COPY_ID_EBO_NAME = "Certified copy of valid ID for each EBO (ultimate beneficial owner) on file";
    public static final String COPY_ID_EBO_NAME_NBD = "Certified copy of valid ID for each EBO (ultimate beneficial owner)";
    public static final String COPY_ID_EBO_TYPE = "COPY_ID_EBO";

    public static final String COPY_POR_EBO_NAME =
            "Certified copy of valid proof of residence (not older than 6 months) for each EBO (ultimate beneficial owner) on file";
    public static final String COPY_POR_EBO_NAME_NBD =
            "Certified copy of valid proof of residence (not older than 6 months) for each EBO (ultimate beneficial owner)";
    public static final String COPY_POR_EBO_TYPE = "COPY_POR_EBO";

    public static final String APPROVED_ANNUAL_ACCOUNTS_NAME = "Approved Annual accounts on file (if audited available to be provided)";
    public static final String APPROVED_ANNUAL_ACCOUNTS_NAME_NBD = "Approved Annual accounts (if audited available to be provided)";
    public static final String APPROVED_ANNUAL_ACCOUNTS_TYPE = "APPROVED_ANNUAL_ACCOUNTS";

    public static final String FIDUCIARY_MANDATE_NAME = "Fiduciary mandate exists on file";
    public static final String FIDUCIARY_MANDATE_TYPE = "FIDUCIARY_MANDATE";

    public static final String ART_ASSOC_FIDUCIARY_NAME =
            "Latest Articles of Association/Statutes/Articles of Incorporation of the fiduciary (if available, notarised copies) on file";
    public static final String ART_ASSOC_FIDUCIARY_NAME_NBD =
            "Latest Articles of Association/Statutes/Articles of Incorporation of the fiduciary (if available, notarised copies)";
    public static final String ART_ASSOC_FIDUCIARY_TYPE = "ART_ASSOC_FIDUCIARY";

    public static final String EXTRACT_TRADE_REGISTER_FIDUCIARY_NAME =
            "Up-to-date extract from the trade register of the fiduciary \"Visura Camerale\"  (not older than 6 months) on file";
    public static final String EXTRACT_TRADE_REGISTER_FIDUCIARY_NAME_NBD =
            "Up-to-date extract from the trade register of the fiduciary \"Visura Camerale\"  (not older than 6 months)";
    public static final String EXTRACT_TRADE_REGISTER_FIDUCIARY_TYPE = "EXTRACT_TRADE_REGISTER_FIDUCIARY";

    public static final String LIST_DIR_SHR_FIDUCIARY_NAME =
            "List of Directors and shareholders of the fiduciary (not older than 6 months) on file";
    public static final String LIST_DIR_SHR_FIDUCIARY_NAME_NBD = "List of Directors and shareholders of the fiduciary (not older than 6 months)";
    public static final String LIST_DIR_SHR_FIDUCIARY_TYPE = "LIST_DIR_SHR_FIDUCIARY";

    public static final String EXTRACT_CENTRAL_REGISTER_BO_FIDUCIARY_NAME =
            "Up to date extract of the central register of beneficial owner in the name the fiduciary (not older than 6 months) on file";
    public static final String EXTRACT_CENTRAL_REGISTER_BO_FIDUCIARY_NAME_NBD =
            "Up to date extract of the central register of beneficial owner in the name the fiduciary (not older than 6 months)";
    public static final String EXTRACT_CENTRAL_REGISTER_BO_FIDUCIARY_TYPE = "EXTRACT_CENTRAL_REGISTER_BO_FIDUCIARY";

    public static final String OWNERSHIP_STRUCTURE_CHART_FIDUCIARY_NAME =
            "Ownership structure chart of the fiduciary in the case of multiple layers of ownership - signed & certified (dated within the last 6 months) on file";
    public static final String OWNERSHIP_STRUCTURE_CHART_FIDUCIARY_NAME_NBD =
            "Ownership structure chart of the fiduciary in the case of multiple layers of ownership - signed & certified (dated within the last 6 months)";
    public static final String OWNERSHIP_STRUCTURE_CHART_FIDUCIARY_TYPE = "OWNERSHIP_STRUCTURE_CHART_FIDUCIARY";

    public static final String LIST_AUTHORISED_SIGNATORIES_FIDUCIARY_NAME =
            "List of authorised signatures of the fiduciary (not older than one year) on file";
    public static final String LIST_AUTHORISED_SIGNATORIES_FIDUCIARY_NAME_NBD =
            "List of authorised signatures of the fiduciary (not older than one year)";
    public static final String LIST_AUTHORISED_SIGNATORIES_FIDUCIARY_TYPE = "LIST_AUTHORISED_SIGNATORIES_FIDUCIARY";

    public static final String COPY_ID_FIDUCIARY_NAME =
            "Certified copy of valid ID for each fiduciary signatory signing the additional form on file";
    public static final String COPY_ID_FIDUCIARY_NBD_NAME =
            "Certified copy of verification of identity of each fiduciary signatory signing the application form (valid ID documents)";
    public static final String COPY_ID_FIDUCIARY_TYPE = "COPY_ID_FIDUCIARY";

    public static final String COPY_ID_EBO_FIDUCIARY_NAME = "Certified copy of valid ID for each EBO on file";
    public static final String COPY_ID_EBO_FIDUCIARY_NAME_NBD = "Certified copy of valid ID for each EBO";
    public static final String COPY_ID_EBO_FIDUCIARY_TYPE = "COPY_ID_EBO_FIDUCIARY";

    public static final String COPY_POR_EBO_FIDUCIARY_NAME = "Certified proof of residence (not older than 6 months) for each EBO on file";
    public static final String COPY_POR_EBO_FIDUCIARY_NAME_NBD = "Certified proof of residence (not older than 6 months) for each EBO";
    public static final String COPY_POR_EBO_FIDUCIARY_TYPE = "COPY_POR_EBO_FIDUCIARY";

    public static final String CERTIFIED_TRUST_DEED_NAME =
            "Certified Trust Deed or relevant extract of the trust deed with rationale as to why entire trust deed cannot be provided exists on file";
    public static final String CERTIFIED_TRUST_DEED_TYPE = "CERTIFIED_TRUST_DEED";

    public static final String DEED_APPOINTMENT_TRUSTEES_NAME =
            "Deed of appointment/resignation of trustees (if any update since set-up of the trust) on file";
    public static final String DEED_APPOINTMENT_TRUSTEES_NAME_NBD =
            "Deed of appointment/resignation of trustees (if any update since set-up of the trust)";
    public static final String DEED_APPOINTMENT_TRUSTEES_TYPE = "DEED_APPOINTMENT_TRUSTEES";

    public static final String DEVIATION_SUITABILITY_PROFILE_NAME = "Deviation from suitability profile";
    public static final String DEVIATION_SUITABILITY_PROFILE_TYPE = "DEVIATION_SUITABILITY_PROFILE";

    public static final String CERTIFIED_ID_EBO_NAME =
            "Certified copy of valid ID for each EBO (settlor, physical trustee, protector if any, nominated beneficiaries If any and aware of such nomination) on file";
    public static final String CERTIFIED_ID_EBO_NAME_NBD =
            "Certified copy of valid ID for each EBO (settlor, physical trustee, protector if any, nominated beneficiaries If any and aware of such nomination)";
    public static final String CERTIFIED_ID_EBO_TYPE = "CERTIFIED_ID_EBO";

    public static final String CERTIFIED_POR_EBO_NAME =
            "Certified proof of residence (not older than 6 months) for each EBO (settlor, physical trustee, protector if any, nominated beneficiaries If any and aware of such nomination) on file";
    public static final String CERTIFIED_POR_EBO_NAME_NBD =
            "Certified proof of residence (not older than 6 months) for each EBO (settlor, physical trustee, protector if any, nominated beneficiaries If any and aware of such nomination)";
    public static final String CERTIFIED_POR_EBO_TYPE = "CERTIFIED_POR_EBO";

    public static final String EXTRACT_CENTRAL_REGISTER_FID_TRUST_NAME =
            "Up-to-date extract of the central register of fiduciary and trust (not older than 6 months) on file";
    public static final String EXTRACT_CENTRAL_REGISTER_FID_TRUST_NAME_NBD =
            "Up-to-date extract of the central register of fiduciary and trust (not older than 6 months)";
    public static final String EXTRACT_CENTRAL_REGISTER_FID_TRUST_TYPE = "EXTRACT_CENTRAL_REGISTER_FID_TRUST";

    public static final String STATUTES_CORP_TRUSTEE_NAME =
            "Identification of the corporate trustees  (statutes/articles of association)  on file";
    public static final String STATUTES_CORP_TRUSTEE_NAME_NBD = "Identification of the corporate trustees  (statutes/articles of association)";
    public static final String STATUTES_CORP_TRUSTEE_TYPE = "STATUTES_CORP_TRUSTEE";

    public static final String EXTRACT_TRADE_REGISTER_CORP_TRUSTEE_NAME =
            "Identification of the corporate trustees  (extract of trade register dated within the last 6 months) on file";
    public static final String EXTRACT_TRADE_REGISTER_CORP_TRUSTEE_NAME_NBD =
            "Identification of the corporate trustees  (extract of trade register dated within the last 6 months)";
    public static final String EXTRACT_TRADE_REGISTER_CORP_TRUSTEE_TYPE = "EXTRACT_TRADE_REGISTER_CORP_TRUSTEE";

    public static final String SHR_REGISTER_CORP_TRUSTEE_NAME =
            "Identification of the corporate trustees  (shareholder register dated within the last 6 months) on file";
    public static final String SHR_REGISTER_CORP_TRUSTEE_NAME_NBD =
            "Identification of the corporate trustees  (shareholder register dated within the last 6 months)";
    public static final String SHR_REGISTER_CORP_TRUSTEE_TYPE = "SHR_REGISTER_CORP_TRUSTEE";

    public static final String LIST_AUTH_SIGN_CORP_TRUSTEE_NAME =
            "Identification of the corporate trustees  (list of authorised signatories dated within the last 12 months) on file";
    public static final String LIST_AUTH_SIGN_CORP_TRUSTEE_NAME_NBD =
            "Identification of the corporate trustees  (list of authorised signatories dated within the last 12 months)";
    public static final String LIST_AUTH_SIGN_CORP_TRUSTEE_TYPE = "LIST_AUTH_SIGN_CORP_TRUSTEE";

    public static final String ID_AND_POR_CORP_TRUSTEE_NAME =
            "Identification of the corporate trustees  (certified valid ID card and POR for each authorised signatory acting on behalf of the corporate trustee within the scope of the policy) on file";
    public static final String ID_AND_POR_CORP_TRUSTEE_NAME_NBD =
            "Identification of the corporate trustees  (certified valid ID card and POR for each authorised signatory acting on behalf of the corporate trustee within the scope of the policy)";
    public static final String ID_AND_POR_CORP_TRUSTEE_TYPE = "ID_AND_POR_CORP_TRUSTEE";

    public static final String OWNERSHIP_STRUCTURE_CORP_TRUSTEE_NAME =
            "Identification of the corporate trustees  (signed and dated ownership structure chart in case of multi-layered ownership) on file";
    public static final String OWNERSHIP_STRUCTURE_CORP_TRUSTEE_NAME_NBD =
            "Identification of the corporate trustees  (signed and dated ownership structure chart in case of multi-layered ownership)";
    public static final String OWNERSHIP_STRUCTURE_CORP_TRUSTEE_TYPE = "OWNERSHIP_STRUCTURE_CORP_TRUSTEE";

    public static final String SHR_TRADE_REGISTER_CORP_TRUSTEE_NAME =
            "Identification of the corporate trustees  (in case of multiple layers of ownership, shareholder register and up to date extract of trade register (not older than 6 months) for each corporate shareholder until the beneficial owner) on file";
    public static final String SHR_TRADE_REGISTER_CORP_TRUSTEE_NAME_NBD =
            "Identification of the corporate trustees  (in case of multiple layers of ownership, shareholder register and up to date extract of trade register (not older than 6 months) for each corporate shareholder until the beneficial owner)";
    public static final String SHR_TRADE_REGISTER_CORP_TRUSTEE_TYPE = "SHR_TRADE_REGISTER_CORP_TRUSTEE";

    public static final String ID_AND_POR_EBO_CORP_TRUSTEE_NAME =
            "Identification of the corporate trustees  (identification of the EBOs - ID and POR) on file";
    public static final String ID_AND_POR_EBO_CORP_TRUSTEE_NAME_NBD =
            "Identification of the corporate trustees  (identification of the EBOs - ID and POR)";
    public static final String ID_AND_POR_EBO_CORP_TRUSTEE_TYPE = "ID_AND_POR_EBO_CORP_TRUSTEE";

    public static final String INFORMATION_RENDITEKENNZIFFER_NAME = "Information zur Renditekennziffer";
    public static final String INFORMATION_RENDITEKENNZIFFER_TYPE = "INFORMATION_RENDITEKENNZIFFER";

    public static final String INVESTMENT_PROFILE_SIGNED_NAME = "investment profile signed by PH";
    public static final String INVESTMENT_PROFILE_SIGNED_TYPE = "INVESTMENT_PROFILE_SIGNED";

    public static final String INVESTMENT_STRATEGY_SIGNED_NAME = "Investment strategy signed by PH";
    public static final String INVESTMENT_STRATEGY_SIGNED_TYPE = "INVESTMENT_STRATEGY_SIGNED";

    public static final String KYC_SIGNED_NAME = "KYC (SOFD) questionnaire signed by broker";
    public static final String KYC_SIGNED_TYPE = "KYC_SIGNED";

    public static final String INTERNET_RESEARCH_EVIDENCE_NAME = "Internet research evidence";
    public static final String INTERNET_RESEARCH_EVIDENCE_TYPE = "INTERNET_RESEARCH_EVIDENCE";

    public static final String WORLD_CHECK_SCREENING_NAME = "World check screening";
    public static final String WORLD_CHECK_SCREENING_TYPE = "WORLD_CHECK_SCREENING";

    public static final String COPY_POA_NAME =
            "Certified copy of a recent proof of residence (not older than 6 months) of POA/legal representative (on file)";
    public static final String COPY_POA_TYPE = "COPY_POA";

    public static final String COPY_PROOF_RESIDENCE_IB_NAME =
            "Certified proof of residence (not older than 6 months) of Irrevocable BEN (on file)";
    public static final String COPY_PROOF_RESIDENCE_IB_TYPE = "COPY_PROOF_RESIDENCE_IB";

    public static final String CLEAR_ID_IB_NAME = "Clear and certified copy of valid ID of Irrevocable BEN";
    public static final String CLEAR_ID_IB_TYPE = "CLEAR_ID_IB";

    public static final String CLEAR_ID_POA_NAME = "Clear and certified copy of valid ID of POA/legal representative";
    public static final String CLEAR_ID_POA_TYPE = "CLEAR_ID_POA";

    public static final String VERIFICATION_DOCUMENTS_BEN_NAME = "Verification of all documents certification (linked to BEN)";
    public static final String VERIFICATION_DOCUMENTS_BEN_TYPE = "VERIFICATION_DOCUMENTS_BEN";

    public static final String VERIFICATION_DOCUMENTS_CERTIFICATION_AND_POA_NAME =
            "Verification of all documents certification + signed POA document";
    public static final String VERIFICATION_DOCUMENTS_CERTIFICATION_AND_POA_TYPE = "VERIFICATION_DOCUMENTS_CERTIFICATION_AND_POA";

    public static final String PH_TAX_COUNTRY_DIFFERENT_APPLICABLE_LAW_NAME =
            "Policyholder tax country and Country of applicable law are not identical. Please check with WSS";
    public static final String PH_TAX_COUNTRY_DIFFERENT_APPLICABLE_LAW_TYPE = "PH_TAX_COUNTRY_DIFFERENT_APPLICABLE_LAW";

    public static final String ALLOCATION_RATE_TO_AMEND_AND_BEC_MATCHING_NAME =
            "Check if the Allocation rate needs to be amended & if the BEC is matching";
    public static final String ALLOCATION_RATE_TO_AMEND_AND_BEC_MATCHING_TYPE = "ALLOCATION_RATE_TO_AMEND_AND_BEC_MATCHING";

    public static final String VERIFICATION_INVESTMENT_PROFILE_NAME = "Investment profile updated manually in CLASS (profile and date)";
    public static final String VERIFICATION_INVESTMENT_PROFILE_TYPE = "VERIFICATION_INVESTMENT_PROFILE";

    public static final String VERIFICATION_SUSTAINABILITY_PREFERENCE_NAME =
            "ESG sustainability preference updated manually in CLASS (preference and date)";
    public static final String VERIFICATION_SUSTAINABILITY_PREFERENCE_TYPE = "VERIFICATION_SUSTAINABILITY_PREFERENCE";

    public static final String INVESTMENT_PROFILE_REQUESTED_NAME = "Investment profile requested to DIB / LIA agent";
    public static final String INVESTMENT_PROFILE_REQUESTED_TYPE = "INVESTMENT_PROFILE_REQUESTED";

    public static final String SUSTAINABILITY_PREFERENCE_REQUESTED_NAME = "ESG sustainability preference requested to DIB / LIA agent";
    public static final String SUSTAINABILITY_PREFERENCE_REQUESTED_TYPE = "SUSTAINABILITY_PREFERENCE_REQUESTED";

    public static final String NTA_ACCEPTANCE_RECEIVED_NAME = "The NTA acceptance and value have been received";
    public static final String NTA_ACCEPTANCE_RECEIVED_TYPE = "NTA_ACCEPTANCE_RECEIVED";

    public static final String ADDITION_FORM_SIGNED_IB_NAME = "Addition request form signed by Irrevocable BEN";
    public static final String ADDITION_FORM_SIGNED_IB_TYPE = "ADDITION_FORM_SIGNED_IB";

    public static final String WARNING_PRICING_NAME =
            "Warning pricing: there is no need of pricing approval as long as the charging structure remains unchanged and that there is no major change with respect to the current structure (for example NTA assets).";
    public static final String WARNING_PRICING_TYPE = "WARNING_PRICING";

    public static final String EBAC_APPROVAL_COMPLIANCE_NAME = "eBAC approval upon compliance decision";
    public static final String EBAC_APPROVAL_COMPLIANCE_TYPE = "EBAC_APPROVAL_COMPLIANCE";

    public static final String POTENTIAL_CONFLICT_OF_INTEREST_NAME =
            "Potential conflict of interest - please raise an internal STR to the Compliance Function";
    public static final String POTENTIAL_CONFLICT_OF_INTEREST_TYPE = "POTENTIAL_CONFLICT_OF_INTEREST";

    public static final String DOCUMENTATION_ORIGIN_FUND_NAME =
            "Ensure collection of rationale for the discrepancy (and attach it to the case), collection of corroborative documentation on the origin of the additional funds (and attach it to the case) and in case of high risk elements, escalate to the Compliance Function.";
    public static final String DOCUMENTATION_ORIGIN_FUND_TYPE = "DOCUMENTATION_ORIGIN_FUND";

    public static final String BANK_ACCOUNT_EVIDENCE_NAME =
            "The client refused to provide document relative to bank account, please raise an STR to Compliance function";
    public static final String BANK_ACCOUNT_EVIDENCE_TYPE = "BANK_ACCOUNT_EVIDENCE";

    // ONBOARDING
    public static final String DISCLAIMER_DULY_SIGNED_HAS_BEEN_RECEIVED_NAME = "The original Legal disclaimer - duly signed - has been received";
    public static final String DISCLAIMER_DULY_SIGNED_HAS_BEEN_RECEIVED_TYPE = "RISK_SCORE_MANDATORY";

    public static final String PREPARE_THE_CLIENT_USER_ACCESS_IN_SECURE_CONNECT_NAME =
            "Ask BS to prepare the client user access in Secure Connect";
    public static final String PREPARE_THE_CLIENT_USER_ACCESS_IN_SECURE_CONNECT_NAME_TYPE = "VERIFICATION_DOCUMENTS_CERTIFICATION";

    public static final String FORM_LAST_VERSION_RECEIVED_NAME =
            "The application form received is the last updated version (if not, the user should ask to Legal and WSS if we can accept it)";
    public static final String FORM_LAST_VERSION_RECEIVED_TYPE = "VERIFICATION_DOCUMENTS_CERTIFICATION";

    public static final String NO_PROOF_OF_DEREGISTRATION_NAME =
            "Contact partner to receive the proof of deregistration from CH commune.  Escalation to FCC - if No proof of deregistration received";
    public static final String NO_PROOF_OF_DEREGISTRATION_TYPE = "RISK_SCORE_MANDATORY";

    public static final String PH_REFUSE_TO_SIGN_TCC_NAME =
            "The PH/EBO refuse to sign the TCC after several reminders - please raise an internal STR to the Compliance Function";
    public static final String PH_REFUSE_TO_SIGN_TCC_TYPE = "RISK_SCORE_MANDATORY";

    public static final String FOLLOW_UP_CONFIRMATION_NAME = "Follow up of the confirmation that policy was subscribed on PH's behalf";
    public static final String FOLLOW_UP_CONFIRMATION_TYPE = "RISK_SCORE_MANDATORY";

    public static final String BROKER_AUTHORISED_IN_COUNTRY_OF_RESIDENCE_NAME =
            "Broker authorised in country of signature - no permanent establishment risk has been identified";
    public static final String BROKER_AUTHORISED_IN_COUNTRY_OF_RESIDENCE_TYPE = "RISK_SCORE_MANDATORY";

    public static final String BROKER_AUTHORISED_IN_PH_COUNTRY_OF_RESIDENCE_NAME =
            "Broker authorised in PH country of residence - no permanent establishment risk has been identified";
    public static final String BROKER_AUTHORISED_IN_PH_COUNTRY_OF_RESIDENCE_TYPE = "RISK_SCORE_MANDATORY";

    public static final String APPLICATION_FORM_SIGNED_IN_EEA_COUNTRY_NAME =
            "Check that the application form is signed in a EEA country. If not -> Contact WSS";
    public static final String APPLICATION_FORM_SIGNED_IN_EEA_COUNTRY_TYPE = "RISK_SCORE_MANDATORY";

    public static final String NO_THIRD_PARTY_PAYMENT_ALLOWED_NAME = "No 3rd party payment allowed";
    public static final String NO_THIRD_PARTY_PAYMENT_ALLOWED_TYPE = "RISK_SCORE_MANDATORY";

    public static final String CHECK_APPLICATION_FORM_SIGNED_IN_ITALY_NAME =
            "Check that the application form is signed in Italy. If not -> Contact WSS";
    public static final String CHECK_APPLICATION_FORM_SIGNED_IN_ITALY_TYPE = "RISK_SCORE_MANDATORY";

    public static final String SET_CONTRACT_TERM_DATE_IN_CLASS_NAME = "Set the contract term date in CLASS";
    public static final String SET_CONTRACT_TERM_DATE_IN_CLASS_TYPE = "RISK_SCORE_MANDATORY";

    public static final String CLIENT_RISK_SCORE_MANDATORY_IN_CLASS_NAME = "Client risk score is mandatory in CLASS";
    public static final String CLIENT_RISK_SCORE_MANDATORY_IN_CLASS_TYPE = "RISK_SCORE_MANDATORY";

    public static final String SEND_STRATEGY_TO_IM_NAME = "Send the strategy to the investment Manager after control with IC";
    public static final String SEND_STRATEGY_TO_IM_TYPE = "RISK_SCORE_MANDATORY";

    public static final String SIGNED_CONNECT_AGREEMENT_NAME = "Signed Connect agreement";
    public static final String SIGNED_CONNECT_AGREEMENT_TYPE = "RISK_SCORE_MANDATORY";

    public static final String DUAL_COMPLIANT_PRODUCT_NAME = "if US person -> dual compliant product can only be sold (UK, IT and DE client only)";
    public static final String DUAL_COMPLIANT_PRODUCT_TYPE = "RISK_SCORE_MANDATORY";

    public static final String CHECK_FEASIBILITY_WITH_WSS_NAME = "US indicia - Check feasibility with WSS";
    public static final String CHECK_FEASIBILITY_WITH_WSS_TYPE = "RISK_SCORE_MANDATORY";

    public static final String CHECK_KYC_QUESTIONNAIRE_SIGNED_BY_INTRODUCING_PARTNER_NAME =
            "Check that KYC questionnaire is signed by introducing partner";
    public static final String CHECK_KYC_QUESTIONNAIRE_SIGNED_BY_INTRODUCING_PARTNER_TYPE = "RISK_SCORE_MANDATORY";

    public static final String APPLICATION_FORM_SIGNED_BY_IRREVOCABLE_BEN_NAME = "Application form signed by Irrevocable BEN";
    public static final String APPLICATION_FORM_SIGNED_BY_IRREVOCABLE_BEN_TYPE = "RISK_SCORE_MANDATORY";

    public static final String FOLLOW_UMBRELLA_ILF_PROCEDURE_NAME = "Follow Umbrella/ILF procedure";
    public static final String FOLLOW_UMBRELLA_ILF_PROCEDURE_TYPE = "RISK_SCORE_MANDATORY";

    public static final String APPLICATION_FORM_SIGNED_BY_ALL_LA_NAME = "Application form signed by all LA";
    public static final String APPLICATION_FORM_SIGNED_BY_ALL_LA_TYPE = "RISK_SCORE_MANDATORY";

    public static final String WORLDCHECK_AND_RESEARCH_ON_OWNER_NAME =
            "3rd PP - World-check screening and Internet research on the other account owner";
    public static final String WORLDCHECK_AND_RESEARCH_ON_OWNER_TYPE = "OFFICE_IN_STANDARD_COUNTRY";

    public static final String CHECK_WSS_FEASIBILITY_NON_CORE_MARKET_NAME = "Check with WSS feasibility of the contract non core market";
    public static final String CHECK_WSS_FEASIBILITY_NON_CORE_MARKET_TYPE = "ENTITY_PARTNER";

    public static final String SEND_PORTFOLIO_TO_CUSTODIAN_BANK_NAME = "Send the portfolio to the custodian bank";
    public static final String SEND_PORTFOLIO_TO_CUSTODIAN_BANK_TYPE = "ENTITY_PARTNER";

    public static final String NB_NOT_ALLOWED_PERMIT_B_L_C_NAME = "The NB is not allowed even with permit B or L or C";
    public static final String NB_NOT_ALLOWED_PERMIT_B_L_C_TYPE = "RISK_SCORE_MANDATORY";

    public static final String VERIFICATION_ALL_DOCUMENTS_CERTIFICATION_NAME = "Verification of all documents certification";
    public static final String VERIFICATION_ALL_DOCUMENTS_CERTIFICATION_TYPE = "VERIFICATION_DOCUMENTS_CERTIFICATION";

    public static final String VERIFICATION_ALL_DOCUMENTS_CERTIFICATION_PROXY_NAME =
            "Verification of all documents certification + signed Proxy document";
    public static final String VERIFICATION_ALL_DOCUMENTS_CERTIFICATION_PROXY_TYPE = "VERIFICATION_DOCUMENTS_CERTIFICATION";

    public static final String THIRD_PARTY_IN_SWISS_RESIDENT_NAME =
            "If one of the settlor, life assured, beneficiary and any other parties of the life insurance contract is Swiss resident -> Escalation to WSS";
    public static final String THIRD_PARTY_IN_SWISS_RESIDENT_TYPE = "VERIFICATION_DOCUMENTS_CERTIFICATION";

    public static final String CHECK_RDR_COMPLIANT_FORM_NAME = "Check that a RDR compliant application form was completed";
    public static final String CHECK_RDR_COMPLIANT_FORM_TYPE = "VERIFICATION_DOCUMENTS_CERTIFICATION";

    public static final String CONFIRMATION_THAT_ADVICE_PROVIDED_OUTSIDE_UK_NAME =
            "Obtain confirmation from the broker that the advice to the client was provided outside of the UK";
    public static final String CONFIRMATION_THAT_ADVICE_PROVIDED_OUTSIDE_UK_TYPE = "VERIFICATION_DOCUMENTS_CERTIFICATION";

    public static final String APPLICATION_PACK_IN_LINE_WITH_SALESFORCE_NAME =
            "Check pricing in Application Pack is in line with pricing approved in Salesforce";
    public static final String APPLICATION_PACK_IN_LINE_WITH_SALESFORCE_TYPE = "VERIFICATION_DOCUMENTS_CERTIFICATION";

    public static final String APPLICATION_PACK_IN_LINE_WITH_PRICING_NOTE_NAME =
            "Check pricing in Application Pack is in line with pricing approved in Pricing Note (to be attached)";
    public static final String APPLICATION_PACK_IN_LINE_WITH_PRICING_NOTE_TYPE = "VERIFICATION_DOCUMENTS_CERTIFICATION";

    public static final String PRICING_NOTE_FROM_CASE_STRUCTURE_NAME =
            "If Total Amount Invested is greater than 50M then make sure the pricing was approved via pricing note from Case Structuring";
    public static final String PRICING_NOTE_FROM_CASE_STRUCTURE_TYPE = "VERIFICATION_DOCUMENTS_CERTIFICATION";

    public static final String CHECK_FEES_CALCULATION_NAME = "Ensure alignment with IMA and CLASS fee calculation method";
    public static final String CHECK_FEES_CALCULATION_TYPE = "CHECK_FEES_CALCULATION";

    public static final String CHECK_ACCOUNT_OPEN_NAME = "Account correctly set-up in class and communicated to Partner / Sales";
    public static final String CHECK_ACCOUNT_OPEN_TYPE = "CHECK_ACCOUNT_OPEN";

    public static final String EEA_DECLARATION_RECEIVED_NAME = "Non EEA declaration received";
    public static final String EEA_DECLARATION_RECEIVED_TYPE = "EEA_DECLARATION_RECEIVED";

    public static final String ANALYSIS_NEEDS_RECEIVED_SIGNED_NAME = "Analysis of Demands and needs / Fact Find received and signed by agent";
    public static final String ANALYSIS_NEEDS_RECEIVED_SIGNED_TYPE = "ANALYSIS_NEEDS_RECEIVED_SIGNED";

    public static final String CONSENT_EMAIL_REQUESTED_NAME = "Consent email requested to Sales";
    public static final String CONSENT_EMAIL_REQUESTED_TYPE = "CONSENT_EMAIL_REQUESTED";

    public static final String VIDEO_RECORDING_RECEIVED_NAME = "Video recording received";
    public static final String VIDEO_RECORDING_RECEIVED_TYPE = "VIDEO_RECORDING_RECEIVED";

    public static final String NEW_VIDEO_OR_EXCEPTION_PROVIDED_NAME = "New video or exception provided";
    public static final String NEW_VIDEO_OR_EXCEPTION_PROVIDED_TYPE = "NEW_VIDEO_OR_EXCEPTION_PROVIDED";

    public static final String HASH_CHECK_PERFORMED_NAME = "Hash tool check performed";
    public static final String HASH_CHECK_PERFORMED_TYPE = "HASH_CHECK_PERFORMED";

    public static final String PASSPORT_CHECKS_PERFORMED_NAME = "Additional passport checks performed";
    public static final String PASSPORT_CHECKS_PERFORMED_TYPE = "PASSPORT_CHECKS_PERFORMED";

    public static final String ESCALATED_TO_MANAGER_NAME = "Validation of Head of Sales received, case escalated to Vulnerable Champion";
    public static final String ESCALATED_TO_MANAGER_TYPE = "ESCALATED_TO_MANAGER";

    public static final String PRICING_APPROVAL_RECEIVED_NAME = "Approval on pricing received from Sales Coordination";
    public static final String PRICING_APPROVAL_RECEIVED_TYPE = "PRICING_APPROVAL_RECEIVED";

    public static final String BROKER_AUTHORISED_TO_INTERMEDIATE_NAME =
            "Check with C&R if the broker is authorised to intermediate the case prior to policy issuance";
    public static final String BROKER_AUTHORISED_TO_INTERMEDIATE_TYPE = "BROKER_AUTHORISED_TO_INTERMEDIATE";

    public static final String CLASS_SETUP_IN_LINE_WITH_PRICING_APPROVAL_NAME = "Setup done in CLASS in line with the pricing approval";
    public static final String CLASS_SETUP_IN_LINE_WITH_PRICING_APPROVAL_TYPE = "CLASS_SETUP_IN_LINE_WITH_PRICING_APPROVAL";

    public static final String ESG_MANDATE_DOCUMENTATION_PROVIDED_NAME = "Art. 8/9 ESG mandate pre-contractual documentation provided";
    public static final String ESG_MANDATE_DOCUMENTATION_PROVIDED_TYPE = "ESG_MANDATE_DOCUMENTATION_PROVIDED";

    public static final String BLOCK_ON_TERMFIX_POLICY_NAME = "Setup a block on the TermFix policy if both Date and Condition exist";
    public static final String BLOCK_ON_TERMFIX_POLICY_TYPE = "BLOCK_ON_TERMFIX_POLICY";

    public static final String AUTHORISED_INVESTMENT_LA_NAME = "Board resolution authorising investment into a life insurance policy";
    public static final String AUTHORISED_INVESTMENT_LA_TYPE = "AUTHORISED_INVESTMENT_LA";

    public static final String FIDUCIARY_MANDATE_NBD_NAME = "Fiduciary mandate";
    public static final String FIDUCIARY_MANDATE_NBD_TYPE = "FIDUCIARY_MANDATE_NBD";

    public static final String TRUSTEE_INVEST_IN_LA_NAME = "A Trustee declaration authorising investment into a life insurance policy";
    public static final String TRUSTEE_INVEST_IN_LA_TYPE = "TRUSTEE_INVEST_IN_LA";

    public static final String FATCA_FORM_REFUSED_NAME =
            "If the PH/EBO refuse to sign the FATCA/CRS/AEOI forms after several reminders - please raise an internal STR to the Compliance Function";
    public static final String FATCA_FORM_REFUSED_TYPE = "FATCA_FORM_REFUSED";

    public static final String FATCA_FORM_INCONSISTENT_NAME =
            "Inconsistency between FATCA/CRS info and AML/KYC info without any legitimate reason - please raise an internal STR to the Compliance Function";
    public static final String FATCA_FORM_INCONSISTENT_TYPE = "FATCA_FORM_INCONSISTENT";

    public static final String TAX_RESIDENCE_NO_LEGITIMATE_REASON_NAME =
            "Inconsistency on tax residence without any legitimate reason - please raise an internal STR to the Compliance Function";
    public static final String TAX_RESIDENCE_NO_LEGITIMATE_REASON_TYPE = "TAX_RESIDENCE_NO_LEGITIMATE_REASON";

    public static final String REVERT_BACK_TO_COLLECT_REASON_NAME =
            "Revert back to the partner to collect the reason for this discrepancy (and attach it to the case)-  If the reason does not make sense, please raise an internal STR to the Compliance Function";
    public static final String REVERT_BACK_TO_COLLECT_REASON_TYPE = "REVERT_BACK_TO_COLLECT_REASON";

    public static final String CONFLICT_OF_INTEREST_NAME =
            "Potential conflict of interest - please raise an internal STR to the Compliance Function";
    public static final String CONFLICT_OF_INTEREST_TYPE = "CONFLICT_OF_INTEREST";

    public static final String ENSURE_COLLECTION_OF_RATIONALE_NAME =
            "Ensure collection of rationale for the discrepancy (and attach it to the case), collection of corroborative documentation on the origin of funds/the additional funds (and attach it to the case) and in case of high risk elements, escalate to the Compliance Function.";
    public static final String ENSURE_COLLECTION_OF_RATIONALE_TYPE = "ENSURE_COLLECTION_OF_RATIONALE";

    public static final String COLLECT_WRITTEN_RATIONALE_NAME =
            "Please collect written rationale (and attach it to the case) and ensure that payment details have not changed as disclosed in the KYC form";
    public static final String COLLECT_WRITTEN_RATIONALE_TYPE = "COLLECT_WRITTEN_RATIONALE";

    public static final String COLLECT_RATIONALE_ALTERED_DOCUMENTS_NAME =
            "Please collect rationale from the partner why the KYC documents are altered or inconsistent (and attach it to the case). In case of suspicion, please raise an STR to Compliance function";
    public static final String COLLECT_RATIONALE_ALTERED_DOCUMENTS_TYPE = "COLLECT_RATIONALE_ALTERED_DOCUMENTS";

    public static final String COLLECT_RATIONALE_TO_AUTHORISE_PH_NAME =
            "Ensure collection of a rationale and documentary evidence allowing to verify that the PH is authorised to act on behalf of the EBO.";
    public static final String COLLECT_RATIONALE_TO_AUTHORISE_PH_TYPE = "COLLECT_RATIONALE_TO_AUTHORISE_PH";

    public static final String CLIENT_REFUSED_PROVIDING_DOCUMENTS_NAME =
            "The client refused to provide document relative to bank account, please raise an STR to Compliance function";
    public static final String CLIENT_REFUSED_PROVIDING_DOCUMENTS_TYPE = "CLIENT_REFUSED_PROVIDING_DOCUMENTS";

    public static final String SYNCHRONIZED_CLASS_BEFORE_DATA_COMPLETION_NAME =
            "Verify synchronization with latest CLASS data before completion : please Regenerate & Save in the Overview tab, control escalation rules triggered then check pending Tasks tab)";
    public static final String SYNCHRONIZED_CLASS_BEFORE_DATA_COMPLETION_TYPE = "VERIFICATION_DATA_SYNCHRONIZATION_BEFORE_COMPLETION";
    public static final String CLIENT_IDENTIFICATION_ON_FILE_NAME =
            "Evidence relative to Client identification on file – If not please attach it to the case";
    public static final String CLIENT_IDENTIFICATION_ON_FILE_TYPE = "CLIENT_IDENTIFICATION_EVIDENCE";
    public static final String ORIGINAL_SIGNED_DOCUMENT_NAME = "Original Signed Document + Audit Log in CMT";
    public static final String ORIGINAL_SIGNED_DOCUMENT_TYPE = "ORIGINAL_DOCUMENT_AUDIT";

    public static final String EBAC_APPROVAL_UNQUOTED_NAME = "eBAC approval for unquoted reason";
    public static final String EBAC_APPROVAL_UNQUOTED_TYPE = "EBAC_APPROVAL_UNQUOTED";
}
