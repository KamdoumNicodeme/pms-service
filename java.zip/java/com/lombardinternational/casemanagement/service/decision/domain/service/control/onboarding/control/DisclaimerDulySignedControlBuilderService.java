package com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control;

import org.springframework.stereotype.Service;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ControlDefinition;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.AbstractControlBuilderService;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ControlConstants.*;

@Service
public class DisclaimerDulySignedControlBuilderService extends AbstractControlBuilderService {

    @Override
    public ControlDefinition buildControl(final WebForm webForm, final ScreenDescription screenDescription) {

        return buildControlDefinition();
    }

    @Override
    protected String getControlName() {

        return DISCLAIMER_DULY_SIGNED_HAS_BEEN_RECEIVED_NAME;
    }

    @Override
    protected String getControlType() {

        return DISCLAIMER_DULY_SIGNED_HAS_BEEN_RECEIVED_TYPE;
    }
}
