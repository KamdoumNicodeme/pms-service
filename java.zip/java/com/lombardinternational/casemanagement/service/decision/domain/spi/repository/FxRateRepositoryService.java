package com.lombardinternational.casemanagement.service.decision.domain.spi.repository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import com.lombardinternational.casemanagement.service.decision.domain.model.FxRate;

public interface FxRateRepositoryService {

    List<FxRate> getFxRateByFxRateDate(LocalDate date);

    void save(FxRate fxRate);

    Optional<LocalDate> getMaxFxRateDate();

    void deleteOldFXRatesRecords();

    void saveOrUpdateIfNewer(FxRate newRate);
}
