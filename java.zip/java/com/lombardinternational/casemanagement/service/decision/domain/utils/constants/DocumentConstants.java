package com.lombardinternational.casemanagement.service.decision.domain.utils.constants;

import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor(access = AccessLevel.PRIVATE)
public final class DocumentConstants {

    public static final String APPLICATION_FORM_DOC_TYPE = "APPLICATION_FORM";
    public static final String APPLICATION_FORM_CMS_DOC_TYPE = "Application form";
    public static final String INVESTMENT_STRATEGY_DOC_TYPE = "INVESTMENT_STRATEGY";
    public static final String INVESTMENT_STRATEGY_CMS_DOC_TYPE = "Investment Strategy";
    public static final String AGREEMENT_FORM_DOC_TYPE = "AGREEMENT";
    public static final String AGREEMENT_FORM_CMS_DOC_TYPE = "E-lia Legal Agreement";
    public static final String REASON_WHY_LET_DOC_TYPE = "REASON_WHY_LET";
    public static final String REASON_WHY_LET_CMS_DOC_TYPE = "Reason why letter";
    public static final String AEOI_FORM_DOC_TYPE = "AEOI";
    public static final String AEOI_FORM_CMS_DOC_TYPE = "AEoI";
    public static final String PAYMENT_DETAILS_DOC_TYPE = "PAYMENT_DETAILS";
    public static final String PAYMENT_DETAILS_CMS_DOC_TYPE = "Premium";
    public static final String TP_DOCS_DOC_TYPE = "TP_DOCS";
    public static final String TP_DOCS_CMS_DOC_TYPE = "3rd party docs";
    public static final String BANK_LETTER_DOC_TYPE = "BANK_LETTER";
    public static final String BANK_LETTER_CMS_DOC_TYPE = "Bank reference letter";
    public static final String TRANSACTION_DOCUMENT_DOC_TYPE = "TRANSACTION_DOCUMENT";
    public static final String TRANSACTION_DOCUMENT_CMS_DOC_TYPE = "Other documents";
    public static final String KYC_DOCUMENT_DOC_TYPE = "KYC_DOCUMENT";
    public static final String KYC_DOCUMENT_CMS_DOC_TYPE = "KYC Document";
    public static final String MEDICAL_DOCUMENT_DOC_TYPE = "MEDICAL_DOCUMENT";
    public static final String MEDICAL_DOCUMENT_CMS_DOC_TYPE = "Medical underwritings and related documentation";
    public static final String CHARGING_STRUCTURE_CMS_DOC_TYPE = "Charging structure";
    public static final String SUITABILITY_PROFILE_CMS_DOC_TYPE = "Suitability Profile";
    public static final String ANNEX_DOC_TYPE = "ANNEX";
    public static final String ANNEX_CMS_DOC_TYPE = "Annexe";
    public static final String TAX_COMPLIANCE_CERTIFICATE_CMS_DOC_TYPE = "Tax compliance certificate";
    public static final String SOFD_CMS_DOC_TYPE = "SOFD";
    public static final String EMAIL_DOC_TYPE = "EMAIL";
    public static final String EMAIL_CMS_DOC_TYPE = "Email";
    public static final String PROOF_RESIDENCE_DOC_TYPE = "PROOF_RESIDENCE";
    public static final String PROOF_RESIDENCE_CMS_DOC_TYPE = "Proof of Residence";
    public static final String FIF_FORM_DESCRIPTION = "FIF form";
    public static final String FIF_FORM_I18N_DESCRIPTION = "fif_form";
    public static final String ADDITIONAL_INVESTMENT_FORM_DESCRIPTION = "Additional investment form signed by the PH(s)";
    public static final String ADDITIONAL_INVESTMENT_FORM_I18N_DESCRIPTION = "invest_form_signed_ph";
    public static final String RECEIVED_CHOICE_OF_LAW_FORM_DESCRIPTION = "Received choice of law with premium tax notice";
    public static final String RECEIVED_CHOICE_OF_LAW_FORM_I18N_DESCRIPTION = "choice_of_law";
    public static final String SIGNED_CONNECT_AGREEMENT_FORM_DESCRIPTION = "Signed Connect agreement";
    public static final String SIGNED_CONNECT_AGREEMENT_FORM_I18N_DESCRIPTION = "signed_connect_agreement";
    public static final String W8BEN_FATCA_FORM_CMT_RELATED_TO_PREFIX_DESCRIPTION = "W8BEN form and list US indicia or W9 + FATCA reporting";
    public static final String W8BEN_FATCA_FORM_DESCRIPTION =
            "W8BEN form and list US indicia or W9 + FATCA reporting (if US person residing outside US confirmed / payment to be received outside USA)";
    public static final String W8BEN_FATCA_FORM_I18N_DESCRIPTION = "w8ben_form";
    public static final String W8BEN_FATCA_2_FORM_CMT_RELATED_TO_PREFIX_DESCRIPTION = "W8BEN form and list US indicia or W9 + FATCA reporting";
    public static final String W8BEN_FATCA_2_FORM_DESCRIPTION =
            "W8BEN form and list US indicia or W9 + FATCA reporting (if US person residing outside US confirmed / payment to be received outside USA) or W9 + FATCA reporting (if US person residing outside US confirmed / payment to be received outside USA)";
    public static final String W8BEN_FATCA_2_FORM_I18N_DESCRIPTION = "w8ben_form";
    public static final String THIRD_PARTY_PAYMENT_FORM_CMT_RELATED_TO_PREFIX_DESCRIPTION = "3rd party - Payment form";
    public static final String THIRD_PARTY_PAYMENT_FORM_DESCRIPTION = "3rd PP - 3rd party payment form";
    public static final String THIRD_PARTY_PAYMENT_FORM_I18N_DESCRIPTION = "payment_form_third_party";
    public static final String CLIENT_I18N_DOCUMENT_RELATED_TO = "client";
    public static final String EBO_I18N_DOCUMENT_RELATED_TO = "ebo";
    public static final String FUND_I18N_DOCUMENT_RELATED_TO = "fund";
    public static final String TP_ENTITY_CONSTITUTIONAL_FORM_CMT_RELATED_TO_PREFIX_DESCRIPTION = "3rd party - Entity constitutional documents";
    public static final String TP_ENTITY_CONSTITUTIONAL_FORM_DESCRIPTION =
            "3rd PP - Constitutional documents of the entity (eg. statutes/trust deed - shareholder register…)";
    public static final String TP_ENTITY_CONSTITUTIONAL_FORM_I18N_DESCRIPTION = "constitutional_documents_third_party";
    public static final String TP_LINK_PROVIDED_BY_NOTARY_FORM_CMT_RELATED_TO_PREFIX_DESCRIPTION =
            "3rd party - Link with the PH provided by the notary";
    public static final String TP_LINK_PROVIDED_BY_NOTARY_FORM_DESCRIPTION =
            "Documentary evidence of a clear rationale and link with the policyholder provided by the notary/solicitor (popy of sale agreement for a property - copy of settlement agreement for liability claim...) plus the payment must be made with reference to the policyholder's name";
    public static final String TP_THIRD_PARTY_LINK_PROVIDED_BY_NOTARY_FORM_I18N_DESCRIPTION = "link_with_PH_third_party_notary";
    public static final String TP_FAMILY_LINK_FORM_CMT_RELATED_TO_PREFIX_DESCRIPTION = "3rd party - Letter from partner confirming family link";
    public static final String TP_FAMILY_LINK_FORM_DESCRIPTION =
            "Family link (letter from regulated intermediary / referrer confirming family link between the policyholder and the third party - birth certificate evidencing family link)";
    public static final String TP_FAMILY_LINK_FORM_I18N_DESCRIPTION = "family_link";
    public static final String TP_PROOF_CONTRACTUAL_RELATIONSHIP_FORM_CMT_RELATED_TO_PREFIX_DESCRIPTION =
            "3rd party - Proof of contractual relationship";
    public static final String TP_PROOF_CONTRACTUAL_RELATIONSHIP_FORM_DESCRIPTION =
            "3rd PP - Proof of contractual relationship between PH and money Transfer Company";
    public static final String TP_PROOF_CONTRACTUAL_RELATIONSHIP_FORM_I18N_DESCRIPTION = "proof_of_relationship_third_party";
    public static final String TP_PROOF_OWNERSHIP_ENTITY_PH_FORM_DESCRIPTION =
            "Proof of ownership evidencing the link between the corporate entity and the PH/EBO";
    public static final String TP_PROOF_OWNERSHIP_ENTITY_PH_FORM_I18N_DESCRIPTION = "proof_of_ownership_ph_corporate_entity";
    public static final String TP_PROOF_CONTRACT_INSTITUTION_FORM_CMT_RELATED_TO_PREFIX_DESCRIPTION =
            "3rd party - Valid proof of contract with relevant institution";
    public static final String TP_PROOF_CONTRACT_INSTITUTION_FORM_DESCRIPTION = """
            3rd PP - Valid proof of contract with relevant institution such as a:
            - Copy of policy schedule / contract / or
            - Copy of the instruction from the policyholder (signed and dated) to the financial institution to withdraw/surrender and pay
            """;
    public static final String TP_PROOF_CONTRACT_INSTITUTION_FORM_I18N_DESCRIPTION = "proof_of_contract_with_institution";
    public static final String ACCEPTABLE_BANK_REFERENCE_FORM_DESCRIPTION = "Acceptable bank reference letter";
    public static final String ACCEPTABLE_BANK_REFERENCE_FORM_I18N_DESCRIPTION = "bank_reference_letter";
    public static final String BERATUNGSPROTOKOLL_FORM_DESCRIPTION = "Beratungsprotokoll";
    public static final String BERATUNGSPROTOKOLL_FORM_I18N_DESCRIPTION = "beratungsprotokoll";
    public static final String DISPOSIZION_PRODOTTI_FINANZIARI_FORM_DESCRIPTION = "Disposizione relativa ai prodotti finanziari (UCI)";
    public static final String DISPOSIZION_PRODOTTI_FINANZIARI_FORM_I18N_DESCRIPTION = "disposizione_prodotti_finanziari";
    public static final String EMAIL_UNCHANGED_KYC_FORM_DESCRIPTION =
            "email from partner unchanged KYC questionnaire or new KYC questionnaire (sign by partner or bank reference letter)";
    public static final String EMAIL_UNCHANGED_KYC_FORM_I18N_DESCRIPTION = "email_from_partner_kyc";
    public static final String REASON_KYC_NOT_SIGNED_FORM_DESCRIPTION =
            "Provide reason why KYC questionnaire not signed by introducing partner or bank reference letter";
    public static final String REASON_KYC_NOT_SIGNED_FORM_I18N_DESCRIPTION = "reason_kyc_not_signed";
    public static final String QUESTIONARIO_ADEGUATEZZA_FORM_DESCRIPTION = "Questionario Adeguatezza";
    public static final String QUESTIONARIO_ADEGUATEZZA_FORM_I18N_DESCRIPTION = "questionario_adeguatezza";
    public static final String SIGNED_SCHEDULE_CHARGES_FORM_DESCRIPTION = "Schedule of charges fully detailed and signed by all PHs";
    public static final String SIGNED_SCHEDULE_CHARGES_FORM_I18N_DESCRIPTION = "schedule_of_charges";
    public static final String SIGNED_SUITABILITY_PROFILE_FORM_DESCRIPTION = "Suitability profile signed by PH/EBO and intermediary";
    public static final String SIGNED_SUITABILITY_PROFILE_FORM_I18N_DESCRIPTION = "suitability_profile";
    public static final String ADDITIONAL_MEDICAL_QUESTIONNAIRE_FORM_DESCRIPTION = "UW - Additional medical questionnaire";
    public static final String ADDITIONAL_MEDICAL_QUESTIONNAIRE_FORM_I18N_DESCRIPTION = "uw_additional_medical_questionnaire";
    public static final String MEDICAL_EXAMINATION_REPORT_FORM_DESCRIPTION = "UW - Medical examination report";
    public static final String MEDICAL_EXAMINATION_REPORT_FORM_I18N_DESCRIPTION = "uw_medical_examination_report";
    public static final String URIN_ANALYSIS_FORM_DESCRIPTION = "UW - Urinalysis";
    public static final String URIN_ANALYSIS_FORM_I18N_DESCRIPTION = "uw_urinalysis";
    public static final String RESTING_EXERCISE_ECG_FORM_DESCRIPTION = "UW - Resting and Exercise ECG";
    public static final String RESTING_EXERCISE_ECG_FORM_I18N_DESCRIPTION = "uw_ecg";
    public static final String HIV_TEST_FORM_DESCRIPTION = "UW - HIV test";
    public static final String HIV_TEST_FORM_I18N_DESCRIPTION = "uw_hiv_test";
    public static final String BLOOD_TEST_FORM_DESCRIPTION = """
                UW - Blood tests
                (Full blood count incl. Blood sedimentation rate +
                Cholesterol - HDL - LDL - Triglycerides +
                GOT - GPT - Gamma-GT - Bilirubin +
                Uric acid - Urea - Creatinine +
                Fasting blood sugar +
                HbA1c +
                Hepatitis B and Heptitis C Serology plus Alpha-Fetoprotein (AFP) +
                Above 50 years of age - Prostate specific Antigen (PSA) for male
            """;
    public static final String BLOOD_TEST_FORM_CMT_RELATED_TO_PREFIX_DESCRIPTION = "UW - Blood tests";
    public static final String BLOOD_TEST_FORM_I18N_DESCRIPTION = "uw_full_blood";
    public static final String CARDIAC_ECHO_FORM_DESCRIPTION = "UW - Cardiac Echo";
    public static final String CARDIAC_ECHO_FORM_I18N_DESCRIPTION = "uw_cardiac_echo";
    public static final String ABDOMINAL_SONOGRAM_FORM_DESCRIPTION =
            "UW - Abdominal sonogram (liver - gallbladder with bile duets - spleen - pancreas - kidneys (including renal pelvis and ureter) - aorta and vena cava)";
    public static final String ABDOMINAL_SONOGRAM_FORM_CMT_RELATED_TO_PREFIX_DESCRIPTION = "UW - Abdominal sonogram";
    public static final String ABDOMINAL_SONOGRAM_FORM_I18N_DESCRIPTION = "uw_abdominal_sonogram";
    public static final String PELVIC_ULTRA_SOUND_FORM_DESCRIPTION =
            "UW - Pelvic ultrasound (include automatically organs such as bladder - ovaries - uterus - prostate)";
    public static final String PELVIC_ULTRA_SOUND_FORM_CMT_RELATED_TO_PREFIX_DESCRIPTION = "UW - Pelvic ultrasound";
    public static final String PELVIC_ULTRA_SOUND_FORM_I18N_DESCRIPTION = "uw_pelvic_ultrasound";
    public static final String FINANCIAL_UNDERWRITING_FORM_DESCRIPTION = "UW - Financial Underwriting";
    public static final String FINANCIAL_UNDERWRITING_FORM_I18N_DESCRIPTION = "uw_financial_underwriting";
    public static final String EXCEL_TEMPLATE_SAR_CALCULATION_FORM_DESCRIPTION = "Excel template of manual SAR calculation";
    public static final String EXCEL_TEMPLATE_SAR_CALCULATION_FORM_I18N_DESCRIPTION = "template_manual_sar_calculation";
    public static final String TAX_COMPLIANCE_CERTIFICATION_EBO_FORM_DESCRIPTION = "Tax compliance certification to be signed by EBO";
    public static final String TAX_COMPLIANCE_CERTIFICATION_EBO_FORM_I18N_DESCRIPTION = "tax_compliance_certification";
    public static final String DESCRIPTION_NEGATIVE_FINDING_FORM_DESCRIPTION = "Description of negative finding / World check match evidence";
    public static final String DESCRIPTION_NEGATIVE_FINDING_FORM_I18N_DESCRIPTION = "description_negative_finding";
    public static final String EXPLANATION_PROFESSION_CLASSIFICATION_FORM_DESCRIPTION = "Explanation about medium profession classification";
    public static final String EXPLANATION_PROFESSION_CLASSIFICATION_FORM_I18N_DESCRIPTION = "explanation_profession_classification";
    public static final String DIFFERENCES_PREVIOUS_KYC_FORM_DESCRIPTION = "Justify differences with previous KYC questionnaire";
    public static final String DIFFERENCES_PREVIOUS_KYC_FORM_I18N_DESCRIPTION = "differences_previous_kyc";
    public static final String JUSTIFICATION_WEALTH_ORIGIN_FORM_DESCRIPTION = "List of action taken to justify origin of wealth";
    public static final String JUSTIFICATION_WEALTH_ORIGIN_FORM_I18N_DESCRIPTION = "justification_wealth_origin";
    public static final String REASON_KYC_NOT_OBTAINED_FORM_DESCRIPTION =
            "Provide reason why new KYC questionnaire not obtained (except if below 100000€/20% of initial premium) and partner to confirm unchanged source of wealth";
    public static final String REASON_KYC_NOT_OBTAINED_FORM_CMT_RELATED_TO_PREFIX_DESCRIPTION =
            "Provide reason why new KYC questionnaire not obtained";
    public static final String REASON_KYC_NOT_OBTAINED_FORM_I18N_DESCRIPTION = "reason_kyc_not_obtained";
    public static final String SCREENING_EVIDENCE_ORIGIN_OF_WEALTH_FORM_DESCRIPTION =
            "Screening evidence or List of action taken to justify origin of wealth";
    public static final String SCREENING_EVIDENCE_ORIGIN_OF_WEALTH_FORM_I18N_DESCRIPTION = "screening_evidence_origin_of_wealth";
    public static final String NTA_VALIDATION_EMAIL_FORM_DESCRIPTION = "NTA Validation - email";
    public static final String NTA_VALIDATION_EMAIL_FORM_I18N_DESCRIPTION = "nta_validation_email";
    public static final String AEOI_SELF_CERTIFICATION_FORM_DESCRIPTION = "AEOI Self Certificate";
    public static final String AEOI_SELF_CERTIFICATION_FORM_I18N_DESCRIPTION = "aeoi_self_certification";
    public static final String PH_PROOF_OF_RESIDENCE_AMENDED_ADDRESS_FORM_DESCRIPTION = "PH Proof of residence for address amended (not older than 6 months)";
    public static final String PH_PROOF_OF_RESIDENCE_AMENDED_ADDRESS_FORM_I18N_DESCRIPTION = "ph_proof_of_residence_amended_address";
    public static final String ID_DESCRIPTION = "Valid ID";
    public static final String ID_I18N_DESCRIPTION = "id";
    public static final String PREMIUM_ASSET_PORTFOLIO_FORM_DESCRIPTION = "Portfolio";
    public static final String PREMIUM_ASSET_PORTFOLIO_FORM_I18N_DESCRIPTION = "portfolio";
    public static final String AUTHORISED_SIGNATORIES_FORM_DESCRIPTION = "Authorised signatory list";
    public static final String AUTHORISED_SIGNATORIES_FORM_I18N_DESCRIPTION = "authorised_signatory_list";
    public static final String FACT_FIND_FORM_DESCRIPTION = "Fact Find";
    public static final String FACT_FIND_FORM_I18N_DESCRIPTION = "fact_find";
    public static final String COPY_PAY_SLIP_FORM_DESCRIPTION = "Copie d'une feuille récente de salaire";
    public static final String COPY_PAY_SLIP_FORM_I18N_DESCRIPTION = "copy_pay_slip";
    public static final String COPY_LATEST_TAX_RETURN_FORM_DESCRIPTION =
            "Copie récente des comptes et/ou copie de la dernière déclaration de revenus";
    public static final String COPY_LATEST_TAX_RETURN_FORM_I18N_DESCRIPTION = "copy_latest_tax_return";
    public static final String COPY_EXCEPTIONAL_REMUNERATION_SHEET_FORM_DESCRIPTION = "Copie de la feuille de rémunération exceptionnelle";
    public static final String COPY_EXCEPTIONAL_REMUNERATION_SHEET_FORM_I18N_DESCRIPTION = "copy_exceptional_remuneration_sheet";
    public static final String COPY_EMPLOYMENT_CONTRACT_FORM_DESCRIPTION = "Copie du contrat d'emploi";
    public static final String COPY_EMPLOYMENT_CONTRACT_FORM_I18N_DESCRIPTION = "copy_employment_contract";
    public static final String DEED_OF_SALES_SIGNED_FORM_DESCRIPTION =
            "Acte de vente signé par toutes les parties prenantes et l'éventuel notaire mentionnant le prix de vente";
    public static final String DEED_OF_SALES_SIGNED_FORM_I18N_DESCRIPTION = "deed_of_sales_signed";
    public static final String PROOF_OF_PAYMENT_FORM_DESCRIPTION = "Preuve du paiement (date, montant et compte crédité)";
    public static final String PROOF_OF_PAYMENT_FORM_I18N_DESCRIPTION = "proof_of_payment";
    public static final String INVESTMENT_SOLD_NAME_FORM_DESCRIPTION =
            "Le nom des investissements vendus, la date à laquelle ils ont été vendus et leur valeur";
    public static final String INVESTMENT_SOLD_NAME_FORM_I18N_DESCRIPTION = "investment_sold_name";
    public static final String COPY_ASSET_PORTFOLIO_FORM_DESCRIPTION = "Copie des portefeuilles d'actif";
    public static final String COPY_ASSET_PORTFOLIO_FORM_I18N_DESCRIPTION = "copy_asset_portfolio";
    public static final String CERTIFICATE_OF_OWNERSHIP_FORM_DESCRIPTION =
            "Certificat de propriété du bien vendu faisant apparaitre la nature du bien.";
    public static final String CERTIFICATE_OF_OWNERSHIP_FORM_I18N_DESCRIPTION = "certificate_of_ownership";
    public static final String DEED_OF_SALE_FORM_DESCRIPTION =
            "Acte de vente reprenant le nom des parties prenantes (vendeurs et acheteurs) et du Notaire instrumentant, l'identification du bien, le prix de vente et la date";
    public static final String DEED_OF_SALE_FORM_I18N_DESCRIPTION = "deed_of_sale";
    public static final String COPY_DEED_OF_SALE_FORM_DESCRIPTION =
            "Copie de l'acte de vente signé par les parties mentionnant le nom de la société, des acheteurs, le nombre de parts vendues, la date et le prix";
    public static final String COPY_DEED_OF_SALE_FORM_I18N_DESCRIPTION = "copy_deed_of_sale";
    public static final String FINANCIAL_STATEMENTS_FORM_DESCRIPTION = "Comptes sociaux de l'année N-1";
    public static final String FINANCIAL_STATEMENTS_FORM_I18N_DESCRIPTION = "financial_statements";
    public static final String COPY_LEGAL_PUBLICATIONS_FORM_DESCRIPTION = "Copie des publications légales";
    public static final String COPY_LEGAL_PUBLICATIONS_FORM_I18N_DESCRIPTION = "copy_legal_publications";
    public static final String NOTARISED_DEED_OF_SUCCESSION_FORM_DESCRIPTION =
            "Acte notarié de succession/legs reprenant l'identité du défunt, la dateet le lieu du décès, la date de succession/legs, l'identité des héritiers ou légataires, le montant de la succession et le montant à justifier.";
    public static final String NOTARISED_DEED_OF_SUCCESSION_FORM_I18N_DESCRIPTION = "notarised_deed_of_succession";
    public static final String LETTER_IDENTIFYING_RECIPIENT_FORM_DESCRIPTION =
            "Lettre du donateur identifiant le donataire, la date et le montant du don ainsi que la preuve du versement des sommes";
    public static final String LETTER_IDENTIFYING_RECIPIENT_FORM_I18N_DESCRIPTION = "letter_identifying_recipient";
    public static final String NOTARISED_DEED_FORM_DESCRIPTION = "Acte notarié en cas de donation faite devant notaire";
    public static final String NOTARISED_DEED_FORM_I18N_DESCRIPTION = "notarised_deed";
    public static final String DIVORCE_CERTIFICATE_FORM_DESCRIPTION = "Acte de divorce";
    public static final String DIVORCE_CERTIFICATE_FORM_I18N_DESCRIPTION = "divorce_certificate";
    public static final String CONFIRMATION_LETTER_GAMBLING_FORM_DESCRIPTION = "Lettre de confirmation de l'organisateur ";
    public static final String CONFIRMATION_LETTER_GAMBLING_FORM_I18N_DESCRIPTION = "confirmation_letter_gambling";
    public static final String COPY_OF_CHEQUE_GAMBLING_FORM_DESCRIPTION = "Copie du chèque reprenant le nom du gagnant et le montant";
    public static final String COPY_OF_CHEQUE_GAMBLING_FORM_I18N_DESCRIPTION = "copy_of_cheque_gambling";
    public static final String DEED_OF_TRANSFER_OF_SHARES_FORM_DESCRIPTION = "Acte de cession de parts sociales daté et signé";
    public static final String DEED_OF_TRANSFER_OF_SHARES_FORM_I18N_DESCRIPTION = "deed_of_transfer_of_shares";
    public static final String BANK_STATEMENT_ENTITY_FORM_DESCRIPTION =
            "Extrait du compte bancaire du souscripteur faisant apparaitre le paiement recu avec le nom du cessionnaire";
    public static final String BANK_STATEMENT_ENTITY_FORM_I18N_DESCRIPTION = "bank_statement_entity";
    public static final String AGM_MINUTES_FORM_DESCRIPTION = "Procès verbal de l'AG daté et signé avec décision de dstribution des dividendes";
    public static final String AGM_MINUTES_FORM_I18N_DESCRIPTION = "agm_minutes";
    public static final String COMPANY_IDENTIFICATION_LESS_THAN_3_MONTHS_FORM_DESCRIPTION =
            "Identification de la société (RCS daté de moins de 3m)";
    public static final String COMPANY_IDENTIFICATION_LESS_THAN_3_MONTHS_FORM_I18N_DESCRIPTION = "company_identification_less_than_3_months";
    public static final String EXTRACT_SUBSCRIBER_BANK_ACCOUNT_FORM_DESCRIPTION =
            "Extrait du compte bancaire du souscripteur faisant apparaittre l'attribution du dividende";
    public static final String EXTRACT_SUBSCRIBER_BANK_ACCOUNT_FORM_I18N_DESCRIPTION = "extract_subscriber_bank_account";
    public static final String COMPANY_ACCOUNTS_DIVIDEND_FORM_DESCRIPTION = "Comptes sociaux (si le premier tiers n'est pas disponible)";
    public static final String COMPANY_ACCOUNTS_DIVIDEND_FORM_I18N_DESCRIPTION = "company_accounts_dividend";
    public static final String COPY_LEGAL_PUBLICATIONS_DIVIDEND_FORM_DESCRIPTION = "Copie des publications légales";
    public static final String COPY_LEGAL_PUBLICATIONS_DIVIDEND_FORM_I18N_DESCRIPTION = "copy_legal_publications_dividend";
    public static final String COPY_DEED_OF_SALE_SIGNED_FORM_DESCRIPTION =
            "Copie de l'acte de vente signé par les parties mentionnant le nom de la société, la date et le prix";
    public static final String COPY_DEED_OF_SALE_SIGNED_FORM_I18N_DESCRIPTION = "copy_deed_of_sale_signed";
    public static final String FINANCIAL_STATEMENTS_SALE_FORM_DESCRIPTION = "Compte sociaux de l'année N-1";
    public static final String FINANCIAL_STATEMENTS_SALE_FORM_I18N_DESCRIPTION = "financial_statements_sale";
    public static final String INVESTMENT_STRATEGY_TO_ATTACH_FORM_DESCRIPTION = "Investment Strategy to attach";
    public static final String INVESTMENT_STRATEGY_TO_ATTACH_FORM_I18N_DESCRIPTION = "investment_strategy_to_attach";
    public static final String HAVE_UNQUOTED_PRODUCT_FORM_DESCRIPTION = "NTA Validation - email";
    public static final String HAVE_UNQUOTED_PRODUCT_FORM_I18N_DESCRIPTION = "have_unquoted_product";
    public static final String DIFFERENT_STRATEGY_FORM_DESCRIPTION = "Strategy";
    public static final String DIFFERENT_STRATEGY_FORM_I18N_DESCRIPTION = "different_strategy";
    public static final String FAS_ADVISORY_MANDATE_FORM_DESCRIPTION = "FAS Advisory Mandate";
    public static final String FAS_ADVISORY_MANDATE_FORM_I18N_DESCRIPTION = "fas_advisory_mandate";
    public static final String DEALING_REQUEST_FORM_DESCRIPTION = "Dealing Request Form";
    public static final String DEALING_REQUEST_FORM_I18N_DESCRIPTION = "dealing_request_form";
}
