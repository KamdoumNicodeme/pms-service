package com.lombardinternational.casemanagement.service.decision.domain.utils;

public enum Constraint {
    EQUALS, IN, CONTAINS, DISJOINT, LESS, MORE
}
