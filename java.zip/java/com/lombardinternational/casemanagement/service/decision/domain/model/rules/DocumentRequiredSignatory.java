package com.lombardinternational.casemanagement.service.decision.domain.model.rules;

import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class DocumentRequiredSignatory {

    private static final AtomicInteger currentOrder = new AtomicInteger(1);

    private String documentType;
    private String documentRelatedTo;
    private boolean documentMustBeGenerated;
    private boolean documentRequiredOnConnect;
    private String description;
    private String i18NDescription;
    private int documentOrder;
    private List<RequiredSignatory> requiredSignatories;
    private String cmsDocumentType;
    private String iterableIndex;

    public static void resetDocumentOrder() {

        currentOrder.set(1);
    }

    public void incrementOrder() {

        this.documentOrder = currentOrder.getAndIncrement();
    }
}
