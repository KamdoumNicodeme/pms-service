package com.lombardinternational.casemanagement.service.decision.domain.utils.constants.cci;

public final class CCIChecklistFieldConstants {

    // GENERAL_DETAILS GROUP
    public static final String CLIENT_NAME = "CLIENT_NAME";

}
