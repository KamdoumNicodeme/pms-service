package com.lombardinternational.casemanagement.service.decision.domain.service.taskscreen.common.groups;

import org.springframework.stereotype.Service;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Group;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Tab;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.taskscreen.TaskScreenGroupBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.taskscreen.common.fields.CommonDistressedFieldsBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.utils.RulesUtils;

import lombok.AllArgsConstructor;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.TaskScreenConstants.DISTRESSED_GROUP;

@Service
@AllArgsConstructor
public class CommonDistressedGroupBuilderService implements TaskScreenGroupBuilderService {

    private final CommonDistressedFieldsBuilderService service;

    @Override
    public void buildGroup(final WebForm webForm, final ScreenDescription screenCheckList, final ScreenDescription screenToFill,
            final Tab parentTab) {

        var ntaGroup = RulesUtils.getGroupInTab(parentTab, DISTRESSED_GROUP);
        if (ntaGroup == null) {
            ntaGroup = Group.builder().groupId(DISTRESSED_GROUP).build();
            parentTab.getGroups().add(ntaGroup);
        }
        ntaGroup.setIsActive(true);
        ntaGroup.incrementOrder();
        ntaGroup.setTitle("Distressed Assets - analyse asset and inform PCS of result.");
        service.buildField(webForm, screenCheckList, screenToFill, ntaGroup);
    }
}
