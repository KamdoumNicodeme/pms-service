package com.lombardinternational.casemanagement.service.decision.domain.service.taskscreen.common.fields;

import org.springframework.stereotype.Service;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Field;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Group;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.SelectInputField;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.TextAreaField;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.taskscreen.TaskScreenFieldBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.spi.repository.ReferenceDataRepositoryService;
import com.lombardinternational.casemanagement.service.decision.domain.utils.ChecklistUtils;

import lombok.AllArgsConstructor;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ReferenceConstants.YES_NO_DOMAIN;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.TaskScreenConstants.NOTES_FIELD;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.TaskScreenConstants.SUPPORTING_DOCUMENTATION_FIELD;

@Service
@AllArgsConstructor
public class CommonDocumentationFieldsBuilderService implements TaskScreenFieldBuilderService {

    private final ReferenceDataRepositoryService referenceDataRepositoryService;

    @Override
    public void buildField(WebForm webForm, ScreenDescription screenCheckList, ScreenDescription screenToFill, Group group) {

        Field.resetFieldId();
        evaluateSupportingDocumentation(group);
        evaluateNotes(group);
    }

    private void evaluateSupportingDocumentation(Group group) {

        var supportingDocumentation = (SelectInputField) ChecklistUtils.getFieldInGroup(group, SUPPORTING_DOCUMENTATION_FIELD);
        if (supportingDocumentation == null) {
            supportingDocumentation = SelectInputField.builder().fieldId(SUPPORTING_DOCUMENTATION_FIELD).build();
            group.getFields().add(supportingDocumentation);
        }
        supportingDocumentation.setIsActive(true);
        supportingDocumentation.incrementOrder();
        supportingDocumentation.setEnabled(true);
        supportingDocumentation.setMandatory(true);
        supportingDocumentation.setLabel("Supporting documentation on assets saved in Investment Compliance Portal");
        supportingDocumentation.setOptions(referenceDataRepositoryService.getReferenceDataOptionsByDomain(YES_NO_DOMAIN));
    }

    private void evaluateNotes(Group group) {

        var notes = (TextAreaField) ChecklistUtils.getFieldInGroup(group, NOTES_FIELD);
        if (notes == null) {
            notes = TextAreaField.builder().fieldId(NOTES_FIELD).build();
            group.getFields().add(notes);
        }
        notes.setIsActive(true);
        notes.incrementOrder();
        notes.setEnabled(true);
        notes.setLabel("Notes");
    }
}
