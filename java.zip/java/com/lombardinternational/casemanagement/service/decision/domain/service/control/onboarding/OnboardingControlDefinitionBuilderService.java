package com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ControlDefinition;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.AbstractControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.ControlDefinitionBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.common.NtaAcceptanceReceivedControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control.AeoiSelfControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control.AnalysisNeedsReceivedSignedControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control.ApplicationFormSignedByAllLaControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control.ApplicationFormSignedByIrrevocableBenControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control.ApplicationFormSignedInEeaCountryControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control.ApplicationPackInLineWithPricingNoteControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control.ApplicationPackInLineWithSalesforceControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control.ApprovedAnnualAccountsControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control.ArtAssocFiduciaryControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control.AuthorisedInvestmentLaControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control.BlockOnTermfixPolicyControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control.BrokerAuthorisedInCountryOfResidenceControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control.BrokerAuthorisedInPhCountryOfResidenceControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control.BrokerAuthorisedToIntermediateControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control.CertifiedIdEboControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control.CertifiedPorEboControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control.CertifiedTrustDeedControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control.CheckAccountOpenControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control.CheckFeasibilityWithWssControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control.CheckFeesCalculationControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control.CheckKycQuestionnaireSignedByIntroducingPartnerControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control.CheckRdrCompliantFormControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control.CheckWssFeasibilityNonCoreMarketControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control.ClassSetupInLineWithPricingApprovalControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control.ClientIdentificationOnFileControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control.ClientRefusedProvidingDocumentsControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control.ClientRiskScoreMandatoryInClassControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control.CollectRationaleAlteredDocumentsControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control.CollectRationaleToAuthorisePhControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control.ConfirmationThatAdviceProvidedOutsideUkControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control.ConflictOfInterestControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control.ConsentEmailRequestedControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control.CopyArtAssocStatutesControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control.CopyIdAuthSignatoriesControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control.CopyIdEboControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control.CopyIdEboFiduciaryControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control.CopyIdFiduciaryControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control.CopyIdPolicyRoleControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control.CopyListDirAuthSignatoriesControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control.CopyPorAuthSignatoriesControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control.CopyPorEboControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control.CopyPorEboFiduciaryControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control.CopyPorPolicyRoleControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control.CopyShrRegisterMemberControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control.CopyTradeCertificateControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control.DeedAppointmentTrusteesControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control.DisclaimerDulySignedControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control.DualCompliantProductControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control.EeaDeclarationReceivedControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control.EnsureCollectionOfRationaleControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control.EntityPartnerControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control.EscalatedToManagerControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control.EsgMandateDocumentationProvidedControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control.ExtractCentralRegisterBoControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control.ExtractCentralRegisterBoFiduciaryControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control.ExtractCentralRegisterFidTrustControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control.ExtractTradeRegisterCorpTrusteeControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control.ExtractTradeRegisterFiduciaryControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control.FatcaFormInconsistentControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control.FatcaFormRefusedControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control.FiduciaryMandateControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control.FollowUmbrellaIlfProcedureGroupBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control.FollowUpConfirmationControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control.FormLastVersionReceivedControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control.HashCheckPerformedControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control.IdAndPorCorpTrusteeControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control.IdAndPorEboCorpTrusteeControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control.ListAuthSignCorpTrusteeControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control.ListAuthorisedSignatoriesFiduciaryControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control.ListDirShrFiduciaryControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control.NbNotAllowedPermitBLCControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control.NewVideoOrExceptionProvidedControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control.NoProofOfDeregistrationControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control.NoThirdPartyPaymentAllowedControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control.OfficeInStandardCountryControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control.OriginalSignedDocumentControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control.OwnershipStructureChartFiduciaryControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control.OwnershipStructureCorpTrusteeControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control.PassportChecksPerformedControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control.PaymentReferenceControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control.PhRefuseToSignTccControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control.PrepareTheClientUserAccessControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control.PricingApprovalReceivedControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control.PricingNoteFromCaseStructuringControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control.ProofBeneficialOwnershipControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control.RevertBackToCollectReasonControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control.SendPortfolioToCustodianBankControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control.SendStrategyToIMControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control.SetContractTermDateInClassControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control.ShrRegisterAndTradeRegisterControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control.ShrRegisterCorpTrusteeControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control.ShrTradeRegisterCorpTrusteeControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control.SignedConnectAgreementControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control.SignedOwnershipStructureChartControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control.StatutesCorpTrusteeControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control.TaxResidenceNoLegitimateReasonControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control.ThirdPartyInSwissResidentControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control.TrusteeInvestInLaControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control.VerificationAllDocumentsCertificationControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control.VerificationAllDocumentsCertificationProxyControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control.VerificationDataSynchronizationBeforeCompletionControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control.VideoRecordingReceivedControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control.WorldCheckAndResearchOnOwnerControlBuilderService;

import lombok.AllArgsConstructor;

@Service
@AllArgsConstructor
public class OnboardingControlDefinitionBuilderService implements ControlDefinitionBuilderService {

    private final AeoiSelfControlBuilderService aeoiSelfControlBuilderService;
    private final AnalysisNeedsReceivedSignedControlBuilderService analysisNeedsReceivedSignedControlBuilderService;
    private final ApplicationFormSignedByAllLaControlBuilderService applicationFormSignedByAllLaControlBuilderService;
    private final ApplicationFormSignedByIrrevocableBenControlBuilderService applicationFormSignedByIrrevocableBenControlBuilderService;
    private final ApplicationFormSignedInEeaCountryControlBuilderService applicationFormSignedInEeaCountryControlBuilderService;
    private final ApplicationPackInLineWithPricingNoteControlBuilderService applicationPackInLineWithPricingNoteControlBuilderService;
    private final ApplicationPackInLineWithSalesforceControlBuilderService applicationPackInLineWithSalesforceControlBuilderService;
    private final ApprovedAnnualAccountsControlBuilderService approvedAnnualAccountsControlBuilderService;
    private final ArtAssocFiduciaryControlBuilderService artAssocFiduciaryControlBuilderService;
    private final AuthorisedInvestmentLaControlBuilderService authorisedInvestmentLaControlBuilderService;
    private final BlockOnTermfixPolicyControlBuilderService blockOnTermfixPolicyControlBuilderService;
    private final BrokerAuthorisedInCountryOfResidenceControlBuilderService brokerAuthorisedInCountryOfResidenceControlBuilderService;
    private final BrokerAuthorisedInPhCountryOfResidenceControlBuilderService brokerAuthorisedInPhCountryOfResidenceControlBuilderService;
    private final BrokerAuthorisedToIntermediateControlBuilderService brokerAuthorisedToIntermediateControlBuilderService;
    private final CertifiedIdEboControlBuilderService certifiedIdEboControlBuilderService;
    private final CertifiedPorEboControlBuilderService certifiedPorEboControlBuilderService;
    private final CertifiedTrustDeedControlBuilderService certifiedTrustDeedControlBuilderService;
    private final CheckAccountOpenControlBuilderService checkAccountOpenControlBuilderService;
    private final CheckFeasibilityWithWssControlBuilderService checkFeasibilityWithWssControlBuilderService;
    private final CheckFeesCalculationControlBuilderService checkFeesCalculationControlBuilderService;
    private final CheckKycQuestionnaireSignedByIntroducingPartnerControlBuilderService checkKycQuestionnaireSignedByIntroducingPartnerControlBuilderService;
    private final CheckRdrCompliantFormControlBuilderService checkRdrCompliantFormControlBuilderService;
    private final CheckWssFeasibilityNonCoreMarketControlBuilderService checkWssFeasibilityNonCoreMarketControlBuilderService;
    private final ClassSetupInLineWithPricingApprovalControlBuilderService classSetupInLineWithPricingApprovalControlBuilderService;
    private final ClientRefusedProvidingDocumentsControlBuilderService clientRefusedProvidingDocumentsControlBuilderService;
    private final ClientRiskScoreMandatoryInClassControlBuilderService clientRiskScoreMandatoryInClassControlBuilderService;
    private final CollectRationaleAlteredDocumentsControlBuilderService collectRationaleAlteredDocumentsControlBuilderService;
    private final CollectRationaleToAuthorisePhControlBuilderService collectRationaleToAuthorisePhControlBuilderService;
    private final ConfirmationThatAdviceProvidedOutsideUkControlBuilderService confirmationThatAdviceProvidedOutsideUkControlBuilderService;
    private final ConflictOfInterestControlBuilderService conflictOfInterestControlBuilderService;
    private final ConsentEmailRequestedControlBuilderService consentEmailRequestedControlBuilderService;
    private final CopyArtAssocStatutesControlBuilderService copyArtAssocStatutesControlBuilderService;
    private final CopyIdAuthSignatoriesControlBuilderService copyIdAuthSignatoriesControlBuilderService;
    private final CopyIdEboControlBuilderService copyIdEboControlBuilderService;
    private final CopyIdEboFiduciaryControlBuilderService copyIdEboFiduciaryControlBuilderService;
    private final CopyIdFiduciaryControlBuilderService copyIdFiduciaryControlBuilderService;
    private final CopyIdPolicyRoleControlBuilderService copyIdPolicyRoleControlBuilderService;
    private final CopyListDirAuthSignatoriesControlBuilderService copyListDirAuthSignatoriesControlBuilderService;
    private final CopyPorAuthSignatoriesControlBuilderService copyPorAuthSignatoriesControlBuilderService;
    private final CopyPorEboControlBuilderService copyPorEboControlBuilderService;
    private final CopyPorEboFiduciaryControlBuilderService copyPorEboFiduciaryControlBuilderService;
    private final CopyPorPolicyRoleControlBuilderService copyPorPolicyRoleControlBuilderService;
    private final CopyShrRegisterMemberControlBuilderService copyShrRegisterMemberControlBuilderService;
    private final CopyTradeCertificateControlBuilderService copyTradeCertificateControlBuilderService;
    private final DeedAppointmentTrusteesControlBuilderService deedAppointmentTrusteesControlBuilderService;
    private final DualCompliantProductControlBuilderService dualCompliantProductControlBuilderService;
    private final EeaDeclarationReceivedControlBuilderService eeaDeclarationReceivedControlBuilderService;
    private final EnsureCollectionOfRationaleControlBuilderService ensureCollectionOfRationaleControlBuilderService;
    private final EntityPartnerControlBuilderService entityPartnerControlBuilderService;
    private final EscalatedToManagerControlBuilderService escalatedToManagerControlBuilderService;
    private final EsgMandateDocumentationProvidedControlBuilderService esgMandateDocumentationProvidedControlBuilderService;
    private final ExtractCentralRegisterBoControlBuilderService extractCentralRegisterBoControlBuilderService;
    private final ExtractCentralRegisterBoFiduciaryControlBuilderService extractCentralRegisterBoFiduciaryControlBuilderService;
    private final ExtractCentralRegisterFidTrustControlBuilderService extractCentralRegisterFidTrustControlBuilderService;
    private final ExtractTradeRegisterCorpTrusteeControlBuilderService extractTradeRegisterCorpTrusteeControlBuilderService;
    private final ExtractTradeRegisterFiduciaryControlBuilderService extractTradeRegisterFiduciaryControlBuilderService;
    private final FatcaFormInconsistentControlBuilderService fatcaFormInconsistentControlBuilderService;
    private final FatcaFormRefusedControlBuilderService fatcaFormRefusedControlBuilderService;
    private final FiduciaryMandateControlBuilderService fiduciaryMandateControlBuilderService;
    private final FollowUmbrellaIlfProcedureGroupBuilderService followUmbrellaIlfProcedureGroupBuilderService;
    private final FollowUpConfirmationControlBuilderService followUpConfirmationControlBuilderService;
    private final FormLastVersionReceivedControlBuilderService formLastVersionReceivedControlBuilderService;
    private final HashCheckPerformedControlBuilderService hashCheckPerformedControlBuilderService;
    private final IdAndPorCorpTrusteeControlBuilderService idAndPorCorpTrusteeControlBuilderService;
    private final IdAndPorEboCorpTrusteeControlBuilderService idAndPorEboCorpTrusteeControlBuilderService;
    private final ListAuthorisedSignatoriesFiduciaryControlBuilderService listAuthorisedSignatoriesFiduciaryControlBuilderService;
    private final ListAuthSignCorpTrusteeControlBuilderService listAuthSignCorpTrusteeControlBuilderService;
    private final ListDirShrFiduciaryControlBuilderService listDirShrFiduciaryControlBuilderService;
    private final NbNotAllowedPermitBLCControlBuilderService nbNotAllowedPermitBLCControlBuilderService;
    private final NewVideoOrExceptionProvidedControlBuilderService newVideoOrExceptionProvidedControlBuilderService;
    private final NoProofOfDeregistrationControlBuilderService noProofOfDeregistrationControlBuilderService;
    private final NoThirdPartyPaymentAllowedControlBuilderService noThirdPartyPaymentAllowedControlBuilderService;
    private final NtaAcceptanceReceivedControlBuilderService ntaAcceptanceReceivedControlBuilderService;
    private final OfficeInStandardCountryControlBuilderService officeInStandardCountryControlBuilderService;
    private final OwnershipStructureChartFiduciaryControlBuilderService ownershipStructureChartFiduciaryControlBuilderService;
    private final OwnershipStructureCorpTrusteeControlBuilderService ownershipStructureCorpTrusteeControlBuilderService;
    private final PassportChecksPerformedControlBuilderService passportChecksPerformedControlBuilderService;
    private final PaymentReferenceControlBuilderService paymentReferenceControlBuilderService;
    private final PhRefuseToSignTccControlBuilderService phRefuseToSignTccControlBuilderService;
    private final PricingApprovalReceivedControlBuilderService pricingApprovalReceivedControlBuilderService;
    private final PricingNoteFromCaseStructuringControlBuilderService pricingNoteFromCaseStructuringControlBuilderService;
    private final ProofBeneficialOwnershipControlBuilderService proofBeneficialOwnershipControlBuilderService;
    private final RevertBackToCollectReasonControlBuilderService revertBackToCollectReasonControlBuilderService;
    private final DisclaimerDulySignedControlBuilderService disclaimerDulySignedControlBuilderService;
    private final SendPortfolioToCustodianBankControlBuilderService sendPortfolioToCustodianBankControlBuilderService;
    private final SendStrategyToIMControlBuilderService sendStrategyToIMControlBuilderService;
    private final SetContractTermDateInClassControlBuilderService setContractTermDateInClassControlBuilderService;
    private final ShrRegisterAndTradeRegisterControlBuilderService shrRegisterAndTradeRegisterControlBuilderService;
    private final ShrRegisterCorpTrusteeControlBuilderService shrRegisterCorpTrusteeControlBuilderService;
    private final ShrTradeRegisterCorpTrusteeControlBuilderService shrTradeRegisterCorpTrusteeControlBuilderService;
    private final SignedConnectAgreementControlBuilderService signedConnectAgreementControlBuilderService;
    private final SignedOwnershipStructureChartControlBuilderService signedOwnershipStructureChartControlBuilderService;
    private final StatutesCorpTrusteeControlBuilderService statutesCorpTrusteeControlBuilderService;
    private final TaxResidenceNoLegitimateReasonControlBuilderService taxResidenceNoLegitimateReasonControlBuilderService;
    private final ThirdPartyInSwissResidentControlBuilderService thirdPartyInSwissResidentControlBuilderService;
    private final TrusteeInvestInLaControlBuilderService trusteeInvestInLaControlBuilderService;
    private final VerificationAllDocumentsCertificationControlBuilderService verificationAllDocumentsCertificationControlBuilderService;
    private final VerificationAllDocumentsCertificationProxyControlBuilderService verificationAllDocumentsCertificationProxyControlBuilderService;
    private final VerificationDataSynchronizationBeforeCompletionControlBuilderService verificationDataSynchronizationBeforeCompletionControlBuilderService;
    private final PrepareTheClientUserAccessControlBuilderService prepareTheClientUserAccessControlBuilderService;
    private final VideoRecordingReceivedControlBuilderService videoRecordingReceivedControlBuilderService;
    private final WorldCheckAndResearchOnOwnerControlBuilderService worldcheckAndResearchOnOwnerControlBuilderService;
    private final ClientIdentificationOnFileControlBuilderService clientIdentificationOnFileControlBuilderService;
    private final OriginalSignedDocumentControlBuilderService originalSignedDocumentControlBuilderService;

    @Override
    public List<ControlDefinition> buildControlDefinition(WebForm webForm, ScreenDescription screenDescription) {

        ControlDefinition.resetControlOrder();
        final List<ControlDefinition> controls = new ArrayList<>();
        List<AbstractControlBuilderService> controlBuilderServices = Arrays.asList(aeoiSelfControlBuilderService,
                analysisNeedsReceivedSignedControlBuilderService, applicationFormSignedByAllLaControlBuilderService,
                applicationFormSignedByIrrevocableBenControlBuilderService, applicationFormSignedInEeaCountryControlBuilderService,
                applicationPackInLineWithPricingNoteControlBuilderService, applicationPackInLineWithSalesforceControlBuilderService,
                approvedAnnualAccountsControlBuilderService, artAssocFiduciaryControlBuilderService, authorisedInvestmentLaControlBuilderService,
                blockOnTermfixPolicyControlBuilderService, brokerAuthorisedInCountryOfResidenceControlBuilderService,
                brokerAuthorisedInPhCountryOfResidenceControlBuilderService, brokerAuthorisedToIntermediateControlBuilderService,
                certifiedIdEboControlBuilderService, certifiedPorEboControlBuilderService, certifiedTrustDeedControlBuilderService,
                checkAccountOpenControlBuilderService, checkFeasibilityWithWssControlBuilderService, checkFeesCalculationControlBuilderService,
                checkKycQuestionnaireSignedByIntroducingPartnerControlBuilderService, checkRdrCompliantFormControlBuilderService,
                checkWssFeasibilityNonCoreMarketControlBuilderService, classSetupInLineWithPricingApprovalControlBuilderService,
                clientRefusedProvidingDocumentsControlBuilderService, clientRiskScoreMandatoryInClassControlBuilderService,
                collectRationaleAlteredDocumentsControlBuilderService, collectRationaleToAuthorisePhControlBuilderService,
                confirmationThatAdviceProvidedOutsideUkControlBuilderService, conflictOfInterestControlBuilderService,
                consentEmailRequestedControlBuilderService, copyArtAssocStatutesControlBuilderService, copyIdAuthSignatoriesControlBuilderService,
                copyIdEboControlBuilderService, copyIdEboFiduciaryControlBuilderService, copyIdFiduciaryControlBuilderService,
                copyIdPolicyRoleControlBuilderService, copyListDirAuthSignatoriesControlBuilderService,
                copyPorAuthSignatoriesControlBuilderService, copyPorEboControlBuilderService, copyPorEboFiduciaryControlBuilderService,
                copyPorPolicyRoleControlBuilderService, copyShrRegisterMemberControlBuilderService, copyTradeCertificateControlBuilderService,
                deedAppointmentTrusteesControlBuilderService, dualCompliantProductControlBuilderService,
                eeaDeclarationReceivedControlBuilderService, ensureCollectionOfRationaleControlBuilderService, entityPartnerControlBuilderService,
                escalatedToManagerControlBuilderService, esgMandateDocumentationProvidedControlBuilderService,
                extractCentralRegisterBoControlBuilderService, extractCentralRegisterBoFiduciaryControlBuilderService,
                extractCentralRegisterFidTrustControlBuilderService, extractTradeRegisterCorpTrusteeControlBuilderService,
                extractTradeRegisterFiduciaryControlBuilderService, fatcaFormInconsistentControlBuilderService,
                fatcaFormRefusedControlBuilderService, fiduciaryMandateControlBuilderService, followUmbrellaIlfProcedureGroupBuilderService,
                followUpConfirmationControlBuilderService, formLastVersionReceivedControlBuilderService, hashCheckPerformedControlBuilderService,
                idAndPorCorpTrusteeControlBuilderService, idAndPorEboCorpTrusteeControlBuilderService,
                listAuthorisedSignatoriesFiduciaryControlBuilderService, listAuthSignCorpTrusteeControlBuilderService,
                listDirShrFiduciaryControlBuilderService, nbNotAllowedPermitBLCControlBuilderService,
                newVideoOrExceptionProvidedControlBuilderService, noProofOfDeregistrationControlBuilderService,
                noThirdPartyPaymentAllowedControlBuilderService, ntaAcceptanceReceivedControlBuilderService,
                officeInStandardCountryControlBuilderService, ownershipStructureChartFiduciaryControlBuilderService,
                ownershipStructureCorpTrusteeControlBuilderService, passportChecksPerformedControlBuilderService,
                paymentReferenceControlBuilderService, phRefuseToSignTccControlBuilderService, pricingApprovalReceivedControlBuilderService,
                pricingNoteFromCaseStructuringControlBuilderService, proofBeneficialOwnershipControlBuilderService,
                revertBackToCollectReasonControlBuilderService, disclaimerDulySignedControlBuilderService,
                sendPortfolioToCustodianBankControlBuilderService, sendStrategyToIMControlBuilderService,
                setContractTermDateInClassControlBuilderService, shrRegisterAndTradeRegisterControlBuilderService,
                shrRegisterCorpTrusteeControlBuilderService, shrTradeRegisterCorpTrusteeControlBuilderService,
                signedConnectAgreementControlBuilderService, signedOwnershipStructureChartControlBuilderService,
                statutesCorpTrusteeControlBuilderService, taxResidenceNoLegitimateReasonControlBuilderService,
                thirdPartyInSwissResidentControlBuilderService, trusteeInvestInLaControlBuilderService,
                verificationAllDocumentsCertificationControlBuilderService, verificationAllDocumentsCertificationProxyControlBuilderService,
                verificationDataSynchronizationBeforeCompletionControlBuilderService, prepareTheClientUserAccessControlBuilderService,
                videoRecordingReceivedControlBuilderService, worldcheckAndResearchOnOwnerControlBuilderService,
                clientIdentificationOnFileControlBuilderService, originalSignedDocumentControlBuilderService

        );
        controlBuilderServices.forEach(service -> Optional.ofNullable(service.buildControl(webForm, screenDescription)).ifPresent(controls::add));
        return controls;
    }
}
