package com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control;

import java.util.List;

import org.springframework.stereotype.Service;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ControlDefinition;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.AbstractControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.spi.repository.CountryDataRepositoryService;
import com.lombardinternational.casemanagement.service.decision.domain.utils.ControlUtils;

import lombok.AllArgsConstructor;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ControlConstants.CHECK_WSS_FEASIBILITY_NON_CORE_MARKET_NAME;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ControlConstants.CHECK_WSS_FEASIBILITY_NON_CORE_MARKET_TYPE;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ReferenceConstants.CORE_MARKET;

@Service
@AllArgsConstructor
public class CheckWssFeasibilityNonCoreMarketControlBuilderService extends AbstractControlBuilderService {

    private final CountryDataRepositoryService countryDataRepositoryService;

    @Override
    public ControlDefinition buildControl(WebForm webForm, ScreenDescription screenDescription) {

        List<String> markets = countryDataRepositoryService.getCountryByTypeAndValue(CORE_MARKET, "YES");
        final var constraints = ControlUtils.verifyPhEboLaResidenceCountryRiskOnMarkets(markets, false);
        if (constraints.stream().anyMatch(constraint -> constraint.test(screenDescription))) {
            return buildControlDefinition();
        }
        return null;
    }

    @Override
    protected String getControlName() {

        return CHECK_WSS_FEASIBILITY_NON_CORE_MARKET_NAME;
    }

    @Override
    protected String getControlType() {

        return CHECK_WSS_FEASIBILITY_NON_CORE_MARKET_TYPE;
    }
}
