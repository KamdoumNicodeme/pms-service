package com.lombardinternational.casemanagement.service.decision.domain.service.document.addition.document;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.DocumentDefinition;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.document.AbstractDocumentBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.utils.Constraint;
import com.lombardinternational.casemanagement.service.decision.domain.utils.FieldConstraint;
import com.lombardinternational.casemanagement.service.decision.domain.utils.WebformUtils;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ChecklistFieldConstants.LINK_THIRD_PARTY_PH;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.DocumentConstants.*;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.WebFormFieldConstants.POLICY_NUMBER_WF;

@Service
public class ThirdPartyPaymentDocumentBuilderService extends AbstractDocumentBuilderService {

    @Override
    public void buildDocument(final WebForm webForm, final ScreenDescription screenDescription, String transactionNumber,
            List<DocumentDefinition> documents) {

        final var constraints = new ArrayList<FieldConstraint>();
        constraints.add(FieldConstraint.builder().fieldId(LINK_THIRD_PARTY_PH).constraint(Constraint.EQUALS).multiple(true)
                .values(Collections.singletonList("3pt_cor_so")).build());
        if (constraints.stream().allMatch(constraint -> constraint.test(screenDescription))) {
            var relatedTo = WebformUtils.getWebFormFieldValueById(webForm, POLICY_NUMBER_WF);
            buildDocumentDefinition(relatedTo, relatedTo, null, null, documents);
        }
    }

    @Override
    protected String getDocumentType() {

        return TP_DOCS_DOC_TYPE;
    }

    @Override
    protected String getCmsDocumentType() {

        return TP_DOCS_CMS_DOC_TYPE;
    }

    @Override
    protected String getDescription() {

        return THIRD_PARTY_PAYMENT_FORM_DESCRIPTION;
    }

    @Override
    protected String getI18NDescription() {

        return THIRD_PARTY_PAYMENT_FORM_I18N_DESCRIPTION;
    }

    @Override
    protected String getCmtRelatedToPrefix() {

        return THIRD_PARTY_PAYMENT_FORM_CMT_RELATED_TO_PREFIX_DESCRIPTION;
    }

    @Override
    protected String getI18NDocumentRelatedTo() {

        return CLIENT_I18N_DOCUMENT_RELATED_TO;
    }
}
