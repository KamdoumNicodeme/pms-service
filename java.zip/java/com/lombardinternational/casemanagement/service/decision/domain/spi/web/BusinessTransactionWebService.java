package com.lombardinternational.casemanagement.service.decision.domain.spi.web;

import com.lombardinternational.casemanagement.service.decision.domain.exception.ClassInternalNotFoundException;
import com.lombardinternational.casemanagement.service.decision.domain.model.transaction.BusinessTransaction;

public interface BusinessTransactionWebService {

    BusinessTransaction getBusinessTransactionDetails(final String businessTransactionNumber) throws ClassInternalNotFoundException;
}
