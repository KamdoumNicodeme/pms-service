package com.lombardinternational.casemanagement.service.decision.domain.model.rules;

import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class ControlDefinition {

    private static final AtomicInteger currentOrder = new AtomicInteger(1);

    private int controlId;
    private String controlName;
    @Builder.Default
    private boolean controlVisibleOnConnect = false;
    private int controlOrder;
    private List<String> decisionReasons;
    private String controlType;

    public static void resetControlOrder() {

        currentOrder.set(1);
    }

    public void incrementOrder() {

        this.controlOrder = currentOrder.getAndIncrement();
    }
}
