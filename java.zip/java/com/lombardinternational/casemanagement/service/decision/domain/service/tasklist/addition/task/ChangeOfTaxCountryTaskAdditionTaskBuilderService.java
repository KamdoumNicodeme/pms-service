package com.lombardinternational.casemanagement.service.decision.domain.service.tasklist.addition.task;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ChecklistFieldConstants.*;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.WebFormFieldConstants.*;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.lombardinternational.casemanagement.service.decision.domain.model.policy.Policy;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.TaskDefinition;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebFormGroup;
import com.lombardinternational.casemanagement.service.decision.domain.service.tasklist.AbstractTaskBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.utils.Constraint;
import com.lombardinternational.casemanagement.service.decision.domain.utils.FieldConstraint;
import com.lombardinternational.casemanagement.service.decision.domain.utils.WebformUtils;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class ChangeOfTaxCountryTaskAdditionTaskBuilderService extends AbstractTaskBuilderService {

    private String concatenatedReasons;

    @Override
    public void buildTask(final Policy policy, final WebForm webForm, final ScreenDescription screenDescription,
            final List<TaskDefinition> taskList) {

        final var constraints = new ArrayList<FieldConstraint>();
        constraints.add(FieldConstraint.builder().fieldId(FISCAL_INFORMATION_STILL_VALID).constraint(Constraint.EQUALS)
                .values(Collections.singletonList("NO")).build());
        if (constraints.stream().anyMatch(constraint -> constraint.test(screenDescription))) {
            concatenatedReasons = "";
            buildReasons(webForm);
            buildTaskDefinition(taskList);
        }
    }

    @Override
    protected String getTaskName() {

        return "Change Of Tax Country";
    }

    @Override
    protected boolean getMandatory() {

        return true;
    }

    @Override
    protected Optional<String> getDecisionReason() {

        return Optional.ofNullable(concatenatedReasons);
    }

    private void buildReasons(WebForm webForm) {

        // First get all policyholders
        WebFormGroup physicalPolicyHolders = WebformUtils.getFirstWebFormGroupById(webForm, PHYSICAL_PERSONS_WF);
        WebFormGroup moralPolicyHolders = WebformUtils.getFirstWebFormGroupById(webForm, MORAL_PERSON_WF);
        List<WebFormGroup> policyHolders = new ArrayList<>();
        if (physicalPolicyHolders != null) {
            policyHolders.addAll(physicalPolicyHolders.getGroups());
        }
        if (moralPolicyHolders != null) {
            policyHolders.add(moralPolicyHolders);
        }

        // Then for each PH, add a decision reason for each new UpdatedAeoi item found
        policyHolders.forEach(ph -> {
            if ("false".equalsIgnoreCase(WebformUtils.getWebFormFieldValueById(ph, IS_NIF_STILL_VALID_WF))) {
                WebFormGroup updatedAeoiGroup = WebformUtils.getFirstWebFormGroupById(webForm, ph, UPDATED_AEOI_WF);
                String clientNumber = WebformUtils.getWebFormFieldValueById(ph, CLIENT_NUMBER_WF);
                if (updatedAeoiGroup != null && updatedAeoiGroup.getGroups() != null && !updatedAeoiGroup.getGroups().isEmpty()) {
                    updatedAeoiGroup.getGroups().forEach(updatedAeoiItem -> addNewReason(buildNewAeoiReason(updatedAeoiItem, clientNumber)));
                } else {
                    log.warn("No new Aeoi details provided for client {}, despite invalid TIN found", clientNumber);
                }
            }
        });
    }

    private String buildNewAeoiReason(WebFormGroup updatedAeoiItem, String clientNumber) {

        String residenceCountry = WebformUtils.getWebFormFieldValueById(updatedAeoiItem, RESIDENCE_COUNTRY_WF);
        String nif = WebformUtils.getWebFormFieldValueById(updatedAeoiItem, NIF_WF);
        String haveNif = WebformUtils.getWebFormFieldValueById(updatedAeoiItem, HAVE_NIF_WF);
        String reason = WebformUtils.getWebFormFieldValueById(updatedAeoiItem, REASON_WF);
        String explanation = WebformUtils.getWebFormFieldValueById(updatedAeoiItem, EXPLANATION_WF);

        if ("true".equalsIgnoreCase(haveNif)) {
            return String.format("Change of tax country for client %s: new Residence country = %s, new TIN = %s \n", clientNumber,
                    residenceCountry, nif);
        } else {
            return String.format(
                    "Change of tax country for client %s: new Residence country = %s, no TIN provided, new reason = %s, new explanation = %s \n",
                    clientNumber, residenceCountry, reason, explanation);
        }
    }

    private void addNewReason(String reason) {

        if (concatenatedReasons == null) {
            concatenatedReasons = "";
        }
        this.concatenatedReasons = concatenatedReasons + reason;
    }

}
