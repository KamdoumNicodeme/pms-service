package com.lombardinternational.casemanagement.service.decision.domain.model.policy;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder
@NoArgsConstructor
public abstract class HardCode {

    private String externalId;
    private String label;
}
