package com.lombardinternational.casemanagement.service.decision.domain.service.document.additionV2.document;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.DocumentDefinition;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebFormField;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebFormGroup;
import com.lombardinternational.casemanagement.service.decision.domain.service.document.AbstractDocumentBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.utils.WebformUtils;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Service;

import java.util.List;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.DocumentConstants.FAS_ADVISORY_MANDATE_FORM_DESCRIPTION;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.DocumentConstants.FAS_ADVISORY_MANDATE_FORM_I18N_DESCRIPTION;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.DocumentConstants.FUND_I18N_DOCUMENT_RELATED_TO;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.DocumentConstants.TP_DOCS_CMS_DOC_TYPE;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.DocumentConstants.TP_DOCS_DOC_TYPE;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.SignatoryConstants.PREMIUM_INVESTMENT_SAF_MANAGER_MANAGEMENT_ADVISED;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.WebFormFieldConstants.FAS_MANAGER;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.WebFormFieldConstants.FUND_ID_WF;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.WebFormFieldConstants.IS_NEW_WF;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.WebFormFieldConstants.POLICY_NUMBER_WF;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.WebFormFieldConstants.SPECIALISED_ASSURANCE_FUNDS_WF;

@Service
public class FasAdvisoryMandateDocumentBuilderService extends AbstractDocumentBuilderService {

    @Override
    public void buildDocument(final WebForm webForm, final ScreenDescription screenDescription, String transactionNumber,
        List<DocumentDefinition> documents) {

        final WebFormGroup safGroup = WebformUtils.getFirstWebFormGroupById(webForm, SPECIALISED_ASSURANCE_FUNDS_WF);

        if (safGroup != null && CollectionUtils.isNotEmpty(safGroup.getGroups())) {

            final String relatedToPolicyNumber = WebformUtils.getWebFormFieldValueById(webForm, POLICY_NUMBER_WF);

            final List<WebFormGroup> safSubGroups = safGroup.getGroups();
            safSubGroups.forEach(group -> buildDocumentDefinitionForGroup(group, relatedToPolicyNumber, documents));
        }
    }

    private void buildDocumentDefinitionForGroup(
        final WebFormGroup group, final String relatedToPolicyNumber, final List<DocumentDefinition> documents) {

        final WebFormField newSafField = WebformUtils.getFirstWebFormField(group, IS_NEW_WF);
        final WebFormField safManagerField = WebformUtils.getFirstWebFormField(group, FAS_MANAGER);

        if (!isNewSaf(newSafField))
            return;

        if (!isSafManagementAdvised(safManagerField))
            return;

        final String fundId = WebformUtils.getWebFormFieldValueById(group, FUND_ID_WF);

        final String relatedTo = "Fund " + fundId;
        buildDocumentDefinition(relatedTo, relatedToPolicyNumber, fundId, null, documents);
    }

    private boolean isNewSaf(final WebFormField field) {

        return "true".equals(WebformUtils.getValueForWebFormField(field));
    }

    private boolean isSafManagementAdvised(final WebFormField field) {

        return PREMIUM_INVESTMENT_SAF_MANAGER_MANAGEMENT_ADVISED.equals(WebformUtils.getValueForWebFormField(field));
    }

    @Override
    protected String getDocumentType() {

        return TP_DOCS_DOC_TYPE;
    }

    @Override
    protected String getCmsDocumentType() {

        return TP_DOCS_CMS_DOC_TYPE;
    }

    @Override
    protected String getDescription() {

        return FAS_ADVISORY_MANDATE_FORM_DESCRIPTION;
    }

    @Override
    protected String getI18NDescription() {

        return FAS_ADVISORY_MANDATE_FORM_I18N_DESCRIPTION;
    }

    @Override
    protected String getI18NDocumentRelatedTo() {

        return FUND_I18N_DOCUMENT_RELATED_TO;
    }

    @Override
    protected boolean getDocumentVisibleOnConnect() {

        return true;
    }

    @Override
    protected boolean getDocumentRequired() {

        return true;
    }
}
