package com.lombardinternational.casemanagement.service.decision.domain.service;

import com.lombardinternational.casemanagement.service.decision.domain.model.policy.Amount;
import com.lombardinternational.casemanagement.service.decision.domain.model.transaction.BusinessTransaction;
import com.lombardinternational.casemanagement.service.decision.domain.model.transaction.BusinessTransactionProductComponent;
import com.lombardinternational.casemanagement.service.decision.domain.model.transaction.Payment;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Collection;
import java.util.Optional;

@Service
@AllArgsConstructor
public class AmountService {

    private final FxRateService fxRateService;

    public Amount convertAmount(Amount amount, String targetCurrency) {

        if (amount == null || amount.getQuantity() == null) {
            return new Amount(BigDecimal.ZERO.setScale(2, RoundingMode.HALF_UP), targetCurrency);
        }

        if (targetCurrency == null || targetCurrency.equals(amount.getIsoCurrencyCode())) {
            amount.setQuantity(amount.getQuantity().setScale(2, RoundingMode.HALF_UP));
            return amount;
        }

        final var fxRate = fxRateService.getLastFxRate(amount.getIsoCurrencyCode(), targetCurrency);

        final Amount convertedAmount = new Amount();
        convertedAmount.setIsoCurrencyCode(targetCurrency);

        if (fxRate.isPresent()) {
            convertedAmount.setQuantity(
                    amount.getQuantity().multiply(fxRate.get().getBareRate().setScale(6, RoundingMode.HALF_UP)).setScale(2, RoundingMode.HALF_UP));
        } else {
            convertedAmount.setQuantity(amount.getQuantity().setScale(2, RoundingMode.HALF_UP));
        }
        return convertedAmount;
    }

    public Amount getSumPaymentAmountInTransaction(BusinessTransaction transaction, String targetCurrency) {

        BigDecimal sum = BigDecimal.ZERO;
        if (transaction != null) {
            sum = Optional.ofNullable(transaction.getProductComponentPayments()).stream().flatMap(Collection::stream)
                    .map(BusinessTransactionProductComponent::getPayments)
                    .flatMap(payments -> Optional.ofNullable(payments).stream().flatMap(Collection::stream)).map(Payment::getPaymentAmount)
                    .map(amount -> convertAmount(amount, targetCurrency)).map(Amount::getQuantity).reduce(BigDecimal.ZERO, BigDecimal::add);
        }

        if (BigDecimal.ZERO.compareTo(sum) == 0) {
            if (transaction != null && transaction.getProductComponentPayments() != null) {
                sum = transaction.getProductComponentPayments().stream()
                        .map(BusinessTransactionProductComponent::getExpectedAmountInPolicyCurrency)
                        .map(expectedAmount -> convertAmount(expectedAmount, targetCurrency)).map(Amount::getQuantity)
                        .reduce(BigDecimal.ZERO, BigDecimal::add);
            }
        }
        return new Amount(sum.setScale(2, RoundingMode.HALF_UP), targetCurrency);
    }
}
