package com.lombardinternational.casemanagement.service.decision.domain.service.taskscreen.addition.fields;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Field;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Group;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.SelectInputField;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.taskscreen.TaskScreenFieldBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.spi.repository.ReferenceDataRepositoryService;
import com.lombardinternational.casemanagement.service.decision.domain.utils.ChecklistUtils;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.Optional;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.TaskScreenConstants.*;

@Service
@AllArgsConstructor
public class ChecklistDataControlsFieldsBuilderService implements TaskScreenFieldBuilderService {

    private final ReferenceDataRepositoryService referenceDataRepositoryService;

    @Override
    public void buildField(final WebForm webForm, final ScreenDescription screenCheckList, final ScreenDescription screenToFill,
            final Group group) {

        Field.resetFieldId();
        evaluateReinvestedInIlf(group, screenCheckList);
        evaluatePremiumWithAssets(group, screenCheckList);
    }

    private void evaluateReinvestedInIlf(Group group, ScreenDescription screenCheckList) {

        var reinvestedInIlf = (SelectInputField) ChecklistUtils.getFieldInGroup(group, REINVESTED_IN_ILF_FIELD);
            if (reinvestedInIlf == null) {
                reinvestedInIlf = SelectInputField.builder().fieldId(REINVESTED_IN_ILF_FIELD).build();
                group.getFields().add(reinvestedInIlf);
            }
            reinvestedInIlf.setIsActive(true);
            reinvestedInIlf.incrementOrder();
            reinvestedInIlf.setLabel("Reinvested in ILF?");
            Optional<Field> investInIlfOpt = ChecklistUtils.getFieldById(screenCheckList, INVESTED_IN_ILF_FIELD);
            reinvestedInIlf.setSelectedValue(investInIlfOpt.map(Field::getSelectedValue).orElse(null));


    }

    private void evaluatePremiumWithAssets(Group group, ScreenDescription screenCheckList) {

        var premiumWithAssets = (SelectInputField) ChecklistUtils.getFieldInGroup(group, PREMIUM_WITH_ASSETS_FIELD);
            if (premiumWithAssets == null) {
                premiumWithAssets = SelectInputField.builder().fieldId(PREMIUM_WITH_ASSETS_FIELD).build();
                group.getFields().add(premiumWithAssets);
            }
            premiumWithAssets.setIsActive(true);
            premiumWithAssets.incrementOrder();
            premiumWithAssets.setLabel("Premium with assets");
            Optional<Field> premiumWithAssetsOpt = ChecklistUtils.getFieldById(screenCheckList, PREMIUM_WITH_ASSETS_FIELD);
            premiumWithAssets.setSelectedValue(premiumWithAssetsOpt.map(Field::getSelectedValue).orElse(null));
    }


}
