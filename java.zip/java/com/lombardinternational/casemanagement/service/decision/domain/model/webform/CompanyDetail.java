package com.lombardinternational.casemanagement.service.decision.domain.model.webform;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class CompanyDetail {

    String companyId;
    String companyName;
    String partnerType;
}
