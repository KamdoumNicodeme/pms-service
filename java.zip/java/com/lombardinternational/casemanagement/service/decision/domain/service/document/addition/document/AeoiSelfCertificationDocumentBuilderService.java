package com.lombardinternational.casemanagement.service.decision.domain.service.document.addition.document;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.DocumentDefinition;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebFormGroup;
import com.lombardinternational.casemanagement.service.decision.domain.service.document.AbstractDocumentBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.utils.DocumentUtils;
import com.lombardinternational.casemanagement.service.decision.domain.utils.WebformUtils;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.DocumentConstants.*;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.WebFormFieldConstants.POLICY_NUMBER_WF;

@Service
public class AeoiSelfCertificationDocumentBuilderService extends AbstractDocumentBuilderService {

    @Override
    public void buildDocument(final WebForm webForm, final ScreenDescription screenDescription, String transactionNumber,
            List<DocumentDefinition> documents) {

        StringBuilder relatedToBuilder = new StringBuilder();
        StringBuilder i18nRelatedToParamBuilder = new StringBuilder();
        StringBuilder relatedToThirdPartyBuilder = new StringBuilder();
        HashMap<Object,WebFormGroup> fieldParent = new HashMap<>();
        List<WebFormGroup> groups = new ArrayList<>();

        WebformUtils.getWebFormObjectsById("ADD_TAX_COUNTRY", webForm, null, null, groups, fieldParent);

        for (WebFormGroup group : groups) {
            if (group != null && CollectionUtils.isNotEmpty(group.getGroups())) {
                for (int ii = 0; ii < group.getGroups().size(); ii++) {
                    WebFormGroup currentGroup = group.getGroups().get(ii);
                    String country = WebformUtils.getWebFormFieldValueById(currentGroup, "COUNTRY");
                    String taxIdentificationNumber = WebformUtils.getWebFormFieldValueById(currentGroup, "TAX_IDENTIFICATION_NUMBER");
                    WebFormGroup policyHolderAEOI = fieldParent.get(group);
                    WebFormGroup parent = fieldParent.get(policyHolderAEOI);
                    WebFormGroup policyHolderPhysical = WebformUtils.getGroupInGroup(parent, "POLICY_HOLDER_PHYSICAL");
                    if (policyHolderPhysical != null) {
                        String clientNumber = WebformUtils.getWebFormFieldValueById(policyHolderPhysical, "CLIENT_NUMBER");
                        String firstName = WebformUtils.getWebFormFieldValueById(policyHolderPhysical, "FIRSTNAME");
                        String lastName = WebformUtils.getWebFormFieldValueById(policyHolderPhysical, "SURNAME");
                        DocumentUtils.buildRelatedTo(relatedToBuilder, "Client", lastName, firstName, clientNumber);
                        relatedToBuilder.append(" - ").append(country).append(" ").append(taxIdentificationNumber).append("¬");
                        i18nRelatedToParamBuilder.append(firstName).append(" ").append(lastName).append(" - ").append(country).append(" ")
                                .append(taxIdentificationNumber).append("¬");
                        relatedToThirdPartyBuilder.append(clientNumber).append("¬");
                    }
                    WebFormGroup policyHolderCompany = WebformUtils.getGroupInGroup(parent, "POLICY_HOLDER_COMPANY");
                    if (policyHolderCompany != null) {
                        String clientNumber = WebformUtils.getWebFormFieldValueById(policyHolderCompany, "CLIENT_NUMBER");
                        String companyName = WebformUtils.getWebFormFieldValueById(policyHolderCompany, "COMPANY_NAME");
                        DocumentUtils.buildRelatedTo(relatedToBuilder, "Client", companyName, null, clientNumber);
                        relatedToBuilder.append(" - ").append(country).append(" ").append(taxIdentificationNumber).append("¬");
                        i18nRelatedToParamBuilder.append(companyName).append(" - ").append(country).append(" ").append(taxIdentificationNumber)
                                .append("¬");
                        relatedToThirdPartyBuilder.append(clientNumber).append("¬");
                    }
                }
            }
        }
        var relatedToPolicy = WebformUtils.getWebFormFieldValueById(webForm, POLICY_NUMBER_WF);
        var relatedTo = relatedToBuilder.toString();
        var i18nRelatedToParam = i18nRelatedToParamBuilder.toString();
        var relatedToThirdParty = relatedToThirdPartyBuilder.toString();

        buildDocumentDefinition(relatedTo, relatedToPolicy, i18nRelatedToParam, relatedToThirdParty, documents);
    }

    @Override
    protected String getDocumentType() {

        return AEOI_FORM_DOC_TYPE;
    }

    @Override
    protected String getCmsDocumentType() {

        return AEOI_FORM_CMS_DOC_TYPE;
    }

    @Override
    protected String getDescription() {

        return AEOI_SELF_CERTIFICATION_FORM_DESCRIPTION;
    }

    @Override
    protected String getI18NDescription() {

        return AEOI_SELF_CERTIFICATION_FORM_I18N_DESCRIPTION;
    }

    @Override
    protected String getI18NDocumentRelatedTo() {

        return CLIENT_I18N_DOCUMENT_RELATED_TO;
    }

    @Override
    protected boolean getDocumentVisibleOnConnect() {

        return true;
    }
}
