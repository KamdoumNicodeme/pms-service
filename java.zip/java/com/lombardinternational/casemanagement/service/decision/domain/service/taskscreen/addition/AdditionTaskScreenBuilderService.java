package com.lombardinternational.casemanagement.service.decision.domain.service.taskscreen.addition;

import java.util.Collections;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Tab;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.taskscreen.SubTaskScreenBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.taskscreen.TaskScreenBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.taskscreen.addition.subtask.ComplianceAdditionSubTaskScreenBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.taskscreen.addition.subtask.DotAdditionSubTaskScreenBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.taskscreen.addition.subtask.IcAdditionSubTaskScreenBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.utils.RulesUtils;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.TaskScreenConstants.TASK_DEFINITION_TAB;

@Service
public class AdditionTaskScreenBuilderService implements TaskScreenBuilderService {

    private final List<SubTaskScreenBuilderService> subTaskScreenBuilderServiceList;

    public AdditionTaskScreenBuilderService(DotAdditionSubTaskScreenBuilderService dotAdditionSubTaskScreenBuilderService,
            ComplianceAdditionSubTaskScreenBuilderService complianceAdditionSubTaskScreenBuilderService,
            IcAdditionSubTaskScreenBuilderService icAdditionSubTaskScreenBuilderService) {

        subTaskScreenBuilderServiceList = List.of(dotAdditionSubTaskScreenBuilderService, complianceAdditionSubTaskScreenBuilderService,
                icAdditionSubTaskScreenBuilderService);
    }

    @Override
    public ScreenDescription buildTaskScreen(WebForm webForm, ScreenDescription screenCheckList, ScreenDescription screenToFill) {

        Optional<SubTaskScreenBuilderService> optionalSubTaskScreenBuilderService = subTaskScreenBuilderServiceList.stream()
                .filter(subTaskScreenBuilderService -> subTaskScreenBuilderService.filterService(screenToFill.getScreenId())).findFirst();
        if (optionalSubTaskScreenBuilderService.isPresent()) {
            Tab taskDefinition = RulesUtils.getTabInScreenDescription(screenToFill, TASK_DEFINITION_TAB);
            if (taskDefinition == null) {
                taskDefinition = Tab.builder().tabId(TASK_DEFINITION_TAB).order(1).type("FormTab").label("Task definition").build();
                screenToFill.setTabs(Collections.singletonList(taskDefinition));
            }
            taskDefinition.setIsActive(true);
            return optionalSubTaskScreenBuilderService.get().buildSubTaskScreen(webForm, screenCheckList, screenToFill, taskDefinition);
        }
        return null;
    }
}
