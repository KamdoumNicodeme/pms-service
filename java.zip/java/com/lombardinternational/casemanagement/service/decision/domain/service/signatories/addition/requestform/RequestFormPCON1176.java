package com.lombardinternational.casemanagement.service.decision.domain.service.signatories.addition.requestform;

import com.lombardinternational.casemanagement.service.decision.domain.model.policy.Policy;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.DocumentRequiredSignatory;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.RequiredSignatory;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control.common.Utils;
import com.lombardinternational.casemanagement.service.decision.domain.service.signatories.AbstractDocumentRequiredSignatoryBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.utils.Constraint;
import com.lombardinternational.casemanagement.service.decision.domain.utils.FieldConstraint;
import com.lombardinternational.casemanagement.service.decision.domain.utils.SignatoryUtils;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.SignatoryConstants.PCON1176;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.WebFormFieldConstants.*;

@Service
public class RequestFormPCON1176 extends AbstractDocumentRequiredSignatoryBuilderService {

    @Override
    public void buildRequiredSignatory(final WebForm webForm, final Policy policy,
            final List<DocumentRequiredSignatory> documentRequiredSignatories, final List<RequiredSignatory> signatories) {

        final List<FieldConstraint> constraints =
                List.of(Utils.createConstraint(COUNTRY_OF_LAW, Constraint.EQUALS, Collections.singletonList("CY")),
                        Utils.createConstraint(TARGET_MARKET, Constraint.EQUALS, Collections.singletonList("NT")),
                        Utils.createConstraint(B_CODE, Constraint.IN, SignatoryUtils.buildBFFMBrokerCode()));

        if (constraints.stream().allMatch(constraint -> constraint.test(webForm))) {
            List<RequiredSignatory> requiredSignatories = buildRequiredSignatories(signatories, List.of("POLICY_HOLDER", "SIGNATORY"));

            buildDocumentRequiredSignatory(documentRequiredSignatories, requiredSignatories);
        }
    }

    @Override
    protected String getDocumentType() {

        return PCON1176;
    }
}
