package com.lombardinternational.casemanagement.service.decision.domain.service.document.addition.document;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.DocumentDefinition;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebFormField;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebFormGroup;
import com.lombardinternational.casemanagement.service.decision.domain.service.document.AbstractDocumentBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.utils.DocumentUtils;
import com.lombardinternational.casemanagement.service.decision.domain.utils.WebformUtils;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.DocumentConstants.*;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.WebFormFieldConstants.POLICY_NUMBER_WF;

@Service
public class ProofResidenceAmendedAddressDocumentBuilderService extends AbstractDocumentBuilderService {

    @Override
    public void buildDocument(final WebForm webForm, final ScreenDescription screenDescription, String transactionNumber,
            List<DocumentDefinition> documents) {

        StringBuilder relatedToBuilder = new StringBuilder();
        StringBuilder i18nRelatedToParamBuilder = new StringBuilder();
        StringBuilder relatedToThirdPartyBuilder = new StringBuilder();
        HashMap<Object,WebFormGroup> fieldParent = new HashMap<>();
        List<WebFormField> fields = new ArrayList<>();

        WebformUtils.getWebFormObjectsById("CHANGE_ADDRESS", webForm, null, fields, null, fieldParent);

        for (WebFormField field : fields) {
            if ("true".equals(WebformUtils.getValueForWebFormField(field))) {
                WebFormGroup address = fieldParent.get(field);
                WebFormGroup holderCountGroup = fieldParent.get(address);

                WebFormGroup policyHolderPhysical = WebformUtils.getGroupInGroup(holderCountGroup, "POLICY_HOLDER_PHYSICAL");
                if (policyHolderPhysical != null) {

                    String firstName = WebformUtils.getWebFormFieldValueById(policyHolderPhysical, "FIRSTNAME");
                    String lastName = WebformUtils.getWebFormFieldValueById(policyHolderPhysical, "SURNAME");
                    String clientNumber = WebformUtils.getWebFormFieldValueById(policyHolderPhysical, "CLIENT_NUMBER");
                    DocumentUtils.buildRelatedTo(relatedToBuilder, "Client", lastName, firstName, clientNumber);
                    relatedToBuilder.append("¬");
                    i18nRelatedToParamBuilder.append(firstName).append(" ").append(lastName).append("¬");
                    relatedToThirdPartyBuilder.append(clientNumber).append("¬");
                }

                WebFormGroup policyHolderCompany = WebformUtils.getGroupInGroup(holderCountGroup, "POLICY_HOLDER_COMPANY");
                if (policyHolderCompany != null) {

                    String companyName = WebformUtils.getWebFormFieldValueById(policyHolderCompany, "COMPANY_NAME");
                    String clientNumber = WebformUtils.getWebFormFieldValueById(policyHolderCompany, "CLIENT_NUMBER");
                    DocumentUtils.buildRelatedTo(relatedToBuilder, "Client", companyName, null, clientNumber);
                    relatedToBuilder.append("¬");
                    i18nRelatedToParamBuilder.append(companyName).append("¬");
                    relatedToThirdPartyBuilder.append(clientNumber).append("¬");
                }
            }
        }
        var relatedToPolicy = WebformUtils.getWebFormFieldValueById(webForm, POLICY_NUMBER_WF);
        var relatedTo = relatedToBuilder.toString();
        var i18nRelatedToParam = i18nRelatedToParamBuilder.toString();
        var relatedToThirdParty = relatedToThirdPartyBuilder.toString();

        buildDocumentDefinition(relatedTo, relatedToPolicy, i18nRelatedToParam, relatedToThirdParty, documents);
    }

    @Override
    protected String getDocumentType() {

        return PROOF_RESIDENCE_DOC_TYPE;
    }

    @Override
    protected String getCmsDocumentType() {

        return PROOF_RESIDENCE_CMS_DOC_TYPE;
    }

    @Override
    protected String getDescription() {

        return PH_PROOF_OF_RESIDENCE_AMENDED_ADDRESS_FORM_DESCRIPTION;
    }

    @Override
    protected String getI18NDescription() {

        return PH_PROOF_OF_RESIDENCE_AMENDED_ADDRESS_FORM_I18N_DESCRIPTION;
    }

    @Override
    protected String getI18NDocumentRelatedTo() {

        return CLIENT_I18N_DOCUMENT_RELATED_TO;
    }

    @Override
    protected boolean getDocumentVisibleOnConnect() {

        return true;
    }

    @Override
    protected boolean getDocumentRequired() {

        return true;
    }
}
