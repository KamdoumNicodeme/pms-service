package com.lombardinternational.casemanagement.service.decision.domain.utils.constants;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public final class ChecklistFieldConstants {

    // TAB ID
    public static final String CHECKLIST_TAB = "CHECKLIST";

    // GENERAL_DETAILS GROUP
    public static final String CONTRACT_TYPE = "CONTRACT_TYPE";
    public static final String POLICY_NUMBER = "POLICY_NUMBER";
    public static final String POLICY_CURRENCY = "POLICY_CURRENCY";
    public static final String IS_MULTISUPPORT = "IS_MULTISUPPORT";
    public static final String POLICY_NAV_EUR = "POLICY_NAV_EUR";
    public static final String ALL_POLICY_NAV_EUR = "ALL_POLICY_NAV_EUR";
    public static final String TOTAL_POLICY_NAV_POLICY_CCY = "TOTAL_POLICY_NAV_POLICY_CCY";
    public static final String TOTAL_POLICY_NAV_EXCLUDING_EXPECTED_PREMIUM = "TOTAL_POLICY_NAV_EXCLUDING_EXPECTED_PREMIUM";
    public static final String BE_POLICY_NAV_EUR = "BE_POLICY_NAV_EUR";
    public static final String TRANSACTION_AMOUNT_CUR = "TRANSACTION_AMOUNT_CUR";
    public static final String TRANSACTION_AMOUNT = "TRANSACTION_AMOUNT";
    public static final String FISCAL_INFORMATION_STILL_VALID = "FISCAL_INFORMATION_STILL_VALID";
    public static final String COUNTRY_OF_APPLICABLE_LAW = "COUNTRY_OF_APPLICABLE_LAW";
    public static final String COUNTRY_OF_LAW = "COUNTRY_OF_LAW";
    public static final String TAX_COUNTRY = "TAX_COUNTRY";
    public static final String BUSINESS_ORIGIN = "BUSINESS_ORIGIN";
    public static final String RESIDENCE_COUNTRY = "RESIDENCE_COUNTRY";
    public static final String PH_RESIDENCE_COUNTRY = "PH_RESIDENCE_COUNTRY";
    public static final String OFF_SHORE_INDICIA = "OFF_SHORE_INDICIA";
    public static final String PH_TYPE_ASSESSMENT = "PH_TYPE_ASSESSMENT";
    public static final String PH_LEGAL_ENTITY = "PH_LEGAL_ENTITY";
    public static final String PREM_PAID_FROM_BEN = "PREM_PAID_FROM_BEN";
    public static final String REQUEST_FORM_RECEIVED = "REQUEST_FORM_RECEIVED";
    public static final String THIRD_PARTY_SUB_TYPE_FOR_PH = "THIRD_PARTY_SUB_TYPE_FOR_PH";
    public static final String THIRD_PARTY_SUB_TYPE_PH = "THIRD_PARTY_SUB_TYPE_PH";
    public static final String MRL_TRUSTEE = "MRL_TRUSTEE";
    public static final String TRUST = "TRUST";
    public static final String TRUST_COUNTRY = "TRUST_COUNTRY";
    public static final String TRUSTEE = "TRUSTEE";
    public static final String TRUSTEE_COUNTRY = "TRUSTEE_COUNTRY";
    public static final String SETTLOR = "SETTLOR";
    public static final String SETTLOR_COUNTRY = "SETTLOR_COUNTRY";
    public static final String CESSION_HOLDER = "CESSION_HOLDER";
    public static final String CESSION_HOLDER_COUNTRY = "CESSION_HOLDER_COUNTRY";
    public static final String PROXY = "PROXY";
    public static final String PROXY_COUNTRY = "PROXY_COUNTRY";
    public static final String SIGNATORY_MAX_RISK = "PROXY_COUNTRY";
    public static final String LA_RESIDENCE_COUNTRY = "LA_RESIDENCE_COUNTRY";
    public static final String SENDING_ADDRESS_COUNTRY = "SENDING_ADDRESS_COUNTRY";
    public static final String BENEFICIARY = "BENEFICIARY";
    public static final String BENEFICIARY_COUNTRY = "BENEFICIARY_COUNTRY";
    public static final String IRREVOCABLE_BEN = "IRREVOCABLE_BEN";
    public static final String IRREVOCABLE_BEN_COUNTRY = "IRREVOCABLE_BEN_COUNTRY";
    public static final String LA_DIFFERENT_TO_PH = "LA_DIFFERENT_TO_PH";
    public static final String LA_DIFFERENT_TO_BEN = "LA_DIFFERENT_TO_BEN";
    public static final String PH_DIFFERENT_TO_EBO = "PH_DIFFERENT_TO_EBO";
    public static final String EBO_COUNTRY = "EBO_COUNTRY";
    public static final String NEW_US_INDICIA = "NEW_US_INDICIA";
    public static final String FORM_SIGNER = "FORM_SIGNER";
    public static final String TP_BLOCK = "TP_BLOCK";
    public static final String FORMER_SWISS_PH = "FORMER_SWISS_PH";
    public static final String FORMER_SWISS_EBO = "FORMER_SWISS_EBO";
    public static final String FORMER_SWISS_LA = "FORMER_SWISS_LA";
    public static final String PROOF_DEREGISTRATION_PH = "PROOF_DEREGISTRATION_PH";
    public static final String PROOF_DEREGISTRATION_EBO = "PROOF_DEREGISTRATION_EBO";
    public static final String PROOF_DEREGISTRATION_LA = "PROOF_DEREGISTRATION_LA";
    public static final String AML_CLAUSE = "AML_CLAUSE";
    public static final String POLICY_SIGNED_COUNTRY = "POLICY_SIGNED_COUNTRY";
    public static final String PH_RESIDENCE_COUNTRY_RISK = "PH_RESIDENCE_COUNTRY_RISK";
    public static final String EBO_RESIDENCE_COUNTRY_RISK = "EBO_RESIDENCE_COUNTRY_RISK";
    public static final String LA_RESIDENCE_COUNTRY_RISK = "LA_RESIDENCE_COUNTRY_RISK";
    public static final String PH_FISCAL_COUNTRY = "PH_FISCAL_COUNTRY";
    public static final String US_INDICIA = "US_INDICIA";
    public static final String RDR_COMPLIANT = "RDR_COMPLIANT";
    public static final String EXPECTED_PREM = "EXPECTED_PREM";
    public static final String ACCOUNT_OPENED_IN_EEA = "ACCOUNT_OPENED_IN_EEA";
    public static final String ESG_MANDATE_SELECTED = "ESG_MANDATE_SELECTED";
    public static final String FAMILY_CASE_TOTAL_AMOUNT = "FAMILY_CASE_TOTAL_AMOUNT";
    public static final String IS_IT_THE_LAST_INSTALLMENT = "IS_IT_THE_LAST_INSTALLMENT";

    // ADDED_INFO GROUP
    public static final String THIRD_PARTY_NAME = "THIRD_PARTY_NAME";
    public static final String LINK_THIRD_PARTY_PH = "LINK_THIRD_PARTY_PH";
    public static final String REASON_THIRD_PARTY_PAYMENT = "REASON_THIRD_PARTY_PAYMENT";
    public static final String THIRD_PARTY_COUNTRY = "THIRD_PARTY_COUNTRY";
    public static final String THIRD_PARTY_COUNTRY_RISK = "THIRD_PARTY_COUNTRY_RISK";

    // TRANSACTION_DETAILS GROUP
    public static final String PREMIUM_WITH_ASSETS = "PREMIUM_WITH_ASSETS";
    public static final String PREMIUM_WITH_UNQ_ASSETS = "PREMIUM_WITH_UNQ_ASSETS";
    public static final String INVESTED_IN_ILF = "INVESTED_IN_ILF";
    public static final String EXISTING_ILF = "EXISTING_ILF";
    public static final String ILF_MNEMONIC = "ILF_MNEMONIC";
    public static final String PAYMENT_THIRD_PARTY = "PAYMENT_THIRD_PARTY";
    public static final String NEGATIVE_FINDING_PAYERS = "NEGATIVE_FINDING_PAYERS";
    public static final String PAYER_IN_SANCTION_LIST = "PAYER_IN_SANCTION_LIST";
    public static final String RATIONALE_FOR_INVESTMENT = "RATIONALE_FOR_INVESTMENT";
    public static final String NUMBER_OF_ORIGINATING_ACCOUNTS = "NUMBER_OF_ORIGINATING_ACCOUNTS";
    public static final String HOLDER_OF_ORIGINATING_ACCOUNTS = "HOLDER_OF_ORIGINATING_ACCOUNTS";
    public static final String COUNTRY_OF_ORIGINATING_ACCOUNTS = "COUNTRY_OF_ORIGINATING_ACCOUNTS";
    public static final String BANK_OF_ORIGINATING_ACCOUNTS = "BANK_OF_ORIGINATING_ACCOUNTS";
    public static final String COUNTRY_OF_ORIGINATING_ACCOUNTS_RISK = "COUNTRY_OF_ORIGINATING_ACCOUNTS_RISK";
    public static final String PAYER_CORPORATE_ENTITY_SHR = "PAYER_CORPORATE_ENTITY_SHR";
    public static final String PAYER_TAX_COUNTRY_DIFFER_PH_EBO = "PAYER_TAX_COUNTRY_DIFFER_PH_EBO";
    public static final String EVIDENCE_ENTITY_KNOWN = "EVIDENCE_ENTITY_KNOWN";
    public static final String SUPPORTING_DOCUMENTATION = "SUPPORTING_DOCUMENTATION";
    public static final String PREMIUM_DIFFER_FROM_EXPECTED = "PREMIUM_DIFFER_FROM_EXPECTED";
    public static final String FUND_ORIGIN_SAME_AS_DISCLOSED = "FUND_ORIGIN_SAME_AS_DISCLOSED";
    public static final String FUND_COUNTRY_DIFFER_TAX_COUNTRY = "FUND_COUNTRY_DIFFER_TAX_COUNTRY";
    public static final String ECONOMIC_JUSTIFICATION = "ECONOMIC_JUSTIFICATION";
    public static final String ECONOMIC_JUSTIF = "ECONOMIC_JUSTIF";
    public static final String EVIDENCE_BANK_ACCOUNT_KNOWN = "EVIDENCE_BANK_ACCOUNT_KNOWN";
    public static final String PH_REFUSE_TO_PROVIDE_EVIDENCE = "PH_REFUSE_TO_PROVIDE_EVIDENCE";
    public static final String FATCA_FORM_REFUSED = "FATCA_FORM_REFUSED";
    public static final String FATCA_FORM_INCONSISTENT = "FATCA_FORM_INCONSISTENT";
    public static final String TAX_RESIDENCE_INCONSISTENT = "TAX_RESIDENCE_INCONSISTENT";
    public static final String PH_NON_FINANCIAL = "PH_NON_FINANCIAL";
    public static final String ENTITY_SAME_AS_FATCA = "ENTITY_SAME_AS_FATCA";
    public static final String CLOSE_TO_EBO = "CLOSE_TO_EBO";
    public static final String PREMIUM_RECEIVED_DIFFERENT_EXPECTED = "PREMIUM_RECEIVED_DIFFERENT_EXPECTED";
    public static final String SAME_AS_DISCLOSED = "SAME_AS_DISCLOSED";
    public static final String SIX_MONTHS_AFTER_SIGNED = "SIX_MONTHS_AFTER_SIGNED";
    public static final String KYC_SUPPORTING_DOCUMENTS = "KYC_SUPPORTING_DOCUMENTS";
    public static final String BANK_NOT_IN_RESIDENCE = "BANK_NOT_IN_RESIDENCE";
    public static final String EVIDENCE_TAX_DECLARED = "EVIDENCE_TAX_DECLARED";
    public static final String REFUSED_ADDITIONAL_INFO = "REFUSED_ADDITIONAL_INFO";
    public static final String IC_ASSET = "IC_ASSET";
    public static final String DAILY_OPERATION_TEAM = "DAILY_OPERATION_TEAM";
    public static final String PREMIUM_CHASING = "PREMIUM_CHASING";
    public static final String FREE_TASK = "FREE_TASK";
    public static final String AML_SIGN_OFF = "AML_SIGN_OFF";
    public static final String ILF_SET_UP = "ILF_SET_UP";

    // DUE_DILIGENCE GROUP
    public static final String INDUSTRY = "INDUSTRY";
    public static final String POSITION = "POSITION";
    public static final String BACKGROUND_DETAILS = "BACKGROUND_DETAILS";
    public static final String RISK_ASSESSMENT = "RISK_ASSESSMENT";
    public static final String PEP = "PEP";
    public static final String ORIGINATOR_PEP = "ORIGINATOR_PEP";
    public static final String IS_PEP_PAYER = "IS_PEP_PAYER";
    public static final String KYC_MANDATORY = "KYC_MANDATORY";
    public static final String NEW_KYC_OBTAINED = "NEW_KYC_OBTAINED";
    public static final String INTRODUCING_PARTNER_SIGNED = "INTRODUCING_PARTNER_SIGNED";
    public static final String INFO_PROVIDED_VERIFIED = "INFO_PROVIDED_VERIFIED";
    public static final String NEW_KYC_IN_LINE = "NEW_KYC_IN_LINE";
    public static final String IS_SAME_ORIGIN_PREMIUM = "IS_SAME_ORIGIN_PREMIUM";
    public static final String NEW_ORIGIN_PREM_CLASS = "NEW_ORIGIN_PREM_CLASS";
    public static final String NEGATIVE_FINDING = "NEGATIVE_FINDING";
    public static final String NEGATIVE_FINDING_THIRD_PARTY = "NEGATIVE_FINDING_THIRD_PARTY";
    public static final String NEGATIVE_SINCE_TRANSACTION = "NEGATIVE_SINCE_TRANSACTION";
    public static final String AT_LEAST_ONE_SOW_OF_KIND = "AT_LEAST_ONE_SOW_OF_KIND";
    public static final String IS_ON_SANCTION_LIST = "IS_ON_SANCTION_LIST";
    public static final String INSIDER = "INSIDER";
    public static final String IS_PH_EBO_GOLDEN_VISA = "IS_PH_EBO_GOLDEN_VISA";
    public static final String ANNUAL_INCOME = "ANNUAL_INCOME";
    public static final String ANNUAL_INCOME_FORCED = "ANNUAL_INCOME_FORCED";
    public static final String SOURCE_OF_WEALTH = "SOURCE_OF_WEALTH";
    public static final String TWENTY_PERCENT_INCOME = "20_PERCENT_INCOME";
    public static final String SOURCE_OF_WEALTH_EDITABLE = "SOURCE_OF_WEALTH_EDITABLE";
    public static final String WEALTH_ALLOCATION_OK = "WEALTH_ALLOCATION_OK";
    public static final String WEALTH_ORIGINATING_COUNTRY_1 = "WEALTH_ORIGINATING_COUNTRY_1";
    public static final String WEALTH_ORIGINATING_COUNTRY_1_RISK = "WEALTH_ORIGINATING_COUNTRY_1_RISK";
    public static final String WEALTH_ORIGINATING_COUNTRY_2 = "WEALTH_ORIGINATING_COUNTRY_2";
    public static final String WEALTH_ORIGINATING_COUNTRY_2_RISK = "WEALTH_ORIGINATING_COUNTRY_2_RISK";
    public static final String WEALTH_ALLOCATION = "WEALTH_ALLOCATION";
    public static final String TOTAL_WEALTH = "TOTAL_WEALTH";

    // INTERMEDIATION GROUP
    public static final String INTRODUCING_PARTNER_CODE = "INTRODUCING_PARTNER_CODE";
    public static final String PARTNER_TYPE = "PARTNER_TYPE";
    public static final String IS_PH_REPRESENTATIVE = "IS_PH_REPRESENTATIVE";
    public static final String TCC_SIGNED = "TCC_SIGNED";
    public static final String TCC_SIGNED_REFUSED = "TCC_SIGNED_REFUSED";
    public static final String TCC_IN_FOLDER = "TCC_IN_FOLDER";
    public static final String NO_INVESTMENT_PROFILE = "NO_INVESTMENT_PROFILE";
    public static final String NEW_INVESTMENT_PROFILE = "NEW_INVESTMENT_PROFILE";
    public static final String NO_SUSTAINABILITY_PREFERENCE = "NO_SUSTAINABILITY_PREFERENCE";
    public static final String NEW_SUSTAINABILITY_PREFERENCE = "NEW_SUSTAINABILITY_PREFERENCE";
    public static final String APP_FORM_SIGNER = "APP_FORM_SIGNER";
    public static final String DS_CONSENT_RECEIVED = "DS_CONSENT_RECEIVED";
    public static final String NB_INTERMEDIATED_DS = "NB_INTERMEDIATED_DS";
    public static final String VIDEO_RECEIVED = "VIDEO_RECEIVED";
    public static final String CLIENT_IDENTIFIABLE = "CLIENT_IDENTIFIABLE";
    public static final String HASH_CHECK_PERFORMED = "HASH_CHECK_PERFORMED";
    public static final String PASSPORT_CHECK_PERFORMED = "PASSPORT_CHECK_PERFORMED";
    public static final String VULNERABLE_INDICIA_DETECTED = "VULNERABLE_INDICIA_DETECTED";
    public static final String PRICING_APPROVAL_CHECKED = "PRICING_APPROVAL_CHECKED";

    // LIFE_COVER GROUP
    public static final String LIFE_COVER_TYPE = "LIFE_COVER_TYPE";
    public static final String SAR = "SAR";
    public static final String UNDER_WRITINGS = "UNDERWRITINGS";

    // SIGNOFF GROUP
    public static final String TRANSACTION_FEEDBACK = "TRANSACTION_FEEDBACK";
    public static final String COMMENTS = "COMMENTS";
    public static final String LAST_REVIEW_DATE = "LAST_REVIEW_DATE";
    public static final String BAC_APPROVAL = "BAC_APPROVAL";

    public static final String WHEN_HAPPENED = "WHEN_HAPPENED";
    public static final String ORIGINATOR_NAME = "ORIGINATOR_NAME";
    public static final String INDUSTRY_RISK = "INDUSTRY_RISK";
    public static final String FORCED_POSITION_RISK = "FORCED_POSITION_RISK";
    public static final String ORIGINATOR_WORLD_CHECK = "ORIGINATOR_WORLD_CHECK";
    public static final String LINK_WITH_EBO = "LINK_WITH_EBO";
    public static final String COMPANY_NAME = "COMPANY_NAME";
    public static final String ORIGINATOR_INDUSTRY_SECTOR = "ORIGINATOR_INDUSTRY_SECTOR";
    public static final String ORIGINATOR_POSITION = "ORIGINATOR_POSITION";
    public static final String COUNTRY_WEALTH_ = "COUNTRY_WEALTH_";
    public static final String _RISK = "_RISK";

    public static final String UNDER_WRITINGS_OPTIONS = "UNDER_WRITINGS_OPTIONS";
    public static final String CONTRIBUTOR_LINK = "CONTRIBUTOR_LINK";
    public static final String PROFESSION = "PROFESSION";

    // GROUP ID
    public static final String GENERAL_DETAILS_GROUP = "GENERAL_DETAILS";
    public static final String INTERMEDIATION_GROUP = "INTERMEDIATION";
    public static final String DUE_DILIGENCE_GROUP = "DUE_DILIGENCE";

    public static final String TRANSACTION_DETAILS_GROUP = "TRANSACTIONS_DETAILS";

    public static final String THIRD_PARTY_GROUP = "THIRD_PARTY";
    public static final String LIFE_COVER_GROUP = "LIFE_COVER";
    public static final String SIGNOFFS_GROUP = "SIGNOFFS";
    public static final String SOURCE_OF_WEALTH_GROUP = "SOURCE_OF_WEALTH_GROUP";
    public static final String CASE_RISK_GROUP = "CASE_RISK";

    // CASE_RISK GROUP
    public static final String PCS_REVIEW = "PCS_REVIEW";
    public static final String RISK_VALUE = "RISK_VALUE";
    public static final String RISK_REASON = "RISK_REASON";
    public static final String BLOCKED_VALUE = "BLOCKED_VALUE";
    public static final String SIGNATURE_TYPE = "SIGNATURE_TYPE";
    public static final String SIGNATURE_GROUP = "SIGNATURE";
    public static final String PROVIDER_GROUP = "PROVIDER";
    public static final String EU_AUTHORIZED_PROVIDER_GROUP = "EU_AUTHORIZED_PROVIDER";
    public static final String PROVIDER = "PROVIDER";
    public static final String CLIENT_IDENTIFICATION_VALIDATION = "CLIENT_IDENTIFICATION_VALIDATION";
    public static final String MULTIFACTOR_AUTHENTICATION = "MULTIFACTOR_AUTHENTICATION";
    public static final String ORIGNAL_SIGNED_DOCUMENT_AUDIT_LOG_CMT = "ORIGNAL_SIGNED_DOCUMENT_AUDIT_LOG_CMT";

}
