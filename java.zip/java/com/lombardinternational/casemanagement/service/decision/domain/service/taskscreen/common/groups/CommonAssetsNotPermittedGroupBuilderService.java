package com.lombardinternational.casemanagement.service.decision.domain.service.taskscreen.common.groups;

import org.springframework.stereotype.Service;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Group;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Tab;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.taskscreen.TaskScreenGroupBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.taskscreen.common.fields.CommonAssetsNotPermittedFieldsBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.utils.RulesUtils;

import lombok.AllArgsConstructor;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.TaskScreenConstants.ASSETS_NOT_PERMITTED_GROUP;

@Service
@AllArgsConstructor
public class CommonAssetsNotPermittedGroupBuilderService implements TaskScreenGroupBuilderService {

    private final CommonAssetsNotPermittedFieldsBuilderService service;

    @Override
    public void buildGroup(final WebForm webForm, final ScreenDescription screenCheckList, final ScreenDescription screenToFill,
            final Tab parentTab) {

        var assetsNotPermitted = RulesUtils.getGroupInTab(parentTab, ASSETS_NOT_PERMITTED_GROUP);
        if (assetsNotPermitted == null) {
            assetsNotPermitted = Group.builder().groupId(ASSETS_NOT_PERMITTED_GROUP).build();
            parentTab.getGroups().add(assetsNotPermitted);
        }
        assetsNotPermitted.setIsActive(true);
        assetsNotPermitted.incrementOrder();
        assetsNotPermitted.setTitle("Assets not permitted under the investment strategy:");
        service.buildField(webForm, screenCheckList, screenToFill, assetsNotPermitted);
    }
}
