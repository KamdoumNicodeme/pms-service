package com.lombardinternational.casemanagement.service.decision.domain.service.signatories.addition.kyc;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.collections4.CollectionUtils;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.DocumentRequiredSignatory;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.RequiredSignatory;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebFormGroup;
import com.lombardinternational.casemanagement.service.decision.domain.service.signatories.AbstractDocumentRequiredSignatoryBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.utils.WebformUtils;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.WebFormFieldConstants.*;

public abstract class KycCont extends AbstractDocumentRequiredSignatoryBuilderService {

    public void buildDocumentRequiredSignatoryPhysical(final WebForm webForm, final List<DocumentRequiredSignatory> documentRequiredSignatories,
            final List<RequiredSignatory> signatories) {

        buildDocumentRequiredSignatoryGlobal(webForm, documentRequiredSignatories, EBO_TYPE_PHYSICAL, signatories);
    }

    public void buildDocumentRequiredSignatoryEntity(final WebForm webForm, final List<DocumentRequiredSignatory> documentRequiredSignatories,
            final List<RequiredSignatory> signatories) {

        buildDocumentRequiredSignatoryGlobal(webForm, documentRequiredSignatories, EBO_TYPE_ENTITY, signatories);
    }

    public void buildDocumentRequiredSignatorySC(final WebForm webForm, final List<DocumentRequiredSignatory> documentRequiredSignatories,
            final List<RequiredSignatory> signatories) {

        buildDocumentRequiredSignatoryGlobal(webForm, documentRequiredSignatories, EBO_TYPE_MORAL, signatories);
    }

    private void buildDocumentRequiredSignatoryGlobal(final WebForm webForm, final List<DocumentRequiredSignatory> documentRequiredSignatories,
            String eboType, final List<RequiredSignatory> signatories) {

        final var kycGrp = WebformUtils.getFirstWebFormGroupById(webForm, KYC_WF);
        if (Boolean.parseBoolean(WebformUtils.getWebFormFieldValueById(kycGrp, IS_KYC_REQUIRED_WF))) {
            final var detailsGrp = WebformUtils.getGroupInGroup(kycGrp, DETAILS_WF);
            if (detailsGrp != null) {
                final var ebosGrp = WebformUtils.getGroupInGroup(detailsGrp, EBO_KYCS_WF);
                List<WebFormGroup> eboKycGroup = retrieveEboGroupsByType(ebosGrp, eboType);
                eboKycGroup.forEach(
                        eboKycGrp -> this.buildDocumentRequiredSignatory(webForm, eboKycGrp, documentRequiredSignatories, signatories, eboType));
            }
        }
    }

    private void buildDocumentRequiredSignatory(final WebForm webForm, final WebFormGroup group,
            final List<DocumentRequiredSignatory> documentRequiredSignatories, final List<RequiredSignatory> signatories, final String eboType) {

        final var eboId = WebformUtils.getWebFormFieldValueById(group, EBO_ID_WF);
        List<RequiredSignatory> requiredSignatories;

        if (EBO_TYPE_PHYSICAL.equalsIgnoreCase(eboType)) {
            // We are supposed to keep only beneficial owner that are matching the ones defined contact details
            requiredSignatories =
                    signatories.stream()
                            .filter(signatory -> "INTERMEDIATE".equals(signatory.getType())
                                    || ("ECONOMICAL_BENEFICIAL_OWNER".equals(signatory.getType()) && eboId.equals(signatory.getThirdPartyId())))
                            .toList();
        } else {
            requiredSignatories =
                    signatories.stream().filter(signatory -> signatory.getType().matches("INTERMEDIATE|ECONOMICAL_BENEFICIAL_OWNER")).toList();
        }
        buildDocumentRequiredSignatory(documentRequiredSignatories, requiredSignatories, eboId);
    }

    private List<WebFormGroup> retrieveEboGroupsByType(WebFormGroup eboKycsGroup, String eboType) {

        var groups = new ArrayList<WebFormGroup>();
        if (eboType != null && eboKycsGroup != null && CollectionUtils.isNotEmpty(eboKycsGroup.getGroups())) {
            for (WebFormGroup eboKycGroup : eboKycsGroup.getGroups()) {
                var eboTypeField = WebformUtils.getWebFormFieldValueById(eboKycGroup, EBO_TYPE_WF);
                if (eboType.equalsIgnoreCase(eboTypeField)) {
                    groups.add(eboKycGroup);
                }
            }
        }
        return groups;
    }
}
