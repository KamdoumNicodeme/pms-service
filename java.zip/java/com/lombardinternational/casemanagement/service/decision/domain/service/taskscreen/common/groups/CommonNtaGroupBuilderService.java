package com.lombardinternational.casemanagement.service.decision.domain.service.taskscreen.common.groups;

import org.springframework.stereotype.Service;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Group;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Tab;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.taskscreen.TaskScreenGroupBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.taskscreen.common.fields.CommonNtaFieldsBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.utils.RulesUtils;

import lombok.AllArgsConstructor;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.TaskScreenConstants.NTA_GROUP;

@Service
@AllArgsConstructor
public class CommonNtaGroupBuilderService implements TaskScreenGroupBuilderService {

    private final CommonNtaFieldsBuilderService service;

    @Override
    public void buildGroup(final WebForm webForm, final ScreenDescription screenCheckList, final ScreenDescription screenToFill,
            final Tab parentTab) {

        var ntaGroup = RulesUtils.getGroupInTab(parentTab, NTA_GROUP);
        if (ntaGroup == null) {
            ntaGroup = Group.builder().groupId(NTA_GROUP).build();
            parentTab.getGroups().add(ntaGroup);
        }
        ntaGroup.setIsActive(true);
        ntaGroup.incrementOrder();
        ntaGroup.setTitle("Non Traditional Assets - Request NTA Acceptance.");
        service.buildField(webForm, screenCheckList, screenToFill, ntaGroup);
    }
}
