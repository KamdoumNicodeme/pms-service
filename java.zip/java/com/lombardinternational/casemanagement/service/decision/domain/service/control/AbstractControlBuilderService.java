package com.lombardinternational.casemanagement.service.decision.domain.service.control;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ControlDefinition;

public abstract class AbstractControlBuilderService implements ControlBuilderService {

    protected ControlDefinition buildControlDefinition() {

        final var controlDefinition = ControlDefinition.builder().controlName(getControlName()).controlType(getControlType()).build();
        controlDefinition.incrementOrder();
        return controlDefinition;
    }

    protected abstract String getControlName();

    protected abstract String getControlType();
}
