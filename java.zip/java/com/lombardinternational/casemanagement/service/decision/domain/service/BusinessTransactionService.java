package com.lombardinternational.casemanagement.service.decision.domain.service;

import java.util.List;
import java.util.stream.Stream;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.lombardinternational.casemanagement.service.decision.domain.configuration.RiskFactorsProperties;
import com.lombardinternational.casemanagement.service.decision.domain.model.transaction.BusinessTransaction;
import com.lombardinternational.casemanagement.service.decision.domain.spi.web.BusinessTransactionWebService;
import com.lombardinternational.casemanagement.service.decision.domain.spi.web.ComplianceWebService;

import lombok.AllArgsConstructor;

@Service
@AllArgsConstructor
public class BusinessTransactionService {

    private static final String EUR_ISO_CODE_CURRENCY = "EUR";
    private static final String POLICY_SERVICING = "POLICY_SERVICING";
    private final BusinessTransactionWebService businessTransactionWebService;
    private final AmountService amountService;
    private final ComplianceWebService complianceWebService;
    @Value("${policies-remediated-list}")
    private final List<String> policiesRemediatedList;

    @Value("${policies-not-remediated-list}")
    private final List<String> policiesNotRemediatedList;

    private final RiskFactorsProperties riskFactorsProperties;

    public BusinessTransaction getBusinessTransactionDetails(final String transactionNumber) throws Exception {

        BusinessTransaction transaction = businessTransactionWebService.getBusinessTransactionDetails(transactionNumber);
        if (transaction != null) {
            final var expectedAmount = amountService.getSumPaymentAmountInTransaction(transaction, transaction.getPolicyIsoCurrencyCode());
            final var expectedAmountEur = amountService.convertAmount(expectedAmount, EUR_ISO_CODE_CURRENCY);

            transaction.setExpectedAmountEur(expectedAmountEur);
            transaction.setExpectedAmount(expectedAmount);

            final var transactionAmounts = transaction.getTransactionAmounts();
            if (transactionAmounts != null) {
                final var grossAmount = transactionAmounts.getGrossAmount();
                transaction.setTransactionAmountEur(amountService.convertAmount(grossAmount, EUR_ISO_CODE_CURRENCY));
            }

            final var policyNumber = transaction.getPolicyNumber();

            final var transactionType = POLICY_SERVICING.equals(transaction.getType()) ? transaction.getCategory() : transaction.getType();
            final var riskFactorIds = riskFactorsProperties.getFactors().get(transactionType);
            if (!CollectionUtils.isEmpty(riskFactorIds)) {
                transaction.setRiskFactorResults(complianceWebService.evaluateRiskFactors(transactionNumber, riskFactorIds));
            }
            transaction.setEboPolicyNav(complianceWebService.getSameEboPolicyNav(policyNumber, transactionNumber, EUR_ISO_CODE_CURRENCY));
            transaction.setIsInRemediationList(
                    Stream.concat(policiesRemediatedList.stream(), policiesNotRemediatedList.stream()).anyMatch(i -> i.equals(policyNumber)));
            transaction.setIsPolicyRemediated(policiesRemediatedList.stream().anyMatch(i -> i.equals(policyNumber)));
        }
        return transaction;
    }
}
