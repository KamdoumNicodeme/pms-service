package com.lombardinternational.casemanagement.service.decision.domain.utils.constants;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class SignatoryConstants {

    // Addition Request form
    public static final String PCON1047 = "PCON1047";
    public static final String PCON1048 = "PCON1048";
    public static final String PCON1339 = "PCON1339";
    public static final String PCON1338 = "PCON1338";
    public static final String PCON1359 = "PCON1359";
    public static final String PCON1578 = "PCON1578";
    public static final String PCON1052 = "PCON1052";
    public static final String PCON1563 = "PCON1563";
    public static final String PCON1314 = "PCON1314";
    public static final String PCON1580 = "PCON1580";
    public static final String PCON1236 = "PCON1236";
    public static final String PCON1319 = "PCON1319";
    public static final String PCON1374 = "PCON1374";
    public static final String PCON1426 = "PCON1426";
    public static final String PCON1457 = "PCON1457";
    public static final String PCON1581 = "PCON1581";
    public static final String PCON1385 = "PCON1385";
    public static final String PCON1579 = "PCON1579";
    public static final String PCON1046 = "PCON1046";
    public static final String PCON1549 = "PCON1549";
    public static final String PCON1550 = "PCON1550";
    public static final String PCON1551 = "PCON1551";
    public static final String PCON1190 = "PCON1190";
    public static final String PCON1414 = "PCON1414";
    public static final String PCON1176 = "PCON1176";
    public static final String PCON1215 = "PCON1215";
    public static final String PCON1552 = "PCON1552";
    public static final String PCON1197 = "PCON1197";

    // KYC
    public static final String CONT2895 = "CONT2895";
    public static final String CONT4868 = "CONT4868";
    public static final String CONT4142 = "CONT4142";
    public static final String CONT2894 = "CONT2894";
    public static final String CONT4869 = "CONT4869";
    public static final String CONT4144 = "CONT4144";
    public static final String CONT2897 = "CONT2897";
    public static final String CONT4870 = "CONT4870";
    public static final String CONT4143 = "CONT4143";
    public static final String CONT2896 = "CONT2896";
    public static final String CONT4871 = "CONT4871";
    public static final String CONT4145 = "CONT4145";
    public static final String CONT2899 = "CONT2899";
    public static final String CONT3003 = "CONT3003";
    public static final String CONT3028 = "CONT3028";
    public static final String CONT2713 = "CONT2713";
    public static final String CONT2714 = "CONT2714";
    public static final String CONT2901 = "CONT2901";
    public static final String CONT3004 = "CONT3004";
    public static final String CONT2903 = "CONT2903";
    public static final String CONT3005 = "CONT3005";
    public static final String CONT3715 = "CONT3715";
    public static final String CONT2905 = "CONT2905";
    public static final String CONT3006 = "CONT3006";
    public static final String CONT3029 = "CONT3029";
    public static final String CONT2907 = "CONT2907";
    public static final String CONT3007 = "CONT3007";
    public static final String CONT3030 = "CONT3030";
    public static final String CONT2908 = "CONT2908";
    public static final String CONT3008 = "CONT3008";
    public static final String CONT3418 = "CONT3418";
    public static final String CONT4062 = "CONT4062";
    public static final String CONT4063 = "CONT4063";
    public static final String CONT4064 = "CONT4064";
    public static final String CONT4076 = "CONT4076";
    public static final String CONT4077 = "CONT4077";
    public static final String CONT4078 = "CONT4078";
    public static final String CONT4073 = "CONT4073";
    public static final String CONT4074 = "CONT4074";
    public static final String CONT4075 = "CONT4075";
    public static final String CONT3407 = "CONT3407";
    public static final String CONT3408 = "CONT3408";
    public static final String CONT3409 = "CONT3409";
    public static final String CONT2909 = "CONT2909";
    public static final String CONT3009 = "CONT3009";
    public static final String CONT3031 = "CONT3031";
    public static final String CONT2912 = "CONT2912";
    public static final String CONT3013 = "CONT3013";
    public static final String CONT2914 = "CONT2914";
    public static final String CONT3014 = "CONT3014";
    public static final String CONT3035 = "CONT3035";
    public static final String CONT2917 = "CONT2917";
    public static final String CONT3015 = "CONT3015";
    public static final String CONT2920 = "CONT2920";
    public static final String CONT3016 = "CONT3016";
    public static final String CONT2921 = "CONT2921";
    public static final String CONT3017 = "CONT3017";
    public static final String CONT2923 = "CONT2923";
    public static final String CONT3019 = "CONT3019";
    public static final String CONT3036 = "CONT3036";
    public static final String CONT2924 = "CONT2924";
    public static final String CONT2928 = "CONT2928";
    public static final String CONT2925 = "CONT2925";
    public static final String CONT2926 = "CONT2926";
    public static final String CONT2927 = "CONT2927";
    public static final String CONT2929 = "CONT2929";
    public static final String CONT3020 = "CONT3020";
    public static final String CONT3021 = "CONT3021";
    public static final String CONT3023 = "CONT3023";
    public static final String CONT3024 = "CONT3024";
    public static final String CONT3025 = "CONT3025";
    public static final String CONT3037 = "CONT3037";
    public static final String CONT3038 = "CONT3038";
    public static final String CONT3040 = "CONT3040";
    public static final String CONT3041 = "CONT3041";

    // POA
    public static final String CONT4874 = "CONT4874";
    public static final String CONT4875 = "CONT4875";
    public static final String CONT4549 = "CONT4549";
    public static final String CONT3198 = "CONT3198";
    public static final String CONT3199 = "CONT3199";
    public static final String CONT3048 = "CONT3048";

    // Fund annex
    public static final String CONT2887 = "CONT2887";
    public static final String CONT2885 = "CONT2885";

    public static final String PREMIUM_INVESTMENT_SAF_BUY_AND_HOLD = "BUY_AND_HOLD";
    public static final String PREMIUM_INVESTMENT_SAF_MANAGER_MANAGEMENT_ADVISED = "ADVISED";
    public static final String PREMIUM_INVESTMENT_SAF_SELF_MANAGED = "SELF";
}
