package com.lombardinternational.casemanagement.service.decision.domain.model.policy;

import java.time.LocalDate;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class Block {

    private String blockType;
    private LocalDate startDate;
    private LocalDate endDate;
    private String blockReason;
    private String unblockReason;
    private String unblockBy;
    protected LocalDate unblockApprovalDate;
}
