package com.lombardinternational.casemanagement.service.decision.domain.service.checklist.cci;

import java.util.Collections;

import org.springframework.stereotype.Service;

import com.lombardinternational.casemanagement.service.decision.domain.model.policy.Policy;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Group;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Tab;
import com.lombardinternational.casemanagement.service.decision.domain.model.transaction.BusinessTransaction;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.checklist.ChecklistBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.checklist.cci.group.GeneralDetailsCCIGroupBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.utils.RulesUtils;

import lombok.AllArgsConstructor;

@Service
@AllArgsConstructor
public class CCIChecklistBuilderService implements ChecklistBuilderService {

    private static final String CHECKLIST = "CHECKLIST";

    private final GeneralDetailsCCIGroupBuilderService generalDetailsCCIGroupBuilderService;

    @Override
    public ScreenDescription buildChecklist(final WebForm webForm, final ScreenDescription screenDescription, final Policy policy,
            final BusinessTransaction transaction) {

        Tab checklist = RulesUtils.getTabInScreenDescription(screenDescription, CHECKLIST);
        if (checklist == null) {
            checklist = Tab.builder().tabId(CHECKLIST).order(1).type("FormTab").label("Checklist").build();
            screenDescription.setTabs(Collections.singletonList(checklist));
        }

        checklist.setIsActive(true);
        Group.resetGroupId();
        generalDetailsCCIGroupBuilderService.buildGroup(webForm, screenDescription, checklist, policy, transaction, null);
        return screenDescription;
    }
}
