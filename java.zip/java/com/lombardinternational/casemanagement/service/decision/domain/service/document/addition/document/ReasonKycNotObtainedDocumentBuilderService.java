package com.lombardinternational.casemanagement.service.decision.domain.service.document.addition.document;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.DocumentDefinition;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.document.AbstractDocumentBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.utils.Constraint;
import com.lombardinternational.casemanagement.service.decision.domain.utils.FieldConstraint;
import com.lombardinternational.casemanagement.service.decision.domain.utils.WebformUtils;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ChecklistFieldConstants.NEW_KYC_OBTAINED;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.DocumentConstants.*;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.WebFormFieldConstants.POLICY_NUMBER_WF;

@Service
public class ReasonKycNotObtainedDocumentBuilderService extends AbstractDocumentBuilderService {

    @Override
    public void buildDocument(final WebForm webForm, final ScreenDescription screenDescription, String transactionNumber,
            List<DocumentDefinition> documents) {

        final var constraints = new ArrayList<FieldConstraint>();
        constraints.add(
                FieldConstraint.builder().fieldId(NEW_KYC_OBTAINED).constraint(Constraint.EQUALS).values(Collections.singletonList("NO")).build());
        if (constraints.stream().allMatch(constraint -> constraint.test(screenDescription))) {
            var relatedTo = WebformUtils.getWebFormFieldValueById(webForm, POLICY_NUMBER_WF);
            buildDocumentDefinition(relatedTo, relatedTo, null, null, documents);
        }
    }

    @Override
    protected String getDocumentType() {

        return KYC_DOCUMENT_DOC_TYPE;
    }

    @Override
    protected String getCmsDocumentType() {

        return KYC_DOCUMENT_CMS_DOC_TYPE;
    }

    @Override
    protected String getDescription() {

        return REASON_KYC_NOT_OBTAINED_FORM_DESCRIPTION;
    }

    @Override
    protected String getCmtRelatedToPrefix() {

        return REASON_KYC_NOT_OBTAINED_FORM_CMT_RELATED_TO_PREFIX_DESCRIPTION;
    }

    @Override
    protected String getI18NDescription() {

        return REASON_KYC_NOT_OBTAINED_FORM_I18N_DESCRIPTION;
    }
}
