package com.lombardinternational.casemanagement.service.decision.domain.utils.constants;

public class ReferenceConstants {

    public static final String TRANSACTION_FEEDBACK_DOMAIN = "TRANSACTION_FEEDBACK_DOMAIN";
    public static final String THIRD_PARTY_TYPE_DOMAIN = "THIRD_PARTY_TYPE_DOMAIN";
    public static final String COUNTRY_DOMAIN = "COUNTRY_DOMAIN";
    public static final String INDUSTRY_SECTOR_DOMAIN = "INDUSTRY_SECTOR";
    public static final String PROFESSION_DOMAIN = "PROFESSION";
    public static final String YES_NO_DOMAIN = "YES_NO_DOMAIN";
    public static final String COMPLIANCE_LEVEL_DOMAIN = "COMPLIANCE_LEVEL";
    public static final String YES_NO_NA_NEW_BUSINESS_VALUES_DOMAIN = "YES_NO_NA_NEW_BUSINESS_VALUES";
    public static final String PARTNER_TYPE_DOMAIN = "PARTNER_TYPE_DOMAIN";
    public static final String AGENT_EMPT_REFERENCE = "AGENT_EMP";
    public static final String AGENT_INT_REFERENCE = "AGENT_INT";
    public static final String AGENT_EXT_REFERENCE = "AGENT_EXT";

    public static final String NUMBER_OF_FUNDS_DOMAIN = "NUMBER_OF_FUNDS_DOMAIN";
    public static final String CHANGED_SINCE_LAST_FCC_REVIEW_DOMAIN = "CHANGED_SINCE_LAST_FCC_REVIEW_DOMAIN";
    public static final String FORM_SIGNER_DOMAIN = "FORM_SIGNER_DOMAIN";

    // STANDARD¬Standard;EXTENDED¬Extended,
    public static final String VALUATION_MODEL_DOMAIN = "VALUATION_MODEL";

    // PREMIUM¬Premium;FUND¬Fund;ILF¬ILF,
    public static final String WHERE_ARE_ASSETS_DOMAIN = "WHERE_ARE_ASSETS";

    public static final String CURRENCY_DOMAIN = "CURRENCY_DOMAIN";
    public static final String POLICY_TYPE_DOMAIN = "POLICY_TYPE_DOMAIN";

    // LIMITED¬Limited;UNLIMITED¬Unlimited;ADVISORY¬Advisory;SELF_MANAGED¬Self-managed
    public static final String MANAGER_TYPE_DOMAIN = "MANAGER_TYPE_DOMAIN";
    public static final String STRATEGY_TYPE_DOMAIN = "STRATEGY_TYPE_DOMAIN";

    // HIGH¬High (1 business day);MEDIUM¬Medium (3 business days);LOW¬Medium (1 week);NA¬N/A
    public static final String ELIGIBILITY_PRIORITY_DOMAIN = "ELIGIBILITY_PRIORITY_DOMAIN";

    public static final String CORE_MARKET = "Core Market";
    public static final String SIGNATURE_DOMAIN = "SIGNATURE_DOMAIN";
    public static final String PROVIDER_DOMAIN = "PROVIDER_DOMAIN";
}
