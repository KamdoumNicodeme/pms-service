package com.lombardinternational.casemanagement.service.decision.domain.utils.constants;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;

import java.util.List;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class WebFormFieldConstants {

    public static final String BROKER_IDENTIFIER_WF = "BROKER_IDENTIFIER";
    public static final String UNQUOTED_INSTRUCTION_WF = "UNQUOTED_INSTRUCTION";
    public static final String IS_MULTISUPPORT_WF = "IS_MULTISUPPORT";
    public static final String PH_HOLDING_HIGHER_WF = "PH_HOLDING_HIGHER";
    public static final String PH_HOLDING_HIGHER_SUBFORM_WF = "PH_HOLDING_HIGHER_SUBFORM";
    public static final String PH_INSIDER_SUBFORM_WF = "PH_INSIDER_SUBFORM";
    public static final String PH_SHARE_DISCLOSURE_SUBFORM_WF = "PH_SHARE_DISCLOSURE_SUBFORM";
    public static final String PH_REGULATE_BUSINESS_SUBFORM_WF = "PH_REGULATE_BUSINESS_SUBFORM";
    public static final String SECURITY_DENOMINATION_WF = "SECURITY_DENOMINATION";
    public static final String ISIN_WF = "ISIN";
    public static final String ASSET_TRANSFER_WF = "ASSET_TRANSFER";
    public static final String HAVE_UNQUOTED_PRODUCT_WF = "HAVE_UNQUOTED_PRODUCT";
    public static final String IS_ASSET_TRANSFER_WF = "IS_ASSET_TRANSFER";
    public static final String IS_STILL_IN_LINE_WF = "IS_STILL_IN_LINE";
    public static final String IS_STILL_VALID_WF = "IS_STILL_VALID";
    public static final String SIGNATORIES_WF = "SIGNATORIES";
    public static final String SIGNING_WF = "SIGNING";
    public static final String POLICY_WF = "POLICY";
    public static final String KYC_WF = "KYC";
    public static final String CONTACT_TYPE_WF = "CONTACT_TYPE";
    public static final String ID_WF = "ID";
    public static final String FIRST_NAME_WF = "FIRST_NAME";
    public static final String LAST_NAME_WF = "LAST_NAME";
    public static final String BENEFICIARY_WEALTH_WF = "BENEFICIARY_WEALTH";
    public static final String WEALTH_ENTITY_WF = "WEALTH_ENTITY";
    public static final String OTHER_WEALTH_WF = "OTHER_WEALTH";
    public static final String HAS_OTHER_WEALTH_WF = "HAS_OTHER_WEALTH";
    public static final String OTHER_WF = "OTHER";
    public static final String HAS_OTHER_WF = "HAS_OTHER";
    public static final String DETAILS_WF = "DETAILS";
    public static final String BUSINESS_SALE_WF = "BUSINESS_SALE";
    public static final String HAS_BUSINESS_SALE_WF = "HAS_BUSINESS_SALE";
    public static final String DONATION_WF = "DONATION";
    public static final String EBO_ID_WF = "EBO_ID";
    public static final String EBO_NAME_WF = "EBO_NAME";
    public static final String HAS_DONATION_WF = "HAS_DONATION";
    public static final String DIVORCE_WF = "DIVORCE";
    public static final String HAS_DIVORCE_WF = "HAS_DIVORCE";
    public static final String HERITAGE_WF = "HERITAGE";
    public static final String HAS_HERITAGE_WF = "HAS_HERITAGE";
    public static final String PROFESSIONAL_ACTIVITY_WF = "PROFESSIONAL_ACTIVITY";
    public static final String HAS_PROFESSIONAL_ACTIVITY_WF = "HAS_PROFESSIONAL_ACTIVITY";
    public static final String POLICY_HOLDER_WF = "POLICY_HOLDER";
    public static final String INTERNAL_DEDICATED_FUNDS_WF = "INTERNAL_DEDICATED_FUNDS";
    public static final String SPECIALISED_ASSURANCE_FUNDS_WF = "SPECIALISED_ASSURANCE_FUNDS";
    public static final String IS_NEW_WF = "IS_NEW";
    public static final String COUNTRY_OF_LAW_WF = "COUNTRY_OF_LAW";
    public static final String TYPE_WF = "TYPE";
    public static final String ENTITY_WF = "ENTITY";
    public static final String DISTRIBUTOR_DECLARATION_WF = "DISTRIBUTOR_DECLARATION";
    public static final String PHYSICALS_WF = "PHYSICALS";
    public static final String MORALS_WF = "MORALS";
    public static final String CONTAINS_UNQUOTED_WF = "CONTAINS_UNQUOTED";
    public static final String POLICY_NUMBER_WF = "POLICY_NUMBER";
    public static final String FUND_ID_WF = "FUND_ID";
    public static final String INVESTMENT_STRATEGY_WF = "INVESTMENT_STRATEGY";
    public static final String BANK_COUNTRY_WF = "BANK_COUNTRY";
    public static final String KYC_INTRO_PURPOSE_OF_INVESTMENT_WF = "KYC_INTRO_PURPOSE_OF_INVESTMENT";
    public static final String ACCOUNT_HOLDER_WF = "ACCOUNT_HOLDER";
    public static final String BANK_NAME_WF = "BANK_NAME";

    public static final String EBO_KYCS_WF = "EBO_KYCS";
    public static final String EBO_TYPE_WF = "EBO_TYPE";
    public static final String IS_KYC_REQUIRED_WF = "IS_KYC_REQUIRED";
    public static final String EBO_TYPE_PHYSICAL = "Physical";
    public static final String EBO_TYPE_MORAL = "Moral";
    public static final String EBO_TYPE_ENTITY = "Entity";

    public static final List<String> EBO_TYPE_GLOBAL_LIST = List.of(EBO_TYPE_PHYSICAL, EBO_TYPE_MORAL);




    // ADN V2 FORM
    public static final String IS_NIF_STILL_VALID_WF = "IS_NIF_STILL_VALID";

    public static final String PHYSICAL_PERSONS_WF = "PHYSICAL_PERSONS";
    public static final String MORAL_PERSON_WF = "MORAL_PERSON";
    public static final String UPDATED_AEOI_WF = "UPDATED_AEOI";
    public static final String CLIENT_NUMBER_WF = "CLIENT_NUMBER";
    public static final String RESIDENCE_COUNTRY_WF = "RESIDENCE_COUNTRY";
    public static final String NIF_WF = "NIF";
    public static final String HAVE_NIF_WF = "HAVE_NIF";
    public static final String REASON_WF = "REASON";
    public static final String EXPLANATION_WF = "EXPLANATION";

    public static final String BRANCH_TYPE = "BRANCH_TYPE";
    public static final String TARGET_MARKET = "TARGET_MARKET";
    public static final String TAX_COUNTRY = "TAX_COUNTRY";
    public static final String POLICY_HOLDER = "POLICY_HOLDER";
    public static final String POLICY_NUMBER = "POLICY_NUMBER";
    public static final String COUNTRY_OF_LAW = "COUNTRY_OF_LAW";
    public static final String ADVISED_IN_UK = "ADVISED_IN_UK";
    public static final String COUNTRY_OF_APPLICABLE_LAW = "COUNTRY_OF_APPLICABLE_LAW";
    public static final String CURRENCY = "CURRENCY";
    public static final String B_CODE = "B_CODE";
    public static final String INVESTMENT_PROFILE = "INVESTMENT_PROFILE";
    public static final String BUSINESS_ORIGIN = "BUSINESS_ORIGIN";
    public static final String MASTER_PRODUCT = "MASTER_PRODUCT";
    public static final String CAA_POLICY_CODE = "CAA_POLICY_CODE";
    public static final String DEVIATION_FORM_SIGNED = "DEVIATION_FORM_SIGNED";

    // Broker Code
    public static final String AZIMUT_BROKER = "B/1716";
    public static final String UNICREDIT_BROKER = "B/2740";
    public static final String FINECO_BROKER = "B/2884";
    public static final String MEDIOLANUM_BROKER = "B/2116";

    // BFFM broker code
    public static final String B_018 = "B/018";
    public static final String B_2000 = "B/2000";
    public static final String B_2110 = "B/2110";
    public static final String B_2172 = "B/2172";
    public static final String B_2435 = "B/2435";
    public static final String B_2436 = "B/2436";
    public static final String B_3080 = "B/3080";
    public static final String B_4219 = "B_4219";
    public static final String B_3292 = "B_3292";

    public static final String ID = "ID";
    public static final String FIRST_NAME = "FIRST_NAME";
    public static final String LAST_NAME = "LAST_NAME";
    public static final String CONTACT_TYPE = "CONTACT_TYPE";
    public static final String PHONE_NUMBER = "PHONE_NUMBER";
    public static final String EMAIL = "EMAIL";
    public static final String CONTACT_DETAILS = "CONTACT_DETAILS";

    // FUND
    public static final String SPECIALISED_ASSURANCE_FUNDS = "SPECIALISED_ASSURANCE_FUNDS";
    public static final String IS_NEW = "IS_NEW";
    public static final String FUND_ID = "FUND_ID";
    public static final String FAS_MANAGER = "FAS_MANAGER";
    public static final String RTO_REPRESENTATIVE = "RTO_REPRESENTATIVE";
    public static final String IS_DIFFERENT = "IS_DIFFERENT";

    // ROP
    public static final String ROP_DETAILS_POLICY_WF = "ROP_DETAILS_POLICY";
    public static final String IS_IT_THE_LAST_INSTALLMENT = "IS_IT_THE_LAST_INSTALLMENT";
}
