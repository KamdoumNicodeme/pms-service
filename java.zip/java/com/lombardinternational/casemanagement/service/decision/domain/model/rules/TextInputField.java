package com.lombardinternational.casemanagement.service.decision.domain.model.rules;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.RequiredArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder
@RequiredArgsConstructor
@EqualsAndHashCode(callSuper = true)
public class TextInputField extends Field {

    private Integer size;
    private Integer minChars;
    private Integer maxChars;

}
