package com.lombardinternational.casemanagement.service.decision.domain.model.webform;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class WebFormGroup {

    private String groupId;
    private String title;
    private String i18NTitleKey;
    private String type;
    private List<BigDecimalWebFormField> bigDecimalFields;
    private List<BooleanWebFormField> booleanFields;
    private List<TextWebFormField> textFields;
    private List<CalendarWebFormField> calendarFields;
    private List<WebFormGroup> groups;

}
