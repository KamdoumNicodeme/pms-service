package com.lombardinternational.casemanagement.service.decision.domain.service.tasklist.addition;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Service;

import com.lombardinternational.casemanagement.service.decision.domain.model.policy.Policy;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.TaskDefinition;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.tasklist.AbstractTaskBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.tasklist.TaskListBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.tasklist.addition.task.ChangeOfTaxCountryTaskAdditionTaskBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.tasklist.addition.task.compliance.DefaultOptionalComplianceTaskBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.tasklist.addition.task.compliance.HighRiskTaskBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.tasklist.addition.task.compliance.ItalianBranchPepTaskBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.tasklist.addition.task.compliance.MarketAbuseTaskBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.tasklist.addition.task.compliance.TransactionFeedbackRejectedTaskBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.tasklist.addition.task.dot.AssetTransferDOTAdditionTaskBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.tasklist.addition.task.dot.DefaultOptionalDOTAdditionTaskBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.tasklist.addition.task.ic.AssetTransferICAdditionTaskBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.tasklist.addition.task.ic.DefaultOptionalICAdditionTaskBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.tasklist.addition.task.ilf.DefaultOptionalILFSetUpTaskBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.tasklist.addition.task.ilf.ILFSetUpTaskBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.tasklist.addition.task.unquoted.DefaultOptionalUnquotedTaskBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.tasklist.common.task.CommonAMLSignOffTaskBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.tasklist.common.task.CommonFreeTaskTaskBuilderService;

import lombok.AllArgsConstructor;

@Service
@AllArgsConstructor
public class AdditionTaskListBuilderService implements TaskListBuilderService {

    private final HighRiskTaskBuilderService highRiskTaskBuilderService;
    private final TransactionFeedbackRejectedTaskBuilderService transactionFeedbackRejectedTaskBuilderService;
    private final MarketAbuseTaskBuilderService marketAbuseTaskBuilderService;
    private final ItalianBranchPepTaskBuilderService italianBranchPepCategoryRedTaskBuilderService;
    private final DefaultOptionalComplianceTaskBuilderService defaultOptionalComplianceTaskBuilderService;
    private final AssetTransferICAdditionTaskBuilderService assetTransferICTaskBuilderService;
    private final DefaultOptionalICAdditionTaskBuilderService defaultOptionalICTaskBuilderService;
    private final AssetTransferDOTAdditionTaskBuilderService assetTransferDOTTaskBuilderService;
    private final DefaultOptionalDOTAdditionTaskBuilderService defaultOptionalDOTTaskBuilderService;
    private final DefaultOptionalUnquotedTaskBuilderService defaultOptionalUnquotedTaskBuilderService;
    private final CommonFreeTaskTaskBuilderService commonFreeTaskTaskBuilderService;
    private final CommonAMLSignOffTaskBuilderService commonAmlSignOffTaskBuilderService;
    private final ILFSetUpTaskBuilderService ilfSetUpTaskBuilderService;
    private final DefaultOptionalILFSetUpTaskBuilderService defaultOptionalILFSetUpTaskBuilderService;
    private final ChangeOfTaxCountryTaskAdditionTaskBuilderService changeOfTaxCountryTaskAdditionTaskBuilderService;

    @Override
    public List<TaskDefinition> buildTaskList(final Policy policy, final WebForm webForm, final ScreenDescription screenDescription) {

        TaskDefinition.resetTaskOrder();
        List<AbstractTaskBuilderService> taskBuilderServices = Arrays.asList(highRiskTaskBuilderService,
                transactionFeedbackRejectedTaskBuilderService, marketAbuseTaskBuilderService, italianBranchPepCategoryRedTaskBuilderService,
                defaultOptionalComplianceTaskBuilderService, assetTransferICTaskBuilderService, defaultOptionalICTaskBuilderService,
                assetTransferDOTTaskBuilderService, defaultOptionalDOTTaskBuilderService, defaultOptionalUnquotedTaskBuilderService,
                commonFreeTaskTaskBuilderService, commonAmlSignOffTaskBuilderService, ilfSetUpTaskBuilderService,
                defaultOptionalILFSetUpTaskBuilderService, changeOfTaxCountryTaskAdditionTaskBuilderService);
        final var taskDefinitions = new ArrayList<TaskDefinition>();
        taskBuilderServices.forEach(service -> service.buildTask(policy, webForm, screenDescription, taskDefinitions));
        return taskDefinitions;
    }
}
