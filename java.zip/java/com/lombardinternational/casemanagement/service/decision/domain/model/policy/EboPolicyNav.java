package com.lombardinternational.casemanagement.service.decision.domain.model.policy;

import java.math.BigDecimal;
import java.util.Map;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class EboPolicyNav {

    private String policyBranch;

    private String policyType;

    // Total Policy NAV (For all policies of all EBO)
    private BigDecimal totalNav;

    // Currency
    private String currency;

    // A table with the following pairs
    // Policy branch
    // Total NAV for all policies of this branch
    private Map<String,BigDecimal> policyNavByBranch;
}
