package com.lombardinternational.casemanagement.service.decision.domain.spi.web;

import java.util.Collection;
import java.util.List;

import com.lombardinternational.casemanagement.service.decision.domain.model.policy.AbstractPerson;
import com.lombardinternational.casemanagement.service.decision.domain.model.policy.Block;
import com.lombardinternational.casemanagement.service.decision.domain.model.policy.Policy;
import com.lombardinternational.casemanagement.service.decision.domain.model.policy.PolicyRole;
import com.lombardinternational.casemanagement.service.decision.domain.model.policy.PolicyValues;
import com.lombardinternational.casemanagement.service.decision.domain.model.transaction.BusinessTransaction;

public interface PolicyWebService {

    Policy getPolicyDetails(final String policyNumber) throws Exception;

    Collection<Block> getBlocks(String policyNumber) throws Exception;

    Collection<BusinessTransaction> getBusinessTransactions(String policyNumber) throws Exception;

    List<PolicyRole> getPolicyRoles(String policyNumber) throws Exception;

    Collection<AbstractPerson> getPolicyLinks(String policyNumber) throws Exception;

    PolicyValues getPolicyValues(String policyNumber) throws Exception;
}
