package com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control;

import java.util.Collections;
import java.util.List;

import org.springframework.stereotype.Service;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ControlDefinition;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.AbstractControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.utils.Constraint;
import com.lombardinternational.casemanagement.service.decision.domain.utils.FieldConstraint;

import static com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control.common.Constants.TRUST;
import static com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control.common.Utils.createConstraintWithMultiple;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ChecklistFieldConstants.THIRD_PARTY_SUB_TYPE_PH;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ControlConstants.CERTIFIED_TRUST_DEED_NAME;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ControlConstants.CERTIFIED_TRUST_DEED_TYPE;

@Service(value = "onboardingCertifiedTrustDeedControlBuilderService")
public class CertifiedTrustDeedControlBuilderService extends AbstractControlBuilderService {

    @Override
    public ControlDefinition buildControl(WebForm webForm, ScreenDescription screenDescription) {

        final List<FieldConstraint> constraints =
                List.of(createConstraintWithMultiple(THIRD_PARTY_SUB_TYPE_PH, Constraint.IN, Boolean.TRUE, Collections.singletonList(TRUST)));

        if (constraints.stream().anyMatch(constraint -> constraint.test(screenDescription))) {
            return buildControlDefinition();
        }
        return null;
    }

    @Override
    protected String getControlName() {

        return CERTIFIED_TRUST_DEED_NAME;
    }

    @Override
    protected String getControlType() {

        return CERTIFIED_TRUST_DEED_TYPE;
    }
}
