package com.lombardinternational.casemanagement.service.decision.domain.model.policy;

import lombok.Builder;
import lombok.Data;

import java.time.LocalDate;
import java.util.Collection;
import java.util.List;

@Data
@Builder
public class Policy {

    private String number;
    private String policyType;
    private String isoCurrencyCode;
    private String countryOfLawCode;
    private Boolean holderAndEBODifferent;
    private Boolean holderAndLifeAssuredDifferent;
    private Boolean beneficiaryAndLifeAssuredDifferent;
    private Boolean inForceForMoreThanOneYear;
    private String businessOrigin;
    private LocalDate effectiveDate;
    private Boolean pledged;
    private String masterProduct;
    private Collection<Block> blocks;
    private List<Holder> holders;
    private List<LifeAssured> lifeAssureds;
    private List<Beneficiary> beneficiaries;
    private List<Beneficiary> irrevocableBeneficiaries;
    private List<EconomicBeneficiary> economicBeneficiaries;
    private List<Trust> trusts;
    private List<Trustee> trustees;
    private List<Settlor> settlors;
    private List<Proxy> proxies;
    private List<CessionHolder> cessionHolders;
    private List<PolicyLink> policyLinks;
    private List<AbstractPerson> thirdParties;
    private String taxReserveBehavior;
    private Amount navInPolicyCurrency;
    private Amount navInEurCurrency;
    private Amount surrenderLiquidValue;
    private String lastReviewDate;
    private String sellingMeetingType;
    private Broker broker;
    private Boolean heldILF;
    private Boolean brokerChangeWithinLast3Months;
    private PolicyHolder policyHolder;
}
