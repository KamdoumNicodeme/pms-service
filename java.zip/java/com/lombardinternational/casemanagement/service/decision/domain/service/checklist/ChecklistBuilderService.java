package com.lombardinternational.casemanagement.service.decision.domain.service.checklist;

import com.lombardinternational.casemanagement.service.decision.domain.model.policy.Policy;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.transaction.BusinessTransaction;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;

public interface ChecklistBuilderService {

    ScreenDescription buildChecklist(final WebForm webForm, final ScreenDescription screenDescription, final Policy policy,
            final BusinessTransaction transaction);
}
