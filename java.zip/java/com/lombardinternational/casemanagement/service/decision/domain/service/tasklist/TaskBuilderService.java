package com.lombardinternational.casemanagement.service.decision.domain.service.tasklist;

import java.util.List;

import com.lombardinternational.casemanagement.service.decision.domain.model.policy.Policy;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.TaskDefinition;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;

public interface TaskBuilderService {

    void buildTask(final Policy policy, final WebForm webForm, final ScreenDescription screenDescription, final List<TaskDefinition> taskList);
}
