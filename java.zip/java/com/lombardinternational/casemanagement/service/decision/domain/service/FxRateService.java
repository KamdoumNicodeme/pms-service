package com.lombardinternational.casemanagement.service.decision.domain.service;

import java.time.LocalDate;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.lombardinternational.casemanagement.service.decision.domain.model.FxRate;
import com.lombardinternational.casemanagement.service.decision.domain.spi.repository.FxRateRepositoryService;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
@AllArgsConstructor
public class FxRateService {

    private final FxRateRepositoryService fxRateRepositoryService;

    Optional<FxRate> getLastFxRate(String fromCcy, String toCcy) {

        var fxRates = fxRateRepositoryService.getFxRateByFxRateDate(LocalDate.now());
        if (fxRates.isEmpty()) {
            final var lastRateDate = fxRateRepositoryService.getMaxFxRateDate();
            if (lastRateDate.isPresent()) {
                fxRates = fxRateRepositoryService.getFxRateByFxRateDate(lastRateDate.get());
            }
        }
        return fxRates.stream().filter(fxRate -> fxRate.getFromCcy().equals(fromCcy) && fxRate.getToCcy().equals(toCcy)).findFirst();
    }
}
