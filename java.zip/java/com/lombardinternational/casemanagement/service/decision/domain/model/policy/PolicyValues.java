package com.lombardinternational.casemanagement.service.decision.domain.model.policy;

import lombok.Data;

@Data
public class PolicyValues {

    private Amount actuarialValue;
    private Amount actuarialValueInEur;
    private Amount surrenderLiquidValue;
}
