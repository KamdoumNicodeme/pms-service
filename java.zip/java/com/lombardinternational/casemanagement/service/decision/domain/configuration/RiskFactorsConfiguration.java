package com.lombardinternational.casemanagement.service.decision.domain.configuration;

import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration
@EnableConfigurationProperties(RiskFactorsProperties.class)
public class RiskFactorsConfiguration {
}
