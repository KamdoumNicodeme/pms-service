package com.lombardinternational.casemanagement.service.decision.domain.model.transaction;

import com.lombardinternational.casemanagement.service.decision.domain.model.policy.Country;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PaymentDetails {

    private String payerID;
    private String payerName;
    private String payerFirstName;
    private String payerBankName;
    private Country payerBankCountry;
    private PaymentOriginator originator;
    private Country payerLegalAddressCountry;
}
