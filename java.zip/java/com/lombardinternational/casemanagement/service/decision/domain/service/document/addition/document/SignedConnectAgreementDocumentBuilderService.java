package com.lombardinternational.casemanagement.service.decision.domain.service.document.addition.document;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.DocumentDefinition;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Field;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.document.AbstractDocumentBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.utils.ChecklistUtils;
import com.lombardinternational.casemanagement.service.decision.domain.utils.WebformUtils;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ChecklistFieldConstants.*;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.DocumentConstants.*;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.WebFormFieldConstants.POLICY_NUMBER_WF;

@Service
public class SignedConnectAgreementDocumentBuilderService extends AbstractDocumentBuilderService {

    @Override
    public void buildDocument(final WebForm webForm, final ScreenDescription screenDescription, String transactionNumber,
            List<DocumentDefinition> documents) {

        Optional<Field> phResidenceCountry = ChecklistUtils.getFieldById(screenDescription, PH_RESIDENCE_COUNTRY);
        Optional<Field> eboCountry = ChecklistUtils.getFieldById(screenDescription, EBO_COUNTRY);
        Optional<Field> laResidenceCountry = ChecklistUtils.getFieldById(screenDescription, LA_RESIDENCE_COUNTRY);
        Optional<Field> sendingAddressOpt = ChecklistUtils.getFieldById(screenDescription, SENDING_ADDRESS_COUNTRY);

        var phResidenceCountries = phResidenceCountry.filter(field -> field.getSelectedValue() != null)
                .map(field -> Arrays.stream(field.getSelectedValue().split(" ")).toList()).orElse(new ArrayList<>());
        var eboCountries = eboCountry.filter(field -> field.getSelectedValue() != null)
                .map(field -> Arrays.stream(field.getSelectedValue().split(" ")).toList()).orElse(new ArrayList<>());
        var laResidenceCountries = laResidenceCountry.filter(field -> field.getSelectedValue() != null)
                .map(field -> Arrays.stream(field.getSelectedValue().split(" ")).toList()).orElse(new ArrayList<>());
        var sendingAddressCountry = sendingAddressOpt.map(Field::getSelectedValue).orElse(null);

        if (!eboCountries.contains(sendingAddressCountry) || !laResidenceCountries.contains(
                sendingAddressCountry) || !phResidenceCountries.contains(sendingAddressCountry)) {
            var relatedTo = WebformUtils.getWebFormFieldValueById(webForm, POLICY_NUMBER_WF);
            buildDocumentDefinition(relatedTo, relatedTo, null, null, documents);
        }
    }

    @Override
    protected String getDocumentType() {

        return AGREEMENT_FORM_DOC_TYPE;
    }

    @Override
    protected String getCmsDocumentType() {

        return AGREEMENT_FORM_CMS_DOC_TYPE;
    }

    @Override
    protected String getDescription() {

        return SIGNED_CONNECT_AGREEMENT_FORM_DESCRIPTION;
    }

    @Override
    protected String getI18NDescription() {

        return SIGNED_CONNECT_AGREEMENT_FORM_I18N_DESCRIPTION;
    }
}
