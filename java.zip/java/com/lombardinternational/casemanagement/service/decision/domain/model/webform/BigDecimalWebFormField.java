package com.lombardinternational.casemanagement.service.decision.domain.model.webform;

import java.math.BigDecimal;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@EqualsAndHashCode(callSuper = true)
@SuperBuilder
@NoArgsConstructor
public class BigDecimalWebFormField extends WebFormField {

    private BigDecimal value;
}
