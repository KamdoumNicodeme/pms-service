package com.lombardinternational.casemanagement.service.decision.domain.service.taskscreen.common.groups;

import org.springframework.stereotype.Service;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Group;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Tab;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.taskscreen.TaskScreenGroupBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.taskscreen.common.fields.CommonAssetsInadmissibleFieldsBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.utils.RulesUtils;

import lombok.AllArgsConstructor;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.TaskScreenConstants.ASSETS_INADMISSIBLE_GROUP;

@Service
@AllArgsConstructor
public class CommonAssetsInadmissibleGroupBuilderService implements TaskScreenGroupBuilderService {

    private final CommonAssetsInadmissibleFieldsBuilderService service;

    @Override
    public void buildGroup(final WebForm webForm, final ScreenDescription screenCheckList, final ScreenDescription screenToFill,
            final Tab parentTab) {

        var assetsInadmissibleGroup = RulesUtils.getGroupInTab(parentTab, ASSETS_INADMISSIBLE_GROUP);
        if (assetsInadmissibleGroup == null) {
            assetsInadmissibleGroup = Group.builder().groupId(ASSETS_INADMISSIBLE_GROUP).build();
            parentTab.getGroups().add(assetsInadmissibleGroup);
        }
        assetsInadmissibleGroup.setIsActive(true);
        assetsInadmissibleGroup.incrementOrder();
        assetsInadmissibleGroup.setTitle("Assets inadmissible due to country-specific investment rules.");
        service.buildField(webForm, screenCheckList, screenToFill, assetsInadmissibleGroup);
    }
}
