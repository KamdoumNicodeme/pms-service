package com.lombardinternational.casemanagement.service.decision.domain.service.taskscreen.addition.groups;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Group;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Tab;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.taskscreen.TaskScreenGroupBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.taskscreen.addition.fields.ChecklistControlsFieldsBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.utils.RulesUtils;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.TaskScreenConstants.CHECKLIST_CONTROLS_GROUP;

@Service
@AllArgsConstructor
public class ChecklistControlsGroupBuilderService implements TaskScreenGroupBuilderService {

    private final ChecklistControlsFieldsBuilderService service;

    @Override
    public void buildGroup(final WebForm webForm, final ScreenDescription screenCheckList, final ScreenDescription screenToFill,
            final Tab parentTab) {

        var checklistControlsGroup = RulesUtils.getGroupInTab(parentTab, CHECKLIST_CONTROLS_GROUP);
        if (checklistControlsGroup == null) {
            checklistControlsGroup = Group.builder().groupId(CHECKLIST_CONTROLS_GROUP).build();
            parentTab.getGroups().add(checklistControlsGroup);
        }
        checklistControlsGroup.setIsActive(true);
        checklistControlsGroup.incrementOrder();
        checklistControlsGroup.setTitle("controls");
        service.buildField(webForm, screenCheckList, screenToFill, checklistControlsGroup);
    }
}
