package com.lombardinternational.casemanagement.service.decision.domain.model;

import java.math.BigDecimal;
import java.time.LocalDate;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class CurrencyExchangeRate {

    private String provider;
    private LocalDate rateDate;
    private BigDecimal rate;
    private String baseIsoCurrencyCode;
    private String quotedIsoCurrencyCode;
}
