package com.lombardinternational.casemanagement.service.decision.domain.service.taskscreen.rop.subtask;

import org.springframework.stereotype.Service;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Group;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Tab;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.taskscreen.SubTaskScreenBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.taskscreen.rop.groups.ComplianceControlsGroupBuilderService;

import lombok.AllArgsConstructor;

@Service
@AllArgsConstructor
public class ComplianceRopSubTaskScreenBuilderService implements SubTaskScreenBuilderService {

    public static String SUB_TASK_SCREEN_ID = "COMPLIANCE_ROP";

    private final ComplianceControlsGroupBuilderService complianceControlsGroupBuilderService;

    @Override
    public ScreenDescription buildSubTaskScreen(WebForm webForm, ScreenDescription screenCheckList, ScreenDescription screenToFill,
            Tab parentTab) {

        Group.resetGroupId();
        complianceControlsGroupBuilderService.buildGroup(webForm, screenCheckList, screenToFill, parentTab);
        return screenToFill;
    }

    public Boolean filterService(String subTaskScreenId) {

        return SUB_TASK_SCREEN_ID.equals(subTaskScreenId);
    }
}
