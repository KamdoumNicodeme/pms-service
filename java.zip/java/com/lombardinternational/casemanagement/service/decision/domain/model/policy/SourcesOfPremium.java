package com.lombardinternational.casemanagement.service.decision.domain.model.policy;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class SourcesOfPremium {

    private String bank;
    private String country;
    private String accountNumber;
    private String accountHolder;
    private Boolean cashAsset;
    private Amount amount;
}
