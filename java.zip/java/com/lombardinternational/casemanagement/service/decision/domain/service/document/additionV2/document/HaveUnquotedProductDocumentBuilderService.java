package com.lombardinternational.casemanagement.service.decision.domain.service.document.additionV2.document;

import java.util.List;

import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Service;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.DocumentDefinition;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.document.AbstractDocumentBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.utils.WebformUtils;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.DocumentConstants.*;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.RulesConstants.*;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.WebFormFieldConstants.*;

@Service
public class HaveUnquotedProductDocumentBuilderService extends AbstractDocumentBuilderService {

    @Override
    public void buildDocument(final WebForm webForm, final ScreenDescription screenDescription, String transactionNumber,
            List<DocumentDefinition> documents) {

        var assetTransfer = WebformUtils.getFirstWebFormGroupById(webForm, ASSET_TRANSFER_WF);
        if (assetTransfer != null && CollectionUtils.isNotEmpty(assetTransfer.getBooleanFields())) {
            var haveUnquotedProduct = WebformUtils.getWebFormFieldValueById(assetTransfer, HAVE_UNQUOTED_PRODUCT_WF);
            if (TRUE.equalsIgnoreCase(haveUnquotedProduct)) {
                var relatedTo = WebformUtils.getWebFormFieldValueById(webForm, POLICY_NUMBER_WF);
                buildDocumentDefinition(relatedTo, relatedTo, null, null, documents);
            }
        }
    }

    @Override
    protected String getDocumentType() {

        return EMAIL_DOC_TYPE;
    }

    @Override
    protected String getCmsDocumentType() {

        return EMAIL_CMS_DOC_TYPE;
    }

    @Override
    protected String getDescription() {

        return HAVE_UNQUOTED_PRODUCT_FORM_DESCRIPTION;
    }

    @Override
    protected String getI18NDescription() {

        return HAVE_UNQUOTED_PRODUCT_FORM_I18N_DESCRIPTION;
    }

    @Override
    protected boolean getDocumentVisibleOnConnect() {

        return true;
    }

    @Override
    protected boolean getDocumentRequired() {

        return true;
    }
}
