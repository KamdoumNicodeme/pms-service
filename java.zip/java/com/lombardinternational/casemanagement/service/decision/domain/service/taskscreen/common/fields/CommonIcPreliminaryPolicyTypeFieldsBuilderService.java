package com.lombardinternational.casemanagement.service.decision.domain.service.taskscreen.common.fields;

import org.springframework.stereotype.Service;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Field;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Group;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.NumberInputField;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.SelectInputField;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.taskscreen.TaskScreenFieldBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.spi.repository.ReferenceDataRepositoryService;
import com.lombardinternational.casemanagement.service.decision.domain.utils.ChecklistUtils;

import lombok.AllArgsConstructor;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ReferenceConstants.*;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.TaskScreenConstants.*;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.TaskScreenConstants.ADDITION_IN_KIND_FIELD;

@Service
@AllArgsConstructor
public class CommonIcPreliminaryPolicyTypeFieldsBuilderService implements TaskScreenFieldBuilderService {


    private final ReferenceDataRepositoryService referenceDataRepositoryService;

    @Override
    public void buildField(final WebForm webForm, final ScreenDescription screenCheckList, final ScreenDescription screenToFill, final Group group) {

        Field.resetFieldId();
        evaluateInitialPremium(group);
        evaluateInitialPremiumCur(group);
        evaluateAdditionInKind(group);
        evaluateAdditionInKindCur(group);
        evaluateWealthDeclaration(group);
        evaluateWealthDeclarationCur(group);
        evaluatePreliminaryPolicyType(group);
    }

    private void evaluateInitialPremium(Group group) {

        var initialPremium = (NumberInputField) ChecklistUtils.getFieldInGroup(group, INITIAL_PREMIUM_FIELD);
        if (initialPremium == null) {
            initialPremium = NumberInputField.builder().fieldId(INITIAL_PREMIUM_FIELD).build();
            group.getFields().add(initialPremium);
        }
        initialPremium.setIsActive(true);
        initialPremium.incrementOrder();
        initialPremium.setEnabled(true);
        initialPremium.setLabel("Initial premium of the policy");
    }

    private void evaluateInitialPremiumCur(Group group) {

        var initialPremiumCur = (SelectInputField) ChecklistUtils.getFieldInGroup(group, INITIAL_PREMIUM_CUR_FIELD);
        if (initialPremiumCur == null) {
            initialPremiumCur = SelectInputField.builder().fieldId(INITIAL_PREMIUM_CUR_FIELD).build();
            group.getFields().add(initialPremiumCur);
        }
        initialPremiumCur.setIsActive(true);
        initialPremiumCur.incrementOrder();
        initialPremiumCur.setEnabled(true);
        initialPremiumCur.setLabel("Currency");
        initialPremiumCur.setOptions(referenceDataRepositoryService.getReferenceDataOptionsByDomain(CURRENCY_DOMAIN));
    }

    private void evaluateAdditionInKind(Group group) {

        var additionInKind = (NumberInputField) ChecklistUtils.getFieldInGroup(group, ADDITION_IN_KIND_FIELD);
        if (additionInKind == null) {
            additionInKind = NumberInputField.builder().fieldId(ADDITION_IN_KIND_FIELD).build();
            group.getFields().add(additionInKind);
        }
        additionInKind.setIsActive(true);
        additionInKind.incrementOrder();
        additionInKind.setEnabled(true);
        additionInKind.setLabel("Value of addition in kind");
    }

    private void evaluateAdditionInKindCur(Group group) {

        var additionInKindCur = (SelectInputField) ChecklistUtils.getFieldInGroup(group, ADDITION_IN_KIND_CUR_FIELD);
        if (additionInKindCur == null) {
            additionInKindCur = SelectInputField.builder().fieldId(ADDITION_IN_KIND_CUR_FIELD).build();
            group.getFields().add(additionInKindCur);
        }
        additionInKindCur.setIsActive(true);
        additionInKindCur.incrementOrder();
        additionInKindCur.setEnabled(true);
        additionInKindCur.setLabel("Currency");
        additionInKindCur.setOptions(referenceDataRepositoryService.getReferenceDataOptionsByDomain(CURRENCY_DOMAIN));
    }

    private void evaluateWealthDeclaration(Group group) {

        var wealthDeclaration = (NumberInputField) ChecklistUtils.getFieldInGroup(group, WEALTH_DECLARATION_FIELD);
        if (wealthDeclaration == null) {
            wealthDeclaration = NumberInputField.builder().fieldId(WEALTH_DECLARATION_FIELD).build();
            group.getFields().add(wealthDeclaration);
        }
        wealthDeclaration.setIsActive(true);
        wealthDeclaration.incrementOrder();
        wealthDeclaration.setEnabled(true);
        wealthDeclaration.setLabel("Wealth declaration of the policy holder");
    }

    private void evaluatePreliminaryPolicyType(Group group) {

        var preliminaryPolicyType = (SelectInputField) ChecklistUtils.getFieldInGroup(group, PRELIMINARY_POLICY_TYPE_FIELD);
        if (preliminaryPolicyType == null) {
            preliminaryPolicyType = SelectInputField.builder().fieldId(PRELIMINARY_POLICY_TYPE_FIELD).build();
            group.getFields().add(preliminaryPolicyType);
        }
        preliminaryPolicyType.setIsActive(true);
        preliminaryPolicyType.incrementOrder();
        preliminaryPolicyType.setEnabled(true);
        preliminaryPolicyType.setLabel("Preliminary policy type");
        preliminaryPolicyType.setOptions(referenceDataRepositoryService.getReferenceDataOptionsByDomain(POLICY_TYPE_DOMAIN));
    }

    private void evaluateWealthDeclarationCur(Group group) {

        var wealthDeclarationCur = (SelectInputField) ChecklistUtils.getFieldInGroup(group, WEALTH_DECLARATION_CUR_FIELD);
        if (wealthDeclarationCur == null) {
            wealthDeclarationCur = SelectInputField.builder().fieldId(WEALTH_DECLARATION_CUR_FIELD).build();
            group.getFields().add(wealthDeclarationCur);
        }
        wealthDeclarationCur.setIsActive(true);
        wealthDeclarationCur.incrementOrder();
        wealthDeclarationCur.setEnabled(true);
        wealthDeclarationCur.setLabel("Currency");
        wealthDeclarationCur.setOptions(referenceDataRepositoryService.getReferenceDataOptionsByDomain(CURRENCY_DOMAIN));
    }
}
