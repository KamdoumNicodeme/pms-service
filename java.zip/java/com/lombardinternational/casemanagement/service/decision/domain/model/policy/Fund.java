package com.lombardinternational.casemanagement.service.decision.domain.model.policy;

import lombok.Data;

@Data
public class Fund {

    private String fundNumber;
    private String fundValuationModel;
    protected String fundSubClass;
}
