package com.lombardinternational.casemanagement.service.decision.domain.service.signatories.addition;

import java.util.List;

import org.springframework.stereotype.Component;

import com.lombardinternational.casemanagement.service.decision.domain.service.signatories.AbstractDocumentRequiredSignatoryBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.signatories.addition.kyc.*;

import lombok.RequiredArgsConstructor;

@Component
@RequiredArgsConstructor
public class AdditionSignatoriesKycProvider {

    private final KycCONT2713 kycCONT2713;
    private final KycCONT2714 kycCONT2714;
    private final KycCONT2894 kycCONT2894;
    private final KycCONT2895 kycCONT2895;
    private final KycCONT2896 kycCONT2896;
    private final KycCONT2897 kycCONT2897;
    private final KycCONT2899 kycCONT2899;
    private final KycCONT2901 kycCONT2901;
    private final KycCONT2903 kycCONT2903;
    private final KycCONT2905 kycCONT2905;
    private final KycCONT2907 kycCONT2907;
    private final KycCONT2908 kycCONT2908;
    private final KycCONT2909 kycCONT2909;
    private final KycCONT2912 kycCONT2912;
    private final KycCONT2914 kycCONT2914;
    private final KycCONT2917 kycCONT2917;
    private final KycCONT2920 kycCONT2920;
    private final KycCONT2921 kycCONT2921;
    private final KycCONT2923 kycCONT2923;
    private final KycCONT2924 kycCONT2924;
    private final KycCONT2925 kycCONT2925;
    private final KycCONT2926 kycCONT2926;
    private final KycCONT2927 kycCONT2927;
    private final KycCONT2928 kycCONT2928;
    private final KycCONT2929 kycCONT2929;
    private final KycCONT3004 kycCONT3004;
    private final KycCONT3005 kycCONT3005;
    private final KycCONT3006 kycCONT3006;
    private final KycCONT3007 kycCONT3007;
    private final KycCONT3008 kycCONT3008;
    private final KycCONT3009 kycCONT3009;
    private final KycCONT3013 kycCONT3013;
    private final KycCONT3014 kycCONT3014;
    private final KycCONT3015 kycCONT3015;
    private final KycCONT3016 kycCONT3016;
    private final KycCONT3017 kycCONT3017;
    private final KycCONT3019 kycCONT3019;
    private final KycCONT3020 kycCONT3020;
    private final KycCONT3021 kycCONT3021;
    private final KycCONT3023 kycCONT3023;
    private final KycCONT3024 kycCONT3024;
    private final KycCONT3025 kycCONT3025;
    private final KycCONT3028 kycCONT3028;
    private final KycCONT3029 kycCONT3029;
    private final KycCONT3031 kycCONT3031;
    private final KycCONT3035 kycCONT3035;
    private final KycCONT3036 kycCONT3036;
    private final KycCONT3037 kycCONT3037;
    private final KycCONT3038 kycCONT3038;
    private final KycCONT3040 kycCONT3040;
    private final KycCONT3041 kycCONT3041;
    private final KycCONT3407 kycCONT3407;
    private final KycCONT3408 kycCONT3408;
    private final KycCONT3409 kycCONT3409;
    private final KycCONT3418 kycCONT3418;
    private final KycCONT3715 kycCONT3715;
    private final KycCONT4062 kycCONT4062;
    private final KycCONT4063 kycCONT4063;
    private final KycCONT4064 kycCONT4064;
    private final KycCONT4073 kycCONT4073;
    private final KycCONT4074 kycCONT4074;
    private final KycCONT4075 kycCONT4075;
    private final KycCONT4076 kycCONT4076;
    private final KycCONT4077 kycCONT4077;
    private final KycCONT4078 kycCONT4078;
    private final KycCONT4142 kycCONT4142;
    private final KycCONT4143 kycCONT4143;
    private final KycCONT4144 kycCONT4144;
    private final KycCONT4145 kycCONT4145;
    private final KycCONT4868 kycCONT4868;
    private final KycCONT4869 kycCONT4869;
    private final KycCONT4870 kycCONT4870;
    private final KycCONT4871 kycCONT4871;
    private final KycCONT3003 kycCONT3003;
    private final KycCONT3030 kycCONT3030;

    public List<AbstractDocumentRequiredSignatoryBuilderService> getAll() {

        return List.of(kycCONT2713, kycCONT2714, kycCONT2894, kycCONT2895, kycCONT2896, kycCONT2897, kycCONT2899, kycCONT2901, kycCONT2903,
                kycCONT2905, kycCONT2907, kycCONT2908, kycCONT2909, kycCONT2912, kycCONT2914, kycCONT2917, kycCONT2920, kycCONT2921, kycCONT2923,
                kycCONT2924, kycCONT2925, kycCONT2926, kycCONT2927, kycCONT2928, kycCONT2929, kycCONT3004, kycCONT3006, kycCONT3007, kycCONT3008,
                kycCONT3009, kycCONT3013, kycCONT3014, kycCONT3015, kycCONT3016, kycCONT3017, kycCONT3019, kycCONT3020, kycCONT3021, kycCONT3023,
                kycCONT3024, kycCONT3025, kycCONT3028, kycCONT3029, kycCONT3031, kycCONT3035, kycCONT3036, kycCONT3037, kycCONT3038, kycCONT3040,
                kycCONT3041, kycCONT3407, kycCONT3408, kycCONT3409, kycCONT3418, kycCONT3715, kycCONT3005, kycCONT4062, kycCONT4063, kycCONT4064,
                kycCONT4073, kycCONT4074, kycCONT4075, kycCONT4076, kycCONT4077, kycCONT4078, kycCONT4142, kycCONT4143, kycCONT4144, kycCONT4145,
                kycCONT4868, kycCONT4869, kycCONT4870, kycCONT4871, kycCONT3003, kycCONT3030);
    }

}
