package com.lombardinternational.casemanagement.service.decision.domain.service.signatories.addition;

import java.util.List;

import org.springframework.stereotype.Component;

import com.lombardinternational.casemanagement.service.decision.domain.service.signatories.AbstractDocumentRequiredSignatoryBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.signatories.addition.fundannex.FundCONT2885;
import com.lombardinternational.casemanagement.service.decision.domain.service.signatories.addition.fundannex.FundCONT2887;

import lombok.RequiredArgsConstructor;

@Component
@RequiredArgsConstructor
public class AdditionSignatoriesFundAnnexProvider {

    private final FundCONT2885 fundCONT2885;
    private final FundCONT2887 fundCONT2887;

    public List<AbstractDocumentRequiredSignatoryBuilderService> getAll() {

        return List.of(fundCONT2885, fundCONT2887);
    }

}
