package com.lombardinternational.casemanagement.service.decision.domain.service.taskscreen.common.groups;

import org.springframework.stereotype.Service;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Group;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Tab;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.taskscreen.TaskScreenGroupBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.taskscreen.common.fields.CommonIdentificationOfAssetsFieldsBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.utils.RulesUtils;

import lombok.AllArgsConstructor;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.TaskScreenConstants.IDENTIFICATION_OF_ASSETS_GROUP;

@Service
@AllArgsConstructor
public class CommonIdentificationOfAssetsGroupBuilderService implements TaskScreenGroupBuilderService {

    private final CommonIdentificationOfAssetsFieldsBuilderService service;

    @Override
    public void buildGroup(final WebForm webForm, final ScreenDescription screenCheckList, final ScreenDescription screenToFill,
            final Tab parentTab) {

        var identificationOfAssetsGroup = RulesUtils.getGroupInTab(parentTab, IDENTIFICATION_OF_ASSETS_GROUP);
        if (identificationOfAssetsGroup == null) {
            identificationOfAssetsGroup = Group.builder().groupId(IDENTIFICATION_OF_ASSETS_GROUP).build();
            parentTab.getGroups().add(identificationOfAssetsGroup);
        }
        identificationOfAssetsGroup.setIsActive(true);
        identificationOfAssetsGroup.incrementOrder();
        identificationOfAssetsGroup.setTitle("Identification of assets on the Watchlist?");
        service.buildField(webForm, screenCheckList, screenToFill, identificationOfAssetsGroup);
    }
}
