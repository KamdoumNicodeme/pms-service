package com.lombardinternational.casemanagement.service.decision.domain.spi.web;

import java.util.Collection;

import com.lombardinternational.casemanagement.service.decision.domain.exception.ClassInternalException;
import com.lombardinternational.casemanagement.service.decision.domain.model.policy.Fund;

public interface FundWebService {

    Collection<Fund> getFunds(final String policyNumber) throws ClassInternalException;
}
