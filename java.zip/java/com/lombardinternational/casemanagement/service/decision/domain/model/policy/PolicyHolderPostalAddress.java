package com.lombardinternational.casemanagement.service.decision.domain.model.policy;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class PolicyHolderPostalAddress {

    private String streetName;
    private String streetNumber;
    private String postCode;
    private String townName;
    private String country;
    private String residenceName;
    private String postalBox;
    private String apartmentNumber;
    private String area;
    private String county;
}
