package com.lombardinternational.casemanagement.service.decision.domain.model.policy;

import java.math.BigDecimal;
import java.time.LocalDate;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class SourcesOfWealth {

    private String description;
    private String companyName;
    private LocalDate transactionDateTime;
    private BigDecimal splitPercentage;
    private String contributorName;
    private String contributorLink;
    private String contributorCountry;
    private String wealthOriginatingcountry1;
    private String wealthOriginatingcountry2;
    private String contributorProfession;
    private String contributorProfIndusSector;
    private Boolean deleted;
    private Boolean exception;
    private Amount amount;
    private Boolean originOfPremium;
}
