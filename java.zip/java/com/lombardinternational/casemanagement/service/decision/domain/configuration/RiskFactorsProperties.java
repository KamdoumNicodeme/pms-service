package com.lombardinternational.casemanagement.service.decision.domain.configuration;

import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.boot.context.properties.ConfigurationProperties;

import jakarta.annotation.PostConstruct;
import lombok.Getter;
import lombok.Setter;

@ConfigurationProperties("risk-factor-ids")
@Getter
@Setter
public class RiskFactorsProperties {

    private Map<String,List<String>> factors = new HashMap<>();

    @Getter
    @Setter
    public static class Factors {

        private List<String> ids;
    }

    @PostConstruct
    public void flattenMap() {

        factors.entrySet().forEach(entry -> {
            List<String> ids = entry.getValue().stream().map(id -> Arrays.stream(id.split(",")).toList()).flatMap(Collection::stream)
                    .map(String::trim).toList();
            entry.setValue(ids);
        });
    }
}
