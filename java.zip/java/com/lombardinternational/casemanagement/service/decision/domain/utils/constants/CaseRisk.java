package com.lombardinternational.casemanagement.service.decision.domain.utils.constants;

import lombok.Getter;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.RulesConstants.*;

@Getter
public enum CaseRisk {

    CASE_RISK_VERY_HIGH(VERY_HIGH, 4), CASE_RISK_HIGH(HIGH, 3), CASE_RISK_MEDIUM(MEDIUM, 2), CASE_RISK_STANDARD(STANDARD, 1);

    private final String value;
    private final int order;

    CaseRisk(String value, Integer order) {

        this.value = value;
        this.order = order;
    }
}
