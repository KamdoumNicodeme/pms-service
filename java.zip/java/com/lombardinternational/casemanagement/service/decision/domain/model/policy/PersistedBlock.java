package com.lombardinternational.casemanagement.service.decision.domain.model.policy;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class PersistedBlock {

    private BlockType blockType;
    private FIUReportingStatus fiuReportingStatus;
    private String endDate;
    private String startDate;
    private String blockReason;
    private String unblockReason;
}
