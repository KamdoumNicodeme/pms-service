package com.lombardinternational.casemanagement.service.decision.domain.model.policy;

import java.util.List;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class SourceOfFunds {

    private Boolean pepFlag;
    private Boolean negativePressFindingFlag;
    private Boolean investmentInLine;
    private Amount totalWealth;
    private Amount annualIncome;
    private Boolean otherPurpose;
    private String companyName;
    private List<SourcesOfWealth> sourcesOfWealth;
    private List<SourcesOfPremium> sourcesOfPremium;
    private PepCategory pepCategory;
    private Boolean isPHEBOGoldenVisaCitizen;
    private Boolean isPHEBORepresentativeIntermediary;
    private Boolean internationalSanctionListFlag;
    private Boolean insiderFlag;
}
