package com.lombardinternational.casemanagement.service.decision.domain.service.signatories.addition;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.stream.Stream;

import org.springframework.stereotype.Service;

import com.lombardinternational.casemanagement.service.decision.domain.model.policy.Policy;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.DocumentRequiredSignatory;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.RequiredSignatory;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.SignatoryResult;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.signatories.AbstractDocumentRequiredSignatoryBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.signatories.ResponseMessageBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.signatories.SignatoriesBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.utils.SignatoryUtils;
import com.lombardinternational.casemanagement.service.decision.domain.utils.WebformUtils;

import lombok.RequiredArgsConstructor;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.WebFormFieldConstants.*;

@Service
@RequiredArgsConstructor
public class AdditionSignatoriesBuilderService implements SignatoriesBuilderService {

    private final ResponseMessageBuilderService responseMessageBuilderService;
    private final AdditionSignatoriesRequestFormProvider requestFormBuilderService;
    private final AdditionSignatoriesProcurationProvider procurationBuilderService;
    private final AdditionSignatoriesKycProvider kycBuilderService;
    private final AdditionSignatoriesFundAnnexProvider fundAnnexBuilderService;

    @Override
    public SignatoryResult buildSignatories(Policy policy, WebForm webForm) {

        DocumentRequiredSignatory.resetDocumentOrder();
        final List<DocumentRequiredSignatory> documentRequiredSignatories = new ArrayList<>();

        final var kycGrp = WebformUtils.getFirstWebFormGroupById(webForm, KYC_WF);
        Stream<List<AbstractDocumentRequiredSignatoryBuilderService>> builders;
        if (Boolean.parseBoolean(WebformUtils.getWebFormFieldValueById(kycGrp, IS_KYC_REQUIRED_WF))) {
            builders = Stream.of(requestFormBuilderService.getAll(), procurationBuilderService.getAll(), fundAnnexBuilderService.getAll(),
                    kycBuilderService.getAll());
        } else {
            builders = Stream.of(requestFormBuilderService.getAll(), procurationBuilderService.getAll(), fundAnnexBuilderService.getAll());
        }

        final List<RequiredSignatory> signatories = SignatoryUtils.buildSignatories(webForm);
        builders.flatMap(Collection::stream)
                .forEach(builder -> builder.buildRequiredSignatory(webForm, policy, documentRequiredSignatories, signatories));

        return new SignatoryResult(documentRequiredSignatories, responseMessageBuilderService.buildResponseMessage());
    }
}
