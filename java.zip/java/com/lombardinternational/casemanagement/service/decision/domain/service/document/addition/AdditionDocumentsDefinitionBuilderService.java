package com.lombardinternational.casemanagement.service.decision.domain.service.document.addition;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.lombardinternational.casemanagement.service.decision.domain.model.policy.Policy;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.DocumentDefinition;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.document.DocumentsDefinitionBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.document.addition.document.AbdominalSonogramDocumentBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.document.addition.document.AcceptableBankReferenceDocumentBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.document.addition.document.AdditionalInvestmentFormDocumentBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.document.addition.document.AdditionalMedicalQuestionnaireDocumentBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.document.addition.document.AeoiSelfCertificationDocumentBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.document.addition.document.BeratungsprotokollDocumentBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.document.addition.document.BloodTestDocumentBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.document.addition.document.CardiacEchoDocumentBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.document.addition.document.DescriptionNegativeFindingDocumentBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.document.addition.document.DifferencesPreviousKYCDocumentBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.document.addition.document.EmailUnchangedKycDocumentBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.document.addition.document.ExcelTemplateSARCalculationDocumentBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.document.addition.document.ExplanationProfessionClassificationDocumentBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.document.addition.document.FinancialUnderwritingDocumentBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.document.addition.document.JustificationWealthOriginDocumentBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.document.addition.document.MedicalExaminationReportDocumentBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.document.addition.document.PelvicUltrasoundDocumentBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.document.addition.document.ProofResidenceAmendedAddressDocumentBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.document.addition.document.QuestionarioAdeguatezzaDocumentBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.document.addition.document.ReasonKycNotObtainedDocumentBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.document.addition.document.ReasonKycNotSignedDocumentBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.document.addition.document.ReceivedChoiceOfLawDocumentBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.document.addition.document.RestingExerciseECGDocumentBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.document.addition.document.ScreeningEvidenceOriginOfWealthDocumentBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.document.addition.document.SignedConnectAgreementDocumentBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.document.addition.document.SignedScheduleChargesDocumentBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.document.addition.document.SignedSuitabilityProfileDocumentBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.document.addition.document.TaxComplianceCertificationEBODocumentBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.document.addition.document.TestHIVDocumentBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.document.addition.document.ThirdPartyEntityConstitutionalDocumentBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.document.addition.document.ThirdPartyFamilyLinkDocumentBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.document.addition.document.ThirdPartyLinkProvidedNotaryDocumentBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.document.addition.document.ThirdPartyPaymentDocumentBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.document.addition.document.ThirdPartyProofContractInstitutionDocumentBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.document.addition.document.ThirdPartyProofContractRelationDocumentBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.document.addition.document.ThirdPartyProofOwnerEntityPhDocumentBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.document.addition.document.UrinAnalysisDocumentBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.document.addition.document.W8BenFatcaDocumentBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.document.addition.document.W8BenFatca_2DocumentBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.document.commons.DisposizionProdottiFinanziariDocumentBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.document.commons.FifFormDocumentBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.document.commons.NTAValidationEmailDocumentBuilderService;

import lombok.AllArgsConstructor;

@Service
@AllArgsConstructor
public class AdditionDocumentsDefinitionBuilderService implements DocumentsDefinitionBuilderService {

    private final FifFormDocumentBuilderService fifFormService;
    private final AdditionalInvestmentFormDocumentBuilderService additionalInvestmentFormService;
    private final AbdominalSonogramDocumentBuilderService abdominalSonogramService;
    private final AcceptableBankReferenceDocumentBuilderService acceptableBankReferenceService;
    private final AdditionalMedicalQuestionnaireDocumentBuilderService additionalMedicalQuestionnaireService;
    private final AeoiSelfCertificationDocumentBuilderService aeoiSelfCertificationService;
    private final BeratungsprotokollDocumentBuilderService beratungsprotokollService;
    private final BloodTestDocumentBuilderService bloodTestService;
    private final CardiacEchoDocumentBuilderService cardiacEchoService;
    private final DescriptionNegativeFindingDocumentBuilderService descriptionNegativeFindingService;
    private final DifferencesPreviousKYCDocumentBuilderService differencesPreviousKYCService;
    private final DisposizionProdottiFinanziariDocumentBuilderService disposizionProdottiFinanziariService;
    private final EmailUnchangedKycDocumentBuilderService emailUnchangedKycService;
    private final ExcelTemplateSARCalculationDocumentBuilderService excelTemplateSARCalculationService;
    private final ExplanationProfessionClassificationDocumentBuilderService explanationProfessionClassificationService;
    private final FinancialUnderwritingDocumentBuilderService financialUnderwritingService;
    private final JustificationWealthOriginDocumentBuilderService justificationWealthOriginService;
    private final MedicalExaminationReportDocumentBuilderService medicalExaminationReportService;
    private final NTAValidationEmailDocumentBuilderService ntaValidationEmailService;
    private final PelvicUltrasoundDocumentBuilderService pelvicUltrasoundService;
    private final ProofResidenceAmendedAddressDocumentBuilderService proofResidenceAmendedAddressService;
    private final QuestionarioAdeguatezzaDocumentBuilderService questionarioAdeguatezzaService;
    private final ReasonKycNotObtainedDocumentBuilderService reasonKycNotObtainedService;
    private final ReasonKycNotSignedDocumentBuilderService reasonKycNotSignedService;
    private final ReceivedChoiceOfLawDocumentBuilderService receivedChoiceOfLawService;
    private final RestingExerciseECGDocumentBuilderService restingExerciseECGService;
    private final ScreeningEvidenceOriginOfWealthDocumentBuilderService screeningEvidenceOriginOfWealthService;
    private final SignedConnectAgreementDocumentBuilderService signedConnectAgreementService;
    private final SignedScheduleChargesDocumentBuilderService signedScheduleChargesService;
    private final SignedSuitabilityProfileDocumentBuilderService signedSuitabilityProfileService;
    private final TaxComplianceCertificationEBODocumentBuilderService taxComplianceCertificationEBOService;
    private final TestHIVDocumentBuilderService testHIVService;
    private final ThirdPartyEntityConstitutionalDocumentBuilderService thirdPartyEntityConstitutionalService;
    private final ThirdPartyFamilyLinkDocumentBuilderService thirdPartyFamilyLinkService;
    private final ThirdPartyLinkProvidedNotaryDocumentBuilderService thirdPartyLinkProvidedNotaryService;
    private final ThirdPartyPaymentDocumentBuilderService thirdPartyPaymentService;
    private final ThirdPartyProofContractInstitutionDocumentBuilderService thirdPartyProofContractInstitutionService;
    private final ThirdPartyProofContractRelationDocumentBuilderService thirdPartyProofContractRelationService;
    private final ThirdPartyProofOwnerEntityPhDocumentBuilderService thirdPartyProofOwnerEntityPhService;
    private final UrinAnalysisDocumentBuilderService urinAnalysisService;
    private final W8BenFatca_2DocumentBuilderService w8BenFatca2Service;
    private final W8BenFatcaDocumentBuilderService w8BenFatcaService;

    @Override
    public List<DocumentDefinition> buildDocumentsDefinition(Policy policy, WebForm webForm, ScreenDescription screenDescription,
            String transactionNumber) throws Exception {

        DocumentDefinition.resetDocumentOrder();
        final var documents = new ArrayList<DocumentDefinition>();
        fifFormService.buildDocument(webForm, screenDescription, transactionNumber, documents);
        additionalInvestmentFormService.buildDocument(webForm, screenDescription, transactionNumber, documents);
        abdominalSonogramService.buildDocument(webForm, screenDescription, transactionNumber, documents);
        acceptableBankReferenceService.buildDocument(webForm, screenDescription, transactionNumber, documents);
        additionalMedicalQuestionnaireService.buildDocument(webForm, screenDescription, transactionNumber, documents);
        aeoiSelfCertificationService.buildDocument(webForm, screenDescription, transactionNumber, documents);
        beratungsprotokollService.buildDocument(webForm, screenDescription, transactionNumber, documents);
        bloodTestService.buildDocument(webForm, screenDescription, transactionNumber, documents);
        cardiacEchoService.buildDocument(webForm, screenDescription, transactionNumber, documents);
        descriptionNegativeFindingService.buildDocument(webForm, screenDescription, transactionNumber, documents);
        differencesPreviousKYCService.buildDocument(webForm, screenDescription, transactionNumber, documents);
        disposizionProdottiFinanziariService.buildDocument(webForm, screenDescription, transactionNumber, documents);
        emailUnchangedKycService.buildDocument(webForm, screenDescription, transactionNumber, documents);
        excelTemplateSARCalculationService.buildDocument(webForm, screenDescription, transactionNumber, documents);
        explanationProfessionClassificationService.buildDocument(webForm, screenDescription, transactionNumber, documents);
        financialUnderwritingService.buildDocument(webForm, screenDescription, transactionNumber, documents);
        justificationWealthOriginService.buildDocument(webForm, screenDescription, transactionNumber, documents);
        medicalExaminationReportService.buildDocument(webForm, screenDescription, transactionNumber, documents);
        ntaValidationEmailService.buildDocument(webForm, screenDescription, transactionNumber, documents);
        pelvicUltrasoundService.buildDocument(webForm, screenDescription, transactionNumber, documents);
        proofResidenceAmendedAddressService.buildDocument(webForm, screenDescription, transactionNumber, documents);
        questionarioAdeguatezzaService.buildDocument(webForm, screenDescription, transactionNumber, documents);
        reasonKycNotObtainedService.buildDocument(webForm, screenDescription, transactionNumber, documents);
        reasonKycNotSignedService.buildDocument(webForm, screenDescription, transactionNumber, documents);
        receivedChoiceOfLawService.buildDocument(webForm, screenDescription, transactionNumber, documents);
        restingExerciseECGService.buildDocument(webForm, screenDescription, transactionNumber, documents);
        screeningEvidenceOriginOfWealthService.buildDocument(webForm, screenDescription, transactionNumber, documents);
        signedConnectAgreementService.buildDocument(webForm, screenDescription, transactionNumber, documents);
        signedScheduleChargesService.buildDocument(webForm, screenDescription, transactionNumber, documents);
        signedSuitabilityProfileService.buildDocument(webForm, screenDescription, transactionNumber, documents);
        taxComplianceCertificationEBOService.buildDocument(webForm, screenDescription, transactionNumber, documents);
        testHIVService.buildDocument(webForm, screenDescription, transactionNumber, documents);
        thirdPartyEntityConstitutionalService.buildDocument(webForm, screenDescription, transactionNumber, documents);
        thirdPartyFamilyLinkService.buildDocument(webForm, screenDescription, transactionNumber, documents);
        thirdPartyLinkProvidedNotaryService.buildDocument(webForm, screenDescription, transactionNumber, documents);
        thirdPartyPaymentService.buildDocument(webForm, screenDescription, transactionNumber, documents);
        thirdPartyProofContractInstitutionService.buildDocument(webForm, screenDescription, transactionNumber, documents);
        thirdPartyProofContractRelationService.buildDocument(webForm, screenDescription, transactionNumber, documents);
        thirdPartyProofOwnerEntityPhService.buildDocument(webForm, screenDescription, transactionNumber, documents);
        urinAnalysisService.buildDocument(webForm, screenDescription, transactionNumber, documents);
        w8BenFatca2Service.buildDocument(webForm, screenDescription, transactionNumber, documents);
        w8BenFatcaService.buildDocument(webForm, screenDescription, transactionNumber, documents);

        return documents;
    }
}
