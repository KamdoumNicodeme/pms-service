package com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control;

import java.util.Collections;
import java.util.List;

import org.springframework.stereotype.Service;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ControlDefinition;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.AbstractControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.utils.Constraint;
import com.lombardinternational.casemanagement.service.decision.domain.utils.FieldConstraint;

import static com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control.common.Utils.*;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ChecklistFieldConstants.*;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ControlConstants.*;

@Service
public class NoProofOfDeregistrationControlBuilderService extends AbstractControlBuilderService {

    @Override
    public ControlDefinition buildControl(WebForm webForm, ScreenDescription screenDescription) {

        List<List<FieldConstraint>> constraintGroups = List.of(buildSwissConstraintsPair(FORMER_SWISS_PH, PROOF_DEREGISTRATION_PH),
                buildSwissConstraintsPair(FORMER_SWISS_EBO, PROOF_DEREGISTRATION_EBO),
                buildSwissConstraintsPair(FORMER_SWISS_LA, PROOF_DEREGISTRATION_LA));

        if (constraintGroups.stream().anyMatch(group -> group.stream().allMatch(constraint -> constraint.test(screenDescription)))) {
            return buildControlDefinition();
        }
        return null;

    }

    private List<FieldConstraint> buildSwissConstraintsPair(String formerSwissFieldId, String proofDeregistrationFieldId) {

        return List.of(createConstraint(formerSwissFieldId, Constraint.EQUALS, Collections.singletonList(YES)),
                createConstraint(proofDeregistrationFieldId, Constraint.EQUALS, Collections.singletonList(NO)));
    }

    @Override
    protected String getControlName() {

        return NO_PROOF_OF_DEREGISTRATION_NAME;
    }

    @Override
    protected String getControlType() {

        return NO_PROOF_OF_DEREGISTRATION_TYPE;
    }
}
