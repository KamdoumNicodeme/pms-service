package com.lombardinternational.casemanagement.service.decision.domain.service.taskscreen.addition.fields;

import java.util.Optional;

import org.springframework.stereotype.Service;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Field;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Group;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.SelectInputField;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.TextInputField;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.taskscreen.TaskScreenFieldBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.spi.repository.ReferenceDataRepositoryService;
import com.lombardinternational.casemanagement.service.decision.domain.utils.ChecklistUtils;

import lombok.AllArgsConstructor;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ChecklistFieldConstants.ANNUAL_INCOME;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ChecklistFieldConstants.ANNUAL_INCOME_FORCED;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ChecklistFieldConstants.EBO_COUNTRY;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ChecklistFieldConstants.FORCED_POSITION_RISK;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ChecklistFieldConstants.INDUSTRY_RISK;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ChecklistFieldConstants.NEGATIVE_FINDING;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ChecklistFieldConstants.ORIGINATOR_NAME;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ChecklistFieldConstants.PEP;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ChecklistFieldConstants.PH_RESIDENCE_COUNTRY;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ChecklistFieldConstants.PROXY_COUNTRY;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ChecklistFieldConstants.SIGNATORY_MAX_RISK;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ChecklistFieldConstants.THIRD_PARTY_COUNTRY_RISK;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ChecklistFieldConstants.WEALTH_ORIGINATING_COUNTRY_1;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ChecklistFieldConstants.WEALTH_ORIGINATING_COUNTRY_1_RISK;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ChecklistFieldConstants.WEALTH_ORIGINATING_COUNTRY_2;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ChecklistFieldConstants.WEALTH_ORIGINATING_COUNTRY_2_RISK;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ReferenceConstants.YES_NO_DOMAIN;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.TaskScreenConstants.ANNUAL_INCOME_FIELD;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.TaskScreenConstants.ANNUAL_INCOME_OVERRIDE_FIELD;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.TaskScreenConstants.COUNTRY_OF_THIRD_PARTY_RISK_FIELD;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.TaskScreenConstants.EBO_COUNTRY_FIELD;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.TaskScreenConstants.INDUSTRY_RISK_FIELD;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.TaskScreenConstants.INDUSTRY_RISK_FORCED_FIELD;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.TaskScreenConstants.IRREVOCABLE_BEN_COUNTRY_FIELD;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.TaskScreenConstants.NEGATIVE_FINDING_FIELD;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.TaskScreenConstants.ORIGINATOR_NAME_FIELD;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.TaskScreenConstants.PEP_FIELD;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.TaskScreenConstants.PH_RESIDENCE_COUNTRY_FIELD;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.TaskScreenConstants.PROXY_COUNTRY_FIELD;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.TaskScreenConstants.SIGNATORY_COUNTRY_FIELD;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.TaskScreenConstants.TRANSACTION_THRESHOLD_FIELD;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.TaskScreenConstants.WEALTH_ORIGINATING_COUNTRY_1_FIELD;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.TaskScreenConstants.WEALTH_ORIGINATING_COUNTRY_1_RISK_FIELD;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.TaskScreenConstants.WEALTH_ORIGINATING_COUNTRY_2_FIELD;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.TaskScreenConstants.WEALTH_ORIGINATING_COUNTRY_2_RISK_FIELD;

@Service
@AllArgsConstructor
public class ChecklistDataFieldsBuilderService implements TaskScreenFieldBuilderService {

    private final ReferenceDataRepositoryService referenceDataRepositoryService;

    @Override
    public void buildField(final WebForm webForm, final ScreenDescription screenCheckList, final ScreenDescription screenToFill,
            final Group group) {

        Field.resetFieldId();
        evaluateTransactionThreshold(group);
        evaluatePhResidenceCountry(group, screenCheckList);
        evaluateProxyCountry(group, screenCheckList);
        evaluateSignatoryCountry(group, screenCheckList);
        evaluateEboCountry(group, screenCheckList);
        evaluateIrrevocableBenCountry(group, screenCheckList);
        evaluateOriginatorName(group, screenCheckList);
        evaluateIndustryRisk(group, screenCheckList);
        evaluateIndustryRiskForced(group, screenCheckList);
        evaluateWealthOriginatingCountry_1(group, screenCheckList);
        evaluateWealthOriginatingCountry_1_Risk(group, screenCheckList);
        evaluateWealthOriginatingCountry_2(group, screenCheckList);
        evaluateWealthOriginatingCountry_2_Risk(group, screenCheckList);
        evaluateNegativeFinding(group, screenCheckList);
        evaluatePep(group, screenCheckList);
        evaluateAnnualIncome(group, screenCheckList);
        evaluateAnnualIncomeOverride(group, screenCheckList);
        evaluateCountryOfThirdPartyRisk(group, screenCheckList);
    }

    private void evaluateTransactionThreshold(Group group) {

        var transactionThreshold = (TextInputField) ChecklistUtils.getFieldInGroup(group, TRANSACTION_THRESHOLD_FIELD);
        if (transactionThreshold == null) {
            transactionThreshold = TextInputField.builder().fieldId(TRANSACTION_THRESHOLD_FIELD).build();
            group.getFields().add(transactionThreshold);
        }
        transactionThreshold.setIsActive(true);
        transactionThreshold.incrementOrder();
        transactionThreshold.setLabel("Transaction threshold");

        // forced value is empty in Excel
    }

    private void evaluatePhResidenceCountry(Group group, ScreenDescription screenCheckList) {

        var phResidenceCountry = (TextInputField) ChecklistUtils.getFieldInGroup(group, PH_RESIDENCE_COUNTRY_FIELD);
        if (phResidenceCountry == null) {
            phResidenceCountry = TextInputField.builder().fieldId(PH_RESIDENCE_COUNTRY_FIELD).build();
            group.getFields().add(phResidenceCountry);
        }
        phResidenceCountry.setIsActive(true);
        phResidenceCountry.incrementOrder();
        phResidenceCountry.setLabel("PH residence country risk");
        Optional<Field> phResidenceCountryOpt = ChecklistUtils.getFieldById(screenCheckList, PH_RESIDENCE_COUNTRY);
        phResidenceCountry.setSelectedValue(phResidenceCountryOpt.map(Field::getSelectedValue).orElse(null));
    }

    private void evaluateProxyCountry(Group group, ScreenDescription screenCheckList) {

        var proxyCountry = (TextInputField) ChecklistUtils.getFieldInGroup(group, PROXY_COUNTRY_FIELD);
        if (proxyCountry == null) {
            proxyCountry = TextInputField.builder().fieldId(PROXY_COUNTRY_FIELD).build();
            group.getFields().add(proxyCountry);
        }
        proxyCountry.setIsActive(true);
        proxyCountry.incrementOrder();
        proxyCountry.setLabel("Proxy residence country risk");
        Optional<Field> proxyCountryOpt = ChecklistUtils.getFieldById(screenCheckList, PROXY_COUNTRY);
        proxyCountry.setSelectedValue(proxyCountryOpt.map(Field::getSelectedValue).orElse(null));
    }

    // TODO
    // Field SIGNATORY_MAX_RISK no longer implemented in checklist
    private void evaluateSignatoryCountry(Group group, ScreenDescription screenCheckList) {

        var signatoryCountry = (TextInputField) ChecklistUtils.getFieldInGroup(group, SIGNATORY_COUNTRY_FIELD);
        if (signatoryCountry == null) {
            signatoryCountry = TextInputField.builder().fieldId(SIGNATORY_COUNTRY_FIELD).build();
            group.getFields().add(signatoryCountry);
        }
        signatoryCountry.setIsActive(true);
        signatoryCountry.incrementOrder();
        signatoryCountry.setLabel("Signatories country max risk");
        Optional<Field> signatoryCountryOpt = ChecklistUtils.getFieldById(screenCheckList, SIGNATORY_MAX_RISK);
        signatoryCountry.setSelectedValue(signatoryCountryOpt.map(Field::getSelectedValue).orElse(null));
    }

    private void evaluateEboCountry(Group group, ScreenDescription screenCheckList) {

        var eboCountry = (TextInputField) ChecklistUtils.getFieldInGroup(group, EBO_COUNTRY_FIELD);
        if (eboCountry == null) {
            eboCountry = TextInputField.builder().fieldId(EBO_COUNTRY_FIELD).build();
            group.getFields().add(eboCountry);
        }
        eboCountry.setIsActive(true);
        eboCountry.incrementOrder();
        eboCountry.setLabel("EBO residence country risk");
        Optional<Field> eboCountryOpt = ChecklistUtils.getFieldById(screenCheckList, EBO_COUNTRY);
        eboCountry.setSelectedValue(eboCountryOpt.map(Field::getSelectedValue).orElse(null));
    }

    private void evaluateIrrevocableBenCountry(Group group, ScreenDescription screenCheckList) {

        var irrevocableBenCountry = (TextInputField) ChecklistUtils.getFieldInGroup(group, IRREVOCABLE_BEN_COUNTRY_FIELD);
        if (irrevocableBenCountry == null) {
            irrevocableBenCountry = TextInputField.builder().fieldId(IRREVOCABLE_BEN_COUNTRY_FIELD).build();
            group.getFields().add(irrevocableBenCountry);
        }
        irrevocableBenCountry.setIsActive(true);
        irrevocableBenCountry.incrementOrder();
        irrevocableBenCountry.setLabel("Irrevocable beneficiary residence country risk");
        Optional<Field> irrevocableBenCountryOpt = ChecklistUtils.getFieldById(screenCheckList, EBO_COUNTRY);
        irrevocableBenCountry.setSelectedValue(irrevocableBenCountryOpt.map(Field::getSelectedValue).orElse(null));
        // TODO
        // in the excel file we are retrieving the data from EBO_COUNTRY aren't we supposed to map IRREVOCABLE_BEN_COUNTRY instead
    }

    private void evaluateOriginatorName(Group group, ScreenDescription screenCheckList) {

        // TODO
        // ORIGINATOR_NAME is a dynamic field if the checklist so we need to handle the position
        /**
         * List<Field> originatorNameList = ChecklistUtils.getFieldsById(screenCheckList, ORIGINATOR_NAME);
         * IntStream.range(0, originatorNameList.size()).forEach(i -> {
         * var originatorName = (TextInputField) ChecklistUtils.getFieldInGroup(group, ORIGINATOR_NAME_FIELD + "_" + i);
         * if (originatorName == null) {
         * originatorName = TextInputField.builder().fieldId(ORIGINATOR_NAME_FIELD + "_" + i).build();
         * group.getFields().add(originatorName);
         * }
         * originatorName.setIsActive(true);
         * originatorName.incrementOrder();
         * originatorName.setLabel("Originator of wealth");
         * originatorName.setSelectedValue(originatorNameList.get(i).getSelectedValue());
         *
         * });
         **/
        var originatorName = (TextInputField) ChecklistUtils.getFieldInGroup(group, ORIGINATOR_NAME_FIELD);
        if (originatorName == null) {
            originatorName = TextInputField.builder().fieldId(ORIGINATOR_NAME_FIELD).build();
            group.getFields().add(originatorName);
        }
        originatorName.setIsActive(true);
        originatorName.incrementOrder();
        originatorName.setLabel("Originator of wealth");
        var originatorNameField = ChecklistUtils.getFieldById(screenCheckList, ORIGINATOR_NAME);
        originatorName.setSelectedValue(originatorNameField.map(Field::getSelectedValue).orElse(null));
    }

    private void evaluateIndustryRisk(Group group, ScreenDescription screenCheckList) {

        // TODO
        // INDUSTRY is a dynamic field if the checklist so we need to handle the position
        // The field that is used today in the TasScreen excel is INDUSTRY_RISK
        /**
         * List<Field> industryList = ChecklistUtils.getFieldsById(screenCheckList, INDUSTRY);
         * IntStream.range(0, industryList.size()).forEach(i -> {
         * var industryRisk = (TextInputField) ChecklistUtils.getFieldInGroup(group, INDUSTRY_RISK_FIELD + "_" + i);
         * if (industryRisk == null) {
         * industryRisk = TextInputField.builder().fieldId(INDUSTRY_RISK_FIELD + "_" + i).build();
         * group.getFields().add(industryRisk);
         * }
         * industryRisk.setIsActive(true);
         * industryRisk.incrementOrder();
         * industryRisk.setLabel("Industry risk");
         * industryRisk.setSelectedValue(industryList.get(i).getSelectedValue());
         * });
         **/
        var industryRisk = (TextInputField) ChecklistUtils.getFieldInGroup(group, INDUSTRY_RISK_FIELD);
        if (industryRisk == null) {
            industryRisk = TextInputField.builder().fieldId(INDUSTRY_RISK_FIELD).build();
            group.getFields().add(industryRisk);
        }
        industryRisk.setIsActive(true);
        industryRisk.incrementOrder();
        industryRisk.setLabel("Industry risk");
        var industryField = ChecklistUtils.getFieldById(screenCheckList, INDUSTRY_RISK);
        industryRisk.setSelectedValue(industryField.map(Field::getSelectedValue).orElse(null));

    }

    private void evaluateIndustryRiskForced(Group group, ScreenDescription screenCheckList) {

        // TODO
        // Field FORCED_POSITION_RISK no longer implemented in checklist
        var industryRisk = (TextInputField) ChecklistUtils.getFieldInGroup(group, INDUSTRY_RISK_FORCED_FIELD);
        if (industryRisk == null) {
            industryRisk = TextInputField.builder().fieldId(INDUSTRY_RISK_FORCED_FIELD).build();
            group.getFields().add(industryRisk);
        }
        industryRisk.setIsActive(true);
        industryRisk.incrementOrder();
        industryRisk.setLabel("Override industry risk");
        var industryField = ChecklistUtils.getFieldById(screenCheckList, FORCED_POSITION_RISK);
        industryRisk.setSelectedValue(industryField.map(Field::getSelectedValue).orElse(null));

    }

    private void evaluateWealthOriginatingCountry_1(Group group, ScreenDescription screenCheckList) {

        // TODO
        // Field WEALTH_ORIGINATING_COUNTRY_1 no longer implemented in checklist
        var wealthOriginatingCountry_1 = (TextInputField) ChecklistUtils.getFieldInGroup(group, WEALTH_ORIGINATING_COUNTRY_1_FIELD);
        if (wealthOriginatingCountry_1 == null) {
            wealthOriginatingCountry_1 = TextInputField.builder().fieldId(WEALTH_ORIGINATING_COUNTRY_1_FIELD).build();
            group.getFields().add(wealthOriginatingCountry_1);
        }
        wealthOriginatingCountry_1.setIsActive(true);
        wealthOriginatingCountry_1.incrementOrder();
        wealthOriginatingCountry_1.setLabel("Wealth originating country 1");
        Optional<Field> wealthOriginatingCountry_1_Opt = ChecklistUtils.getFieldById(screenCheckList, WEALTH_ORIGINATING_COUNTRY_1);
        wealthOriginatingCountry_1.setSelectedValue(wealthOriginatingCountry_1_Opt.map(Field::getSelectedValue).orElse(null));
    }

    private void evaluateWealthOriginatingCountry_1_Risk(Group group, ScreenDescription screenCheckList) {

        var wealthOriginatingCountry_1_Risk = (TextInputField) ChecklistUtils.getFieldInGroup(group, WEALTH_ORIGINATING_COUNTRY_1_RISK_FIELD);
        if (wealthOriginatingCountry_1_Risk == null) {
            wealthOriginatingCountry_1_Risk = TextInputField.builder().fieldId(WEALTH_ORIGINATING_COUNTRY_1_RISK_FIELD).build();
            group.getFields().add(wealthOriginatingCountry_1_Risk);
        }
        wealthOriginatingCountry_1_Risk.setIsActive(true);
        wealthOriginatingCountry_1_Risk.incrementOrder();
        wealthOriginatingCountry_1_Risk.setLabel("Wealth originating country 1 risk");
        Optional<Field> wealthOriginatingCountry_1_RiskOpt = ChecklistUtils.getFieldById(screenCheckList, WEALTH_ORIGINATING_COUNTRY_1_RISK);
        wealthOriginatingCountry_1_Risk.setSelectedValue(wealthOriginatingCountry_1_RiskOpt.map(Field::getSelectedValue).orElse(null));
    }

    private void evaluateWealthOriginatingCountry_2(Group group, ScreenDescription screenCheckList) {

        // TODO
        // Field WEALTH_ORIGINATING_COUNTRY_2 no longer implemented in checklist
        var wealthOriginatingCountry_2 = (TextInputField) ChecklistUtils.getFieldInGroup(group, WEALTH_ORIGINATING_COUNTRY_2_FIELD);
        if (wealthOriginatingCountry_2 == null) {
            wealthOriginatingCountry_2 = TextInputField.builder().fieldId(WEALTH_ORIGINATING_COUNTRY_2_FIELD).build();
            group.getFields().add(wealthOriginatingCountry_2);
        }
        wealthOriginatingCountry_2.setIsActive(true);
        wealthOriginatingCountry_2.incrementOrder();
        wealthOriginatingCountry_2.setLabel("Wealth originating country 2");
        Optional<Field> wealthOriginatingCountry_2_Opt = ChecklistUtils.getFieldById(screenCheckList, WEALTH_ORIGINATING_COUNTRY_2);
        wealthOriginatingCountry_2.setSelectedValue(wealthOriginatingCountry_2_Opt.map(Field::getSelectedValue).orElse(null));
    }

    private void evaluateWealthOriginatingCountry_2_Risk(Group group, ScreenDescription screenCheckList) {

        var wealthOriginatingCountry_2_Risk = (TextInputField) ChecklistUtils.getFieldInGroup(group, WEALTH_ORIGINATING_COUNTRY_2_RISK_FIELD);
        if (wealthOriginatingCountry_2_Risk == null) {
            wealthOriginatingCountry_2_Risk = TextInputField.builder().fieldId(WEALTH_ORIGINATING_COUNTRY_2_RISK_FIELD).build();
            group.getFields().add(wealthOriginatingCountry_2_Risk);
        }
        wealthOriginatingCountry_2_Risk.setIsActive(true);
        wealthOriginatingCountry_2_Risk.incrementOrder();
        wealthOriginatingCountry_2_Risk.setLabel("Wealth originating country 2 risk");
        Optional<Field> wealthOriginatingCountry_2_Risk_Opt = ChecklistUtils.getFieldById(screenCheckList, WEALTH_ORIGINATING_COUNTRY_2_RISK);
        wealthOriginatingCountry_2_Risk.setSelectedValue(wealthOriginatingCountry_2_Risk_Opt.map(Field::getSelectedValue).orElse(null));
    }

    private void evaluateNegativeFinding(Group group, ScreenDescription screenCheckList) {

        var negativeFinding = (SelectInputField) ChecklistUtils.getFieldInGroup(group, NEGATIVE_FINDING_FIELD);
        if (negativeFinding == null) {
            negativeFinding = SelectInputField.builder().fieldId(NEGATIVE_FINDING_FIELD).build();
            group.getFields().add(negativeFinding);
        }
        negativeFinding.setIsActive(true);
        negativeFinding.incrementOrder();
        negativeFinding.setLabel("Negative finding / Worldcheck match");
        Optional<Field> negativeFindingOpt = ChecklistUtils.getFieldById(screenCheckList, NEGATIVE_FINDING);
        negativeFinding.setSelectedValue(negativeFindingOpt.map(Field::getSelectedValue).orElse(null));
        negativeFinding.setOptions(
                referenceDataRepositoryService.getReferenceDataOptionsByDomainAndSelectedValue(YES_NO_DOMAIN, negativeFinding.getSelectedValue()));
    }

    private void evaluatePep(Group group, ScreenDescription screenCheckList) {

        var pep = (SelectInputField) ChecklistUtils.getFieldInGroup(group, PEP_FIELD);
        if (pep == null) {
            pep = SelectInputField.builder().fieldId(PEP_FIELD).build();
            group.getFields().add(pep);
        }
        pep.setIsActive(true);
        pep.incrementOrder();
        pep.setLabel("Is there a PEP (PH-LA-EBO-Proxy-DIR-SHA-AS-Payee)");
        Optional<Field> pepOpt = ChecklistUtils.getFieldById(screenCheckList, PEP);
        pep.setSelectedValue(pepOpt.map(Field::getSelectedValue).orElse(null));
    }

    private void evaluateAnnualIncomeOverride(Group group, ScreenDescription screenCheckList) {

        // TODO
        // ANNUAL_INCOME is a dynamic field if the checklist so we need to handle the position
        /**
         * List<Field> annualIncomeList = ChecklistUtils.getFieldsById(screenCheckList, ANNUAL_INCOME);
         * IntStream.range(0, annualIncomeList.size()).forEach(i -> {
         * var annualIncomeOverride = (TextInputField) ChecklistUtils.getFieldInGroup(group, ANNUAL_INCOME_FIELD + "_" + i);
         * if (annualIncomeOverride == null) {
         * annualIncomeOverride = TextInputField.builder().fieldId(ANNUAL_INCOME_OVERRIDE_FIELD).build();
         * group.getFields().add(annualIncomeOverride);
         * }
         * annualIncomeOverride.setIsActive(true);
         * annualIncomeOverride.incrementOrder();
         * annualIncomeOverride.setLabel("Annual income");
         * annualIncomeOverride.setSelectedValue(annualIncomeList.get(i).getSelectedValue());
         * });
         **/
        var annualIncomeOverride = (TextInputField) ChecklistUtils.getFieldInGroup(group, ANNUAL_INCOME_OVERRIDE_FIELD);
        if (annualIncomeOverride == null) {
            annualIncomeOverride = TextInputField.builder().fieldId(ANNUAL_INCOME_OVERRIDE_FIELD).build();
            group.getFields().add(annualIncomeOverride);
        }
        annualIncomeOverride.setIsActive(true);
        annualIncomeOverride.incrementOrder();
        annualIncomeOverride.setLabel("Annual income");
        var annualIncome = ChecklistUtils.getFieldById(screenCheckList, ANNUAL_INCOME);
        annualIncomeOverride.setSelectedValue(annualIncome.map(Field::getSelectedValue).orElse(null));
    }

    private void evaluateAnnualIncome(Group group, ScreenDescription screenCheckList) {

        var annualIncome = (TextInputField) ChecklistUtils.getFieldInGroup(group, ANNUAL_INCOME_FIELD);
        if (annualIncome == null) {
            annualIncome = TextInputField.builder().fieldId(ANNUAL_INCOME_FIELD).build();
            group.getFields().add(annualIncome);
        }
        annualIncome.setIsActive(true);
        annualIncome.incrementOrder();
        annualIncome.setLabel("Third party coutry max risk");
        var countryOfThirdPartyRiskOpt = ChecklistUtils.getFieldById(screenCheckList, THIRD_PARTY_COUNTRY_RISK);
        annualIncome.setSelectedValue(countryOfThirdPartyRiskOpt.map(Field::getSelectedValue).orElse(null));

    }

    private void evaluateCountryOfThirdPartyRisk(Group group, ScreenDescription screenCheckList) {

        // TODO
        // Field ANNUAL_INCOME_FORCED no longer implemented in checklist
        var annualIncome = (TextInputField) ChecklistUtils.getFieldInGroup(group, COUNTRY_OF_THIRD_PARTY_RISK_FIELD);
        if (annualIncome == null) {
            annualIncome = TextInputField.builder().fieldId(COUNTRY_OF_THIRD_PARTY_RISK_FIELD).build();
            group.getFields().add(annualIncome);
        }
        annualIncome.setIsActive(true);
        annualIncome.incrementOrder();
        annualIncome.setLabel("Annual income (manual override)");
        var countryOfThirdPartyRiskOpt = ChecklistUtils.getFieldById(screenCheckList, ANNUAL_INCOME_FORCED);
        annualIncome.setSelectedValue(countryOfThirdPartyRiskOpt.map(Field::getSelectedValue).orElse(null));

    }
}
