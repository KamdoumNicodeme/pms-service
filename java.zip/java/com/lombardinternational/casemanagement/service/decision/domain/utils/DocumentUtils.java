package com.lombardinternational.casemanagement.service.decision.domain.utils;

import org.apache.commons.lang3.StringUtils;

public class DocumentUtils {

    public static void buildRelatedTo(StringBuilder builder, String type, String name, String firstName, String clientNumber) {

        builder.append(type).append(" ");
        if (firstName != null) {
            builder.append(firstName).append(" ");
        }
        if (StringUtils.isNotBlank(clientNumber)) {
            builder.append(name).append(" - ").append(clientNumber);
        }
    }
}
