package com.lombardinternational.casemanagement.service.decision.domain.model.policy;

public class PolicyLink extends PolicyRole {
}
