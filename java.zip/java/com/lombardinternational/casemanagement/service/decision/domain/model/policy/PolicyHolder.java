package com.lombardinternational.casemanagement.service.decision.domain.model.policy;

import lombok.Builder;
import lombok.Data;

import java.util.List;

@Data
@Builder
public class PolicyHolder {

    private String taxResidency;
    private PolicyHolderSendingAddress sendingAddress;
    private String discreetLevel;
    private List<String> languages;
}
