package com.lombardinternational.casemanagement.service.decision.domain.model.policy;

import java.math.BigDecimal;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Amount {

    private BigDecimal quantity;
    private String isoCurrencyCode;
}
