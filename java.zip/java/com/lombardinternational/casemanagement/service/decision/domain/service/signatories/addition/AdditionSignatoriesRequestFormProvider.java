package com.lombardinternational.casemanagement.service.decision.domain.service.signatories.addition;

import java.util.List;

import org.springframework.stereotype.Component;

import com.lombardinternational.casemanagement.service.decision.domain.service.signatories.AbstractDocumentRequiredSignatoryBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.signatories.addition.requestform.RequestFormPCON1046;
import com.lombardinternational.casemanagement.service.decision.domain.service.signatories.addition.requestform.RequestFormPCON1047;
import com.lombardinternational.casemanagement.service.decision.domain.service.signatories.addition.requestform.RequestFormPCON1048;
import com.lombardinternational.casemanagement.service.decision.domain.service.signatories.addition.requestform.RequestFormPCON1052;
import com.lombardinternational.casemanagement.service.decision.domain.service.signatories.addition.requestform.RequestFormPCON1176;
import com.lombardinternational.casemanagement.service.decision.domain.service.signatories.addition.requestform.RequestFormPCON1190;
import com.lombardinternational.casemanagement.service.decision.domain.service.signatories.addition.requestform.RequestFormPCON1197;
import com.lombardinternational.casemanagement.service.decision.domain.service.signatories.addition.requestform.RequestFormPCON1215;
import com.lombardinternational.casemanagement.service.decision.domain.service.signatories.addition.requestform.RequestFormPCON1236;
import com.lombardinternational.casemanagement.service.decision.domain.service.signatories.addition.requestform.RequestFormPCON1314;
import com.lombardinternational.casemanagement.service.decision.domain.service.signatories.addition.requestform.RequestFormPCON1319;
import com.lombardinternational.casemanagement.service.decision.domain.service.signatories.addition.requestform.RequestFormPCON1338;
import com.lombardinternational.casemanagement.service.decision.domain.service.signatories.addition.requestform.RequestFormPCON1339;
import com.lombardinternational.casemanagement.service.decision.domain.service.signatories.addition.requestform.RequestFormPCON1359;
import com.lombardinternational.casemanagement.service.decision.domain.service.signatories.addition.requestform.RequestFormPCON1374;
import com.lombardinternational.casemanagement.service.decision.domain.service.signatories.addition.requestform.RequestFormPCON1385;
import com.lombardinternational.casemanagement.service.decision.domain.service.signatories.addition.requestform.RequestFormPCON1414;
import com.lombardinternational.casemanagement.service.decision.domain.service.signatories.addition.requestform.RequestFormPCON1426;
import com.lombardinternational.casemanagement.service.decision.domain.service.signatories.addition.requestform.RequestFormPCON1457;
import com.lombardinternational.casemanagement.service.decision.domain.service.signatories.addition.requestform.RequestFormPCON1549;
import com.lombardinternational.casemanagement.service.decision.domain.service.signatories.addition.requestform.RequestFormPCON1550;
import com.lombardinternational.casemanagement.service.decision.domain.service.signatories.addition.requestform.RequestFormPCON1551;
import com.lombardinternational.casemanagement.service.decision.domain.service.signatories.addition.requestform.RequestFormPCON1552;
import com.lombardinternational.casemanagement.service.decision.domain.service.signatories.addition.requestform.RequestFormPCON1563;
import com.lombardinternational.casemanagement.service.decision.domain.service.signatories.addition.requestform.RequestFormPCON1578;
import com.lombardinternational.casemanagement.service.decision.domain.service.signatories.addition.requestform.RequestFormPCON1579;
import com.lombardinternational.casemanagement.service.decision.domain.service.signatories.addition.requestform.RequestFormPCON1580;
import com.lombardinternational.casemanagement.service.decision.domain.service.signatories.addition.requestform.RequestFormPCON1581;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@Component
public class AdditionSignatoriesRequestFormProvider {

    private final RequestFormPCON1047 requestFormPCON1047;
    private final RequestFormPCON1048 requestFormPCON1048;
    private final RequestFormPCON1339 requestFormPCON1339;
    private final RequestFormPCON1338 requestFormPCON1338;
    private final RequestFormPCON1578 requestFormPCON1578;
    private final RequestFormPCON1052 requestFormPCON1052;
    private final RequestFormPCON1563 requestFormPCON1563;
    private final RequestFormPCON1314 requestFormPCON1314;
    private final RequestFormPCON1580 requestFormPCON1580;
    private final RequestFormPCON1046 requestFormPCON1046;
    private final RequestFormPCON1236 requestFormPCON1236;
    private final RequestFormPCON1319 requestFormPCON1319;
    private final RequestFormPCON1374 requestFormPCON1374;
    private final RequestFormPCON1385 requestFormPCON1385;
    private final RequestFormPCON1426 requestFormPCON1426;
    private final RequestFormPCON1457 requestFormPCON1457;
    private final RequestFormPCON1549 requestFormPCON1549;
    private final RequestFormPCON1550 requestFormPCON1550;
    private final RequestFormPCON1551 requestFormPCON1551;
    private final RequestFormPCON1579 requestFormPCON1579;
    private final RequestFormPCON1581 requestFormPCON1581;
    private final RequestFormPCON1176 requestFormPCON1176;
    private final RequestFormPCON1190 requestFormPCON1190;
    private final RequestFormPCON1197 requestFormPCON1197;
    private final RequestFormPCON1215 requestFormPCON1215;
    private final RequestFormPCON1359 requestFormPCON1359;
    private final RequestFormPCON1414 requestFormPCON1414;
    private final RequestFormPCON1552 requestFormPCON1552;

    public List<AbstractDocumentRequiredSignatoryBuilderService> getAll() {

        return List.of(requestFormPCON1047, requestFormPCON1048, requestFormPCON1339, requestFormPCON1338, requestFormPCON1578,
                requestFormPCON1052, requestFormPCON1563, requestFormPCON1314, requestFormPCON1580, requestFormPCON1046, requestFormPCON1236,
                requestFormPCON1319, requestFormPCON1374, requestFormPCON1385, requestFormPCON1426, requestFormPCON1457, requestFormPCON1549,
                requestFormPCON1550, requestFormPCON1551, requestFormPCON1579, requestFormPCON1581, requestFormPCON1176, requestFormPCON1190,
                requestFormPCON1197, requestFormPCON1215, requestFormPCON1359, requestFormPCON1414, requestFormPCON1552);
    }
}
