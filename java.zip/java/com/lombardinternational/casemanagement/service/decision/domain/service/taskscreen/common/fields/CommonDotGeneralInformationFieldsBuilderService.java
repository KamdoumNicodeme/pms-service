package com.lombardinternational.casemanagement.service.decision.domain.service.taskscreen.common.fields;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.*;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.taskscreen.TaskScreenFieldBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.spi.repository.ReferenceDataRepositoryService;
import com.lombardinternational.casemanagement.service.decision.domain.utils.ChecklistUtils;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.Optional;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ChecklistFieldConstants.*;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ReferenceConstants.*;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.RulesConstants.YES;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.TaskScreenConstants.*;

@Service
@AllArgsConstructor
public class CommonDotGeneralInformationFieldsBuilderService implements TaskScreenFieldBuilderService {

    private final ReferenceDataRepositoryService referenceDataRepositoryService;

    @Override
    public void buildField(final WebForm webForm, final ScreenDescription screenCheckList, final ScreenDescription screenToFill,
            final Group group) {

        Field.resetFieldId();
        evaluatePolicyCurrency(group, screenCheckList);
        evaluateValuationModel(group);
        evaluateIsMultiSupport(group, screenCheckList);
        evaluateWhereAreAssets(group);
        evaluateIlfMnemonic(group, screenCheckList);
        evaluateRunValnoff(group);
        evaluateNavVariation(group);
        evaluateCheckReview(group, screenCheckList);
        evaluateValuationCash(group);
        evaluateValuationCashCur(group);
        evaluateValuationAsset(group);
        evaluateValuationAssetCur(group);
        evaluateValuationTotal(group);
        evaluateValuationTotalCur(group);
        evaluateNotes(group);
        evaluatePortfolioInCmt(group);
    }

    private void evaluatePolicyCurrency(Group group, ScreenDescription screenCheckList) {

        var policyCurrency = (TextInputField) ChecklistUtils.getFieldInGroup(group, POLICY_CURRENCY_FIELD);
        if (policyCurrency == null) {
            policyCurrency = TextInputField.builder().fieldId(POLICY_CURRENCY_FIELD).build();
            group.getFields().add(policyCurrency);
        }
        policyCurrency.setIsActive(true);
        policyCurrency.incrementOrder();
        policyCurrency.setLabel("Policy currency");
        Optional<Field> policyCurrencyValue = ChecklistUtils.getFieldById(screenCheckList, POLICY_CURRENCY);
        if (policyCurrencyValue.isPresent()) {
            policyCurrency.setSelectedValue(policyCurrencyValue.get().getSelectedValue());
        }
    }

    private void evaluateValuationModel(Group group) {

        var valuationModel = (SelectInputField) ChecklistUtils.getFieldInGroup(group, VALUATION_MODEL_FIELD);
        if (valuationModel == null) {
            valuationModel = SelectInputField.builder().fieldId(VALUATION_MODEL_FIELD).build();
            group.getFields().add(valuationModel);
        }
        valuationModel.setIsActive(true);
        valuationModel.incrementOrder();
        valuationModel.setLabel("Valuation model");
        valuationModel.setEnabled(Boolean.TRUE);
        valuationModel.setMandatory(Boolean.TRUE);
        valuationModel.setOptions(referenceDataRepositoryService.getReferenceDataOptionsByDomain(VALUATION_MODEL_DOMAIN));
    }

    private void evaluateIsMultiSupport(Group group, ScreenDescription screenCheckList) {

        var isMultiSupport = (SelectInputField) ChecklistUtils.getFieldInGroup(group, IS_MULTISUPPORT);
        if (isMultiSupport == null) {
            isMultiSupport = SelectInputField.builder().fieldId(IS_MULTISUPPORT).build();
            group.getFields().add(isMultiSupport);
        }
        isMultiSupport.setIsActive(true);
        isMultiSupport.incrementOrder();
        isMultiSupport.setLabel("Is multisupport?");
        isMultiSupport.setEnabled(Boolean.FALSE);

        Optional<Field> isMultiSupportOptional = ChecklistUtils.getFieldById(screenCheckList, IS_MULTISUPPORT);
        String isMultiSupportValue = isMultiSupportOptional.map(Field::getSelectedValue).orElse(null);

        isMultiSupport.setSelectedValue(isMultiSupportValue);
        isMultiSupport
                .setOptions(referenceDataRepositoryService.getReferenceDataOptionsByDomainAndSelectedValue(YES_NO_DOMAIN, isMultiSupportValue));
    }

    private void evaluateWhereAreAssets(Group group) {

        var whereAreAssets = (SelectInputField) ChecklistUtils.getFieldInGroup(group, WHERE_ARE_ASSETS_FIELD);
        if (whereAreAssets == null) {
            whereAreAssets = SelectInputField.builder().fieldId(WHERE_ARE_ASSETS_FIELD).build();
            group.getFields().add(whereAreAssets);
        }
        whereAreAssets.setIsActive(true);
        whereAreAssets.incrementOrder();
        whereAreAssets.setLabel("Where are the assets?");
        whereAreAssets.setEnabled(Boolean.TRUE);
        whereAreAssets.setOptions(referenceDataRepositoryService.getReferenceDataOptionsByDomain(WHERE_ARE_ASSETS_DOMAIN));
    }

    private void evaluateIlfMnemonic(Group group, ScreenDescription screenCheckList) {

        var ilfMnemonic = (TextInputField) ChecklistUtils.getFieldInGroup(group, ILF_MNEMONIC_FIELD);
        if (ilfMnemonic == null) {
            ilfMnemonic = TextInputField.builder().fieldId(ILF_MNEMONIC_FIELD).build();
            group.getFields().add(ilfMnemonic);
        }
        ilfMnemonic.setIsActive(true);
        ilfMnemonic.incrementOrder();
        ilfMnemonic.setLabel("ILF Mnemonic");
        ilfMnemonic.setEnabled(Boolean.TRUE);
        ilfMnemonic.setMandatory(Boolean.TRUE);
        Optional<Field> investedInIlfOpt = ChecklistUtils.getFieldById(screenCheckList, INVESTED_IN_ILF);
        var investedInIlf = investedInIlfOpt.map(Field::getSelectedValue).orElse(null);
        ilfMnemonic.setDisplayIf(String.valueOf("YES".equals(investedInIlf)));
    }

    private void evaluateRunValnoff(Group group) {

        var runValnoff = (CheckBoxField) ChecklistUtils.getFieldInGroup(group, RUN_VALNOFF_FIELD);
        if (runValnoff == null) {
            runValnoff = CheckBoxField.builder().fieldId(RUN_VALNOFF_FIELD).build();
            group.getFields().add(runValnoff);
        }
        runValnoff.setIsActive(true);
        runValnoff.incrementOrder();
        runValnoff.setLabel("Run a VALNOFF before the allocate of the Addition in Class in the following cases");
        runValnoff.setEnabled(Boolean.TRUE);
        runValnoff.setMandatory(Boolean.TRUE);
        runValnoff.setDisplayIf("#" + VALUATION_MODEL_FIELD + "# == \"STANDARD\" && #" + IS_MULTISUPPORT_FIELD + "# == \"YES\"");
    }

    private void evaluateNavVariation(Group group) {

        var navVariation = (NumberInputField) ChecklistUtils.getFieldInGroup(group, NAV_VARIATION_FIELD);
        if (navVariation == null) {
            navVariation = NumberInputField.builder().fieldId(NAV_VARIATION_FIELD).build();
            group.getFields().add(navVariation);
        }
        navVariation.setIsActive(true);
        navVariation.incrementOrder();
        navVariation.setLabel("NAV variation (in %)");
        navVariation.setEnabled(Boolean.TRUE);
        navVariation.setMandatory(Boolean.TRUE);
        navVariation.setDisplayIf("#" + VALUATION_MODEL_FIELD + "# == \"STANDARD\" && #" + IS_MULTISUPPORT_FIELD + "# == \"YES\"");
    }

    private void evaluateCheckReview(Group group, ScreenDescription screenCheckList) {

        Optional<Field> premiumWithAssetsOpt = ChecklistUtils.getFieldById(screenCheckList, PREMIUM_WITH_ASSETS);
        var premiumWithAssetsValue = premiumWithAssetsOpt.map(Field::getSelectedValue).orElse(null);
        var checkReview = (SelectInputField) ChecklistUtils.getFieldInGroup(group, CHECK_REVIEW_FIELD);
        if (YES.equals(premiumWithAssetsValue)) {
            if (checkReview == null) {
                checkReview = SelectInputField.builder().fieldId(CHECK_REVIEW_FIELD).build();
                group.getFields().add(checkReview);
            }
            checkReview.setIsActive(true);
            checkReview.incrementOrder();
            checkReview.setLabel("Check if assets have been reviewed by IC & make sure that portfolio submitted is on-line with the original portfolio analysed by IC");
            checkReview.setEnabled(Boolean.TRUE);
            checkReview.setMandatory(Boolean.TRUE);
            checkReview.setOptions(referenceDataRepositoryService.getReferenceDataOptionsByDomain(YES_NO_DOMAIN));
            checkReview.setDisplayIf("true");
        } else {
            group.getFields().remove(checkReview);
        }
    }

    private void evaluateValuationCash(Group group) {

        var valuationCash = (NumberInputField) ChecklistUtils.getFieldInGroup(group, VALUATION_CASH_FIELD);
        if (valuationCash == null) {
            valuationCash = NumberInputField.builder().fieldId(VALUATION_CASH_FIELD).build();
            group.getFields().add(valuationCash);
        }
        valuationCash.setIsActive(true);
        valuationCash.incrementOrder();
        valuationCash.setLabel("Valuation - Cash");
        valuationCash.setEnabled(Boolean.TRUE);
    }

    private void evaluateValuationCashCur(Group group) {

        var valuationCashCur = (SelectInputField) ChecklistUtils.getFieldInGroup(group, VALUATION_CASH_CUR_FIELD);
        if (valuationCashCur == null) {
            valuationCashCur = SelectInputField.builder().fieldId(VALUATION_CASH_CUR_FIELD).build();
            group.getFields().add(valuationCashCur);
        }
        valuationCashCur.setIsActive(true);
        valuationCashCur.incrementOrder();
        valuationCashCur.setLabel("Currency");
        valuationCashCur.setEnabled(Boolean.TRUE);
        valuationCashCur.setOptions(referenceDataRepositoryService.getReferenceDataOptionsByDomain(CURRENCY_DOMAIN));
    }

    private void evaluateValuationAsset(Group group) {

        var valuationAsset = (NumberInputField) ChecklistUtils.getFieldInGroup(group, VALUATION_ASSET_FIELD);
        if (valuationAsset == null) {
            valuationAsset = NumberInputField.builder().fieldId(VALUATION_ASSET_FIELD).build();
            group.getFields().add(valuationAsset);
        }
        valuationAsset.setIsActive(true);
        valuationAsset.incrementOrder();
        valuationAsset.setLabel("Valuation - Asset");
        valuationAsset.setEnabled(Boolean.TRUE);
    }

    private void evaluateValuationAssetCur(Group group) {

        var valuationAssetCur = (SelectInputField) ChecklistUtils.getFieldInGroup(group, VALUATION_ASSET_CUR_FIELD);
        if (valuationAssetCur == null) {
            valuationAssetCur = SelectInputField.builder().fieldId(VALUATION_ASSET_CUR_FIELD).build();
            group.getFields().add(valuationAssetCur);
        }
        valuationAssetCur.setIsActive(true);
        valuationAssetCur.incrementOrder();
        valuationAssetCur.setLabel("Currency");
        valuationAssetCur.setEnabled(Boolean.TRUE);
        valuationAssetCur.setOptions(referenceDataRepositoryService.getReferenceDataOptionsByDomain(CURRENCY_DOMAIN));
    }

    private void evaluateValuationTotal(Group group) {

        var valuationTotal = (NumberInputField) ChecklistUtils.getFieldInGroup(group, VALUATION_TOTAL_FIELD);
        if (valuationTotal == null) {
            valuationTotal = NumberInputField.builder().fieldId(VALUATION_TOTAL_FIELD).build();
            group.getFields().add(valuationTotal);
        }
        valuationTotal.setIsActive(true);
        valuationTotal.incrementOrder();
        valuationTotal.setLabel("Valuation - Total");
        valuationTotal.setEnabled(Boolean.TRUE);
    }

    private void evaluateValuationTotalCur(Group group) {

        var valuationAssetCur = (SelectInputField) ChecklistUtils.getFieldInGroup(group, VALUATION_TOTAL_CUR_FIELD);
        if (valuationAssetCur == null) {
            valuationAssetCur = SelectInputField.builder().fieldId(VALUATION_TOTAL_CUR_FIELD).build();
            group.getFields().add(valuationAssetCur);
        }
        valuationAssetCur.setIsActive(true);
        valuationAssetCur.incrementOrder();
        valuationAssetCur.setLabel("Currency");
        valuationAssetCur.setEnabled(Boolean.TRUE);
        valuationAssetCur.setOptions(referenceDataRepositoryService.getReferenceDataOptionsByDomain(CURRENCY_DOMAIN));
    }

    private void evaluateNotes(Group group) {

        var notes = (TextAreaField) ChecklistUtils.getFieldInGroup(group, NOTES_FIELD);
        if (notes == null) {
            notes = TextAreaField.builder().fieldId(NOTES_FIELD).build();
            group.getFields().add(notes);
        }
        notes.setIsActive(true);
        notes.incrementOrder();
        notes.setLabel("Notes");
        notes.setEnabled(Boolean.TRUE);
    }

    private void evaluatePortfolioInCmt(Group group) {

        var portfolioInCmt = (CheckBoxField) ChecklistUtils.getFieldInGroup(group, PORTFOLIO_IN_CMT_FIELD);
        if (portfolioInCmt == null) {
            portfolioInCmt = CheckBoxField.builder().fieldId(PORTFOLIO_IN_CMT_FIELD).build();
            group.getFields().add(portfolioInCmt);
        }
        portfolioInCmt.setIsActive(true);
        portfolioInCmt.setMandatory(true);
        portfolioInCmt.incrementOrder();
        portfolioInCmt.setLabel("Add bank portoflio with details of positions included in the ADD in CMT case");
        portfolioInCmt.setEnabled(Boolean.TRUE);
    }

}
