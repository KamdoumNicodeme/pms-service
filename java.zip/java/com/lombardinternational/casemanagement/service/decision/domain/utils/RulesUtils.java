package com.lombardinternational.casemanagement.service.decision.domain.utils;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;

import com.lombardinternational.casemanagement.service.decision.domain.model.policy.AbstractPerson;
import com.lombardinternational.casemanagement.service.decision.domain.model.policy.Address;
import com.lombardinternational.casemanagement.service.decision.domain.model.policy.Country;
import com.lombardinternational.casemanagement.service.decision.domain.model.policy.PolicyRole;
import com.lombardinternational.casemanagement.service.decision.domain.model.policy.RiskFactorResult;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Field;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Group;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.SelectInputFieldOption;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Tab;
import com.lombardinternational.casemanagement.service.decision.domain.model.transaction.BusinessTransaction;
import com.lombardinternational.casemanagement.service.decision.domain.model.transaction.BusinessTransactionProductComponent;
import com.lombardinternational.casemanagement.service.decision.domain.model.transaction.MoneyInPayment;
import com.lombardinternational.casemanagement.service.decision.domain.model.transaction.PaymentDetails;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.TextWebFormField;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebFormGroup;

public class RulesUtils {

    public static boolean checkFieldInGroup(Group group, String fieldId) {

        return Optional.ofNullable(group.getFields()).stream().flatMap(Collection::stream).anyMatch(field -> fieldId.equals(field.getFieldId()));
    }

    public static boolean checkGroupInTab(Tab tab, String groupId) {

        return Optional.ofNullable(tab.getGroups()).stream().flatMap(Collection::stream).anyMatch(group -> groupId.equals(group.getGroupId()));
    }

    public static boolean checkTabInCheckList(ScreenDescription screenDescription, String tabId) {

        return Optional.ofNullable(screenDescription.getTabs()).stream().flatMap(Collection::stream).anyMatch(tab -> tabId.equals(tab.getTabId()));
    }

    public static Tab getTabInScreenDescription(ScreenDescription screenDescription, String tabId) {

        return Optional.ofNullable(screenDescription.getTabs()).stream().flatMap(Collection::stream).filter(tab -> tabId.equals(tab.getTabId()))
                .findFirst().orElse(null);
    }

    public static Group getGroupInTab(Tab tab, String groupId) {

        return Optional.ofNullable(tab.getGroups()).stream().flatMap(Collection::stream).filter(group -> groupId.equals(group.getGroupId()))
                .findFirst().orElse(null);
    }

    public static Field getFieldInGroup(Group group, String fieldId) {

        return Optional.ofNullable(group.getFields()).stream().flatMap(Collection::stream).filter(field -> fieldId.equals(field.getFieldId()))
                .findFirst().orElse(null);
    }

    public static TextWebFormField getFieldInGroup(WebFormGroup webFormGroup, String fieldId) {

        return Optional.ofNullable(webFormGroup.getTextFields()).stream().flatMap(Collection::stream)
                .filter(text -> fieldId.equals(text.getFieldId())).findFirst().orElse(null);
    }

    public static boolean checkPaymentOriginatorPTCORSO(BusinessTransaction transaction) {

        var displayIf = false;
        List<BusinessTransactionProductComponent> productComponents = transaction.getProductComponentPayments();
        if (productComponents != null && !productComponents.isEmpty()) {
            List<MoneyInPayment> payments =
                    productComponents.stream().map(BusinessTransactionProductComponent::getPayments).filter(Objects::nonNull)
                            .flatMap(Collection::stream).filter(MoneyInPayment.class::isInstance).map(MoneyInPayment.class::cast).toList();
            List<PaymentDetails> paymentDetails = new ArrayList<>();
            for (MoneyInPayment payment : payments) {
                if (payment.getPaymentDetails() != null && payment.getPaymentDetails().getPayerID() != null
                        && payment.getPaymentDetails().getPayerLegalAddressCountry() != null
                        && payment.getPaymentDetails().getOriginator() != null) {
                    paymentDetails.add(payment.getPaymentDetails());
                } else if (payment.getExpectedPaymentDetails() != null && payment.getExpectedPaymentDetails().getOriginator() != null
                        && payment.getExpectedPaymentDetails().getOriginator().getExternalId() != null) {
                    paymentDetails.add(payment.getExpectedPaymentDetails());
                }
            }
            if (paymentDetails.stream().anyMatch(payment -> "3pt_cor_so".equals(payment.getOriginator().getExternalId()))) {
                return true;
            }
        }

        return displayIf;
    }

    public static String getRiskFactorAnswerDescription(BusinessTransaction businessTransaction, String riskFactorReference) {

        return Optional.ofNullable(businessTransaction.getRiskFactorResults()).stream().flatMap(Collection::stream)
                .filter(riskFactor -> riskFactorReference.equals(riskFactor.getReference())
                        && StringUtils.isNotBlank(riskFactor.getAnswerDescription()))
                .map(RiskFactorResult::getAnswerDescription).findFirst().orElse(null);
    }

    public static String getRiskFactorLevel(BusinessTransaction businessTransaction, String riskFactorReference) {

        return Optional.ofNullable(businessTransaction.getRiskFactorResults()).stream().flatMap(Collection::stream)
                .filter(riskFactor -> riskFactorReference.equals(riskFactor.getReference()) && StringUtils.isNotBlank(riskFactor.getRiskLevel()))
                .map(RiskFactorResult::getRiskLevel).findFirst().orElse(null);
    }

    public static String getRiskFactorData(BusinessTransaction businessTransaction, String riskFactorReference) {

        return Optional.ofNullable(businessTransaction.getRiskFactorResults()).stream().flatMap(Collection::stream)
                .filter(riskFactor -> riskFactorReference.equals(riskFactor.getReference()) && StringUtils.isNotBlank(riskFactor.getData()))
                .map(RiskFactorResult::getData).findFirst().orElse("N/A");
    }

    public static String offShoreIndiciaDataResult(String content, String value) {

        content = content.replace(",", "");
        content = content.replace(" ", "");
        content = content.replace(value, "");

        if (!content.isEmpty()) {
            return "OTHER";

        }
        return value;
    }

    public static List<AbstractPerson> getThirdPartyFromRole(List<? extends PolicyRole> policyRole) {

        return policyRole.stream().map(PolicyRole::getThirdParties).filter(Objects::nonNull).flatMap(Collection::stream).toList();
    }

    public static List<String> getCountriesFromRole(List<? extends PolicyRole> policyRole) {

        return getThirdPartyFromRole(policyRole).stream().map(AbstractPerson::getAddress).filter(Objects::nonNull).map(Address::getCountry)
                .filter(Objects::nonNull).map(Country::getIsoCountryCode).collect(Collectors.toCollection(ArrayList::new));
    }

    public static List<SelectInputFieldOption> getNumbersSelectInputField(Integer number) {

        List<SelectInputFieldOption> options = new ArrayList<>();
        for (int i = 1; i <= number; i++) {
            options.add(new SelectInputFieldOption(String.valueOf(i), String.valueOf(i)));
        }
        return options;
    }

    public static boolean evaluateFieldValue(ScreenDescription screenDescription, String fieldName, String valueToCheck, String defaultValue) {

        return valueToCheck
                .equalsIgnoreCase(ChecklistUtils.getFieldById(screenDescription, fieldName).map(Field::getSelectedValue).orElse(defaultValue));
    }
}
