package com.lombardinternational.casemanagement.service.decision.domain.utils;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.lombardinternational.casemanagement.service.decision.domain.model.webform.BigDecimalWebFormField;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.BooleanWebFormField;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.CalendarWebFormField;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.TextWebFormField;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebFormField;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebFormGroup;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class WebformUtils {

    private static final String ADDITION_V2 = "ADDITION_V2";

    public static boolean isV2(WebForm webForm) {

        return ADDITION_V2.equals(webForm.getWebFormId());
    }

    public static WebFormField getFirstWebFormField(WebForm webForm, String id) {

        return getWebFormFieldsById(webForm, id).stream().findFirst().orElse(null);
    }

    public static WebFormField getFirstWebFormField(WebFormGroup webFormGroup, String id) {

        return getWebFormGroupFieldsById(webFormGroup, id).stream().findFirst().orElse(null);
    }

    public static String getWebFormFieldValueById(WebForm webForm, String id) {

        List<WebFormField> fields = getWebFormFieldsById(webForm, id);
        if (!fields.isEmpty()) {
            WebFormField field = fields.getFirst();
            return getValueForWebFormField(field);
        }
        return "N/A";
    }

    public static String getWebFormFieldValueById(WebFormGroup webFormGroup, String id) {

        List<WebFormField> fields = getWebFormGroupFieldsById(webFormGroup, id);
        if (!fields.isEmpty()) {
            WebFormField field = fields.getFirst();
            return getValueForWebFormField(field);

        }
        return "N/A";
    }

    public static List<WebFormField> getWebFormFieldsById(WebForm webForm, String id) {

        List<WebFormField> fields = new ArrayList<>();
        getWebFormObjectsById(id, webForm, null, fields, null, null);
        return fields;
    }

    public static List<WebFormField> getWebFormGroupFieldsById(WebFormGroup webFormGroup, String id) {

        List<WebFormField> fields = new ArrayList<>();
        if (webFormGroup != null) {
            getWebFormObjectsById(id, null, webFormGroup, fields, null, null);
        }
        return fields;
    }

    public static WebFormGroup getFirstWebFormGroupById(WebForm webForm, String id) {

        List<WebFormGroup> groups = new ArrayList<>();
        getWebFormObjectsById(id, webForm, null, null, groups, null);
        return !groups.isEmpty() ? groups.getFirst() : null;
    }

    public static WebFormGroup getFirstWebFormGroupById(WebForm webForm, WebFormGroup webFormGroup, String id) {

        List<WebFormGroup> groups = new ArrayList<>();
        getWebFormObjectsById(id, webForm, webFormGroup, null, groups, null);
        return !groups.isEmpty() ? groups.getFirst() : null;
    }

    public static void getWebFormObjectsById(String id, WebForm webForm, WebFormGroup group, List<WebFormField> fields, List<WebFormGroup> groups,
            HashMap<Object,WebFormGroup> fieldParent) {

        if (fields == null) {
            fields = new ArrayList<>();
        }
        if (groups == null) {
            groups = new ArrayList<>();
        }

        if (fieldParent == null) {
            fieldParent = new HashMap<>();
        }

        if (group != null) {

            if (id.equals(group.getGroupId())) {
                groups.add(group);
            }
            if (group.getBigDecimalFields() != null) {
                for (int ii = 0; ii < group.getBigDecimalFields().size(); ii++) {
                    BigDecimalWebFormField currentField = group.getBigDecimalFields().get(ii);
                    if (id.equals(currentField.getFieldId())) {
                        fields.add(currentField);
                        fieldParent.put(currentField, group);
                    }
                }
            }
            if (group.getBooleanFields() != null) {
                for (int ii = 0; ii < group.getBooleanFields().size(); ii++) {
                    BooleanWebFormField currentField = group.getBooleanFields().get(ii);
                    if (id.equals(currentField.getFieldId())) {
                        fields.add(currentField);
                        fieldParent.put(currentField, group);
                    }
                }
            }
            if (group.getCalendarFields() != null) {
                for (int ii = 0; ii < group.getCalendarFields().size(); ii++) {
                    CalendarWebFormField currentField = group.getCalendarFields().get(ii);
                    if (id.equals(currentField.getFieldId())) {
                        fields.add(currentField);
                        fieldParent.put(currentField, group);
                    }
                }
            }
            if (group.getTextFields() != null) {
                for (int ii = 0; ii < group.getTextFields().size(); ii++) {
                    TextWebFormField currentField = group.getTextFields().get(ii);
                    if (id.equals(currentField.getFieldId())) {
                        fields.add(currentField);
                        fieldParent.put(currentField, group);
                    }
                }
            }

            if (group.getGroups() != null) {
                for (int jj = 0; jj < group.getGroups().size(); jj++) {
                    WebFormGroup currentGroup = group.getGroups().get(jj);
                    fieldParent.put(currentGroup, group);
                    getWebFormObjectsById(id, webForm, currentGroup, fields, groups, fieldParent);
                }
            }
        }

        if (group == null) {
            for (int kk = 0; kk < webForm.getGroups().size(); kk++) {
                getWebFormObjectsById(id, webForm, webForm.getGroups().get(kk), fields, groups, fieldParent);
            }
        }
    }

    public static String getValueForWebFormField(WebFormField field) {

        switch (field) {
        case BooleanWebFormField booleanWebFormField -> {
            return (booleanWebFormField.getValue() == null) ? null : booleanWebFormField.getValue().toString();
        }
        case BigDecimalWebFormField bigDecimalWebFormField -> {
            return (bigDecimalWebFormField.getValue() == null) ? null : bigDecimalWebFormField.getValue().toPlainString();
        }
        case CalendarWebFormField calendarWebFormField -> {
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
            LocalDate date = calendarWebFormField.getValue();
            return date.format(formatter);
        }
        case TextWebFormField textWebFormField -> {
            return textWebFormField.getValue();
        }
        case null, default -> {
            return "N/A";
        }
        }
    }

    public static WebFormGroup getGroupInGroup(WebFormGroup group, String id) {

        if (group != null && group.getGroups() != null) {
            for (int ii = 0; ii < group.getGroups().size(); ii++) {
                WebFormGroup currentGroup = group.getGroups().get(ii);
                if (id.equals(currentGroup.getGroupId())) {
                    return currentGroup;
                }
            }
        }
        return null;
    }
}
