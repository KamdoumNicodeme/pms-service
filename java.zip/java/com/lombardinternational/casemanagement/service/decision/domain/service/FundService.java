package com.lombardinternational.casemanagement.service.decision.domain.service;

import java.util.ArrayList;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.lombardinternational.casemanagement.service.decision.domain.exception.ClassInternalException;
import com.lombardinternational.casemanagement.service.decision.domain.spi.web.FundWebService;

import lombok.AllArgsConstructor;

@Service
@AllArgsConstructor
public class FundService {

    private static final String PCF = "PCF";
    private final FundWebService fundWebService;

    public boolean containsILFFund(final String policyNumber) throws ClassInternalException {

        return Optional.of(fundWebService.getFunds(policyNumber)).orElse(new ArrayList<>()).stream()
                .anyMatch(fund -> PCF.equals(fund.getFundSubClass()));
    }
}
