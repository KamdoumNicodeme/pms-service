package com.lombardinternational.casemanagement.service.decision.domain.service.taskscreen.common.fields;

import org.springframework.stereotype.Service;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Group;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.SelectInputField;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.TextAreaField;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.TextInputField;
import com.lombardinternational.casemanagement.service.decision.domain.spi.repository.ReferenceDataRepositoryService;
import com.lombardinternational.casemanagement.service.decision.domain.utils.ChecklistUtils;

import lombok.AllArgsConstructor;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ReferenceConstants.YES_NO_DOMAIN;

@Service
@AllArgsConstructor
public class CommonAssetsFieldsService {

    private final ReferenceDataRepositoryService referenceDataRepositoryService;

    public void evaluateContainedInPortfolio(Group group, String fieldId) {

        var containedInPortfolio = (SelectInputField) ChecklistUtils.getFieldInGroup(group, fieldId);
        if (containedInPortfolio == null) {
            containedInPortfolio = SelectInputField.builder().fieldId(fieldId).build();
            group.getFields().add(containedInPortfolio);
        }
        containedInPortfolio.setIsActive(true);
        containedInPortfolio.incrementOrder();
        containedInPortfolio.setEnabled(true);
        containedInPortfolio.setMandatory(true);
        containedInPortfolio.setLabel("Contained in the portfolio");
        containedInPortfolio.setOptions(referenceDataRepositoryService.getReferenceDataOptionsByDomain(YES_NO_DOMAIN));
    }

    public void evaluateListOfAssets(Group group, String fieldId) {

        var listOfAssets = (TextAreaField) ChecklistUtils.getFieldInGroup(group, fieldId);
        if (listOfAssets == null) {
            listOfAssets = TextAreaField.builder().fieldId(fieldId).build();
            group.getFields().add(listOfAssets);
        }
        listOfAssets.setIsActive(true);
        listOfAssets.incrementOrder();
        listOfAssets.setEnabled(true);
        listOfAssets.setMandatory(true);
        listOfAssets.setLabel("List of Assets identified (Name / ISIN or similar identifier / CCY / Value)");
    }

    public void evaluateNtaOrPcsInformed(Group group, String fieldId) {

        var ntaOrPcsInformed = (TextInputField) ChecklistUtils.getFieldInGroup(group, fieldId);
        if (ntaOrPcsInformed == null) {
            ntaOrPcsInformed = TextInputField.builder().fieldId(fieldId).build();
            group.getFields().add(ntaOrPcsInformed);
        }
        ntaOrPcsInformed.setIsActive(true);
        ntaOrPcsInformed.incrementOrder();
        ntaOrPcsInformed.setEnabled(true);
        ntaOrPcsInformed.setMandatory(true);
        ntaOrPcsInformed.setLabel("Date NTA or PCS informed");
    }
}
