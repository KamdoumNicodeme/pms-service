package com.lombardinternational.casemanagement.service.decision.domain.model.policy;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class PolicyHolderSendingAddress {

    private String salutation;
    private String addresse;
    private String careOf;
    private PolicyHolderPostalAddress address;
}
