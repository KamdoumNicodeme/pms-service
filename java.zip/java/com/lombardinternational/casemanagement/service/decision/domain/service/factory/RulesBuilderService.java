package com.lombardinternational.casemanagement.service.decision.domain.service.factory;

import com.lombardinternational.casemanagement.service.decision.domain.model.policy.Policy;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.*;
import com.lombardinternational.casemanagement.service.decision.domain.model.transaction.BusinessTransaction;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;

import java.util.List;

public interface RulesBuilderService {

    ScreenDescription buildCheckList(final WebForm webForm, final ScreenDescription screenDescription, final Policy policy,
            final BusinessTransaction transaction);

    List<TaskDefinition> buildTaskList(final WebForm webForm, final ScreenDescription screenDescription, final Policy policy);

    ScreenDescription buildTaskScreen(final WebForm webForm, final ScreenDescription screenCheckList, final ScreenDescription screenToFill);

    List<DocumentDefinition> buildDocumentsDefinition(final WebForm webForm, final ScreenDescription screenDescription, final Policy policy,
            final String transactionNumber) throws Exception;

    List<ControlDefinition> buildControlDefinition(final WebForm webForm, final ScreenDescription screenDescription);

    SignatoryResult buildSignatories(final WebForm webForm, final Policy policy);
}
