package com.lombardinternational.casemanagement.service.decision.domain.exception;

public class ClassInternalValidationError extends RuntimeException {

    public ClassInternalValidationError(final String message) {

        super(message);
    }
}
