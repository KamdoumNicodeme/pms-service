package com.lombardinternational.casemanagement.service.decision.domain.model.policy;

import java.util.List;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder
@NoArgsConstructor
public class PolicyRole {

    private String roleId;
    private List<AbstractPerson> thirdParties;
}
