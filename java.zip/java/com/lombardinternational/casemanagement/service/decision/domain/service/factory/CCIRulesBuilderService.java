package com.lombardinternational.casemanagement.service.decision.domain.service.factory;

import com.lombardinternational.casemanagement.service.decision.domain.model.policy.Policy;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.*;
import com.lombardinternational.casemanagement.service.decision.domain.model.transaction.BusinessTransaction;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.checklist.cci.CCIChecklistBuilderService;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@AllArgsConstructor
public class CCIRulesBuilderService implements RulesBuilderService {

    private final CCIChecklistBuilderService checklistBuilderService;

    @Override
    public ScreenDescription buildCheckList(final WebForm webForm, final ScreenDescription screenDescription, final Policy policy,
            final BusinessTransaction transaction) {

        return checklistBuilderService.buildChecklist(webForm, screenDescription, policy, transaction);
    }

    @Override
    public List<TaskDefinition> buildTaskList(final WebForm webForm, final ScreenDescription screenDescription, final Policy policy) {

        return List.of();
    }

    @Override
    public ScreenDescription buildTaskScreen(final WebForm webForm, final ScreenDescription screenCheckList,
            final ScreenDescription screenToFill) {

        return null;
    }

    @Override
    public List<DocumentDefinition> buildDocumentsDefinition(final WebForm webForm, final ScreenDescription screenDescription, final Policy policy,
            String transactionNumber) {

        return List.of();
    }

    @Override
    public List<ControlDefinition> buildControlDefinition(final WebForm webForm, final ScreenDescription screenDescription) {

        return List.of();
    }

    @Override
    public SignatoryResult buildSignatories(final WebForm webForm, final Policy policy) {

        return null;
    }
}
