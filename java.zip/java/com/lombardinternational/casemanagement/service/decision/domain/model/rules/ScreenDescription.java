package com.lombardinternational.casemanagement.service.decision.domain.model.rules;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class ScreenDescription {

    private LocalDate loadTimeStamp;
    private String screenId;
    private ScreenDescription inputedScreenDescription;
    @Builder.Default
    private List<Tab> tabs = new ArrayList<>();

    public Tab getTabWithId(String id) {

        return tabs.stream().filter(t -> t.getTabId().equalsIgnoreCase(id)).findFirst().orElse(null);
    }

    public Group getGroupWithId(String id) {

        return tabs.stream().flatMap(t -> t.getGroups().stream()).filter(g -> g.getGroupId().equalsIgnoreCase(id)).findFirst().orElse(null);
    }

    public Field getFieldWithId(String id) {

        return tabs.stream().flatMap(t -> t.getGroups().stream()).filter(Objects::nonNull).flatMap(g -> g.getFields().stream())
                .filter(f -> f.getFieldId().equalsIgnoreCase(id)).findFirst().orElse(null);
    }

}
