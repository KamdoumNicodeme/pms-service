package com.lombardinternational.casemanagement.service.decision.domain.service.control.rop;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ControlDefinition;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.AbstractControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.ControlDefinitionBuilderService;

import lombok.AllArgsConstructor;

@Service
@AllArgsConstructor
public class RopControlDefinitionBuilderService implements ControlDefinitionBuilderService {

    @Override
    public List<ControlDefinition> buildControlDefinition(final WebForm webForm, final ScreenDescription screenDescription) {

        ControlDefinition.resetControlOrder();
        List<AbstractControlBuilderService> controlBuilderServices = Arrays.asList();
        final var controls = new ArrayList<ControlDefinition>();
        controlBuilderServices.forEach(service -> Optional.ofNullable(service.buildControl(webForm, screenDescription)).ifPresent(controls::add));
        return controls;
    }
}
