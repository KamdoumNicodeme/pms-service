package com.lombardinternational.casemanagement.service.decision.domain.service.taskscreen.common.groups;

import org.springframework.stereotype.Service;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Group;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Tab;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.taskscreen.TaskScreenGroupBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.taskscreen.common.fields.CommonDotGeneralInformationFieldsBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.utils.RulesUtils;

import lombok.AllArgsConstructor;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.TaskScreenConstants.GENERAL_INFORMATION_GROUP;

@Service
@AllArgsConstructor
public class CommonDotGeneralInformationGroupBuilderService implements TaskScreenGroupBuilderService {

    private final CommonDotGeneralInformationFieldsBuilderService service;

    @Override
    public void buildGroup(final WebForm webForm, final ScreenDescription screenCheckList, final ScreenDescription screenToFill,
            final Tab parentTab) {

        var generalInformationGroup = RulesUtils.getGroupInTab(parentTab, GENERAL_INFORMATION_GROUP);
        if (generalInformationGroup == null) {
            generalInformationGroup = Group.builder().groupId(GENERAL_INFORMATION_GROUP).build();
            parentTab.getGroups().add(generalInformationGroup);
        }
        generalInformationGroup.setIsActive(true);
        generalInformationGroup.incrementOrder();
        generalInformationGroup.setTitle("General information");
        service.buildField(webForm, screenCheckList, screenToFill, generalInformationGroup);
    }
}
