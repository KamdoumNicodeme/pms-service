package com.lombardinternational.casemanagement.service.decision.adapter.api.web.rest.mapper;

import com.lombardinternational.casemanagement.service.decision.adapter.api.web.rest.dto.SignatoryResultDTO;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.SignatoryResult;
import org.mapstruct.Mapper;

import java.util.List;

@Mapper
public interface SignatoryDefinitionMapper {

    SignatoryResult toEntity(SignatoryResultDTO signatoryResultDTO);

    SignatoryResultDTO toDto(SignatoryResult signatoryResult);

    List<SignatoryResult> toEntity(List<SignatoryResultDTO> signatoryResultDTOS);

    List<SignatoryResultDTO> toDto(List<SignatoryResult> signatoryResults);
}
