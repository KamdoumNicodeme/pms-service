package com.lombardinternational.casemanagement.service.decision.adapter.api.messaging.event.model;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalTime;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Schema(name = "Fx Rate", description = "Exchange rate from one currency to an other")
@JsonIgnoreProperties(ignoreUnknown = true)
public class FxRateEvent {

    @Schema(description = "Source Currency")
    private String fromCcy;
    @Schema(description = "Target Currency")
    private String toCcy;
    @Schema(description = "Bare Rate")
    private BigDecimal bareRate;
    @Schema(description = "Buy Rate")
    private BigDecimal buyRate;
    @Schema(description = "Sell Rate")
    private BigDecimal sellRate;
    @Schema(description = "Source of fxRate")
    private String source;
    @Schema(description = "Date of Exchange Rate")
    private LocalDate fxRateDate;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "HH:mm:ss")
    private LocalTime fxRateTime;
}
