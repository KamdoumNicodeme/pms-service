package com.lombardinternational.casemanagement.service.decision.adapter.spi.db.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.lombardinternational.casemanagement.service.decision.adapter.spi.db.model.CountryDataEntity;
import com.lombardinternational.casemanagement.service.decision.adapter.spi.db.model.ReferenceDataEntity;
import com.lombardinternational.casemanagement.service.decision.adapter.spi.db.repository.CountryDataRepository;
import com.lombardinternational.casemanagement.service.decision.domain.spi.repository.CountryDataRepositoryService;

import lombok.AllArgsConstructor;

@Service
@AllArgsConstructor
public class CountryDataRepositoryServiceImpl implements CountryDataRepositoryService {

    private final CountryDataRepository countryDataRepository;

    @Override
    public List<String> getCountryIsoCodeByType(String countryType) {

        List<CountryDataEntity> referenceDataEntities = this.countryDataRepository.findCountryDataEntitiesByCountryType(countryType);
        return referenceDataEntities.stream().map(CountryDataEntity::getReferenceData).map(ReferenceDataEntity::getCode)
                .collect(Collectors.toList());
    }

    @Override
    public List<String> getCountryByTypeAndValue(String countryType, String countryValue) {

        List<CountryDataEntity> referenceDataEntities =
                this.countryDataRepository.findCountryDataEntitiesByCountryTypeAndCountryValue(countryType, countryValue);
        return referenceDataEntities.stream().map(CountryDataEntity::getReferenceData).map(ReferenceDataEntity::getCode)
                .collect(Collectors.toList());
    }
}
