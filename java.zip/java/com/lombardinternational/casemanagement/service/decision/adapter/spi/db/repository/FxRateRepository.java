package com.lombardinternational.casemanagement.service.decision.adapter.spi.db.repository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.query.Procedure;

import com.lombardinternational.casemanagement.service.decision.adapter.spi.db.model.FxRateEntity;

public interface FxRateRepository extends JpaRepository<FxRateEntity,Long> {

    List<FxRateEntity> findByFxRateDate(LocalDate fxDate);

    Optional<FxRateEntity> findByFromCcyAndToCcyAndFxRateDate(String fromCcy, String toCcy, LocalDate fxRateDate);

    @Query("SELECT MAX(FR.fxRateDate) FROM FxRateEntity FR")
    Optional<LocalDate> findMaxFxRateDate();

    @Procedure(procedureName = "DeleteOldFXRatesRecords")
    void deleteOldFXRatesRecords();

    Optional<FxRateEntity> findTopByFromCcyAndToCcyAndFxRateDateOrderByFxRateTimeDesc(String fromCcy, String toCcy, LocalDate fxRateDate);
}
