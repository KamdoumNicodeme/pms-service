package com.lombardinternational.casemanagement.service.decision.adapter.spi.web.service;

import org.springframework.stereotype.Service;

import com.lombardinternational.casemanagement.service.decision.adapter.spi.web.mapper.BusinessTransactionMapper;
import com.lombardinternational.casemanagement.service.decision.domain.exception.ClassInternalException;
import com.lombardinternational.casemanagement.service.decision.domain.exception.ClassInternalNotFoundException;
import com.lombardinternational.casemanagement.service.decision.domain.model.transaction.BusinessTransaction;
import com.lombardinternational.casemanagement.service.decision.domain.spi.web.BusinessTransactionWebService;
import com.lombardinternational.clients.classapp.client.BusinessTransactionClient;
import com.lombardinternational.clients.classapp.exception.ClassClientException;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@AllArgsConstructor
public class BusinessTransactionWebServiceImpl implements BusinessTransactionWebService {

    private final BusinessTransactionClient businessTransactionClient;
    private final BusinessTransactionMapper businessTransactionMapper;

    @Override
    public BusinessTransaction getBusinessTransactionDetails(final String businessTransactionNumber) throws ClassInternalNotFoundException {

        try {
            return businessTransactionMapper.toEntity(businessTransactionClient.getBusinessTransaction(businessTransactionNumber));
        } catch (ClassClientException e) {
            if (e.status() == 400) {
                throw new ClassInternalNotFoundException(e.getMessage());
            }
            throw new ClassInternalException(e.getMessage());
        }
    }
}
