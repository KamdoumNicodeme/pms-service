package com.lombardinternational.casemanagement.service.decision.adapter.api.web.rest.dto;

import com.lombardinternational.casemanagement.service.decision.adapter.api.web.rest.dto.screen.ScreenDescriptionDTO;
import com.lombardinternational.casemanagement.service.decision.adapter.api.web.rest.dto.webform.WebFormDTO;

import lombok.Data;

@Data
public class ChecklistRequestDTO {

    private ScreenDescriptionDTO screenDescription;
    private WebFormDTO webForm;
    private String policyNumber;
    private String transactionNumber;
}
