package com.lombardinternational.casemanagement.service.decision.adapter.spi.web.mapper;

import org.mapstruct.Mapper;

import com.lombardinternational.casemanagement.service.decision.domain.model.policy.EboPolicyNav;

@Mapper
public interface EboPolicyNavMapper extends DtoMapper<EboPolicyNav,com.lombardinternational.clients.classapp.model.EboPolicyNav> {
}
