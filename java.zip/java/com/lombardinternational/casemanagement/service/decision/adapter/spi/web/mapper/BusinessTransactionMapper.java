package com.lombardinternational.casemanagement.service.decision.adapter.spi.web.mapper;

import java.util.Collection;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import com.lombardinternational.casemanagement.service.decision.domain.model.transaction.BusinessTransaction;
import com.lombardinternational.clients.classapp.model.BusinessTransactionDetails;
import com.lombardinternational.clients.classapp.model.BusinessTransactionLight;

@Mapper(uses = { AmountMapper.class, PaymentMapper.class })
public interface BusinessTransactionMapper {

    @Mapping(source = "transactionId", target = "identifier")
    @Mapping(source = "transactionType", target = "type")
    @Mapping(source = "endorsementCategory", target = "category")
    @Mapping(source = "endorsementSubCategory", target = "subCategory")
    BusinessTransaction lightToEntity(BusinessTransactionLight businessTransactionLight);

    Collection<BusinessTransaction> lightsToEntities(Collection<BusinessTransactionLight> businessTransactionLightList);

    @Mapping(source = "transactionNumber", target = "identifier")
    @Mapping(source = "transactionType", target = "type")
    @Mapping(source = "businessTransaction", target = "transactionAmounts.grossAmount")
    @Mapping(source = "endorsementCategory", target = "category")
    @Mapping(source = "endorsementSubCategory", target = "subCategory")
    @Mapping(source = "policyCurrency.isoCode", target = "policyIsoCurrencyCode")
    BusinessTransaction toEntity(BusinessTransactionDetails businessTransaction);
}
