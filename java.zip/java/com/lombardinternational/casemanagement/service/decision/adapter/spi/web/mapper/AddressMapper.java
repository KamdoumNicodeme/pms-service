package com.lombardinternational.casemanagement.service.decision.adapter.spi.web.mapper;

import org.mapstruct.Mapper;

import com.lombardinternational.casemanagement.service.decision.domain.model.policy.Address;

@Mapper(uses = { CountryMapper.class })
public interface AddressMapper {

    Address map(com.lombardinternational.clients.classapp.model.Address address);
}
