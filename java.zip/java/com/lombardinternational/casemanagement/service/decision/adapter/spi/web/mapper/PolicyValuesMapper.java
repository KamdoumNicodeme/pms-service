package com.lombardinternational.casemanagement.service.decision.adapter.spi.web.mapper;

import org.mapstruct.Mapper;

import com.lombardinternational.casemanagement.service.decision.domain.model.policy.PolicyValues;

@Mapper
public interface PolicyValuesMapper extends DtoMapper<PolicyValues,com.lombardinternational.clients.classapp.model.PolicyValues> {
}
