package com.lombardinternational.casemanagement.service.decision.adapter.api.web.rest.mapper;

import java.util.List;

import org.mapstruct.Mapper;

import com.lombardinternational.casemanagement.service.decision.adapter.api.web.rest.dto.DocumentDefinitionDTO;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.DocumentDefinition;

@Mapper
public interface DocumentDefinitionMapper {

    DocumentDefinitionDTO toDto(DocumentDefinition documentDefinition);

    List<DocumentDefinitionDTO> toDto(List<DocumentDefinition> documentDefinition);

    DocumentDefinition toEntity(DocumentDefinitionDTO documentDefinitionDTO);
}
