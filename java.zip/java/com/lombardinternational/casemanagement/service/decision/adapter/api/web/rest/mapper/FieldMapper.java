package com.lombardinternational.casemanagement.service.decision.adapter.api.web.rest.mapper;

import java.util.List;

import org.mapstruct.Mapper;
import org.mapstruct.Named;

import com.lombardinternational.casemanagement.service.decision.adapter.api.web.rest.dto.screen.CheckBoxFieldDTO;
import com.lombardinternational.casemanagement.service.decision.adapter.api.web.rest.dto.screen.FieldDTO;
import com.lombardinternational.casemanagement.service.decision.adapter.api.web.rest.dto.screen.NumberInputFieldDTO;
import com.lombardinternational.casemanagement.service.decision.adapter.api.web.rest.dto.screen.SelectInputFieldDTO;
import com.lombardinternational.casemanagement.service.decision.adapter.api.web.rest.dto.screen.TextAreaFieldDTO;
import com.lombardinternational.casemanagement.service.decision.adapter.api.web.rest.dto.screen.TextInputFieldDTO;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.CheckBoxField;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Field;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.NumberInputField;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.SelectInputField;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.TextAreaField;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.TextInputField;

@Mapper
public interface FieldMapper {

    default Field map(FieldDTO field) {

        return switch (field) {
        case SelectInputFieldDTO selectInputFieldDTO -> toEntity(selectInputFieldDTO);
        case NumberInputFieldDTO numberInputFieldDTO -> toEntity(numberInputFieldDTO);
        case TextAreaFieldDTO textAreaFieldDTO -> toEntity(textAreaFieldDTO);
        case TextInputFieldDTO textInputFieldDTO -> toEntity(textInputFieldDTO);
        case CheckBoxFieldDTO checkBoxFieldDTO -> toEntity(checkBoxFieldDTO);
        case null, default -> throw new RuntimeException("Cannot parse a Field dto to a Field");
        };
    }

    default FieldDTO map(Field field) {

        return switch (field) {
        case SelectInputField selectInputField -> toDto(selectInputField);
        case NumberInputField numberInputField -> toDto(numberInputField);
        case TextAreaField textAreaField -> toDto(textAreaField);
        case TextInputField textInputField -> toDto(textInputField);
        case CheckBoxField checkBoxField -> toDto(checkBoxField);
        case null, default -> throw new RuntimeException("Cannot parse a Field to a Field dto");
        };
    }

    List<Field> toEntity(List<FieldDTO> fieldDTOS);

    List<FieldDTO> toDto(List<Field> fields);

    @Named("selectInputField")
    SelectInputField toEntity(SelectInputFieldDTO fieldDTO);

    @Named("selectInputFieldDTO")
    SelectInputFieldDTO toDto(SelectInputField field);

    @Named("numberInputField")
    NumberInputField toEntity(NumberInputFieldDTO fieldDTO);

    @Named("numberInputFieldDTO")
    NumberInputFieldDTO toDto(NumberInputField field);

    @Named("textAreaField")
    TextAreaField toEntity(TextAreaFieldDTO fieldDTO);

    @Named("textAreaFieldDTO")
    TextAreaFieldDTO toDto(TextAreaField field);

    @Named("textInputField")
    TextInputField toEntity(TextInputFieldDTO fieldDTO);

    @Named("textInputFieldDTO")
    TextInputFieldDTO toDto(TextInputField field);

    @Named("CheckBoxField")
    CheckBoxField toEntity(CheckBoxFieldDTO fieldDTO);

    @Named("CheckBoxFieldDTO")
    CheckBoxFieldDTO toDto(CheckBoxField field);
}
