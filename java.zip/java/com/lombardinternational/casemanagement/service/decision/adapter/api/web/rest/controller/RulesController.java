package com.lombardinternational.casemanagement.service.decision.adapter.api.web.rest.controller;

import com.lombardinternational.casemanagement.service.decision.adapter.api.web.rest.dto.*;
import com.lombardinternational.casemanagement.service.decision.adapter.api.web.rest.dto.screen.ScreenDescriptionDTO;
import com.lombardinternational.casemanagement.service.decision.adapter.api.web.rest.mapper.*;
import com.lombardinternational.casemanagement.service.decision.domain.api.RulesEngineService;
import com.lombardinternational.utils.servicelogger.milestones.domain.LogMilestone;
import io.swagger.v3.oas.annotations.Operation;
import lombok.AllArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RequestMapping("/api/rules")
@RestController
@AllArgsConstructor
public class RulesController {

    private final RulesEngineService service;
    private final WebFormMapper webFormMapper;
    private final ScreenDescriptionMapper screenDescriptionMapper;
    private final TaskDefinitionMapper taskDefinitionMapper;
    private final DocumentDefinitionMapper documentDefinitionMapper;
    private final ControlDefinitionMapper controlDefinitionMapper;
    private final SignatoryDefinitionMapper signatoryDefinitionMapper;

    @PostMapping("/checklist")
    @Operation(summary = "Generate the checklist", description = "Generate the checklist")
    @LogMilestone
    public ResponseEntity<ScreenDescriptionDTO> generateCheckList(@RequestBody ChecklistRequestDTO request) throws Exception {

        var screenDescription = service.buildCheckList(webFormMapper.toEntity(request.getWebForm()),
                screenDescriptionMapper.toEntity(request.getScreenDescription()), request.getPolicyNumber(), request.getTransactionNumber());
        return ResponseEntity.ok(screenDescriptionMapper.toDto(screenDescription));
    }

    @PostMapping("/tasklist")
    @Operation(summary = "Generate the tasklist", description = "Generate the tasklist")
    @LogMilestone
    public ResponseEntity<List<TaskDefinitionDTO>> generateTaskList(@RequestBody TaskListRequestDTO request) throws Exception {

        var taskDefinitions = service.buildTaskList(webFormMapper.toEntity(request.getWebForm()),
                screenDescriptionMapper.toEntity(request.getScreenDescription()), request.getPolicyNumber());
        return ResponseEntity.ok(taskDefinitionMapper.toDto(taskDefinitions));
    }

    @PostMapping("/taskscreen")
    @Operation(summary = "Generate the taskscreen", description = "Generate the taskscreen")
    @LogMilestone
    public ResponseEntity<ScreenDescriptionDTO> generateTaskScreen(@RequestBody TaskScreenRequestDTO request) {

        var screenDescription = service.buildTaskScreen(webFormMapper.toEntity(request.getWebForm()),
                screenDescriptionMapper.toEntity(request.getScreenCheckList()), screenDescriptionMapper.toEntity(request.getScreenToFill()));
        return ResponseEntity.ok(screenDescriptionMapper.toDto(screenDescription));
    }

    @PostMapping("/documents")
    @Operation(summary = "Generate the documents", description = "Generate the documents")
    @LogMilestone
    public ResponseEntity<List<DocumentDefinitionDTO>> generateDocumentsDefinition(@RequestBody DocumentDefinitionRequestDTO request)
            throws Exception {

        var documentDefinition = service.buildDocumentsDefinition(webFormMapper.toEntity(request.getWebForm()),
                screenDescriptionMapper.toEntity(request.getScreenDescription()), request.getPolicyNumber(), request.getTransactionNumber());
        return ResponseEntity.ok(documentDefinitionMapper.toDto(documentDefinition));
    }

    @PostMapping("/controls")
    @Operation(summary = "Generate the controls", description = "Generate the controls")
    @LogMilestone
    public ResponseEntity<List<ControlDefinitionDTO>> generateControlDefinition(@RequestBody ControlDefinitionRequestDTO request) {

        var controlDefinitions = service.buildControlDefinition(webFormMapper.toEntity(request.getWebForm()),
                screenDescriptionMapper.toEntity(request.getScreenDescription()));
        return ResponseEntity.ok(controlDefinitionMapper.toDto(controlDefinitions));
    }

    @PostMapping("/signatories")
    @Operation(summary = "Generate the signatories", description = "Generate the signatories")
    @LogMilestone
    public ResponseEntity<SignatoryResultDTO> generateSignatories(@RequestBody SignatoriesRequestDTO request) throws Exception {

        var signatoryDefinitions = service.buildSignatories(webFormMapper.toEntity(request.getWebForm()), request.getPolicyNumber());
        return ResponseEntity.ok(signatoryDefinitionMapper.toDto(signatoryDefinitions));
    }
}
