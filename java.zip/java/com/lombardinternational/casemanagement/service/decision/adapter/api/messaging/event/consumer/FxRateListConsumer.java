package com.lombardinternational.casemanagement.service.decision.adapter.api.messaging.event.consumer;

import java.time.LocalTime;
import java.util.List;
import java.util.Optional;

import org.springframework.kafka.support.KafkaHeaders;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

import com.lombardinternational.casemanagement.service.decision.adapter.api.messaging.event.mapper.EventMapper;
import com.lombardinternational.casemanagement.service.decision.adapter.api.messaging.event.model.FxRateEvent;
import com.lombardinternational.casemanagement.service.decision.domain.model.FxRate;
import com.lombardinternational.casemanagement.service.decision.domain.spi.repository.FxRateRepositoryService;
import com.lombardinternational.utils.kafkaheaders.domain.service.FlowKafkaHeaders;
import com.lombardinternational.utils.servicelogger.milestones.domain.LogMilestone;

import io.github.springwolf.core.asyncapi.annotations.AsyncListener;
import io.github.springwolf.core.asyncapi.annotations.AsyncOperation;
import lombok.extern.slf4j.Slf4j;

@LogMilestone(category = "Consumer")
@Component
@Slf4j
public class FxRateListConsumer extends AbstractEventConsumer<Long,List<FxRate>,List<FxRateEvent>> {

    private final FxRateRepositoryService fxRateRepositoryService;

    public FxRateListConsumer(final EventMapper<Long,List<FxRate>,List<FxRateEvent>> mapper,
            final FxRateRepositoryService fxRateRepositoryService) {

        super(mapper);
        this.fxRateRepositoryService = fxRateRepositoryService;
    }

    @AsyncListener(operation = @AsyncOperation(channelName = "public.foreignexchange.rate", description = "Consume list of fx rate events and persist the freshest rates in case-decision-service", payloadType = FxRateEvent.class, headers = @AsyncOperation.Headers(values = {
            @AsyncOperation.Headers.Header(name = FlowKafkaHeaders.CORRELATION_ID, description = "Message correlation id", value = "4234354354354"),
            @AsyncOperation.Headers.Header(name = FlowKafkaHeaders.CREATE_TIMESTAMP, description = "Message Creation timestamp", value = "2025-06-03T10:00:00.000"),
            @AsyncOperation.Headers.Header(name = KafkaHeaders.RECEIVED_KEY, description = "Message Received Key", value = "FX_LIST_EVENT_KEY"),
            @AsyncOperation.Headers.Header(name = "source_category", description = "Source category of FX rate", value = "VENDOR") })))
    @Override
    public void accept(Message<List<FxRateEvent>> eventMessage) {

        String sourceCategory = Optional.ofNullable(eventMessage.getHeaders().get("source_category"))
                .map(header -> (header instanceof byte[]) ? new String((byte[]) header) : header.toString()).orElse("UNKNOWN");

        if (!"VENDOR".equalsIgnoreCase(sourceCategory)) {
            log.info("[CONSUMER] Ignored FX rate list event with source_category = {}", sourceCategory);
            return;
        }

        super.accept(eventMessage);
    }

    @Override
    protected void handle(final List<FxRateEvent> events, final String correlationId, final LocalTime createdTimestamp) {

        List<FxRate> fxRates = mapper.toEntity(events, correlationId, createdTimestamp);

        fxRates.forEach(fxRateRepositoryService::saveOrUpdateIfNewer);

        log.info("[CONSUMER] Processed FX rate list with {} entries (correlationId = {})", fxRates.size(), correlationId);
    }

    @Override
    protected String getEventType() {

        return "FxRateList";
    }

}
