package com.lombardinternational.casemanagement.service.decision.adapter.api.web.rest.dto;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class DocumentDefinitionDTO {

    private String documentType;
    private String documentRelatedTo;
    private String i18NDocumentRelatedTo;
    private String i18NDocumentRelatedToParam;
    private String relatedToPolicyNumber;
    private String relatedToThirdpartyId;
    private boolean documentRequired;
    private boolean documentVisibleOnConnect;
    private int documentOrder;
    private String description;
    private String i18NDescription;
    private String cmsDocumentType;
    private boolean neverDisplayExternally;
}
