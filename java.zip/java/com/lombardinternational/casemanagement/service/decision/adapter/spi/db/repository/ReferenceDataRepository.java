package com.lombardinternational.casemanagement.service.decision.adapter.spi.db.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.lombardinternational.casemanagement.service.decision.adapter.spi.db.model.ReferenceDataEntity;

public interface ReferenceDataRepository extends JpaRepository<ReferenceDataEntity,String> {

    List<ReferenceDataEntity> findByDomain(String domain);
}
