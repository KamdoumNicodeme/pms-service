package com.lombardinternational.casemanagement.service.decision.adapter.api.web.rest.mapper;

import java.util.List;

import org.mapstruct.Mapper;

import com.lombardinternational.casemanagement.service.decision.adapter.api.web.rest.dto.ControlDefinitionDTO;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ControlDefinition;

@Mapper
public interface ControlDefinitionMapper {

    ControlDefinitionDTO toDto(ControlDefinition controlDefinition);

    ControlDefinition toEntity(ControlDefinitionDTO controlDefinitionDTO);

    List<ControlDefinitionDTO> toDto(List<ControlDefinition> controlDefinitions);

    List<ControlDefinition> toEntity(List<ControlDefinitionDTO> controlDefinitionDTOS);
}
