package com.lombardinternational.casemanagement.service.decision.adapter.api.messaging.event.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

@AllArgsConstructor
@Data
@Builder
public class CaseDecisionServiceError {

    private String code;
    private String message;
    private String exception;
}
