package com.lombardinternational.casemanagement.service.decision.adapter.api.messaging.event.consumer;

import java.io.Serializable;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.function.Consumer;

import org.springframework.kafka.support.KafkaHeaders;
import org.springframework.messaging.Message;

import com.lombardinternational.casemanagement.service.decision.adapter.api.messaging.event.mapper.EventMapper;
import com.lombardinternational.casemanagement.service.decision.adapter.api.messaging.event.utils.KafkaUtils;
import com.lombardinternational.utils.kafkaheaders.domain.service.FlowKafkaHeaders;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RequiredArgsConstructor
public abstract class AbstractEventConsumer< I extends Serializable, E, V > implements Consumer<Message<V>> {

    protected final EventMapper<I,E,V> mapper;

    @Override
    public void accept(Message<V> eventMessage) {

        final var correlationId = this.getCorrelationId(eventMessage);
        final var messageKey = this.getMessageKey(eventMessage);
        LocalTime fxRateTime = getCreateTimestamp(eventMessage).atZone(ZoneOffset.UTC).toLocalTime();
        log.info("[CONSUMER] Receive '{}' event with correlation ID '{}' and message key '{}' from Kafka", getEventType(), correlationId,
                messageKey);
        this.handle(eventMessage.getPayload(), correlationId, fxRateTime);
    }

    protected abstract void handle(V event, String correlationId, LocalTime createdTimestamp);

    protected abstract String getEventType();

    protected String getMessageKey(Message<V> eventMessage) {

        return KafkaUtils.extract(eventMessage, KafkaHeaders.RECEIVED_KEY);
    }

    protected String getCorrelationId(Message<V> eventMessage) {

        return KafkaUtils.extract(eventMessage, FlowKafkaHeaders.CORRELATION_ID);
    }

    protected Instant getCreateTimestamp(Message<V> eventMessage) {

        return parseCreatedTimestamp(KafkaUtils.extract(eventMessage, FlowKafkaHeaders.CREATE_TIMESTAMP));
    }

    protected Instant parseCreatedTimestamp(String createdTimestamp) {

        if (createdTimestamp == null) {
            return Instant.now();
        }

        try {
            return Instant.parse(createdTimestamp);
        } catch (DateTimeParseException e) {
            log.warn("Failed to parse timestamp as Instant, trying fallback. Input: {}", createdTimestamp);
            return LocalDateTime.parse(createdTimestamp, DateTimeFormatter.ISO_DATE_TIME).toInstant(ZoneOffset.UTC);
        }
    }

}
