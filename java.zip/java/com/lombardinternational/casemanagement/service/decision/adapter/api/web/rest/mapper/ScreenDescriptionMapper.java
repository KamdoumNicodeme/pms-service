package com.lombardinternational.casemanagement.service.decision.adapter.api.web.rest.mapper;

import org.mapstruct.Mapper;

import com.lombardinternational.casemanagement.service.decision.adapter.api.web.rest.dto.screen.ScreenDescriptionDTO;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;

@Mapper(uses = FieldMapper.class)
public interface ScreenDescriptionMapper {

    ScreenDescriptionDTO toDto(ScreenDescription screenDescription);

    ScreenDescription toEntity(ScreenDescriptionDTO screenDescriptionDTO);
}
