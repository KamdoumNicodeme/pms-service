package com.lombardinternational.casemanagement.service.decision.adapter.api.web.rest.dto;

import java.util.List;

import lombok.Data;

@Data
public class RequiredSignatoryDTO {

    private String thirdPartyId;
    private String type;
    private String firstName;
    private String lastName;
    private String email;
    private String phoneNumber;
    private String label;
    private String signerId;
    private List<String> allowedActions;
    private String onBehalfOf;
}
