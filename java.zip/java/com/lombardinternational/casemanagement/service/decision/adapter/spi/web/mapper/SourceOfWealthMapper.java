package com.lombardinternational.casemanagement.service.decision.adapter.spi.web.mapper;

import org.mapstruct.BeanMapping;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

import com.lombardinternational.casemanagement.service.decision.domain.model.policy.SourcesOfWealth;

@Mapper
public interface SourceOfWealthMapper {

    @BeanMapping(ignoreByDefault = true)
    @Mappings({ @Mapping(target = "description", source = "wealthCategory.externalId"),
            @Mapping(target = "companyName", source = "originatorCompanyName"),
            @Mapping(target = "transactionDateTime", source = "relevantTransactionDate"),
            @Mapping(target = "contributorName", source = "originatorID"),
            @Mapping(target = "contributorLink", source = "relationShipWithOriginator.externalId"),
            @Mapping(target = "contributorCountry", source = "originatorCountry.externalId"),
            @Mapping(target = "wealthOriginatingcountry1", source = "firstWealthOriginatingCountry.externalId"),
            @Mapping(target = "wealthOriginatingcountry2", source = "secondWealthOriginatingCountry.externalId"),
            @Mapping(target = "contributorProfession", source = "originatorProfession.externalId"),
            @Mapping(target = "contributorProfIndusSector", source = "originatorIndustrySector.externalId"),
            @Mapping(target = "exception", source = "exceptionForOriginator"), @Mapping(target = "originOfPremium", source = "originOfPremium") })
    SourcesOfWealth map(com.lombardinternational.clients.classapp.model.SourceOfWealth sourceOfWealth);
}
