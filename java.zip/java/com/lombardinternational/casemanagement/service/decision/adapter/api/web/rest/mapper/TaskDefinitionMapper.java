package com.lombardinternational.casemanagement.service.decision.adapter.api.web.rest.mapper;

import java.util.List;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import com.lombardinternational.casemanagement.service.decision.adapter.api.web.rest.dto.TaskDefinitionDTO;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.TaskDefinition;

@Mapper
public interface TaskDefinitionMapper {

    TaskDefinitionDTO toDto(TaskDefinition taskDefinition);

    @Mapping(target = "rulePriority", ignore = true)
    TaskDefinition toEntity(TaskDefinitionDTO taskDefinitionDTO);

    List<TaskDefinitionDTO> toDto(List<TaskDefinition> taskDefinition);

    List<TaskDefinition> toEntity(List<TaskDefinitionDTO> taskDefinitionDTO);
}
