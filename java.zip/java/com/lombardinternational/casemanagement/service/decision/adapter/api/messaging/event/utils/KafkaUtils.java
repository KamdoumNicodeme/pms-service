package com.lombardinternational.casemanagement.service.decision.adapter.api.messaging.event.utils;

import org.springframework.messaging.Message;

import lombok.experimental.UtilityClass;

@UtilityClass
public class KafkaUtils {

    public String extract(Message<?> message, String key) {

        Object value = message.getHeaders().get(key);
        return switch (value) {
        case null -> null;
        case String s -> s;
        case byte[] bytes -> new String(bytes);
        default -> String.valueOf(value);
        };
    }
}
