package com.lombardinternational.casemanagement.service.decision.adapter.spi.web.service;

import java.util.Collections;
import java.util.List;

import org.springframework.stereotype.Service;

import com.lombardinternational.casemanagement.service.decision.adapter.spi.web.mapper.EboPolicyNavMapper;
import com.lombardinternational.casemanagement.service.decision.adapter.spi.web.mapper.RiskFactorResultMapper;
import com.lombardinternational.casemanagement.service.decision.domain.exception.ClassInternalException;
import com.lombardinternational.casemanagement.service.decision.domain.exception.ClassInternalValidationError;
import com.lombardinternational.casemanagement.service.decision.domain.model.policy.EboPolicyNav;
import com.lombardinternational.casemanagement.service.decision.domain.model.policy.RiskFactorResult;
import com.lombardinternational.casemanagement.service.decision.domain.spi.web.ComplianceWebService;
import com.lombardinternational.clients.classapp.client.ComplianceServiceClient;
import com.lombardinternational.clients.classapp.exception.ClassClientException;

import lombok.AllArgsConstructor;

@Service
@AllArgsConstructor
public class ComplianceWebServiceImpl implements ComplianceWebService {

    private final ComplianceServiceClient complianceServiceClient;
    private final RiskFactorResultMapper riskFactorResultMapper;
    private final EboPolicyNavMapper eboPolicyNavMapper;

    @Override
    public List<RiskFactorResult> evaluateRiskFactors(final String transactionNumber, final List<String> factorIds) throws Exception {

        if (transactionNumber == null || transactionNumber.isEmpty()) {
            return Collections.emptyList();
        }
        try {
            return riskFactorResultMapper.toEntities(complianceServiceClient.evaluateRiskFactors(transactionNumber, factorIds));
        } catch (ClassClientException e) {
            throw handleComplianceServiceClientException(e);
        }
    }

    @Override
    public EboPolicyNav getSameEboPolicyNav(final String policyNumber, final String transactionNumber, final String currency) throws Exception {

        try {
            return eboPolicyNavMapper.toEntity(complianceServiceClient.getSameEboPolicyNav(policyNumber, transactionNumber, currency));
        } catch (ClassClientException e) {
            throw handleComplianceServiceClientException(e);
        }
    }

    private Exception handleComplianceServiceClientException(final ClassClientException e) {

        if (e.status() == 500) {
            return new ClassInternalException(e.getMessage());
        }
        return new ClassInternalValidationError(e.getMessage());
    }
}
