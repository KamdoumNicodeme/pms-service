package com.lombardinternational.casemanagement.service.decision.adapter.api.web.rest.configuration;

import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.apache.hc.core5.http.HttpHeaders;
import org.springdoc.core.customizers.OpenApiCustomizer;
import org.springdoc.core.models.GroupedOpenApi;
import org.springdoc.core.utils.SpringDocUtils;
import org.springframework.boot.info.BuildProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.fasterxml.jackson.databind.JsonNode;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.License;
import io.swagger.v3.oas.models.responses.ApiResponse;
import io.swagger.v3.oas.models.security.SecurityRequirement;
import io.swagger.v3.oas.models.security.SecurityScheme;

import static org.springframework.http.HttpStatus.*;

/**
 * The Swagger configuration class
 */
@Configuration
public class SwaggerConfiguration {

    private static final String APPLICATION = "case-decision-service";
    private static final String TITLE = "Case Decision Service";
    private static final String DESCRIPTION = "Case Decision Service API";
    private static final String LICENSE = "Lombard International Assurance";
    private static final String CONTACT_NAME = "IT Application Development";
    private static final String CONTACT_URL = "https://www.lombardinternational.com";

    private static final String BASE_PACKAGE = "com.lombardinternational.casemanagement.service.decision.adapter.api.web.rest.controller";
    private static final String[] PATH_SELECTOR = { "/api/**" };

    private static final String BEARER = "bearer";
    private static final String JWT = "jwt";

    private final BuildProperties buildProperties;

    /**
     * The constructor
     *
     * @param buildProperties:
     *            the {@link BuildProperties}
     */
    public SwaggerConfiguration(BuildProperties buildProperties) {

        this.buildProperties = buildProperties;
    }

    @Bean
    public GroupedOpenApi salesforceApi() {

        return GroupedOpenApi.builder().group(APPLICATION).displayName(APPLICATION).addOpenApiCustomizer(openApiCustomizer())
                .packagesToScan(BASE_PACKAGE).pathsToMatch(PATH_SELECTOR).build();
    }

    /**
     * @return the case {@link OpenApiCustomizer}
     */
    private OpenApiCustomizer openApiCustomizer() {

        return openApi -> {
            SpringDocUtils.getConfig().replaceWithClass(Calendar.class, Date.class).replaceWithClass(JsonNode.class, Object.class);

            apiInfo(openApi).getPaths().values()
                    .forEach(pathItem -> pathItem.readOperations().forEach(operation -> operation.getResponses().putAll(globalResponses())));
        };
    }

    /**
     * Set all the information on the {@link OpenAPI} object
     * 
     * @param openApi:
     *            the {@link OpenAPI}
     * @return a {@link OpenAPI}
     */
    private OpenAPI apiInfo(OpenAPI openApi) {

        return openApi
                .info(openApi.getInfo().title(TITLE).description(DESCRIPTION).version(buildProperties.getVersion())
                        .license(new License().name(LICENSE)).contact(new Contact().name(CONTACT_NAME).url(CONTACT_URL)))
                .components(openApi.getComponents()
                        // JWT security
                        .addSecuritySchemes(JWT, new SecurityScheme().type(SecurityScheme.Type.HTTP).scheme(BEARER).in(SecurityScheme.In.HEADER)
                                .name(HttpHeaders.AUTHORIZATION))
                // JWT security
                ).addSecurityItem(new SecurityRequirement().addList(JWT));
    }

    /**
     * @return a {@link Map} containing all the global {@link ApiResponse}
     */
    private Map<String,ApiResponse> globalResponses() {

        final Map<String,ApiResponse> apiResponses = new HashMap<>();

        final ApiResponse internalErrorResponse = new ApiResponse().description(INTERNAL_SERVER_ERROR.getReasonPhrase()
                + ": Something went wrong when executing the request. Check the application logs for more information.");

        final ApiResponse badRequestErrorResponse =
                new ApiResponse().description(BAD_REQUEST.getReasonPhrase() + ": The request is not well formatted.");

        final ApiResponse forbiddenErrorResponse = new ApiResponse().description(
                FORBIDDEN.getReasonPhrase() + ": The user described by the 'Authorization' header is not authorized to access the endpoint. "
                        + "Check that the user is added to the proper group in Active Directory.");

        final ApiResponse unauthorizedErrorResponse = new ApiResponse().description(UNAUTHORIZED.getReasonPhrase()
                + ": The request is not properly authorized. Provide an 'Authorization' header with basic authentication or a JWT.");

        apiResponses.put(String.valueOf(INTERNAL_SERVER_ERROR.value()), internalErrorResponse);
        apiResponses.put(String.valueOf(BAD_REQUEST.value()), badRequestErrorResponse);
        apiResponses.put(String.valueOf(FORBIDDEN.value()), forbiddenErrorResponse);
        apiResponses.put(String.valueOf(UNAUTHORIZED.value()), unauthorizedErrorResponse);

        return apiResponses;
    }
}
