package com.lombardinternational.casemanagement.service.decision.adapter.spi.web.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import com.lombardinternational.casemanagement.service.decision.domain.model.policy.Fund;

@Mapper
public interface FundMapper extends DtoMapper<Fund,com.lombardinternational.clients.classapp.model.Fund> {

    @Mapping(target = "fundSubClass", source = "typeOfSecurity")
    Fund toEntity(com.lombardinternational.clients.classapp.model.Fund fund);
}
