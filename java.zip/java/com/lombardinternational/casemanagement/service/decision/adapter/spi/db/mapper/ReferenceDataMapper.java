package com.lombardinternational.casemanagement.service.decision.adapter.spi.db.mapper;

import java.util.List;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.ReportingPolicy;

import com.lombardinternational.casemanagement.service.decision.adapter.spi.db.model.ReferenceDataEntity;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.SelectInputFieldOption;

@Mapper(unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface ReferenceDataMapper {

    @Mapping(source = "description", target = "value")
    @Mapping(source = "code", target = "key")
    SelectInputFieldOption mapToEntity(ReferenceDataEntity referenceDataEntity);

    List<SelectInputFieldOption> mapToEntity(List<ReferenceDataEntity> referenceDataEntities);
}
