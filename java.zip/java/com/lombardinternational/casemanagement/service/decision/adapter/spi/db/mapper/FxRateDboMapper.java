package com.lombardinternational.casemanagement.service.decision.adapter.spi.db.mapper;

import org.mapstruct.Mapper;

import com.lombardinternational.casemanagement.service.decision.adapter.spi.db.model.FxRateEntity;
import com.lombardinternational.casemanagement.service.decision.domain.model.FxRate;

@Mapper
public interface FxRateDboMapper {

    FxRateEntity toEntity(FxRate fxRate);

    FxRate toDomain(FxRateEntity entity);
}
