package com.lombardinternational.casemanagement.service.decision.adapter.spi.web.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import com.lombardinternational.casemanagement.service.decision.domain.model.policy.PersistedBlock;

@Mapper
public interface PersistedBlockMapper {

    @Mapping(source = "FIUReportingStatus", target = "fiuReportingStatus")
    PersistedBlock map(com.lombardinternational.clients.classapp.model.PersistedBlock persistedBlock);
}
