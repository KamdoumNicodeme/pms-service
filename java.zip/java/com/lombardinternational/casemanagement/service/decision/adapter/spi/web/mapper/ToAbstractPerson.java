package com.lombardinternational.casemanagement.service.decision.adapter.spi.web.mapper;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

import org.mapstruct.Mapping;

@Retention(RetentionPolicy.CLASS)
@Mapping(target = "thirdPartyId", source = "externalId")
@Mapping(target = "fatcaStatus", source = "fatcaStatus.externalId")
public @interface ToAbstractPerson {

}
