package com.lombardinternational.casemanagement.service.decision.adapter.api.web.rest.configuration;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationConverter;
import org.springframework.security.oauth2.server.resource.authentication.JwtGrantedAuthoritiesConverter;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
public class WebSecurityConfiguration {

    private static final String[] PERMIT_ALL_ACCESS = {
            // actuator
            "/actuator/**",

            // swagger
            "/swagger-ui/**", "/swagger-resources/**", "webjars/**", "/v3/api-docs/**" };

    private static final String API_ENDPOINTS = "/api/**";

    public static final String CASE_DECISION_READER_GROUP = "DL_Case_Decision_Reader";
    public static final String CASE_DECISION_WRITER_GROUP = "DL_Case_Decision_Writer";

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {

        http.cors(Customizer.withDefaults()).csrf((csrf) -> csrf.disable())
                .authorizeRequests((auth) -> auth.requestMatchers(PERMIT_ALL_ACCESS).permitAll().requestMatchers(HttpMethod.GET, API_ENDPOINTS)
                        .hasAnyAuthority(CASE_DECISION_READER_GROUP).requestMatchers(API_ENDPOINTS).hasAuthority(CASE_DECISION_WRITER_GROUP)
                        .anyRequest().authenticated())
                .oauth2ResourceServer(
                        (oauth2ResourceServer) -> oauth2ResourceServer.jwt((jwt) -> jwt.jwtAuthenticationConverter(jwtAuthenticationConverter())));

        return http.build();
    }

    /**
     * Map claims from the JWT to create a Spring Authentication object
     * 
     * @return the generated {@link JwtAuthenticationConverter}
     */
    public JwtAuthenticationConverter jwtAuthenticationConverter() {

        JwtGrantedAuthoritiesConverter groupsConverter = new JwtGrantedAuthoritiesConverter();
        groupsConverter.setAuthoritiesClaimName("groups");
        groupsConverter.setAuthorityPrefix("");

        JwtAuthenticationConverter jwtAuthenticationConverter = new JwtAuthenticationConverter();
        jwtAuthenticationConverter.setJwtGrantedAuthoritiesConverter(groupsConverter);
        jwtAuthenticationConverter.setPrincipalClaimName("preferred_username");
        return jwtAuthenticationConverter;
    }
}
