package com.lombardinternational.casemanagement.service.decision.adapter.spi.web.mapper;

import java.util.Collection;
import java.util.List;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;

import com.lombardinternational.casemanagement.service.decision.domain.model.policy.AbstractPerson;
import com.lombardinternational.casemanagement.service.decision.domain.model.policy.MoralPerson;
import com.lombardinternational.casemanagement.service.decision.domain.model.policy.PhysicalPerson;
import com.lombardinternational.clients.classapp.model.thirdparty.MoralPersonLight;
import com.lombardinternational.clients.classapp.model.thirdparty.PhysicalPersonLight;
import com.lombardinternational.clients.classapp.model.thirdparty.ThirdParty;
import com.lombardinternational.clients.classapp.model.thirdparty.ThirdPartyLight;

@Mapper(uses = { SourceOfFundsMapper.class, PersistedBlockMapper.class, AddressMapper.class }, config = HardCodeMapperConfig.class)
public interface AbstractPersonMapper {

    default AbstractPerson toEntity(ThirdParty thirdParty) {

        if (thirdParty instanceof com.lombardinternational.clients.classapp.model.thirdparty.MoralPerson) {
            return toEntity((com.lombardinternational.clients.classapp.model.thirdparty.MoralPerson) thirdParty);
        } else if (thirdParty instanceof com.lombardinternational.clients.classapp.model.thirdparty.PhysicalPerson) {
            return toEntity((com.lombardinternational.clients.classapp.model.thirdparty.PhysicalPerson) thirdParty);
        } else {
            throw new IllegalArgumentException("Unsupported third party type: " + thirdParty.getClass());
        }
    }

    @Named("moralPerson")
    @ToAbstractPerson
    @Mapping(source = "companyLegalForm.externalId", target = "companyLegalForm")
    @Mapping(source = "thirdParty", target = "subType", qualifiedByName = "mapSubType")
    MoralPerson toEntity(com.lombardinternational.clients.classapp.model.thirdparty.MoralPerson thirdParty);

    @Named("physicalPerson")
    @ToAbstractPerson
    @Mapping(target = "subType", constant = "Individual")
    PhysicalPerson toEntity(com.lombardinternational.clients.classapp.model.thirdparty.PhysicalPerson thirdParty);

    @Named("mapSubType")
    default String mapSubType(com.lombardinternational.clients.classapp.model.thirdparty.MoralPerson thirdParty) {

        if (thirdParty.getCompanyLegalForm() == null)
            return "Company";
        return switch (thirdParty.getCompanyLegalForm().getExternalId()) {
        case "FIDUCIARY" -> "Fiduciary";
        case "TRUST" -> "Trust";
        case "TRAD_COMP" -> "Trading company";
        default -> "Company";
        };
    }

    List<AbstractPerson> toEntities(Collection<ThirdPartyLight> thirdParties);

    default AbstractPerson toEntity(ThirdPartyLight thirdParty) {

        if (thirdParty instanceof MoralPersonLight) {
            return toEntity((MoralPersonLight) thirdParty);
        } else if (thirdParty instanceof PhysicalPersonLight) {
            return toEntity((PhysicalPersonLight) thirdParty);
        } else {
            throw new IllegalArgumentException("Unsupported third party type: " + thirdParty.getClass());
        }
    }

    @Named("moralPerson")
    @ToAbstractPerson
    @Mapping(source = "companyLegalForm.externalId", target = "companyLegalForm")
    MoralPerson toEntity(MoralPersonLight thirdParty);

    @Named("physicalPerson")
    @ToAbstractPerson
    PhysicalPerson toEntity(PhysicalPersonLight thirdParty);
}
