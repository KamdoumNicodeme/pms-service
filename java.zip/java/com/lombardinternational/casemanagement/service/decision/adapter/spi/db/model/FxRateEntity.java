package com.lombardinternational.casemanagement.service.decision.adapter.spi.db.model;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;
import lombok.Data;

@Entity
@Table(name = "FX_RATE")
@SequenceGenerator(name = "seq_fx_rate", sequenceName = "SEQ_FX_RATE", allocationSize = 1)
@Data
public class FxRateEntity {

    @Id
    @Column(name = "ID")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq_fx_rate")
    private Long id;

    @Column(name = "FROM_CCY", nullable = false)
    private String fromCcy;

    @Column(name = "TO_CCY", nullable = false)
    private String toCcy;

    @Column(name = "BARE_RATE", nullable = false)
    private BigDecimal bareRate;

    @Column(name = "BUY_RATE", nullable = false)
    private BigDecimal buyRate;

    @Column(name = "SELL_RATE", nullable = false)
    private BigDecimal sellRate;

    @Column(name = "SOURCE", nullable = false)
    private String source;

    @Column(name = "FX_RATE_DATE", nullable = false)
    private LocalDate fxRateDate;

    @Column(name = "FX_RATE_TIME", nullable = false)
    private LocalTime fxRateTime;
}
