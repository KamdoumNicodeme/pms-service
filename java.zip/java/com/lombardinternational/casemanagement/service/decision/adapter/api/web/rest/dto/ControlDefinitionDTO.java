package com.lombardinternational.casemanagement.service.decision.adapter.api.web.rest.dto;

import java.util.List;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class ControlDefinitionDTO {

    private int controlId;
    private String controlName;
    private boolean controlVisibleOnConnect;
    private int controlOrder;
    private List<String> decisionReasons;
    private String controlType;
}
