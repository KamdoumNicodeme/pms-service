package com.lombardinternational.casemanagement.service.decision.adapter.api.web.rest.dto;

import com.lombardinternational.casemanagement.service.decision.adapter.api.web.rest.dto.webform.WebFormDTO;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class SignatoriesRequestDTO {

    private WebFormDTO webForm;
    private String policyNumber;
}
