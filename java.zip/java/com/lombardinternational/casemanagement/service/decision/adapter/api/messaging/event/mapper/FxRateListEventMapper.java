package com.lombardinternational.casemanagement.service.decision.adapter.api.messaging.event.mapper;

import java.time.LocalTime;
import java.util.List;

import org.springframework.stereotype.Component;

import com.lombardinternational.casemanagement.service.decision.adapter.api.messaging.event.model.FxRateEvent;
import com.lombardinternational.casemanagement.service.decision.domain.model.FxRate;

@Component
public class FxRateListEventMapper implements EventMapper<Long,List<FxRate>,List<FxRateEvent>> {

    @Override
    public List<FxRate> toEntity(List<FxRateEvent> events, String correlationId, LocalTime createdTimestamp) {

        if (events.isEmpty()) {
            return List.of();
        }

        return events.stream()
                .map(e -> FxRate.builder().fromCcy(e.getFromCcy()).toCcy(e.getToCcy()).bareRate(e.getBareRate()).buyRate(e.getBuyRate())
                        .sellRate(e.getSellRate()).fxRateDate(e.getFxRateDate()).fxRateTime(e.getFxRateTime()).source(e.getSource()).build())
                .toList();
    }

}
