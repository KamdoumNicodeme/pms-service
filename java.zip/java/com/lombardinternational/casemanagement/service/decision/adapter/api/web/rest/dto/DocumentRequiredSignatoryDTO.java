package com.lombardinternational.casemanagement.service.decision.adapter.api.web.rest.dto;

import lombok.Data;

import java.util.List;

@Data
public class DocumentRequiredSignatoryDTO {

    private String documentType;
    private String documentRelatedTo;
    private boolean documentMustBeGenerated;
    private boolean documentRequiredOnConnect;
    private String description;
    private String i18NDescription;
    private int documentOrder;
    private List<RequiredSignatoryDTO> requiredSignatories;
    private String cmsDocumentType;
    private String iterableIndex;
}
