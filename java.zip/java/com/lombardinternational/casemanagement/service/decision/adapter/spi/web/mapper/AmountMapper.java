package com.lombardinternational.casemanagement.service.decision.adapter.spi.web.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import com.lombardinternational.casemanagement.service.decision.domain.model.policy.Amount;

@Mapper
public interface AmountMapper {

    @Mapping(target = "isoCurrencyCode", source = "currency")
    Amount map(com.lombardinternational.clients.classapp.model.Amount amount);
}
