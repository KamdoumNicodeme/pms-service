package com.lombardinternational.casemanagement.service.decision.adapter.spi.db.service;

import java.util.List;

import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import com.lombardinternational.casemanagement.service.decision.adapter.spi.db.mapper.ReferenceDataMapper;
import com.lombardinternational.casemanagement.service.decision.adapter.spi.db.repository.ReferenceDataRepository;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.SelectInputFieldOption;
import com.lombardinternational.casemanagement.service.decision.domain.spi.repository.ReferenceDataRepositoryService;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@AllArgsConstructor
public class ReferenceDataRepositoryServiceImpl implements ReferenceDataRepositoryService {

    public static final String REFERENCE_DATA_CACHE = "REFERENCE_DATA_CACHE";
    private final ReferenceDataMapper referenceDataMapper;
    private final ReferenceDataRepository referenceDataRepository;

    @Cacheable(REFERENCE_DATA_CACHE)
    @Override
    public List<SelectInputFieldOption> getReferenceDataOptionsByDomain(String domain) {

        var referenceEntities = referenceDataRepository.findByDomain(domain);
        var selectOptions = referenceDataMapper.mapToEntity(referenceEntities);
        selectOptions.addFirst(new SelectInputFieldOption("", ""));
        return selectOptions;
    }

    @Cacheable(REFERENCE_DATA_CACHE)
    @Override
    public List<SelectInputFieldOption> getReferenceDataOptionsByDomainAndSelectedValue(final String domain, final String selectedValue) {

        var options = getReferenceDataOptionsByDomain(domain);
        if (options.isEmpty()) {
            return selectedValue == null ? List.of(new SelectInputFieldOption("", ""))
                    : List.of(new SelectInputFieldOption(selectedValue, selectedValue));
        } else if (selectedValue == null) {
            return options;
        } else {
            return options.stream().filter(option -> option.getKey().equalsIgnoreCase(selectedValue)).toList();
        }

    }

    @CacheEvict(allEntries = true, value = { REFERENCE_DATA_CACHE })
    @Scheduled(cron = "${scheduler.dataDomain.cleanup.cron}")
    public void refreshCacheReferenceData() {

        log.info("Refreshing Reference Data Cache");
    }
}
