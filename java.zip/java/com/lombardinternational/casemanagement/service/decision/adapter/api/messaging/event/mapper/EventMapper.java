package com.lombardinternational.casemanagement.service.decision.adapter.api.messaging.event.mapper;

import java.io.Serializable;
import java.time.LocalTime;

public interface EventMapper< I extends Serializable, E, V > {

    E toEntity(V model, String correlationId, LocalTime lastUpdateTime);
}
