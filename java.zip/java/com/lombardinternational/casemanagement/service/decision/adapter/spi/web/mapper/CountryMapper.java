package com.lombardinternational.casemanagement.service.decision.adapter.spi.web.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import com.lombardinternational.casemanagement.service.decision.domain.model.policy.Country;

@Mapper
public interface CountryMapper {

    @Mapping(target = "isoCountryCode", source = "externalId")
    @Mapping(target = "countryName", source = "label")
    Country map(com.lombardinternational.clients.classapp.model.Country country);
}
