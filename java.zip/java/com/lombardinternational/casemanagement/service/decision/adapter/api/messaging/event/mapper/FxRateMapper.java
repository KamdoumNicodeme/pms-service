package com.lombardinternational.casemanagement.service.decision.adapter.api.messaging.event.mapper;

import org.mapstruct.Mapper;

import com.lombardinternational.casemanagement.service.decision.adapter.api.messaging.event.model.FxRateEvent;
import com.lombardinternational.casemanagement.service.decision.domain.model.FxRate;

@Mapper
public interface FxRateMapper extends EventMapper<Long,FxRate,FxRateEvent> {
}
