package com.lombardinternational.casemanagement.service.decision.adapter.spi.web.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import com.lombardinternational.casemanagement.service.decision.domain.model.policy.Block;
import com.lombardinternational.clients.classapp.model.PersistedBlock;

@Mapper
public interface BlockMapper extends DtoMapper<Block,PersistedBlock> {

    @Mapping(source = "blockType.label", target = "blockType")
    Block toEntity(PersistedBlock persistedBlock);
}
