package com.lombardinternational.casemanagement.service.decision.adapter.spi.db.repository;

import java.math.BigInteger;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.lombardinternational.casemanagement.service.decision.adapter.spi.db.model.CountryDataEntity;

public interface CountryDataRepository extends JpaRepository<CountryDataEntity,BigInteger> {

    List<CountryDataEntity> findCountryDataEntitiesByCountryType(String countryType);

    List<CountryDataEntity> findCountryDataEntitiesByCountryTypeAndCountryValue(String countryType, String countrValue);
}
