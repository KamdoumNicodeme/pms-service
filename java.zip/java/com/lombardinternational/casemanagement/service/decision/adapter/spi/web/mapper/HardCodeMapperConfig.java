package com.lombardinternational.casemanagement.service.decision.adapter.spi.web.mapper;

import org.mapstruct.MapperConfig;
import org.mapstruct.MappingInheritanceStrategy;

import com.lombardinternational.casemanagement.service.decision.domain.model.policy.HardCode;

@MapperConfig(mappingInheritanceStrategy = MappingInheritanceStrategy.AUTO_INHERIT_FROM_CONFIG)
public interface HardCodeMapperConfig {

    HardCode map(com.lombardinternational.clients.classapp.model.HardCode hardCode);
}
