package com.lombardinternational.casemanagement.service.decision.adapter.spi.web.service;

import com.lombardinternational.casemanagement.service.decision.adapter.spi.web.mapper.*;
import com.lombardinternational.casemanagement.service.decision.domain.exception.ClassInternalException;
import com.lombardinternational.casemanagement.service.decision.domain.exception.ClassInternalNotFoundException;
import com.lombardinternational.casemanagement.service.decision.domain.exception.ClassInternalValidationError;
import com.lombardinternational.casemanagement.service.decision.domain.model.policy.*;
import com.lombardinternational.casemanagement.service.decision.domain.model.transaction.BusinessTransaction;
import com.lombardinternational.casemanagement.service.decision.domain.spi.web.PolicyWebService;
import com.lombardinternational.clients.classapp.client.PolicyServiceClient;
import com.lombardinternational.clients.classapp.exception.ClassClientException;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.Collection;
import java.util.List;

@Service
@AllArgsConstructor
@Slf4j
public class PolicyWebServiceImpl implements PolicyWebService {

    private static final String POLICY_NOT_FOUND_CLASS_MESSAGE = "Error, the requested policy";

    private final PolicyServiceClient policyClient;
    private final PolicyMapper policyMapper;
    private final BlockMapper blockMapper;
    private final BusinessTransactionMapper businessTransactionMapper;
    private final PolicyRoleMapper policyRoleMapper;
    private final AbstractPersonMapper abstractPersonMapper;
    private final PolicyValuesMapper policyValuesMapper;

    @Override
    public Policy getPolicyDetails(final String policyNumber) throws Exception {

        try {
            return policyMapper.toEntity(policyClient.getPolicyDetails(policyNumber));
        } catch (ClassClientException e) {
            throw handlePolicyServiceClientException(e);
        }
    }

    @Override
    public Collection<Block> getBlocks(final String policyNumber) throws Exception {

        try {
            return blockMapper.toEntities(policyClient.getBlocks(policyNumber));
        } catch (ClassClientException e) {
            throw handlePolicyServiceClientException(e);
        }
    }

    @Override
    public Collection<BusinessTransaction> getBusinessTransactions(final String policyNumber) throws Exception {

        try {
            return businessTransactionMapper.lightsToEntities(policyClient.getBusinessTransactions(policyNumber));
        } catch (ClassClientException e) {
            throw handlePolicyServiceClientException(e);
        }
    }

    @Override
    public List<PolicyRole> getPolicyRoles(final String policyNumber) throws Exception {

        try {
            return policyRoleMapper.toEntities(policyClient.getPolicyRoles(policyNumber, null));
        } catch (ClassClientException e) {
            throw handlePolicyServiceClientException(e);
        }
    }

    @Override
    public Collection<AbstractPerson> getPolicyLinks(final String policyNumber) throws Exception {

        try {
            return abstractPersonMapper.toEntities(policyClient.getInternalRiskRecursiveLinks(policyNumber));
        } catch (ClassClientException e) {
            throw handlePolicyServiceClientException(e);
        }
    }

    @Override
    public PolicyValues getPolicyValues(final String policyNumber) throws Exception {

        try {
            return policyValuesMapper.toEntity(policyClient.getPolicyValues(policyNumber, false, false));
        } catch (ClassClientException e) {
            throw handlePolicyServiceClientException(e);
        }
    }

    private Exception handlePolicyServiceClientException(final ClassClientException e)
            throws ClassInternalException, ClassInternalNotFoundException, ClassInternalValidationError {

        if (e.status() == 500) {
            return new ClassInternalException(e.getMessage());
        }
        if (e.getMessage().startsWith(POLICY_NOT_FOUND_CLASS_MESSAGE)) {
            return new ClassInternalNotFoundException(e.getMessage());
        } else {
            return new ClassInternalValidationError(e.getMessage());
        }
    }
}
