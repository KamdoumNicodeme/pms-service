package com.lombardinternational.casemanagement.service.decision.adapter.spi.db.service;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.cache.Cache;
import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import com.lombardinternational.casemanagement.service.decision.adapter.spi.db.mapper.FxRateDboMapper;
import com.lombardinternational.casemanagement.service.decision.adapter.spi.db.model.FxRateEntity;
import com.lombardinternational.casemanagement.service.decision.adapter.spi.db.repository.FxRateRepository;
import com.lombardinternational.casemanagement.service.decision.domain.model.FxRate;
import com.lombardinternational.casemanagement.service.decision.domain.spi.repository.FxRateRepositoryService;

import jakarta.transaction.Transactional;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@AllArgsConstructor
@EnableScheduling
public class FxRateRepositoryServiceImpl implements FxRateRepositoryService {

    public static final String FX_RATES_CACHE = "FX_RATES_REST_CACHE";
    private final FxRateRepository fxRateRepository;
    private final FxRateDboMapper fxRateMapper;
    private final CacheManager cacheManager;

    @Cacheable(FX_RATES_CACHE)
    @Override
    public List<FxRate> getFxRateByFxRateDate(final LocalDate date) {

        return fxRateRepository.findByFxRateDate(date).stream().map(fxRateMapper::toDomain).toList();
    }

    @Override
    public void save(final FxRate fxRate) {

        // We need to search for existing rate in case we have a new rate load to avoid issue while retrieving the last rate on a specific date
        final var dbo = fxRateRepository.findByFromCcyAndToCcyAndFxRateDate(fxRate.getFromCcy(), fxRate.getToCcy(), fxRate.getFxRateDate())
                .map(existingRate -> updateRate(fxRate, existingRate)).orElseGet(() -> fxRateMapper.toEntity(fxRate));
        this.fxRateRepository.save(dbo);
        Optional.ofNullable(cacheManager.getCache(FX_RATES_CACHE)).ifPresent(Cache::clear);
    }

    @Override
    public Optional<LocalDate> getMaxFxRateDate() {

        return fxRateRepository.findMaxFxRateDate();
    }

    @Override
    @Scheduled(cron = "${scheduler.fxrate.cleanup.cron}")
    @Transactional
    public void deleteOldFXRatesRecords() {

        log.info("FxRate cleaning start");
        fxRateRepository.deleteOldFXRatesRecords();
        log.info("FxRate cleaning end");
    }

    @CacheEvict(allEntries = true, value = { FX_RATES_CACHE })
    @Scheduled(fixedDelay = 24 * 60 * 60 * 1000)
    public void refreshCacheFxRates() {

        log.info("Refreshing Fx Rates Cache");
    }

    @Override
    public void saveOrUpdateIfNewer(final FxRate newRate) {

        fxRateRepository
                .findTopByFromCcyAndToCcyAndFxRateDateOrderByFxRateTimeDesc(newRate.getFromCcy(), newRate.getToCcy(), newRate.getFxRateDate())
                .ifPresentOrElse(existing -> {
                    if (newRate.getFxRateTime().isAfter(existing.getFxRateTime())) {
                        fxRateRepository.save(fxRateMapper.toEntity(newRate));
                        log.debug("Updated FX rate for {} → {} on {}", newRate.getFromCcy(), newRate.getToCcy(), newRate.getFxRateDate());
                    } else {
                        log.debug("Skipped outdated FX rate for {} → {} on {}", newRate.getFromCcy(), newRate.getToCcy(), newRate.getFxRateDate());
                    }
                }, () -> {
                    fxRateRepository.save(fxRateMapper.toEntity(newRate));
                    log.debug("Inserted new FX rate for {} → {} on {}", newRate.getFromCcy(), newRate.getToCcy(), newRate.getFxRateDate());
                });
    }

    private FxRateEntity updateRate(final FxRate fxRate, final FxRateEntity existingRate) {

        existingRate.setBuyRate(fxRate.getBuyRate());
        existingRate.setSellRate(fxRate.getSellRate());
        existingRate.setBareRate(fxRate.getBareRate());
        return existingRate;
    }
}
