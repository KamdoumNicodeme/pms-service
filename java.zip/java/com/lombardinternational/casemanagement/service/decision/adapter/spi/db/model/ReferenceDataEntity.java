package com.lombardinternational.casemanagement.service.decision.adapter.spi.db.model;

import java.util.Set;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;
import lombok.Data;

@Entity
@Table(name = "REFERENCE_DATA")
@SequenceGenerator(name = "reference_data_seq", sequenceName = "SEQ_REFERENCE_DATA", allocationSize = 1)
@Data
public class ReferenceDataEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "reference_data_seq")
    private Long id;

    @Column(name = "CODE", nullable = false, length = 255)
    private String code;

    @Column(name = "DOMAIN", nullable = false, length = 255)
    private String domain;

    @Column(name = "DESCRIPTION", length = 255)
    private String description;

    @OneToMany(mappedBy = "referenceData", cascade = CascadeType.ALL, orphanRemoval = true)
    private Set<CountryDataEntity> countryData;
}
