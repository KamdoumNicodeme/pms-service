package com.lombardinternational.casemanagement.service.decision.adapter.api.web.rest.mapper;

import org.mapstruct.Mapper;

import com.lombardinternational.casemanagement.service.decision.adapter.api.web.rest.dto.webform.WebFormDTO;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;

@Mapper
public interface WebFormMapper {

    WebForm toEntity(WebFormDTO webFormDTO);

    WebFormDTO toDto(WebForm webForm);
}
