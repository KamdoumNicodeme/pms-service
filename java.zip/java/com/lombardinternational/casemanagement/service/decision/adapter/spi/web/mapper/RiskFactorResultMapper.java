package com.lombardinternational.casemanagement.service.decision.adapter.spi.web.mapper;

import org.mapstruct.Mapper;

import com.lombardinternational.casemanagement.service.decision.domain.model.policy.RiskFactorResult;

@Mapper
public interface RiskFactorResultMapper extends DtoMapper<RiskFactorResult,com.lombardinternational.clients.classapp.model.RiskFactorResult> {
}
