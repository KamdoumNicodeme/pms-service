package com.lombardinternational.casemanagement.service.decision.adapter.api.web.rest.controller;

import org.apache.kafka.common.errors.TimeoutException;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.lombardinternational.casemanagement.service.decision.adapter.api.messaging.event.model.CaseDecisionServiceError;
import com.lombardinternational.casemanagement.service.decision.domain.exception.ClassInternalException;
import com.lombardinternational.casemanagement.service.decision.domain.exception.ClassInternalNotFoundException;
import com.lombardinternational.casemanagement.service.decision.domain.exception.ClassInternalValidationError;
import com.lombardinternational.clients.classapp.exception.ClassClientException;

import feign.RetryableException;
import jakarta.servlet.UnavailableException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import static com.lombardinternational.casemanagement.service.decision.domain.errors.CaseDecisionErrorCode.*;

@ControllerAdvice
@Slf4j
@RequiredArgsConstructor
public class ControllerExceptionHandler extends ResponseEntityExceptionHandler {

    private CaseDecisionServiceError buildError(Exception e, String code) {

        return CaseDecisionServiceError.builder().code(code).message(e.getMessage()).exception(e.getClass().getName()).build();
    }

    @ExceptionHandler(value = { ClassClientException.class })
    protected ResponseEntity<Object> handleClassClientException(final ClassClientException e, final WebRequest request) {

        log.error("ClassClientException intercepted", e);
        return handleExceptionInternal(e, e.getMessage(), new HttpHeaders(), HttpStatus.BAD_REQUEST, request);
    }

    @ExceptionHandler(value = { TimeoutException.class, RetryableException.class })
    protected ResponseEntity<CaseDecisionServiceError> handleClassClientTimeoutException(final RetryableException e) {

        log.error("RetryableException intercepted", e);
        return ResponseEntity.status(HttpStatus.REQUEST_TIMEOUT).body(buildError(e, CLASS_TIMEOUT));
    }

    @ExceptionHandler(value = { UnavailableException.class })
    protected ResponseEntity<CaseDecisionServiceError> handleClassClientUnavailableException(final UnavailableException e) {

        log.error("UnavailableException intercepted", e);
        return ResponseEntity.status(HttpStatus.SERVICE_UNAVAILABLE).body(buildError(e, CLASS_UNAVAILABLE));
    }

    @ExceptionHandler(value = { ClassInternalNotFoundException.class })
    public final ResponseEntity<CaseDecisionServiceError> handleClassInternalNotFoundException(final ClassInternalNotFoundException e) {

        log.error("ClassInternalNotFoundException intercepted", e);
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(buildError(e, CLASS_NOT_FOUND));
    }

    @ExceptionHandler(value = { ClassInternalException.class })
    public final ResponseEntity<CaseDecisionServiceError> handleClassInternalErrorException(final ClassInternalException e) {

        log.error("ClassInternalException intercepted", e);
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(buildError(e, CLASS_INTERNAL_ERROR));
    }

    @ExceptionHandler(value = { ClassInternalValidationError.class })
    public final ResponseEntity<CaseDecisionServiceError> handleClassBadRequestException(final ClassInternalValidationError e) {

        log.error("ClassInternalValidationError intercepted", e);
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(buildError(e, CLASS_VALIDATION_ERROR));
    }
}
