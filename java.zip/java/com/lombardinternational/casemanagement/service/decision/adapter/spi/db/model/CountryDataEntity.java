package com.lombardinternational.casemanagement.service.decision.adapter.spi.db.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;
import lombok.Data;

@Entity
@Table(name = "COUNTRY_DATA")
@SequenceGenerator(name = "seq_country_data", sequenceName = "SEQ_COUNTRY_DATA", allocationSize = 1)
@Data
public class CountryDataEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "country_data_seq")
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "ID_REF_DATA", nullable = false)
    private ReferenceDataEntity referenceData;

    @Column(name = "COUNTRY_TYPE", nullable = false, length = 255)
    private String countryType;

    @Column(name = "COUNTRY_VALUE", nullable = false, length = 255)
    private String countryValue;

}
