package com.lombardinternational.casemanagement.service.decision.adapter.spi.web.mapper;

import java.util.List;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.SubclassMapping;

import com.lombardinternational.casemanagement.service.decision.domain.model.policy.Beneficiary;
import com.lombardinternational.casemanagement.service.decision.domain.model.policy.CessionHolder;
import com.lombardinternational.casemanagement.service.decision.domain.model.policy.EconomicBeneficiary;
import com.lombardinternational.casemanagement.service.decision.domain.model.policy.Holder;
import com.lombardinternational.casemanagement.service.decision.domain.model.policy.LifeAssured;
import com.lombardinternational.casemanagement.service.decision.domain.model.policy.PolicyRole;
import com.lombardinternational.casemanagement.service.decision.domain.model.policy.Proxy;
import com.lombardinternational.casemanagement.service.decision.domain.model.policy.Settlor;
import com.lombardinternational.casemanagement.service.decision.domain.model.policy.Trust;
import com.lombardinternational.casemanagement.service.decision.domain.model.policy.Trustee;
import com.lombardinternational.clients.classapp.model.roles.AbstractPolicyRole;

@Mapper(uses = { AbstractPersonMapper.class, CountryMapper.class })
public interface PolicyRoleMapper {

    List<PolicyRole> toEntities(List<AbstractPolicyRole> thirdPartyPolicyRoles);

    @Mapping(target = "roleId", source = "externalId")
    @SubclassMapping(source = com.lombardinternational.clients.classapp.model.roles.Holder.class, target = Holder.class)
    @SubclassMapping(source = com.lombardinternational.clients.classapp.model.roles.Beneficiary.class, target = Beneficiary.class)
    @SubclassMapping(source = com.lombardinternational.clients.classapp.model.roles.Trust.class, target = Trust.class)
    @SubclassMapping(source = com.lombardinternational.clients.classapp.model.roles.Trustee.class, target = Trustee.class)
    @SubclassMapping(source = com.lombardinternational.clients.classapp.model.roles.LifeAssured.class, target = LifeAssured.class)
    @SubclassMapping(source = com.lombardinternational.clients.classapp.model.roles.EconomicBeneficialOwner.class, target = EconomicBeneficiary.class)
    @SubclassMapping(source = com.lombardinternational.clients.classapp.model.roles.Settlor.class, target = Settlor.class)
    @SubclassMapping(source = com.lombardinternational.clients.classapp.model.roles.Proxy.class, target = Proxy.class)
    @SubclassMapping(source = com.lombardinternational.clients.classapp.model.roles.CessionHolder.class, target = CessionHolder.class)
    PolicyRole toEntity(AbstractPolicyRole thirdPartyPolicyRole);

    @Mapping(target = "irrevocableFlag", source = "irrevocable")
    Beneficiary toEntity(com.lombardinternational.clients.classapp.model.roles.Beneficiary abstractPolicyRole);

    @Mapping(source = "taxCountry.externalId", target = "taxIsoCountryCode")
    Holder toEntity(com.lombardinternational.clients.classapp.model.roles.Holder abstractPolicyRole);
}
