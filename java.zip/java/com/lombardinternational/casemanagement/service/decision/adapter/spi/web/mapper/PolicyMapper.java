package com.lombardinternational.casemanagement.service.decision.adapter.spi.web.mapper;

import com.lombardinternational.casemanagement.service.decision.domain.model.policy.Policy;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;

import java.time.LocalDate;
import java.time.Period;

@Mapper(uses = { CountryMapper.class, AmountMapper.class })
public interface PolicyMapper {

    @Mapping(source = "policyNumber", target = "number")
    @Mapping(source = "businessOrigin.externalId", target = "businessOrigin")
    @Mapping(source = "currency.isoCode", target = "isoCurrencyCode")
    @Mapping(source = "countryOfLaw.externalId", target = "countryOfLawCode")
    @Mapping(source = "isPledged", target = "pledged")
    @Mapping(source = "effectiveDate", target = "inForceForMoreThanOneYear", qualifiedByName = "inForceForMoreThanOneYear")
    Policy toEntity(com.lombardinternational.clients.classapp.model.Policy policy);

    @Named("inForceForMoreThanOneYear")
    default Boolean inForceForMoreThanOneYear(LocalDate effectiveDate) {

        if (effectiveDate == null)
            return false;
        final LocalDate currentDate = LocalDate.now();

        final int years = Period.between(effectiveDate, currentDate).getYears();
        return years > 1;
    }
}
