package com.lombardinternational.casemanagement.service.decision.adapter.spi.web.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

import com.lombardinternational.casemanagement.service.decision.domain.model.policy.SourceOfFunds;

@Mapper(uses = { SourceOfWealthMapper.class })
public interface SourceOfFundsMapper {

    @Mappings({ @Mapping(target = "negativePressFindingFlag", source = "negativePressFinding"),
            @Mapping(target = "internationalSanctionListFlag", source = "isOnInternationalSanctionList"),
            @Mapping(target = "insiderFlag", source = "isInsider"), @Mapping(target = "pepFlag", source = "isThirdPartyPep") })
    SourceOfFunds map(com.lombardinternational.clients.classapp.model.SourceOfFunds sourceOfFunds);
}
