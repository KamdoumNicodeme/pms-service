package com.lombardinternational.casemanagement.service.decision.adapter.spi.web.service;

import java.util.Collection;

import org.springframework.stereotype.Service;

import com.lombardinternational.casemanagement.service.decision.adapter.spi.web.mapper.FundMapper;
import com.lombardinternational.casemanagement.service.decision.domain.exception.ClassInternalException;
import com.lombardinternational.casemanagement.service.decision.domain.model.policy.Fund;
import com.lombardinternational.casemanagement.service.decision.domain.spi.web.FundWebService;
import com.lombardinternational.clients.classapp.client.FundServiceClient;
import com.lombardinternational.clients.classapp.exception.ClassClientException;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@AllArgsConstructor
public class FundWebServiceImpl implements FundWebService {

    private final FundServiceClient fundServiceClient;
    private final FundMapper fundMapper;

    @Override
    public Collection<Fund> getFunds(final String policyNumber) throws ClassClientException {

        try {
            return fundMapper.toEntities(fundServiceClient.getFundsByPolicyNumber(policyNumber));
        } catch (ClassClientException e) {
            throw new ClassInternalException(e.getMessage());
        }
    }
}
