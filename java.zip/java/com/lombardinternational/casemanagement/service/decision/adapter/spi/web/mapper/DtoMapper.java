package com.lombardinternational.casemanagement.service.decision.adapter.spi.web.mapper;

import java.util.Collection;
import java.util.List;

public interface DtoMapper< E, D > {

    E toEntity(D dto);

    List<E> toEntities(List<D> dtos);

    Collection<E> toEntities(Collection<D> dtos);
}
