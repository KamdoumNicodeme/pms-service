package com.lombardinternational.casemanagement.service.decision.adapter.spi.web.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Named;

import com.lombardinternational.casemanagement.service.decision.domain.model.transaction.MoneyInPayment;
import com.lombardinternational.casemanagement.service.decision.domain.model.transaction.MoneyOutPayment;
import com.lombardinternational.casemanagement.service.decision.domain.model.transaction.Payment;

@Mapper(uses = { CountryMapper.class, AmountMapper.class })
public interface PaymentMapper {

    default Payment map(com.lombardinternational.clients.classapp.model.Payment payment) {

        if (payment instanceof com.lombardinternational.clients.classapp.model.MoneyOutPayment) {
            return toEntity((com.lombardinternational.clients.classapp.model.MoneyOutPayment) payment);
        } else if (payment instanceof com.lombardinternational.clients.classapp.model.MoneyInPayment) {
            return toEntity((com.lombardinternational.clients.classapp.model.MoneyInPayment) payment);
        } else {
            throw new RuntimeException("Cannot parse Class Payment to Payment");
        }
    }

    @Named("moneyInPayment")
    MoneyInPayment toEntity(com.lombardinternational.clients.classapp.model.MoneyInPayment payment);

    @Named("moneyOutPayment")
    MoneyOutPayment toEntity(com.lombardinternational.clients.classapp.model.MoneyOutPayment payment);
}
