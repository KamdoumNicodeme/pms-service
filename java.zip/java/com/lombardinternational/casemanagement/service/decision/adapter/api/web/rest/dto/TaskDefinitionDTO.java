package com.lombardinternational.casemanagement.service.decision.adapter.api.web.rest.dto;

import java.util.List;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class TaskDefinitionDTO {

    private int taskId;
    private boolean suggested;
    private boolean mandatory;
    private String mainTaskName;
    private String mainTaskDynamicScreenId;
    private int mainTaskExpectedDurationSeconds;
    private int signoffTaskExpectedDurationSeconds;
    private int taskOrder;
    private boolean releasableFromSubTask;
    @Builder.Default
    private boolean completeRequired = true;
    private List<String> decisionReasons;
}
