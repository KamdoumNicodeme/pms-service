package com.lombardinternational.casemanagement.service.decision.adapter.api.web.rest.dto;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import lombok.Data;

@Data
public class SignatoryResultDTO {

    private List<DocumentRequiredSignatoryDTO> documentRequiredSignatories = new ArrayList<>();
    private Map<String,String> responseMessages = new HashMap<>();
}
