package com.lombardinternational.casedefinition.domain.service;

import com.lombardinternational.casedefinition.model.Fund;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.ArrayList;
import java.util.List;

@ExtendWith(MockitoExtension.class)
public class FundServiceTest {

    @InjectMocks
    private FundServiceImpl fundService;

    @Test
    void testFalseIfEmptyOrNull() {
        Assertions.assertFalse(fundService.containILFFund(null));
        Assertions.assertFalse(fundService.containILFFund(new ArrayList<>()));
    }

    @Test
    void testFalseIfNoPCF() {
        List<Fund> funds = new ArrayList<>();
        funds.add(createFund("F1", "BMF"));
        funds.add(createFund("F2", "PCP"));
        Assertions.assertFalse(fundService.containILFFund(funds));
    }

    @Test
    void testTrueIfAllPCF() {
        List<Fund> funds = new ArrayList<>();
        funds.add(createFund("F1", "PCF"));
        funds.add(createFund("F2", "PCF"));
        Assertions.assertTrue(fundService.containILFFund(funds));
    }

    @Test
    void testTrueIfAltLeastOnePCF() {
        List<Fund> funds = new ArrayList<>();
        funds.add(createFund("F1", "VIP"));
        funds.add(createFund("F2", "PCF"));
        funds.add(createFund("F3", "VIP"));
        Assertions.assertTrue(fundService.containILFFund(funds));
    }

    private Fund createFund(String fundNumber, String fundSubClass) {
        Fund fund = new Fund();
        fund.setFundNumber(fundNumber);
        fund.setFundSubClass(fundSubClass);
        return fund;
    }
}
