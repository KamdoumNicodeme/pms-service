package com.lombardinternational.casedefinition.utils;

import com.lombardinternational.casedefinition.model.CurrencyExchangeRate;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.Calendar;
import java.util.List;

public class FxRateUtils {
    public static List<CurrencyExchangeRate> getFxRates() {
        CurrencyExchangeRate fxRateUsdToEur = new CurrencyExchangeRate();
        fxRateUsdToEur.setBaseIsoCurrencyCode("USD");
        fxRateUsdToEur.setQuotedIsoCurrencyCode("EUR");
        fxRateUsdToEur.setRate(BigDecimal.valueOf(0.902656150));
        fxRateUsdToEur.setRateDate(Calendar.getInstance());
        CurrencyExchangeRate fxRateCadToEur = new CurrencyExchangeRate();
        fxRateCadToEur.setBaseIsoCurrencyCode("CAD");
        fxRateCadToEur.setQuotedIsoCurrencyCode("EUR");
        fxRateCadToEur.setRate(BigDecimal.valueOf(0.6696018745));
        fxRateCadToEur.setRateDate(Calendar.getInstance());
        CurrencyExchangeRate fxRateEurToGbp = new CurrencyExchangeRate();
        fxRateEurToGbp.setBaseIsoCurrencyCode("EUR");
        fxRateEurToGbp.setQuotedIsoCurrencyCode("GBP");
        fxRateEurToGbp.setRate(BigDecimal.valueOf(0.8409583569));
        fxRateEurToGbp.setRateDate(Calendar.getInstance());
        return Arrays.asList(fxRateUsdToEur, fxRateCadToEur, fxRateEurToGbp);
    }
}
