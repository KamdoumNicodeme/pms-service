package com.lombardinternational.casedefinition.converter;

import com.lombardinternational.casedefinition.mapper.CycleAvoidingMappingContext;
import com.lombardinternational.casedefinition.mapper.cdm.*;
import java.util.List;
import java.util.stream.Collectors;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;

import com.lombard.cdm.DataGridField;
import com.lombard.cdm.DocumentUploadInputField;
import com.lombard.cdm.Group;
import com.lombard.cdm.ScreenDescription;
import com.lombard.cdm.Tab;

import io.github.benas.randombeans.EnhancedRandomBuilder;
import io.github.benas.randombeans.api.EnhancedRandom;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.*;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = {
    CdmMapperImpl.class, CdmDocumentRequiredSignatoryMapperImpl.class,
    CdmFieldMapperImpl.class, CdmWebFormMapperImpl.class, CdmScreenDescriptionMapperImpl.class
})
public class ScreenDescriptionConverterTest {

    @Autowired
    CdmMapper mapper;

    @Test
    public void contextLoads() {
        assertThat(mapper).isNotNull();
    }

    @Test
    public void shouldConvertToScreenDescriptionFromCDM() {
        // configure random generator
        final EnhancedRandom enhancedRandom = EnhancedRandomBuilder.aNewEnhancedRandomBuilder().scanClasspathForConcreteTypes(true).build();

        // remove unsupported object type

        final ScreenDescription cdmScreenDescription = enhancedRandom.nextObject(ScreenDescription.class);
        cleanObject(cdmScreenDescription);
        final com.lombardinternational.casedefinition.model.ScreenDescription screenDescription =
                mapper.map(cdmScreenDescription, new CycleAvoidingMappingContext());
        assertEquals(cdmScreenDescription.getScreenId(), screenDescription.getScreenId());

    }

    /**
     * Remove unsupported type of field
     * 
     * @param cdmScreenDescription
     */
    private void cleanObject(ScreenDescription cdmScreenDescription) {

        final List<Tab> tabs = cdmScreenDescription.getTabs();
        tabs.stream().filter(tab -> tab != null).collect(Collectors.toList());
        for (Tab tab : tabs) {
            List<Group> groups = tab.getGroups();
            for (Group group : groups) {
                group.setFields(group.getFields().stream()
                        .filter(field -> !(field instanceof DataGridField) && !(field instanceof DocumentUploadInputField))
                        .collect(Collectors.toList()));
            }
        }

        System.out.println(cdmScreenDescription.toString());

    }

}
