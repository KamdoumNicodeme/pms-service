package com.lombardinternational.casedefinition.screendescription;

import com.lombardinternational.casedefinition.mapper.CycleAvoidingMappingContext;
import com.lombardinternational.casedefinition.mapper.cdm.*;
import java.io.File;
import java.util.Optional;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import com.lombard.csm.LoadScreenDescriptionRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import static org.hamcrest.CoreMatchers.*;
import static org.junit.Assert.*;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = {
	CdmMapperImpl.class, CdmDocumentRequiredSignatoryMapperImpl.class,
	CdmFieldMapperImpl.class, CdmWebFormMapperImpl.class, CdmScreenDescriptionMapperImpl.class
})
public class WebformTest {

	@Autowired
	CdmMapper mapper;

	@Test
	public void contextLoads() {
		assertThat(mapper, is(notNullValue()));
	}

	@Test
	public void testFlattened() throws JAXBException {

		File f = new File("src/test/java/com/lombardinternational/casedefinition/screendescription/loadScreenDescriptionRequest.xml");
		JAXBContext jaxbContext = JAXBContext.newInstance(LoadScreenDescriptionRequest.class);
		Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
		JAXBElement wf = (JAXBElement) jaxbUnmarshaller.unmarshal(f);
		LoadScreenDescriptionRequest req = (LoadScreenDescriptionRequest) wf.getValue();

		final com.lombardinternational.casedefinition.model.WebForm caseData = mapper.map(
				req.getBusinessContext().getCaseInitializationData(), new CycleAvoidingMappingContext());

		assertThat(caseData.getGroups().stream()
				.flatMap(wfg -> wfg.flattened().map(
						tf -> tf.getTextFields().stream().filter(t -> t.getFieldId().equals("CASE_ID")).findFirst()))
				.filter(Optional::isPresent).findFirst().get().get().getValue(), is("DRF_193_20180305"));
	}

}
