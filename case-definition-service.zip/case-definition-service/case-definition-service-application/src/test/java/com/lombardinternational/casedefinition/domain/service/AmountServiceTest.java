package com.lombardinternational.casedefinition.domain.service;

import java.math.BigDecimal;
import java.util.ArrayList;

import com.lombardinternational.clients.fxrates.model.FxRateFilter;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;

import com.lombardinternational.casedefinition.domain.spi.FxRateWebService;
import com.lombardinternational.casedefinition.model.Amount;
import com.lombardinternational.casedefinition.model.BusinessTransaction;
import com.lombardinternational.casedefinition.utils.BusinessTransactionUtils;
import com.lombardinternational.casedefinition.utils.FxRateUtils;

import static org.mockito.ArgumentMatchers.*;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
public class AmountServiceTest {

    @InjectMocks
    private AmountServiceImpl amountService;

    @Mock
    private FxRateWebService fxRateWebService;

    @BeforeEach
    void initMock() {
        Mockito.when(fxRateWebService.getFxRate(any(),any()))
              .thenReturn(FxRateUtils.getFxRates());
    }

    @Test
    void testSumPaymentAmount() {
        BusinessTransaction businessTransaction = BusinessTransactionUtils.createBusinessTransaction();
        Amount amountInEur = amountService.getSumPaymentAmountInTransaction(businessTransaction, "EUR");

        Assertions.assertEquals("EUR", amountInEur.getIsoCurrencyCode());
        Assertions.assertEquals(BigDecimal.valueOf(190705.90).setScale(2), amountInEur.getQuantity());
    }

    @Test
    void testSumPaymentAmount_NoBussinessTransaction() {
        Amount amountInEur = amountService.getSumPaymentAmountInTransaction(null, "EUR");

        Assertions.assertEquals("EUR", amountInEur.getIsoCurrencyCode());
        Assertions.assertEquals(BigDecimal.ZERO.setScale(2), amountInEur.getQuantity());
    }
    @Test
    void testSumPaymentAmount_NoProductComponentPayment() {
        BusinessTransaction businessTransaction = BusinessTransactionUtils.createBusinessTransaction();
        businessTransaction.setProductComponentPayments(null);
        Amount amountInEur = amountService.getSumPaymentAmountInTransaction(businessTransaction, "EUR");

        Assertions.assertEquals("EUR", amountInEur.getIsoCurrencyCode());
        Assertions.assertEquals(BigDecimal.ZERO.setScale(2), amountInEur.getQuantity());
    }
    @Test
    void testSumPaymentAmount_NoPayment() {
        BusinessTransaction businessTransaction = BusinessTransactionUtils.createBusinessTransaction();
        businessTransaction.setProductComponentPayments(new ArrayList<>());
        Amount amountInEur = amountService.getSumPaymentAmountInTransaction(businessTransaction, "EUR");

        Assertions.assertEquals("EUR", amountInEur.getIsoCurrencyCode());
        Assertions.assertEquals(BigDecimal.ZERO.setScale(2), amountInEur.getQuantity());
    }
    @Test
    void testSumPaymentAmount_NoPaymentAmount() {
        BusinessTransaction businessTransaction = BusinessTransactionUtils.createBusinessTransaction();
        businessTransaction.getProductComponentPayments().get(0).setPayments(null);
        Amount amountInEur = amountService.getSumPaymentAmountInTransaction(businessTransaction, "EUR");

        Assertions.assertEquals("EUR", amountInEur.getIsoCurrencyCode());
        Assertions.assertEquals(BigDecimal.ZERO.setScale(2), amountInEur.getQuantity());
    }

    @Test
    void testSumPaymentAmount_AmountEur() {
        BusinessTransaction businessTransaction = BusinessTransactionUtils.createBusinessTransactionPaymentEur();
        Amount amountInEur = amountService.getSumPaymentAmountInTransaction(businessTransaction, "EUR");

        Assertions.assertEquals("EUR", amountInEur.getIsoCurrencyCode());
        Assertions.assertEquals(BigDecimal.valueOf(250000.00).setScale(2), amountInEur.getQuantity());
    }

    @Test
    void testSumPaymentAmount_AmountMix() {
        BusinessTransaction businessTransaction = BusinessTransactionUtils.createBusinessTransactionPaymentMix();
        Amount amountInEur = amountService.getSumPaymentAmountInTransaction(businessTransaction, "EUR");

        Assertions.assertEquals("EUR", amountInEur.getIsoCurrencyCode());
        Assertions.assertEquals(BigDecimal.valueOf(240265.60).setScale(2), amountInEur.getQuantity());
    }

    @Test
    void testConvertAmount_NoQuantity() {
        Amount amount = amountService.convertAmount(new Amount(null, "USD"), "USD");

        Assertions.assertEquals("USD", amount.getIsoCurrencyCode());
        Assertions.assertEquals(BigDecimal.ZERO.setScale(2), amount.getQuantity());
    }

    @Test
    void testConvertAmount_NoCurrency() {
        Amount amount = amountService.convertAmount(new Amount(BigDecimal.valueOf(100000.000000), null), "USD");

        Assertions.assertEquals("USD", amount.getIsoCurrencyCode());
        Assertions.assertEquals(BigDecimal.valueOf(100000.00).setScale(2), amount.getQuantity());
    }

    @Test
    void testConvertAmount_TargetCurrencyNull() {
        Amount amount = amountService.convertAmount(new Amount(BigDecimal.valueOf(100000.000000), "EUR"), null);

        Assertions.assertEquals("EUR", amount.getIsoCurrencyCode());
        Assertions.assertEquals(BigDecimal.valueOf(100000.00).setScale(2), amount.getQuantity());
    }

    @Test
    void testConvertAmount_TargetCurrencyEqualsToSourceCurrency() {
        Amount amount = amountService.convertAmount(new Amount(BigDecimal.valueOf(100000.000000), "EUR"), "EUR");

        Assertions.assertEquals("EUR", amount.getIsoCurrencyCode());
        Assertions.assertEquals(BigDecimal.valueOf(100000.00).setScale(2), amount.getQuantity());
    }
}
