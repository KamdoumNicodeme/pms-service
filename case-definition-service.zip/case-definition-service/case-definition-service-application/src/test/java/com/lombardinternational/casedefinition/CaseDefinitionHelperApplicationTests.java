package com.lombardinternational.casedefinition;

import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.kie.server.client.RuleServicesClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.lombardinternational.casedefinition.config.KieServerConfigurationProperties;

@RunWith(SpringRunner.class)
@SpringBootTest
public class CaseDefinitionHelperApplicationTests {

    @Autowired
    RuleServicesClient ruleServicesClient;

    @Autowired
    KieServerConfigurationProperties kieProperties;

    @Ignore
    @Test
    public void testRemoteExecution() {

        // MyModel screenDescription = new MyModel();
        // screenDescription.setText("1");
        //
        // BatchExecutionCommandBuilder builder = new BatchExecutionCommandBuilder(kieProperties.getSession());
        // builder.addCommand(BatchExecutionCommandBuilder.COMMANDS.newInsert(screenDescription, "Screen id test"));
        // builder.addCommand(BatchExecutionCommandBuilder.COMMANDS.newFireAllRules("fire-identifier"));
        //
        // // Call remote service
        // ServiceResponse<ExecutionResults> response = ruleServicesClient.executeCommandsWithResults(kieProperties.getContainer(),
        // builder.build());
        // System.out.println(response.getResult());
    }

}
