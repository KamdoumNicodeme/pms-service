package com.lombardinternational.casedefinition.config;


import org.springframework.context.annotation.Configuration;

@Configuration
public class TestConverterConfiguration {

}
