package com.lombardinternational.casedefinition.utils;

import com.lombardinternational.casedefinition.model.*;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.List;


public class BusinessTransactionUtils {

    public static BusinessTransaction createBusinessTransaction() {
        BusinessTransaction businessTransaction = new BusinessTransaction();
        businessTransaction.setProductComponentPayments(createBusinessTransactionProductComponent());
        return businessTransaction;
    }

    public static List<BusinessTransactionProductComponent> createBusinessTransactionProductComponent() {
        BusinessTransactionProductComponent businessTransactionProductComponent = new BusinessTransactionProductComponent();
        businessTransactionProductComponent.setPayments(createPayments());
        return Arrays.asList(businessTransactionProductComponent);
    }

    public static List<Payment> createPayments() {
        Payment payment = new MoneyInPayment();
        payment.setPaymentAmount(new Amount(BigDecimal.valueOf(100000.0), "USD"));

                Payment payment1 = new MoneyInPayment();
        payment1.setPaymentAmount(new Amount(BigDecimal.valueOf(150000.0), "CAD"));

                return Arrays.asList(payment, payment1);
    }
    public static BusinessTransaction createBusinessTransactionPaymentEur() {
        BusinessTransaction businessTransaction = new BusinessTransaction();
        businessTransaction.setProductComponentPayments(createBusinessTransactionProductComponentEur());
        return businessTransaction;
    }

    public static List<BusinessTransactionProductComponent> createBusinessTransactionProductComponentEur() {
        BusinessTransactionProductComponent businessTransactionProductComponent = new BusinessTransactionProductComponent();
        businessTransactionProductComponent.setPayments(createPaymentsEur());
        return Arrays.asList(businessTransactionProductComponent);
    }

    public static List<Payment> createPaymentsEur() {
        Payment payment = new MoneyInPayment();
        payment.setPaymentAmount(new Amount(BigDecimal.valueOf(100000.0), "EUR"));

        Payment payment1 = new MoneyInPayment();
        payment1.setPaymentAmount(new Amount(BigDecimal.valueOf(150000.0), "EUR"));

        return Arrays.asList(payment, payment1);
    }

    public static BusinessTransaction createBusinessTransactionPaymentMix() {
        BusinessTransaction businessTransaction = new BusinessTransaction();
        businessTransaction.setProductComponentPayments(createBusinessTransactionProductComponentMix());
        return businessTransaction;
    }

    public static List<BusinessTransactionProductComponent> createBusinessTransactionProductComponentMix() {
        BusinessTransactionProductComponent businessTransactionProductComponent = new BusinessTransactionProductComponent();
        businessTransactionProductComponent.setPayments(createPaymentsMix());
        return Arrays.asList(businessTransactionProductComponent);
    }

    public static List<Payment> createPaymentsMix() {
        Payment payment = new MoneyInPayment();
        payment.setPaymentAmount(new Amount(BigDecimal.valueOf(100000.0), "USD"));

        Payment payment1 = new MoneyInPayment();
        payment1.setPaymentAmount(new Amount(BigDecimal.valueOf(150000.0), "EUR"));

        return Arrays.asList(payment, payment1);
    }

}
