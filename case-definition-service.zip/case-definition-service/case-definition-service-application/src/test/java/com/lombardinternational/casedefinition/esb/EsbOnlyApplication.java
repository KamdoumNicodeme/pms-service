//package com.lombardinternational.casedefinition.esb;
//
//import org.kie.server.client.KieServicesConfiguration;
//import org.kie.server.client.RuleServicesClient;
//import org.springframework.boot.autoconfigure.SpringBootApplication;
//import org.springframework.context.annotation.Bean;
//
//import com.lombardinternational.casedefinition.config.EsbConfiguration;
//
//@SpringBootApplication(scanBasePackageClasses={EsbConfiguration.class}, scanBasePackages= {"com.lombardinternational.casedefinition.service"})
//public class EsbOnlyApplication {
//
//}
//
