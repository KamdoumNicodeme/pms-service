package com.lombardinternational.casedefinition.adapter.api.web.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.lombardinternational.casedefinition.adapter.api.web.dto.SignatoryResult;
import com.lombardinternational.casedefinition.adapter.api.web.dto.WebformSignatoryRequest;
import com.lombardinternational.casedefinition.adapter.api.web.mapper.SignatoryResultMapper;
import com.lombardinternational.casedefinition.adapter.api.web.mapper.WebFormMapper;
import com.lombardinternational.casedefinition.domain.api.WebFormBusinessService;
import com.lombardinternational.casedefinition.model.WebForm;
import com.lombardinternational.utils.servicelogger.milestones.domain.LogMilestone;
import com.lombardinternational.utils.servicelogger.milestones.domain.LoggableValue;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;

/**
 * WebForm Rest Controller
 *
 * @author qemo
 */
@Tag(name ="WebForms", description = "WebForms management")
@RestController
@RequestMapping("/api/webforms")
@LogMilestone(category = "rest", domain = "case-definition")
public class WebFormController {

    private final WebFormBusinessService webFormBusinessService;
    private final WebFormMapper webFormMapper;
    private final SignatoryResultMapper signatoryResultMapper;

    @Autowired
    public WebFormController(WebFormBusinessService webFormBusinessService,
        WebFormMapper webFormMapper,
        SignatoryResultMapper signatoryResultMapper) {
        this.webFormBusinessService = webFormBusinessService;
        this.webFormMapper = webFormMapper;
        this.signatoryResultMapper = signatoryResultMapper;
    }

    @PostMapping("signatories")
    @Operation(summary = "Generate connect signature list based on a WebformSignatoryRequest")
    @LogMilestone(action = "get signatories")
    public ResponseEntity<SignatoryResult> getSignatories(@LoggableValue({"caseType", "policyNumber", "clientNumber"}) @Valid @RequestBody WebformSignatoryRequest webformSignatoryRequest) {
        final WebForm webForm = this.webFormMapper.webFormFromDTO(webformSignatoryRequest.getCaseInitializationData());

        final com.lombardinternational.casedefinition.model.SignatoryResult signatoryResult = this.webFormBusinessService
            .computeSignatories(webformSignatoryRequest.getCaseType(), webformSignatoryRequest.getPolicyNumber(), webForm);

        return ResponseEntity.ok(this.signatoryResultMapper.dtoFromSignatoryResult(signatoryResult));
    }
}
