package com.lombardinternational.casedefinition.adapter.api.web.dto;

import java.util.Calendar;

public class CalendarWebFormField extends WebFormField {

    private Calendar value;

    public CalendarWebFormField() {
    }

    public Calendar getValue() {

        return value;
    }

    public void setValue(Calendar value) {

        this.value = value;
    }

    @Override
    public String toString() {

        return "CalendarWebFormField [" + super.toString() + " - value=" + value + "]";
    }

}
