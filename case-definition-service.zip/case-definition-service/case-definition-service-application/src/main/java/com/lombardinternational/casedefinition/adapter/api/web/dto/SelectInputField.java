package com.lombardinternational.casedefinition.adapter.api.web.dto;

import java.util.List;

public class SelectInputField extends Field {

    private Integer minWidthPct;
    private Integer minWidthPx;
    private List<SelectInputFieldOption> options;

    public SelectInputField() {
        super();
    }

    public Integer getMinWidthPct() {

        return minWidthPct;
    }

    public void setMinWidthPct(Integer minWidthPct) {

        this.minWidthPct = minWidthPct;
    }

    public Integer getMinWidthPx() {

        return minWidthPx;
    }

    public void setMinWidthPx(Integer minWidthPx) {

        this.minWidthPx = minWidthPx;
    }

    public List<SelectInputFieldOption> getOptions() {

        return options;
    }

    public void setOptions(List<SelectInputFieldOption> options) {

        this.options = options;
    }

    @Override
    public String toString() {

        final StringBuilder optionsToString = new StringBuilder();
        if (options != null) {
            options.forEach(option -> optionsToString.append(option).append("\n"));
        }
        return "SelectInputField [" + super.toString() + " minWidthPct=" + minWidthPct + ", minWidthPx=" + minWidthPx + ", options="
            + optionsToString.toString() + "]";
    }

}
