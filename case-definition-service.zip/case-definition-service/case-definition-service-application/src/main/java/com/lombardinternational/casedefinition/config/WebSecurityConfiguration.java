package com.lombardinternational.casedefinition.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationConverter;
import org.springframework.security.oauth2.server.resource.authentication.JwtGrantedAuthoritiesConverter;


/**
 * Security configuration class ${@link WebSecurityConfiguration}
 *
 * @author qemo
 */
@Configuration
public class WebSecurityConfiguration extends WebSecurityConfigurerAdapter {
    private static final String[] PERMIT_ALL_ACCESS = {
        // actuator
        "/actuator/**",

        // swagger
        "/swagger-ui.html",
        "/swagger-ui/**",
        "/swagger-resources/**",
        "webjars/**",
        "/v3/api-docs/**"
    };

    @Value("${security.jwt.group}")
    private String caseDefinitionReaderGroup;

    @Value("${security.jwt.authority-prefix}")
    private String authorityPrefix;

    @Value("${security.jwt.principal-claim-name}")
    private String principalClaimName;

    /**
     * {@inheritDoc}
     */
    @Override
    protected void configure(final HttpSecurity http) throws Exception {
        http.cors()
            .and()
                .authorizeRequests()
                    .antMatchers(PERMIT_ALL_ACCESS)
                        .permitAll()
                    .antMatchers("/api/**")
                        .hasAuthority(this.caseDefinitionReaderGroup)
                    .anyRequest()
                        .authenticated()
            .and()
                .csrf()
                    .disable()
                .headers()
                    .frameOptions()
                        .disable()
            .and()
                .oauth2ResourceServer()
                    .jwt().jwtAuthenticationConverter(jwtAuthenticationConverter());
    }

    /**
     * Map claims from the JWT to create a Spring Authentication object
     * @return the generated {@link JwtAuthenticationConverter}
     */
    public JwtAuthenticationConverter jwtAuthenticationConverter() {
        JwtGrantedAuthoritiesConverter groupsConverter = new JwtGrantedAuthoritiesConverter();
        groupsConverter.setAuthoritiesClaimName("groups");
        groupsConverter.setAuthorityPrefix(this.authorityPrefix);

        JwtAuthenticationConverter jwtAuthenticationConverter = new JwtAuthenticationConverter();
        jwtAuthenticationConverter.setJwtGrantedAuthoritiesConverter(groupsConverter);
        jwtAuthenticationConverter.setPrincipalClaimName(this.principalClaimName);
        return jwtAuthenticationConverter;
    }
}
