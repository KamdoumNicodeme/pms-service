package com.lombardinternational.casedefinition.adapter.spi.service.rest.mapper;

import com.lombardinternational.casedefinition.model.Fund;
import org.mapstruct.BeanMapping;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import java.util.Collection;
import java.util.List;

@Mapper(componentModel = "spring")
public interface FundMapper {

    @BeanMapping(ignoreByDefault = true)
    @Mapping(target = "fundNumber", source = "fundNumber")
    @Mapping(target = "fundSubClass", source = "typeOfSecurity")
    Fund map(com.lombardinternational.clients.classapp.model.Fund fund);

    List<Fund> map(Collection<com.lombardinternational.clients.classapp.model.Fund> fund);

}
