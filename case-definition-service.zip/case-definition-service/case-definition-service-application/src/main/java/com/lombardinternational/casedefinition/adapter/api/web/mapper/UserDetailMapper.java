package com.lombardinternational.casedefinition.adapter.api.web.mapper;

import com.lombardinternational.casedefinition.model.UserDetail;
import org.mapstruct.Mapper;

/**
 * Mapper between ${@link UserDetailMapper} and ${@link com.lombardinternational.casedefinition.adapter.api.web.dto.UserDetail}
 *
 * @author qemo
 */
@Mapper(componentModel="spring")
public interface UserDetailMapper {

    UserDetail userDetailFromDTO(com.lombardinternational.casedefinition.adapter.api.web.dto.UserDetail dto);
}
