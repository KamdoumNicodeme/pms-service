package com.lombardinternational.casedefinition.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.ImportResource;
import org.springframework.context.annotation.PropertySource;

@Configuration
@PropertySource({ "classpath:fwk-client-config.yml" })
@ImportResource({ "classpath:intfwk-common-context.xml", "classpath:intfwk-client-context.xml", "classpath:webservices-application-context.xml" })
public class EsbConfiguration {

}
