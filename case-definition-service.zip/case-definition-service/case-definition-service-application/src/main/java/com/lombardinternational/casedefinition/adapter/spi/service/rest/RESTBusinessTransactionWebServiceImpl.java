package com.lombardinternational.casedefinition.adapter.spi.service.rest;

import com.lombardinternational.casedefinition.domain.spi.BusinessTransactionWebService;
import com.lombardinternational.casedefinition.mapper.BusinessTransactionMapper;
import com.lombardinternational.casedefinition.model.BusinessTransaction;
import com.lombardinternational.clients.classapp.client.BusinessTransactionClient;
import com.lombardinternational.clients.classapp.client.PolicyServiceClient;
import com.lombardinternational.clients.classapp.model.BusinessTransactionDetails;
import com.lombardinternational.clients.classapp.model.BusinessTransactionLight;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import java.util.Collection;
import java.util.List;

@Service
@RequiredArgsConstructor
public class RESTBusinessTransactionWebServiceImpl implements BusinessTransactionWebService {
    
    private final BusinessTransactionClient businessTransactionClient;
    private final PolicyServiceClient policyServiceClient;
    private final BusinessTransactionMapper businessTransactionMapper;

    @Override
    public BusinessTransaction getBusinessTransaction(String businessTransactionNumber) throws RuntimeException {
        if(!businessTransactionNumber.isEmpty()) {
            BusinessTransactionDetails businessTransaction = businessTransactionClient.getBusinessTransaction(businessTransactionNumber);
            return businessTransactionMapper.buildBusinessTransaction(businessTransaction);
        }
        return null;
    }

    @Override
    public List<BusinessTransaction> getBusinessTransactions(String policyNumber) throws RuntimeException {
        if(StringUtils.isBlank(policyNumber))
            throw new IllegalArgumentException("policyNumber cannot be null or blank.");

        Collection<BusinessTransactionLight> businessTransactions = policyServiceClient.getBusinessTransactions(policyNumber);
        return businessTransactionMapper.mapToListFromLightList(businessTransactions);
    }
}
