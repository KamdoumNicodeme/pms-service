package com.lombardinternational.casedefinition.adapter.spi.ruleengine;

import com.lombardinternational.casedefinition.config.KieServerConfigurationProperties;
import com.lombardinternational.casedefinition.domain.spi.RulesWebService;
import com.lombardinternational.casedefinition.model.BusinessTransaction;
import com.lombardinternational.casedefinition.model.CaseControlDefinition;
import com.lombardinternational.casedefinition.model.CaseDeal;
import com.lombardinternational.casedefinition.model.CaseDocumentDefinition;
import com.lombardinternational.casedefinition.model.CurrencyExchangeRate;
import com.lombardinternational.casedefinition.model.Policy;
import com.lombardinternational.casedefinition.model.RequiredSignatory;
import com.lombardinternational.casedefinition.model.ScreenDescription;
import com.lombardinternational.casedefinition.model.SignatoryResult;
import com.lombardinternational.casedefinition.model.TaskDefinition;
import com.lombardinternational.casedefinition.model.WebForm;
import com.lombardinternational.casedefinition.util.BatchExecutionCommandBuilder;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.Validate;
import org.kie.api.runtime.ExecutionResults;
import org.kie.server.api.model.ServiceResponse;
import org.kie.server.client.RuleServicesClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
@EnableConfigurationProperties({ KieServerConfigurationProperties.class })
public class RulesWebServiceImpl implements RulesWebService {

    private static final Logger logger = LoggerFactory.getLogger(RulesWebServiceImpl.class);
    private final RuleServicesClient ruleServicesClient;
    private final KieServerConfigurationProperties kieProperties;

    private static final String OVERALL_CASE_RISK = "overallCaseRisk";
    private static final String TRANSLATIONS = "translations";
    private static final String FATCA_RISK = "fatcaRisk";
    private static final String DESTINATION_RISK = "destinationRisk";
    private static final String RESIDENCE_RISK = "residenceRisk";
    private static final String PROFESSION_RISK = "professionsRisk";
    private static final String PAYMENT_IN_RISK = "paymentInRisk";
    private static final String WEALTH_RISK = "wealthRisk";
    private static final String AGENDA_SETVALUE_NAME = "SETVALUE";
    private static final String AGENDA_BUILD_NAME = "BUILD";
    private static final String CONTAINER_CHECKLIST_KEY = "checklist";
    private static final String CONTAINER_DOCUMENT_LIST_KEY = "documentList";
    private static final String CONTAINER_TASKLIST_KEY = "taskList";
    private static final String CONTAINER_TASKSCREEN_KEY = "taskScreen";
    private static final String CONTAINER_CONTROL_LIST_KEY = "controlList";
    private static final String CONTAINER_CONNECT_SIGNATURE_LIST_KEY = "connectSignatureList";
    private static final String SCREEN_TASK = "SCREEN_TASK";
    private static final String WEB_FORM_ID = "WEB_FORM";
    private static final String SCREEN_CHECKLIST = "SCREEN_CHECKLIST";
    private static final String POLICY = "policy";
    private static final String BUSINESS_TRANSACTION = "transaction";
    private static final String CASE_DEALS = "caseDeals";
    private static final String REQUIRED_SIGNATORIES = "requiredSignatoryList";
    private static final String GLOBAL_SHARED_LISTS = "globalSharedLists";
    private static final String GLOBAL_COUNTRY_RISK = "globalCountryRisk";
    private static final String GLOBAL_FX_RATES = "fxRates";

    @Autowired
    public RulesWebServiceImpl(RuleServicesClient ruleServicesClient,
        KieServerConfigurationProperties kieProperties) {
        this.ruleServicesClient = ruleServicesClient;
        this.kieProperties = kieProperties;
    }

    /**
     * see {@inheritDoc}
     */
    @Override
    public ScreenDescription computeScreenDescription(final Policy policy, final BusinessTransaction businessTransaction, final WebForm webForm,
                                                      final ScreenDescription screenDescriptionToBuild, final Map<String, CaseDeal> caseDeals, final List<CurrencyExchangeRate> fxRates) throws RuntimeException {
        Validate.notNull(screenDescriptionToBuild, "Error,screen description can not be null.It is used to compute the screen description");

        final String number = policy != null ? policy.getNumber() : "No policy number";
        final String webformId = (webForm != null) ? webForm.getWebFormId() : StringUtils.EMPTY;
        final String identifier = businessTransaction != null ? businessTransaction.getIdentifier() : "No business transaction number";

        logger.info(
            "Process the computation of the screen definition. Parameters are: policyNumber= {} - Business transaction number = {} - WebFormID= {} - screen descritpion= {}",
            number, identifier, webformId, screenDescriptionToBuild.getScreenId());

        // Define the session to use to compute the rules
        final BatchExecutionCommandBuilder builder = new BatchExecutionCommandBuilder(kieProperties.getSession());

        // setup of the global object : global object are used as Context element for
        // the rules
        builder.addCommand(BatchExecutionCommandBuilder.COMMANDS.newSetGlobal(POLICY, policy));
        builder.addCommand(BatchExecutionCommandBuilder.COMMANDS.newSetGlobal(BUSINESS_TRANSACTION, businessTransaction));

        // Add shared map
        this.buildSharedMap(builder);

        builder.addCommand(BatchExecutionCommandBuilder.COMMANDS.newSetGlobal(CASE_DEALS, caseDeals));
        builder.addCommand(BatchExecutionCommandBuilder.COMMANDS.newSetGlobal(GLOBAL_FX_RATES, fxRates));

        builder.addCommand(BatchExecutionCommandBuilder.COMMANDS.newInsert(webForm, WEB_FORM_ID));
        builder.addCommand(BatchExecutionCommandBuilder.COMMANDS.newInsert(screenDescriptionToBuild, SCREEN_CHECKLIST));
        builder.addCommand(BatchExecutionCommandBuilder.COMMANDS.newAgendaGroupSetFocus(AGENDA_BUILD_NAME));
        builder.addCommand(BatchExecutionCommandBuilder.COMMANDS.newFireAllRules("fire-identifier"));

        builder.addCommand(BatchExecutionCommandBuilder.COMMANDS.newAgendaGroupSetFocus(AGENDA_SETVALUE_NAME));
        builder.addCommand(BatchExecutionCommandBuilder.COMMANDS.newFireAllRules("fire-identifier"));
        // Call remote service

        logger.info("Trigger the execution of the rules used to compute the screen : {}", screenDescriptionToBuild.getScreenId());
        if (policy != null) {
            logger.debug("policy: {}", policy.toString());
        }

        if (businessTransaction != null) {
            logger.debug("business transaction: {}", businessTransaction.toString());
        }

        final String webformToString = (webForm != null) ? webForm.toString() : StringUtils.EMPTY;

        logger.debug("web form: " + webformToString);
        logger.debug("screen description to fill: {}", screenDescriptionToBuild.getScreenId());

        final ServiceResponse<ExecutionResults> response =
            ruleServicesClient.executeCommandsWithResults(kieProperties.getContainer().get(CONTAINER_CHECKLIST_KEY), builder.build());

        final ExecutionResults executionResult = response.getResult();

        if (executionResult != null) {
            logger.info("Rules have been executed with success");
            final ScreenDescription resultScreenDescription = (ScreenDescription) executionResult.getValue(SCREEN_CHECKLIST);
            logger.debug(resultScreenDescription.toString());
            return resultScreenDescription;

        } else {
            logger.error("Error while executing the rules." + response.getMsg());
            throw new RuntimeException("Error while executing the rules." + response.getMsg());
        }
    }

    /**
     * see {@inheritDoc}
     */
    @Override
    public List<TaskDefinition> computeTaskDefinition(final Policy policy, final WebForm webForm, final ScreenDescription screenCheckList) throws RuntimeException {
        final BatchExecutionCommandBuilder builder = new BatchExecutionCommandBuilder(kieProperties.getSession());

        final List<TaskDefinition> taskDefinitions = new ArrayList<>();

        // Add shared map
        buildSharedMap(builder);

        builder.addCommand(BatchExecutionCommandBuilder.COMMANDS.newInsert(taskDefinitions, "results"));
        builder.addCommand(BatchExecutionCommandBuilder.COMMANDS.newInsert(webForm, WEB_FORM_ID));
        builder.addCommand(BatchExecutionCommandBuilder.COMMANDS.newInsert(screenCheckList, SCREEN_CHECKLIST));

        // setup of the global object : global object are used as Context element for
        // the rules
        builder.addCommand(BatchExecutionCommandBuilder.COMMANDS.newSetGlobal(POLICY, policy));

        builder.addCommand(BatchExecutionCommandBuilder.COMMANDS.newAgendaGroupSetFocus(AGENDA_BUILD_NAME));
        builder.addCommand(BatchExecutionCommandBuilder.COMMANDS.newFireAllRules("fire-identifier"));
        builder.addCommand(BatchExecutionCommandBuilder.COMMANDS.newAgendaGroupSetFocus(AGENDA_SETVALUE_NAME));
        builder.addCommand(BatchExecutionCommandBuilder.COMMANDS.newFireAllRules("fire-identifier"));

        // Call remote service
        logger.info("Trigger the execution of the rules used to get the list of tasks.");
        logger.debug("web form: {}", ((webForm != null) ? webForm.toString() : StringUtils.EMPTY));
        logger.debug("screen description to fill: {}", screenCheckList != null ? screenCheckList.getScreenId() : StringUtils.EMPTY);

        final ServiceResponse<ExecutionResults> response =
            ruleServicesClient.executeCommandsWithResults(kieProperties.getContainer().get(CONTAINER_TASKLIST_KEY), builder.build());

        final ExecutionResults executionResult = response.getResult();

        if (executionResult != null) {
            logger.info("Rules have been executed with success");
            final List<TaskDefinition> resultTaskDefinitions = ((List<TaskDefinition>) executionResult.getValue("results"));
            logger.debug(resultTaskDefinitions.toString());
            return resultTaskDefinitions;
        } else {
            logger.error("Error while executing the rules. {}", response.getMsg());
            throw new RuntimeException("Error while executing the rules." + response.getMsg());
        }
    }

    /**
     * see {@inheritDoc}
     */
    @Override
    public List<CaseDocumentDefinition> computeCaseDocumentsDefinition(final Policy policy, final WebForm webForm, final ScreenDescription screenCheckList)
        throws RuntimeException {
        final BatchExecutionCommandBuilder builder = new BatchExecutionCommandBuilder(kieProperties.getSession());
        final List<CaseDocumentDefinition> caseDocuments = new ArrayList<>();

        builder.addCommand(BatchExecutionCommandBuilder.COMMANDS.newInsert(caseDocuments, "results"));
        builder.addCommand(BatchExecutionCommandBuilder.COMMANDS.newSetGlobal(POLICY, policy));
        builder.addCommand(BatchExecutionCommandBuilder.COMMANDS.newInsert(webForm, WEB_FORM_ID));

        if (screenCheckList != null) {
            builder.addCommand(BatchExecutionCommandBuilder.COMMANDS.newInsert(screenCheckList, SCREEN_CHECKLIST));
        }

        builder.addCommand(BatchExecutionCommandBuilder.COMMANDS.newFireAllRules("fire-identifier"));

        // Call remote service

        logger.info("Trigger the execution of the rules used to compute the list of case document definitions");

        if (policy != null) {
            logger.debug("policy: {}", policy.toString());
        }

        logger.debug("web form: {}", ((webForm != null) ? webForm.toString() : StringUtils.EMPTY));

        if (screenCheckList != null) {
            logger.debug("screen checklist: {}", screenCheckList.getScreenId());
        }

        final ServiceResponse<ExecutionResults> response =
            ruleServicesClient.executeCommandsWithResults(kieProperties.getContainer().get(CONTAINER_DOCUMENT_LIST_KEY), builder.build());

        final ExecutionResults executionResult = response.getResult();

        if (executionResult != null) {
            logger.info("Rules have been executed with success");
            final List<CaseDocumentDefinition> resultCaseDocumentDefinitions =
                ((List<CaseDocumentDefinition>) executionResult.getValue("results"));

            logger.debug(resultCaseDocumentDefinitions.toString());
            return resultCaseDocumentDefinitions;

        } else {

            logger.error("Error while executing the rules. {}", response.getMsg());
            throw new RuntimeException("Error while executing the rules." + response.getMsg());
        }
    }

    @Override
    public ScreenDescription computeTaskScreen(final WebForm webForm, final ScreenDescription screenCheckList, final ScreenDescription screenToFill)
        throws RuntimeException {
        final BatchExecutionCommandBuilder builder = new BatchExecutionCommandBuilder(kieProperties.getSession());

        builder.addCommand(BatchExecutionCommandBuilder.COMMANDS.newInsert(webForm, WEB_FORM_ID));
        builder.addCommand(BatchExecutionCommandBuilder.COMMANDS.newInsert(screenCheckList, SCREEN_CHECKLIST));
        builder.addCommand(BatchExecutionCommandBuilder.COMMANDS.newInsert(screenToFill, SCREEN_TASK));

        // Add shared map
        this.buildSharedMap(builder);

        builder.addCommand(BatchExecutionCommandBuilder.COMMANDS.newAgendaGroupSetFocus(AGENDA_BUILD_NAME));
        builder.addCommand(BatchExecutionCommandBuilder.COMMANDS.newFireAllRules("fire-identifier"));
        builder.addCommand(BatchExecutionCommandBuilder.COMMANDS.newAgendaGroupSetFocus(AGENDA_SETVALUE_NAME));
        builder.addCommand(BatchExecutionCommandBuilder.COMMANDS.newFireAllRules("fire-identifier"));

        logger.info("Trigger the execution of the rules used to compute the screen : {}", screenToFill.getScreenId());
        logger.debug("web form: {}", ((webForm != null) ? webForm.toString() : StringUtils.EMPTY));
        logger.debug("screen checklist: {}", screenCheckList != null ? screenCheckList.getScreenId() : StringUtils.EMPTY);
        logger.debug("screen description to fill: {}", screenToFill != null ? screenToFill.getScreenId() : StringUtils.EMPTY);

        // Call remote service
        final ServiceResponse<ExecutionResults> response =
            ruleServicesClient.executeCommandsWithResults(kieProperties.getContainer().get(CONTAINER_TASKSCREEN_KEY), builder.build());

        final ExecutionResults executionResult = response.getResult();

        if (executionResult != null) {
            logger.info("Rules have been executed with success");
            final ScreenDescription resultScreenDescription = (ScreenDescription) executionResult.getValue(SCREEN_TASK);
            logger.debug(resultScreenDescription.toString());
            return resultScreenDescription;
        } else {
            logger.error("Error while executing the rules. {}", response.getMsg());
            throw new RuntimeException("Error while executing the rules." + response.getMsg());
        }
    }

    /**
     * see {@inheritDoc}
     */
    @Override
    public List<CaseControlDefinition> computeCaseControlDefinitions(final WebForm webForm, final ScreenDescription screenCheckList)
        throws RuntimeException {

        final BatchExecutionCommandBuilder builder = new BatchExecutionCommandBuilder(kieProperties.getSession());
        final List<CaseControlDefinition> caseControlDefintions = new ArrayList<>();

        // Add shared map
        buildSharedMap(builder);

        builder.addCommand(BatchExecutionCommandBuilder.COMMANDS.newInsert(caseControlDefintions, "results"));
        builder.addCommand(BatchExecutionCommandBuilder.COMMANDS.newInsert(webForm, WEB_FORM_ID));
        builder.addCommand(BatchExecutionCommandBuilder.COMMANDS.newInsert(screenCheckList, SCREEN_CHECKLIST));

        builder.addCommand(BatchExecutionCommandBuilder.COMMANDS.newAgendaGroupSetFocus(AGENDA_BUILD_NAME));
        builder.addCommand(BatchExecutionCommandBuilder.COMMANDS.newFireAllRules("fire-identifier"));
        builder.addCommand(BatchExecutionCommandBuilder.COMMANDS.newAgendaGroupSetFocus(AGENDA_SETVALUE_NAME));
        builder.addCommand(BatchExecutionCommandBuilder.COMMANDS.newFireAllRules("fire-identifier"));

        // Call remote service
        final String webFormId = webForm != null ? webForm.getWebFormId() : StringUtils.EMPTY;
        final String webFormToString = webForm != null ? webForm.toString() : StringUtils.EMPTY;

        logger.info("Trigger the execution of the rules used to compute the screen list of controls. Webform: {} - Screen checklist: {}",
            webFormId, screenCheckList != null ? screenCheckList.getScreenId() : StringUtils.EMPTY);
        logger.debug("web form: {}", webFormToString);
        logger.debug("screen checklist: {}", screenCheckList != null ? screenCheckList.getScreenId() : StringUtils.EMPTY);

        final ServiceResponse<ExecutionResults> response =
            ruleServicesClient.executeCommandsWithResults(kieProperties.getContainer().get(CONTAINER_CONTROL_LIST_KEY), builder.build());

        final ExecutionResults executionResult = response.getResult();

        if (executionResult != null) {
            logger.info("Rules have been executed with success");
            final List<CaseControlDefinition> resultCaseControlDefinitions = ((List<CaseControlDefinition>) executionResult.getValue("results"));
            logger.debug(resultCaseControlDefinitions.toString());
            return resultCaseControlDefinitions;

        } else {
            logger.error("Error while executing the rules. {}", response.getMsg());
            throw new RuntimeException("Error while executing the rules." + response.getMsg());
        }
    }

    /**
     * see {@inheritDoc}
     */
    @Override
    public SignatoryResult computeSignatories(final Policy policy, final WebForm webForm) throws RuntimeException {
        Validate.notNull(webForm, "Error, web form can not be null.It is used to compute the screen description");

        final SignatoryResult signatoryResult = new SignatoryResult();
        final ArrayList<RequiredSignatory> requiredSignatoryList = new ArrayList<>();
        // Define the session to use to compute the rules

        final BatchExecutionCommandBuilder builder = new BatchExecutionCommandBuilder(kieProperties.getSession());

        // setup of the global object : global object are used as Context element for
        // the rules
        builder.addCommand(BatchExecutionCommandBuilder.COMMANDS.newSetGlobal(POLICY, policy));
        builder.addCommand(BatchExecutionCommandBuilder.COMMANDS.newSetGlobal(REQUIRED_SIGNATORIES, requiredSignatoryList));

        builder.addCommand(BatchExecutionCommandBuilder.COMMANDS.newInsert(signatoryResult, "results"));
        builder.addCommand(BatchExecutionCommandBuilder.COMMANDS.newInsert(webForm, WEB_FORM_ID));
        builder.addCommand(BatchExecutionCommandBuilder.COMMANDS.newFireAllRules("fire-identifier"));

        // Call remote service

        logger.info("Trigger the execution of the rules used to compute the list of required document signatory");

        if (policy != null) {
            logger.debug("policy: {}", policy.toString());
        }

        logger.debug("web form: {}", webForm.toString());

        final ServiceResponse<ExecutionResults> response = ruleServicesClient
            .executeCommandsWithResults(kieProperties.getContainer().get(CONTAINER_CONNECT_SIGNATURE_LIST_KEY), builder.build());

        final ExecutionResults executionResult = response.getResult();

        if (executionResult != null) {
            logger.info("Rules have been executed with success");
            final SignatoryResult result = (SignatoryResult) executionResult.getValue("results");
            logger.debug(result.toString());

            return result;

        } else {
            logger.error("Error while executing the rules. {}", response.getMsg());
            throw new RuntimeException("Error while executing the rules." + response.getMsg());
        }
    }

    /**
     * add all the {@link Map<String, List<String>>} to the given {@link BatchExecutionCommandBuilder}
     *
     * @param builder: the {@link BatchExecutionCommandBuilder}
     */
    private void buildSharedMap(BatchExecutionCommandBuilder builder) {

        final Map<String, List<String>> residenceRisk = new HashMap<>();
        final Map<String, List<String>> fatcaRisk = new HashMap<>();
        final Map<String, List<String>> destinationRisk = new HashMap<>();
        final Map<String, List<String>> professionsRisk = new HashMap<>();
        final Map<String, List<String>> paymentInRisk = new HashMap<>();
        final Map<String, List<String>> wealthRisk = new HashMap<>();
        final Map<String, String> translations = new HashMap<>();
        final Map<String, String> globalSharedLists = new HashMap<>();
        final Map<String, List<String>> overallCaseRisk = new HashMap<>();
        final Map<String, List<String>> globalCountryRisk = new HashMap<>();

        builder.addCommand(BatchExecutionCommandBuilder.COMMANDS.newSetGlobal(RESIDENCE_RISK, residenceRisk));
        builder.addCommand(BatchExecutionCommandBuilder.COMMANDS.newSetGlobal(FATCA_RISK, fatcaRisk));
        builder.addCommand(BatchExecutionCommandBuilder.COMMANDS.newSetGlobal(DESTINATION_RISK, destinationRisk));
        builder.addCommand(BatchExecutionCommandBuilder.COMMANDS.newSetGlobal(PROFESSION_RISK, professionsRisk));
        builder.addCommand(BatchExecutionCommandBuilder.COMMANDS.newSetGlobal(PAYMENT_IN_RISK, paymentInRisk));
        builder.addCommand(BatchExecutionCommandBuilder.COMMANDS.newSetGlobal(WEALTH_RISK, wealthRisk));
        builder.addCommand(BatchExecutionCommandBuilder.COMMANDS.newSetGlobal(TRANSLATIONS, translations));
        builder.addCommand(BatchExecutionCommandBuilder.COMMANDS.newSetGlobal(GLOBAL_SHARED_LISTS, globalSharedLists));
        builder.addCommand(BatchExecutionCommandBuilder.COMMANDS.newSetGlobal(OVERALL_CASE_RISK, overallCaseRisk));
        builder.addCommand(BatchExecutionCommandBuilder.COMMANDS.newSetGlobal(GLOBAL_COUNTRY_RISK, globalCountryRisk));

    }
}
