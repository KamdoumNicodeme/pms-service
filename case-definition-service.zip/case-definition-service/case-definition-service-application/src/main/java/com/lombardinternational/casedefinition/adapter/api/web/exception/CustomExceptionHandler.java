package com.lombardinternational.casedefinition.adapter.api.web.exception;

import com.lombardinternational.casedefinition.adapter.spi.ruleengine.RulesWebServiceImpl;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import java.util.Date;

@RestControllerAdvice
public class CustomExceptionHandler extends ResponseEntityExceptionHandler {

    private static final Logger logger = LoggerFactory.getLogger(CustomExceptionHandler.class);

    @ExceptionHandler({Exception.class})
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    protected ErrorResource handleAllExceptions(Exception ex, WebRequest webRequest){
        logger.error("Error occurred : ", ex);
        return new ErrorResource(HttpStatus.INTERNAL_SERVER_ERROR.name(), ex.getMessage(), webRequest.getDescription(false), new Date());
    }

    @Override
    protected ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException ex, HttpHeaders headers, HttpStatus status,
        WebRequest request) {
        return ResponseEntity.badRequest().body(new ErrorResource(status.name(), ex.getMessage(), request.getDescription(false), new Date()));
    }
}
