package com.lombardinternational.casedefinition.adapter.api.web.dto;



import java.util.ArrayList;
import java.util.List;

public class Group {
    protected String groupId;
    protected String title;
    protected String i18NTitleKey;
    protected int order;
    protected List<Field> fields = new ArrayList<>();
    protected String displayIf;

    public Group() {
    }

    public String getGroupId() {
        return groupId;
    }

    public void setGroupId(String groupId) {
        this.groupId = groupId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getI18NTitleKey() {
        return i18NTitleKey;
    }

    public void setI18NTitleKey(String i18NTitleKey) {
        this.i18NTitleKey = i18NTitleKey;
    }

    public int getOrder() {
        return order;
    }

    public void setOrder(int order) {
        this.order = order;
    }

    public List<Field> getFields() {
        return fields;
    }

    public void setFields(List<Field> fields) {
        this.fields = fields;
    }

    public String getDisplayIf() {
        return displayIf;
    }

    public void setDisplayIf(String displayIf) {
        this.displayIf = displayIf;
    }
}
