package com.lombardinternational.casedefinition.adapter.api.web.mapper;

import com.lombardinternational.casedefinition.model.ScreenDescription;
import org.mapstruct.Mapper;

/**
 * Mapper between ${@link ScreenDescription} and ${@link com.lombardinternational.casedefinition.adapter.api.web.dto.ScreenDescription}
 *
 * @author qemo
 */
@Mapper(componentModel = "spring",uses = {TabMapper.class})
public interface ScreenDescriptionMapper {
    ScreenDescription screenDescriptionFromDTO(com.lombardinternational.casedefinition.adapter.api.web.dto.ScreenDescription screenDescriptionDTO);
    com.lombardinternational.casedefinition.adapter.api.web.dto.ScreenDescription DTOFromScreenDescription(ScreenDescription screenDescription);
}
