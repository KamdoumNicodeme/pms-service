package com.lombardinternational.casedefinition.mapper;

import com.lombardinternational.casedefinition.model.Address;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring", uses = { CountryMapper.class })
public interface AddressMapper {

    Address map(com.lombardinternational.clients.classapp.model.Address address);
}
