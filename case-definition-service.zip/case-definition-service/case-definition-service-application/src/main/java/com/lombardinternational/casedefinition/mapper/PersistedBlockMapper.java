package com.lombardinternational.casedefinition.mapper;

import com.lombardinternational.casedefinition.model.PersistedBlock;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring")
public interface PersistedBlockMapper {

    @Mapping(source = "FIUReportingStatus", target = "FIUReportingStatus")
    PersistedBlock map(com.lombardinternational.clients.classapp.model.PersistedBlock persistedBlock);
}
