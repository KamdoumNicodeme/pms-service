package com.lombardinternational.casedefinition.mapper.cdm;

import com.lombardinternational.casedefinition.model.*;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface CdmDocumentRequiredSignatoryMapper {

    com.lombard.cdm.RequiredSignatory map(RequiredSignatory cdm);



}
