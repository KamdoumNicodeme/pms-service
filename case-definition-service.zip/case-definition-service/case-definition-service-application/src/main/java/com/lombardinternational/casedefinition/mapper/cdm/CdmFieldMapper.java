package com.lombardinternational.casedefinition.mapper.cdm;

import com.lombardinternational.casedefinition.model.*;
import org.mapstruct.*;

@Mapper(componentModel = "spring")
public interface CdmFieldMapper {


    CheckBoxField map (com.lombard.cdm.CheckBoxField field);
    com.lombard.cdm.CheckBoxField map (CheckBoxField field);

    LabelField map (com.lombard.cdm.LabelField field);
    com.lombard.cdm.LabelField map (LabelField field);

    NumberInputField map (com.lombard.cdm.NumberInputField field);
    com.lombard.cdm.NumberInputField map (NumberInputField field);

    SelectInputField map (com.lombard.cdm.SelectInputField field);
    com.lombard.cdm.SelectInputField map (SelectInputField field);

    TextAreaField map (com.lombard.cdm.TextAreaField field);
    com.lombard.cdm.TextAreaField map (TextAreaField field);

    TextInputField map (com.lombard.cdm.TextInputField field);
    com.lombard.cdm.TextInputField map (TextInputField field);

    default Field map(com.lombard.cdm.Field cdm) {
        if (cdm == null) return null;

        if (cdm instanceof com.lombard.cdm.CheckBoxField) return map((com.lombard.cdm.CheckBoxField) cdm);
        if (cdm instanceof com.lombard.cdm.LabelField) return map((com.lombard.cdm.LabelField) cdm);
        if (cdm instanceof com.lombard.cdm.NumberInputField) return map((com.lombard.cdm.NumberInputField) cdm);
        if (cdm instanceof com.lombard.cdm.SelectInputField) return map((com.lombard.cdm.SelectInputField) cdm);
        if (cdm instanceof com.lombard.cdm.TextAreaField) return map((com.lombard.cdm.TextAreaField) cdm);
        if (cdm instanceof com.lombard.cdm.TextInputField) return map((com.lombard.cdm.TextInputField) cdm);

        return null; // Default fallback
    }

    default com.lombard.cdm.Field map(Field cds) {
        if (cds == null) return null;

        if (cds instanceof CheckBoxField) return map((CheckBoxField) cds);
        if (cds instanceof LabelField) return map((LabelField) cds);
        if (cds instanceof NumberInputField) return map((NumberInputField) cds);
        if (cds instanceof SelectInputField) return map((SelectInputField) cds);
        if (cds instanceof TextAreaField) return map((TextAreaField) cds);
        if (cds instanceof TextInputField) return map((TextInputField) cds);

        return null; // Default Fallback
    }

}
