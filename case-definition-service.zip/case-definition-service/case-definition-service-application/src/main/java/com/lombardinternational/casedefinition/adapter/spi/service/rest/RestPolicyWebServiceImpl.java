package com.lombardinternational.casedefinition.adapter.spi.service.rest;

import java.util.Collection;
import java.util.List;

import org.springframework.stereotype.Service;

import com.lombardinternational.casedefinition.domain.spi.PolicyWebService;
import com.lombardinternational.clients.classapp.client.PolicyServiceClient;
import com.lombardinternational.clients.classapp.model.PersistedBlock;
import com.lombardinternational.clients.classapp.model.Policy;
import com.lombardinternational.clients.classapp.model.PolicyValues;
import com.lombardinternational.clients.classapp.model.roles.AbstractPolicyRole;
import com.lombardinternational.clients.classapp.model.thirdparty.ThirdPartyLight;

import lombok.AllArgsConstructor;

@Service
@AllArgsConstructor
public class RestPolicyWebServiceImpl implements PolicyWebService {

    private final PolicyServiceClient policyClient;

    @Override
    public Policy getPolicy(final String policyNumber) throws IllegalArgumentException {
        return policyClient.getPolicyDetails(policyNumber);
    }

    @Override
    public PolicyValues getPolicyValues(final String policyNumber) {
        return policyClient.getPolicyValues(policyNumber, false, false);
    }

    @Override
    public Collection<PersistedBlock> getBlocks(final String policyNumber) {
        return policyClient.getBlocks(policyNumber);
    }

    @Override
    public List<AbstractPolicyRole> getPolicyRole(final String policyNumber) {
        return policyClient.getPolicyRoles(policyNumber, null);
    }

    @Override
    public Collection<ThirdPartyLight> getPolicyLinks(String policyNumber) {
        return policyClient.getInternalRiskRecursiveLinks(policyNumber, null);
    }
}
