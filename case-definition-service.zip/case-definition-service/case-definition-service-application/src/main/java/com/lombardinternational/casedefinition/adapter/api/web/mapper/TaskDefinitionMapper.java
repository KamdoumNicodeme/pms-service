package com.lombardinternational.casedefinition.adapter.api.web.mapper;

import com.lombardinternational.casedefinition.adapter.api.web.dto.TaskDefinition;
import org.mapstruct.Mapper;

import java.util.List;

/**
 * Mapper between ${@link TaskDefinition} and ${@link com.lombardinternational.casedefinition.adapter.api.web.dto.TaskDefinition}
 *
 * @author qemo
 */
@Mapper(componentModel = "spring")
public interface TaskDefinitionMapper {

    TaskDefinition map (com.lombardinternational.casedefinition.model.TaskDefinition taskDefinition);

    List<TaskDefinition> map(List<com.lombardinternational.casedefinition.model.TaskDefinition> taskDefinitions);
}
