package com.lombardinternational.casedefinition.domain.service;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import com.lombardinternational.casedefinition.domain.api.PolicyService;
import com.lombardinternational.casedefinition.domain.api.WebFormBusinessService;
import com.lombardinternational.casedefinition.domain.spi.RulesWebService;
import com.lombardinternational.casedefinition.model.Policy;
import com.lombardinternational.casedefinition.model.SignatoryResult;
import com.lombardinternational.casedefinition.model.WebForm;

import lombok.AllArgsConstructor;

/**
 * ${@link WebForm} Business Service
 *
 * @author qemo
 */
@Service
@AllArgsConstructor
public class WebFormBusinessServiceImpl implements WebFormBusinessService {

    /**
     * New business case type.
     */
    private static final String NB_CASE_TYPE = "NEW_BUSINESS";

    /**
     * Required services
     */
    private final PolicyService policyService;
    private final RulesWebService rulesWebService;

    /**
     * see {@inheritDoc}
     */
    @Override
    public SignatoryResult computeSignatories(String caseType, String policyNumber, WebForm webForm) {

        Policy policy = null;
        if (StringUtils.isNotBlank(policyNumber) && !NB_CASE_TYPE.equals(caseType)) {
            policy = policyService.buildPolicy(policyNumber);

        }
        return this.rulesWebService.computeSignatories(policy, webForm);
    }
}
