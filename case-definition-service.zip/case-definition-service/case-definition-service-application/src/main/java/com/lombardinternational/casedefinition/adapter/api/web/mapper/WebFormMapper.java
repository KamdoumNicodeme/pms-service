package com.lombardinternational.casedefinition.adapter.api.web.mapper;

import org.mapstruct.Mapper;

import com.lombardinternational.casedefinition.model.WebForm;

/**
 * Mapper between ${@link WebFormMapper} and ${@link com.lombardinternational.casedefinition.adapter.api.web.dto.WebForm}
 *
 * @author qemo
 */
@Mapper(componentModel = "spring", uses = {UserDetailMapper.class, CompanyDetailMapper.class, FormInitiatorlMapper.class, WebFormGroupMapper.class})
public interface WebFormMapper {

    WebForm webFormFromDTO(com.lombardinternational.casedefinition.adapter.api.web.dto.WebForm dto);
}
