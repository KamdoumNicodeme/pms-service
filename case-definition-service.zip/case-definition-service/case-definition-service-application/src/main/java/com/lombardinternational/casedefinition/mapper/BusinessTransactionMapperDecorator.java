package com.lombardinternational.casedefinition.mapper;

import com.lombardinternational.casedefinition.model.RoleEndorsementBusinessTransaction;
import com.lombardinternational.clients.classapp.client.EndorsementBusinessTransactionClient;
import com.lombardinternational.clients.classapp.model.BusinessTransactionDetails;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

public abstract class BusinessTransactionMapperDecorator implements BusinessTransactionMapper {

    @Autowired
    @Qualifier("delegate")
    private BusinessTransactionMapper delegate;

    @Autowired
    private EndorsementBusinessTransactionClient endorsementBusinessTransactionClient;

    public RoleEndorsementBusinessTransaction mapToRoleEndorsement(BusinessTransactionDetails businessTransactionDetails) {
        RoleEndorsementBusinessTransaction roleEndorsementBusinessTransaction = delegate.mapToRoleEndorsement(businessTransactionDetails);
        com.lombardinternational.clients.classapp.model.RoleEndorsementBusinessTransaction roleEndorsementBusinessTransactionREST = endorsementBusinessTransactionClient.getRoleEndorsementBusinessTransaction(roleEndorsementBusinessTransaction.getIdentifier());
        delegate.updateRoleEndorsement(roleEndorsementBusinessTransaction, roleEndorsementBusinessTransactionREST);
        return roleEndorsementBusinessTransaction;
    }
}
