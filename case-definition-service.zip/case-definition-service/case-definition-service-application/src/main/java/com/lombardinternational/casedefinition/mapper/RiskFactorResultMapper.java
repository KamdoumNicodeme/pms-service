package com.lombardinternational.casedefinition.mapper;

import com.lombardinternational.casedefinition.model.RiskFactorResult;
import org.mapstruct.Mapper;

import java.util.List;

@Mapper(componentModel = "spring")
public interface RiskFactorResultMapper {

    List<RiskFactorResult> mapToList(List<com.lombardinternational.clients.classapp.model.RiskFactorResult> riskFactorResults);
}
