package com.lombardinternational.casedefinition.domain.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lombardinternational.casedefinition.domain.api.FundService;
import com.lombardinternational.casedefinition.domain.spi.FundWebService;
import com.lombardinternational.casedefinition.model.Fund;

@Service
public class FundServiceImpl implements FundService {

    @Autowired
    private FundWebService fundWebService;

    private static final String PCF = "PCF";

    private FundServiceImpl() {
    }

    @Override
    public List<Fund> getFunds(final String policyNumber) {
        return fundWebService.getFunds(policyNumber);
    }

    @Override
    public Boolean containILFFund(List<Fund> funds) {
            return Optional.ofNullable(funds).orElse(new ArrayList<>()).stream().anyMatch(fund -> PCF.equals(fund.getFundSubClass()));
    }

}
