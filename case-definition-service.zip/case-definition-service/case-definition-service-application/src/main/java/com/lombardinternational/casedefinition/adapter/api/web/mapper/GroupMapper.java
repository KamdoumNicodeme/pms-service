package com.lombardinternational.casedefinition.adapter.api.web.mapper;

import com.lombardinternational.casedefinition.model.Group;
import org.mapstruct.Mapper;

import java.util.List;

/**
 * Mapper between ${@link Group} and ${@link com.lombardinternational.casedefinition.adapter.api.web.dto.Group}
 *
 * @author qemo
 */
@Mapper(componentModel="spring",uses = {FieldMapper.class})
public interface GroupMapper {
      List<Group> groupFromDTO(List<com.lombardinternational.casedefinition.adapter.api.web.dto.Group> dtos);
      List<com.lombardinternational.casedefinition.adapter.api.web.dto.Group> groupToDTO(List<Group> groups);
}
