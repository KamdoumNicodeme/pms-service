package com.lombardinternational.casedefinition.mapper;

import java.util.List;
import java.util.stream.Collectors;

import org.mapstruct.AfterMapping;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.SubclassMapping;

import com.lombardinternational.casedefinition.model.EconomicBeneficiary;
import com.lombardinternational.casedefinition.model.MoralPerson;
import com.lombardinternational.casedefinition.model.PhysicalPerson;
import com.lombardinternational.casedefinition.model.PolicyRole;
import com.lombardinternational.clients.classapp.model.roles.AbstractPolicyRole;
import com.lombardinternational.clients.classapp.model.roles.Beneficiary;
import com.lombardinternational.clients.classapp.model.roles.CessionHolder;
import com.lombardinternational.clients.classapp.model.roles.EconomicBeneficialOwner;
import com.lombardinternational.clients.classapp.model.roles.Holder;
import com.lombardinternational.clients.classapp.model.roles.LifeAssured;
import com.lombardinternational.clients.classapp.model.roles.Proxy;
import com.lombardinternational.clients.classapp.model.roles.Settlor;
import com.lombardinternational.clients.classapp.model.roles.Trust;
import com.lombardinternational.clients.classapp.model.roles.Trustee;

@Mapper(componentModel = "spring", uses = { AbstractPersonMapper.class, CountryMapper.class })
public interface PolicyRoleMapper {

    List<PolicyRole> mapToList(List<AbstractPolicyRole> thirdPartyPolicyRoles);

    @Mapping(target = "roleId", source = "externalId")
    @SubclassMapping(source = Holder.class, target = com.lombardinternational.casedefinition.model.Holder.class)
    @SubclassMapping(source = Beneficiary.class, target = com.lombardinternational.casedefinition.model.Beneficiary.class)
    @SubclassMapping(source = Trust.class, target = com.lombardinternational.casedefinition.model.Trust.class)
    @SubclassMapping(source = Trustee.class, target = com.lombardinternational.casedefinition.model.Trustee.class)
    @SubclassMapping(source = LifeAssured.class, target = com.lombardinternational.casedefinition.model.LifeAssured.class)
    @SubclassMapping(source = EconomicBeneficialOwner.class, target = EconomicBeneficiary.class)
    @SubclassMapping(source = Settlor.class, target = com.lombardinternational.casedefinition.model.Settlor.class)
    @SubclassMapping(source = Proxy.class, target = com.lombardinternational.casedefinition.model.Proxy.class)
    @SubclassMapping(source = CessionHolder.class, target = com.lombardinternational.casedefinition.model.CessionHolder.class)
    PolicyRole mapRole(AbstractPolicyRole thirdPartyPolicyRole);

    @AfterMapping
    default void setMoralPhysicalPerson(@MappingTarget PolicyRole policyRole) {
        policyRole.setMoralPersons(policyRole.getThirdParties().stream()
                .filter(MoralPerson.class::isInstance)
                .map(MoralPerson.class::cast)
                .collect(Collectors.toList()));
        policyRole.setPhysicalPersons(policyRole.getThirdParties().stream()
                .filter(PhysicalPerson.class::isInstance)
                .map(PhysicalPerson.class::cast)
                .collect(Collectors.toList()));
    }

    @Mapping(target = "irrevocableFlag", source = "irrevocable")
    @Mapping(target = "roleId", source = "externalId")
    com.lombardinternational.casedefinition.model.Beneficiary mapTo(Beneficiary abstractPolicyRole);

    @Mapping(source = "taxCountry.externalId", target = "taxIsoCountryCode")
    @Mapping(target = "roleId", source = "externalId")
    com.lombardinternational.casedefinition.model.Holder mapTo(Holder abstractPolicyRole);
}
