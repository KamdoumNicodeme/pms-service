package com.lombardinternational.casedefinition.adapter.spi.service.rest;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lombardinternational.casedefinition.adapter.spi.service.rest.mapper.FundMapper;
import com.lombardinternational.casedefinition.domain.spi.FundWebService;
import com.lombardinternational.casedefinition.model.Fund;
import com.lombardinternational.clients.classapp.client.FundServiceClient;

@Service("restFundWebServiceImpl")
public class RestFundWebServiceImpl implements FundWebService {

    private final FundServiceClient fundServiceClient;
    private final FundMapper fundMapper;

    @Autowired
    public RestFundWebServiceImpl(FundServiceClient fundServiceClient, FundMapper fundMapper) {
        this.fundServiceClient = fundServiceClient;
        this.fundMapper = fundMapper;
    }


    @Override
    public List<Fund> getFunds(String policyNumber) throws IllegalArgumentException {
        if (policyNumber == null || policyNumber.trim().isEmpty())
            throw new IllegalArgumentException("policyNumber cannot be null or blank.");

        return fundMapper.map(fundServiceClient.getFundsByPolicyNumber(policyNumber));
    }
}
