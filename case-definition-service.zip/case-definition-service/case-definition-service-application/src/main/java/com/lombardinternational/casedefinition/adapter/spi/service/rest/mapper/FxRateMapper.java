package com.lombardinternational.casedefinition.adapter.spi.service.rest.mapper;

import com.lombardinternational.casedefinition.model.CurrencyExchangeRate;
import com.lombardinternational.clients.fxrates.model.FxRate;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;

import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

@Mapper(componentModel = "spring")
public interface FxRateMapper {

    @Mapping(source = "source", target = "provider")
    @Mapping(source = "fxRateDate", target = "rateDate", qualifiedByName = "toCalendar")
    @Mapping(source = "bareRate", target = "rate")
    @Mapping(source = "fromCcy", target = "baseIsoCurrencyCode")
    @Mapping(source = "toCcy", target = "quotedIsoCurrencyCode")
    CurrencyExchangeRate toCurrencyExchangeRate(FxRate fxRate);

    List<CurrencyExchangeRate> toCurrencyExchangeRates(List<FxRate> fxRates);

    @Named("toCalendar")
    static Calendar toCalendar(LocalDate localDate) {
        if (localDate == null) {
            return null;
        }
        ZoneId zoneId = ZoneId.systemDefault();
        Date date = Date.from(localDate.atStartOfDay(zoneId).toInstant());
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        return calendar;
    }
}
