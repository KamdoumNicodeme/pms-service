package com.lombardinternational.casedefinition.domain.spi;

import com.lombardinternational.casedefinition.model.Fund;

import java.util.List;

public interface FundWebService {

    /**
     * Get funds of a policy
     *
     * @param policyNumber
     * @return
     * @exception IllegalArgumentException
     *                policyNumber is null or blank
     */
    List<Fund> getFunds(String policyNumber) throws IllegalArgumentException;
}
