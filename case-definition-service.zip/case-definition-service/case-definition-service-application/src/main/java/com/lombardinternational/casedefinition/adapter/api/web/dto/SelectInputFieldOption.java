package com.lombardinternational.casedefinition.adapter.api.web.dto;

public class SelectInputFieldOption {

    private String key;
    private String value;

    public SelectInputFieldOption() {
    }

    public String getKey() {

        return key;
    }

    public void setKey(String key) {

        this.key = key;
    }

    public String getValue() {

        return value;
    }

    public void setValue(String value) {

        this.value = value;
    }

    @Override
    public String toString() {

        return "SelectInputFieldOption [key=" + key + ", value=" + value + "]";
    }

}
