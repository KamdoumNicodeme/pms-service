package com.lombardinternational.casedefinition.adapter.api.web.dto;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;

import io.swagger.v3.oas.annotations.media.Schema;

public class CaseControlRequest {


    @Schema(requiredMode = Schema.RequiredMode.REQUIRED)
    @NotBlank(message = "caseType is mandatory")
    protected String caseType;

    @Schema(requiredMode = Schema.RequiredMode.REQUIRED)
    @NotBlank(message = "policyNumber is mandatory")
    protected String policyNumber;

    @Schema(requiredMode = Schema.RequiredMode.REQUIRED)
    @NotBlank(message = "businessTransactionId is mandatory")
    protected String businessTransactionId;

    protected String clientNumber;

    @Schema(requiredMode = Schema.RequiredMode.REQUIRED)
    @Valid
    protected WebForm caseInitializationData;

    @Schema(requiredMode = Schema.RequiredMode.REQUIRED)
    @Valid
    protected ScreenDescription checkListOverviewData;

    public CaseControlRequest() {
    }

    public String getCaseType() {
        return caseType;
    }

    public void setCaseType(String caseType) {
        this.caseType = caseType;
    }

    public String getPolicyNumber() {
        return policyNumber;
    }

    public void setPolicyNumber(String policyNumber) {
        this.policyNumber = policyNumber;
    }

    public String getBusinessTransactionId() {
        return businessTransactionId;
    }

    public void setBusinessTransactionId(String businessTransactionId) {
        this.businessTransactionId = businessTransactionId;
    }

    public String getClientNumber() {
        return clientNumber;
    }

    public void setClientNumber(String clientNumber) {
        this.clientNumber = clientNumber;
    }

    public WebForm getCaseInitializationData() {
        return caseInitializationData;
    }

    public void setCaseInitializationData(WebForm caseInitializationData) {
        this.caseInitializationData = caseInitializationData;
    }

    public ScreenDescription getCheckListOverviewData() {
        return checkListOverviewData;
    }

    public void setCheckListOverviewData(ScreenDescription checkListOverviewData) {
        this.checkListOverviewData = checkListOverviewData;
    }

    @Override
    public String toString() {
        return "CaseControlRequest{" +
            "caseType='" + caseType + '\'' +
            ", policyNumber='" + policyNumber + '\'' +
            ", businessTransactionId='" + businessTransactionId + '\'' +
            ", clientNumber='" + clientNumber + '\'' +
            ", caseInitializationData=" + caseInitializationData +
            ", checkListOverviewData=" + checkListOverviewData +
            '}';
    }
}
