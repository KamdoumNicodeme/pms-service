package com.lombardinternational.casedefinition.adapter.api.web.exception;

import java.util.Date;

public class ErrorResource {
    private String code;
    private String message;
    private String description;
    private Date timestamp;

    public ErrorResource(String code, String message, String description, Date timestamp) {
        this.code = code;
        this.message = message;
        this.description = description;
        this.timestamp = timestamp;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Date getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(Date timestamp) {
        this.timestamp = timestamp;
    }

}