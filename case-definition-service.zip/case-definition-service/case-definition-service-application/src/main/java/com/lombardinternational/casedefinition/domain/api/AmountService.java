package com.lombardinternational.casedefinition.domain.api;

import com.lombardinternational.casedefinition.model.Amount;
import com.lombardinternational.casedefinition.model.BusinessTransaction;

public interface AmountService {

    /**
     * Convert a amount to another amount using the target currency
     * 
     * @param amount
     * @param targetCurrency
     * @return a {@link Amount}
     */
    Amount convertAmount(Amount amount, String targetCurrency);

    /**
     * sum amount in transaction in specific currency
     *
     * @param transaction
     * @param targetCurrency
     * @return a {@link Amount}
     */
    Amount getSumPaymentAmountInTransaction(BusinessTransaction transaction, String targetCurrency);
}
