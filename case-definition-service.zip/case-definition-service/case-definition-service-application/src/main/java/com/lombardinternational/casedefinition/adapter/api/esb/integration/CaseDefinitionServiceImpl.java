package com.lombardinternational.casedefinition.adapter.api.esb.integration;

import com.lombard.cdm.DocumentRequiredSignatory;
import com.lombard.csm.GetCaseControlsDefinitionRequest;
import com.lombard.csm.GetCaseControlsDefinitionRequestBusinessContext;
import com.lombard.csm.GetCaseControlsDefinitionResponse;
import com.lombard.csm.GetCaseControlsDefinitionResponseBusinessContext;
import com.lombard.csm.GetCaseDocumentsDefinitionRequest;
import com.lombard.csm.GetCaseDocumentsDefinitionRequestBusinessContext;
import com.lombard.csm.GetCaseDocumentsDefinitionResponse;
import com.lombard.csm.GetCaseDocumentsDefinitionResponseBusinessContext;
import com.lombard.csm.GetRequiredSignatoriesRequest;
import com.lombard.csm.GetRequiredSignatoriesRequestBusinessContext;
import com.lombard.csm.GetRequiredSignatoriesResponse;
import com.lombard.csm.GetRequiredSignatoriesResponseBusinessContext;
import com.lombard.csm.LoadCaseSubTasksDefinitionRequest;
import com.lombard.csm.LoadCaseSubTasksDefinitionRequestBusinessContext;
import com.lombard.csm.LoadCaseSubTasksDefinitionResponse;
import com.lombard.csm.LoadCaseSubTasksDefinitionResponseBusinessContext;
import com.lombard.csm.LoadScreenDescriptionRequest;
import com.lombard.csm.LoadScreenDescriptionRequestBusinessContext;
import com.lombard.csm.LoadScreenDescriptionResponse;
import com.lombard.csm.LoadScreenDescriptionResponseBusinessContext;
import com.lombard.csm.LoadTaskScreenDescriptionRequest;
import com.lombard.csm.LoadTaskScreenDescriptionRequestBusinessContext;
import com.lombard.csm.LoadTaskScreenDescriptionResponse;
import com.lombard.csm.LoadTaskScreenDescriptionResponseBusinessContext;
import com.lombard.integration.fwk.service.annotation.ServiceDefinition;
import com.lombard.service.CaseDefinitionService;
import com.lombardinternational.casedefinition.domain.api.CaseBusinessService;
import com.lombardinternational.casedefinition.domain.api.ScreenBusinessService;
import com.lombardinternational.casedefinition.domain.api.WebFormBusinessService;
import com.lombardinternational.casedefinition.mapper.CycleAvoidingMappingContext;
import com.lombardinternational.casedefinition.mapper.cdm.CdmMapper;
import com.lombardinternational.casedefinition.model.CaseControlDefinition;
import com.lombardinternational.casedefinition.model.CaseDocumentDefinition;
import com.lombardinternational.casedefinition.model.ScreenDescription;
import com.lombardinternational.casedefinition.model.SignatoryResult;
import com.lombardinternational.casedefinition.model.TaskDefinition;
import com.lombardinternational.casedefinition.model.WebForm;

import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;
import java.util.stream.Collectors;

@ServiceDefinition
public class CaseDefinitionServiceImpl implements CaseDefinitionService {

    private final CdmMapper mapper;
    private final ScreenBusinessService screenBusinessService;
    private final WebFormBusinessService webFormBusinessService;
    private final CaseBusinessService caseBusinessService;

    @Autowired
    public CaseDefinitionServiceImpl(CdmMapper mapper, ScreenBusinessService screenBusinessService,
        WebFormBusinessService webFormBusinessService, CaseBusinessService caseBusinessService) {
        this.mapper = mapper;
        this.screenBusinessService = screenBusinessService;
        this.webFormBusinessService = webFormBusinessService;
        this.caseBusinessService = caseBusinessService;
    }

    @Override
    public LoadTaskScreenDescriptionResponse loadTaskScreenDescription(LoadTaskScreenDescriptionRequest loadTaskScreenDescriptionRequest) {

        final LoadTaskScreenDescriptionRequestBusinessContext loadTaskScreenDescriptionRequestBusinessContext =
            loadTaskScreenDescriptionRequest.getBusinessContext();

        final com.lombard.cdm.WebForm cdmWebForm = loadTaskScreenDescriptionRequestBusinessContext.getCaseInitializationData();
        final WebForm webForm = cdmWebForm != null ? mapper.map(cdmWebForm, new CycleAvoidingMappingContext()) : null;

        final com.lombard.cdm.ScreenDescription cdmScreenChecklist = loadTaskScreenDescriptionRequestBusinessContext.getCheckListOverviewData();
        final ScreenDescription screenCheckList =
            cdmScreenChecklist != null ? mapper.map(cdmScreenChecklist, new CycleAvoidingMappingContext()) :
                null;

        final com.lombard.cdm.ScreenDescription cdmScreenToFill = loadTaskScreenDescriptionRequestBusinessContext.getScreenDescription();
        final ScreenDescription screenToFill =
            cdmScreenToFill != null ? mapper.map(cdmScreenToFill, new CycleAvoidingMappingContext()) : null;

        final ScreenDescription screenDescription = this.screenBusinessService
            .computeTaskScreen(loadTaskScreenDescriptionRequestBusinessContext.getCaseType(), webForm, screenCheckList, screenToFill);

        final LoadTaskScreenDescriptionResponse loadTaskScreenDescriptionResponse = new LoadTaskScreenDescriptionResponse();
        final LoadTaskScreenDescriptionResponseBusinessContext taskScreenDescriptionResponseBusinessContext =
            new LoadTaskScreenDescriptionResponseBusinessContext();
        taskScreenDescriptionResponseBusinessContext.setScreenDescription(mapper.map(screenDescription, new CycleAvoidingMappingContext()));
        loadTaskScreenDescriptionResponse.setBusinessContext(taskScreenDescriptionResponseBusinessContext);
        return loadTaskScreenDescriptionResponse;
    }

    @Override
    public GetRequiredSignatoriesResponse getRequiredSignatories(GetRequiredSignatoriesRequest getRequiredSignatoriesRequest) {

        final GetRequiredSignatoriesRequestBusinessContext getRequiredSignatoriesRequestBusinessContext =
            getRequiredSignatoriesRequest.getBusinessContext();

        final com.lombard.cdm.WebForm cdmWebForm = getRequiredSignatoriesRequestBusinessContext.getCaseInitializationData();
        final WebForm webForm = cdmWebForm != null ? mapper.map(cdmWebForm, new CycleAvoidingMappingContext()) : null;

        final SignatoryResult signatoryResult = this.webFormBusinessService
            .computeSignatories(getRequiredSignatoriesRequestBusinessContext.getCaseType(),
                getRequiredSignatoriesRequestBusinessContext.getPolicyNumber(), webForm);

        final GetRequiredSignatoriesResponse requiredSignatoriesResponse = buildRequiredSignatoriesResponse(signatoryResult);
        return requiredSignatoriesResponse;
    }

    @Override
    public LoadCaseSubTasksDefinitionResponse loadCaseSubTasksDefinition(LoadCaseSubTasksDefinitionRequest loadCaseSubTasksDefinitionRequest) {

        final LoadCaseSubTasksDefinitionRequestBusinessContext loadCaseSubTasksDefinitionRequestBusinessContext =
            loadCaseSubTasksDefinitionRequest.getBusinessContext();

        final com.lombard.cdm.WebForm cdmWebForm = loadCaseSubTasksDefinitionRequestBusinessContext.getCaseInitializationData();
        final WebForm webForm = cdmWebForm != null ? mapper.map(cdmWebForm, new CycleAvoidingMappingContext()) : null;

        final com.lombard.cdm.ScreenDescription cdmScreenDescription = loadCaseSubTasksDefinitionRequestBusinessContext.getCheckListOverviewData();
        final ScreenDescription screenDescription = cdmScreenDescription != null ?
            mapper.map(cdmScreenDescription, new CycleAvoidingMappingContext()) : null;

        final List<TaskDefinition> taskDefinitions = caseBusinessService
            .computeCaseSubTasks(loadCaseSubTasksDefinitionRequestBusinessContext.getPolicyNumber(),
                loadCaseSubTasksDefinitionRequestBusinessContext.getCaseType(), webForm, screenDescription);

        final List<com.lombard.cdm.TaskDefinition> cdmTaskDefinitions = taskDefinitions.stream()
                                                                                       .map(mapper::map)
                                                                                       .collect(Collectors.toList());

        final LoadCaseSubTasksDefinitionResponse tasksDefinitionResponse = new LoadCaseSubTasksDefinitionResponse();
        tasksDefinitionResponse.setBusinessContext(new LoadCaseSubTasksDefinitionResponseBusinessContext());
        tasksDefinitionResponse.getBusinessContext().getTaskDefinitions().addAll(cdmTaskDefinitions);

        return tasksDefinitionResponse;
    }

    @Override
    public GetCaseDocumentsDefinitionResponse getCaseDocumentsDefinition(GetCaseDocumentsDefinitionRequest getCaseDocumentsDefinitionRequest) {

        final GetCaseDocumentsDefinitionRequestBusinessContext getCaseDocumentsDefinitionRequestBusinessContext =
            getCaseDocumentsDefinitionRequest.getBusinessContext();

        final com.lombard.cdm.WebForm cdmWebForm = getCaseDocumentsDefinitionRequestBusinessContext.getCaseInitializationData();
        final WebForm webForm = cdmWebForm != null ? mapper.map(cdmWebForm, new CycleAvoidingMappingContext()) : null;

        final com.lombard.cdm.ScreenDescription cdmScreenDescription = getCaseDocumentsDefinitionRequestBusinessContext.getCheckListOverviewData();
        final ScreenDescription screenDescription =
            cdmScreenDescription != null ? mapper.map(cdmScreenDescription, new CycleAvoidingMappingContext()) : null;

        final List<CaseDocumentDefinition>
            caseDocumentDefinitions = caseBusinessService
            .computeCaseDocumentsDefinition(getCaseDocumentsDefinitionRequestBusinessContext.getPolicyNumber(),
                getCaseDocumentsDefinitionRequestBusinessContext.getCaseType(), webForm, screenDescription);

        final GetCaseDocumentsDefinitionResponse documentsDefinitionResponse = new GetCaseDocumentsDefinitionResponse();
        final GetCaseDocumentsDefinitionResponseBusinessContext responseBusinessContext = new GetCaseDocumentsDefinitionResponseBusinessContext();
        documentsDefinitionResponse.setBusinessContext(responseBusinessContext);

        caseDocumentDefinitions.forEach(caseDocumentDefinition -> responseBusinessContext.getCaseDocumentDefinitions()
                                                                                         .add(mapper.map(caseDocumentDefinition)));

        return documentsDefinitionResponse;
    }

    @Override
    public GetCaseControlsDefinitionResponse getCaseControlsDefinition(GetCaseControlsDefinitionRequest getCaseControlsDefinitionRequest) {

        final GetCaseControlsDefinitionRequestBusinessContext getCaseControlsDefinitionRequestBusinessContext =
            getCaseControlsDefinitionRequest.getBusinessContext();

        final com.lombard.cdm.WebForm cdmWebForm = getCaseControlsDefinitionRequestBusinessContext.getCaseInitializationData();
        final WebForm webForm = cdmWebForm != null ? mapper.map(cdmWebForm, new CycleAvoidingMappingContext()) : null;

        final com.lombard.cdm.ScreenDescription cdmScreenDescription = getCaseControlsDefinitionRequestBusinessContext.getCheckListOverviewData();
        final ScreenDescription screenDescription = cdmScreenDescription != null ?
            mapper.map(cdmScreenDescription, new CycleAvoidingMappingContext()) : null;

        final List<CaseControlDefinition>
            caseControlDefinitions = this.caseBusinessService
            .computeCaseControlDefinitions(getCaseControlsDefinitionRequestBusinessContext.getCaseType(), webForm, screenDescription);

        final GetCaseControlsDefinitionResponse caseControlsDefinitionResponse = new GetCaseControlsDefinitionResponse();
        final GetCaseControlsDefinitionResponseBusinessContext definitionResponseBusinessContext =
            new GetCaseControlsDefinitionResponseBusinessContext();
        caseControlsDefinitionResponse.setBusinessContext(definitionResponseBusinessContext);

        final List<com.lombard.cdm.CaseControlDefinition> cdmCaseControlDefinitions = caseControlDefinitions.stream()
                                                                                                            .map(
                                                                                                                mapper::map)
                                                                                                            .collect(Collectors.toList());
        definitionResponseBusinessContext.getCaseControlDefinitions().addAll(cdmCaseControlDefinitions);
        return caseControlsDefinitionResponse;
    }

    @Override
    public LoadScreenDescriptionResponse loadScreenDescription(LoadScreenDescriptionRequest loadScreenDescriptionRequest) {

        final LoadScreenDescriptionRequestBusinessContext loadScreenDescriptionRequestBusinessContext =
            loadScreenDescriptionRequest.getBusinessContext();

        final com.lombard.cdm.WebForm cdmWebForm = loadScreenDescriptionRequestBusinessContext.getCaseInitializationData();
        final WebForm webForm = cdmWebForm != null ? mapper.map(cdmWebForm, new CycleAvoidingMappingContext()) : null;

        final com.lombard.cdm.ScreenDescription cdmScreenDescriptionToBuild = loadScreenDescriptionRequestBusinessContext.getScreenDescription();
        final ScreenDescription screenDescriptionToBuild = cdmScreenDescriptionToBuild != null ?
            mapper.map(cdmScreenDescriptionToBuild, new CycleAvoidingMappingContext()) : null;

        final com.lombardinternational.casedefinition.model.ScreenDescription screenDescription = this.screenBusinessService
            .computeScreenDescription(loadScreenDescriptionRequestBusinessContext.getPolicyNumber(),
                loadScreenDescriptionRequestBusinessContext.getCaseType(),
                loadScreenDescriptionRequestBusinessContext.getBusinessTransactionNumber(), webForm, screenDescriptionToBuild);

        final LoadScreenDescriptionResponse loadScreenDescriptionResponse = new LoadScreenDescriptionResponse();
        LoadScreenDescriptionResponseBusinessContext responseBusinessContext = new LoadScreenDescriptionResponseBusinessContext();
        loadScreenDescriptionResponse.setBusinessContext(responseBusinessContext);
        responseBusinessContext.setScreenDescription(mapper.map(screenDescription, new CycleAvoidingMappingContext()));
        return loadScreenDescriptionResponse;
    }

    /**
     * Build a GetRequiredSignatoriesResponse based on the object {@link SignatoryResult}
     *
     * @param signatoryResult
     */
    private GetRequiredSignatoriesResponse buildRequiredSignatoriesResponse(final SignatoryResult signatoryResult) {

        final GetRequiredSignatoriesResponse requiredSignatoriesResponse = new GetRequiredSignatoriesResponse();
        final GetRequiredSignatoriesResponseBusinessContext responseBusinessContext = new GetRequiredSignatoriesResponseBusinessContext();
        requiredSignatoriesResponse.setBusinessContext(responseBusinessContext);
        final List<DocumentRequiredSignatory> cdmDocumentRequiredSignatories = signatoryResult.getDocumentRequiredSignatories().stream()
                                                                                              .map(mapper::map)
                                                                                              .collect(Collectors.toList());
        responseBusinessContext.getDocumentRequiredSignatories().addAll(cdmDocumentRequiredSignatories);
        responseBusinessContext.setMessage(signatoryResult.getResponseMessages().get("MESSAGE"));
        responseBusinessContext.setMessageI18N(signatoryResult.getResponseMessages().get("MESSAGE_I18N"));
        responseBusinessContext.setStatus(signatoryResult.getResponseMessages().get("STATUS"));
        return requiredSignatoriesResponse;
    }
}
