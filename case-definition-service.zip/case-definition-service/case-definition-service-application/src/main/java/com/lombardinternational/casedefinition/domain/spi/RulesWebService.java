package com.lombardinternational.casedefinition.domain.spi;

import com.lombardinternational.casedefinition.model.BusinessTransaction;
import com.lombardinternational.casedefinition.model.CaseControlDefinition;
import com.lombardinternational.casedefinition.model.CaseDeal;
import com.lombardinternational.casedefinition.model.CaseDocumentDefinition;
import com.lombardinternational.casedefinition.model.CurrencyExchangeRate;
import com.lombardinternational.casedefinition.model.Policy;
import com.lombardinternational.casedefinition.model.ScreenDescription;
import com.lombardinternational.casedefinition.model.SignatoryResult;
import com.lombardinternational.casedefinition.model.TaskDefinition;
import com.lombardinternational.casedefinition.model.WebForm;

import java.util.List;
import java.util.Map;

public interface RulesWebService {

    /**
     * Compute a screen description based on an existing screen description, a policy, a business transaction, a webform and a map of deals
     *
     * @param policy                   : the ${@link Policy}
     * @param businessTransaction      : the ${@link BusinessTransaction}
     * @param webForm                  : the ${@link WebForm}
     * @param screenDescriptionToBuild : the ${@link ScreenDescription} to build
     * @param caseDeals                : a ${@link Map<String, CaseDeal> caseDeals}
     * @param fxRates
     * @return a ${@link ScreenDescription}
     * @throws RuntimeException when an error occurred during rules application
     */
    ScreenDescription computeScreenDescription(final Policy policy, final BusinessTransaction businessTransaction, final WebForm webForm,
                                               final ScreenDescription screenDescriptionToBuild, final Map<String, CaseDeal> caseDeals, final List<CurrencyExchangeRate> fxRates);

    /**
     * Provide the list of tasks based on the policy, the webform and the screen CheckList
     *
     * @param policy: the ${@link Policy}
     * @param webForm: the ${@link WebForm}
     * @param screenCheckList: the ${@link ScreenDescription} checklist
     * @return a ${@link List<TaskDefinition>}
     * @throws RuntimeException when an error occurred during rules application
     */
    List<TaskDefinition> computeTaskDefinition(final Policy policy, final WebForm webForm, final ScreenDescription screenCheckList);

    /**
     * Get the list of documents linked to the case based on a policy, a webform and a checklist
     *
     * @param policy: the ${@link Policy}
     * @param webForm: the ${@link WebForm}
     * @param screenCheckList: the ${@link ScreenDescription} checklist
     * @return a ${@link CaseDocumentDefinition}
     * @throws RuntimeException when an error occurred during rules application
     */
    List<CaseDocumentDefinition> computeCaseDocumentsDefinition(final Policy policy, final WebForm webForm, final ScreenDescription screenCheckList);

    /**
     * Get the screen definition for task
     *
     * @param webForm: the ${@link WebForm}
     * @param screenCheckList: the ${@link ScreenDescription} checklist
     * @param screenToFill: the ${@link ScreenDescription} to fill
     * @returna a ${@link ScreenDescription}
     * @throws RuntimeException when an error occurred during rules application
     */
    ScreenDescription computeTaskScreen(final WebForm webForm, final ScreenDescription screenCheckList, final ScreenDescription screenToFill);

    /**
     * Get list of case control definitions based on the web form and the checklist
     *
     * @param webForm: the ${@link WebForm}
     * @param screenCheckList: the ${@link ScreenDescription} checklist
     * @return a ${@link List<CaseControlDefinition>}
     * @throws IllegalArgumentException web form or screen check list is null
     * @throws RuntimeException         when an error occurred during rules application
     */
    List<CaseControlDefinition> computeCaseControlDefinitions(final WebForm webForm, final ScreenDescription screenCheckList) throws IllegalArgumentException;

    /**
     * Get the list of document required signatory based on the policy and the web form
     *
     * @param policy: the ${@link Policy}
     * @param webForm: the ${@link WebForm}
     * @return a ${@link SignatoryResult}
     * @throws RuntimeException when an error occurred during rules application
     */
    SignatoryResult computeSignatories(final Policy policy, final WebForm webForm);

}
