package com.lombardinternational.casedefinition.mapper;

import java.time.LocalDate;
import java.time.Period;
import java.util.List;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.Named;
import org.springframework.beans.factory.annotation.Autowired;

import com.lombardinternational.casedefinition.domain.api.BusinessTransactionService;
import com.lombardinternational.casedefinition.domain.api.FundService;
import com.lombardinternational.casedefinition.domain.spi.PolicyWebService;
import com.lombardinternational.casedefinition.model.Block;
import com.lombardinternational.casedefinition.model.Fund;
import com.lombardinternational.casedefinition.model.Policy;
import com.lombardinternational.clients.classapp.model.Amount;
import com.lombardinternational.clients.classapp.model.PolicyValues;

@Mapper(componentModel = "spring", uses = { CountryMapper.class, BlockMapper.class, AmountMapper.class })
public abstract class PolicyMapper {

    @Autowired
    private PolicyWebService policyService;

    @Autowired
    private FundService fundService;

    @Autowired
    private BusinessTransactionService businessTransactionService;

    @Autowired
    private BlockMapper blockMapper;

    @Mapping(source = "policyNumber", target = "number")
    @Mapping(source = "businessOrigin.externalId", target = "businessOrigin")
    @Mapping(source = "currency.isoCode", target = "isoCurrencyCode")
    @Mapping(source = "countryOfLaw.externalId", target = "countryOfLawCode")
    @Mapping(source = "policyNumber", target = "blocks", qualifiedByName = "mapPolicyBlock")
    @Mapping(source = "isPledged", target = "pledged")
    @Mapping(source = "policyNumber", target = "heldILF", qualifiedByName = "mapHeldILF")
    @Mapping(source = "effectiveDate", target = "inForceforMoreThanOneYear", qualifiedByName = "inForceForMoreThanOneYear")
    @Mapping(source = "policyNumber", target = "brokerChangeWithinLast3Months", qualifiedByName = "brokerChangeWithinLast3Months")
    public abstract Policy map(com.lombardinternational.clients.classapp.model.Policy policy);

    @Named("mapPolicyBlock")
    List<Block> mapPolicyBlock(String policyNumber) {
        return blockMapper.mapToList(policyService.getBlocks(policyNumber));
    }

    @Named("mapHeldILF")
    Boolean mapHeldILF(String policyNumber) {
        List<Fund> funds = fundService.getFunds(policyNumber);
        return fundService.containILFFund(funds);
    }

    @Named("inForceForMoreThanOneYear")
    Boolean inForceForMoreThanOneYear(LocalDate effectiveDate) {
        if (effectiveDate == null) return false;
        final LocalDate currentDate = LocalDate.now();

        final int years = Period.between(effectiveDate, currentDate).getYears();
        return years > 1;
    }

    @Named("brokerChangeWithinLast3Months")
    Boolean brokerChangeWithinLast3Months(String policyNumber) {
        return businessTransactionService.hasMadeChangeOfBroker(policyNumber);
    }

    @Mapping(source = "actuarialValue", target = "navInPolicyCurrency")
    @Mapping(source = "policyValues", target = "navInEurCurrency", qualifiedByName = "navInEurCurrency")
    @Mapping(source = "surrenderLiquidValue", target = "surrenderLiquidValue")
    public abstract void updatePolicyValues(PolicyValues policyValues, @MappingTarget Policy policy);

    @Named("navInEurCurrency")
    Amount navInEurCurrency(PolicyValues policyValues) {
        if (policyValues.getActuarialValueInEur() == null) return policyValues.getActuarialValue();
        return policyValues.getActuarialValueInEur();
    }
}
