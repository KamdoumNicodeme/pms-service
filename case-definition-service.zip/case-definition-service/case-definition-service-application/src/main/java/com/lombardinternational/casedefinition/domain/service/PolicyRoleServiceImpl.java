package com.lombardinternational.casedefinition.domain.service;

import java.util.Collection;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.function.Supplier;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.stereotype.Service;

import com.lombardinternational.casedefinition.domain.api.PolicyRoleService;
import com.lombardinternational.casedefinition.model.AbstractPerson;
import com.lombardinternational.casedefinition.model.PolicyRole;

@Service
public class PolicyRoleServiceImpl implements PolicyRoleService {

    @Override
    public Boolean policyRoleAreDifferent(final List<? extends PolicyRole> policyRolesA, final List<? extends PolicyRole> policyRolesB) {
        final Supplier<Stream<? extends PolicyRole>> streamRoleA = () -> Optional.ofNullable(policyRolesA).map(Collection::stream).orElseGet(Stream::empty);
        final Supplier<Stream<? extends PolicyRole>> streamRoleB = () -> Optional.ofNullable(policyRolesB).map(Collection::stream).orElseGet(Stream::empty);

        final List<String> roleAIds = Stream.concat(
                        streamRoleA.get().map(PolicyRole::getMoralPersons).filter(Objects::nonNull),
                        streamRoleA.get().map(PolicyRole::getPhysicalPersons).filter(Objects::nonNull))
                .flatMap(Collection::stream)
                .map(AbstractPerson::getThirdPartyId)
                .collect(Collectors.toList());

        final List<String> roleBIds = Stream.concat(
                        streamRoleB.get().map(PolicyRole::getMoralPersons).filter(Objects::nonNull),
                        streamRoleB.get().map(PolicyRole::getPhysicalPersons).filter(Objects::nonNull))
                .flatMap(Collection::stream)
                .map(AbstractPerson::getThirdPartyId)
                .collect(Collectors.toList());

        roleBIds.removeAll(roleAIds);
        return CollectionUtils.isNotEmpty(roleBIds);
    }


}
