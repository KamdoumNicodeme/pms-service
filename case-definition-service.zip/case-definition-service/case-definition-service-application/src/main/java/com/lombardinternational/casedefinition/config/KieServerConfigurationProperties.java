package com.lombardinternational.casedefinition.config;

import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties(prefix = "kieserver")
public class KieServerConfigurationProperties {

    private String serverUrl;
    private String userName;
    private String password;
    private Map<String,String> container;
    private String session;
    private Set<Class<?>> extraClasses = new HashSet<Class<?>>();

    /**
     * @return the serverUrl
     */
    public String getServerUrl() {

        return serverUrl;
    }

    /**
     * @return the userName
     */
    public String getUserName() {

        return userName;
    }

    /**
     * @return the password
     */
    public String getPassword() {

        return password;
    }

    /**
     * @return the container
     */
    public Map<String,String> getContainer() {

        return container;
    }

    /**
     * @return the session
     */
    public String getSession() {

        return session;
    }

    /**
     * @return the extraClasses
     */
    public Set<Class<?>> getExtraClasses() {

        return extraClasses;
    }

    /**
     * @param serverUrl
     *            the serverUrl to set
     */
    public void setServerUrl(String serverUrl) {

        this.serverUrl = serverUrl;
    }

    /**
     * @param userName
     *            the userName to set
     */
    public void setUserName(String userName) {

        this.userName = userName;
    }

    /**
     * @param password
     *            the password to set
     */
    public void setPassword(String password) {

        this.password = password;
    }

    /**
     * @param container
     *            the container to set
     */
    public void setContainer(Map<String,String> container) {

        this.container = container;
    }

    /**
     * @param session
     *            the session to set
     */
    public void setSession(String session) {

        this.session = session;
    }

    /**
     * @param extraClasses
     *            the extraClasses to set
     */
    public void setExtraClasses(Set<Class<?>> extraClasses) {

        this.extraClasses = extraClasses;
    }

}
