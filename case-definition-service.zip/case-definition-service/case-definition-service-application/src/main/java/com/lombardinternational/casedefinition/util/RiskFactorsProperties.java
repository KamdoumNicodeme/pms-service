package com.lombardinternational.casedefinition.util;


import lombok.Data;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import javax.annotation.PostConstruct;
import java.util.*;
import java.util.stream.Collectors;

@Data
@Configuration
@ConfigurationProperties(prefix = "risk-factors-ids")
public class RiskFactorsProperties {
    private static final Logger logger = LoggerFactory.getLogger(RiskFactorsProperties.class);

    private Map<String, List<String>> factors = new HashMap<>();

    @Data
    public static class Factors {
        private List<String> ids;
    }

    @PostConstruct
    public void flattenMap() {
        factors.entrySet().forEach(entry -> {
            List<String> ids = entry.getValue().stream()
                    .map(id -> Arrays.stream(id.split(","))
                            .collect(Collectors.toList()))
                    .flatMap(Collection::stream)
                    .map(String::trim)
                    .collect(Collectors.toList());
            entry.setValue(ids);
        });
    }
}