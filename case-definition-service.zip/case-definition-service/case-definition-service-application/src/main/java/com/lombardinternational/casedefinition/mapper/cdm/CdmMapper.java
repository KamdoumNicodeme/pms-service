package com.lombardinternational.casedefinition.mapper.cdm;

import com.lombardinternational.casedefinition.mapper.CycleAvoidingMappingContext;
import com.lombardinternational.casedefinition.model.*;
import org.mapstruct.Context;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring", uses = { CdmWebFormMapper.class, CdmScreenDescriptionMapper.class, CdmDocumentRequiredSignatoryMapper.class})
public interface CdmMapper {

    WebForm map(com.lombard.cdm.WebForm cdmWebForm, @Context CycleAvoidingMappingContext context);
    ScreenDescription map(com.lombard.cdm.ScreenDescription cdmScreenDescription, @Context CycleAvoidingMappingContext context);

    com.lombard.cdm.ScreenDescription map(ScreenDescription screenDescription, @Context CycleAvoidingMappingContext context);
    com.lombard.cdm.TaskDefinition map(TaskDefinition taskDefinition);
    com.lombard.cdm.CaseControlDefinition map(CaseControlDefinition caseControlDefinition);
    com.lombard.cdm.CaseDocumentDefinition map(CaseDocumentDefinition CaseDocumentDefinition);
    com.lombard.cdm.DocumentRequiredSignatory map(DocumentRequiredSignatory DocumentRequiredSignatory);

}
