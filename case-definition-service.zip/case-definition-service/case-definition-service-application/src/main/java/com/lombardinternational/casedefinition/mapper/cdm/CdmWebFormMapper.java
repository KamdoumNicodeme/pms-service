package com.lombardinternational.casedefinition.mapper.cdm;

import com.lombardinternational.casedefinition.adapter.api.web.dto.UserDetail;
import com.lombardinternational.casedefinition.mapper.CycleAvoidingMappingContext;
import com.lombardinternational.casedefinition.model.*;
import java.util.List;
import org.mapstruct.Context;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring")
public interface CdmWebFormMapper {

    UserDetail map(com.lombard.cdm.UserDetail cdm);
    CompanyDetail map(com.lombard.cdm.CompanyDetail cdm);
    WebFormGroup map(com.lombard.cdm.WebFormGroup cdm, @Context CycleAvoidingMappingContext context);
    BigDecimalWebFormField map(com.lombard.cdm.BigDecimalWebFormField cdm);
    TextWebFormField map(com.lombard.cdm.TextWebFormField cdm);
    CalendarWebFormField map(com.lombard.cdm.CalendarWebFormField cdm);

    @Mapping(target = "value", expression = "java(field.isValue())")
    BooleanWebFormField map (com.lombard.cdm.BooleanWebFormField field);
    @Mapping(target = "value", expression = "java(field.getValue())")
    com.lombard.cdm.BooleanWebFormField map (BooleanWebFormField field);

    List<BigDecimalWebFormField> mapBigDecimal(List<com.lombard.cdm.BigDecimalWebFormField> cdm);
    List<BooleanWebFormField> mapBoolean(List<com.lombard.cdm.BooleanWebFormField> cdm);
    List<TextWebFormField> mapText(List<com.lombard.cdm.TextWebFormField> cdm);
    List<CalendarWebFormField> mapCalendar(List<com.lombard.cdm.CalendarWebFormField> cdm);
    List<WebFormGroup> mapGroup(List<com.lombard.cdm.WebFormGroup> cdm);

}
