package com.lombardinternational.casedefinition.adapter.api.web.mapper;

import com.lombardinternational.casedefinition.model.TextAreaField;
import org.mapstruct.Mapper;

import java.util.List;

/**
 * Mapper between ${@link TextAreaFieldMapper} and ${@link com.lombardinternational.casedefinition.adapter.api.web.dto.TextAreaField}
 *
 * @author qemo
 */
@Mapper(componentModel="spring")
public interface TextAreaFieldMapper {
    List<TextAreaField> textAreaFieldFromDTO(List<com.lombardinternational.casedefinition.adapter.api.web.dto.TextAreaField> dtos);
}
