package com.lombardinternational.casedefinition.adapter.api.web.mapper;

import com.lombardinternational.casedefinition.model.CompanyDetail;
import org.mapstruct.Mapper;

/**
 * Mapper between ${@link CompanyDetail} and ${@link com.lombardinternational.casedefinition.adapter.api.web.dto.CompanyDetail}
 *
 * @author qemo
 */
@Mapper(componentModel="spring")
public interface CompanyDetailMapper {

    CompanyDetail companyDetailFromDTO(com.lombardinternational.casedefinition.adapter.api.web.dto.CompanyDetail companyDetailDTO);
}
