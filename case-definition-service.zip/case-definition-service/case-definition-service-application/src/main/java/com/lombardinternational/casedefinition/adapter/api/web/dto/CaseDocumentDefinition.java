package com.lombardinternational.casedefinition.adapter.api.web.dto;

public class CaseDocumentDefinition {

    private String documentType;
    private String documentRelatedTo;
    private String i18NDocumentRelatedTo;
    private String i18NDocumentRelatedToParam;
    private String relatedToPolicyNumber;
    private String relatedToThirdpartyId;
    private boolean documentRequired;
    private boolean documentVisibleOnConnect;
    private String copyBusinessKey;
    private String originalBusinessKey;
    private String exceptionBusinessKey;
    private int documentOrder;
    private String description;
    private String i18NDescription;
    private String documentSharepointId;
    private String cmsDocumentType;
    private boolean neverDisplayExternally;

    public CaseDocumentDefinition() {
    }

    public String getDocumentType() {

        return documentType;
    }

    public void setDocumentType(String documentType) {

        this.documentType = documentType;
    }

    public String getDocumentRelatedTo() {

        return documentRelatedTo;
    }

    public void setDocumentRelatedTo(String documentRelatedTo) {

        this.documentRelatedTo = documentRelatedTo;
    }

    public boolean isDocumentRequired() {

        return documentRequired;
    }

    public void setDocumentRequired(boolean documentRequired) {

        this.documentRequired = documentRequired;
    }

    public boolean isDocumentVisibleOnConnect() {

        return documentVisibleOnConnect;
    }

    public void setDocumentVisibleOnConnect(boolean documentVisibleOnConnect) {

        this.documentVisibleOnConnect = documentVisibleOnConnect;
    }

    public String getCopyBusinessKey() {

        return copyBusinessKey;
    }

    public void setCopyBusinessKey(String copyBusinessKey) {

        this.copyBusinessKey = copyBusinessKey;
    }

    public String getOriginalBusinessKey() {

        return originalBusinessKey;
    }

    public void setOriginalBusinessKey(String originalBusinessKey) {

        this.originalBusinessKey = originalBusinessKey;
    }

    public String getExceptionBusinessKey() {

        return exceptionBusinessKey;
    }

    public void setExceptionBusinessKey(String exceptionBusinessKey) {

        this.exceptionBusinessKey = exceptionBusinessKey;
    }

    public int getDocumentOrder() {

        return documentOrder;
    }

    public void setDocumentOrder(int documentOrder) {

        this.documentOrder = documentOrder;
    }

    public String getRelatedToPolicyNumber() {

        return relatedToPolicyNumber;
    }

    public void setRelatedToPolicyNumber(String relatedToPolicyNumber) {

        this.relatedToPolicyNumber = relatedToPolicyNumber;
    }

    public String getRelatedToThirdpartyId() {

        return relatedToThirdpartyId;
    }

    public void setRelatedToThirdpartyId(String relatedToThirdpartyId) {

        this.relatedToThirdpartyId = relatedToThirdpartyId;
    }

    public String getDescription() {

        return description;
    }

    public void setDescription(String description) {

        this.description = description;
    }

    public String getDocumentSharepointId() {

        return documentSharepointId;
    }

    public void setDocumentSharepointId(String documentSharepointId) {

        this.documentSharepointId = documentSharepointId;
    }

    public String getCmsDocumentType() {

        return cmsDocumentType;
    }

    public void setCmsDocumentType(String cmsDocumentType) {

        this.cmsDocumentType = cmsDocumentType;
    }

    public String getI18NDocumentRelatedTo() {

        return i18NDocumentRelatedTo;
    }

    public void setI18NDocumentRelatedTo(String i18NDocumentRelatedTo) {

        this.i18NDocumentRelatedTo = i18NDocumentRelatedTo;
    }

    public String getI18NDocumentRelatedToParam() {

        return i18NDocumentRelatedToParam;
    }

    public void setI18NDocumentRelatedToParam(String i18NDocumentRelatedToParam) {

        this.i18NDocumentRelatedToParam = i18NDocumentRelatedToParam;
    }

    public String getI18NDescription() {

        return i18NDescription;
    }

    public void setI18NDescription(String i18NDescription) {

        this.i18NDescription = i18NDescription;
    }

    public boolean getNeverDisplayExternally() {

        return neverDisplayExternally;
    }

    public void setNeverDisplayExternally(boolean neverDisplayExternally) {

        this.neverDisplayExternally = neverDisplayExternally;
    }

    @Override
    public String toString() {

        return "CaseDocumentDefinition [documentType=" + documentType + ", documentRelatedTo=" + documentRelatedTo + ", i18NDocumentRelatedTo="
                + i18NDocumentRelatedTo + ", i18NDocumentRelatedToParam=" + i18NDocumentRelatedToParam + ", relatedToPolicyNumber="
                + relatedToPolicyNumber + ", relatedToThirdpartyId=" + relatedToThirdpartyId + ", documentRequired=" + documentRequired
                + ", documentVisibleOnConnect=" + documentVisibleOnConnect + ", copyBusinessKey=" + copyBusinessKey + ", originalBusinessKey="
                + originalBusinessKey + ", exceptionBusinessKey=" + exceptionBusinessKey + ", documentOrder=" + documentOrder + ", description="
                + description + ", i18NDescription=" + i18NDescription + ", documentSharepointId=" + documentSharepointId + ", cmsDocumentType="
                + cmsDocumentType + ", neverDisplayExternally=" + neverDisplayExternally + "]";
    }

}
