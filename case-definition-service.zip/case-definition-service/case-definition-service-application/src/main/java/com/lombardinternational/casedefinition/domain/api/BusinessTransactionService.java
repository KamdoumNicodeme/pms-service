package com.lombardinternational.casedefinition.domain.api;

import com.lombardinternational.casedefinition.model.BusinessTransaction;
import com.lombardinternational.casedefinition.model.Policy;

public interface BusinessTransactionService {

    /**
     * Check if the broker has change within the last 3 months
     *
     * @param policyNumber
     * @return a {@link Boolean}
     */
    Boolean hasMadeChangeOfBroker(String policyNumber);

    BusinessTransaction buildBusinessTransaction(String businessTransactionNumber, Policy policy, String caseType, String policyNumber);

}
