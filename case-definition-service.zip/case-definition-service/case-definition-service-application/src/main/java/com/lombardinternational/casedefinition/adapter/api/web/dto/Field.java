package com.lombardinternational.casedefinition.adapter.api.web.dto;

import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.fasterxml.jackson.annotation.JsonTypeInfo;

@JsonTypeInfo(
    use = JsonTypeInfo.Id.NAME,
    property = "type")
@JsonSubTypes({
                  @JsonSubTypes.Type(value = LabelField.class, name = "labelField"),
                  @JsonSubTypes.Type(value = TextInputField.class, name = "textInputField"),
                  @JsonSubTypes.Type(value = NumberInputField.class, name = "numberInputField"),
                  @JsonSubTypes.Type(value = SelectInputField.class, name = "selectInputField"),
                  @JsonSubTypes.Type(value = TextAreaField.class, name = "textAreaField"),
                  @JsonSubTypes.Type(value = CheckBoxField.class, name = "checkBoxField"),
              })
public abstract class Field {


    protected String fieldId;
    protected String label;

    protected String i18NLabelKey;
    protected int order;
    protected boolean enabled;
    protected boolean mandatory;
    protected Boolean multiple;
    protected Integer maxMultiple;
    protected String selectedValue;
    protected String displayIf;
    protected String enableIf;
    protected Boolean labelBold;
    protected String sourceSystem;

    public Field() {
    }

    public String getFieldId() {
        return fieldId;
    }

    public void setFieldId(String fieldId) {
        this.fieldId = fieldId;
    }

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public String getI18NLabelKey() {
        return i18NLabelKey;
    }

    public void setI18NLabelKey(String i18NLabelKey) {
        this.i18NLabelKey = i18NLabelKey;
    }

    public int getOrder() {
        return order;
    }

    public void setOrder(int order) {
        this.order = order;
    }

    public boolean isEnabled() {
        return enabled;
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }

    public boolean isMandatory() {
        return mandatory;
    }

    public void setMandatory(boolean mandatory) {
        this.mandatory = mandatory;
    }

    public Boolean getMultiple() {
        return multiple;
    }

    public void setMultiple(Boolean multiple) {
        this.multiple = multiple;
    }

    public Integer getMaxMultiple() {
        return maxMultiple;
    }

    public void setMaxMultiple(Integer maxMultiple) {
        this.maxMultiple = maxMultiple;
    }

    public String getSelectedValue() {
        return selectedValue;
    }

    public void setSelectedValue(String selectedValue) {
        this.selectedValue = selectedValue;
    }

    public String getDisplayIf() {
        return displayIf;
    }

    public void setDisplayIf(String displayIf) {
        this.displayIf = displayIf;
    }

    public String getEnableIf() {
        return enableIf;
    }

    public void setEnableIf(String enableIf) {
        this.enableIf = enableIf;
    }

    public Boolean getLabelBold() {
        return labelBold;
    }

    public void setLabelBold(Boolean labelBold) {
        this.labelBold = labelBold;
    }

    public String getSourceSystem() {
        return sourceSystem;
    }

    public void setSourceSystem(String sourceSystem) {
        this.sourceSystem = sourceSystem;
    }

    @Override
    public String toString() {
        return "Field{" +
            "fieldId='" + fieldId + '\'' +
            ", label='" + label + '\'' +
            ", i18NLabelKey='" + i18NLabelKey + '\'' +
            ", order=" + order +
            ", enabled=" + enabled +
            ", mandatory=" + mandatory +
            ", multiple=" + multiple +
            ", maxMultiple=" + maxMultiple +
            ", selectedValue='" + selectedValue + '\'' +
            ", displayIf='" + displayIf + '\'' +
            ", enableIf='" + enableIf + '\'' +
            ", labelBold=" + labelBold +
            ", sourceSystem='" + sourceSystem + '\'' +
            '}';
    }
}
