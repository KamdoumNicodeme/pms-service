package com.lombardinternational.casedefinition.domain.service;

import com.lombardinternational.casedefinition.domain.api.BusinessTransactionService;
import com.lombardinternational.casedefinition.domain.api.PolicyService;
import com.lombardinternational.casedefinition.domain.api.ScreenBusinessService;
import com.lombardinternational.casedefinition.domain.spi.DealWebService;
import com.lombardinternational.casedefinition.domain.spi.FxRateWebService;
import com.lombardinternational.casedefinition.domain.spi.RulesWebService;
import com.lombardinternational.casedefinition.model.*;

import lombok.AllArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;


/**
 * ${@link ScreenDescription} Business Service
 *
 * @author qemo
 */
@Service
@AllArgsConstructor
public class ScreenBusinessServiceImpl implements ScreenBusinessService {

    private static final Logger logger = LoggerFactory.getLogger(ScreenBusinessServiceImpl.class);

    /**
     * Change of Investment Manager and Custodian Bank cases type.
     */
    private static final List<String> CIM_CCB_CASES_TYPE = Collections.unmodifiableList(Arrays.asList("CIM", "CCB", "CIM_CCB"));

    /**
     * EURO ISO code
     */
    private static final String EUR_ISO_CODE_CURRENCY = "EUR";


    /**
     * Required services
     */
    private final DealWebService restDealWebServiceImpl;
    private final PolicyService policyService;
    private final BusinessTransactionService businessTransactionService;
    private final RulesWebService rulesWebService;
    private final FxRateWebService fxRateWebService;

    /**
     * see {@inheritDoc}
     */
    @Override
    public ScreenDescription computeScreenDescription(String policyNumber, String caseType, String businessTransactionNumber, WebForm webForm,
                                                      ScreenDescription screenDescriptionToBuild) {
        Policy policy = null;
        BusinessTransaction businessTransaction = null;

        if (StringUtils.isNotBlank(policyNumber) && !CIM_CCB_CASES_TYPE.contains(caseType)) {
            logger.info("Start calling webservices : Policy and Policy Client");

            if (StringUtils.isNotBlank(policyNumber)) {
                policy = policyService.buildPolicy(policyNumber);
            }

            if (StringUtils.isNotBlank(businessTransactionNumber)) {
                businessTransaction = businessTransactionService.buildBusinessTransaction(businessTransactionNumber, policy, caseType, policyNumber);
            }
            logger.info("Webservices call ending with success");
        }
        List<CurrencyExchangeRate> fxRates = fxRateWebService.getFxRate(EUR_ISO_CODE_CURRENCY, null)
                .stream()
                .filter(rate -> EUR_ISO_CODE_CURRENCY.equals(rate.getBaseIsoCurrencyCode()))
                .collect(Collectors.toList());

        return this.rulesWebService.computeScreenDescription(policy, businessTransaction, webForm,
                screenDescriptionToBuild, webForm != null ? this.getCaseDeals(webForm) : null, fxRates);
    }

    /**
     * see {@inheritDoc}
     */
    @Override
    public ScreenDescription computeTaskScreen(String caseType, WebForm webForm, ScreenDescription screenCheckList,
                                               ScreenDescription screenToFill) {
        // Setup webform based on caseType
        final WebForm validateWebForm = CIM_CCB_CASES_TYPE.contains(caseType) ? null : webForm;

        return this.rulesWebService.computeTaskScreen(validateWebForm, screenCheckList, screenToFill);
    }

    /**
     * Get case deals based on the given webform.
     *
     * @param webForm Webform
     * @return Case deals
     */
    private Map<String, CaseDeal> getCaseDeals(final com.lombardinternational.casedefinition.model.WebForm webForm) {

        try {
            final TextWebFormField caseIdField = webForm.getGroups().stream()
                    .flatMap(wfg -> wfg.flattened()
                            .map(tf -> tf.getTextFields()).flatMap(tfs -> tfs.stream())).filter(t -> "CASE_ID".equals(t.getFieldId())).findFirst().orElse(null);
            final Map<String, CaseDeal> caseDealMap = new HashMap<>();
            if (caseIdField != null) {
                final List<CaseDeal> caseDealList = restDealWebServiceImpl.getCaseDeals(caseIdField.getValue());

                caseDealList.forEach(caseDeal -> caseDealMap.put(caseDeal.getCaseDealId(), caseDeal));
            }
            return caseDealMap;
        } catch (NoSuchElementException e) {
            logger.error(e.getMessage(), e);
            return null;
        }
    }
}
