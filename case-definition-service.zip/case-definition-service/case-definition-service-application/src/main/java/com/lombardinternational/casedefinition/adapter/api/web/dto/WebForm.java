package com.lombardinternational.casedefinition.adapter.api.web.dto;


import java.util.ArrayList;
import java.util.List;

import javax.validation.constraints.NotBlank;

public class WebForm {

    private UserDetail userDetail;

    private CompanyDetail companyDetail;

    private FormInitiator formInitiator;

    @NotBlank(message = "webFormId is mandatory")
    private String webFormId;

    private String webFormWorkFlow;

    private List<WebFormGroup> groups = new ArrayList<>();

    public UserDetail getUserDetail() {
        return userDetail;
    }

    public void setUserDetail(UserDetail userDetail) {
        this.userDetail = userDetail;
    }

    public CompanyDetail getCompanyDetail() {
        return companyDetail;
    }

    public void setCompanyDetail(CompanyDetail companyDetail) {
        this.companyDetail = companyDetail;
    }

    public FormInitiator getFormInitiator() {
        return formInitiator;
    }

    public void setFormInitiator(final FormInitiator formInitiator) {
        this.formInitiator = formInitiator;
    }

    public String getWebFormId() {
        return webFormId;
    }

    public void setWebFormId(String webFormId) {
        this.webFormId = webFormId;
    }

    public String getWebFormWorkFlow() {
        return webFormWorkFlow;
    }

    public void setWebFormWorkFlow(String webFormWorkFlow) {
        this.webFormWorkFlow = webFormWorkFlow;
    }

    public List<WebFormGroup> getGroups() {
        return groups;
    }

    public void setGroups(List<WebFormGroup> groups) {
        this.groups = groups;
    }

    @Override
    public String toString() {
        return "WebForm{" +
                "userDetail=" + userDetail +
                ", companyDetail=" + companyDetail +
                ", formInitiator=" + formInitiator +
                ", webFormId='" + webFormId + '\'' +
                ", webFormWorkFlow='" + webFormWorkFlow + '\'' +
                ", groups=" + groups +
                '}';
    }
}
