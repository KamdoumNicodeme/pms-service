package com.lombardinternational.casedefinition.adapter.api.web.dto;


import javax.validation.Valid;
import javax.validation.constraints.NotBlank;

public class CaseSubTaskRequest {

    @NotBlank(message = "caseType is mandatory")
    protected String caseType;


    @NotBlank(message = "policyNumber is mandatory")
    protected String policyNumber;


    @NotBlank(message = "businessTransactionNumber is mandatory")
    protected String businessTransactionNumber;

    protected String clientNumber;


    @Valid
    protected WebForm caseInitializationData;


    @Valid
    protected ScreenDescription checkListOverviewData;

    public CaseSubTaskRequest() {
    }

    public String getCaseType() {
        return caseType;
    }

    public void setCaseType(String caseType) {
        this.caseType = caseType;
    }

    public String getPolicyNumber() {
        return policyNumber;
    }

    public void setPolicyNumber(String policyNumber) {
        this.policyNumber = policyNumber;
    }

    public String getBusinessTransactionNumber() {
        return businessTransactionNumber;
    }

    public void setBusinessTransactionNumber(String businessTransactionNumber) {
        this.businessTransactionNumber = businessTransactionNumber;
    }

    public String getClientNumber() {
        return clientNumber;
    }

    public void setClientNumber(String clientNumber) {
        this.clientNumber = clientNumber;
    }

    public WebForm getCaseInitializationData() {
        return caseInitializationData;
    }

    public void setCaseInitializationData(WebForm caseInitializationData) {
        this.caseInitializationData = caseInitializationData;
    }

    public ScreenDescription getCheckListOverviewData() {
        return checkListOverviewData;
    }

    public void setCheckListOverviewData(ScreenDescription checkListOverviewData) {
        this.checkListOverviewData = checkListOverviewData;
    }

    @Override
    public String toString() {
        return "CaseSubTaskRequest{" +
            "caseType='" + caseType + '\'' +
            ", policyNumber='" + policyNumber + '\'' +
            ", businessTransactionNumber='" + businessTransactionNumber + '\'' +
            ", clientNumber='" + clientNumber + '\'' +
            ", caseInitializationData=" + caseInitializationData +
            ", checkListOverviewData=" + checkListOverviewData +
            '}';
    }
}
