package com.lombardinternational.casedefinition.domain.api;

import com.lombardinternational.casedefinition.model.CaseControlDefinition;
import com.lombardinternational.casedefinition.model.CaseDocumentDefinition;
import com.lombardinternational.casedefinition.model.ScreenDescription;
import com.lombardinternational.casedefinition.model.TaskDefinition;
import com.lombardinternational.casedefinition.model.WebForm;

import java.util.List;

public interface CaseBusinessService {


    /**
     * Get the list of {@link CaseDocumentDefinition} based on a policy number, a case type, a {@link WebForm}, and a {@link ScreenDescription}
     *
     * @param policyNumber: the policy number
     * @param caseType: the case type
     * @param webForm: a {@link WebForm}
     * @param screenCheckList: a {@link ScreenDescription}
     * @return a {@link List<CaseDocumentDefinition>}
     */
    List<CaseDocumentDefinition> computeCaseDocumentsDefinition(String policyNumber, String caseType, WebForm webForm,
        ScreenDescription screenCheckList);

    /**
     * Get list of {@link CaseControlDefinition} based on a case type, a {@link WebForm}, and a {@link ScreenDescription}
     *
     *
     * @param caseType: the case type
     * @param webForm: a {@link WebForm}
     * @param screenCheckList: a {@link ScreenDescription}
     * @return a {@link List<CaseControlDefinition>}
     * @exception
     * IllegalArgumentException
     *                web form or screen check list is null
     */
    List<CaseControlDefinition> computeCaseControlDefinitions(String caseType, WebForm webForm, ScreenDescription screenCheckList);

    /**
     *  Get the list of {@link TaskDefinition} based on a policy number, a case type, a {@link WebForm}, and a {@link ScreenDescription}
     *
     * @param policyNumber: the policy number
     * @param caseType: the case type
     * @param webForm: a {@link WebForm}
     * @param screenCheckList: a {@link ScreenDescription}
     * @return a {@link List<TaskDefinition>}
     */
    List<TaskDefinition> computeCaseSubTasks(String policyNumber, String caseType, WebForm webForm, ScreenDescription screenCheckList);
}
