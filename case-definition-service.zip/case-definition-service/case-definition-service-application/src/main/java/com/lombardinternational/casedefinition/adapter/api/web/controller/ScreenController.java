package com.lombardinternational.casedefinition.adapter.api.web.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.lombardinternational.casedefinition.adapter.api.web.dto.ScreenDescription;
import com.lombardinternational.casedefinition.adapter.api.web.dto.ScreenDescriptionRequest;
import com.lombardinternational.casedefinition.adapter.api.web.mapper.ScreenDescriptionMapper;
import com.lombardinternational.casedefinition.adapter.api.web.mapper.WebFormMapper;
import com.lombardinternational.casedefinition.domain.api.ScreenBusinessService;
import com.lombardinternational.casedefinition.model.WebForm;
import com.lombardinternational.utils.servicelogger.milestones.domain.LogMilestone;
import com.lombardinternational.utils.servicelogger.milestones.domain.LoggableValue;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;

/**
 * Screen Rest Controller
 *
 * @author qemo
 */
@Tag(name = "Screens", description = "Screens management")
@RestController
@RequestMapping("/api/screens")
@LogMilestone(category = "rest", domain = "case-definition")
public class ScreenController {

    private final ScreenBusinessService screenBusinessService;
    private final WebFormMapper webFormMapper;
    private final ScreenDescriptionMapper screenDescriptionMapper;

    @Autowired
    public ScreenController(ScreenBusinessService screenBusinessService,
                            WebFormMapper webFormMapper,
                            ScreenDescriptionMapper screenDescriptionMapper) {
        this.screenBusinessService = screenBusinessService;
        this.webFormMapper = webFormMapper;
        this.screenDescriptionMapper = screenDescriptionMapper;
    }

    @PostMapping("description")
    @Operation(summary = "Generate a ScreenDescription based on a ScreenDescriptionRequest")
    @LogMilestone(action = "get screen description")
    public ResponseEntity<ScreenDescription> getScreenDescription(@LoggableValue({"caseType", "policyNumber", "businessTransactionNumber", "clientNumber"}) @Valid @RequestBody ScreenDescriptionRequest screenDescriptionRequest) {
        // WebForm mapping to model object
        final WebForm webForm = this.webFormMapper.webFormFromDTO(screenDescriptionRequest.getCaseInitializationData());

        // ScreenDescriptionToBuild mapping to model object
        final com.lombardinternational.casedefinition.model.ScreenDescription screenDescriptionToBuild =
                this.screenDescriptionMapper.screenDescriptionFromDTO(screenDescriptionRequest.getScreenDescription());

        final com.lombardinternational.casedefinition.model.ScreenDescription screenDescription = this.screenBusinessService
                .computeScreenDescription(screenDescriptionRequest.getPolicyNumber(), screenDescriptionRequest.getCaseType(),
                        screenDescriptionRequest.getBusinessTransactionNumber(), webForm, screenDescriptionToBuild);

        return ResponseEntity.ok(screenDescriptionMapper.DTOFromScreenDescription(screenDescription));
    }

    @PostMapping("task")
    @Operation(summary = "Generate sub-task screen based on a ScreenDescriptionRequest")
    @LogMilestone(action = "get task screen description")
    public ResponseEntity<ScreenDescription> getTaskScreenDescription(@LoggableValue({"caseType", "policyNumber", "businessTransactionNumber", "clientNumber"}) @Valid @RequestBody ScreenDescriptionRequest screenDescriptionRequest) {
        // WebForm mapping to model object
        final WebForm webForm = this.webFormMapper.webFormFromDTO(screenDescriptionRequest.getCaseInitializationData());

        // ScreenCheckList mapping to model object
        final com.lombardinternational.casedefinition.model.ScreenDescription screenCheckList =
                this.screenDescriptionMapper.screenDescriptionFromDTO(screenDescriptionRequest.getScreenCheckList());

        // ScreenToFill mapping to model object
        final com.lombardinternational.casedefinition.model.ScreenDescription screenToFill =
                this.screenDescriptionMapper.screenDescriptionFromDTO(screenDescriptionRequest.getScreenDescription());

        final com.lombardinternational.casedefinition.model.ScreenDescription screenDescription = this.screenBusinessService
                .computeTaskScreen(screenDescriptionRequest.getCaseType(), webForm, screenCheckList, screenToFill);

        return ResponseEntity.ok(screenDescriptionMapper.DTOFromScreenDescription(screenDescription));
    }
}
