package com.lombardinternational.casedefinition.adapter.api.web.dto;

import java.util.List;

public class RequiredSignatory {

    private String thirdpartyId;
    private String type;
    private String firstName;
    private String lastName;
    private String email;
    private String phoneNumber;
    private String label;
    private String signerId;
    private List<String> allowedActions;
    private String onBehalfOf;

    public RequiredSignatory() {
    }

    public String getThirdpartyId() {

        return thirdpartyId;
    }

    public void setThirdpartyId(String thirdpartyId) {

        this.thirdpartyId = thirdpartyId;
    }

    public String getType() {

        return type;
    }

    public void setType(String type) {

        this.type = type;
    }

    public String getFirstName() {

        return firstName;
    }

    public void setFirstName(String firstName) {

        this.firstName = firstName;
    }

    public String getLastName() {

        return lastName;
    }

    public void setLastName(String lastName) {

        this.lastName = lastName;
    }
    
    public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getLabel() {
		return label;
	}

	public void setLabel(String label) {
		this.label = label;
	}

	public String getSignerId() {
		return signerId;
	}

	public void setSignerId(String signerId) {
		this.signerId = signerId;
	}

	public List<String> getAllowedActions() {

        return allowedActions;
    }

    public void setAllowedActions(List<String> allowedActions) {

        this.allowedActions = allowedActions;
    }
    
    public String getOnBehalfOf() {
		return onBehalfOf;
	}

	public void setOnBehalfOf(String onBehalfOf) {
		this.onBehalfOf = onBehalfOf;
	}

    @Override
    public String toString() {
        return "RequiredSignatory{" +
            "thirdpartyId='" + thirdpartyId + '\'' +
            ", type='" + type + '\'' +
            ", firstName='" + firstName + '\'' +
            ", lastName='" + lastName + '\'' +
            ", email='" + email + '\'' +
            ", phoneNumber='" + phoneNumber + '\'' +
            ", label='" + label + '\'' +
            ", signerId='" + signerId + '\'' +
            ", allowedActions=" + allowedActions +
            ", onBehalfOf='" + onBehalfOf + '\'' +
            '}';
    }
}
