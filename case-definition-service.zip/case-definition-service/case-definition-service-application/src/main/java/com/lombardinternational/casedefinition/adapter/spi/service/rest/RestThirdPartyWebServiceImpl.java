package com.lombardinternational.casedefinition.adapter.spi.service.rest;

import org.springframework.stereotype.Service;

import com.lombardinternational.casedefinition.domain.spi.ThirdPartyWebService;
import com.lombardinternational.clients.classapp.client.ThirdPartyServiceClient;
import com.lombardinternational.clients.classapp.model.thirdparty.ThirdParty;

import lombok.AllArgsConstructor;

@Service
@AllArgsConstructor
public class RestThirdPartyWebServiceImpl implements ThirdPartyWebService {

    private final ThirdPartyServiceClient thirdPartyClient;

    @Override
    public ThirdParty getThirdParty(final String externalId) {
        return thirdPartyClient.getThirdParty(externalId);
    }
}
