package com.lombardinternational.casedefinition.adapter.api.web.mapper;

import com.lombardinternational.casedefinition.adapter.api.web.dto.CaseDocumentDefinition;
import org.mapstruct.Mapper;

import java.util.List;

/**
 * Mapper between ${@link CaseDocumentDefinition} and ${@link com.lombardinternational.casedefinition.model.CaseDocumentDefinition}
 *
 * @author qemo
 */
@Mapper(componentModel="spring")
public interface CaseDocumentDefinitionMapper {


    List<CaseDocumentDefinition> dtoFromCaseDocumentDefinition(
        List<com.lombardinternational.casedefinition.model.CaseDocumentDefinition> caseDocumentDefinitions);
}
