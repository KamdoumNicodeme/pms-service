package com.lombardinternational.casedefinition.adapter.api.web.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.lombardinternational.casedefinition.adapter.api.web.dto.CaseControlDefinition;
import com.lombardinternational.casedefinition.adapter.api.web.dto.CaseControlRequest;
import com.lombardinternational.casedefinition.adapter.api.web.dto.CaseDocumentDefinition;
import com.lombardinternational.casedefinition.adapter.api.web.dto.CaseDocumentRequest;
import com.lombardinternational.casedefinition.adapter.api.web.dto.CaseSubTaskRequest;
import com.lombardinternational.casedefinition.adapter.api.web.dto.TaskDefinition;
import com.lombardinternational.casedefinition.adapter.api.web.mapper.CaseControlDefinitionMapper;
import com.lombardinternational.casedefinition.adapter.api.web.mapper.CaseDocumentDefinitionMapper;
import com.lombardinternational.casedefinition.adapter.api.web.mapper.ScreenDescriptionMapper;
import com.lombardinternational.casedefinition.adapter.api.web.mapper.TaskDefinitionMapper;
import com.lombardinternational.casedefinition.adapter.api.web.mapper.WebFormMapper;
import com.lombardinternational.casedefinition.domain.api.CaseBusinessService;
import com.lombardinternational.casedefinition.model.ScreenDescription;
import com.lombardinternational.casedefinition.model.WebForm;
import com.lombardinternational.utils.servicelogger.milestones.domain.LogMilestone;
import com.lombardinternational.utils.servicelogger.milestones.domain.LoggableValue;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;

/**
 * Case Rest Controller
 *
 * @author qemo
 */
@Tag(name = "Cases", description = "Cases management")
@RestController
@RequestMapping("/api/cases")
@LogMilestone(category = "rest", domain = "case-definition")
public class CaseController {

    private final CaseBusinessService caseBusinessService;
    private final WebFormMapper webFormMapper;
    private final ScreenDescriptionMapper screenDescriptionMapper;
    private final CaseDocumentDefinitionMapper caseDocumentDefinitionMapper;
    private final CaseControlDefinitionMapper caseControlDefinitionMapper;
    private final TaskDefinitionMapper taskDefinitionMapper;

    @Autowired
    public CaseController(CaseBusinessService caseBusinessService,
                          WebFormMapper webFormMapper,
                          ScreenDescriptionMapper screenDescriptionMapper,
                          CaseDocumentDefinitionMapper caseDocumentDefinitionMapper,
                          CaseControlDefinitionMapper caseControlDefinitionMapper,
                          TaskDefinitionMapper taskDefinitionMapper) {
        this.caseBusinessService = caseBusinessService;
        this.webFormMapper = webFormMapper;
        this.screenDescriptionMapper = screenDescriptionMapper;
        this.caseDocumentDefinitionMapper = caseDocumentDefinitionMapper;
        this.caseControlDefinitionMapper = caseControlDefinitionMapper;
        this.taskDefinitionMapper = taskDefinitionMapper;
    }

    @PostMapping("/documents")
    @Operation(summary = "Generate document list based on a CaseDocumentRequest")
    @LogMilestone(action = "get case documents")
    public ResponseEntity<List<CaseDocumentDefinition>> getCaseDocuments(@LoggableValue({"caseType", "policyNumber", "businessTransactionNumber", "clientNumber"}) @Valid @RequestBody CaseDocumentRequest caseDocumentRequest) {
        final String policyNumber = caseDocumentRequest.getPolicyNumber();
        final WebForm webForm = this.webFormMapper.webFormFromDTO(caseDocumentRequest.getCaseInitializationData());

        final ScreenDescription screenDescription =
                this.screenDescriptionMapper.screenDescriptionFromDTO(caseDocumentRequest.getCheckListOverviewData());

        final List<com.lombardinternational.casedefinition.model.CaseDocumentDefinition>
                caseDocumentDefinitions = caseBusinessService.computeCaseDocumentsDefinition(policyNumber, caseDocumentRequest.getCaseType(), webForm, screenDescription);

        return ResponseEntity.ok(this.caseDocumentDefinitionMapper.dtoFromCaseDocumentDefinition(caseDocumentDefinitions));
    }

    @PostMapping("/subTasks")
    @Operation(summary = "Generate subtask list based on a CaseSubTaskRequest")
    @LogMilestone(action = "get sub tasks")
    public ResponseEntity<List<TaskDefinition>> getSubTasks(@LoggableValue({"caseType", "policyNumber", "businessTransactionNumber", "clientNumber"}) @Valid @RequestBody CaseSubTaskRequest caseSubTaskRequest) {
        final WebForm webForm = this.webFormMapper.webFormFromDTO(caseSubTaskRequest.getCaseInitializationData());
        final ScreenDescription screenDescription = this.screenDescriptionMapper.screenDescriptionFromDTO(caseSubTaskRequest.getCheckListOverviewData());

        final List<com.lombardinternational.casedefinition.model.TaskDefinition> taskDefinitions = caseBusinessService
                .computeCaseSubTasks(caseSubTaskRequest.getPolicyNumber(), caseSubTaskRequest.getCaseType(), webForm, screenDescription);

        return ResponseEntity.ok(taskDefinitionMapper.map(taskDefinitions));
    }

    @PostMapping("/controls")
    @Operation(summary = "Generate control list based on a CaseControlRequest")
    @LogMilestone(action = "get controls")
    public ResponseEntity<List<CaseControlDefinition>> getControls(@LoggableValue({"caseType", "policyNumber", "businessTransactionId", "clientNumber"}) @Valid @RequestBody CaseControlRequest caseControlRequest) {
        final WebForm webForm = this.webFormMapper.webFormFromDTO(caseControlRequest.getCaseInitializationData());
        final ScreenDescription screenDescription =
                this.screenDescriptionMapper.screenDescriptionFromDTO(caseControlRequest.getCheckListOverviewData());

        final List<com.lombardinternational.casedefinition.model.CaseControlDefinition>
                caseControlDefinitions = this.caseBusinessService.computeCaseControlDefinitions(caseControlRequest.getCaseType(), webForm, screenDescription);

        return ResponseEntity.ok(this.caseControlDefinitionMapper.dtoFromCaseControlDefinition(caseControlDefinitions));
    }
}
