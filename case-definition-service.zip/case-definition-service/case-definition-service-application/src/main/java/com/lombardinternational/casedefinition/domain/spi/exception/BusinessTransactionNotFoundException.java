package com.lombardinternational.casedefinition.domain.spi.exception;

/**
 * Entity that represent ${@link BusinessTransactionNotFoundException}
 *
 * @author qemo
 */
public class BusinessTransactionNotFoundException extends RuntimeException {
    public static final String NOT_FOUND_WITH_BUSINESS_TRANSACTION_NUMBER =
        "Cannot find a BusinessTransaction with the businessTransactionNumber: {0}";

    public static final String NOT_FOUND_WITH_POLICY_NUMBER =
        "Cannot find a BusinessTransaction with the businessTransactionNumber: {0}";


    public BusinessTransactionNotFoundException(String message) {
        super(message);
    }
}
