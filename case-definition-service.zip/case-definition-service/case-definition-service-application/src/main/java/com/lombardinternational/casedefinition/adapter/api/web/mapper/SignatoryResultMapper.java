package com.lombardinternational.casedefinition.adapter.api.web.mapper;

import com.lombardinternational.casedefinition.model.SignatoryResult;
import org.mapstruct.Mapper;

/**
 * Mapper between ${@link SignatoryResult} and ${@link com.lombardinternational.casedefinition.adapter.api.web.dto.SignatoryResult}
 *
 * @author qemo
 */
@Mapper(componentModel = "spring", uses = {DocumentRequiredSignatoryMapper.class})
public interface SignatoryResultMapper {
    SignatoryResult signatoryResultFromDTO(com.lombardinternational.casedefinition.adapter.api.web.dto.SignatoryResult dto);
    com.lombardinternational.casedefinition.adapter.api.web.dto.SignatoryResult dtoFromSignatoryResult(SignatoryResult signatoryResult);
}
