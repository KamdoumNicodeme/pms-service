package com.lombardinternational.casedefinition.domain.spi;

import com.lombardinternational.casedefinition.domain.spi.exception.BusinessTransactionNotFoundException;
import com.lombardinternational.casedefinition.model.BusinessTransaction;

import java.util.List;

public interface BusinessTransactionWebService {


    /**
     * Find a business transaction based on the business transaction number
     *
     * @param businessTransactionNumber
     * @return
     * @exception IllegalArgumentException
     *                businessTransactionNumber is null
     * @exception BusinessTransactionNotFoundException
     *                Business transaction can not be found based on the business transaction number
     */
    BusinessTransaction getBusinessTransaction(String businessTransactionNumber) throws RuntimeException;

    /**
     * Get the list of business transaction number linked to a policy
     *
     * @param policyNumber
     * @return
     * @exception IllegalArgumentException
     *                policyNumber is null
     * @exception BusinessTransactionNotFoundException
     *                Service Business Transaction service returns error in the response
     */
    List<BusinessTransaction> getBusinessTransactions(String policyNumber) throws RuntimeException;
}
