package com.lombardinternational.casedefinition.adapter.api.web.dto;

public class CheckBoxField extends Field {

    public CheckBoxField() {
        super();
    }

    @Override
    public String toString() {

        return "CheckBoxField [" + super.toString() + "]";
    }

}
