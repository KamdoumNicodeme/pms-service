package com.lombardinternational.casedefinition.adapter.api.web.mapper;

import com.lombardinternational.casedefinition.model.BigDecimalWebFormField;
import org.mapstruct.Mapper;

import java.util.List;

/**
 * Mapper between ${@link BigDecimalWebFormField} and ${@link com.lombardinternational.casedefinition.adapter.api.web.dto.BigDecimalWebFormField}
 *
 * @author qemo
 */
@Mapper(componentModel="spring")
public interface BigDecimalWebFormFieldMapper {

    List<BigDecimalWebFormField> bigDecimalWebFormFieldFromDTO(List<com.lombardinternational.casedefinition.adapter.api.web.dto.BigDecimalWebFormField> dtos);
}
