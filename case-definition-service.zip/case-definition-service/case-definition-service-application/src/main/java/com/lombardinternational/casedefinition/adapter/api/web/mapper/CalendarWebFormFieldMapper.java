package com.lombardinternational.casedefinition.adapter.api.web.mapper;

import com.lombardinternational.casedefinition.model.CalendarWebFormField;
import org.mapstruct.Mapper;

import java.util.List;

/**
 * Mapper between ${@link CalendarWebFormField} and ${@link com.lombardinternational.casedefinition.adapter.api.web.dto.CalendarWebFormField}
 *
 * @author qemo
 */
@Mapper(componentModel = "spring")
public interface CalendarWebFormFieldMapper {

    List<CalendarWebFormField> calendarWebFormFieldFromDTO(
        List<com.lombardinternational.casedefinition.adapter.api.web.dto.CalendarWebFormField> CalendarWebFormFieldDTOs);
}
