package com.lombardinternational.casedefinition.mapper;

import com.lombardinternational.casedefinition.model.MoneyInPayment;
import com.lombardinternational.casedefinition.model.MoneyOutPayment;
import com.lombardinternational.casedefinition.model.Payment;
import org.mapstruct.BeanMapping;
import org.mapstruct.Mapper;
import org.mapstruct.MappingTarget;
import org.mapstruct.Named;

@Mapper(componentModel = "spring", uses = {CountryMapper.class, AmountMapper.class}, config = HardCodeMapperConfig.class)
public interface PaymentMapper {

    @BeanMapping(ignoreByDefault = true)
    void mapPayment(com.lombardinternational.clients.classapp.model.Payment classPayment, @MappingTarget Payment payment);

    default Payment map(com.lombardinternational.clients.classapp.model.Payment payment) {
        if (payment instanceof com.lombardinternational.clients.classapp.model.MoneyOutPayment) {
            return mapTo((com.lombardinternational.clients.classapp.model.MoneyOutPayment) payment);
        } else if (payment instanceof com.lombardinternational.clients.classapp.model.MoneyInPayment) {
            return mapTo((com.lombardinternational.clients.classapp.model.MoneyInPayment) payment);
        } else {
            throw new RuntimeException("Cannot parse Class Payment to Payment");
        }
    }

    @Named("moneyInPayment")
    MoneyInPayment mapTo(com.lombardinternational.clients.classapp.model.MoneyInPayment payment);

    @Named("moneyOutPayment")
    MoneyOutPayment mapTo(com.lombardinternational.clients.classapp.model.MoneyOutPayment payment);
}
