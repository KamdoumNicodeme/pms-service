package com.lombardinternational.casedefinition.adapter.api.web.mapper;

import com.lombardinternational.casedefinition.model.WebFormGroup;
import org.mapstruct.Mapper;

import java.util.List;

/**
 * Mapper between ${@link WebFormGroupMapper} and ${@link com.lombardinternational.casedefinition.adapter.api.web.dto.WebFormGroup}
 *
 * @author qemo
 */
@Mapper(componentModel = "spring", uses = {BigDecimalWebFormFieldMapper.class, BooleanWebFormFieldMapper.class, TextWebFormFieldMapper.class,
    CalendarWebFormFieldMapper.class}, config = WebFormFieldMapper.class)
public interface WebFormGroupMapper {

    List<WebFormGroup> webFormGroupFromDTO(List<com.lombardinternational.casedefinition.adapter.api.web.dto.WebFormGroup> dtos);
    WebFormGroup webFormGroupFromDTO(com.lombardinternational.casedefinition.adapter.api.web.dto.WebFormGroup dto);
}
