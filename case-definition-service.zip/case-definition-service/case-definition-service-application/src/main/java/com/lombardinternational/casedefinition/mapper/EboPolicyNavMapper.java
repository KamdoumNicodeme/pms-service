package com.lombardinternational.casedefinition.mapper;


import com.lombardinternational.casedefinition.model.EboPolicyNav;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface EboPolicyNavMapper {
    EboPolicyNav map(com.lombardinternational.clients.classapp.model.EboPolicyNav eboPolicyNav);
}
