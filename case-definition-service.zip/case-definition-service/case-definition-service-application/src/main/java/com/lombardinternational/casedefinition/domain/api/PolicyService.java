package com.lombardinternational.casedefinition.domain.api;

import com.lombardinternational.casedefinition.model.Policy;

public interface PolicyService {

    /**
     * Construct policy, third parties and their roles
     *
     * @param policyNumber
     * @return
     */
    Policy buildPolicy(String policyNumber);
}
