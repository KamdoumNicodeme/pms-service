package com.lombardinternational.casedefinition.adapter.api.web.dto;

public class FormInitiator {

    private Long userId;
    private String userLogin;
    private String displayedName;
    private Long companyId;
    private String companyName;
    private String initiatorRole;
    private String partnerType;

    public FormInitiator() {
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(final Long userId) {
        this.userId = userId;
    }

    public String getUserLogin() {
        return userLogin;
    }

    public void setUserLogin(final String userLogin) {
        this.userLogin = userLogin;
    }

    public String getDisplayedName() {
        return displayedName;
    }

    public void setDisplayedName(final String displayedName) {
        this.displayedName = displayedName;
    }

    public Long getCompanyId() {
        return companyId;
    }

    public void setCompanyId(final Long companyId) {
        this.companyId = companyId;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(final String companyName) {
        this.companyName = companyName;
    }

    public String getInitiatorRole() {
        return initiatorRole;
    }

    public void setInitiatorRole(final String initiatorRole) {
        this.initiatorRole = initiatorRole;
    }

    public String getPartnerType() {
        return partnerType;
    }

    public void setPartnerType(final String partnerType) {
        this.partnerType = partnerType;
    }

    @Override
    public String toString() {
        return "FormInitiator{" +
                "userId=" + userId +
                ", userLogin='" + userLogin + '\'' +
                ", displayedName='" + displayedName + '\'' +
                ", companyId=" + companyId +
                ", companyName='" + companyName + '\'' +
                ", initiatorRole='" + initiatorRole + '\'' +
                ", partnerType='" + partnerType + '\'' +
                '}';
    }
}
