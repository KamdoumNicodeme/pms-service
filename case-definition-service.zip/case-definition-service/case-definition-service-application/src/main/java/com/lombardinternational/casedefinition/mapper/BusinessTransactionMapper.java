package com.lombardinternational.casedefinition.mapper;

import com.lombardinternational.clients.classapp.model.BusinessTransactionLight;
import org.mapstruct.*;

import com.lombardinternational.casedefinition.model.BusinessTransaction;
import com.lombardinternational.casedefinition.model.RoleEndorsementBusinessTransaction;
import com.lombardinternational.clients.classapp.model.BusinessTransactionDetails;

import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

@Mapper(componentModel = "spring", uses = { PolicyRoleMapper.class, PaymentMapper.class, AmountMapper.class })
@DecoratedWith(BusinessTransactionMapperDecorator.class)
public interface BusinessTransactionMapper {

    List<String> POLICY_SERVICING_BT_TYPE = Collections.unmodifiableList(Arrays.asList("POLICY_SERVICING"));
    List<String> POLICY_SERVICING_BT_SUB_TYPE = Collections.unmodifiableList(Arrays.asList("REMOVE_ADD_ROLES"));


    default BusinessTransaction buildBusinessTransaction(BusinessTransactionDetails businessTransactionDetails) {
        if (POLICY_SERVICING_BT_TYPE.contains(businessTransactionDetails.getTransactionType()) && POLICY_SERVICING_BT_SUB_TYPE.contains(businessTransactionDetails.getEndorsementCategory())) {
            return mapToRoleEndorsement(businessTransactionDetails);
        }
        return mapToBusinessTransaction(businessTransactionDetails);
    }

    @ToBusinessTransaction
    BusinessTransaction mapToBusinessTransaction(BusinessTransactionDetails businessTransactionDetails);

    @ToBusinessTransaction
    RoleEndorsementBusinessTransaction mapToRoleEndorsement(BusinessTransactionDetails businessTransactionDetails);

    @BeanMapping(ignoreByDefault = true)
    @Mapping(source = "rolesAfterEndorsement", target = "rolesAfterEndorsement")
    void updateRoleEndorsement(@MappingTarget RoleEndorsementBusinessTransaction targetRoleEndorsementBusinessTransaction, com.lombardinternational.clients.classapp.model.RoleEndorsementBusinessTransaction roleEndorsementBusinessTransaction);

    @Mapping(source = "transactionId", target = "identifier")
    @Mapping(source = "transactionType", target = "type")
    @Mapping(source = "endorsementCategory", target = "category")
    @Mapping(source = "endorsementSubCategory", target = "subCategory")
    @Mapping(source = "closingDate", target = "closeDate")
    BusinessTransaction mapToBusinessTransactionFromLight(BusinessTransactionLight businessTransactionLight);

    List<BusinessTransaction> mapToListFromLightList(Collection<BusinessTransactionLight> businessTransactionLightList);
}
