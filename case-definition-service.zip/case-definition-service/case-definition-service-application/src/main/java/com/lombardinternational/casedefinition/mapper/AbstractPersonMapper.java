package com.lombardinternational.casedefinition.mapper;

import java.util.Collection;
import java.util.List;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;

import com.lombardinternational.casedefinition.model.AbstractPerson;
import com.lombardinternational.clients.classapp.model.thirdparty.MoralPerson;
import com.lombardinternational.clients.classapp.model.thirdparty.MoralPersonLight;
import com.lombardinternational.clients.classapp.model.thirdparty.PhysicalPerson;
import com.lombardinternational.clients.classapp.model.thirdparty.PhysicalPersonLight;
import com.lombardinternational.clients.classapp.model.thirdparty.ThirdParty;
import com.lombardinternational.clients.classapp.model.thirdparty.ThirdPartyLight;

@Mapper(componentModel = "spring", uses = { PersistedBlockMapper.class, SourceOfFundsMapper.class,
    AddressMapper.class }, config = HardCodeMapperConfig.class)
public interface AbstractPersonMapper {

    List<AbstractPerson> mapToList(Collection<ThirdPartyLight> thirdParties);

    default AbstractPerson map(ThirdPartyLight thirdParty) {
        if (thirdParty instanceof MoralPersonLight) {
            return mapTo((MoralPersonLight) thirdParty);
        } else if (thirdParty instanceof PhysicalPersonLight) {
            return mapTo((PhysicalPersonLight) thirdParty);
        } else {
            throw new IllegalArgumentException("Unsupported third party type: " + thirdParty.getClass());
        }
    }

    @Named("moralPerson")
    @ToAbstractPerson
    @Mapping(source = "companyLegalForm.externalId", target = "companyLegalForm")
    com.lombardinternational.casedefinition.model.MoralPerson mapTo(MoralPersonLight thirdParty);

    @Named("physicalPerson")
    @ToAbstractPerson
    com.lombardinternational.casedefinition.model.PhysicalPerson mapTo(PhysicalPersonLight thirdParty);

    default AbstractPerson map(ThirdParty thirdParty) {
        if (thirdParty instanceof MoralPerson) {
            return mapTo((MoralPerson) thirdParty);
        } else if (thirdParty instanceof PhysicalPerson) {
            return mapTo((PhysicalPerson) thirdParty);
        } else {
            throw new IllegalArgumentException("Unsupported third party type: " + thirdParty.getClass());
        }
    }

    @Named("moralPerson")
    @ToAbstractPerson
    @Mapping(source = "companyLegalForm.externalId", target = "companyLegalForm")
    @Mapping(source = "thirdParty", target = "subType", qualifiedByName = "mapSubType")
    com.lombardinternational.casedefinition.model.MoralPerson mapTo(MoralPerson thirdParty);

    @Named("physicalPerson")
    @ToAbstractPerson
    @Mapping(source = "lastName", target = "lastname")
    @Mapping(target = "subType", constant = "Individual")
    com.lombardinternational.casedefinition.model.PhysicalPerson mapTo(PhysicalPerson thirdParty);

    @Named("mapSubType")
    default String mapSubType(MoralPerson thirdParty) {
        if (thirdParty.getCompanyLegalForm() == null) return "Company";
        switch (thirdParty.getCompanyLegalForm().getExternalId()) {
            case "FIDUCIARY":
                return "Fiduciary";
            case "TRUST":
                return "Trust";
            case "TRAD_COMP":
                return "Trading company";
            default:
                return "Company";
        }
    }
}
