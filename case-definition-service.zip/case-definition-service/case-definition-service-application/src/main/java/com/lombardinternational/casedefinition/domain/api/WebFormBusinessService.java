package com.lombardinternational.casedefinition.domain.api;

import com.lombardinternational.casedefinition.model.SignatoryResult;
import com.lombardinternational.casedefinition.model.WebForm;

public interface WebFormBusinessService {

    /**
     * Get the list of document required signatory based on the policy and the web form
     *
     *
     * @param caseType a case type
     * @param policyNumber a policy number
     * @param webForm the ${@link WebForm}
     * @return a ${@link SignatoryResult}
     */
    SignatoryResult computeSignatories(String caseType, String policyNumber, WebForm webForm);
}
