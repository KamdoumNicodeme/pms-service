package com.lombardinternational.casedefinition.adapter.api.web.dto;

import java.util.List;

public class DocumentRequiredSignatory {

    private String documentType;
    private String documentRelatedTo;
    private boolean documentMustBeGenerated;
    private boolean documentRequiredOnConnect;
    private String description;
    private String i18NDescription;
    private int documentOrder;
    private List<RequiredSignatory> requiredSignatories;
    private String cmsDocumentType;

    public DocumentRequiredSignatory() {
    }

    public String getDocumentType() {

        return documentType;
    }

    public void setDocumentType(String documentType) {

        this.documentType = documentType;
    }

    public String getDocumentRelatedTo() {

        return documentRelatedTo;
    }

    public void setDocumentRelatedTo(String documentRelatedTo) {

        this.documentRelatedTo = documentRelatedTo;
    }

    public boolean isDocumentMustBeGenerated() {

        return documentMustBeGenerated;
    }

    public void setDocumentMustBeGenerated(boolean documentMustBeGenerated) {

        this.documentMustBeGenerated = documentMustBeGenerated;
    }

    public boolean isDocumentRequiredOnConnect() {

        return documentRequiredOnConnect;
    }

    public void setDocumentRequiredOnConnect(boolean documentRequiredOnConnect) {

        this.documentRequiredOnConnect = documentRequiredOnConnect;
    }

    public String getDescription() {

        return description;
    }

    public void setDescription(String description) {

        this.description = description;
    }

    public String getI18NDescription() {

        return i18NDescription;
    }

    public void setI18NDescription(String i18nDescription) {

        i18NDescription = i18nDescription;
    }

    public int getDocumentOrder() {

        return documentOrder;
    }

    public void setDocumentOrder(int documentOrder) {

        this.documentOrder = documentOrder;
    }

    public List<RequiredSignatory> getRequiredSignatories() {

        return requiredSignatories;
    }

    public void setRequiredSignatories(List<RequiredSignatory> requiredSignatories) {

        this.requiredSignatories = requiredSignatories;
    }

    public String getCmsDocumentType() {

        return cmsDocumentType;
    }

    public void setCmsDocumentType(String cmsDocumentType) {

        this.cmsDocumentType = cmsDocumentType;
    }

    @Override
    public String toString() {

        return "DocumentRequiredSignatory [documentType=" + documentType + ", documentRelatedTo=" + documentRelatedTo
                + ", documentMustBeGenerated=" + documentMustBeGenerated + ", documentRequiredOnConnect=" + documentRequiredOnConnect
                + ", description=" + description + ", i18NDescription=" + i18NDescription + ", documentOrder=" + documentOrder
                + ", requiredSignatories=" + requiredSignatories + ", cmsDocumentType=" + cmsDocumentType + "]";
    }

}
