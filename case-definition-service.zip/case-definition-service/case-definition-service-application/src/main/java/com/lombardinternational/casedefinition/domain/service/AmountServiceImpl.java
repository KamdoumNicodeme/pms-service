package com.lombardinternational.casedefinition.domain.service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Collection;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.stream.Stream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lombardinternational.casedefinition.domain.api.AmountService;
import com.lombardinternational.casedefinition.domain.spi.FxRateWebService;
import com.lombardinternational.casedefinition.model.Amount;
import com.lombardinternational.casedefinition.model.BusinessTransaction;
import com.lombardinternational.casedefinition.model.BusinessTransactionProductComponent;
import com.lombardinternational.casedefinition.model.CurrencyExchangeRate;
import com.lombardinternational.casedefinition.model.Payment;

@Service
public class AmountServiceImpl implements AmountService {

    private final FxRateWebService fxRateWebService;

    @Autowired
    public AmountServiceImpl(FxRateWebService fxRateWebService) {
        this.fxRateWebService = fxRateWebService;
    }

    /**
     * see {@inheritDoc}
     */
    @Override
    public Amount convertAmount(Amount amount, String targetCurrency) {

        if (amount == null || amount.getQuantity() == null) {
            return new Amount(BigDecimal.ZERO.setScale(2, RoundingMode.HALF_UP), targetCurrency);
        }

        if (targetCurrency == null || targetCurrency.equals(amount.getIsoCurrencyCode())) {
            amount.setQuantity(amount.getQuantity().setScale(2, RoundingMode.HALF_UP));
            return amount;
        }

        final List<CurrencyExchangeRate> fxRates = fxRateWebService.getFxRate(amount.getIsoCurrencyCode(), targetCurrency);

        final Optional<CurrencyExchangeRate> currencyExchangeRate =
                fxRates.stream().filter(fxRate -> fxRate.getBaseIsoCurrencyCode().equals(amount.getIsoCurrencyCode())
                        && fxRate.getQuotedIsoCurrencyCode().equals(targetCurrency))
                        .max(Comparator.comparing(CurrencyExchangeRate::getRateDate));

        final Amount convertedAmount = new Amount();
        convertedAmount.setIsoCurrencyCode(targetCurrency);

        if (currencyExchangeRate.isPresent()) {
            convertedAmount.setQuantity(
                    amount.getQuantity()
                            .multiply(currencyExchangeRate.get().getRate().setScale(6, RoundingMode.HALF_UP))
                            .setScale(2, RoundingMode.HALF_UP));
        } else {
            convertedAmount.setQuantity(amount.getQuantity().setScale(2, RoundingMode.HALF_UP));
        }
        return convertedAmount;
    }

    @Override
    public Amount getSumPaymentAmountInTransaction(BusinessTransaction transaction, String targetCurrency) {
        BigDecimal sum = BigDecimal.ZERO;
        if (transaction != null) {
            sum = Optional.ofNullable(transaction.getProductComponentPayments()).map(Collection::stream).orElseGet(Stream::empty)
                    .map(BusinessTransactionProductComponent::getPayments)
                    .flatMap(payments -> Optional.ofNullable(payments).map(Collection::stream).orElseGet(Stream::empty))
                    .map(Payment::getPaymentAmount)
                    .map(amount -> convertAmount(amount, targetCurrency))
                    .map(Amount::getQuantity)
                    .reduce(BigDecimal.ZERO, BigDecimal::add);
        }

        if (BigDecimal.ZERO.compareTo(sum) != 0) {
            return new Amount(sum.setScale(2, RoundingMode.HALF_UP), targetCurrency);
        } else {
            if (transaction != null && transaction.getProductComponentPayments() != null) {
                sum = transaction.getProductComponentPayments().stream()
                        .map(BusinessTransactionProductComponent::getExpectedAmountInPolicyCurrency)
                        .map(expectedAmount -> convertAmount(expectedAmount, targetCurrency))
                        .map(Amount::getQuantity)
                        .reduce(BigDecimal.ZERO, BigDecimal::add);
            }
            return new Amount(sum.setScale(2, RoundingMode.HALF_UP), targetCurrency);
        }
    }

}
