package com.lombardinternational.casedefinition.domain.api;

import com.lombardinternational.casedefinition.model.Fund;

import java.util.List;

public interface FundService {

    /**
     * Get list of funds by policy number
     *
     * @param policyNumber
     * @return
     */
    List<Fund> getFunds(String policyNumber);

    /**
     * Check if the list of fund contains ILF fund
     * 
     * @param funds: the {@link List<Fund>}
     * @return a {@link Boolean}
     */
    Boolean containILFFund(List<Fund> funds);
}
