package com.lombardinternational.casedefinition.adapter.api.web.dto;



import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class SignatoryResult {

    private List<DocumentRequiredSignatory> documentRequiredSignatories = new ArrayList<>();
    private Map<String,String> responseMessages = new HashMap<>();

    public List<DocumentRequiredSignatory> getDocumentRequiredSignatories() {
        return documentRequiredSignatories;
    }

    public void setDocumentRequiredSignatories(
        List<DocumentRequiredSignatory> documentRequiredSignatories) {
        this.documentRequiredSignatories = documentRequiredSignatories;
    }

    public Map<String, String> getResponseMessages() {
        return responseMessages;
    }

    public void setResponseMessages(Map<String, String> responseMessages) {
        this.responseMessages = responseMessages;
    }

    @Override
    public String toString() {
        return "SignatoryResult{" +
            "documentRequiredSignatories=" + documentRequiredSignatories +
            ", responseMessages=" + responseMessages +
            '}';
    }
}
