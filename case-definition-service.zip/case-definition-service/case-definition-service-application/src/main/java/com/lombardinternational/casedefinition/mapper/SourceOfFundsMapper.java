package com.lombardinternational.casedefinition.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

import com.lombardinternational.casedefinition.model.SourceOfFunds;

@Mapper(componentModel = "spring", uses = { SourceOfWealthMapper.class })
public interface SourceOfFundsMapper {

    @Mappings({
                  @Mapping(target = "negativePressFindingFlag", source = "negativePressFinding"),
                  @Mapping(target = "internationalSanctionListFlag", source = "isOnInternationalSanctionList"),
                  @Mapping(target = "insiderFlag", source = "isInsider"),
                  @Mapping(target = "pepFlag", source = "isThirdPartyPep")
              })
    SourceOfFunds map(com.lombardinternational.clients.classapp.model.SourceOfFunds sourceOfFunds);
}
