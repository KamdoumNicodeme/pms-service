package com.lombardinternational.casedefinition.domain.service;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import com.lombardinternational.casedefinition.domain.api.CaseBusinessService;
import com.lombardinternational.casedefinition.domain.api.PolicyService;
import com.lombardinternational.casedefinition.domain.spi.RulesWebService;
import com.lombardinternational.casedefinition.model.CaseControlDefinition;
import com.lombardinternational.casedefinition.model.CaseDocumentDefinition;
import com.lombardinternational.casedefinition.model.Policy;
import com.lombardinternational.casedefinition.model.ScreenDescription;
import com.lombardinternational.casedefinition.model.TaskDefinition;
import com.lombardinternational.casedefinition.model.WebForm;

import lombok.AllArgsConstructor;

/**
 * ${@link CaseDocumentDefinition} Business Service
 *
 * @author qemo
 */
@Service
@AllArgsConstructor
public class CaseBusinessServiceImpl implements CaseBusinessService {

    /**
     * New business case type.
     */
    private static final String NB_CASE_TYPE = "NEW_BUSINESS";

    /**
     * Change of Investment Manager and Custodian Bank cases type.
     */
    private static final List<String> CIM_CCB_CASES_TYPE = Collections.unmodifiableList(Arrays.asList("CIM", "CCB", "CIM_CCB"));

    /**
     * Required services
     */
    private final RulesWebService rulesWebService;
    private final PolicyService policyService;

    /**
     * see {@inheritDoc}
     */
    @Override
    public List<CaseDocumentDefinition> computeCaseDocumentsDefinition(String policyNumber, String caseType, WebForm webForm,
        ScreenDescription screenCheckList) {
        final Policy policy =
            StringUtils.isNotBlank(policyNumber) && !NB_CASE_TYPE.equals(caseType) ? policyService.buildPolicy(policyNumber) : null;
        final WebForm evaluatedWebForm = CIM_CCB_CASES_TYPE.contains(caseType) ? null : webForm;

        return this.rulesWebService.computeCaseDocumentsDefinition(policy, evaluatedWebForm, screenCheckList);
    }

    /**
     * see {@inheritDoc}
     */
    @Override
    public List<CaseControlDefinition> computeCaseControlDefinitions(String caseType, WebForm webForm, ScreenDescription screenCheckList) {
        final WebForm evaluatedWebForm = CIM_CCB_CASES_TYPE.contains(caseType) ? null : webForm;

        return this.rulesWebService.computeCaseControlDefinitions(evaluatedWebForm, screenCheckList);
    }

    /**
     * see {@inheritDoc}
     */
    @Override
    public List<TaskDefinition> computeCaseSubTasks(String policyNumber, String caseType, WebForm webForm, ScreenDescription screenCheckList) {
        Policy policy = StringUtils.isNotBlank(policyNumber) && !NB_CASE_TYPE.equals(caseType) ? policyService.buildPolicy(policyNumber) : null;
        final WebForm evaluatedWebForm = CIM_CCB_CASES_TYPE.contains(caseType) ? null : webForm;

        if (screenCheckList == null) {
            screenCheckList = new ScreenDescription();
            screenCheckList.setScreenId(this.convertCaseTypeToCheckListScreenId(caseType));
        }

        return this.rulesWebService.computeTaskDefinition(policy, evaluatedWebForm, screenCheckList);
    }

    /**
     * Based on the case type return the right name of the checklist
     *
     * @param caseType: the caseType
     * @return a {@link String}
     */
    private String convertCaseTypeToCheckListScreenId(String caseType) {

        String screenId = "";

        switch (caseType) {
        case "WITHDRAWAL":
            screenId = "WITHDRAWAL_CHECKLIST";
            break;
        case "SURRENDER":
            screenId = "SURRENDER_CHECKLIST";
            break;

        }

        return screenId;
    }
}
