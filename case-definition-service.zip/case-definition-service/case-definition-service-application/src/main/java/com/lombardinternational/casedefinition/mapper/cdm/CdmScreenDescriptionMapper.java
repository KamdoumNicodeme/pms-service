package com.lombardinternational.casedefinition.mapper.cdm;

import com.lombardinternational.casedefinition.model.*;
import java.util.List;
import org.mapstruct.*;

@Mapper(componentModel = "spring", uses = {CdmFieldMapper.class})
public interface CdmScreenDescriptionMapper {

    Tab map(com.lombard.cdm.Tab cdm);
    com.lombard.cdm.Tab map(Tab cds);
    Group map(com.lombard.cdm.Group cdm);
    com.lombard.cdm.Group map(Group cds);

    List<Tab> mapTabsToCds(List<com.lombard.cdm.Tab> cdm);
    List<Group> mapGroupsToCds(List<com.lombard.cdm.Group> cdm);
    List<Field> mapFieldsToCds(List<com.lombard.cdm.Field> cdm);
    List<com.lombard.cdm.Tab> mapTabsToCdm(List<Tab> cds);
    List<com.lombard.cdm.Group> mapGroupsToCdm(List<Group> cds);
    List<com.lombard.cdm.Field> mapFieldsToCdm(List<Field> cds);



}
