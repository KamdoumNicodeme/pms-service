package com.lombardinternational.casedefinition.adapter.spi.service.rest.mapper;

import com.lombardinternational.casedefinition.model.CaseDeal;
import org.mapstruct.Mapper;

import java.util.List;

@Mapper(componentModel = "spring")
public interface CaseDealMapper {
    List<CaseDeal> mapToCaseDealList(List<com.lombardinternational.casemanagement.clients.casebusinesscase.model.CaseDeal> cdmCaseDeals);
}
