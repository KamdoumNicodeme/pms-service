package com.lombardinternational.casedefinition.adapter.api.web.dto;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;

import io.swagger.v3.oas.annotations.media.Schema;

/***
 *
 */
public class ScreenDescriptionRequest {

    @Schema(requiredMode = Schema.RequiredMode.REQUIRED)
    @NotBlank(message = "caseType is mandatory")
    protected String caseType;

    @Schema(requiredMode = Schema.RequiredMode.REQUIRED)
    @NotBlank(message = "policyNumber is mandatory")
    protected String policyNumber;

    @Schema(requiredMode = Schema.RequiredMode.REQUIRED)
    @NotBlank(message = "businessTransactionNumber is mandatory")
    protected String businessTransactionNumber;

    private String clientNumber;

    @Schema(requiredMode = Schema.RequiredMode.REQUIRED)
    @Valid
    private ScreenDescription screenDescription;

    @Schema(requiredMode = Schema.RequiredMode.REQUIRED)
    @Valid
    private WebForm caseInitializationData;

    @Schema(requiredMode = Schema.RequiredMode.REQUIRED)
    @Valid
    private ScreenDescription screenCheckList;

    public ScreenDescriptionRequest() {
    }

    public String getCaseType() {
        return caseType;
    }

    public void setCaseType(String caseType) {
        this.caseType = caseType;
    }

    public String getPolicyNumber() {
        return policyNumber;
    }

    public void setPolicyNumber(String policyNumber) {
        this.policyNumber = policyNumber;
    }

    public String getBusinessTransactionNumber() {
        return businessTransactionNumber;
    }

    public void setBusinessTransactionNumber(String businessTransactionNumber) {
        this.businessTransactionNumber = businessTransactionNumber;
    }

    public String getClientNumber() {
        return clientNumber;
    }

    public void setClientNumber(String clientNumber) {
        this.clientNumber = clientNumber;
    }

    public ScreenDescription getScreenDescription() {
        return screenDescription;
    }

    public void setScreenDescription(ScreenDescription screenDescription) {
        this.screenDescription = screenDescription;
    }

    public WebForm getCaseInitializationData() {
        return caseInitializationData;
    }

    public void setCaseInitializationData(WebForm caseInitializationData) {
        this.caseInitializationData = caseInitializationData;
    }

    public ScreenDescription getScreenCheckList() {
        return screenCheckList;
    }

    public void setScreenCheckList(ScreenDescription screenCheckList) {
        this.screenCheckList = screenCheckList;
    }

    @Override
    public String toString() {
        return "ScreenDescriptionRequest{" +
            "caseType='" + caseType + '\'' +
            ", policyNumber='" + policyNumber + '\'' +
            ", businessTransactionNumber='" + businessTransactionNumber + '\'' +
            ", clientNumber='" + clientNumber + '\'' +
            ", screenDescription=" + screenDescription +
            ", caseInitializationData=" + caseInitializationData +
            ", screenCheckList=" + screenCheckList +
            '}';
    }
}
