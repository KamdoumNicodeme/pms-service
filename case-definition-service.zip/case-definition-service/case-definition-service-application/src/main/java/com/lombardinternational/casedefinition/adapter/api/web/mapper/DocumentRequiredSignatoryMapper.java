package com.lombardinternational.casedefinition.adapter.api.web.mapper;

import com.lombardinternational.casedefinition.model.DocumentRequiredSignatory;
import com.lombardinternational.casedefinition.model.RequiredSignatory;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;

import java.util.ArrayList;
import java.util.List;

/**
 * Mapper between ${@link DocumentRequiredSignatory} and ${@link com.lombardinternational.casedefinition.adapter.api.web.dto.DocumentRequiredSignatory}
 *
 * @author qemo
 */
@Mapper(componentModel = "spring")
public interface DocumentRequiredSignatoryMapper {

    @Mapping(source = "requiredSignatories", target = "requiredSignatories", qualifiedByName = "getRequiredSignatoryList")
    List<DocumentRequiredSignatory> documentRequiredSignatoryFromDTO(
        List<com.lombardinternational.casedefinition.adapter.api.web.dto.DocumentRequiredSignatory> documentRequiredSignatoriesDTO);

    List<com.lombardinternational.casedefinition.adapter.api.web.dto.DocumentRequiredSignatory> dtoFromDocumentRequiredSignatory(
        List<DocumentRequiredSignatory> documentRequiredSignatories);

    @Named("getRequiredSignatoryList")
    default List<RequiredSignatory> getRequiredSignatoryList(List<com.lombardinternational.casedefinition.adapter.api.web.dto.RequiredSignatory> requiredSignatoryList) {
        if(requiredSignatoryList == null) {
            return new ArrayList<RequiredSignatory>();
        }
        List<RequiredSignatory> signatories = new ArrayList<>();
        for(com.lombardinternational.casedefinition.adapter.api.web.dto.RequiredSignatory requiredSignatory : requiredSignatoryList) {
            signatories.add(requiredSignatoryToSignatory(requiredSignatory));
        }
        return signatories;
    }

    RequiredSignatory requiredSignatoryToSignatory(com.lombardinternational.casedefinition.adapter.api.web.dto.RequiredSignatory requiredSignatory);

    List<com.lombardinternational.casedefinition.adapter.api.web.dto.RequiredSignatory> dtoFromRequiredSignatory(List<RequiredSignatory> requiredSignatories);
}