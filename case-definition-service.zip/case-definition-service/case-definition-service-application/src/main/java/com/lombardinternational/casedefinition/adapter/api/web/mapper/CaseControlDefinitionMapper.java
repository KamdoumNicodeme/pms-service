package com.lombardinternational.casedefinition.adapter.api.web.mapper;

import com.lombardinternational.casedefinition.adapter.api.web.dto.CaseControlDefinition;
import org.mapstruct.Mapper;

import java.util.List;

/**
 * Mapper between ${@link CaseControlDefinition} and ${@link com.lombardinternational.casedefinition.model.CaseControlDefinition}
 *
 * @author qemo
 */
@Mapper(componentModel = "spring")
public interface CaseControlDefinitionMapper {
    List<CaseControlDefinition> dtoFromCaseControlDefinition( List<com.lombardinternational.casedefinition.model.CaseControlDefinition> caseControlDefinitionDTOs);
}
