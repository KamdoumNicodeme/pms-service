package com.lombardinternational.casedefinition.adapter.api.web.mapper;

import com.lombardinternational.casedefinition.model.LabelField;
import org.mapstruct.Mapper;

import java.util.List;

/**
 * Mapper between ${@link LabelField} and ${@link com.lombardinternational.casedefinition.adapter.api.web.dto.LabelField}
 *
 * @author qemo
 */
@Mapper(componentModel="spring")
public interface LabelFieldMapper {

    List<LabelField> labelFieldFromDTO(List<com.lombardinternational.casedefinition.adapter.api.web.dto.LabelField> labelFieldDTOs);
}
