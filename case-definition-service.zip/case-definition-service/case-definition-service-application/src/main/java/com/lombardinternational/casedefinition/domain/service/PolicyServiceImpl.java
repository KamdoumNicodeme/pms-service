package com.lombardinternational.casedefinition.domain.service;

import com.lombardinternational.casedefinition.domain.api.PolicyRoleService;
import com.lombardinternational.casedefinition.domain.api.PolicyService;
import com.lombardinternational.casedefinition.domain.spi.PolicyWebService;
import com.lombardinternational.casedefinition.mapper.AbstractPersonMapper;
import com.lombardinternational.casedefinition.mapper.PolicyMapper;
import com.lombardinternational.casedefinition.mapper.PolicyRoleMapper;
import com.lombardinternational.casedefinition.model.*;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

@Service
@AllArgsConstructor
public class PolicyServiceImpl implements PolicyService {

    private final PolicyWebService policyService;
    private final PolicyRoleMapper policyRoleMapper;
    private final PolicyMapper policyMapper;
    private final PolicyRoleService policyRoleService;
    private final AbstractPersonMapper abstractPersonMapper;

    @Override
    public Policy buildPolicy(final String policyNumber) {
        Policy policy = policyMapper.map(policyService.getPolicy(policyNumber));
        policyMapper.updatePolicyValues(policyService.getPolicyValues(policyNumber), policy);

        buildPolicyRole(policy);
        buildPolicyLinks(policy);
        policy.setHolderAndEBODifferent(policyRoleService.policyRoleAreDifferent(policy.getHolders(), policy.getEconomicBeneficiaries()));
        policy.setHolderAndLifeAssuredDifferent(policyRoleService.policyRoleAreDifferent(policy.getHolders(), policy.getLifeAssureds()));
        policy.setBeneficiaryAndLifeAssuredDifferent(policyRoleService.policyRoleAreDifferent(policy.getBeneficiaries(), policy.getLifeAssureds()));
        return policy;
    }

    private void buildPolicyRole(final Policy policy) {
        List<PolicyRole> policyRoles = policyRoleMapper.mapToList(policyService.getPolicyRole(policy.getNumber()));

        policy.setHolders(getSpecificRole(Holder.class, policyRoles));
        policy.setCessionHolders(getSpecificRole(CessionHolder.class, policyRoles));
        policy.setLifeAssureds(getSpecificRole(LifeAssured.class, policyRoles));
        policy.setEconomicBeneficiaries(getSpecificRole(EconomicBeneficiary.class, policyRoles));
        policy.setTrustees(getSpecificRole(Trustee.class, policyRoles));
        policy.setTrusts(getSpecificRole(Trust.class, policyRoles));
        policy.setProxies(getSpecificRole(Proxy.class, policyRoles));
        policy.setSettlors(getSpecificRole(Settlor.class, policyRoles));
        List<Beneficiary> beneficiaries = getSpecificRole(Beneficiary.class, policyRoles);
        policy.setBeneficiaries(beneficiaries.stream().filter(beneficiary -> !beneficiary.getIrrevocableFlag()).collect(Collectors.toList()));
        policy.setIrrevocableBeneficiaries(beneficiaries.stream().filter(Beneficiary::getIrrevocableFlag).collect(Collectors.toList()));


        policy.setMoralPersons(policyRoles.stream().map(PolicyRole::getMoralPersons).distinct().flatMap(Collection::stream).collect(Collectors.toList()));
        policy.setPhysicalPersons(policyRoles.stream().map(PolicyRole::getPhysicalPersons).distinct().flatMap(Collection::stream).collect(Collectors.toList()));
    }

    private void buildPolicyLinks(final Policy policy) {
        List<AbstractPerson> tpLinks = abstractPersonMapper.mapToList(policyService.getPolicyLinks(policy.getNumber()));

        PolicyLink policyLink = new PolicyLink();
        policyLink.setMoralPersons(tpLinks.stream().filter(MoralPerson.class::isInstance).map(MoralPerson.class::cast).collect(Collectors.toList()));
        policyLink.setPhysicalPersons(tpLinks.stream().filter(PhysicalPerson.class::isInstance).map(PhysicalPerson.class::cast).collect(Collectors.toList()));
        policy.setPolicyLinks(Collections.singletonList(policyLink));
    }

    private <T extends PolicyRole> List<T> getSpecificRole(final Class<T> classType, List<PolicyRole> roles) {
        return roles.stream()
                .filter(classType::isInstance)
                .map(classType::cast)
                .collect(Collectors.toList());
    }
}
