package com.lombardinternational.casedefinition.adapter.spi.service.rest;

import com.lombardinternational.casedefinition.adapter.spi.service.rest.mapper.CaseDealMapper;
import com.lombardinternational.casedefinition.domain.spi.DealWebService;
import com.lombardinternational.casemanagement.clients.casebusinesscase.client.CaseClient;
import com.lombardinternational.casemanagement.clients.casebusinesscase.model.CaseDeal;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service("restDealWebServiceImpl")
public class RestDealWebServiceImpl implements DealWebService {

   private final CaseClient caseClient;
   private final CaseDealMapper caseDealMapper;

    @Autowired
    public RestDealWebServiceImpl(CaseClient caseClient, CaseDealMapper caseDealMapper) {
        this.caseClient = caseClient;
        this.caseDealMapper = caseDealMapper;
    }

    /**
     * see {@inheritDoc}
     *
     * @param caseDealId
     */
    @Override
    public List<com.lombardinternational.casedefinition.model.CaseDeal> getCaseDeals(String caseDealId) {
        List<CaseDeal> caseDealsList = caseClient.getCaseDeals(caseDealId);
        return this.caseDealMapper.mapToCaseDealList(caseDealsList);
    }
}
