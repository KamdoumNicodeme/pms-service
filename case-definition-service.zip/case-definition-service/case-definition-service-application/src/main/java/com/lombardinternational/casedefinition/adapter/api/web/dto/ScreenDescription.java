package com.lombardinternational.casedefinition.adapter.api.web.dto;



import javax.validation.constraints.NotBlank;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class ScreenDescription {


    private LocalDate loadTimeStamp;

    @NotBlank(message = "screenId is mandatory")
    private String screenId;

    private ScreenDescription inputedScreenDescription;

    private List<Tab> tabs = new ArrayList<>();

    public ScreenDescription() {
    }

    public LocalDate getLoadTimeStamp() {
        return loadTimeStamp;
    }

    public void setLoadTimeStamp(LocalDate loadTimeStamp) {
        this.loadTimeStamp = loadTimeStamp;
    }

    public String getScreenId() {
        return screenId;
    }

    public void setScreenId(String screenId) {
        this.screenId = screenId;
    }

    public ScreenDescription getInputedScreenDescription() {
        return inputedScreenDescription;
    }

    public void setInputedScreenDescription(ScreenDescription inputedScreenDescription) {
        this.inputedScreenDescription = inputedScreenDescription;
    }

    public List<Tab> getTabs() {
        return tabs;
    }

    public void setTabs(List<Tab> tabs) {
        this.tabs = tabs;
    }

    @Override
    public String toString() {
        return "ScreenDescription{" +
            "loadTimeStamp=" + loadTimeStamp +
            ", screenId='" + screenId + '\'' +
            ", inputedScreenDescription=" + inputedScreenDescription +
            ", tabs=" + tabs +
            '}';
    }
}
