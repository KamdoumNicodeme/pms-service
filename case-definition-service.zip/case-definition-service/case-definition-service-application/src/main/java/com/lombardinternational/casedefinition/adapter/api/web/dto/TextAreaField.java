package com.lombardinternational.casedefinition.adapter.api.web.dto;

public class TextAreaField extends Field {

    private Integer rows;
    private Integer cols;
    private Integer minChars;
    private Integer maxChars;

    public TextAreaField() {
        super();
    }

    public Integer getRows() {

        return rows;
    }

    public void setRows(Integer rows) {

        this.rows = rows;
    }

    public Integer getCols() {

        return cols;
    }

    public void setCols(Integer cols) {

        this.cols = cols;
    }

    public Integer getMinChars() {

        return minChars;
    }

    public void setMinChars(Integer minChars) {

        this.minChars = minChars;
    }

    public Integer getMaxChars() {

        return maxChars;
    }

    public void setMaxChars(Integer maxChars) {

        this.maxChars = maxChars;
    }

    @Override
    public String toString() {

        return "TextAreaField [" + super.toString() + " rows=" + rows + ", cols=" + cols + ", minChars=" + minChars + ", maxChars=" + maxChars
            + "]";
    }

}
