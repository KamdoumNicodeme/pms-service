package com.lombardinternational.casedefinition.domain.spi;


import java.util.Collection;
import java.util.List;

import com.lombardinternational.clients.classapp.model.PersistedBlock;
import com.lombardinternational.clients.classapp.model.Policy;
import com.lombardinternational.clients.classapp.model.PolicyValues;
import com.lombardinternational.clients.classapp.model.roles.AbstractPolicyRole;
import com.lombardinternational.clients.classapp.model.thirdparty.ThirdPartyLight;

public interface PolicyWebService {

    /**
     * Find the policy by using the service provided by the integration framework
     *
     * @param policyNumber
     * @return
     * @throws IllegalArgumentException policyNumber is null or blank
     */
    Policy getPolicy(String policyNumber) throws IllegalArgumentException;

    PolicyValues getPolicyValues(String policyNumber);

    Collection<PersistedBlock> getBlocks(String policyNumber);

    List<AbstractPolicyRole> getPolicyRole(String policyNumber);

    Collection<ThirdPartyLight> getPolicyLinks(String policyNumber);
}
