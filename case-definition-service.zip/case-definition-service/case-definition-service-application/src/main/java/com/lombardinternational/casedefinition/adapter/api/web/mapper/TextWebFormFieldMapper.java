package com.lombardinternational.casedefinition.adapter.api.web.mapper;

import com.lombardinternational.casedefinition.model.TextWebFormField;
import org.mapstruct.Mapper;

import java.util.List;

/**
 * Mapper between ${@link TextWebFormFieldMapper} and ${@link com.lombardinternational.casedefinition.adapter.api.web.dto.TextWebFormField}
 *
 * @author qemo
 */
@Mapper(componentModel="spring")
public interface TextWebFormFieldMapper {
    List<TextWebFormField> textWebFormFieldFromDTO(List<com.lombardinternational.casedefinition.adapter.api.web.dto.TextWebFormField> textWebFormFieldDTOs);
}
