package com.lombardinternational.casedefinition.config;

import com.lombardinternational.casedefinition.model.AbstractPerson;
import com.lombardinternational.casedefinition.model.Address;
import com.lombardinternational.casedefinition.model.Amount;
import com.lombardinternational.casedefinition.model.BankAccount;
import com.lombardinternational.casedefinition.model.Beneficiary;
import com.lombardinternational.casedefinition.model.BigDecimalWebFormField;
import com.lombardinternational.casedefinition.model.Block;
import com.lombardinternational.casedefinition.model.BooleanWebFormField;
import com.lombardinternational.casedefinition.model.BusinessTransaction;
import com.lombardinternational.casedefinition.model.BusinessTransactionProductComponent;
import com.lombardinternational.casedefinition.model.CalendarWebFormField;
import com.lombardinternational.casedefinition.model.CaseControlDefinition;
import com.lombardinternational.casedefinition.model.CaseDeal;
import com.lombardinternational.casedefinition.model.CaseDocumentDefinition;
import com.lombardinternational.casedefinition.model.CessionHolder;
import com.lombardinternational.casedefinition.model.CheckBoxField;
import com.lombardinternational.casedefinition.model.Country;
import com.lombardinternational.casedefinition.model.CurrencyExchangeRate;
import com.lombardinternational.casedefinition.model.DocumentRequiredSignatory;
import com.lombardinternational.casedefinition.model.EconomicBeneficiary;
import com.lombardinternational.casedefinition.model.Field;
import com.lombardinternational.casedefinition.model.Fund;
import com.lombardinternational.casedefinition.model.Group;
import com.lombardinternational.casedefinition.model.Holder;
import com.lombardinternational.casedefinition.model.LabelField;
import com.lombardinternational.casedefinition.model.LifeAssured;
import com.lombardinternational.casedefinition.model.MoneyInBusinessTransaction;
import com.lombardinternational.casedefinition.model.MoneyInPayment;
import com.lombardinternational.casedefinition.model.MoneyOutBusinessTransaction;
import com.lombardinternational.casedefinition.model.MoneyOutPayment;
import com.lombardinternational.casedefinition.model.MoralPerson;
import com.lombardinternational.casedefinition.model.NumberInputField;
import com.lombardinternational.casedefinition.model.Payment;
import com.lombardinternational.casedefinition.model.PaymentDetails;
import com.lombardinternational.casedefinition.model.PaymentOriginator;
import com.lombardinternational.casedefinition.model.PhysicalPerson;
import com.lombardinternational.casedefinition.model.Policy;
import com.lombardinternational.casedefinition.model.PolicyRole;
import com.lombardinternational.casedefinition.model.PolicyServicingBusinessTransaction;
import com.lombardinternational.casedefinition.model.ProductComponent;
import com.lombardinternational.casedefinition.model.Proxy;
import com.lombardinternational.casedefinition.model.RequiredSignatory;
import com.lombardinternational.casedefinition.model.RoleEndorsementBusinessTransaction;
import com.lombardinternational.casedefinition.model.ScreenDescription;
import com.lombardinternational.casedefinition.model.SelectInputField;
import com.lombardinternational.casedefinition.model.SelectInputFieldOption;
import com.lombardinternational.casedefinition.model.Settlor;
import com.lombardinternational.casedefinition.model.SignatoryResult;
import com.lombardinternational.casedefinition.model.SourceOfFunds;
import com.lombardinternational.casedefinition.model.SourcesOfPremium;
import com.lombardinternational.casedefinition.model.SourcesOfWealth;
import com.lombardinternational.casedefinition.model.Tab;
import com.lombardinternational.casedefinition.model.TaskDefinition;
import com.lombardinternational.casedefinition.model.TextAreaField;
import com.lombardinternational.casedefinition.model.TextInputField;
import com.lombardinternational.casedefinition.model.TextWebFormField;
import com.lombardinternational.casedefinition.model.TransactionAmounts;
import com.lombardinternational.casedefinition.model.Trust;
import com.lombardinternational.casedefinition.model.Trustee;
import com.lombardinternational.casedefinition.model.UserDetail;
import com.lombardinternational.casedefinition.model.WebForm;
import com.lombardinternational.casedefinition.model.WebFormField;
import com.lombardinternational.casedefinition.model.WebFormGroup;
import org.kie.server.client.KieServicesConfiguration;
import org.kie.server.client.KieServicesFactory;
import org.kie.server.client.RuleServicesClient;
import org.kie.server.client.impl.KieServicesConfigurationImpl;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.HashSet;
import java.util.Set;

@Configuration
@EnableConfigurationProperties(KieServerConfigurationProperties.class)
public class RulesEngineConfiguration {

    @Bean
    public KieServicesConfiguration kieServicesConfiguration(KieServerConfigurationProperties props) {

        final KieServicesConfiguration config = new KieServicesConfigurationImpl(props.getServerUrl(), props.getUserName(), props.getPassword());
        // config.addExtraClasses(props.getExtraClasses());
        final Set<Class<?>> classes = new HashSet<>();
        classes.add(AbstractPerson.class);
        classes.add(Address.class);
        classes.add(Amount.class);
        classes.add(BankAccount.class);
        classes.add(Beneficiary.class);
        classes.add(BigDecimalWebFormField.class);
        classes.add(Block.class);
        classes.add(BooleanWebFormField.class);
        classes.add(BusinessTransaction.class);
        classes.add(CalendarWebFormField.class);
        classes.add(CaseControlDefinition.class);
        classes.add(CaseDocumentDefinition.class);
        classes.add(CessionHolder.class);
        classes.add(CheckBoxField.class);
        classes.add(DocumentRequiredSignatory.class);
        classes.add(EconomicBeneficiary.class);
        classes.add(Field.class);
        classes.add(Fund.class);
        classes.add(Group.class);
        classes.add(Holder.class);
        classes.add(LabelField.class);
        classes.add(LifeAssured.class);
        classes.add(MoneyInBusinessTransaction.class);
        classes.add(MoneyOutBusinessTransaction.class);
        classes.add(NumberInputField.class);
        classes.add(Policy.class);
        classes.add(PolicyRole.class);
        classes.add(PolicyServicingBusinessTransaction.class);
        classes.add(ProductComponent.class);
        classes.add(Proxy.class);
        classes.add(RequiredSignatory.class);
        classes.add(RoleEndorsementBusinessTransaction.class);
        classes.add(ScreenDescription.class);
        classes.add(SelectInputField.class);
        classes.add(SelectInputFieldOption.class);
        classes.add(Settlor.class);
        classes.add(SourceOfFunds.class);
        classes.add(SourcesOfPremium.class);
        classes.add(SourcesOfWealth.class);
        classes.add(Tab.class);
        classes.add(TaskDefinition.class);
        classes.add(TextAreaField.class);
        classes.add(TextInputField.class);
        classes.add(TextWebFormField.class);
        classes.add(TransactionAmounts.class);
        classes.add(Trust.class);
        classes.add(Trustee.class);
        classes.add(UserDetail.class);
        classes.add(WebForm.class);
        classes.add(WebFormField.class);
        classes.add(WebFormGroup.class);
        classes.add(SignatoryResult.class);
        classes.add(CaseDeal.class);
        classes.add(CurrencyExchangeRate.class);
        classes.add(BusinessTransactionProductComponent.class);
        classes.add(Payment.class);
        classes.add(MoneyInPayment.class);
        classes.add(MoneyOutPayment.class);
        classes.add(PaymentDetails.class);
        classes.add(PaymentOriginator.class);
        classes.add(Country.class);
        classes.add(MoralPerson.class);
        classes.add(PhysicalPerson.class);
        config.addExtraClasses(classes);

        return config;
    }

    @Bean
    public RuleServicesClient ruleServiceClient(KieServicesConfiguration config) {

        return KieServicesFactory.newKieServicesClient(config).getServicesClient(RuleServicesClient.class);
    }

}
