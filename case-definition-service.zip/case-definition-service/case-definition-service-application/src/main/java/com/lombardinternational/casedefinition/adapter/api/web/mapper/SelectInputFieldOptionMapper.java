package com.lombardinternational.casedefinition.adapter.api.web.mapper;

import com.lombardinternational.casedefinition.model.SelectInputFieldOption;
import org.mapstruct.Mapper;

import java.util.List;

/**
 * Mapper between ${@link SelectInputFieldOptionMapper} and ${@link com.lombardinternational.casedefinition.adapter.api.web.dto.SelectInputFieldOption}
 *
 * @author qemo
 */
@Mapper(componentModel="spring")
public interface SelectInputFieldOptionMapper {
    List<SelectInputFieldOption> selectInputFieldOptionFromDTO(List<com.lombardinternational.casedefinition.adapter.api.web.dto.SelectInputFieldOption> selectInputFieldOptionDTOs);
}
