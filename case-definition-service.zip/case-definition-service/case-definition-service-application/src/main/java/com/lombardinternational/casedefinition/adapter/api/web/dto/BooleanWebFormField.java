package com.lombardinternational.casedefinition.adapter.api.web.dto;


public class BooleanWebFormField extends WebFormField {

    private Boolean value;

    public BooleanWebFormField() {
    }

    public Boolean getValue() {

        return value;
    }

    public void setValue(Boolean value) {

        this.value = value;
    }

    @Override
    public String toString() {

        return "BooleanWebFormField [" + super.toString() + ", value=" + value + "]";
    }

}
