package com.lombardinternational.casedefinition.adapter.api.web.mapper;

import com.lombardinternational.casedefinition.model.CheckBoxField;
import org.mapstruct.Mapper;

import java.util.List;

/**
 * Mapper between ${@link CheckBoxField} and ${@link com.lombardinternational.casedefinition.adapter.api.web.dto.CheckBoxField}
 *
 * @author qemo
 */
@Mapper(componentModel="spring")
public interface CheckBoxFieldMapper {

    List<CheckBoxField> checkBoxFieldFromDTO(List<com.lombardinternational.casedefinition.adapter.api.web.dto.CheckBoxField> checkBoxFieldDTOs);
}
