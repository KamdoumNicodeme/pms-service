package com.lombardinternational.casedefinition.mapper;

import java.util.Collection;
import java.util.List;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import com.lombardinternational.casedefinition.model.Block;
import com.lombardinternational.clients.classapp.model.PersistedBlock;

@Mapper(componentModel = "spring")
public interface BlockMapper {

    List<Block> mapToList(Collection<PersistedBlock> persistedBlockCollection);

    @Mapping(source = "blockType.label", target = "blockType")
    Block map(PersistedBlock persistedBlock);
}
