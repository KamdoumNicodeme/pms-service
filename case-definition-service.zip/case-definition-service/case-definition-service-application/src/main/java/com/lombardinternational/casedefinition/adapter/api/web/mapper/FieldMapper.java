package com.lombardinternational.casedefinition.adapter.api.web.mapper;

import com.lombardinternational.casedefinition.model.CheckBoxField;
import com.lombardinternational.casedefinition.model.Field;
import com.lombardinternational.casedefinition.model.LabelField;
import com.lombardinternational.casedefinition.model.NumberInputField;
import com.lombardinternational.casedefinition.model.SelectInputField;
import com.lombardinternational.casedefinition.model.TextAreaField;
import com.lombardinternational.casedefinition.model.TextInputField;
import org.mapstruct.Mapper;
import org.mapstruct.Named;

import java.util.List;

/**
 * Entity that represent ${@link FieldMapper}
 *
 * @author qemo
 */
@Mapper(componentModel = "spring")
public interface FieldMapper {
    default Field map(com.lombardinternational.casedefinition.adapter.api.web.dto.Field field) {
        if(field instanceof com.lombardinternational.casedefinition.adapter.api.web.dto.LabelField) {
            return fromDto((com.lombardinternational.casedefinition.adapter.api.web.dto.LabelField) field);
        }else if(field instanceof com.lombardinternational.casedefinition.adapter.api.web.dto.TextInputField) {
            return fromDto((com.lombardinternational.casedefinition.adapter.api.web.dto.TextInputField) field);
        }else if(field instanceof com.lombardinternational.casedefinition.adapter.api.web.dto.NumberInputField) {
            return fromDto((com.lombardinternational.casedefinition.adapter.api.web.dto.NumberInputField) field);
        }else if(field instanceof com.lombardinternational.casedefinition.adapter.api.web.dto.SelectInputField) {
            return fromDto((com.lombardinternational.casedefinition.adapter.api.web.dto.SelectInputField) field);
        }else if(field instanceof com.lombardinternational.casedefinition.adapter.api.web.dto.TextAreaField) {
            return fromDto((com.lombardinternational.casedefinition.adapter.api.web.dto.TextAreaField) field);
        }else if(field instanceof com.lombardinternational.casedefinition.adapter.api.web.dto.CheckBoxField) {
            return fromDto((com.lombardinternational.casedefinition.adapter.api.web.dto.CheckBoxField) field);
        }else {
            throw new RuntimeException("Cannot parse a Field dto to a Field");
        }
    }

    default com.lombardinternational.casedefinition.adapter.api.web.dto.Field map(Field field) {
        if(field instanceof LabelField) {
            return toDto((LabelField) field);
        }else if(field instanceof TextInputField) {
            return toDto((TextInputField) field);
        }else if(field instanceof NumberInputField) {
            return toDto((NumberInputField) field);
        }else if(field instanceof SelectInputField) {
            return toDto((SelectInputField) field);
        }else if(field instanceof TextAreaField) {
            return toDto((TextAreaField) field);
        }else if(field instanceof CheckBoxField) {
            return toDto((CheckBoxField) field);
        }else {
            throw new RuntimeException("Cannot parse a Field to a Field dto");
        }
    }

    List<Field> mapFromDto(List<com.lombardinternational.casedefinition.adapter.api.web.dto.Field> fields);
    List<com.lombardinternational.casedefinition.adapter.api.web.dto.Field> mapToDto(List<Field> fields);

    @Named("labelField")
    LabelField fromDto(com.lombardinternational.casedefinition.adapter.api.web.dto.LabelField labelField);

    @Named("labelFieldDto")
    com.lombardinternational.casedefinition.adapter.api.web.dto.LabelField toDto(LabelField labelField);

    @Named("textInputField")
    TextInputField fromDto(com.lombardinternational.casedefinition.adapter.api.web.dto.TextInputField textInputField);

    @Named("textInputFieldDto")
    com.lombardinternational.casedefinition.adapter.api.web.dto.TextInputField toDto(TextInputField textInputField);

    @Named("numberInputField")
    NumberInputField fromDto(com.lombardinternational.casedefinition.adapter.api.web.dto.NumberInputField numberInputField);

    @Named("numberInputFieldDto")
    com.lombardinternational.casedefinition.adapter.api.web.dto.NumberInputField toDto(NumberInputField numberInputField);

    @Named("selectInputField")
    SelectInputField fromDto(com.lombardinternational.casedefinition.adapter.api.web.dto.SelectInputField selectInputField);

    @Named("selectInputFieldDto")
    com.lombardinternational.casedefinition.adapter.api.web.dto.SelectInputField toDto(SelectInputField selectInputField);

    @Named("textAreaField")
    TextAreaField fromDto(com.lombardinternational.casedefinition.adapter.api.web.dto.TextAreaField textAreaField);

    @Named("textAreaField")
    com.lombardinternational.casedefinition.adapter.api.web.dto.TextAreaField toDto(TextAreaField textAreaField);

    @Named("checkBoxField")
    CheckBoxField fromDto(com.lombardinternational.casedefinition.adapter.api.web.dto.CheckBoxField checkBoxField);

    @Named("checkBoxField")
    com.lombardinternational.casedefinition.adapter.api.web.dto.CheckBoxField toDto(CheckBoxField checkBoxField);
}
