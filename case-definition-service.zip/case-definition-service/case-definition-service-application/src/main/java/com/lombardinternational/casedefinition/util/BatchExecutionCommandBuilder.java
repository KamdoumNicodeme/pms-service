package com.lombardinternational.casedefinition.util;

import org.kie.api.KieServices;
import org.kie.api.command.BatchExecutionCommand;
import org.kie.api.command.Command;
import org.kie.api.command.KieCommands;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.ArrayList;
import java.util.List;

public class BatchExecutionCommandBuilder {

    public static final KieCommands COMMANDS = KieServices.Factory.get().getCommands();

    // Mandatory
    private final String session;
    // Optional
    private final List<Command<?>> commands = new ArrayList<>();

    @Autowired
    public BatchExecutionCommandBuilder(String session) {
        this.session = session;
    }

    public BatchExecutionCommandBuilder addCommand(Command<?> command) {

        commands.add(command);
        return this;
    }

    public BatchExecutionCommandBuilder addCommands(List<Command<?>> command) {

        commands.addAll(command);
        return this;
    }

    public BatchExecutionCommand build() {

        return KieServices.Factory.get().getCommands().newBatchExecution(commands, session);
    }

}
