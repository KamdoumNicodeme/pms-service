package com.lombardinternational.casedefinition.adapter.api.web.mapper;

import com.lombardinternational.casedefinition.model.BooleanWebFormField;
import org.mapstruct.Mapper;

import java.util.List;

/**
 * Mapper between ${@link BooleanWebFormField} and ${@link com.lombardinternational.casedefinition.adapter.api.web.dto.BooleanWebFormField}
 *
 * @author qemo
 */
@Mapper(componentModel="spring")
public interface BooleanWebFormFieldMapper {

    List<BooleanWebFormField> booleanWebFormFieldFromDTO(List<com.lombardinternational.casedefinition.adapter.api.web.dto.BooleanWebFormField> dtos);

}
