package com.lombardinternational.casedefinition.domain.service;

import com.lombardinternational.casedefinition.domain.api.AmountService;
import com.lombardinternational.casedefinition.domain.api.BusinessTransactionService;
import com.lombardinternational.casedefinition.domain.spi.BusinessTransactionWebService;
import com.lombardinternational.casedefinition.mapper.EboPolicyNavMapper;
import com.lombardinternational.casedefinition.mapper.RiskFactorResultMapper;
import com.lombardinternational.casedefinition.model.Amount;
import com.lombardinternational.casedefinition.model.BusinessTransaction;
import com.lombardinternational.casedefinition.model.Policy;
import com.lombardinternational.casedefinition.model.TransactionAmounts;
import com.lombardinternational.casedefinition.util.RiskFactorsProperties;
import com.lombardinternational.clients.classapp.client.ComplianceServiceClient;
import com.lombardinternational.clients.classapp.model.EboPolicyNav;
import com.lombardinternational.clients.classapp.model.RiskFactorResult;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.Calendar;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Service
@RequiredArgsConstructor
public class BusinessTransactionServiceImpl implements BusinessTransactionService {

    private static final Logger logger = LoggerFactory.getLogger(BusinessTransactionServiceImpl.class);

    private final BusinessTransactionWebService restBusinessTransactionWebService;
    private final ComplianceServiceClient complianceServiceClient;
    private final AmountService amountService;
    private final RiskFactorResultMapper riskFactorResultMapper;
    private final EboPolicyNavMapper eboPolicyNavMapper;

    @Value("${policies-remediated-list}")
    private final List<String> policiesRemediatedList;

    @Value("${policies-not-remediated-list}")
    private final List<String> policiesNotRemediatedList;

    private static final String EUR_ISO_CODE_CURRENCY = "EUR";
    private final RiskFactorsProperties riskFactorsProperties;

    /**
     * see {@inheritDoc}
     */
    @Override
    public Boolean hasMadeChangeOfBroker(String policyNumber) {

        List<BusinessTransaction> businessTransactions = restBusinessTransactionWebService.getBusinessTransactions(policyNumber);

        // define the date minus 3 months
        final Calendar currentDate = Calendar.getInstance();
        currentDate.add(Calendar.MONTH, -3);

        final List<BusinessTransaction> filterBusinessTransactions =
                businessTransactions.stream().filter(businessTransaction -> "DISTRIBUTION_NETWORK".equals(businessTransaction.getCategory())
                        && "CHANGE_PARTNER_STRUCTURE".equals(businessTransaction.getSubCategory())).collect(Collectors.toList());

        return filterBusinessTransactions.stream()
                .map(BusinessTransaction::getCloseDate)
                .filter(Objects::nonNull)
                .anyMatch(closeDateCalendar -> currentDate.compareTo(closeDateCalendar) <= 0);
    }

    @Override
    public BusinessTransaction buildBusinessTransaction(String businessTransactionNumber, Policy policy, String caseType, String policyNumber) {

        logger.info("Building business transaction");
        BusinessTransaction businessTransaction = restBusinessTransactionWebService.getBusinessTransaction(businessTransactionNumber);

        if (businessTransaction != null) {
            // set the amount in EUR
            logger.info("Convert business transaction amount to EUR");
            final TransactionAmounts transactionAmounts = businessTransaction.getTransactionAmounts();
            final Amount expectedAmount = amountService.getSumPaymentAmountInTransaction(businessTransaction, policy.getIsoCurrencyCode());
            final Amount expectedAmountEur = amountService.convertAmount(expectedAmount, EUR_ISO_CODE_CURRENCY);

            businessTransaction.setExpectedAmountEur(expectedAmountEur);
            businessTransaction.setExpectedAmount(expectedAmount);
            if (transactionAmounts != null) {
                final Amount grossAmount = transactionAmounts.getGrossAmount();
                businessTransaction.setTransactionAmountEur(amountService.convertAmount(grossAmount, EUR_ISO_CODE_CURRENCY));
            }
            if(!StringUtils.isBlank(caseType) && !CollectionUtils.isEmpty(riskFactorsProperties.getFactors()) && !CollectionUtils.isEmpty(riskFactorsProperties.getFactors().get(caseType))) {
                logger.info("Evaluate risk factors for transaction {}", businessTransactionNumber);
                List<RiskFactorResult> riskFactorResults = complianceServiceClient.evaluateRiskFactors(businessTransactionNumber, riskFactorsProperties.getFactors().get(caseType));
                businessTransaction.setRiskFactorResults(riskFactorResultMapper.mapToList(riskFactorResults));
            }
            final EboPolicyNav eboPolicyNav = complianceServiceClient.getSameEboPolicyNav(policyNumber, businessTransactionNumber, "EUR");
            businessTransaction.setEboPolicyNav(eboPolicyNavMapper.map(eboPolicyNav));

            // Map policy remediation list
            businessTransaction.setIsInRemediationList(Stream.concat(policiesRemediatedList.stream(), policiesNotRemediatedList.stream()).anyMatch(i -> i.equals(policyNumber)));
            businessTransaction.setIsPolicyRemediated(policiesRemediatedList.stream().anyMatch(i -> i.equals(policyNumber)));

        }
        return businessTransaction;
    }

}
