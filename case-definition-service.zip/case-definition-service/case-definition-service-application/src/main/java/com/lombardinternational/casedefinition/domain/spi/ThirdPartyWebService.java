package com.lombardinternational.casedefinition.domain.spi;

import com.lombardinternational.clients.classapp.model.thirdparty.ThirdParty;

public interface ThirdPartyWebService {

    ThirdParty getThirdParty(String externalId);
}
