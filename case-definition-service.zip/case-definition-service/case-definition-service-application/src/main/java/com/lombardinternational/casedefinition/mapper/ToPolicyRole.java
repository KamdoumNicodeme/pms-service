package com.lombardinternational.casedefinition.mapper;

import org.mapstruct.Mapping;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

@Retention(RetentionPolicy.CLASS)
@Mapping(target = "roleId", source = "externalId")
public @interface ToPolicyRole {

}
