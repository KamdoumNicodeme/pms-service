package com.lombardinternational.casedefinition.adapter.api.web.mapper;

import org.mapstruct.Mapper;

import com.lombardinternational.casedefinition.model.FormInitiator;

/**
 * Mapper between ${@link FormInitiator} and ${@link com.lombardinternational.casedefinition.adapter.api.web.dto.FormInitiator}
 */
@Mapper(componentModel="spring")
public interface FormInitiatorlMapper {

    FormInitiator formInitiatorFromDTO(com.lombardinternational.casedefinition.adapter.api.web.dto.CompanyDetail FormInitiator);
}
