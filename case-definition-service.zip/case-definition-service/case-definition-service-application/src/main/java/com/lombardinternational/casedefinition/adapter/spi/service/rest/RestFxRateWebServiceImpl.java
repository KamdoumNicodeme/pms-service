package com.lombardinternational.casedefinition.adapter.spi.service.rest;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import com.lombardinternational.casedefinition.adapter.spi.service.rest.mapper.FxRateMapper;
import com.lombardinternational.casedefinition.domain.spi.FxRateWebService;
import com.lombardinternational.casedefinition.model.CurrencyExchangeRate;
import com.lombardinternational.clients.fxrates.client.FxRatesServiceClient;
import com.lombardinternational.clients.fxrates.model.FxRate;
import com.lombardinternational.clients.fxrates.model.FxRateFilter;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class RestFxRateWebServiceImpl implements FxRateWebService {

    public static final String FX_RATES_CACHE = "FX_RATES_REST_CACHE";


    private final  FxRatesServiceClient fxRatesServiceClient;
    private final FxRateMapper fxRateMapper;

    @Autowired
    public RestFxRateWebServiceImpl(FxRatesServiceClient fxRatesServiceClient,
            FxRateMapper fxRateMapper) {
        this.fxRatesServiceClient = fxRatesServiceClient;
        this.fxRateMapper = fxRateMapper;
    }

    @Override
    @Cacheable(value = FX_RATES_CACHE, key = "{ #sourceCcy, #targetCcy }")
    public List<CurrencyExchangeRate> getFxRate(final String sourceCcy, final String targetCcy) {
        log.info("Start calling webservice FxRate for {}/{}", sourceCcy, targetCcy);

        final LocalDate toDate = LocalDate.now();
        final LocalDate fromDate = toDate.minusDays(5);

        final FxRateFilter fxRateFilter = new FxRateFilter();
        fxRateFilter.setFromCcy(sourceCcy);
        fxRateFilter.setToCcy(targetCcy);
        fxRateFilter.setFxRateFromDate(fromDate);
        fxRateFilter.setFxRateToDate(toDate);

        List<FxRate> fxRates = fxRatesServiceClient.getValidFxRates(fxRateFilter);

        if (fxRates == null || fxRates.isEmpty()) {
            log.warn("No FX rates found for {} to {} between {} and {}", sourceCcy, targetCcy, fromDate, toDate);
            return new ArrayList<>();
        }

        fxRates.forEach(rate ->
                log.debug("Found rate: {} -> {}, date={}, time={}, rate={}",
                        rate.getFromCcy(), rate.getToCcy(),
                        rate.getFxRateDate(), rate.getFxRateTime(), rate.getBareRate())
        );


        FxRate latestFxRate = fxRates.stream()
                .max(Comparator
                        .comparing(FxRate::getFxRateDate)
                        .thenComparing(FxRate::getFxRateTime, Comparator.nullsLast(Comparator.naturalOrder())))
                .orElse(null);

        if (latestFxRate == null) {
            log.warn("Unable to determine latest FX rate for {}/{}", sourceCcy, targetCcy);
            return new ArrayList<>();
        }

        return fxRateMapper.toCurrencyExchangeRates(Collections.singletonList(latestFxRate));
    }



    @CacheEvict(allEntries = true, value = FX_RATES_CACHE)
    @Scheduled(fixedDelay = 24 * 60 * 60 * 1000)
    public void refreshCacheFxRate() {
        log.info("Fx rate cache has been cleared");
    }
}

