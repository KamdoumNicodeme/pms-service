package com.lombardinternational.casedefinition.adapter.api.web.mapper;

import com.lombardinternational.casedefinition.model.NumberInputField;
import org.mapstruct.Mapper;

import java.util.List;

/**
 * Mapper between ${@link NumberInputField} and ${@link com.lombardinternational.casedefinition.adapter.api.web.dto.NumberInputField}
 *
 * @author qemo
 */
@Mapper(componentModel="spring")
public interface NumberInputFieldMapper {

    List<NumberInputField> numberInputFieldFromDTO(List<com.lombardinternational.casedefinition.adapter.api.web.dto.NumberInputField> numberInputFields);
}
