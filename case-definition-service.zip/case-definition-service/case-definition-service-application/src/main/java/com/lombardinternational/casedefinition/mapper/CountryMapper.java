package com.lombardinternational.casedefinition.mapper;

import com.lombardinternational.casedefinition.model.Country;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring")
public interface CountryMapper {

    @Mapping(target = "isoCountryCode", source = "externalId")
    @Mapping(target = "countryName", source = "label")
    Country map(com.lombardinternational.clients.classapp.model.Country country);
}
