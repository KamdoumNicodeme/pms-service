package com.lombardinternational.casedefinition.adapter.api.web.dto;



import java.util.ArrayList;
import java.util.List;

public class Tab {
    private String tabId;
    private String label;
    private String i18NLabelKey;
    private int order;
    private Boolean triggersRecomputeScreen;
    private String type;
    private List<Group> groups = new ArrayList<>();
    private String displayIf;

    public Tab() {
    }

    public String getTabId() {
        return tabId;
    }

    public void setTabId(String tabId) {
        this.tabId = tabId;
    }

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public String getI18NLabelKey() {
        return i18NLabelKey;
    }

    public void setI18NLabelKey(String i18NLabelKey) {
        this.i18NLabelKey = i18NLabelKey;
    }

    public int getOrder() {
        return order;
    }

    public void setOrder(int order) {
        this.order = order;
    }

    public Boolean getTriggersRecomputeScreen() {
        return triggersRecomputeScreen;
    }

    public void setTriggersRecomputeScreen(Boolean triggersRecomputeScreen) {
        this.triggersRecomputeScreen = triggersRecomputeScreen;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public List<Group> getGroups() {
        return groups;
    }

    public void setGroups(List<Group> groups) {
        this.groups = groups;
    }

    public String getDisplayIf() {
        return displayIf;
    }

    public void setDisplayIf(String displayIf) {
        this.displayIf = displayIf;
    }

    @Override
    public String toString() {
        return "Tab{" +
            "tabId='" + tabId + '\'' +
            ", label='" + label + '\'' +
            ", i18NLabelKey='" + i18NLabelKey + '\'' +
            ", order=" + order +
            ", triggersRecomputeScreen=" + triggersRecomputeScreen +
            ", type='" + type + '\'' +
            ", groups=" + groups +
            ", displayIf='" + displayIf + '\'' +
            '}';
    }
}
