package com.lombardinternational.casedefinition.domain.api;

import com.lombardinternational.casedefinition.model.ScreenDescription;
import com.lombardinternational.casedefinition.model.WebForm;

public interface ScreenBusinessService {

    /**
     *
     * @param policyNumber a policy number
     * @param caseType   case type
     * @param businessTransactionNumber a business transaction number
     * @param webForm the ${@link WebForm}
     * @param screenDescriptionToBuild the ${@link ScreenDescription} to build
     * @return a ${@link ScreenDescription}
     */
    ScreenDescription computeScreenDescription(String policyNumber, String caseType, String businessTransactionNumber, WebForm webForm,
        ScreenDescription screenDescriptionToBuild/*, Map<String, CaseDeal> caseDeals*/);
    /**
     *
     * @param webForm a ${@link WebForm}
     * @param screenCheckList a ${@link ScreenDescription} with check list
     * @param screenToFill the ${@link ScreenDescription} to fill
     * @return a ${@link ScreenDescription}
     */
    ScreenDescription computeTaskScreen(String caseType, WebForm webForm, ScreenDescription screenCheckList, ScreenDescription screenToFill);

}
