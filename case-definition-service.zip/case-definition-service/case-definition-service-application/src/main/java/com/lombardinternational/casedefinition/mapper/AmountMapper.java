package com.lombardinternational.casedefinition.mapper;

import com.lombardinternational.clients.classapp.model.BusinessTransactionDetails;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import com.lombardinternational.casedefinition.model.Amount;

@Mapper(componentModel = "spring")
public interface AmountMapper {

    @Mapping(target = "isoCurrencyCode", source = "currency")
    Amount map(com.lombardinternational.clients.classapp.model.Amount amount);

    @Mapping(target = "isoCurrencyCode", source = "policyCurrency.isoCode")
    @Mapping(target = "quantity", source = "grossAmount")
    Amount mapFromBusinessTransaction(BusinessTransactionDetails businessTransaction);
}
