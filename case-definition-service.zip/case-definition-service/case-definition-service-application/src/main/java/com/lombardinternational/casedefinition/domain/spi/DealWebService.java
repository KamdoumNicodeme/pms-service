package com.lombardinternational.casedefinition.domain.spi;

import com.lombardinternational.casedefinition.model.CaseDeal;

import java.util.List;

public interface DealWebService {

    /**
     * Provides deals for a given case reference.
     * @param caseDealId
     * @return
     */
    List<CaseDeal> getCaseDeals(String caseDealId);
}
