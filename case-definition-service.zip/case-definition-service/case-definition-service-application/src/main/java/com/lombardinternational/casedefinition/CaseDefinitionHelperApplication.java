package com.lombardinternational.casedefinition;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;

@SpringBootApplication
public class CaseDefinitionHelperApplication extends SpringBootServletInitializer {

    @Override
    protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
        return application.sources(CaseDefinitionHelperApplication.class);
    }
    
    public static void main(String[] args) {
        SpringApplication.run(CaseDefinitionHelperApplication.class, args);
    }
}
