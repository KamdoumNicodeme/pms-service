package com.lombardinternational.casedefinition.mapper;

import com.lombardinternational.casedefinition.model.HardCode;
import org.mapstruct.MapperConfig;
import org.mapstruct.MappingInheritanceStrategy;

@MapperConfig(componentModel = "spring", mappingInheritanceStrategy = MappingInheritanceStrategy.AUTO_INHERIT_FROM_CONFIG)
public interface HardCodeMapperConfig {

    HardCode map(com.lombardinternational.clients.classapp.model.HardCode hardCode);
}
