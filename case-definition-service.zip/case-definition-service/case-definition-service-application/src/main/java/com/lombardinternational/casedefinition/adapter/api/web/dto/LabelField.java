package com.lombardinternational.casedefinition.adapter.api.web.dto;

public class LabelField extends Field {

    public LabelField() {
        super();
    }
}
