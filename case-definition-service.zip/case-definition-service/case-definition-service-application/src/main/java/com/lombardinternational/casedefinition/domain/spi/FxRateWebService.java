package com.lombardinternational.casedefinition.domain.spi;

import com.lombardinternational.casedefinition.model.CurrencyExchangeRate;

import java.util.List;

public interface FxRateWebService {

    /**
     * Get the last FX Rates known
     *
     * @return a {@link List<CurrencyExchangeRate>}
     * @exception RuntimeException
     *                Service which get FXRates returns errors
     */
     List<CurrencyExchangeRate> getFxRate(final String sourceCcy,final String targetCcy) throws RuntimeException;
}
