package com.lombardinternational.casedefinition.adapter.api.web.mapper;

import com.lombardinternational.casedefinition.model.WebFormField;
import org.mapstruct.MapperConfig;
import org.mapstruct.MappingInheritanceStrategy;

@MapperConfig(componentModel = "spring", mappingInheritanceStrategy = MappingInheritanceStrategy.AUTO_INHERIT_FROM_CONFIG)
public interface WebFormFieldMapper {

    WebFormField webFormFieldFromDTO(com.lombardinternational.casedefinition.adapter.api.web.dto.WebFormField webFormFieldDTO);
}
