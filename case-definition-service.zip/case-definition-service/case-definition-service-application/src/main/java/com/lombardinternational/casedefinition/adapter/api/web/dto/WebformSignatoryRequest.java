package com.lombardinternational.casedefinition.adapter.api.web.dto;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;

public class WebformSignatoryRequest {


    @NotBlank(message = "caseType is mandatory")
    protected String caseType;

    protected String policyNumber;

    protected String clientNumber;

    @Valid
    protected WebForm caseInitializationData;

    public String getCaseType() {
        return caseType;
    }

    public void setCaseType(String caseType) {
        this.caseType = caseType;
    }

    public String getPolicyNumber() {
        return policyNumber;
    }

    public void setPolicyNumber(String policyNumber) {
        this.policyNumber = policyNumber;
    }

    public String getClientNumber() {
        return clientNumber;
    }

    public void setClientNumber(String clientNumber) {
        this.clientNumber = clientNumber;
    }

    public WebForm getCaseInitializationData() {
        return caseInitializationData;
    }

    public void setCaseInitializationData(WebForm caseInitializationData) {
        this.caseInitializationData = caseInitializationData;
    }
}
