package com.lombardinternational.casedefinition.domain.api;

import java.util.List;

import com.lombardinternational.casedefinition.model.PolicyRole;

public interface PolicyRoleService {

	/**
	 * Get a boolean value that represent the non concordance between two list of {@link PolicyRole}
	 *
	 * @param policyRolesA
	 * @param policyRolesB
	 * @return
	 */
	Boolean policyRoleAreDifferent(List<? extends PolicyRole> policyRolesA, List<? extends PolicyRole> policyRolesB);
}
