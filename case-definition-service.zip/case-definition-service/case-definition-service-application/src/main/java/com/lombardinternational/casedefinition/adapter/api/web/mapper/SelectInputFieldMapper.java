package com.lombardinternational.casedefinition.adapter.api.web.mapper;

import com.lombardinternational.casedefinition.model.SelectInputField;
import org.mapstruct.Mapper;

import java.util.List;

/**
 * Mapper between ${@link SelectInputField} and ${@link com.lombardinternational.casedefinition.adapter.api.web.dto.SelectInputField}
 *
 * @author qemo
 */
@Mapper(componentModel = "spring", uses = {SelectInputFieldOptionMapper.class})
public interface SelectInputFieldMapper {

    List<SelectInputField> selectInputFieldFromDTO(List<com.lombardinternational.casedefinition.adapter.api.web.dto.SelectInputField> selectInputFieldDTOs);
}
