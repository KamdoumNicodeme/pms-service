package com.lombardinternational.casedefinition.adapter.api.web.mapper;

import com.lombardinternational.casedefinition.model.Tab;
import org.mapstruct.Mapper;

import java.util.List;

/**
 * Mapper between ${@link TabMapper} and ${@link com.lombardinternational.casedefinition.adapter.api.web.dto.Tab}
 *
 * @author qemo
 */
@Mapper(componentModel = "spring",uses = {GroupMapper.class})
public interface TabMapper {

    Tab tabFromDTO(com.lombardinternational.casedefinition.adapter.api.web.dto.Tab tabDTO);
    List<Tab> tabFromDTO(List<com.lombardinternational.casedefinition.adapter.api.web.dto.Tab> tabDTOs);

    com.lombardinternational.casedefinition.adapter.api.web.dto.Tab DTOFromTab(Tab tab);
    List<com.lombardinternational.casedefinition.adapter.api.web.dto.Tab> DTOFromTab(List<Tab> tabs);
}
