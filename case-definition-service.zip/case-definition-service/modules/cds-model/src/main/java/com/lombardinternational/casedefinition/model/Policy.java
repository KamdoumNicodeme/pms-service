package com.lombardinternational.casedefinition.model;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;

public class Policy {

    private String number;
    private String policyType;
    private String isoCurrencyCode;
    private String countryOfLawCode;
    private Boolean holderAndEBODifferent;
    private Boolean holderAndLifeAssuredDifferent;
    private Boolean beneficiaryAndLifeAssuredDifferent;
    private Boolean impactedByMadoff;
    private Boolean inForceforMoreThanOneYear;
    private String businessOrigin;
    private String businessRefererName;
    private String businessRefererCode;
    private Boolean irrevocableBeneficiary;
    private Calendar effectiveDate;
    private Boolean pledged;
    private List<Block> blocks;
    private List<Holder> holders;
    private List<LifeAssured> lifeAssureds;
    private List<Beneficiary> beneficiaries;
    private List<Beneficiary> irrevocableBeneficiaries;
    private List<EconomicBeneficiary> economicBeneficiaries;
    private List<Trust> trusts;
    private List<Trustee> trustees;
    private List<Settlor> settlors;
    private List<Proxy> proxies;
    private List<CessionHolder> cessionHolders;
    private List<PolicyLink> policyLinks;
    private Boolean brokerChangeWithinLast3Months;
    private Boolean heldILF;
    private String blocksAsString;
    private List<MoralPerson> moralPersons;
    private List<PhysicalPerson> physicalPersons;
    private String taxReserveBehavior;
    private Amount navInPolicyCurrency;
    private Amount navInEurCurrency;
    private Amount surrenderLiquidValue;
    private String lastReviewDate;
    private String sellingMeetingType;
    private Broker broker;

    public Policy() {

    }

    public String getNumber() {

        return number;
    }

    public void setNumber(String number) {

        this.number = number;
    }

    public String getPolicyType() {

        return policyType;
    }

    public void setPolicyType(String policyType) {

        this.policyType = policyType;
    }

    public String getIsoCurrencyCode() {

        return isoCurrencyCode;
    }

    public void setIsoCurrencyCode(String isoCurrencyCode) {

        this.isoCurrencyCode = isoCurrencyCode;
    }

    public String getCountryOfLawCode() {

        return countryOfLawCode;
    }

    public void setCountryOfLawCode(String countryOfLawCode) {

        this.countryOfLawCode = countryOfLawCode;
    }

    public Boolean isHolderAndEBODifferent() {

        return holderAndEBODifferent;
    }

    public Boolean isHolderAndLifeAssuredDifferent() {

        return holderAndLifeAssuredDifferent;
    }

    public Boolean isBeneficiaryAndLifeAssuredDifferent() {

        return beneficiaryAndLifeAssuredDifferent;
    }

    public void setHolderAndEBODifferent(Boolean holderAndEBODifferent) {

        this.holderAndEBODifferent = holderAndEBODifferent;
    }

    public Boolean getImpactedByMadoff() {

        return impactedByMadoff;
    }

    public void setImpactedByMadoff(Boolean impactedByMadoff) {

        this.impactedByMadoff = impactedByMadoff;
    }

    public String getBusinessOrigin() {

        return businessOrigin;
    }

    public void setBusinessOrigin(String businessOrigin) {

        this.businessOrigin = businessOrigin;
    }

    public String getBusinessRefererName() {

        return businessRefererName;
    }

    public void setBusinessRefererName(String businessRefererName) {

        this.businessRefererName = businessRefererName;
    }

    public String getBusinessRefererCode() {

        return businessRefererCode;
    }

    public void setBusinessRefererCode(String businessRefererCode) {

        this.businessRefererCode = businessRefererCode;
    }

    public Calendar getEffectiveDate() {

        return effectiveDate;
    }

    public void setEffectiveDate(Calendar effectiveDate) {

        this.effectiveDate = effectiveDate;
    }

    public List<Block> getBlocks() {

        return blocks;
    }

    public void setBlocks(List<Block> blocks) {

        this.blocks = blocks;
    }

    public List<Holder> getHolders() {

        return holders;
    }

    public void setHolders(List<Holder> holders) {

        this.holders = holders;
    }

    public Boolean getPledged() {

        return pledged;
    }

    public void setPledged(Boolean pledged) {

        this.pledged = pledged;
    }

    public Boolean isIrrevocableBeneficiary() {

        return irrevocableBeneficiary;
    }

    public List<Beneficiary> getBeneficiaries() {

        return beneficiaries;
    }

    public void setBeneficiaries(List<Beneficiary> beneficiaries) {

        this.beneficiaries = beneficiaries;
    }

    public List<Beneficiary> getIrrevocableBeneficiaries() {

        return irrevocableBeneficiaries;
    }

    public void setIrrevocableBeneficiaries(List<Beneficiary> irrevocableBeneficiaries) {

        this.irrevocableBeneficiaries = irrevocableBeneficiaries;
    }

    public Boolean getIrrevocableBeneficiary() {

        return irrevocableBeneficiary;
    }

    public void setIrrevocableBeneficiary(Boolean irrevocableBeneficiary) {

        this.irrevocableBeneficiary = irrevocableBeneficiary;
    }

    public List<EconomicBeneficiary> getEconomicBeneficiaries() {

        return economicBeneficiaries;
    }

    public void setEconomicBeneficiaries(List<EconomicBeneficiary> economicBeneficiaries) {

        this.economicBeneficiaries = economicBeneficiaries;
    }

    public List<Trust> getTrusts() {

        return trusts;
    }

    public void setTrusts(List<Trust> trusts) {

        this.trusts = trusts;
    }

    public List<Trustee> getTrustees() {

        return trustees;
    }

    public void setTrustees(List<Trustee> trustees) {

        this.trustees = trustees;
    }

    public List<Settlor> getSettlors() {

        return settlors;
    }

    public void setSettlors(List<Settlor> settlors) {

        this.settlors = settlors;
    }

    public List<Proxy> getProxies() {

        return proxies;
    }

    public void setProxies(List<Proxy> proxies) {

        this.proxies = proxies;
    }

    public Boolean isInForceforMoreThanOneYear() {

        return inForceforMoreThanOneYear;
    }

    public void setInForceforMoreThanOneYear(Boolean inForceforMoreThanOneYear) {

        this.inForceforMoreThanOneYear = inForceforMoreThanOneYear;
    }

    public void setBrokerChangeWithinLast3Months(Boolean brokerChangeWithinLast3Months) {

        this.brokerChangeWithinLast3Months = brokerChangeWithinLast3Months;
    }

    public Boolean isBrokerChangeWithinLast3Months() {

        return brokerChangeWithinLast3Months;
    }

    public Boolean isHeldILF() {

        return heldILF;
    }

    public void setHeldILF(Boolean heldILF) {

        this.heldILF = heldILF;
    }

    /**
     * Provide the blocks of the policy as String
     *
     * @return
     */
    public String getBlocksAsString() {

        final StringBuilder blocksStringBuilder = new StringBuilder();
        blocks.forEach(block -> blocksStringBuilder.append(block.toString()).append("\n"));
        return blocksStringBuilder.toString();
    }

    public List<MoralPerson> getMoralPersons() {

        return moralPersons;
    }

    public void setMoralPersons(List<MoralPerson> moralPersons) {

        this.moralPersons = moralPersons;
    }

    public List<PhysicalPerson> getPhysicalPersons() {

        return physicalPersons;
    }

    public void setPhysicalPersons(List<PhysicalPerson> physicalPersons) {

        this.physicalPersons = physicalPersons;
    }

    public List<CessionHolder> getCessionHolders() {

        return cessionHolders;
    }

    public void setCessionHolders(List<CessionHolder> cessionHolders) {

        this.cessionHolders = cessionHolders;
    }

    public List<PolicyLink> getPolicyLinks() {
        return policyLinks;
    }

    public void setPolicyLinks(final List<PolicyLink> policyLinks) {
        this.policyLinks = policyLinks;
    }

    public String getTaxReserveBehavior() {

        return taxReserveBehavior;
    }

    public void setTaxReserveBehavior(String taxReserveBehavior) {

        this.taxReserveBehavior = taxReserveBehavior;
    }

    public Amount getNavInPolicyCurrency() {
        return navInPolicyCurrency;
    }

    public void setNavInPolicyCurrency(final Amount navInPolicyCurrency) {
        this.navInPolicyCurrency = navInPolicyCurrency;
    }

    public Amount getNavInEurCurrency() {

        return navInEurCurrency;
    }

    public void setNavInEurCurrency(Amount navInEurCurrency) {

        this.navInEurCurrency = navInEurCurrency;
    }

    public Amount getSurrenderLiquidValue() {

        return surrenderLiquidValue;
    }

    public void setSurrenderLiquidValue(Amount surrenderLiquidValue) {

        this.surrenderLiquidValue = surrenderLiquidValue;
    }

    public List<LifeAssured> getLifeAssureds() {

        return lifeAssureds;
    }

    public void setLifeAssureds(List<LifeAssured> lifeAssureds) {

        this.lifeAssureds = lifeAssureds;
    }

    public void setHolderAndLifeAssuredDifferent(Boolean holderAndLifeAssuredDifferent) {

        this.holderAndLifeAssuredDifferent = holderAndLifeAssuredDifferent;
    }

    public void setBeneficiaryAndLifeAssuredDifferent(Boolean beneficiaryAndLifeAssuredDifferent) {

        this.beneficiaryAndLifeAssuredDifferent = beneficiaryAndLifeAssuredDifferent;
    }

    public String getLastReviewDate() {
        return lastReviewDate;
    }

    public void setLastReviewDate(String lastReviewDate) {
        this.lastReviewDate = lastReviewDate;
    }


    public String getSellingMeetingType() {
        return sellingMeetingType;
    }

    public void setSellingMeetingType(String sellingMeetingType) {
        this.sellingMeetingType = sellingMeetingType;
    }

    public Broker getBroker() {
        return this.broker;
    }

    public void setBroker(Broker broker) {
        this.broker = broker;
    }

    @Override
    public String toString() {

        final SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
        final String effectiveDateFormatted = effectiveDate != null ? simpleDateFormat.format(effectiveDate.getTime()) : null;
        return "Policy [number=" + number + ", policyType=" + policyType + ", isoCurrencyCode=" + isoCurrencyCode + ", countryOfLawCode="
                + countryOfLawCode + ", holderAndEBODifferent="
                + holderAndEBODifferent + ", impactedByMadoff=" + impactedByMadoff + ", businessOrigin=" + businessOrigin
                + ", businessRefererName=" + businessRefererName + ", businessRefererCode=" + businessRefererCode + ", effectiveDate="
                + effectiveDateFormatted + ", taxReserveBehavior=" + taxReserveBehavior + ", lastReviewDate=" + lastReviewDate
                + ", sellingMeetingType=" + sellingMeetingType + "]";
    }
}
