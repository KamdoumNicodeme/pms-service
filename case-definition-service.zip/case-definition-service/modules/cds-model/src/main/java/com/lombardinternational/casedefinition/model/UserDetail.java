package com.lombardinternational.casedefinition.model;

public class UserDetail {

    private String userId;
    private String login;
    private String firstName;
    private String lastName;
    private String userRole;
    private String clientNumber;
    private Boolean authorizedSigntory;
    private String phoneNumber;
    private String email;

    public UserDetail() {
        // TODO Auto-generated constructor stub
    }

    public String getUserId() {

        return userId;
    }

    public void setUserId(String userId) {

        this.userId = userId;
    }

    public String getLogin() {

        return login;
    }

    public void setLogin(String login) {

        this.login = login;
    }

    public String getFirstName() {

        return firstName;
    }

    public void setFirstName(String firstName) {

        this.firstName = firstName;
    }

    public String getLastName() {

        return lastName;
    }

    public void setLastName(String lastName) {

        this.lastName = lastName;
    }

    public String getUserRole() {

        return userRole;
    }

    public void setUserRole(String userRole) {

        this.userRole = userRole;
    }

    public String getClientNumber() {

        return clientNumber;
    }

    public void setClientNumber(String clientNumber) {

        this.clientNumber = clientNumber;
    }

    public Boolean getAuthorizedSigntory() {

        return authorizedSigntory;
    }

    public void setAuthorizedSigntory(Boolean authorizedSigntory) {

        this.authorizedSigntory = authorizedSigntory;
    }

    public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	@Override
    public String toString() {

        return "UserDetail [userId=" + userId + ", login=" + login + ", firstName=" + firstName + ", lastName=" + lastName + ", userRole="
                + userRole + ", clientNumber=" + clientNumber + ", authorizedSigntory=" + authorizedSigntory 
                + ", phoneNumber=" + phoneNumber 
                + ", email=" + email + "]";
    }

}
