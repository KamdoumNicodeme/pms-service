package com.lombardinternational.casedefinition.model;

import java.math.BigDecimal;
import java.util.Calendar;

/**
 * Object that represent a ${@link Penalty}
 *
 * @author qemo
 */
public class Penalty {
    private Calendar definitionDate;
    private String penaltyCalculationBasis;
    private String numberDaysLeft;
    private BigDecimal defaultRate;
    private BigDecimal quarterDefaultRate;
    private String delayDuration;
    private String delayDurationUnit;
    private String duration;
    private String durationUnit;
    private BigDecimal applicationRate;
    private BigDecimal quarterApplicationRate;
    private Calendar startDate;
    private Calendar endDate;
    private String penaltyType;
    private Amount amount;
    private Broker payeeBroker;
    private InvestmentManager payeeInvestmentManager;
    private BrokerPayee payeeBrokerPayee;

    public Calendar getDefinitionDate() {
        return definitionDate;
    }

    public void setDefinitionDate(Calendar definitionDate) {
        this.definitionDate = definitionDate;
    }

    public String getPenaltyCalculationBasis() {
        return penaltyCalculationBasis;
    }

    public void setPenaltyCalculationBasis(String penaltyCalculationBasis) {
        this.penaltyCalculationBasis = penaltyCalculationBasis;
    }

    public String getNumberDaysLeft() {
        return numberDaysLeft;
    }

    public void setNumberDaysLeft(String numberDaysLeft) {
        this.numberDaysLeft = numberDaysLeft;
    }

    public BigDecimal getDefaultRate() {
        return defaultRate;
    }

    public void setDefaultRate(BigDecimal defaultRate) {
        this.defaultRate = defaultRate;
    }

    public BigDecimal getQuarterDefaultRate() {
        return quarterDefaultRate;
    }

    public void setQuarterDefaultRate(BigDecimal quarterDefaultRate) {
        this.quarterDefaultRate = quarterDefaultRate;
    }

    public String getDelayDuration() {
        return delayDuration;
    }

    public void setDelayDuration(String delayDuration) {
        this.delayDuration = delayDuration;
    }

    public String getDelayDurationUnit() {
        return delayDurationUnit;
    }

    public void setDelayDurationUnit(String delayDurationUnit) {
        this.delayDurationUnit = delayDurationUnit;
    }

    public String getDuration() {
        return duration;
    }

    public void setDuration(String duration) {
        this.duration = duration;
    }

    public String getDurationUnit() {
        return durationUnit;
    }

    public void setDurationUnit(String durationUnit) {
        this.durationUnit = durationUnit;
    }

    public BigDecimal getApplicationRate() {
        return applicationRate;
    }

    public void setApplicationRate(BigDecimal applicationRate) {
        this.applicationRate = applicationRate;
    }

    public BigDecimal getQuarterApplicationRate() {
        return quarterApplicationRate;
    }

    public void setQuarterApplicationRate(BigDecimal quarterApplicationRate) {
        this.quarterApplicationRate = quarterApplicationRate;
    }

    public Calendar getStartDate() {
        return startDate;
    }

    public void setStartDate(Calendar startDate) {
        this.startDate = startDate;
    }

    public Calendar getEndDate() {
        return endDate;
    }

    public void setEndDate(Calendar endDate) {
        this.endDate = endDate;
    }

    public String getPenaltyType() {
        return penaltyType;
    }

    public void setPenaltyType(String penaltyType) {
        this.penaltyType = penaltyType;
    }

    public Amount getAmount() {
        return amount;
    }

    public void setAmount(Amount amount) {
        this.amount = amount;
    }

    public Broker getPayeeBroker() {
        return payeeBroker;
    }

    public void setPayeeBroker(Broker payeeBroker) {
        this.payeeBroker = payeeBroker;
    }

    public InvestmentManager getPayeeInvestmentManager() {
        return payeeInvestmentManager;
    }

    public void setPayeeInvestmentManager(InvestmentManager payeeInvestmentManager) {
        this.payeeInvestmentManager = payeeInvestmentManager;
    }

    public BrokerPayee getPayeeBrokerPayee() {
        return payeeBrokerPayee;
    }

    public void setPayeeBrokerPayee(BrokerPayee payeeBrokerPayee) {
        this.payeeBrokerPayee = payeeBrokerPayee;
    }
}
