package com.lombardinternational.casedefinition.model;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class ScreenDescription {

    private Calendar loadTimeStamp;
    private String screenId;
    private ScreenDescription inputedScreenDescription;
    private List<Tab> tabs;

    public ScreenDescription() {
    }

    public Calendar getLoadTimeStamp() {

        return loadTimeStamp;
    }

    public void setLoadTimeStamp(Calendar value) {

        this.loadTimeStamp = value;
    }

    public String getScreenId() {

        return screenId;
    }

    public void setScreenId(String value) {

        this.screenId = value;
    }

    public ScreenDescription getInputedScreenDescription() {

        return inputedScreenDescription;
    }

    public void setInputedScreenDescription(ScreenDescription value) {

        this.inputedScreenDescription = value;
    }

    public List<Tab> getTabs() {

        if (tabs == null) {
            tabs = new ArrayList<Tab>();
        }
        return this.tabs;
    }

    public void setTabs(List<Tab> tabs) {

        this.tabs = tabs;
    }

    @Override
    public String toString() {

        return "ScreenDescription [loadTimeStamp=" + loadTimeStamp + ", screenId=" + screenId + ", inputedScreenDescription="
                + inputedScreenDescription + ", tabs=" + tabs + "]";
    }

    // Add helper methods on sd. GetGroup, ....
    public Tab getTabWithId(String id) {

        return tabs.stream().filter(t -> t.getTabId().equalsIgnoreCase(id)).findFirst().get();
    }

    public Group getGroupWithId(String id) {

        return tabs.stream().flatMap(t -> t.getGroups().stream()).filter(g -> g.getGroupId().equalsIgnoreCase(id)).findFirst().get();
    }

    public Field getFieldWithId(String id) {

        return tabs.stream().flatMap(t -> t.getGroups().stream()).filter(g -> g != null).flatMap(g -> g.getFields().stream())
                .filter(f -> f.getFieldId().equalsIgnoreCase(id)).findFirst().get();
    }

}
