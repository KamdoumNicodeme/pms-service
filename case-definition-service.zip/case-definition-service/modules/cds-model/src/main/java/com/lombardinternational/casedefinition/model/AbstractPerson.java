package com.lombardinternational.casedefinition.model;

import java.util.List;
import java.util.Objects;

public abstract class AbstractPerson {

    private String thirdPartyId;
    private Address address;
    private String fatcaStatus;
    private String subType;
    private SourceOfFunds sourceOfFunds;
    private List<PersistedBlock> persistedBlocks;
    private ProfessionIndustrySector professionIndustrySector;

    public String getThirdPartyId() {

        return thirdPartyId;
    }

    public void setThirdPartyId(String thirdPartyId) {

        this.thirdPartyId = thirdPartyId;
    }

    public Address getAddress() {

        return address;
    }

    public void setAddress(Address address) {

        this.address = address;
    }

    public String getFatcaStatus() {

        return fatcaStatus;
    }

    public void setFatcaStatus(String fatcaStatus) {

        this.fatcaStatus = fatcaStatus;
    }

    public String getSubType() {

        return subType;
    }

    public void setSubType(String subType) {

        this.subType = subType;
    }

    public SourceOfFunds getSourceOfFunds() {

        return sourceOfFunds;
    }

    public void setSourceOfFunds(SourceOfFunds sourceOfFunds) {

        this.sourceOfFunds = sourceOfFunds;
    }

    public List<PersistedBlock> getPersistedBlocks() {
        return persistedBlocks;
    }

    public void setPersistedBlocks(List<PersistedBlock> persistedBlocks) {
        this.persistedBlocks = persistedBlocks;
    }

    public ProfessionIndustrySector getProfessionIndustrySector() {
        return professionIndustrySector;
    }

    public void setProfessionIndustrySector(final ProfessionIndustrySector professionIndustrySector) {
        this.professionIndustrySector = professionIndustrySector;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o)
            return true;
        if (o == null || getClass() != o.getClass())
            return false;
        AbstractPerson that = (AbstractPerson) o;
        return thirdPartyId.equals(that.thirdPartyId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(thirdPartyId);
    }

    @Override
    public String toString() {
        return "AbstractPerson{" +
                "thirdPartyId='" + thirdPartyId + '\'' +
                ", address=" + address +
                ", fatcaStatus='" + fatcaStatus + '\'' +
                ", subType='" + subType + '\'' +
                ", sourceOfFunds=" + sourceOfFunds +
                ", persistedBlocks=" + persistedBlocks +
                ", professionIndustrySector=" + professionIndustrySector +
                '}';
    }

}
