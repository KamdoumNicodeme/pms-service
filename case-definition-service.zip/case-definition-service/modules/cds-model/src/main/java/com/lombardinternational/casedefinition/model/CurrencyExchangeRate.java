package com.lombardinternational.casedefinition.model;

import java.math.BigDecimal;
import java.util.Calendar;

public class CurrencyExchangeRate {

    private String provider;
    private Calendar rateDate;
    private BigDecimal rate;
    private String baseIsoCurrencyCode;
    private String quotedIsoCurrencyCode;

    public String getProvider() {
        return provider;
    }

    public void setProvider(String provider) {
        this.provider = provider;
    }

    public Calendar getRateDate() {
        return rateDate;
    }

    public void setRateDate(Calendar rateDate) {
        this.rateDate = rateDate;
    }

    public BigDecimal getRate() {
        return rate;
    }

    public void setRate(BigDecimal rate) {
        this.rate = rate;
    }

    public String getBaseIsoCurrencyCode() {
        return baseIsoCurrencyCode;
    }

    public void setBaseIsoCurrencyCode(String baseIsoCurrencyCode) {
        this.baseIsoCurrencyCode = baseIsoCurrencyCode;
    }

    public String getQuotedIsoCurrencyCode() {
        return quotedIsoCurrencyCode;
    }

    public void setQuotedIsoCurrencyCode(String quotedIsoCurrencyCode) {
        this.quotedIsoCurrencyCode = quotedIsoCurrencyCode;
    }
}
