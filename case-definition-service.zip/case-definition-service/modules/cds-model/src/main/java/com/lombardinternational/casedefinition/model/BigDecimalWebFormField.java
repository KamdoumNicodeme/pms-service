package com.lombardinternational.casedefinition.model;

import java.math.BigDecimal;

public class BigDecimalWebFormField extends WebFormField {

    private BigDecimal value;

    public BigDecimalWebFormField() {
        // TODO Auto-generated constructor stub
    }

    public BigDecimal getValue() {

        return value;
    }

    public void setValue(BigDecimal value) {

        this.value = value;
    }

    @Override
    public String toString() {

        return "BigDecimalWebFormField [" + super.toString() + " - value=" + value + "]";
    }

}
