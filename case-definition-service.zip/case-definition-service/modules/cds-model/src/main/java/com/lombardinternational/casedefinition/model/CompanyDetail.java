package com.lombardinternational.casedefinition.model;

public class CompanyDetail {

    private String companyId;
    private String companyName;
    private String loginPrefix;
    private String partnerType;

    public CompanyDetail() {
        // TODO Auto-generated constructor stub
    }

    public String getCompanyId() {

        return companyId;
    }

    public void setCompanyId(String companyId) {

        this.companyId = companyId;
    }

    public String getCompanyName() {

        return companyName;
    }

    public void setCompanyName(String companyName) {

        this.companyName = companyName;
    }

    public String getLoginPrefix() {

        return loginPrefix;
    }

    public void setLoginPrefix(String loginPrefix) {

        this.loginPrefix = loginPrefix;
    }

    public String getPartnerType() {

        return partnerType;
    }

    public void setPartnerType(String partnerType) {

        this.partnerType = partnerType;
    }

    @Override
    public String toString() {

        return "CompanyDetail [companyId=" + companyId + ", companyName=" + companyName + ", loginPrefix=" + loginPrefix + ", partnerType="
                + partnerType + "]";
    }

}
