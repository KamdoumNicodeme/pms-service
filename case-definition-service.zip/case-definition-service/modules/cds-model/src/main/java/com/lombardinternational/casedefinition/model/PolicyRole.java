package com.lombardinternational.casedefinition.model;

import java.util.List;
import java.util.Objects;

public class PolicyRole {

    private String roleId;
    private String economicSector;
    private List<MoralPerson> moralPersons;
    private List<PhysicalPerson> physicalPersons;
    private List<AbstractPerson> thirdParties;

    public PolicyRole() {

        // TODO Auto-generated constructor stub
    }

    public String getEconomicSector() {

        return economicSector;
    }

    public void setEconomicSector(String economicSector) {

        this.economicSector = economicSector;
    }

    public List<MoralPerson> getMoralPersons() {

        return moralPersons;
    }

    public void setMoralPersons(List<MoralPerson> moralPersons) {

        this.moralPersons = moralPersons;
    }

    public List<PhysicalPerson> getPhysicalPersons() {

        return physicalPersons;
    }

    public void setPhysicalPersons(List<PhysicalPerson> physicalPersons) {

        this.physicalPersons = physicalPersons;
    }
    public List<AbstractPerson> getThirdParties() {
        return thirdParties;
    }

    public void setThirdParties(List<AbstractPerson> thirdParties) {
        this.thirdParties = thirdParties;
    }
    public String getRoleId() {

        return roleId;
    }

    public void setRoleId(String roleId) {

        this.roleId = roleId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o)
            return true;
        if (o == null || getClass() != o.getClass())
            return false;
        PolicyRole that = (PolicyRole) o;
        return roleId.equals(that.roleId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(roleId);
    }

    @Override
    public String toString() {
        return "PolicyRole{" +
            "roleId='" + roleId + '\'' +
            ", economicSector='" + economicSector + '\'' +
            ", thirdParties=" + thirdParties +
            ", moralPersons=" + moralPersons +
            ", physicalPersons=" + physicalPersons +
            '}';
    }
}
