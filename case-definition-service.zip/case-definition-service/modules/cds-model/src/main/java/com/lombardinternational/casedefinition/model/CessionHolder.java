package com.lombardinternational.casedefinition.model;

public class CessionHolder extends PolicyRole {

}
