package com.lombardinternational.casedefinition.model;

public class PolicyServicingBusinessTransaction extends BusinessTransaction {

}
