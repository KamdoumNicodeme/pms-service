package com.lombardinternational.casedefinition.model;

public class Country {

    private String isoCountryCode;
    private String countryName;

    public Country() {
        // TODO Auto-generated constructor stub
    }

    public String getIsoCountryCode() {

        return isoCountryCode;
    }

    public void setIsoCountryCode(String isoCountryCode) {

        this.isoCountryCode = isoCountryCode;
    }

    public String getCountryName() {

        return countryName;
    }

    public void setCountryName(String countryName) {

        this.countryName = countryName;
    }

    @Override
    public String toString() {

        return "Country [isoCountryCode=" + isoCountryCode + ", countryName=" + countryName + "]";
    }

}
