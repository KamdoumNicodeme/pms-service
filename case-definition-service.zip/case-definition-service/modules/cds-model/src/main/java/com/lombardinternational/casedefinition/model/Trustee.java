package com.lombardinternational.casedefinition.model;

public class Trustee extends PolicyRole {

}
