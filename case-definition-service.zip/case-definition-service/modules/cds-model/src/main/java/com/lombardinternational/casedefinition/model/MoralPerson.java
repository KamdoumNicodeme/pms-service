package com.lombardinternational.casedefinition.model;

public class MoralPerson extends AbstractPerson {

    private String name;
    private String companyName;
    private String companyLegalForm;

    public MoralPerson() {
        // TODO Auto-generated constructor stub
    }

    public String getName() {

        return name;
    }

    public void setName(String name) {

        this.name = name;
    }

    public String getCompanyName() {

        return companyName;
    }

    public void setCompanyName(String companyName) {

        this.companyName = companyName;
    }

    public String getCompanyLegalForm() {

        return companyLegalForm;
    }

    public void setCompanyLegalForm(String companyLegalForm) {

        this.companyLegalForm = companyLegalForm;
    }

    @Override
    public String toString() {

        return "MoralPerson [" + super.toString() + ", name=" + name + ", companyName=" + companyName + ", companyLegalForm=" + companyLegalForm + "]";
    }

}
