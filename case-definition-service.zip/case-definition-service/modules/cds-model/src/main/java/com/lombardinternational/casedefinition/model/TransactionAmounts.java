package com.lombardinternational.casedefinition.model;

import java.math.BigDecimal;

public class TransactionAmounts {

    private Amount grossAmount;
    private Amount grossAmountBaseCurrency;
    private Amount differenceAmount;
    private Amount amount;
    private Amount deathGainAmount;
    private Amount fundingDifferenceAmount;
    private Amount interestAmount;
    private Amount transactionAmount;
    private Amount taxableAmount;
    private Amount taxAmount;
    private Amount afterTaxAmount;
    private Amount premiumAmount;
    private Amount premiumAfterTaxAmount;
    private BigDecimal marketingAllowanceRate;
    private Amount marketingAllowanceAmount;
    private BigDecimal salesMarginRate;
    private Amount salesMarginAmount;
    private Amount feeAmount;
    private Amount penaltyAmount;
    private Amount outstandingFeeAmount;
    private BigDecimal allocationRate;
    private BigDecimal initialCharges;
    private Amount investedAmount;
    private Amount expectedAmount;
    private Amount investAmount;
    private BigDecimal bonusAllocation;
    private BigDecimal solvencyMarginRate;
    private Amount additionSplitAmount;
    private Amount toInvestWithNOTaxAmount;
    private BigDecimal companyCustodyFeeRate;
    private Amount fixedChargeAmount;
    private BigDecimal initialFeeRate;
    private Amount premiumExpectedAmount;
    private String renewalExpenseType;
    private BigDecimal taxRate;
    private BigDecimal trailerFeeRate;
    private String couponPaymentIsoCurrency;
    private Amount annualCashProvisional;
    private Amount annualCash;

    public TransactionAmounts() {
        // TODO Auto-generated constructor stub
    }

    public Amount getGrossAmount() {

        return grossAmount;
    }

    public void setGrossAmount(Amount grossAmount) {

        this.grossAmount = grossAmount;
    }

    public Amount getGrossAmountBaseCurrency() {

        return grossAmountBaseCurrency;
    }

    public void setGrossAmountBaseCurrency(Amount grossAmountBaseCurrency) {

        this.grossAmountBaseCurrency = grossAmountBaseCurrency;
    }

    public Amount getDifferenceAmount() {

        return differenceAmount;
    }

    public void setDifferenceAmount(Amount differenceAmount) {

        this.differenceAmount = differenceAmount;
    }

    public Amount getAmount() {

        return amount;
    }

    public void setAmount(Amount amount) {

        this.amount = amount;
    }

    public Amount getDeathGainAmount() {

        return deathGainAmount;
    }

    public void setDeathGainAmount(Amount deathGainAmount) {

        this.deathGainAmount = deathGainAmount;
    }

    public Amount getFundingDifferenceAmount() {

        return fundingDifferenceAmount;
    }

    public void setFundingDifferenceAmount(Amount fundingDifferenceAmount) {

        this.fundingDifferenceAmount = fundingDifferenceAmount;
    }

    public Amount getInterestAmount() {

        return interestAmount;
    }

    public void setInterestAmount(Amount interestAmount) {

        this.interestAmount = interestAmount;
    }

    public Amount getTransactionAmount() {

        return transactionAmount;
    }

    public void setTransactionAmount(Amount transactionAmount) {

        this.transactionAmount = transactionAmount;
    }

    public Amount getTaxableAmount() {

        return taxableAmount;
    }

    public void setTaxableAmount(Amount taxableAmount) {

        this.taxableAmount = taxableAmount;
    }

    public Amount getTaxAmount() {

        return taxAmount;
    }

    public void setTaxAmount(Amount taxAmount) {

        this.taxAmount = taxAmount;
    }

    public Amount getAfterTaxAmount() {

        return afterTaxAmount;
    }

    public void setAfterTaxAmount(Amount afterTaxAmount) {

        this.afterTaxAmount = afterTaxAmount;
    }

    public Amount getPremiumAmount() {

        return premiumAmount;
    }

    public void setPremiumAmount(Amount premiumAmount) {

        this.premiumAmount = premiumAmount;
    }

    public Amount getPremiumAfterTaxAmount() {

        return premiumAfterTaxAmount;
    }

    public void setPremiumAfterTaxAmount(Amount premiumAfterTaxAmount) {

        this.premiumAfterTaxAmount = premiumAfterTaxAmount;
    }

    public BigDecimal getMarketingAllowanceRate() {

        return marketingAllowanceRate;
    }

    public void setMarketingAllowanceRate(BigDecimal marketingAllowanceRate) {

        this.marketingAllowanceRate = marketingAllowanceRate;
    }

    public Amount getMarketingAllowanceAmount() {

        return marketingAllowanceAmount;
    }

    public void setMarketingAllowanceAmount(Amount marketingAllowanceAmount) {

        this.marketingAllowanceAmount = marketingAllowanceAmount;
    }

    public BigDecimal getSalesMarginRate() {

        return salesMarginRate;
    }

    public void setSalesMarginRate(BigDecimal salesMarginRate) {

        this.salesMarginRate = salesMarginRate;
    }

    public Amount getSalesMarginAmount() {

        return salesMarginAmount;
    }

    public void setSalesMarginAmount(Amount salesMarginAmount) {

        this.salesMarginAmount = salesMarginAmount;
    }

    public Amount getFeeAmount() {

        return feeAmount;
    }

    public void setFeeAmount(Amount feeAmount) {

        this.feeAmount = feeAmount;
    }

    public Amount getPenaltyAmount() {

        return penaltyAmount;
    }

    public void setPenaltyAmount(Amount penaltyAmount) {

        this.penaltyAmount = penaltyAmount;
    }

    public Amount getOutstandingFeeAmount() {

        return outstandingFeeAmount;
    }

    public void setOutstandingFeeAmount(Amount outstandingFeeAmount) {

        this.outstandingFeeAmount = outstandingFeeAmount;
    }

    public BigDecimal getAllocationRate() {

        return allocationRate;
    }

    public void setAllocationRate(BigDecimal allocationRate) {

        this.allocationRate = allocationRate;
    }

    public BigDecimal getInitialCharges() {

        return initialCharges;
    }

    public void setInitialCharges(BigDecimal initialCharges) {

        this.initialCharges = initialCharges;
    }

    public Amount getInvestedAmount() {

        return investedAmount;
    }

    public void setInvestedAmount(Amount investedAmount) {

        this.investedAmount = investedAmount;
    }

    public Amount getExpectedAmount() {

        return expectedAmount;
    }

    public void setExpectedAmount(Amount expectedAmount) {

        this.expectedAmount = expectedAmount;
    }

    public Amount getInvestAmount() {

        return investAmount;
    }

    public void setInvestAmount(Amount investAmount) {

        this.investAmount = investAmount;
    }

    public BigDecimal getBonusAllocation() {

        return bonusAllocation;
    }

    public void setBonusAllocation(BigDecimal bonusAllocation) {

        this.bonusAllocation = bonusAllocation;
    }

    public BigDecimal getSolvencyMarginRate() {

        return solvencyMarginRate;
    }

    public void setSolvencyMarginRate(BigDecimal solvencyMarginRate) {

        this.solvencyMarginRate = solvencyMarginRate;
    }

    public Amount getAdditionSplitAmount() {

        return additionSplitAmount;
    }

    public void setAdditionSplitAmount(Amount additionSplitAmount) {

        this.additionSplitAmount = additionSplitAmount;
    }

    public Amount getToInvestWithNOTaxAmount() {

        return toInvestWithNOTaxAmount;
    }

    public void setToInvestWithNOTaxAmount(Amount toInvestWithNOTaxAmount) {

        this.toInvestWithNOTaxAmount = toInvestWithNOTaxAmount;
    }

    public BigDecimal getCompanyCustodyFeeRate() {

        return companyCustodyFeeRate;
    }

    public void setCompanyCustodyFeeRate(BigDecimal companyCustodyFeeRate) {

        this.companyCustodyFeeRate = companyCustodyFeeRate;
    }

    public Amount getFixedChargeAmount() {

        return fixedChargeAmount;
    }

    public void setFixedChargeAmount(Amount fixedChargeAmount) {

        this.fixedChargeAmount = fixedChargeAmount;
    }

    public BigDecimal getInitialFeeRate() {

        return initialFeeRate;
    }

    public void setInitialFeeRate(BigDecimal initialFeeRate) {

        this.initialFeeRate = initialFeeRate;
    }

    public Amount getPremiumExpectedAmount() {

        return premiumExpectedAmount;
    }

    public void setPremiumExpectedAmount(Amount premiumExpectedAmount) {

        this.premiumExpectedAmount = premiumExpectedAmount;
    }

    public String getRenewalExpenseType() {

        return renewalExpenseType;
    }

    public void setRenewalExpenseType(String renewalExpenseType) {

        this.renewalExpenseType = renewalExpenseType;
    }

    public BigDecimal getTaxRate() {

        return taxRate;
    }

    public void setTaxRate(BigDecimal taxRate) {

        this.taxRate = taxRate;
    }

    public BigDecimal getTrailerFeeRate() {

        return trailerFeeRate;
    }

    public void setTrailerFeeRate(BigDecimal trailerFeeRate) {

        this.trailerFeeRate = trailerFeeRate;
    }

    public String getCouponPaymentIsoCurrency() {

        return couponPaymentIsoCurrency;
    }

    public void setCouponPaymentIsoCurrency(String couponPaymentIsoCurrency) {

        this.couponPaymentIsoCurrency = couponPaymentIsoCurrency;
    }

    public Amount getAnnualCashProvisional() {

        return annualCashProvisional;
    }

    public void setAnnualCashProvisional(Amount annualCashProvisional) {

        this.annualCashProvisional = annualCashProvisional;
    }

    public Amount getAnnualCash() {

        return annualCash;
    }

    public void setAnnualCash(Amount annualCash) {

        this.annualCash = annualCash;
    }

    @Override
    public String toString() {

        return "TransactionAmounts [grossAmount=" + grossAmount + ", grossAmountBaseCurrency=" + grossAmountBaseCurrency + ", differenceAmount="
                + differenceAmount + ", amount=" + amount + ", deathGainAmount=" + deathGainAmount + ", fundingDifferenceAmount="
                + fundingDifferenceAmount + ", interestAmount=" + interestAmount + ", transactionAmount=" + transactionAmount + ", taxableAmount="
                + taxableAmount + ", taxAmount=" + taxAmount + ", afterTaxAmount=" + afterTaxAmount + ", premiumAmount=" + premiumAmount
                + ", premiumAfterTaxAmount=" + premiumAfterTaxAmount + ", marketingAllowanceRate=" + marketingAllowanceRate
                + ", marketingAllowanceAmount=" + marketingAllowanceAmount + ", salesMarginRate=" + salesMarginRate + ", salesMarginAmount="
                + salesMarginAmount + ", feeAmount=" + feeAmount + ", penaltyAmount=" + penaltyAmount + ", outstandingFeeAmount="
                + outstandingFeeAmount + ", allocationRate=" + allocationRate + ", initialCharges=" + initialCharges + ", investedAmount="
                + investedAmount + ", expectedAmount=" + expectedAmount + ", investAmount=" + investAmount + ", bonusAllocation=" + bonusAllocation
                + ", solvencyMarginRate=" + solvencyMarginRate + ", additionSplitAmount=" + additionSplitAmount + ", toInvestWithNOTaxAmount="
                + toInvestWithNOTaxAmount + ", companyCustodyFeeRate=" + companyCustodyFeeRate + ", fixedChargeAmount=" + fixedChargeAmount
                + ", initialFeeRate=" + initialFeeRate + ", premiumExpectedAmount=" + premiumExpectedAmount + ", renewalExpenseType="
                + renewalExpenseType + ", taxRate=" + taxRate + ", trailerFeeRate=" + trailerFeeRate + ", couponPaymentIsoCurrency="
                + couponPaymentIsoCurrency + ", annualCashProvisional=" + annualCashProvisional + ", annualCash=" + annualCash + "]";
    }

}
