package com.lombardinternational.casedefinition.model;

public abstract class Field {

    private String fieldId;
    private String label;
    private String i18NLabelKey;
    private int order;
    private boolean enabled;
    private boolean mandatory;
    private Boolean multiple;
    private Integer maxMultiple;
    private String selectedValue;
    private String displayIf;
    private String enableIf;
    private Boolean labelBold;
    private String sourceSystem;

    public String getFieldId() {

        return fieldId;
    }

    public void setFieldId(String fieldId) {

        this.fieldId = fieldId;
    }

    public String getLabel() {

        return label;
    }

    public void setLabel(String label) {

        this.label = label;
    }

    public String getI18NLabelKey() {

        return i18NLabelKey;
    }

    public void setI18NLabelKey(String i18nLabelKey) {

        i18NLabelKey = i18nLabelKey;
    }

    public int getOrder() {

        return order;
    }

    public void setOrder(int order) {

        this.order = order;
    }

    public boolean isEnabled() {

        return enabled;
    }

    public void setEnabled(boolean enabled) {

        this.enabled = enabled;
    }

    public boolean isMandatory() {

        return mandatory;
    }

    public void setMandatory(boolean mandatory) {

        this.mandatory = mandatory;
    }

    public Boolean getMultiple() {

        return multiple;
    }

    public void setMultiple(Boolean multiple) {

        this.multiple = multiple;
    }

    public Integer getMaxMultiple() {

        return maxMultiple;
    }

    public void setMaxMultiple(Integer maxMultiple) {

        this.maxMultiple = maxMultiple;
    }

    public String getSelectedValue() {

        return selectedValue;
    }

    public void setSelectedValue(String selectedValue) {

        this.selectedValue = selectedValue;
    }

    public String getDisplayIf() {

        return displayIf;
    }

    public void setDisplayIf(String displayIf) {

        this.displayIf = displayIf;
    }

    public String getEnableIf() {

        return enableIf;
    }

    public void setEnableIf(String enableIf) {

        this.enableIf = enableIf;
    }

    public Boolean getLabelBold() {

        return labelBold;
    }

    public void setLabelBold(Boolean labelBold) {

        this.labelBold = labelBold;
    }

    public String getSourceSystem() {

        return sourceSystem;
    }

    public void setSourceSystem(String sourceSystem) {

        this.sourceSystem = sourceSystem;
    }

    @Override
    public String toString() {

        return "Field [fieldId=" + fieldId + ", label=" + label + ", i18NLabelKey=" + i18NLabelKey + ", order=" + order + ", enabled=" + enabled
                + ", mandatory=" + mandatory + ", multiple=" + multiple + ", maxMultiple=" + maxMultiple + ", selectedValue=" + selectedValue
                + ", displayIf=" + displayIf + ", enableIf=" + enableIf + ", labelBold=" + labelBold + ", sourceSystem=" + sourceSystem + "]";
    }

}
