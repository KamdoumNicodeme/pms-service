package com.lombardinternational.casedefinition.model;

public class LifeAssured extends PolicyRole {

    public LifeAssured() {
        // TODO Auto-generated constructor stub
    }


}
