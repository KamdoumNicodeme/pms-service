package com.lombardinternational.casedefinition.model;

import java.util.List;
import java.util.Objects;

public class BusinessTransactionProductComponent {
    private Amount expectedAmountInPolicyCurrency;

    private List<Payment> payments;

    public BusinessTransactionProductComponent() {
    }

    public Amount getExpectedAmountInPolicyCurrency() {
        return expectedAmountInPolicyCurrency;
    }

    public void setExpectedAmountInPolicyCurrency(Amount expectedAmountInPolicyCurrency) {
        this.expectedAmountInPolicyCurrency = expectedAmountInPolicyCurrency;
    }

    public List<Payment> getPayments() {
        return payments;
    }

    public void setPayments(List<Payment> payments) {
        this.payments = payments;
    }

    @Override
    public boolean equals(final Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        final BusinessTransactionProductComponent that = (BusinessTransactionProductComponent) o;
        return Objects.equals(expectedAmountInPolicyCurrency, that.expectedAmountInPolicyCurrency) && Objects.equals(payments, that.payments);
    }

    @Override
    public int hashCode() {
        return Objects.hash(expectedAmountInPolicyCurrency, payments);
    }

    @Override
    public String toString() {
        return "BusinessTransactionProductComponent{" +
                "expectedAmountInPolicyCurrency=" + expectedAmountInPolicyCurrency +
                ", payments=" + payments +
                '}';
    }
}
