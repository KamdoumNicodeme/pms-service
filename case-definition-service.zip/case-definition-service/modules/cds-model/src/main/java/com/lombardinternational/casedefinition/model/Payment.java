package com.lombardinternational.casedefinition.model;

import java.util.Objects;

public abstract class Payment {
    private Amount paymentAmount;
    private Country paymentCountry;
    private PaymentDetails paymentDetails;

    public Amount getPaymentAmount() {
        return paymentAmount;
    }

    public void setPaymentAmount(Amount paymentAmount) {
        this.paymentAmount = paymentAmount;
    }

    public Country getPaymentCountry() {
        return paymentCountry;
    }

    public void setPaymentCountry(Country paymentCountry) {
        this.paymentCountry = paymentCountry;
    }

    public PaymentDetails getPaymentDetails() {
        return paymentDetails;
    }

    public void setPaymentDetails(PaymentDetails paymentDetails) {
        this.paymentDetails = paymentDetails;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Payment payment = (Payment) o;
        return Objects.equals(paymentAmount, payment.paymentAmount) && Objects.equals(paymentCountry, payment.paymentCountry) && Objects.equals(paymentDetails, payment.paymentDetails);
    }

    @Override
    public int hashCode() {
        return Objects.hash(paymentAmount, paymentCountry, paymentDetails);
    }

    @Override
    public String toString() {
        return "Payment{" +
                "paymentAmount=" + paymentAmount +
                ", paymentCountry=" + paymentCountry +
                ", paymentDetails=" + paymentDetails +
                '}';
    }
}
