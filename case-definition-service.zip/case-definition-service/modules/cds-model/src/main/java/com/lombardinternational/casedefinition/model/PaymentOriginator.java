package com.lombardinternational.casedefinition.model;


import java.util.Objects;

public class PaymentOriginator {
    private String externalId;
    private String label;

    public String getExternalId() {
        return externalId;
    }

    public void setExternalId(String externalId) {
        this.externalId = externalId;
    }

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        PaymentOriginator that = (PaymentOriginator) o;
        return Objects.equals(externalId, that.externalId) && Objects.equals(label, that.label);
    }

    @Override
    public int hashCode() {
        return Objects.hash(externalId, label);
    }

    @Override
    public String toString() {
        return "PaymentOriginator{" +
                "externalId='" + externalId + '\'' +
                ", label='" + label + '\'' +
                '}';
    }
}
