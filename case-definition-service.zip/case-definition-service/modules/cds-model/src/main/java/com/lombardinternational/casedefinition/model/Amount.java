package com.lombardinternational.casedefinition.model;

import java.math.BigDecimal;

public class Amount {

    private BigDecimal quantity;
    private String isoCurrencyCode;

    public Amount() {
        // TODO Auto-generated constructor stub
    }

    public Amount(BigDecimal quantity, String isoCurrencyCode) {
        this.quantity = quantity;
        this.isoCurrencyCode = isoCurrencyCode;
    }

    public BigDecimal getQuantity() {

        return quantity;
    }

    public void setQuantity(BigDecimal quantity) {

        this.quantity = quantity;
    }

    public String getIsoCurrencyCode() {

        return isoCurrencyCode;
    }

    public void setIsoCurrencyCode(String isoCurrencyCode) {

        this.isoCurrencyCode = isoCurrencyCode;
    }

    @Override
    public String toString() {

        return "Amount [quantity=" + quantity + ", isoCurrencyCode=" + isoCurrencyCode + "]";
    }

}
