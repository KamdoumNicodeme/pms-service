package com.lombardinternational.casedefinition.model;

import java.util.List;

public class CaseControlDefinition {

    private int controlId;
    private String controlName;
    private boolean controlVisibleOnConnect;
    private int controlOrder;
    private List<String> decisionReasons;
    private String controlType;

    public CaseControlDefinition() {
    }

    public int getControlId() {

        return controlId;
    }

    public void setControlId(int controlId) {

        this.controlId = controlId;
    }

    public String getControlName() {

        return controlName;
    }

    public void setControlName(String controlName) {

        this.controlName = controlName;
    }

    public boolean isControlVisibleOnConnect() {

        return controlVisibleOnConnect;
    }

    public void setControlVisibleOnConnect(boolean controlVisibleOnConnect) {

        this.controlVisibleOnConnect = controlVisibleOnConnect;
    }

    public int getControlOrder() {

        return controlOrder;
    }

    public void setControlOrder(int controlOrder) {

        this.controlOrder = controlOrder;
    }

    public List<String> getDecisionReasons() {

        return decisionReasons;
    }

    public void setDecisionReasons(List<String> decisionReasons) {

        this.decisionReasons = decisionReasons;
    }

    public String getControlType() {

        return controlType;
    }

    public void setControlType(String controlType) {

        this.controlType = controlType;
    }

    @Override
    public String toString() {

        final StringBuilder decisionReasonsToString = new StringBuilder();
        if (decisionReasons != null) {
            decisionReasons.forEach(decisionReason -> decisionReasonsToString.append(decisionReason).append(" \n "));
        }
        return "CaseControlDefinition [controlId=" + controlId + ", controlName=" + controlName + ", controlVisibleOnConnect="
                + controlVisibleOnConnect + ", controlOrder=" + controlOrder + ", controlType=" + controlType + ", decisionReasons="
                + decisionReasonsToString.toString() + "]";
    }

}
