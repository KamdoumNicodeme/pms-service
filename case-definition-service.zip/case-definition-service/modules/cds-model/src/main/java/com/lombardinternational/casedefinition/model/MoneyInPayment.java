package com.lombardinternational.casedefinition.model;

public class MoneyInPayment extends Payment {

    private PaymentDetails expectedPaymentDetails;

    public MoneyInPayment() {
        // TODO Auto-generated constructor stub
    }

    public PaymentDetails getExpectedPaymentDetails() {
        return expectedPaymentDetails;
    }

    public void setExpectedPaymentDetails(PaymentDetails expectedPaymentDetails) {
        this.expectedPaymentDetails = expectedPaymentDetails;
    }

    @Override
    public String toString() {
        return "MoneyInPayment{" +
                "paymentDetails=" + getPaymentDetails() +
                ", expectedPaymentDetails=" + getExpectedPaymentDetails() +
                '}';
    }
}
