package com.lombardinternational.casedefinition.model;

public class LabelField extends Field {

    @Override
    public String toString() {

        return "LabelField [" + super.toString() + "]";
    }

}
