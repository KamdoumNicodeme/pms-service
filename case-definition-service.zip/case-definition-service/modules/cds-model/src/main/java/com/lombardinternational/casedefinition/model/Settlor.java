package com.lombardinternational.casedefinition.model;

public class Settlor extends PolicyRole {

}
