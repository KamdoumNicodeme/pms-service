package com.lombardinternational.casedefinition.model;

public class PhysicalPerson extends AbstractPerson {

    private String firstName;
    private String lastname;
    private Profession profession;

    public PhysicalPerson() {
        // TODO Auto-generated constructor stub
    }

    public String getFirstName() {

        return firstName;
    }

    public void setFirstName(String firstName) {

        this.firstName = firstName;
    }

    public String getLastname() {

        return lastname;
    }

    public void setLastname(String lastname) {

        this.lastname = lastname;
    }

    public Profession getProfession() {
        return profession;
    }

    public void setProfession(final Profession profession) {
        this.profession = profession;
    }

    @Override
    public String getSubType() {

        return "Individual";
    }

    @Override
    public String toString() {
        return "PhysicalPerson{" +
                "firstName='" + firstName + '\'' +
                ", lastname='" + lastname + '\'' +
                ", profession=" + profession +
                '}';
    }

}
