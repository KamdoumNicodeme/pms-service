package com.lombardinternational.casedefinition.model;

public class PersistedBlock {

    private BlockType blockType;
    private FIUReportingStatus fiuReportingStatus;
    private String endDate;
    private String startDate;
    private String blockReason;
    private String unblockReason;

    public BlockType getBlockType() {
        return blockType;
    }

    public void setBlockType(BlockType blockType) {
        this.blockType = blockType;
    }

    public FIUReportingStatus getFIUReportingStatus() {
        return fiuReportingStatus;
    }

    public void setFIUReportingStatus(FIUReportingStatus fiuReportingStatus) {
        this.fiuReportingStatus = fiuReportingStatus;
    }

    public String getEndDate() {
        return endDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    public String getStartDate() {
        return startDate;
    }

    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    public String getBlockReason() {
        return blockReason;
    }

    public void setBlockReason(String blockReason) {
        this.blockReason = blockReason;
    }

    public String getUnblockReason() {
        return unblockReason;
    }

    public void setUnblockReason(String unblockReason) {
        this.unblockReason = unblockReason;
    }

    @Override
    public String toString() {
        return "PersistedBlock{" +
            "blockType=" + blockType +
            ", fiuReportingStatus='" + fiuReportingStatus + '\'' +
            ", endDate='" + endDate + '\'' +
            ", startDate='" + startDate + '\'' +
            ", blockReason='" + blockReason + '\'' +
            ", unblockReason='" + unblockReason + '\'' +
            '}';
    }
}
