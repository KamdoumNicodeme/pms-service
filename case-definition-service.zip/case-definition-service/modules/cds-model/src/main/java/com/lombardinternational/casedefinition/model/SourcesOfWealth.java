package com.lombardinternational.casedefinition.model;

import java.math.BigDecimal;
import java.util.Calendar;
import java.util.Objects;

public class SourcesOfWealth {

    private String description;
    private String companyName;
    private Calendar transactionDateTime;
    private BigDecimal splitPercentage;
    private Amount amount;
    private String contributorName;
    private String contributorLink;
    private String contributorCountry;
    private String wealthOriginatingcountry1;
    private String wealthOriginatingcountry2;
    private String contributorProfession;
    private String contributorProfIndusSector;
    private Boolean deleted;
    private Boolean exception;
    private Boolean originOfPremium;

    public SourcesOfWealth() {
        // TODO Auto-generated constructor stub
    }

    public String getDescription() {

        return description;
    }

    public void setDescription(String description) {

        this.description = description;
    }

    public String getCompanyName() {

        return companyName;
    }

    public void setCompanyName(String companyName) {

        this.companyName = companyName;
    }

    public Calendar getTransactionDateTime() {

        return transactionDateTime;
    }

    public void setTransactionDateTime(Calendar transactionDateTime) {

        this.transactionDateTime = transactionDateTime;
    }

    public BigDecimal getSplitPercentage() {

        return splitPercentage;
    }

    public void setSplitPercentage(BigDecimal splitPercentage) {

        this.splitPercentage = splitPercentage;
    }

    public Amount getAmount() {

        return amount;
    }

    public void setAmount(Amount amount) {

        this.amount = amount;
    }

    public String getContributorName() {

        return contributorName;
    }

    public void setContributorName(String contributorName) {

        this.contributorName = contributorName;
    }

    public String getContributorLink() {

        return contributorLink;
    }

    public void setContributorLink(String contributorLink) {

        this.contributorLink = contributorLink;
    }

    public String getContributorCountry() {

        return contributorCountry;
    }

    public void setContributorCountry(String contributorCountry) {

        this.contributorCountry = contributorCountry;
    }

    public String getWealthOriginatingcountry1() {

        return wealthOriginatingcountry1;
    }

    public void setWealthOriginatingcountry1(String wealthOriginatingcountry1) {

        this.wealthOriginatingcountry1 = wealthOriginatingcountry1;
    }

    public String getWealthOriginatingcountry2() {

        return wealthOriginatingcountry2;
    }

    public void setWealthOriginatingcountry2(String wealthOriginatingcountry2) {

        this.wealthOriginatingcountry2 = wealthOriginatingcountry2;
    }

    public String getContributorProfession() {

        return contributorProfession;
    }

    public void setContributorProfession(String contributorProfession) {

        this.contributorProfession = contributorProfession;
    }

    public String getContributorProfIndusSector() {

        return contributorProfIndusSector;
    }

    public void setContributorProfIndusSector(String contributorProfIndusSector) {

        this.contributorProfIndusSector = contributorProfIndusSector;
    }

    public Boolean getDeleted() {

        return deleted;
    }

    public void setDeleted(Boolean deleted) {

        this.deleted = deleted;
    }

    public Boolean getException() {
        return exception;
    }

    public void setException(Boolean exception) {
        this.exception = exception;
    }

    public Boolean getOriginOfPremium() {
        return originOfPremium;
    }

    public void setOriginOfPremium(Boolean originOfPremium) {
        this.originOfPremium = originOfPremium;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        SourcesOfWealth that = (SourcesOfWealth) o;
        return Objects.equals(description, that.description) && Objects.equals(companyName, that.companyName) && Objects.equals(transactionDateTime, that.transactionDateTime) && Objects.equals(splitPercentage, that.splitPercentage) && Objects.equals(amount, that.amount) && Objects.equals(contributorName, that.contributorName) && Objects.equals(contributorLink, that.contributorLink) && Objects.equals(contributorCountry, that.contributorCountry) && Objects.equals(wealthOriginatingcountry1, that.wealthOriginatingcountry1) && Objects.equals(wealthOriginatingcountry2, that.wealthOriginatingcountry2) && Objects.equals(contributorProfession, that.contributorProfession) && Objects.equals(contributorProfIndusSector, that.contributorProfIndusSector) && Objects.equals(deleted, that.deleted) && Objects.equals(exception, that.exception) && Objects.equals(originOfPremium, that.originOfPremium);
    }

    @Override
    public int hashCode() {
        return Objects.hash(description, companyName, transactionDateTime, splitPercentage, amount, contributorName, contributorLink, contributorCountry, wealthOriginatingcountry1, wealthOriginatingcountry2, contributorProfession, contributorProfIndusSector, deleted, exception, originOfPremium);
    }

    @Override
    public String toString() {
        return "SourcesOfWealth{" +
                "description='" + description + '\'' +
                ", companyName='" + companyName + '\'' +
                ", transactionDateTime=" + transactionDateTime +
                ", splitPercentage=" + splitPercentage +
                ", amount=" + amount +
                ", contributorName='" + contributorName + '\'' +
                ", contributorLink='" + contributorLink + '\'' +
                ", contributorCountry='" + contributorCountry + '\'' +
                ", wealthOriginatingcountry1='" + wealthOriginatingcountry1 + '\'' +
                ", wealthOriginatingcountry2='" + wealthOriginatingcountry2 + '\'' +
                ", contributorProfession='" + contributorProfession + '\'' +
                ", contributorProfIndusSector='" + contributorProfIndusSector + '\'' +
                ", deleted=" + deleted +
                ", exception=" + exception +
                ", originOfPremium=" + originOfPremium +
                '}';
    }
}
