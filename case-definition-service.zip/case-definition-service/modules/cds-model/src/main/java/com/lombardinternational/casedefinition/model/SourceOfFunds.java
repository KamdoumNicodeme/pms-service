package com.lombardinternational.casedefinition.model;

import java.util.Calendar;
import java.util.List;

public class SourceOfFunds {

    private Boolean pepFlag;
    private Boolean negativePressFindingFlag;
    private Amount totalWealth;
    private Amount annualIncome;
    private List<SourcesOfWealth> sourcesOfWealth;
    private String occupation;
    private Boolean internationalSanctionListFlag;
    private Boolean insiderFlag;
    private PepCategory pepCategory;
    private Boolean isPHEBOGoldenVisaCitizen;
    private Boolean isPHEBORepresentativeIntermediary;

    public SourceOfFunds() {

        // TODO Auto-generated constructor stub
    }

    public Boolean getPepFlag() {

        return pepFlag;
    }

    public void setPepFlag(Boolean pepFlag) {

        this.pepFlag = pepFlag;
    }

    public Boolean getNegativePressFindingFlag() {

        return negativePressFindingFlag;
    }

    public void setNegativePressFindingFlag(Boolean negativePressFindingFlag) {

        this.negativePressFindingFlag = negativePressFindingFlag;
    }

    public Amount getTotalWealth() {

        return totalWealth;
    }

    public void setTotalWealth(Amount totalWealth) {

        this.totalWealth = totalWealth;
    }

    public Amount getAnnualIncome() {

        return annualIncome;
    }

    public void setAnnualIncome(Amount annualIncome) {

        this.annualIncome = annualIncome;
    }

    public List<SourcesOfWealth> getSourcesOfWealth() {

        return sourcesOfWealth;
    }

    public void setSourcesOfWealth(List<SourcesOfWealth> sourcesOfWealth) {

        this.sourcesOfWealth = sourcesOfWealth;
    }

    public String getOccupation() {

        return occupation;
    }

    public void setOccupation(String occupation) {

        this.occupation = occupation;
    }

    public Boolean isInternationalSanctionListFlag() {

        return internationalSanctionListFlag;
    }

    public void setInternationalSanctionListFlag(Boolean internationalSanctionListFlag) {

        this.internationalSanctionListFlag = internationalSanctionListFlag;
    }

    public Boolean isInsiderFlag() {

        return insiderFlag;
    }

    public void setInsiderFlag(Boolean insiderFlag) {

        this.insiderFlag = insiderFlag;
    }

    public PepCategory getPepCategory() {
        return pepCategory;
    }

    public void setPepCategory(PepCategory pepCategory) {
        this.pepCategory = pepCategory;
    }

    public Boolean getIsPHEBOGoldenVisaCitizen() {
        return isPHEBOGoldenVisaCitizen;
    }

    public void setIsPHEBOGoldenVisaCitizen(Boolean isPHEBOGoldenVisaCitizen) {
        this.isPHEBOGoldenVisaCitizen = isPHEBOGoldenVisaCitizen;
    }

    public Boolean getIsPHEBORepresentativeIntermediary() {
        return isPHEBORepresentativeIntermediary;
    }

    public void setIsPHEBORepresentativeIntermediary(Boolean isPHEBORepresentativeIntermediary) {
        this.isPHEBORepresentativeIntermediary = isPHEBORepresentativeIntermediary;
    }

    @Override
    public String toString() {
        return "SourceOfFunds{" +
                "pepFlag=" + pepFlag +
                ", negativePressFindingFlag=" + negativePressFindingFlag +
                ", totalWealth=" + totalWealth +
                ", annualIncome=" + annualIncome +
                ", sourcesOfWealth=" + sourcesOfWealth +
                ", occupation='" + occupation + '\'' +
                ", internationalSanctionListFlag=" + internationalSanctionListFlag +
                ", insiderFlag=" + insiderFlag +
                ", pepCategory=" + pepCategory +
                ", isPHEBOGoldenVisaCitizen=" + isPHEBOGoldenVisaCitizen +
                ", isPHEBORepresentativeIntermediary=" + isPHEBORepresentativeIntermediary +
                '}';
    }

}
