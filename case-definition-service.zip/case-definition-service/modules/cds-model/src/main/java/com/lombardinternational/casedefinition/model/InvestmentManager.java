package com.lombardinternational.casedefinition.model;

/**
 * Object that represent ${@link InvestmentManager}
 *
 * @author qemo
 */
public class InvestmentManager {
    private String number;
    private String name;
    private String serviceTeam;

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getServiceTeam() {
        return serviceTeam;
    }

    public void setServiceTeam(String serviceTeam) {
        this.serviceTeam = serviceTeam;
    }
}
