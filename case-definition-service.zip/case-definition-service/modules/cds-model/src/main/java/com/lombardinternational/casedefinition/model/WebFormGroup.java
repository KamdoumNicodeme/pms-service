package com.lombardinternational.casedefinition.model;

import java.util.List;
import java.util.stream.Stream;

public class WebFormGroup {

    private String groupId;
    private String title;
    private String i18NTitleKey;
    private String type;
    private List<BigDecimalWebFormField> bigDecimalFields;
    private List<BooleanWebFormField> booleanFields;
    private List<TextWebFormField> textFields;
    private List<CalendarWebFormField> calendarFields;
    private List<WebFormGroup> groups;

    public WebFormGroup() {
        // TODO Auto-generated constructor stub
    }

    public String getGroupId() {

        return groupId;
    }

    public void setGroupId(String groupId) {

        this.groupId = groupId;
    }

    public String getTitle() {

        return title;
    }

    public void setTitle(String title) {

        this.title = title;
    }

    public String getI18NTitleKey() {

        return i18NTitleKey;
    }

    public void setI18NTitleKey(String i18nTitleKey) {

        i18NTitleKey = i18nTitleKey;
    }

    public String getType() {

        return type;
    }

    public void setType(String type) {

        this.type = type;
    }

    public List<BigDecimalWebFormField> getBigDecimalFields() {

        return bigDecimalFields;
    }

    public void setBigDecimalFields(List<BigDecimalWebFormField> bigDecimalFields) {

        this.bigDecimalFields = bigDecimalFields;
    }

    public List<BooleanWebFormField> getBooleanFields() {

        return booleanFields;
    }

    public void setBooleanFields(List<BooleanWebFormField> booleanFields) {

        this.booleanFields = booleanFields;
    }

    public List<TextWebFormField> getTextFields() {

        return textFields;
    }

    public void setTextFields(List<TextWebFormField> textFields) {

        this.textFields = textFields;
    }

    public List<CalendarWebFormField> getCalendarFields() {

        return calendarFields;
    }

    public void setCalendarFields(List<CalendarWebFormField> calendarFields) {

        this.calendarFields = calendarFields;
    }

    public List<WebFormGroup> getGroups() {

        return groups;
    }

    public void setGroups(List<WebFormGroup> groups) {

        this.groups = groups;
    }
    
    public Stream<WebFormGroup> flattened() {
    	return Stream.concat(Stream.of(this), groups.stream().flatMap(WebFormGroup::flattened));
    }

    @Override
    public String toString() {

        return "WebFormGroup [groupId=" + groupId + ", title=" + title + ", i18NTitleKey=" + i18NTitleKey + ", type=" + type
                + ", bigDecimalFields=" + bigDecimalFields + ", booleanFields=" + booleanFields + ", textFields=" + textFields
                + ", calendarFields=" + calendarFields + ", groups=" + groups + "]";
    }

}
