package com.lombardinternational.casedefinition.model;

public class Profession extends HardCode {
}
