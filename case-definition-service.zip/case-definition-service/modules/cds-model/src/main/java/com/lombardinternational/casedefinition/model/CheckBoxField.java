package com.lombardinternational.casedefinition.model;

public class CheckBoxField extends Field {

    @Override
    public String toString() {

        return "CheckBoxField [" + super.toString() + "]";
    }

}
