package com.lombardinternational.casedefinition.model;

import java.util.List;

/**
 * @author mbelarbi
 *
 */
public class Tab {

    private String tabId;
    private String label;
    private String i18NLabelKey;
    private int order;
    private boolean triggersRecomputeScreen;
    private String type;
    private List<Group> groups;
    private String displayIf;

    public Tab() {
    }

    public String getTabId() {

        return tabId;
    }

    public void setTabId(String tabId) {

        this.tabId = tabId;
    }

    public String getLabel() {

        return label;
    }

    public void setLabel(String label) {

        this.label = label;
    }

    public String getI18NLabelKey() {

        return i18NLabelKey;
    }

    public void setI18NLabelKey(String i18nLabelKey) {

        i18NLabelKey = i18nLabelKey;
    }

    public int getOrder() {

        return order;
    }

    public void setOrder(int order) {

        this.order = order;
    }

    public boolean isTriggersRecomputeScreen() {

        return triggersRecomputeScreen;
    }

    public void setTriggersRecomputeScreen(boolean triggersRecomputeScreen) {

        this.triggersRecomputeScreen = triggersRecomputeScreen;
    }

    public String getType() {

        return type;
    }

    public void setType(String type) {

        this.type = type;
    }

    public List<Group> getGroups() {

        return groups;
    }

    public void setGroups(List<Group> groups) {

        this.groups = groups;
    }

    public String getDisplayIf() {

        return displayIf;
    }

    public void setDisplayIf(String displayIf) {

        this.displayIf = displayIf;
    }

    @Override
    public String toString() {

        return "Tab [tabId=" + tabId + ", label=" + label + ", i18NLabelKey=" + i18NLabelKey + ", order=" + order + ", triggersRecomputeScreen="
                + triggersRecomputeScreen + ", type=" + type + ", groups=" + groups + "]";
    }

}
