package com.lombardinternational.casedefinition.model;

public abstract class WebFormField {

    private String fieldId;
    private String label;

    public String getFieldId() {

        return fieldId;
    }

    public void setFieldId(String fieldId) {

        this.fieldId = fieldId;
    }

    public String getLabel() {

        return label;
    }

    public void setLabel(String label) {

        this.label = label;
    }

    @Override
    public String toString() {

        return "WebFormField [fieldId=" + fieldId + ", label=" + label + "]";
    }

}
