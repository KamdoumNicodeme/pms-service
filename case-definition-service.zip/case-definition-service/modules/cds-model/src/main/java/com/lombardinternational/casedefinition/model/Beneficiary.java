package com.lombardinternational.casedefinition.model;

public class Beneficiary extends PolicyRole {

    private Boolean irrevocableFlag;

    public Beneficiary() {
        // TODO Auto-generated constructor stub
    }

    public Boolean getIrrevocableFlag() {

        return irrevocableFlag;
    }

    public void setIrrevocableFlag(Boolean irrevocableFlag) {

        this.irrevocableFlag = irrevocableFlag;
    }

    @Override
    public String toString() {
        return "Beneficiary{" +
                "irrevocableFlag=" + irrevocableFlag +
                '}';
    }
}
