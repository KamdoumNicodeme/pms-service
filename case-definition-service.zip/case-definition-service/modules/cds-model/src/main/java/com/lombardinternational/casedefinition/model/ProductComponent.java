package com.lombardinternational.casedefinition.model;

public class ProductComponent {

    private String productComponentNumber;
    private String investmentManagerCode;
    private String investmentManagerName;

    public ProductComponent() {
        // TODO Auto-generated constructor stub
    }

    public String getProductComponentNumber() {

        return productComponentNumber;
    }

    public void setProductComponentNumber(String productComponentNumber) {

        this.productComponentNumber = productComponentNumber;
    }

    public String getInvestmentManagerCode() {

        return investmentManagerCode;
    }

    public void setInvestmentManagerCode(String investmentManagerCode) {

        this.investmentManagerCode = investmentManagerCode;
    }

    public String getInvestmentManagerName() {

        return investmentManagerName;
    }

    public void setInvestmentManagerName(String investmentManagerName) {

        this.investmentManagerName = investmentManagerName;
    }

    @Override
    public String toString() {

        return "ProductComponent [productComponentNumber=" + productComponentNumber + ", investmentManagerCode=" + investmentManagerCode
                + ", investmentManagerName=" + investmentManagerName + "]";
    }

}
