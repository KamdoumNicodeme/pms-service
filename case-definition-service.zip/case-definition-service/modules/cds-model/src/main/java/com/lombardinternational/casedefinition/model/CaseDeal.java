package com.lombardinternational.casedefinition.model;

public class CaseDeal {

	protected String caseDealId;
	protected String dealType;
	protected String etisGroupId;
	protected String etisDealId;
	protected Boolean validated;

	public CaseDeal() {
	}

	public String getCaseDealId() {
		return caseDealId;
	}

	public void setCaseDealId(String caseDealId) {
		this.caseDealId = caseDealId;
	}

	public String getDealType() {
		return dealType;
	}

	public void setDealType(String dealType) {
		this.dealType = dealType;
	}

	public String getEtisGroupId() {
		return etisGroupId;
	}

	public void setEtisGroupId(String etisGroupId) {
		this.etisGroupId = etisGroupId;
	}

	public String getEtisDealId() {
		return etisDealId;
	}

	public void setEtisDealId(String etisDealId) {
		this.etisDealId = etisDealId;
	}

	public Boolean getValidated() {
		return validated;
	}

	public void setValidated(Boolean validated) {
		this.validated = validated;
	}

}
