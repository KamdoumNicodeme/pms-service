package com.lombardinternational.casedefinition.model;

public class BlockType extends HardCode {

}
