package com.lombardinternational.casedefinition.model;

import java.util.List;

public class RoleEndorsementBusinessTransaction extends PolicyServicingBusinessTransaction {

    private List<PolicyRole> rolesAfterEndorsement;

    public List<PolicyRole> getRolesAfterEndorsement() {
        return rolesAfterEndorsement;
    }

    public void setRolesAfterEndorsement(List<PolicyRole> rolesAfterEndorsement) {
        this.rolesAfterEndorsement = rolesAfterEndorsement;
    }
}
