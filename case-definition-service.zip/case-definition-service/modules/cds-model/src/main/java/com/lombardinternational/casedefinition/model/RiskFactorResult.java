package com.lombardinternational.casedefinition.model;

public class RiskFactorResult {

    private String reference;
    private String description;
    private String data;
    private String answerReference;
    private String answerDescription;
    private String riskLevel;
    private Integer score;

    private String stackTrace;

    public String getData() {

        return this.data;
    }

    public void setData(String data) {

        this.data = data;
    }

    public String getReference() {

        return reference;
    }

    public void setReference(String reference) {

        this.reference = reference;
    }

    public String getDescription() {

        return description;
    }

    public void setDescription(String description) {

        this.description = description;
    }

    public String getAnswerReference() {

        return answerReference;
    }

    public void setAnswerReference(String answerReference) {

        this.answerReference = answerReference;
    }

    public String getAnswerDescription() {

        return answerDescription;
    }

    public void setAnswerDescription(String answerDescription) {

        this.answerDescription = answerDescription;
    }

    public Integer getScore() {

        return score;
    }

    public void setScore(Integer score) {

        this.score = score;
    }

    public String getStackTrace() {

        return stackTrace;
    }

    public void setStackTrace(String stackTrace) {

        this.stackTrace = stackTrace;
    }

    public String getRiskLevel() {

        return riskLevel;
    }

    public void setRiskLevel(String riskLevel) {

        this.riskLevel = riskLevel;
    }

    @Override
    public String toString() {
        return "RiskFactorResult{" +
                "reference='" + reference + '\'' +
                ", description='" + description + '\'' +
                ", data='" + data + '\'' +
                ", answerReference='" + answerReference + '\'' +
                ", answerDescription='" + answerDescription + '\'' +
                ", riskLevel='" + riskLevel + '\'' +
                ", score=" + score +
                ", stackTrace='" + stackTrace + '\'' +
                '}';
    }
}
