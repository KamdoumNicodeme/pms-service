package com.lombardinternational.casedefinition.model;

public class TextWebFormField extends WebFormField {

    private String value;

    public TextWebFormField() {
        // TODO Auto-generated constructor stub
    }

    public String getValue() {

        return value;
    }

    public void setValue(String value) {

        this.value = value;
    }

    @Override
    public String toString() {

        return "TextWebFormField [" + super.toString() + " value=" + value + "]";
    }

}
