package com.lombardinternational.casedefinition.model;

import java.util.List;

public class WebForm {

    private UserDetail userDetail;
    private CompanyDetail companyDetail;
    private FormInitiator formInitiator;
    private String webFormId;
    private String webFormWorkFlow;
    private List<WebFormGroup> groups;

    public WebForm() {
        // TODO Auto-generated constructor stub
    }

    public String getWebFormId() {

        return webFormId;
    }

    public void setWebFormId(String webFormId) {

        this.webFormId = webFormId;
    }

    public String getWebFormWorkFlow() {

        return webFormWorkFlow;
    }

    public void setWebFormWorkFlow(String webFormWorkFlow) {

        this.webFormWorkFlow = webFormWorkFlow;
    }

    public UserDetail getUserDetail() {

        return userDetail;
    }

    public void setUserDetail(UserDetail userDetail) {

        this.userDetail = userDetail;
    }

    public CompanyDetail getCompanyDetail() {

        return companyDetail;
    }

    public void setCompanyDetail(CompanyDetail companyDetail) {

        this.companyDetail = companyDetail;
    }

    public FormInitiator getFormInitiator() {
        return formInitiator;
    }

    public void setFormInitiator(final FormInitiator formInitiator) {
        this.formInitiator = formInitiator;
    }

    public List<WebFormGroup> getGroups() {

        return groups;
    }

    public void setGroups(List<WebFormGroup> groups) {

        this.groups = groups;
    }

    @Override
    public String toString() {
        return "WebForm{" +
                "userDetail=" + userDetail +
                ", companyDetail=" + companyDetail +
                ", formInitiator=" + formInitiator +
                ", webFormId='" + webFormId + '\'' +
                ", webFormWorkFlow='" + webFormWorkFlow + '\'' +
                ", groups=" + groups +
                '}';
    }
}
