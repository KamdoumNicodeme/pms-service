package com.lombardinternational.casedefinition.model;

import java.util.Objects;

public class PaymentDetails {
    private String payerID;
    private String payerName;
    private String payerFirstName;
    private String payerBankName;
    private Country payerLegalAddressCountry;
    private Country payerBankCountry;
    private PaymentOriginator originator;

    public String getPayerID() {
        return payerID;
    }

    public void setPayerID(String payerID) {
        this.payerID = payerID;
    }

    public String getPayerName() {
        return payerName;
    }

    public void setPayerName(String payerName) {
        this.payerName = payerName;
    }

    public String getPayerFirstName() {
        return payerFirstName;
    }

    public void setPayerFirstName(String payerFirstName) {
        this.payerFirstName = payerFirstName;
    }

    public String getPayerBankName() {
        return payerBankName;
    }

    public void setPayerBankName(String payerBankName) {
        this.payerBankName = payerBankName;
    }

    public Country getPayerLegalAddressCountry() {
        return payerLegalAddressCountry;
    }

    public void setPayerLegalAddressCountry(final Country payerLegalAddressCountry) {
        this.payerLegalAddressCountry = payerLegalAddressCountry;
    }

    public Country getPayerBankCountry() {
        return payerBankCountry;
    }

    public void setPayerBankCountry(Country payerBankCountry) {
        this.payerBankCountry = payerBankCountry;
    }

    public PaymentOriginator getOriginator() {
        return originator;
    }

    public void setOriginator(PaymentOriginator originator) {
        this.originator = originator;
    }

    @Override
    public boolean equals(final Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        final PaymentDetails that = (PaymentDetails) o;
        return Objects.equals(payerID, that.payerID) && Objects.equals(payerName, that.payerName) && Objects.equals(payerFirstName, that.payerFirstName) && Objects.equals(payerBankName, that.payerBankName) && Objects.equals(payerLegalAddressCountry, that.payerLegalAddressCountry) && Objects.equals(payerBankCountry, that.payerBankCountry) && Objects.equals(originator, that.originator);
    }

    @Override
    public int hashCode() {
        return Objects.hash(payerID, payerName, payerFirstName, payerBankName, payerLegalAddressCountry, payerBankCountry, originator);
    }

    @Override
    public String toString() {
        return "PaymentDetails{" +
                "payerID='" + payerID + '\'' +
                ", payerName='" + payerName + '\'' +
                ", payerFirstName='" + payerFirstName + '\'' +
                ", payerBankName='" + payerBankName + '\'' +
                ", payerLegalAddressCountry='" + payerLegalAddressCountry + '\'' +
                ", payerBankCountry=" + payerBankCountry +
                ", originator=" + originator +
                '}';
    }
}
