package com.lombardinternational.casedefinition.model;

public class MoneyOutPayment extends Payment {

    public MoneyOutPayment() {
        // TODO Auto-generated constructor stub
    }

    @Override
    public String toString() {
        return "MoneyInPayment{" +
                "paymentDetails=" + getPaymentDetails() +
                '}';
    }
}
