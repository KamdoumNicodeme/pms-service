package com.lombardinternational.casedefinition.model;

public class PepCategory extends HardCode {

}
