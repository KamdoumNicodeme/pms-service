package com.lombardinternational.casedefinition.model;

import java.util.List;

public class Group {

    private String groupId;
    private String title;
    private String i18NTitleKey;
    private int order;
    private int columnsCount;
    private List<Field> fields;
    private String displayIf;

    public Group() {
    }

    public String getGroupId() {

        return groupId;
    }

    public void setGroupId(String groupId) {

        this.groupId = groupId;
    }

    public String getTitle() {

        return title;
    }

    public void setTitle(String title) {

        this.title = title;
    }

    public String getI18NTitleKey() {

        return i18NTitleKey;
    }

    public void setI18NTitleKey(String i18nTitleKey) {

        i18NTitleKey = i18nTitleKey;
    }

    public int getOrder() {

        return order;
    }

    public void setOrder(int order) {

        this.order = order;
    }

    public int getColumnsCount() {

        return columnsCount;
    }

    public void setColumnsCount(int columnsCount) {

        this.columnsCount = columnsCount;
    }

    public List<Field> getFields() {

        return fields;
    }

    public void setFields(List<Field> fields) {

        this.fields = fields;
    }

    public String getDisplayIf() {

        return displayIf;
    }

    public void setDisplayIf(String displayIf) {

        this.displayIf = displayIf;
    }

    @Override
    public String toString() {

        return "Group [groupId=" + groupId + ", title=" + title + ", i18NTitleKey=" + i18NTitleKey + ", order=" + order + ", columnsCount="
                + columnsCount + ", fields=" + fields + ", displayIf=" + displayIf + "]";
    }

}
