package com.lombardinternational.casedefinition.model;

import java.util.Calendar;
import java.util.List;

public class BusinessTransaction {

    private String identifier;
    private String type;
    private String category;
    private String subCategory;
    private Calendar closeDate;

    private List<Penalty> penalties;

    private Amount transactionAmountEur;
    private Amount expectedAmount;
    private Amount expectedAmountEur;
    private TransactionAmounts transactionAmounts;

    private Integer caaRiskScoring;
    private Integer internalRiskScoring;

    private List<RiskFactorResult> riskFactorResults;

    private Boolean isInRemediationList;
    private Boolean isPolicyRemediated;

    private EboPolicyNav eboPolicyNav;

    private String sellingMeetingType;

    private List<BusinessTransactionProductComponent> productComponentPayments;

    public BusinessTransaction() {
        // TODO Auto-generated constructor stub
    }

    public String getIdentifier() {
        return identifier;
    }

    public void setIdentifier(String identifier) {
        this.identifier = identifier;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Amount getTransactionAmountEur() {
        return transactionAmountEur;
    }

    public void setTransactionAmountEur(Amount transactionAmountEur) {
        this.transactionAmountEur = transactionAmountEur;
    }

    public TransactionAmounts getTransactionAmounts() {
        return transactionAmounts;
    }

    public void setTransactionAmounts(TransactionAmounts transactionAmounts) {
        this.transactionAmounts = transactionAmounts;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getSubCategory() {
        return subCategory;
    }

    public void setSubCategory(String subCategory) {
        this.subCategory = subCategory;
    }

    public Calendar getCloseDate() {
        return closeDate;
    }

    public void setCloseDate(Calendar closeDate) {
        this.closeDate = closeDate;
    }

    public List<Penalty> getPenalties() {
        return penalties;
    }

    public void setPenalties(List<Penalty> penalties) {
        this.penalties = penalties;
    }

    public Integer getCaaRiskScoring() {
        return caaRiskScoring;
    }

    public void setCaaRiskScoring(Integer caaRiskScoring) {
        this.caaRiskScoring = caaRiskScoring;
    }

    public Integer getInternalRiskScoring() {
        return internalRiskScoring;
    }

    public void setInternalRiskScoring(Integer internalRiskScoring) {
        this.internalRiskScoring = internalRiskScoring;
    }

    public List<RiskFactorResult> getRiskFactorResults() {
        return riskFactorResults;
    }

    public void setRiskFactorResults(List<RiskFactorResult> riskFactorResults) {
        this.riskFactorResults = riskFactorResults;
    }

    public EboPolicyNav getEboPolicyNav() { return eboPolicyNav; }

    public void setEboPolicyNav(EboPolicyNav eboPolicyNav) {
        this.eboPolicyNav = eboPolicyNav;
    }

    public void setIsInRemediationList(Boolean isInRemediationList) {
        this.isInRemediationList = isInRemediationList;
    }

    public Boolean getIsInRemediationList() {
        return isInRemediationList;
    }

    public void setIsPolicyRemediated(Boolean isPolicyRemediated) {
        this.isPolicyRemediated = isPolicyRemediated;
    }

    public Boolean getIsPolicyRemediated() {
        return isPolicyRemediated;
    }

    public String getSellingMeetingType() {
        return sellingMeetingType;
    }

    public void setSellingMeetingType(final String sellingMeetingType) {
        this.sellingMeetingType = sellingMeetingType;
    }

    public List<BusinessTransactionProductComponent> getProductComponentPayments() {
        return productComponentPayments;
    }

    public void setProductComponentPayments(final List<BusinessTransactionProductComponent> productComponentPayments) {
        this.productComponentPayments = productComponentPayments;
    }

    public Amount getExpectedAmount() {
        return expectedAmount;
    }

    public void setExpectedAmount(Amount expectedAmount) {
        this.expectedAmount = expectedAmount;
    }

    public Amount getExpectedAmountEur() {

        return expectedAmountEur;
    }

    public void setExpectedAmountEur(Amount expectedAmountEur) {
        this.expectedAmountEur = expectedAmountEur;
    }

    @Override
    public String toString() {
        return "BusinessTransaction{" +
            "identifier='" + identifier + '\'' +
            ", type='" + type + '\'' +
            ", transactionAmountEur=" + transactionAmountEur +
            ", transactionAmounts=" + transactionAmounts +
            ", caaRiskScoring=" + caaRiskScoring +
            ", internalRiskScoring=" + internalRiskScoring +
            ", eboPolicyNav=" + eboPolicyNav +
            ", sellingMeetingType=" + sellingMeetingType +
            ", productComponentPayments=" + productComponentPayments +
            '}';
    }
}
