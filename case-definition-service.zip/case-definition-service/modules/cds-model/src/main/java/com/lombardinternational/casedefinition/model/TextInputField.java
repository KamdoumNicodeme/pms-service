package com.lombardinternational.casedefinition.model;

public class TextInputField extends Field {

    private Integer size;
    private Integer minChars;
    private Integer maxChars;

    public Integer getSize() {

        return size;
    }

    public void setSize(Integer size) {

        this.size = size;
    }

    public Integer getMinChars() {

        return minChars;
    }

    public void setMinChars(Integer minChars) {

        this.minChars = minChars;
    }

    public Integer getMaxChars() {

        return maxChars;
    }

    public void setMaxChars(Integer maxChars) {

        this.maxChars = maxChars;
    }

    @Override
    public String toString() {

        return "TextInputField [" + super.toString() + " size=" + size + ", minChars=" + minChars + ", maxChars=" + maxChars + "]";
    }

}
