package com.lombardinternational.casedefinition.model;

import java.text.SimpleDateFormat;
import java.util.Calendar;

public class Block {

    private String blockType;
    private Calendar startDate;
    private Calendar endDate;
    private String blockReason;
    private String unblockReason;
    private String unblockBy;
    protected Calendar unblockApprovalDate;

    public Block() {
    }

    public String getBlockType() {

        return blockType;
    }

    public void setBlockType(String blockType) {

        this.blockType = blockType;
    }

    public Calendar getStartDate() {

        return startDate;
    }

    public void setStartDate(Calendar startDate) {

        this.startDate = startDate;
    }

    public Calendar getEndDate() {

        return endDate;
    }

    public void setEndDate(Calendar endDate) {

        this.endDate = endDate;
    }

    public String getBlockReason() {

        return blockReason;
    }

    public void setBlockReason(String blockReason) {

        this.blockReason = blockReason;
    }

    public String getUnblockReason() {

        return unblockReason;
    }

    public void setUnblockReason(String unblockReason) {

        this.unblockReason = unblockReason;
    }

    public String getUnblockBy() {

        return unblockBy;
    }

    public void setUnblockBy(String unblockBy) {

        this.unblockBy = unblockBy;
    }

    public Calendar getUnblockApprovalDate() {

        return unblockApprovalDate;
    }

    public void setUnblockApprovalDate(Calendar unblockApprovalDate) {

        this.unblockApprovalDate = unblockApprovalDate;
    }

    @Override
    public String toString() {

        final SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");

        final String startDateFormatted = startDate != null ? simpleDateFormat.format(startDate.getTime()) : null;
        final String endDateFormatted = endDate != null ? simpleDateFormat.format(endDate.getTime()) : null;
        final String unblockApprovalDateFormatted = unblockApprovalDate != null ? simpleDateFormat.format(unblockApprovalDate.getTime()) : null;
        return "Block [blockType=" + blockType + ", startDate=" + startDateFormatted + ", endDate=" + endDateFormatted + ", blockReason="
                + blockReason + ", unblockReason=" + unblockReason + ", unblockBy=" + unblockBy + ", unblockApprovalDate="
                + unblockApprovalDateFormatted + "]";
    }

}
