package com.lombardinternational.casedefinition.model;

public abstract class HardCode {

    private String externalId;
    private String label;

    public String getExternalId() {
        return externalId;
    }

    public void setExternalId(String externalId) {
        this.externalId = externalId;
    }

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    @Override
    public String toString() {
        return "HardCode{" +
            "externalId='" + externalId + '\'' +
            ", label='" + label + '\'' +
            '}';
    }
}
