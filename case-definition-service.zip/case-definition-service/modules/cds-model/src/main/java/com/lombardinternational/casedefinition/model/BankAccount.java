package com.lombardinternational.casedefinition.model;

import java.util.Calendar;

public class BankAccount {

    private String bankAccountId;
    private String number;
    private String isoCurrencyCode;
    private String name;
    private String ibanNumber;
    private Calendar setUpDate;
    private String typeDescription;
    private String activityCode;
    private String accountBlockage;
    private String label;
    private String defaultFlag;
    private String ribCode;
    private String usage;
    private Fund fund;

    public BankAccount() {
        // TODO Auto-generated constructor stub
    }

    public String getBankAccountId() {

        return bankAccountId;
    }

    public void setBankAccountId(String bankAccountId) {

        this.bankAccountId = bankAccountId;
    }

    public String getNumber() {

        return number;
    }

    public void setNumber(String number) {

        this.number = number;
    }

    public String getIsoCurrencyCode() {

        return isoCurrencyCode;
    }

    public void setIsoCurrencyCode(String isoCurrencyCode) {

        this.isoCurrencyCode = isoCurrencyCode;
    }

    public String getName() {

        return name;
    }

    public void setName(String name) {

        this.name = name;
    }

    public String getIbanNumber() {

        return ibanNumber;
    }

    public void setIbanNumber(String ibanNumber) {

        this.ibanNumber = ibanNumber;
    }

    public Calendar getSetUpDate() {

        return setUpDate;
    }

    public void setSetUpDate(Calendar setUpDate) {

        this.setUpDate = setUpDate;
    }

    public String getTypeDescription() {

        return typeDescription;
    }

    public void setTypeDescription(String typeDescription) {

        this.typeDescription = typeDescription;
    }

    public String getActivityCode() {

        return activityCode;
    }

    public void setActivityCode(String activityCode) {

        this.activityCode = activityCode;
    }

    public String getAccountBlockage() {

        return accountBlockage;
    }

    public void setAccountBlockage(String accountBlockage) {

        this.accountBlockage = accountBlockage;
    }

    public String getLabel() {

        return label;
    }

    public void setLabel(String label) {

        this.label = label;
    }

    public String getDefaultFlag() {

        return defaultFlag;
    }

    public void setDefaultFlag(String defaultFlag) {

        this.defaultFlag = defaultFlag;
    }

    public String getRibCode() {

        return ribCode;
    }

    public void setRibCode(String ribCode) {

        this.ribCode = ribCode;
    }

    public String getUsage() {

        return usage;
    }

    public void setUsage(String usage) {

        this.usage = usage;
    }

    public Fund getFund() {

        return fund;
    }

    public void setFund(Fund fund) {

        this.fund = fund;
    }

    @Override
    public String toString() {

        return "BankAccount [bankAccountId=" + bankAccountId + ", number=" + number + ", isoCurrencyCode=" + isoCurrencyCode + ", name=" + name
                + ", ibanNumber=" + ibanNumber + ", setUpDate=" + setUpDate + ", typeDescription=" + typeDescription + ", activityCode="
                + activityCode + ", accountBlockage=" + accountBlockage + ", label=" + label + ", defaultFlag=" + defaultFlag + ", ribCode="
                + ribCode + ", usage=" + usage + ", fund=" + fund + "]";
    }

}
