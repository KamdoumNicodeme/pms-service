package com.lombardinternational.casedefinition.model;

import java.math.BigDecimal;

public class Holder extends PolicyRole {

    private String taxIsoCountryCode;
    private BigDecimal riskScore;
    private Address sendingAddress;

	public Holder() {
        // TODO Auto-generated constructor stub
    }

    public String getTaxIsoCountryCode() {

        return taxIsoCountryCode;
    }

    public void setTaxIsoCountryCode(String taxIsoCountryCode) {

        this.taxIsoCountryCode = taxIsoCountryCode;
    }
    
    public Address getSendingAddress() {
		return sendingAddress;
	}

	public void setSendingAddress(Address sendingAddress) {
		this.sendingAddress = sendingAddress;
	}

    /*
     * public BigDecimal getRiskScore() {
     * 
     * return riskScore;
     * }
     * 
     * public void setRiskScore(BigDecimal riskScore) {
     * 
     * this.riskScore = riskScore;
     * }
     */
    @Override
    public String toString() {

        return "Holder [taxCountry=" + taxIsoCountryCode + ", riskScore=" + riskScore + ", toString()=" + super.toString() + "]";
    }

}
