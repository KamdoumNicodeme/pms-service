package com.lombardinternational.casedefinition.model;

public class Trust extends PolicyRole {

}
