package com.lombardinternational.casedefinition.model;

public class Fund {

    private String fundNumber;
    private String fundValuationModel;
    protected String fundSubClass;

    public Fund() {
        // TODO Auto-generated constructor stub
    }

    public String getFundNumber() {

        return fundNumber;
    }

    public void setFundNumber(String fundNumber) {

        this.fundNumber = fundNumber;
    }

    public String getFundValuationModel() {

        return fundValuationModel;
    }

    public void setFundValuationModel(String fundValuationModel) {

        this.fundValuationModel = fundValuationModel;
    }

    public String getFundSubClass() {
        return fundSubClass;
    }

    public void setFundSubClass(String fundSubClass) {
        this.fundSubClass = fundSubClass;
    }

    @Override
    public String toString() {
        return "Fund{" +
            "fundNumber='" + fundNumber + '\'' +
            ", fundValuationModel='" + fundValuationModel + '\'' +
            ", fundSubClass=" + fundSubClass +
            '}';
    }
}
