package com.lombardinternational.casedefinition.model;

import java.util.List;

public class TaskDefinition {

    private int taskId;
    private boolean suggested;
    private boolean mandatory;
    private String mainTaskName;
    private String mainTaskDynamicScreenId;
    private int mainTaskExpectedDurationSeconds;
    private int signoffTaskExpectedDurationSeconds;
    private int taskOrder;
    private boolean releasableFromSubTask;
    private boolean completeRequired = true;
    private List<String> decisionReasons;

    public TaskDefinition() {
    }

    public boolean isSuggested() {

        return suggested;
    }

    public void setSuggested(boolean suggested) {

        this.suggested = suggested;
    }

    public String getMainTaskName() {

        return mainTaskName;
    }

    public void setMainTaskName(String mainTaskName) {

        this.mainTaskName = mainTaskName;
    }

    public String getMainTaskDynamicScreenId() {

        return mainTaskDynamicScreenId;
    }

    public void setMainTaskDynamicScreenId(String mainTaskDynamicScreenId) {

        this.mainTaskDynamicScreenId = mainTaskDynamicScreenId;
    }

    public int getMainTaskExpectedDurationSeconds() {

        return mainTaskExpectedDurationSeconds;
    }

    public void setMainTaskExpectedDurationSeconds(int mainTaskExpectedDurationSeconds) {

        this.mainTaskExpectedDurationSeconds = mainTaskExpectedDurationSeconds;
    }

    public int getSignoffTaskExpectedDurationSeconds() {

        return signoffTaskExpectedDurationSeconds;
    }

    public void setSignoffTaskExpectedDurationSeconds(int signoffTaskExpectedDurationSeconds) {

        this.signoffTaskExpectedDurationSeconds = signoffTaskExpectedDurationSeconds;
    }

    public int getTaskOrder() {

        return taskOrder;
    }

    public void setTaskOrder(int taskOrder) {

        this.taskOrder = taskOrder;
    }

    public boolean isReleasableFromSubTask() {

        return releasableFromSubTask;
    }

    public void setReleasableFromSubTask(boolean releasableFromSubTask) {

        this.releasableFromSubTask = releasableFromSubTask;
    }

    public int getTaskId() {

        return taskId;
    }

    public void setTaskId(int taskId) {

        this.taskId = taskId;
    }

    public boolean isMandatory() {

        return mandatory;
    }

    public void setMandatory(boolean mandatory) {

        this.mandatory = mandatory;
    }

    public List<String> getDecisionReasons() {

        return decisionReasons;
    }

    public void setDecisionReasons(List<String> decisionReasons) {

        this.decisionReasons = decisionReasons;
    }

    @Override
    public String toString() {

        final StringBuilder decisionReasonsToString = new StringBuilder();
        if (decisionReasons != null) {
            decisionReasons.forEach(decisionReason -> decisionReasonsToString.append(decisionReason).append("\n"));
        }
        return "TaskDefinition [taskId=" + taskId + ", suggested=" + suggested + ", mandatory=" + mandatory + ", mainTaskName=" + mainTaskName
                + ", mainTaskDynamicScreenId=" + mainTaskDynamicScreenId + ", mainTaskExpectedDurationSeconds=" + mainTaskExpectedDurationSeconds
                + ", signoffTaskExpectedDurationSeconds=" + signoffTaskExpectedDurationSeconds + ", taskOrder=" + taskOrder
                + ", releasableFromSubTask=" + releasableFromSubTask + ", decisionReasons=" + decisionReasonsToString.toString() + "]";
    }

	public boolean isCompleteRequired() {
		return completeRequired;
	}

	public void setCompleteRequired(boolean completeRequired) {
		this.completeRequired = completeRequired;
	}

}
