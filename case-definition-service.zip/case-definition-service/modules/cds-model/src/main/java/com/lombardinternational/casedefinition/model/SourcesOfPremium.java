package com.lombardinternational.casedefinition.model;

public class SourcesOfPremium {

    private String bank;
    private String country;
    private String accountNumber;
    private String accountHolder;
    private Boolean cashAsset;
    private Amount amount;

    public SourcesOfPremium() {
        // TODO Auto-generated constructor stub
    }

    public String getBank() {

        return bank;
    }

    public void setBank(String bank) {

        this.bank = bank;
    }

    public String getCountry() {

        return country;
    }

    public void setCountry(String country) {

        this.country = country;
    }

    public String getAccountNumber() {

        return accountNumber;
    }

    public void setAccountNumber(String accountNumber) {

        this.accountNumber = accountNumber;
    }

    public String getAccountHolder() {

        return accountHolder;
    }

    public void setAccountHolder(String accountHolder) {

        this.accountHolder = accountHolder;
    }

    public Boolean getCashAsset() {

        return cashAsset;
    }

    public void setCashAsset(Boolean cashAsset) {

        this.cashAsset = cashAsset;
    }

    public Amount getAmount() {

        return amount;
    }

    public void setAmount(Amount amount) {

        this.amount = amount;
    }

    @Override
    public String toString() {

        return "SourcesOfPremium [bank=" + bank + ", country=" + country + ", accountNumber=" + accountNumber + ", accountHolder=" + accountHolder
                + ", cashAsset=" + cashAsset + ", amount=" + amount + "]";
    }

}
