package com.lombardinternational.casedefinition.model;

import java.math.BigDecimal;
import java.util.Map;

public class EboPolicyNav {

    private String policyBranch;

    private String policyType;

    //Total Policy NAV (For all policies of all EBO)
    private BigDecimal totalNav;

    //Currency
    private String currency;

    //A table with the following pairs
    //Policy branch
    //Total NAV for all policies of this branch
    private Map<String, BigDecimal> policyNavByBranch;

    public String getPolicyBranch() {
        return this.policyBranch;
    }

    public void setPolicyBranch(final String policyBranch) {
        this.policyBranch = policyBranch;
    }

    public String getPolicyType() {
        return this.policyType;
    }

    public void setPolicyType(final String policyType) {
        this.policyType = policyType;
    }

    public BigDecimal getTotalNav() {
        return this.totalNav;
    }

    public void setTotalNav(final BigDecimal totalNav) {
        this.totalNav = totalNav;
    }

    public String getCurrency() {
        return this.currency;
    }

    public void setCurrency(final String currency) {
        this.currency = currency;
    }

    public Map<String, BigDecimal> getPolicyNavByBranch() {
        return policyNavByBranch;
    }

    public void setPolicyNavByBranch(final Map<String, BigDecimal> policyNavByBranch) {
        this.policyNavByBranch = policyNavByBranch;
    }
}
