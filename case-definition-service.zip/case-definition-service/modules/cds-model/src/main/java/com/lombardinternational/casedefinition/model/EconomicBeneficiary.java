package com.lombardinternational.casedefinition.model;

public class EconomicBeneficiary extends PolicyRole {

    private String countryOfPolicyAdministration;

    public EconomicBeneficiary() {
        // TODO Auto-generated constructor stub
    }

    @Override
    public String toString() {

        return "EconomicBeneficiary [" + super.toString() + ", countryOfPolicyAdministration=" + countryOfPolicyAdministration + "]";
    }

}
