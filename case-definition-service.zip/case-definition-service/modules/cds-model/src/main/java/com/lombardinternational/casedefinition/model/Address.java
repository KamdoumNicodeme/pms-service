package com.lombardinternational.casedefinition.model;

public class Address {

    private Long addressId;
    private String residenceName;
    private String streetName;
    private String streetNumber;
    private String apartmentNumber;
    private String postalBox;
    private String postCode;
    private String townName;
    private Country country;
    private String county;
    private String areaName;
    private String phone;
    private String fax;
    private String email;
    private String careOfName;
    private String addressee;
    private String salutationCode;

    public Long getAddressId() {

        return addressId;
    }

    public void setAddressId(Long addressId) {

        this.addressId = addressId;
    }

    public String getResidenceName() {

        return residenceName;
    }

    public void setResidenceName(String residenceName) {

        this.residenceName = residenceName;
    }

    public String getStreetName() {

        return streetName;
    }

    public void setStreetName(String streetName) {

        this.streetName = streetName;
    }

    public String getStreetNumber() {

        return streetNumber;
    }

    public void setStreetNumber(String streetNumber) {

        this.streetNumber = streetNumber;
    }

    public String getApartmentNumber() {

        return apartmentNumber;
    }

    public void setApartmentNumber(String apartmentNumber) {

        this.apartmentNumber = apartmentNumber;
    }

    public String getPostalBox() {

        return postalBox;
    }

    public void setPostalBox(String postalBox) {

        this.postalBox = postalBox;
    }

    public String getPostCode() {

        return postCode;
    }

    public void setPostCode(String postCode) {

        this.postCode = postCode;
    }

    public String getTownName() {

        return townName;
    }

    public void setTownName(String townName) {

        this.townName = townName;
    }

    public Country getCountry() {

        return country;
    }

    public void setCountry(Country country) {

        this.country = country;
    }

    public String getCounty() {

        return county;
    }

    public void setCounty(String county) {

        this.county = county;
    }

    public String getAreaName() {

        return areaName;
    }

    public void setAreaName(String areaName) {

        this.areaName = areaName;
    }

    public String getPhone() {

        return phone;
    }

    public void setPhone(String phone) {

        this.phone = phone;
    }

    public String getFax() {

        return fax;
    }

    public void setFax(String fax) {

        this.fax = fax;
    }

    public String getEmail() {

        return email;
    }

    public void setEmail(String email) {

        this.email = email;
    }

    public String getCareOfName() {

        return careOfName;
    }

    public void setCareOfName(String careOfName) {

        this.careOfName = careOfName;
    }

    public String getAddressee() {

        return addressee;
    }

    public void setAddressee(String addressee) {

        this.addressee = addressee;
    }

    public String getSalutationCode() {

        return salutationCode;
    }

    public void setSalutationCode(String salutationCode) {

        this.salutationCode = salutationCode;
    }

    @Override
    public String toString() {

        return "Address [addressId=" + addressId + ", residenceName=" + residenceName + ", streetName=" + streetName + ", streetNumber="
                + streetNumber + ", apartmentNumber=" + apartmentNumber + ", postalBox=" + postalBox + ", postCode=" + postCode + ", townName="
                + townName + ", country=" + country + ", county=" + county + ", areaName=" + areaName + ", phone=" + phone + ", fax=" + fax
                + ", email=" + email + ", careOfName=" + careOfName + ", addressee=" + addressee + ", salutationCode=" + salutationCode + "]";
    }

}
