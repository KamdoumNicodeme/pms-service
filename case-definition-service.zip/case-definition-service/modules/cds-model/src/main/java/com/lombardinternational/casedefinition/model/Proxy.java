package com.lombardinternational.casedefinition.model;

public class Proxy extends PolicyRole {

}
