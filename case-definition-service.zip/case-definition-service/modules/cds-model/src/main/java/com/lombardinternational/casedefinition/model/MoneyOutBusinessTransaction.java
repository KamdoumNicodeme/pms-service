package com.lombardinternational.casedefinition.model;

public class MoneyOutBusinessTransaction extends BusinessTransaction {

    private String type;

    public MoneyOutBusinessTransaction() {
        super();
    }

    @Override
    public String getType() {

        return type;
    }

    @Override
    public void setType(String type) {

        this.type = type;
    }

    @Override
    public String toString() {

        return "MoneyOutBusinessTransaction [" + super.toString() + ", type=" + type + "]";
    }

}
