package com.lombardinternational.casedefinition.model;

public class MoneyInBusinessTransaction extends BusinessTransaction {

}
