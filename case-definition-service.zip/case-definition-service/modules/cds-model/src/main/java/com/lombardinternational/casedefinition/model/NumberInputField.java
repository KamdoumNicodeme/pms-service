package com.lombardinternational.casedefinition.model;

public class NumberInputField extends Field {

    private Integer min;
    private Integer max;
    private Integer decimals;
    private Integer size;

    public Integer getMin() {

        return min;
    }

    public void setMin(Integer min) {

        this.min = min;
    }

    public Integer getMax() {

        return max;
    }

    public void setMax(Integer max) {

        this.max = max;
    }

    public Integer getDecimals() {

        return decimals;
    }

    public void setDecimals(Integer decimals) {

        this.decimals = decimals;
    }

    public Integer getSize() {

        return size;
    }

    public void setSize(Integer size) {

        this.size = size;
    }

    @Override
    public String toString() {

        return "NumberInputField [" + super.toString() + " min=" + min + ", max=" + max + ", decimals=" + decimals + ", size=" + size + "]";
    }

}
