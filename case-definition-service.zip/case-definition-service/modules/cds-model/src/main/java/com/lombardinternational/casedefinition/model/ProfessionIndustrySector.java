package com.lombardinternational.casedefinition.model;

public class ProfessionIndustrySector extends HardCode {
}
