package com.lombardinternational.casedefinition.model;

/**
 * Object that represent ${@link BrokerPayee}
 *
 * @author qemo
 */
public class BrokerPayee {
    private String number;
    private String name;
    private String locationCode;
    private Broker partnerBroker;
    private InvestmentManager partnerInvestmentManager;

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLocationCode() {
        return locationCode;
    }

    public void setLocationCode(String locationCode) {
        this.locationCode = locationCode;
    }

    public Broker getPartnerBroker() {
        return partnerBroker;
    }

    public void setPartnerBroker(Broker partnerBroker) {
        this.partnerBroker = partnerBroker;
    }

    public InvestmentManager getPartnerInvestmentManager() {
        return partnerInvestmentManager;
    }

    public void setPartnerInvestmentManager(InvestmentManager partnerInvestmentManager) {
        this.partnerInvestmentManager = partnerInvestmentManager;
    }
}
