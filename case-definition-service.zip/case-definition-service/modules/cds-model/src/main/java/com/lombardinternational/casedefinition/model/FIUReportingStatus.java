package com.lombardinternational.casedefinition.model;

public class FIUReportingStatus extends HardCode {

}
