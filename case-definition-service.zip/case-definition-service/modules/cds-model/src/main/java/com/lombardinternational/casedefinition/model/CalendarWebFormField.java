package com.lombardinternational.casedefinition.model;

import java.util.Calendar;

public class CalendarWebFormField extends WebFormField {

    private Calendar value;

    public CalendarWebFormField() {
        // TODO Auto-generated constructor stub
    }

    public Calendar getValue() {

        return value;
    }

    public void setValue(Calendar value) {

        this.value = value;
    }

    @Override
    public String toString() {

        return "CalendarWebFormField [" + super.toString() + " - value=" + value + "]";
    }

}
