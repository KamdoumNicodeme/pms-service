package com.lombardinternational.casedefinition.model;

public class PolicyLink extends PolicyRole {
}
