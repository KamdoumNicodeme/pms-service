package com.lombardinternational.casedefinition.model;

/**
 * Object that represent ${@link Broker}
 *
 * @author qemo
 */
public class Broker {
    private String number;
    private String name;
    private String locationCode;
    private String serviceTeam;
    private String globalPartnerCode;

    private String distanceSellingApprovalStatus;
    private String partnerType;

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLocationCode() {
        return locationCode;
    }

    public void setLocationCode(String locationCode) {
        this.locationCode = locationCode;
    }

    public String getServiceTeam() {
        return serviceTeam;
    }

    public void setServiceTeam(String serviceTeam) {
        this.serviceTeam = serviceTeam;
    }

    public String getGlobalPartnerCode() {
        return globalPartnerCode;
    }

    public void setGlobalPartnerCode(String globalPartnerCode) {
        this.globalPartnerCode = globalPartnerCode;
    }

    public String getDistanceSellingApprovalStatus() {
        return distanceSellingApprovalStatus;
    }

    public void setDistanceSellingApprovalStatus(String distanceSellingApprovalStatus) {
        this.distanceSellingApprovalStatus = distanceSellingApprovalStatus;
    }

    public String getPartnerType() {
        return partnerType;
    }

    public void setPartnerType(String partnerType) {
        this.partnerType = partnerType;
    }
}
