# Case Definition Service

## Description

Case definition service provide some Cases SOAP services

## Development

### Swagger endpoints

- Swagger JSON doc: http://localhost:8090/v3/api-docs
- Swagger-ui: http://localhost:8090/swagger-ui/

### Useful link

- Cloud config: https://gitlab.lia.int/lia/cloud-configuration/cloud-config-files/-/tree/development/case-definition-service
- Openshift:
    - DEV: https://console-openshift-console.apps.ocp4.lia.int/k8s/cluster/projects/dev-case-definition-service
- Vault: 
    - Development: https://vault.apps.ocp4.lia.int/ui/vault/secrets/development/show/case-definition-service
    - Testing: https://vault.apps.ocp4.lia.int/ui/vault/secrets/testing/show/case-definition-service

### Run it locally on developer machine

- Run your local EMS 
- Run your ESB mock
- Run your local class installation
- Run your application without profile (``` mvn spring-boot:run ``` or with Intellij)

### Test REST endpoints


A Postman collection with some requests foreach endpoints is available here (http://confluence/live/download/attachments/79883221/case%20def%20service.postman_collection.json?version=1&modificationDate=1634304649086&api=v2)

## Useful documentation
- http://confluence/live/display/IDTT/How+to+perform+local+test+for+Brain
- http://confluence/live/display/IDTT/How+to+setup+local+Drools+and+KIE+development+platform