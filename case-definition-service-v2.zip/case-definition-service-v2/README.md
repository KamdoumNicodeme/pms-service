# case-definition-service-v2

Spring Boot 3.5.13 / Java 21 service for ONBOARDING case definitions without KIE, EMS, JMS or runtime Excel parsing.

## Scope

Implemented transaction: `ONBOARDING` / `NEW_BUSINESS_CHECKLIST` / `DIGITAL_ONBOARDING`.

The service exposes the `case-decision-service` style endpoints:

- `POST /api/rules/checklist`
- `POST /api/rules/tasklist`
- `POST /api/rules/taskscreen`
- `POST /api/rules/documents`
- `POST /api/rules/controls`
- `POST /api/rules/signatories`

It also exposes compatibility endpoints matching the legacy case-definition REST shape:

- `POST /api/screens/description`
- `POST /api/screens/task`
- `POST /api/cases/documents`
- `POST /api/cases/subTasks`
- `POST /api/cases/controls`
- `POST /api/webforms/signatories`

## Legacy source used for the initial Java transcription

- `brain/checklist-screen-rules/src/main/resources/ChecklistRules_Onboarding.xls`
- `brain/task-list-rules/src/main/resources/TaskRules_Onboarding.xls`
- `brain/task-screen-rules/src/main/resources/TaskScreenRules_Onboarding.xls`
- `brain/document-list-rules/src/main/resources/DocumentRules_Onboarding.xls`
- `brain/control-list-rules/src/main/resources/ControlRules_Onboarding.xls`

Those Excel files are not loaded by this service at runtime. The generated Java constants live in:

- `src/main/java/com/lombardinternational/casedefinition/v2/domain/rules/onboarding/OnboardingStaticRules.java`

## Architecture

The service follows the `case-decision-service` rule-builder structure:

- `domain/service/RulesEngineServiceImpl` routes requests through a transaction factory.
- `domain/service/factory/TransactionFactory` maps `NEW_BUSINESS_CHECKLIST` / `ONBOARDING` to `OnboardingRulesBuilderService`.
- `domain/service/checklist/onboarding` builds checklist tabs/groups/fields.
- `domain/service/tasklist/onboarding` builds and merges task definitions by task name.
- `domain/service/taskscreen/onboarding` builds sub-task screens.
- `domain/service/document/onboarding` builds documents.
- `domain/service/control/onboarding` builds controls.

The rule models use Lombok builders and a field hierarchy close to `case-decision-service`:

- `Field`
- `TextInputField`
- `TextAreaField`
- `NumberInputField`
- `SelectInputField`
- `CheckBoxField`
- `Group`
- `Tab`
- `TaskDefinition`
- `CaseDocumentDefinition`
- `CaseControlDefinition`

## Current migration note

Checklist/task/task-screen/document/control definitions are present as Java rules. Simple field comparisons and list membership conditions are evaluated in Java. Complex legacy helper code extracted from Drools is still a migration-hardening topic: it should be progressively rewritten as dedicated Java predicates, preferably by splitting the generated spec builders into one explicit business builder per rule where needed.

## Run

```bash
mvn spring-boot:run
```

Default port: `9070`.
