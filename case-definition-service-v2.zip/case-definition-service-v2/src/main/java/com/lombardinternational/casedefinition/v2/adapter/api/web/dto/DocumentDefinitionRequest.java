package com.lombardinternational.casedefinition.v2.adapter.api.web.dto;

public record DocumentDefinitionRequest(WebForm webForm, ScreenDescription screenDescription, String policyNumber, String transactionNumber) {
}
