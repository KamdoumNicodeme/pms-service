package com.lombardinternational.casedefinition.v2.domain.service.document;

import com.lombardinternational.casedefinition.v2.domain.model.CaseDocumentDefinition;

import java.util.List;

public abstract class AbstractDocumentBuilderService implements DocumentBuilderService {
    protected void addDocumentDefinition(String relatedTo, String relatedToPolicyNumber, String i18NRelatedToParam,
            String relatedToThirdParty, List<CaseDocumentDefinition> documents) {
        final var documentDefinition = CaseDocumentDefinition.builder().documentType(getDocumentType()).cmsDocumentType(getCmsDocumentType())
                .documentRequired(getDocumentRequired()).documentVisibleOnConnect(getDocumentVisibleOnConnect()).description(getDescription())
                .i18NDescription(getI18NDescription()).documentRelatedTo(relatedTo).relatedToPolicyNumber(relatedToPolicyNumber)
                .i18NDocumentRelatedToParam(i18NRelatedToParam).i18NDocumentRelatedTo(getI18NDocumentRelatedTo())
                .relatedToThirdpartyId(relatedToThirdParty).neverDisplayExternally(getNeverDisplayExternally()).build();
        documentDefinition.incrementOrder();
        documents.add(documentDefinition);
    }

    protected abstract String getDocumentType();
    protected abstract String getCmsDocumentType();
    protected boolean getDocumentRequired() { return false; }
    protected boolean getDocumentVisibleOnConnect() { return false; }
    protected abstract String getDescription();
    protected abstract String getI18NDescription();
    protected String getI18NDocumentRelatedTo() { return null; }
    protected boolean getNeverDisplayExternally() { return false; }
}
