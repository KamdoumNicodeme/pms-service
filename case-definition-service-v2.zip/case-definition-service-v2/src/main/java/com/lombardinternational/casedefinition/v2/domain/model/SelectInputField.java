package com.lombardinternational.casedefinition.v2.domain.model;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.util.List;

@Data
@SuperBuilder
@NoArgsConstructor
@EqualsAndHashCode(callSuper = true)
public class SelectInputField extends Field {
    private Integer minWidthPct;
    private Integer minWidthPx;
    private List<SelectInputFieldOption> options;
}
