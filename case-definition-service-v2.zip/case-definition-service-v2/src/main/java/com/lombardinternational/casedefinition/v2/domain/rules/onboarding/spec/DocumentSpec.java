package com.lombardinternational.casedefinition.v2.domain.rules.onboarding.spec;

import java.util.List;

public record DocumentSpec(String documentType, String cmsDocumentType, int order, String requiredExpression,
                           String visibleExpression, String i18nRelatedTo, String i18nRelatedToParam, String relatedTo,
                           String relatedToThirdParty, String relatedToPolicy, String description, String i18nDescription,
                           String documentSharepointId, boolean neverDisplayExternally, List<String> conditions,
                           String technicalAction, String ruleName) {
}
