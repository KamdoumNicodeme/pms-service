package com.lombardinternational.casedefinition.v2.domain.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Stream;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class WebFormGroup {
    private String fieldsetId;
    private String groupId;
    private List<WebFormField> fields = new ArrayList<>();
    private List<WebFormGroup> groups = new ArrayList<>();

    public Optional<String> findFieldValue(String fieldId) {
        return fields().filter(field -> Objects.equals(field.getFieldId(), fieldId)).findFirst().flatMap(WebFormField::effectiveValue);
    }

    public Stream<WebFormField> fields() {
        Stream<WebFormField> direct = fields == null ? Stream.empty() : fields.stream().filter(Objects::nonNull);
        Stream<WebFormField> nested = groups == null ? Stream.empty() : groups.stream().filter(Objects::nonNull).flatMap(WebFormGroup::fields);
        return Stream.concat(direct, nested);
    }
}
