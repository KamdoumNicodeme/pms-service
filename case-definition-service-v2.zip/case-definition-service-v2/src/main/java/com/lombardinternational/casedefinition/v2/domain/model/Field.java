package com.lombardinternational.casedefinition.v2.domain.model;

import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.util.concurrent.atomic.AtomicInteger;

@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
@JsonTypeInfo(use = JsonTypeInfo.Id.NAME, property = "type")
@JsonSubTypes({
        @JsonSubTypes.Type(value = LabelField.class, name = "labelField"),
        @JsonSubTypes.Type(value = TextInputField.class, name = "textInputField"),
        @JsonSubTypes.Type(value = NumberInputField.class, name = "numberInputField"),
        @JsonSubTypes.Type(value = SelectInputField.class, name = "selectInputField"),
        @JsonSubTypes.Type(value = TextAreaField.class, name = "textAreaField"),
        @JsonSubTypes.Type(value = CheckBoxField.class, name = "checkBoxField")
})
public abstract class Field {
    private static final AtomicInteger currentOrder = new AtomicInteger(1);

    private String fieldId;
    private String label;
    private String i18NLabelKey;
    private int order;
    @Builder.Default
    private Boolean enabled = false;
    @Builder.Default
    private Boolean mandatory = false;
    private Boolean multiple;
    private Integer maxMultiple;
    private String selectedValue;
    private String displayIf;
    private String enableIf;
    @Builder.Default
    private Boolean labelBold = false;
    private String sourceSystem;
    @Builder.Default
    private Boolean isActive = Boolean.FALSE;

    public static void resetFieldId() {
        currentOrder.set(1);
    }

    public void incrementOrder() {
        this.order = currentOrder.getAndIncrement();
    }
}
