package com.lombardinternational.casedefinition.v2.adapter.api.web;

import com.lombardinternational.casedefinition.v2.adapter.api.web.dto.*;
import com.lombardinternational.casedefinition.v2.adapter.api.web.mapper.CaseControlDefinitionMapper;
import com.lombardinternational.casedefinition.v2.adapter.api.web.mapper.CaseDocumentDefinitionMapper;
import com.lombardinternational.casedefinition.v2.adapter.api.web.mapper.ScreenDescriptionMapper;
import com.lombardinternational.casedefinition.v2.adapter.api.web.mapper.SignatoryResultMapper;
import com.lombardinternational.casedefinition.v2.adapter.api.web.mapper.TaskDefinitionMapper;
import com.lombardinternational.casedefinition.v2.adapter.api.web.mapper.WebFormMapper;
import com.lombardinternational.casedefinition.v2.domain.api.RulesEngineService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/rules")
@RequiredArgsConstructor
public class RulesController {
    private final RulesEngineService rulesEngineService;
    private final WebFormMapper webFormMapper;
    private final ScreenDescriptionMapper screenDescriptionMapper;
    private final CaseDocumentDefinitionMapper caseDocumentDefinitionMapper;
    private final CaseControlDefinitionMapper caseControlDefinitionMapper;
    private final TaskDefinitionMapper taskDefinitionMapper;
    private final SignatoryResultMapper signatoryResultMapper;

    @PostMapping("/checklist")
    public ResponseEntity<ScreenDescription> generateChecklist(@RequestBody ChecklistRequest request) {
        var webForm = webFormMapper.webFormFromDTO(request.webForm());
        var screenDescription = screenDescriptionMapper.screenDescriptionFromDTO(request.screenDescription());
        var checklist = rulesEngineService.buildCheckList(webForm, screenDescription, request.policyNumber(), request.transactionNumber());
        return ResponseEntity.ok(screenDescriptionMapper.DTOFromScreenDescription(checklist));
    }

    @PostMapping("/tasklist")
    public ResponseEntity<List<TaskDefinition>> generateTaskList(@RequestBody TaskListRequest request) {
        var webForm = webFormMapper.webFormFromDTO(request.webForm());
        var screenDescription = screenDescriptionMapper.screenDescriptionFromDTO(request.screenDescription());
        var taskDefinitions = rulesEngineService.buildTaskList(webForm, screenDescription, request.policyNumber());
        return ResponseEntity.ok(taskDefinitionMapper.map(taskDefinitions));
    }

    @PostMapping("/taskscreen")
    public ResponseEntity<ScreenDescription> generateTaskScreen(@RequestBody TaskScreenRequest request) {
        var webForm = webFormMapper.webFormFromDTO(request.webForm());
        var screenCheckList = screenDescriptionMapper.screenDescriptionFromDTO(request.screenCheckList());
        var screenToFill = screenDescriptionMapper.screenDescriptionFromDTO(request.screenToFill());
        var taskScreen = rulesEngineService.buildTaskScreen(webForm, screenCheckList, screenToFill);
        return ResponseEntity.ok(screenDescriptionMapper.DTOFromScreenDescription(taskScreen));
    }

    @PostMapping("/documents")
    public ResponseEntity<List<CaseDocumentDefinition>> generateDocuments(@RequestBody DocumentDefinitionRequest request) {
        var webForm = webFormMapper.webFormFromDTO(request.webForm());
        var screenDescription = screenDescriptionMapper.screenDescriptionFromDTO(request.screenDescription());
        var definitions = rulesEngineService.buildDocumentsDefinition(webForm, screenDescription, request.policyNumber(), request.transactionNumber());
        return ResponseEntity.ok(caseDocumentDefinitionMapper.dtoFromCaseDocumentDefinition(definitions));
    }

    @PostMapping("/controls")
    public ResponseEntity<List<CaseControlDefinition>> generateControls(@RequestBody ControlDefinitionRequest request) {
        var webForm = webFormMapper.webFormFromDTO(request.webForm());
        var screenDescription = screenDescriptionMapper.screenDescriptionFromDTO(request.screenDescription());
        var definitions = rulesEngineService.buildControlDefinition(webForm, screenDescription);
        return ResponseEntity.ok(caseControlDefinitionMapper.dtoFromCaseControlDefinition(definitions));
    }

    @PostMapping("/signatories")
    public ResponseEntity<SignatoryResult> generateSignatories(@RequestBody SignatoriesRequest request) {
        var webForm = webFormMapper.webFormFromDTO(request.webForm());
        var result = rulesEngineService.buildSignatories(webForm, request.policyNumber());
        return ResponseEntity.ok(signatoryResultMapper.dtoFromSignatoryResult(result));
    }
}
