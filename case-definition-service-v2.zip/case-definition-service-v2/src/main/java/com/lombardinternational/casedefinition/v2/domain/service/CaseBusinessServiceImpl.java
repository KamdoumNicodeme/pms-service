package com.lombardinternational.casedefinition.v2.domain.service;

import com.lombardinternational.casedefinition.v2.domain.api.CaseBusinessService;
import com.lombardinternational.casedefinition.v2.domain.api.PolicyService;
import com.lombardinternational.casedefinition.v2.domain.model.CaseControlDefinition;
import com.lombardinternational.casedefinition.v2.domain.model.CaseDocumentDefinition;
import com.lombardinternational.casedefinition.v2.domain.model.Policy;
import com.lombardinternational.casedefinition.v2.domain.model.ScreenDescription;
import com.lombardinternational.casedefinition.v2.domain.model.TaskDefinition;
import com.lombardinternational.casedefinition.v2.domain.model.WebForm;
import com.lombardinternational.casedefinition.v2.domain.transaction.onboarding.rules.OnboardingTransactionIds;
import com.lombardinternational.casedefinition.v2.domain.spi.RulesWebService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.List;

@Service
@RequiredArgsConstructor
public class CaseBusinessServiceImpl implements CaseBusinessService {
    private static final String NEW_BUSINESS_CASE_TYPE = "NEW_BUSINESS";
    private static final String ONBOARDING_CASE_TYPE = "ONBOARDING";
    private static final List<String> CIM_CCB_CASE_TYPES = List.of("CIM", "CCB", "CIM_CCB");

    private final RulesWebService rulesWebService;
    private final PolicyService policyService;

    @Override
    public List<CaseDocumentDefinition> computeCaseDocumentsDefinition(String policyNumber, String caseType, WebForm webForm,
            ScreenDescription screenCheckList) {
        Policy policy = StringUtils.hasText(policyNumber) && !NEW_BUSINESS_CASE_TYPE.equals(caseType)
                ? policyService.buildPolicy(policyNumber)
                : null;
        return rulesWebService.computeCaseDocumentsDefinition(policy, evaluatedWebForm(caseType, webForm), screenCheckList);
    }

    @Override
    public List<CaseControlDefinition> computeCaseControlDefinitions(String caseType, WebForm webForm,
            ScreenDescription screenCheckList) {
        return rulesWebService.computeCaseControlDefinitions(evaluatedWebForm(caseType, webForm), screenCheckList);
    }

    @Override
    public List<TaskDefinition> computeCaseSubTasks(String policyNumber, String caseType, WebForm webForm,
            ScreenDescription screenCheckList) {
        Policy policy = StringUtils.hasText(policyNumber) && !NEW_BUSINESS_CASE_TYPE.equals(caseType)
                ? policyService.buildPolicy(policyNumber)
                : null;
        ScreenDescription checklist = screenCheckList == null ? new ScreenDescription() : screenCheckList;
        if (!StringUtils.hasText(checklist.getScreenId())) {
            checklist.setScreenId(convertCaseTypeToCheckListScreenId(caseType));
        }
        return rulesWebService.computeTaskDefinition(policy, evaluatedWebForm(caseType, webForm), checklist);
    }

    private WebForm evaluatedWebForm(String caseType, WebForm webForm) {
        return CIM_CCB_CASE_TYPES.contains(caseType) ? null : webForm;
    }

    private String convertCaseTypeToCheckListScreenId(String caseType) {
        if (ONBOARDING_CASE_TYPE.equals(caseType) || NEW_BUSINESS_CASE_TYPE.equals(caseType)) {
            return OnboardingTransactionIds.CHECKLIST_SCREEN_ID;
        }
        return "";
    }
}
