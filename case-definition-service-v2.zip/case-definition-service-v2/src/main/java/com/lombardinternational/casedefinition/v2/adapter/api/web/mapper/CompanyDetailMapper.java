package com.lombardinternational.casedefinition.v2.adapter.api.web.mapper;

import com.lombardinternational.casedefinition.v2.domain.model.CompanyDetail;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface CompanyDetailMapper {
    CompanyDetail companyDetailFromDTO(com.lombardinternational.casedefinition.v2.adapter.api.web.dto.CompanyDetail dto);

    com.lombardinternational.casedefinition.v2.adapter.api.web.dto.CompanyDetail dtoFromCompanyDetail(CompanyDetail companyDetail);
}
