package com.lombardinternational.casedefinition.v2.adapter.api.web.mapper;

import com.lombardinternational.casedefinition.v2.domain.model.Tab;
import org.mapstruct.Mapper;

import java.util.List;

@Mapper(componentModel = "spring", uses = {GroupMapper.class})
public interface TabMapper {
    Tab tabFromDTO(com.lombardinternational.casedefinition.v2.adapter.api.web.dto.Tab tabDTO);

    List<Tab> tabFromDTO(List<com.lombardinternational.casedefinition.v2.adapter.api.web.dto.Tab> tabDTOs);

    com.lombardinternational.casedefinition.v2.adapter.api.web.dto.Tab DTOFromTab(Tab tab);

    List<com.lombardinternational.casedefinition.v2.adapter.api.web.dto.Tab> DTOFromTab(List<Tab> tabs);
}
