package com.lombardinternational.casedefinition.v2.domain.service.checklist.onboarding.group;

import com.lombardinternational.casedefinition.v2.domain.model.Group;
import com.lombardinternational.casedefinition.v2.domain.model.ScreenDescription;
import com.lombardinternational.casedefinition.v2.domain.model.Tab;
import com.lombardinternational.casedefinition.v2.domain.model.WebForm;
import com.lombardinternational.casedefinition.v2.domain.service.checklist.GroupBuilderService;
import com.lombardinternational.casedefinition.v2.domain.service.checklist.onboarding.field.OnboardingDueDiligenceFieldsBuilderService;
import com.lombardinternational.casedefinition.v2.domain.utils.ChecklistUtils;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import static com.lombardinternational.casedefinition.v2.domain.transaction.onboarding.rules.OnboardingChecklistIds.DUE_DILIGENCE_GROUP;

@Service
@AllArgsConstructor
public class OnboardingDueDiligenceGroupBuilderService implements GroupBuilderService {
    private final OnboardingDueDiligenceFieldsBuilderService fieldsBuilderService;

    @Override
    public void buildGroup(WebForm webForm, ScreenDescription screenDescription, Tab parentTab) {
        var group = ChecklistUtils.getGroupInTab(parentTab, DUE_DILIGENCE_GROUP);
        if (group == null) {
            group = Group.builder().groupId(DUE_DILIGENCE_GROUP).build();
            parentTab.getGroups().add(group);
        }

        group.setIsActive(true);
        group.setOrder(7);
        group.setTitle("Due diligence - EBO and related parties to the policy");
        group.setColumnsCount(2);
        group.setDisplayIf(null);
        fieldsBuilderService.buildField(webForm, screenDescription, group);
    }
}
