package com.lombardinternational.casedefinition.v2.domain.service.checklist;

import com.lombardinternational.casedefinition.v2.domain.model.ScreenDescription;
import com.lombardinternational.casedefinition.v2.domain.model.WebForm;

public interface ChecklistBuilderService {
    ScreenDescription buildChecklist(WebForm webForm, ScreenDescription screenDescription, String policyNumber, String transactionNumber);
}
