package com.lombardinternational.casedefinition.v2.domain.model;

public class Trustee extends PolicyRole {
}
