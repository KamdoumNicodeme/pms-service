package com.lombardinternational.casedefinition.v2.domain.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class DocumentRequiredSignatory {
    private String documentType;
    private String documentRelatedTo;
    private boolean documentMustBeGenerated;
    private boolean documentRequiredOnConnect;
    private String description;
    private String i18NDescription;
    private int documentOrder;
    @Builder.Default
    private List<RequiredSignatory> requiredSignatories = new ArrayList<>();
    private String cmsDocumentType;
}
