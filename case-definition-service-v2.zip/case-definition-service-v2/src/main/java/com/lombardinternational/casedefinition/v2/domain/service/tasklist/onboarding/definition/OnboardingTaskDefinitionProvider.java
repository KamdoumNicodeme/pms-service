package com.lombardinternational.casedefinition.v2.domain.service.tasklist.onboarding.definition;

import org.springframework.stereotype.Service;

import com.lombardinternational.casedefinition.v2.domain.rules.onboarding.spec.TaskSpec;

import java.util.ArrayList;
import java.util.List;

/**
 * Java source of truth for ONBOARDING rules migrated from the legacy Brain Excel sheets.
 */
@Service
public class OnboardingTaskDefinitionProvider {
    public List<TaskSpec> tasks() {
        List<TaskSpec> specs = new ArrayList<>();
        addTasks(specs);
        return List.copyOf(specs);
    }

    private void addTasks(List<TaskSpec> specs) {
        specs.add(new TaskSpec(true, false, "Compliance check", "COMPLIANCE_NEW_BUSINESS", 10, "60*60*24*2", "60*60*24", false, "#forcedValue", List.of("BUSINESS_ORIGIN, != \"IT\"", "PCS_REVIEW,\nNone (Compliance escalation required);Senior sign-off,\nfalse,\nfalse,"), "taskTriggered = false;\nString riskReason = ((Field) getObjectById(\"RISK_REASON\", sd)).getSelectedValue();\nif (!riskReason.isEmpty()) {\n    forcedValue = riskReason;\n    taskTriggered = true;\n}", "Onboarding_Tasks.Rule1"));
        specs.add(new TaskSpec(true, false, "Compliance check", "COMPLIANCE_NEW_BUSINESS", 10, "60*60*24*2", "60*60*24", false, "Market abuse", List.of("INSIDER, == \"YES\""), "", "Onboarding_Tasks.Rule2"));
        specs.add(new TaskSpec(true, false, "Compliance check", "COMPLIANCE_NEW_BUSINESS", 10, "60*60*24*2", "60*60*24", false, "Italian branch PEP", List.of("BUSINESS_ORIGIN, == \"IT\"", "PEP, == \"YES\""), "", "Onboarding_Tasks.Rule3"));
        specs.add(new TaskSpec(true, false, "Compliance check", "COMPLIANCE_NEW_BUSINESS", 10, "60*60*24*2", "60*60*24", false, "TCC signed by fiscal adviser OR Tax return AND Escalation to Tax Compliance - if No TCC", List.of("EBO_RESIDENCE_COUNTRY_RISK,\nAS;BS;GU;KN;NA;TT;VI;WS,\ntrue,\nfalse,"), "", "Onboarding_Tasks.Rule4"));
        specs.add(new TaskSpec(true, false, "Compliance check", "COMPLIANCE_NEW_BUSINESS", 10, "60*60*24*2", "60*60*24", false, "Contact client to obtain explanation (Residence vs fiscal country) or correct information AND If not sensible explanation obtained - Escalation to Compliance", List.of(), "taskTriggered = false;\n\nString phResidenceCountryRisk = getFieldValue(getObjectById(\"PH_RESIDENCE_COUNTRY_RISK\", sd));\nList<String> residenceCountries = extractCountries(phResidenceCountryRisk);\n\nString phFiscalCountry = getFieldValue(getObjectById(\"PH_FISCAL_COUNTRY\", sd));\nList<String> fiscalCountries = extractCountries(phFiscalCountry);\n\nif (Collections.disjoint(residenceCountries, fiscalCountries)) {\n    taskTriggered = true;\n}", "Onboarding_Tasks.Rule5"));
        specs.add(new TaskSpec(true, false, "Compliance check", "COMPLIANCE_NEW_BUSINESS", 10, "60*60*24*2", "60*60*24", false, "Check with client why no TCC signed AND Escalation to Tax Compliance - if refused again (No TCC)", List.of("TCC_SIGNED, == \"NO\""), "", "Onboarding_Tasks.Rule6"));
        specs.add(new TaskSpec(false, false, "Compliance check", "COMPLIANCE_NEW_BUSINESS", 10, "60*60*24*2", "60*60*24", false, "", List.of(), "", "Onboarding_Tasks.Rule7"));
        specs.add(new TaskSpec(true, false, "IC-Asset", "IC_NEW_BUSINESS", 10, "60*60*24*2", "60*60*24", false, "Escalation to Investment Compliance - Premium with assets", List.of("PREMIUM_WITH_ASSETS, == \"YES\""), "", "Onboarding_Tasks.Rule8"));
        specs.add(new TaskSpec(false, false, "IC-Asset", "IC_NEW_BUSINESS", 10, "60*60*24*2", "60*60*24", false, "", List.of(), "", "Onboarding_Tasks.Rule9"));
        specs.add(new TaskSpec(false, false, "Unquoted", "UNQUOTED_NEW_BUSINESS", 60, "60*60*24*30", "60*60*24", false, "", List.of(), "", "Onboarding_Tasks.Rule10"));
        specs.add(new TaskSpec(true, false, "Strategy Monitoring", "STRATEGY_MONITORING_NEW_BUSINESS", 60, "60*60*24*30", "60*60*24", false, "This task is always mandatory", List.of(), "", "Onboarding_Tasks.Rule11"));
        specs.add(new TaskSpec(false, false, "Daily Operations Team", "DOT_NEW_BUSINESS", 10, "60*60*24*2", "60*60*24", true, "", List.of(), "", "Onboarding_Tasks.Rule12"));
        specs.add(new TaskSpec(false, false, "Complex", "COMPLEX_UNQ_NEW_BUSINESS", 60, "60*60*24*30", "60*60*24", true, "", List.of(), "", "Onboarding_Tasks.Rule13"));
        specs.add(new TaskSpec(false, false, "eBAC escalation", "EBAC_NEW_BUSINESS", 60, "60*60*24*30", "60*60*24", true, "", List.of(), "", "Onboarding_Tasks.Rule14"));
        specs.add(new TaskSpec(false, false, "Physical BAC escalation", "BAC_NEW_BUSINESS", 60, "60*60*24*30", "60*60*24", true, "", List.of(), "", "Onboarding_Tasks.Rule15"));
        specs.add(new TaskSpec(false, false, "Inadmissible Asset", "INAD_ASSET_NEW_BUSINESS", 60, "60*60*24*30", "60*60*24", true, "", List.of(), "", "Onboarding_Tasks.Rule16"));
        specs.add(new TaskSpec(false, false, "NTA Notification", "", 60, "60*60*24*30", "60*60*24", true, "", List.of(), "", "Onboarding_Tasks.Rule17"));
        specs.add(new TaskSpec(false, false, "Free Task", "", 60, "60*60*24*30", "60*60*24", false, "", List.of(), "", "Onboarding_Tasks.Rule18"));
        specs.add(new TaskSpec(false, false, "Free Sub-Task", "", 60, "60*60*24*30", "60*60*24", true, "", List.of(), "", "Onboarding_Tasks.Rule19"));
        specs.add(new TaskSpec(true, false, "AML sign-off", "", 60, "60*60*24*2", "60*60*24", false, "", List.of(), "", "Onboarding_Tasks.Rule20"));
    }
}
