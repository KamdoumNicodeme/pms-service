package com.lombardinternational.casedefinition.v2.adapter.api.web.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonTypeInfo(use = JsonTypeInfo.Id.NAME, property = "type")
@JsonSubTypes({
        @JsonSubTypes.Type(value = LabelField.class, name = "labelField"),
        @JsonSubTypes.Type(value = TextInputField.class, name = "textInputField"),
        @JsonSubTypes.Type(value = NumberInputField.class, name = "numberInputField"),
        @JsonSubTypes.Type(value = SelectInputField.class, name = "selectInputField"),
        @JsonSubTypes.Type(value = TextAreaField.class, name = "textAreaField"),
        @JsonSubTypes.Type(value = CheckBoxField.class, name = "checkBoxField")
})
public abstract class Field {
    private String fieldId;
    private String label;
    private String i18NLabelKey;
    private int order;
    @Builder.Default
    private Boolean enabled = Boolean.FALSE;
    @Builder.Default
    private Boolean mandatory = Boolean.FALSE;
    private Boolean multiple;
    private Integer maxMultiple;
    private String selectedValue;
    private String displayIf;
    private String enableIf;
    private Boolean labelBold;
    private String sourceSystem;
    private Boolean isActive;
}
