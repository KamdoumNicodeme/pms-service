package com.lombardinternational.casedefinition.v2.adapter.api.web.mapper;

import com.lombardinternational.casedefinition.v2.domain.model.WebFormField;
import org.mapstruct.Mapper;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Collection;
import java.util.List;

@Mapper(componentModel = "spring")
public abstract class TextWebFormFieldMapper {
    @Autowired
    protected WebFormFieldMapper webFormFieldMapper;

    public List<WebFormField> textWebFormFieldFromDTO(
            Collection<com.lombardinternational.casedefinition.v2.adapter.api.web.dto.TextWebFormField> dtos) {
        return webFormFieldMapper.webFormFieldFromDTO(dtos);
    }
}
