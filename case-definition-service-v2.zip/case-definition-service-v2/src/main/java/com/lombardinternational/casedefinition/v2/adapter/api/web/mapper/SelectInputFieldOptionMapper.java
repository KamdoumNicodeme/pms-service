package com.lombardinternational.casedefinition.v2.adapter.api.web.mapper;

import com.lombardinternational.casedefinition.v2.domain.model.SelectInputFieldOption;
import org.mapstruct.Mapper;

import java.util.List;

@Mapper(componentModel = "spring")
public interface SelectInputFieldOptionMapper {
    SelectInputFieldOption selectInputFieldOptionFromDTO(
            com.lombardinternational.casedefinition.v2.adapter.api.web.dto.SelectInputFieldOption dto);

    List<SelectInputFieldOption> selectInputFieldOptionFromDTO(
            List<com.lombardinternational.casedefinition.v2.adapter.api.web.dto.SelectInputFieldOption> dtos);

    com.lombardinternational.casedefinition.v2.adapter.api.web.dto.SelectInputFieldOption dtoFromSelectInputFieldOption(
            SelectInputFieldOption option);

    List<com.lombardinternational.casedefinition.v2.adapter.api.web.dto.SelectInputFieldOption> dtoFromSelectInputFieldOption(
            List<SelectInputFieldOption> options);
}
