package com.lombardinternational.casedefinition.v2.domain.model;

import lombok.Data;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Data
public class BusinessTransaction {
    private String identifier;
    private String type;
    private String category;
    private String subCategory;
    private LocalDate closeDate;
    private TransactionAmounts transactionAmounts;
    private Amount expectedAmount;
    private Amount expectedAmountEur;
    private Amount transactionAmountEur;
    private Boolean isInRemediationList;
    private Boolean isPolicyRemediated;
    private List<BusinessTransactionProductComponent> productComponentPayments = new ArrayList<>();
}
