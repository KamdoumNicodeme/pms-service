package com.lombardinternational.casedefinition.v2.adapter.api.web.mapper;

import com.lombardinternational.casedefinition.v2.domain.model.CaseDocumentDefinition;
import org.mapstruct.Mapper;

import java.util.List;

@Mapper(componentModel = "spring")
public interface CaseDocumentDefinitionMapper {
    List<com.lombardinternational.casedefinition.v2.adapter.api.web.dto.CaseDocumentDefinition> dtoFromCaseDocumentDefinition(
            List<CaseDocumentDefinition> definitions);
}
