package com.lombardinternational.casedefinition.v2.domain.service.checklist.onboarding.field;

import com.lombardinternational.casedefinition.v2.domain.model.Group;
import com.lombardinternational.casedefinition.v2.domain.model.ScreenDescription;
import com.lombardinternational.casedefinition.v2.domain.model.WebForm;
import com.lombardinternational.casedefinition.v2.domain.service.checklist.FieldBuilderService;
import org.springframework.stereotype.Service;

import java.util.Map;

@Service
public class OnboardingSignatureFieldsBuilderService extends OnboardingChecklistFieldsBuilderSupport implements FieldBuilderService {
    @Override
    public void buildField(WebForm webForm, ScreenDescription screenDescription, Group group) {
        var previousValues = previousValues(screenDescription);
        resetFields(group);
        buildSignatureType(group, previousValues, webForm);
        buildProvider(group, previousValues, webForm);
        buildEuAuthorisedProvider(group, previousValues, webForm);
        buildClientIdentificationValidation(group, previousValues, webForm);
        buildMultifactorAuthentication(group, previousValues, webForm);
        buildOriginalSignedDocumentAuditLogCmt(group, previousValues, webForm);
        sortFields(group);
    }

    private void buildSignatureType(Group group, Map<String, String> previousValues, WebForm webForm) {
        buildField(group, new FieldRule("SIGNATURE_TYPE", FieldKind.SELECT, 1, "Signature Type?", true, true,
                "ELECTRONIC\u00acElectronic;WET\u00acWet;MULTIPLE\u00acMultiple", null, false, null, false), previousValues, webForm);
    }

    private void buildProvider(Group group, Map<String, String> previousValues, WebForm webForm) {
        buildField(group, new FieldRule("PROVIDER", FieldKind.SELECT, 2, "Provider?", true, false,
                "INTERNAL_PROVIDER\u00acInternal Provider;PARTNER_ESIGN_SERVICE\u00acPartner e-signature service", "true", false, "false", false), previousValues, webForm);
    }

    private void buildEuAuthorisedProvider(Group group, Map<String, String> previousValues, WebForm webForm) {
        buildField(group, new FieldRule("EU_AUTHORISED_PROVIDER", FieldKind.CHECK_BOX, 3, "EU authorised Provider?", true, true,
                null, "(#SIGNATURE_TYPE# == \"ELECTRONIC\" || #SIGNATURE_TYPE# == \"MULTIPLE\") && #PROVIDER# == \"PARTNER_ESIGN_SERVICE\"", false, null, false), previousValues, webForm);
    }

    private void buildClientIdentificationValidation(Group group, Map<String, String> previousValues, WebForm webForm) {
        buildField(group, new FieldRule("CLIENT_IDENTIFICATION_VALIDATION", FieldKind.CHECK_BOX, 4, "Client Identification & Validation?", true, true,
                null, "(#SIGNATURE_TYPE# == \"ELECTRONIC\" || #SIGNATURE_TYPE# == \"MULTIPLE\") && (#PROVIDER# == \"PARTNER_ESIGN_SERVICE\" || #PROVIDER# == \"INTERNAL_PROVIDER\")", false, null, false), previousValues, webForm);
    }

    private void buildMultifactorAuthentication(Group group, Map<String, String> previousValues, WebForm webForm) {
        buildField(group, new FieldRule("MULTIFACTOR_AUTHENTICATION", FieldKind.CHECK_BOX, 5, "Multifactor Authentication?", true, true,
                null, "(#SIGNATURE_TYPE# == \"ELECTRONIC\" || #SIGNATURE_TYPE# == \"MULTIPLE\") && #PROVIDER# == \"PARTNER_ESIGN_SERVICE\"", false, null, false), previousValues, webForm);
    }

    private void buildOriginalSignedDocumentAuditLogCmt(Group group, Map<String, String> previousValues, WebForm webForm) {
        buildField(group, new FieldRule("ORIGINAL_SIGNED_DOCUMENT_AUDIT_LOG_CMT", FieldKind.CHECK_BOX, 6, "Original Signed Document + Audit Log in CMT?", true, true,
                null, "(#SIGNATURE_TYPE# == \"ELECTRONIC\" || #SIGNATURE_TYPE# == \"MULTIPLE\") && (#PROVIDER# == \"PARTNER_ESIGN_SERVICE\" || #PROVIDER# == \"INTERNAL_PROVIDER\")", false, null, false), previousValues, webForm);
    }

}
