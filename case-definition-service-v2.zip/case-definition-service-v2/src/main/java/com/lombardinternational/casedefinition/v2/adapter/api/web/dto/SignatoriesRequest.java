package com.lombardinternational.casedefinition.v2.adapter.api.web.dto;

public record SignatoriesRequest(WebForm webForm, String policyNumber) {
}
