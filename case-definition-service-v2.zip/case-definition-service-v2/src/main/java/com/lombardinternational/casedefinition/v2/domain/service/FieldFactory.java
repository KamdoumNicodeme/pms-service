package com.lombardinternational.casedefinition.v2.domain.service;

import com.lombardinternational.casedefinition.v2.domain.model.*;
import com.lombardinternational.casedefinition.v2.domain.rules.onboarding.spec.FieldSpec;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Component
public class FieldFactory {
    public Field create(FieldSpec spec, Map<String, String> previousValues, WebForm webForm) {
        Field field = switch (spec.fieldType()) {
            case "SelectInputField" -> new SelectInputField();
            case "NumberInputField" -> new NumberInputField();
            case "TextAreaField" -> new TextAreaField();
            case "CheckBoxField" -> new CheckBoxField();
            default -> new TextInputField();
        };
        field.setFieldId(spec.fieldId());
        field.setOrder(spec.order());
        field.setLabel(spec.label());
        field.setEnabled(spec.enabled());
        field.setMandatory(spec.mandatory());
        field.setDisplayIf(blankToNull(spec.displayIf()));
        field.setLabelBold(spec.labelBold());
        field.setSourceSystem(blankToNull(spec.sourceSystem()));
        field.setIsActive(true);
        field.setSelectedValue(resolveSelectedValue(spec, previousValues, webForm));
        if (field instanceof SelectInputField selectInputField) {
            selectInputField.setOptions(parseOptions(spec.valueOptions()));
        }
        return field;
    }

    private String resolveSelectedValue(FieldSpec spec, Map<String, String> previousValues, WebForm webForm) {
        String previous = previousValues.get(spec.fieldId());
        if (previous != null) {
            return previous;
        }
        String valueOptions = spec.valueOptions();
        if (valueOptions == null || valueOptions.isBlank() || looksLikeOptionList(valueOptions) || valueOptions.startsWith("#")) {
            if (webForm != null && "#forcedValue".equals(valueOptions)) {
                return webForm.findFieldValue(spec.fieldId()).orElse(null);
            }
            return null;
        }
        if (valueOptions.endsWith("String")) {
            return null;
        }
        return valueOptions;
    }

    private List<SelectInputFieldOption> parseOptions(String valueOptions) {
        if (valueOptions == null || valueOptions.isBlank() || valueOptions.startsWith("#") || valueOptions.endsWith("String")) {
            return List.of();
        }
        if (!looksLikeOptionList(valueOptions)) {
            return List.of();
        }
        List<SelectInputFieldOption> options = new ArrayList<>();
        for (String item : valueOptions.split(";")) {
            if (item.isBlank()) {
                continue;
            }
            String[] parts = item.split("¬", 2);
            String key = parts[0].trim();
            String value = parts.length > 1 ? parts[1].trim() : key;
            options.add(new SelectInputFieldOption(key, value));
        }
        return options;
    }

    private boolean looksLikeOptionList(String valueOptions) {
        return valueOptions.contains(";") || valueOptions.contains("¬");
    }

    private String blankToNull(String value) {
        return value == null || value.isBlank() ? null : value;
    }
}
