package com.lombardinternational.casedefinition.v2.domain.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class SignatoryResult {
    @Builder.Default
    private List<DocumentRequiredSignatory> documentRequiredSignatories = new ArrayList<>();
    @Builder.Default
    private Map<String, String> responseMessages = new LinkedHashMap<>();
}
