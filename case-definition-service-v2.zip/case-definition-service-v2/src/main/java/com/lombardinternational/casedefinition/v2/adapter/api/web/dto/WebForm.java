package com.lombardinternational.casedefinition.v2.adapter.api.web.dto;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class WebForm {
    private UserDetail userDetail;
    private CompanyDetail companyDetail;
    private FormInitiator formInitiator;
    @NotBlank(message = "webFormId is mandatory")
    private String webFormId;
    private String webFormWorkFlow;
    @Builder.Default
    @JsonAlias({"webFormGroups", "caseInitializationData"})
    private List<WebFormGroup> groups = new ArrayList<>();

    public List<WebFormGroup> getWebFormGroups() {
        return groups;
    }

    public void setWebFormGroups(List<WebFormGroup> webFormGroups) {
        this.groups = webFormGroups;
    }
}
