package com.lombardinternational.casedefinition.v2.adapter.api.web.dto;

public class BigDecimalWebFormField extends WebFormField {
}
