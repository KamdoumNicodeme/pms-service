package com.lombardinternational.casedefinition.v2.domain.model;

import lombok.Data;

@Data
public class TransactionAmounts {
    private Amount grossAmount;
}
