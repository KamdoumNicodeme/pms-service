package com.lombardinternational.casedefinition.v2.domain.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CurrencyExchangeRate {
    private String provider;
    private String baseIsoCurrencyCode;
    private String quotedIsoCurrencyCode;
    private BigDecimal rate;
    private LocalDate rateDate;
    private LocalTime rateTime;
}
