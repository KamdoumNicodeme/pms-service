package com.lombardinternational.casedefinition.v2.domain.service;

import com.lombardinternational.casedefinition.v2.domain.api.PolicyService;
import com.lombardinternational.casedefinition.v2.domain.api.WebFormBusinessService;
import com.lombardinternational.casedefinition.v2.domain.model.Policy;
import com.lombardinternational.casedefinition.v2.domain.model.SignatoryResult;
import com.lombardinternational.casedefinition.v2.domain.model.WebForm;
import com.lombardinternational.casedefinition.v2.domain.spi.RulesWebService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

@Service
@RequiredArgsConstructor
public class WebFormBusinessServiceImpl implements WebFormBusinessService {
    private static final String NEW_BUSINESS_CASE_TYPE = "NEW_BUSINESS";

    private final PolicyService policyService;
    private final RulesWebService rulesWebService;

    @Override
    public SignatoryResult computeSignatories(String caseType, String policyNumber, WebForm webForm) {
        Policy policy = StringUtils.hasText(policyNumber) && !NEW_BUSINESS_CASE_TYPE.equals(caseType)
                ? policyService.buildPolicy(policyNumber)
                : null;
        return rulesWebService.computeSignatories(policy, webForm);
    }
}
