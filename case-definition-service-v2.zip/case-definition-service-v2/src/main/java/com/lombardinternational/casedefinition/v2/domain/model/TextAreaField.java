package com.lombardinternational.casedefinition.v2.domain.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
@EqualsAndHashCode(callSuper = true)
public class TextAreaField extends Field {
    private Integer rows;
    private Integer cols;
    private Integer minChars;
    private Integer maxChars;
}
