package com.lombardinternational.casedefinition.v2.adapter.api.web.mapper;

import com.lombardinternational.casedefinition.v2.domain.model.UserDetail;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface UserDetailMapper {
    UserDetail userDetailFromDTO(com.lombardinternational.casedefinition.v2.adapter.api.web.dto.UserDetail dto);

    com.lombardinternational.casedefinition.v2.adapter.api.web.dto.UserDetail dtoFromUserDetail(UserDetail userDetail);
}
