package com.lombardinternational.casedefinition.v2.adapter.api.web.mapper;

import com.lombardinternational.casedefinition.v2.domain.model.WebForm;
import org.mapstruct.Mapping;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring", uses = {UserDetailMapper.class, CompanyDetailMapper.class, FormInitiatorlMapper.class, WebFormGroupMapper.class})
public interface WebFormMapper {
    @Mapping(source = "groups", target = "webFormGroups")
    WebForm webFormFromDTO(com.lombardinternational.casedefinition.v2.adapter.api.web.dto.WebForm dto);

    @Mapping(source = "webFormGroups", target = "groups")
    com.lombardinternational.casedefinition.v2.adapter.api.web.dto.WebForm dtoFromWebForm(WebForm webForm);
}
