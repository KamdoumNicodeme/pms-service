package com.lombardinternational.casedefinition.v2.domain.service;

import com.lombardinternational.casedefinition.v2.domain.model.ScreenDescription;
import com.lombardinternational.casedefinition.v2.domain.model.WebForm;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Locale;
import java.util.Optional;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Component
public class ConditionEvaluator {
    private static final Pattern FIELD_COMPARISON = Pattern.compile("^([A-Za-z0-9_]+)\\s*,\\s*(==|!=|>=|<=|>|<)\\s*\"?([^\"]*)\"?.*$");

    public boolean matches(List<String> rawConditions, WebForm webForm, ScreenDescription screenDescription) {
        if (rawConditions == null || rawConditions.isEmpty()) {
            return true;
        }
        return rawConditions.stream().allMatch(condition -> matches(condition, webForm, screenDescription));
    }

    private boolean matches(String rawCondition, WebForm webForm, ScreenDescription screenDescription) {
        if (rawCondition == null || rawCondition.isBlank() || "X".equals(rawCondition.trim())) {
            return true;
        }
        String condition = rawCondition.trim();
        Matcher matcher = FIELD_COMPARISON.matcher(condition);
        if (matcher.matches()) {
            String fieldId = matcher.group(1);
            String operator = matcher.group(2);
            String expected = stripQuotes(matcher.group(3));
            Optional<String> value = valueOf(fieldId, webForm, screenDescription);
            return value.map(actual -> compare(actual, operator, expected)).orElse(false);
        }

        String[] parts = condition.split(",");
        if (parts.length >= 2 && parts[0].trim().matches("[A-Za-z0-9_]+")) {
            String fieldId = parts[0].trim();
            String listExpression = parts[1].replace("|", "").trim();
            if (listExpression.contains(";")) {
                Optional<String> value = valueOf(fieldId, webForm, screenDescription);
                boolean inList = value.map(actual -> List.of(listExpression.split(";")).stream()
                        .map(String::trim)
                        .anyMatch(item -> item.equalsIgnoreCase(actual.trim()))).orElse(false);
                return condition.contains("false, | true") || condition.endsWith("true,") ? !inList : inList;
            }
        }

        // Complex legacy Java helper conditions are preserved on the output object as triggerCondition.
        // They are treated as applicable until the dedicated Java rule is implemented.
        return true;
    }

    private Optional<String> valueOf(String fieldId, WebForm webForm, ScreenDescription screenDescription) {
        if (screenDescription != null) {
            Optional<String> checklistValue = screenDescription.findField(fieldId).map(field -> field.getSelectedValue());
            if (checklistValue.isPresent()) {
                return checklistValue;
            }
        }
        if (webForm != null) {
            return webForm.findFieldValue(fieldId);
        }
        return Optional.empty();
    }

    private boolean compare(String actual, String operator, String expected) {
        return switch (operator) {
            case "==" -> actual.equalsIgnoreCase(expected);
            case "!=" -> !actual.equalsIgnoreCase(expected);
            case ">", ">=", "<", "<=" -> compareNumbers(actual, operator, expected);
            default -> false;
        };
    }

    private boolean compareNumbers(String actual, String operator, String expected) {
        try {
            double left = Double.parseDouble(actual);
            double right = Double.parseDouble(expected);
            return switch (operator) {
                case ">" -> left > right;
                case ">=" -> left >= right;
                case "<" -> left < right;
                case "<=" -> left <= right;
                default -> false;
            };
        } catch (NumberFormatException ex) {
            return false;
        }
    }

    private String stripQuotes(String value) {
        String stripped = value == null ? "" : value.trim();
        if (stripped.toLowerCase(Locale.ROOT).endsWith(",")) {
            stripped = stripped.substring(0, stripped.length() - 1);
        }
        return stripped.replace("\"", "").trim();
    }
}
