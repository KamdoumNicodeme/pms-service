package com.lombardinternational.casedefinition.v2.domain.rules.onboarding.spec;

import java.util.List;

public record ControlSpec(String controlName, boolean visibleOnConnect, int order, String controlType,
                          List<String> conditions, String technicalAction, String ruleName) {
}
