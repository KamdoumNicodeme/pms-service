package com.lombardinternational.casedefinition.v2.adapter.api.web.mapper;

import com.lombardinternational.casedefinition.v2.domain.model.NumberInputField;
import org.mapstruct.Mapper;

import java.util.List;

@Mapper(componentModel = "spring")
public interface NumberInputFieldMapper {
    List<NumberInputField> numberInputFieldFromDTO(List<com.lombardinternational.casedefinition.v2.adapter.api.web.dto.NumberInputField> dtos);
}
