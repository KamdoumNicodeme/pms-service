package com.lombardinternational.casedefinition.v2.adapter.spi.service.rest;

import com.lombardinternational.casedefinition.v2.adapter.spi.service.rest.mapper.FundMapper;
import com.lombardinternational.casedefinition.v2.domain.model.Fund;
import com.lombardinternational.casedefinition.v2.domain.spi.FundWebService;
import com.lombardinternational.clients.classapp.client.FundServiceClient;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.List;

@Service
@RequiredArgsConstructor
public class RestFundWebServiceImpl implements FundWebService {
    private final FundServiceClient fundServiceClient;
    private final FundMapper fundMapper;

    @Override
    public List<Fund> getFunds(String policyNumber) {
        if (!StringUtils.hasText(policyNumber)) {
            throw new IllegalArgumentException("policyNumber cannot be null or blank.");
        }
        return fundMapper.map(fundServiceClient.getFundsByPolicyNumber(policyNumber));
    }
}
