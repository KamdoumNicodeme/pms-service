package com.lombardinternational.casedefinition.v2.domain.service.checklist.onboarding.field;

import com.lombardinternational.casedefinition.v2.domain.model.Group;
import com.lombardinternational.casedefinition.v2.domain.model.ScreenDescription;
import com.lombardinternational.casedefinition.v2.domain.model.WebForm;
import com.lombardinternational.casedefinition.v2.domain.service.checklist.FieldBuilderService;
import org.springframework.stereotype.Service;

import java.util.Map;

@Service
public class OnboardingDueDiligenceFieldsBuilderService extends OnboardingChecklistFieldsBuilderSupport implements FieldBuilderService {
    @Override
    public void buildField(WebForm webForm, ScreenDescription screenDescription, Group group) {
        var previousValues = previousValues(screenDescription);
        resetFields(group);
        buildIndustry(group, previousValues, webForm);
        buildPosition(group, previousValues, webForm);
        buildBackgroundDetails(group, previousValues, webForm);
        buildRiskAssessment(group, previousValues, webForm);
        buildPep(group, previousValues, webForm);
        buildOriginatorPep(group, previousValues, webForm);
        buildIsPepPayer(group, previousValues, webForm);
        buildTccSigned(group, previousValues, webForm);
        buildTccSignedRefused(group, previousValues, webForm);
        buildIntroducingPartnerSigned(group, previousValues, webForm);
        buildInfoProvidedVerified(group, previousValues, webForm);
        buildNegativeFinding(group, previousValues, webForm);
        buildNegativeFindingThirdParty(group, previousValues, webForm);
        buildAtLeastOneSowOfKind(group, previousValues, webForm);
        buildOriginatorWorldCheck(group, previousValues, webForm);
        buildIsOnSanctionList(group, previousValues, webForm);
        buildInsider(group, previousValues, webForm);
        buildIsPhEboGoldenVisa(group, previousValues, webForm);
        buildAnnualIncome(group, previousValues, webForm);
        build20PercentIncome(group, previousValues, webForm);
        buildSourceOfWealth(group, previousValues, webForm);
        buildMinimumWealth(group, previousValues, webForm);
        buildWealthAllocationOk(group, previousValues, webForm);
        buildWealthOriginatingCountry1Risk(group, previousValues, webForm);
        buildWealthOriginatingCountry2Risk(group, previousValues, webForm);
        buildWealthAllocation(group, previousValues, webForm);
        buildTotalWealth(group, previousValues, webForm);
        buildKycSupportingDocuments(group, previousValues, webForm);
        sortFields(group);
    }

    private void buildIndustry(Group group, Map<String, String> previousValues, WebForm webForm) {
        buildField(group, new FieldRule("INDUSTRY", FieldKind.SELECT, 100, "Industry", false, true,
                "#forcedValue", null, false, "From CLASS", true), previousValues, webForm);
    }

    private void buildPosition(Group group, Map<String, String> previousValues, WebForm webForm) {
        buildField(group, new FieldRule("POSITION", FieldKind.SELECT, 101, "Position", false, false,
                "#forcedValue", "#forcedDisplayIf", false, "From CLASS", true), previousValues, webForm);
    }

    private void buildBackgroundDetails(Group group, Map<String, String> previousValues, WebForm webForm) {
        buildField(group, new FieldRule("BACKGROUND_DETAILS", FieldKind.TEXT_AREA, 200, "Profession background details", true, true,
                null, null, false, null, false), previousValues, webForm);
    }

    private void buildRiskAssessment(Group group, Map<String, String> previousValues, WebForm webForm) {
        buildField(group, new FieldRule("RISK_ASSESSMENT", FieldKind.TEXT_AREA, 201, "Profession risk assessment", true, true,
                null, null, false, null, false), previousValues, webForm);
    }

    private void buildPep(Group group, Map<String, String> previousValues, WebForm webForm) {
        buildField(group, new FieldRule("PEP", FieldKind.SELECT, 202, "Is there a PEP on the policy", false, true,
                "#forcedValue", null, false, null, false), previousValues, webForm);
    }

    private void buildOriginatorPep(Group group, Map<String, String> previousValues, WebForm webForm) {
        buildField(group, new FieldRule("ORIGINATOR_PEP", FieldKind.SELECT, 203, "Is the Originator, linked to the source of funds to be invested, a PEP?", true, true,
                "YES\u00acYes;NO\u00acNo", "#forcedDisplayIf", false, null, false), previousValues, webForm);
    }

    private void buildIsPepPayer(Group group, Map<String, String> previousValues, WebForm webForm) {
        buildField(group, new FieldRule("IS_PEP_PAYER", FieldKind.SELECT, 204, "Is one of the payer a PEP?", true, true,
                "YES\u00acYes;NO\u00acNo", "#forcedDisplayIf", false, null, false), previousValues, webForm);
    }

    private void buildTccSigned(Group group, Map<String, String> previousValues, WebForm webForm) {
        buildField(group, new FieldRule("TCC_SIGNED", FieldKind.SELECT, 308, "TCC duly signed received?", true, true,
                "YES\u00acYes;NO\u00acNo", null, false, null, false), previousValues, webForm);
    }

    private void buildTccSignedRefused(Group group, Map<String, String> previousValues, WebForm webForm) {
        buildField(group, new FieldRule("TCC_SIGNED_REFUSED", FieldKind.SELECT, 309, "Did the PH/EBO refuse to sign the TCC and this after several reminders to sign the form?", true, true,
                "YES\u00acYes;NO\u00acNo", "#TCC_SIGNED# == \"NO\"", false, null, false), previousValues, webForm);
    }

    private void buildIntroducingPartnerSigned(Group group, Map<String, String> previousValues, WebForm webForm) {
        buildField(group, new FieldRule("INTRODUCING_PARTNER_SIGNED", FieldKind.SELECT, 310, "Introducing partner signs KYC questionnaire", true, true,
                "YES\u00acYes;NO\u00acNo", null, false, null, false), previousValues, webForm);
    }

    private void buildInfoProvidedVerified(Group group, Map<String, String> previousValues, WebForm webForm) {
        buildField(group, new FieldRule("INFO_PROVIDED_VERIFIED", FieldKind.SELECT, 311, "Info provided on KYC questionnaire could be verified", true, true,
                "YES\u00acYes;NO\u00acNo", null, false, null, false), previousValues, webForm);
    }

    private void buildNegativeFinding(Group group, Map<String, String> previousValues, WebForm webForm) {
        buildField(group, new FieldRule("NEGATIVE_FINDING", FieldKind.SELECT, 312, "Negative press finding / World check match (on all roles on policy)", false, true,
                "#forcedValue", null, false, null, false), previousValues, webForm);
    }

    private void buildNegativeFindingThirdParty(Group group, Map<String, String> previousValues, WebForm webForm) {
        buildField(group, new FieldRule("NEGATIVE_FINDING_THIRD_PARTY", FieldKind.TEXT, 313, "Negative press finding / Worldcheck match on following Third party(ies)", false, false,
                "#forcedValue", "#forcedDisplayIf", false, null, false), previousValues, webForm);
    }

    private void buildAtLeastOneSowOfKind(Group group, Map<String, String> previousValues, WebForm webForm) {
        buildField(group, new FieldRule("AT_LEAST_ONE_SOW_OF_KIND", FieldKind.SELECT, 314, "Invisible field : used as display if condition for ORIGINATOR_WORLD_CHECK", false, true,
                "#forcedValue", "false", false, null, false), previousValues, webForm);
    }

    private void buildOriginatorWorldCheck(Group group, Map<String, String> previousValues, WebForm webForm) {
        buildField(group, new FieldRule("ORIGINATOR_WORLD_CHECK", FieldKind.SELECT, 314, "World check match or negative press found on originator", true, true,
                "YES\u00acYes;NO\u00acNo", "#forcedDisplayIf", false, null, false), previousValues, webForm);
    }

    private void buildIsOnSanctionList(Group group, Map<String, String> previousValues, WebForm webForm) {
        buildField(group, new FieldRule("IS_ON_SANCTION_LIST", FieldKind.SELECT, 315, "Is there any person designated on a sanctions list on the policy?", false, true,
                "#forcedValue", null, false, null, false), previousValues, webForm);
    }

    private void buildInsider(Group group, Map<String, String> previousValues, WebForm webForm) {
        buildField(group, new FieldRule("INSIDER", FieldKind.SELECT, 316, "Is the person an insider to any assets invested in the policy?", false, false,
                "#forcedValue", null, false, null, false), previousValues, webForm);
    }

    private void buildIsPhEboGoldenVisa(Group group, Map<String, String> previousValues, WebForm webForm) {
        buildField(group, new FieldRule("IS_PH_EBO_GOLDEN_VISA", FieldKind.SELECT, 317, "Is the PH / EBO a country national who applied for residence rights or citizenship in exchange of capital transfers purchase of property or government bonds or investment in corporate entities (who has a Golden Visa) or a Golden Passport", false, true,
                "#forcedValue", null, false, null, false), previousValues, webForm);
    }

    private void buildAnnualIncome(Group group, Map<String, String> previousValues, WebForm webForm) {
        buildField(group, new FieldRule("ANNUAL_INCOME", FieldKind.TEXT, 320, "Annual Income", false, false,
                "#forcedValue", null, false, "From CLASS", true), previousValues, webForm);
    }

    private void build20PercentIncome(Group group, Map<String, String> previousValues, WebForm webForm) {
        buildField(group, new FieldRule("20_PERCENT_INCOME", FieldKind.SELECT, 321, "A portion of wealth is from inheritance / Gift / Donation / Divorce", false, false,
                "#forcedValue", null, false, "From Connect", true), previousValues, webForm);
    }

    private void buildSourceOfWealth(Group group, Map<String, String> previousValues, WebForm webForm) {
        buildField(group, new FieldRule("SOURCE_OF_WEALTH", FieldKind.TEXT, 400, "Source of wealth description", true, false,
                null, null, false, null, true), previousValues, webForm);
    }

    private void buildMinimumWealth(Group group, Map<String, String> previousValues, WebForm webForm) {
        buildField(group, new FieldRule("MINIMUM_WEALTH", FieldKind.SELECT, 401, "Minimum wealth > 250000\u20ac in transferrable assets (not including property)", true, true,
                "YES\u00acYes;NO\u00acNo", null, false, null, true), previousValues, webForm);
    }

    private void buildWealthAllocationOk(Group group, Map<String, String> previousValues, WebForm webForm) {
        buildField(group, new FieldRule("WEALTH_ALLOCATION_OK", FieldKind.SELECT, 402, "Wealth allocation in line with source", true, true,
                "YES\u00acYes;NO\u00acNo", null, false, null, true), previousValues, webForm);
    }

    private void buildWealthOriginatingCountry1Risk(Group group, Map<String, String> previousValues, WebForm webForm) {
        buildField(group, new FieldRule("WEALTH_ORIGINATING_COUNTRY_1_RISK", FieldKind.TEXT, 403, "Country 1 origin of premium", false, true,
                "#forcedValue", null, false, "From CLASS", true), previousValues, webForm);
    }

    private void buildWealthOriginatingCountry2Risk(Group group, Map<String, String> previousValues, WebForm webForm) {
        buildField(group, new FieldRule("WEALTH_ORIGINATING_COUNTRY_2_RISK", FieldKind.TEXT, 404, "Country 2 origin of premium", false, false,
                "#forcedValue", null, false, "From CLASS", true), previousValues, webForm);
    }

    private void buildWealthAllocation(Group group, Map<String, String> previousValues, WebForm webForm) {
        buildField(group, new FieldRule("WEALTH_ALLOCATION", FieldKind.TEXT, 405, "Wealth allocation", true, true,
                null, null, false, null, true), previousValues, webForm);
    }

    private void buildTotalWealth(Group group, Map<String, String> previousValues, WebForm webForm) {
        buildField(group, new FieldRule("TOTAL_WEALTH", FieldKind.TEXT, 406, "Total wealth", false, false,
                "#forcedValue", null, false, "From Connect", true), previousValues, webForm);
    }

    private void buildKycSupportingDocuments(Group group, Map<String, String> previousValues, WebForm webForm) {
        buildField(group, new FieldRule("KYC_SUPPORTING_DOCUMENTS", FieldKind.SELECT, 500, "Are all KYC supporting documents (and if applicable the ones on the tax conformity of the funds) consistent and not altered (i.e. anomalies/ inconsistencies in the POR, documentation to corroborate the SOF/SOW such as no VAT number, no invoice number, no address, incorrect amount etc.)", true, true,
                "YES\u00acYes;NO\u00acNo", null, false, null, false), previousValues, webForm);
    }

}
