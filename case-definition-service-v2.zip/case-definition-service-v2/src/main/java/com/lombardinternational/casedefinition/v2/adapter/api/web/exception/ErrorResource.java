package com.lombardinternational.casedefinition.v2.adapter.api.web.exception;

import lombok.Builder;

@Builder
public record ErrorResource(String code, String message) {
}
