package com.lombardinternational.casedefinition.v2.adapter.api.web.dto;

public record TaskScreenRequest(WebForm webForm, ScreenDescription screenCheckList, ScreenDescription screenToFill) {
}
