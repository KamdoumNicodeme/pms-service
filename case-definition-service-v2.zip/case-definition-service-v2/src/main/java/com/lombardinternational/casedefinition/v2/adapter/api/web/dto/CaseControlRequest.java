package com.lombardinternational.casedefinition.v2.adapter.api.web.dto;

public record CaseControlRequest(String caseType, String businessTransactionId,
                                 WebForm caseInitializationData, ScreenDescription checkListOverviewData) {
}
