package com.lombardinternational.casedefinition.v2.domain.service;

import com.lombardinternational.casedefinition.v2.domain.model.*;
import com.lombardinternational.casedefinition.v2.domain.service.taskscreen.onboarding.definition.OnboardingTaskScreenDefinitionProvider;
import org.springframework.stereotype.Component;

import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.Map;

@Component
public class DefinitionAssembler {
    private final FieldFactory fieldFactory;
    private final OnboardingTaskScreenDefinitionProvider taskScreenDefinitionProvider;

    public DefinitionAssembler(FieldFactory fieldFactory, OnboardingTaskScreenDefinitionProvider taskScreenDefinitionProvider) {
        this.fieldFactory = fieldFactory;
        this.taskScreenDefinitionProvider = taskScreenDefinitionProvider;
    }

    public ScreenDescription buildScreen(String screenId, ScreenDescription previousScreen, WebForm webForm) {
        ScreenDescription screen = previousScreen == null ? ScreenDescription.builder().screenId(screenId).build() : previousScreen;
        screen.setScreenId(screenId);
        screen.getTabs().clear();

        Map<String, String> previousValues = previousScreen == null ? Map.of() : previousScreen.selectedValuesByFieldId();
        Map<String, Tab> tabsById = new LinkedHashMap<>();
        Map<String, Group> groupsById = new LinkedHashMap<>();

        taskScreenDefinitionProvider.tabs(screenId).stream()
                .sorted(Comparator.comparingInt(OnboardingTaskScreenDefinitionProvider.TabRule::order))
                .forEach(spec -> {
                    Tab tab = Tab.builder().tabId(spec.tabId()).label(spec.label()).type(spec.type()).order(spec.order())
                            .displayIf(blankToNull(spec.displayIf())).isActive(true).build();
                    tabsById.put(spec.tabId(), tab);
                    screen.getTabs().add(tab);
                });

        taskScreenDefinitionProvider.groups(screenId).stream()
                .sorted(Comparator.comparingInt(OnboardingTaskScreenDefinitionProvider.GroupRule::order))
                .forEach(spec -> {
                    Group group = Group.builder().groupId(spec.groupId()).title(spec.title()).order(spec.order())
                            .columnsCount(spec.columnsCount()).displayIf(blankToNull(spec.displayIf())).isActive(true).build();
                    groupsById.put(spec.groupId(), group);
                    tabsById.computeIfAbsent(spec.tabId(), this::placeholderTab).getGroups().add(group);
                });

        taskScreenDefinitionProvider.fields(screenId).stream()
                .sorted(Comparator.comparingInt(OnboardingTaskScreenDefinitionProvider.FieldRule::order)
                        .thenComparing(OnboardingTaskScreenDefinitionProvider.FieldRule::fieldId))
                .forEach(spec -> groupsById.computeIfAbsent(spec.groupId(), this::placeholderGroup)
                        .getFields().add(fieldFactory.create(spec.toFieldSpec(), previousValues, webForm)));

        screen.getTabs().forEach(tab -> tab.getGroups().sort(Comparator.comparingInt(Group::getOrder).thenComparing(Group::getGroupId)));
        screen.getTabs().forEach(tab -> tab.getGroups().forEach(group -> group.getFields().sort(Comparator.comparingInt(Field::getOrder).thenComparing(Field::getFieldId))));
        return screen;
    }

    private Tab placeholderTab(String tabId) {
        return Tab.builder().tabId(tabId).label(tabId).type("FormTab").order(9999).isActive(true).build();
    }

    private Group placeholderGroup(String groupId) {
        return Group.builder().groupId(groupId).title(groupId).order(9999).columnsCount(1).isActive(true).build();
    }

    private String blankToNull(String value) {
        return value == null || value.isBlank() ? null : value;
    }
}
