package com.lombardinternational.casedefinition.v2.adapter.api.web.dto;

public record WebformSignatoryRequest(String policyNumber, String caseType, WebForm caseInitializationData) {
}
