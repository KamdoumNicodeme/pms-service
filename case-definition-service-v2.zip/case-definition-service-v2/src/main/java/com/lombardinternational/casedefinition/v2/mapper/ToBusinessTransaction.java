package com.lombardinternational.casedefinition.v2.mapper;

import org.mapstruct.Mapping;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

@Retention(RetentionPolicy.CLASS)
@Mapping(source = "transactionNumber", target = "identifier")
@Mapping(source = "transactionType", target = "type")
@Mapping(source = "businessTransactionDetails", target = "transactionAmounts.grossAmount")
@Mapping(source = "closingDate", target = "closeDate")
@Mapping(source = "endorsementCategory", target = "category")
@Mapping(source = "endorsementSubCategory", target = "subCategory")
public @interface ToBusinessTransaction {
}
