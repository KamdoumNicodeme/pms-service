package com.lombardinternational.casedefinition.v2.adapter.api.web.mapper;

import com.lombardinternational.casedefinition.v2.domain.model.TextInputField;
import org.mapstruct.Mapper;

import java.util.List;

@Mapper(componentModel = "spring")
public interface TextInputFieldMapper {
    List<TextInputField> textInputFieldFromDTO(List<com.lombardinternational.casedefinition.v2.adapter.api.web.dto.TextInputField> dtos);
}
