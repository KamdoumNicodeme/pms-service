package com.lombardinternational.casedefinition.v2.adapter.api.web.dto;

public record ChecklistRequest(WebForm webForm, ScreenDescription screenDescription, String policyNumber, String transactionNumber) {
}
