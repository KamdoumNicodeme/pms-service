package com.lombardinternational.casedefinition.v2.domain.spi;

import com.lombardinternational.casedefinition.v2.domain.model.BusinessTransaction;
import com.lombardinternational.casedefinition.v2.domain.spi.exception.BusinessTransactionNotFoundException;

import java.util.List;

public interface BusinessTransactionWebService {
    BusinessTransaction getBusinessTransaction(String businessTransactionNumber) throws BusinessTransactionNotFoundException;

    List<BusinessTransaction> getBusinessTransactions(String policyNumber) throws BusinessTransactionNotFoundException;
}
