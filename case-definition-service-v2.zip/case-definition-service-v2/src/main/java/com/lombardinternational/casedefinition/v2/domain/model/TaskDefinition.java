package com.lombardinternational.casedefinition.v2.domain.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TaskDefinition {
    private static final AtomicInteger currentOrder = new AtomicInteger(1);

    private int taskId;
    private boolean suggested;
    private boolean mandatory;
    private String mainTaskName;
    private String mainTaskDynamicScreenId;
    private int mainTaskExpectedDurationSeconds;
    private int signoffTaskExpectedDurationSeconds;
    private int taskOrder;
    private int rulePriority;
    @Builder.Default
    private boolean releasableFromSubTask = false;
    @Builder.Default
    private boolean completeRequired = true;
    @Builder.Default
    private List<String> decisionReasons = new ArrayList<>();

    public static void resetTaskOrder() {
        currentOrder.set(1);
    }

    public void incrementOrder() {
        this.taskOrder = currentOrder.getAndIncrement();
    }
}
