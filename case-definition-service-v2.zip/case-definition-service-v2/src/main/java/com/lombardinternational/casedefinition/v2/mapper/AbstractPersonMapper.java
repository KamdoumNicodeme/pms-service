package com.lombardinternational.casedefinition.v2.mapper;

import com.lombardinternational.casedefinition.v2.domain.model.AbstractPerson;
import com.lombardinternational.clients.classapp.model.thirdparty.MoralPerson;
import com.lombardinternational.clients.classapp.model.thirdparty.MoralPersonLight;
import com.lombardinternational.clients.classapp.model.thirdparty.PhysicalPerson;
import com.lombardinternational.clients.classapp.model.thirdparty.PhysicalPersonLight;
import com.lombardinternational.clients.classapp.model.thirdparty.ThirdParty;
import com.lombardinternational.clients.classapp.model.thirdparty.ThirdPartyLight;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;

import java.util.Collection;
import java.util.List;

@Mapper(componentModel = "spring")
public interface AbstractPersonMapper {
    List<AbstractPerson> mapToList(Collection<ThirdPartyLight> thirdParties);

    default AbstractPerson map(ThirdPartyLight thirdParty) {
        if (thirdParty instanceof MoralPersonLight moralPerson) {
            return mapTo(moralPerson);
        } else if (thirdParty instanceof PhysicalPersonLight physicalPerson) {
            return mapTo(physicalPerson);
        } else {
            throw new IllegalArgumentException("Unsupported third party type: " + thirdParty.getClass());
        }
    }

    @Named("moralPerson")
    @ToAbstractPerson
    @Mapping(source = "companyLegalForm.externalId", target = "companyLegalForm")
    com.lombardinternational.casedefinition.v2.domain.model.MoralPerson mapTo(MoralPersonLight thirdParty);

    @Named("physicalPerson")
    @ToAbstractPerson
    com.lombardinternational.casedefinition.v2.domain.model.PhysicalPerson mapTo(PhysicalPersonLight thirdParty);

    default AbstractPerson map(ThirdParty thirdParty) {
        if (thirdParty instanceof MoralPerson moralPerson) {
            return mapTo(moralPerson);
        } else if (thirdParty instanceof PhysicalPerson physicalPerson) {
            return mapTo(physicalPerson);
        } else {
            throw new IllegalArgumentException("Unsupported third party type: " + thirdParty.getClass());
        }
    }

    @Named("moralPerson")
    @ToAbstractPerson
    @Mapping(source = "companyLegalForm.externalId", target = "companyLegalForm")
    @Mapping(source = "thirdParty", target = "subType", qualifiedByName = "mapSubType")
    com.lombardinternational.casedefinition.v2.domain.model.MoralPerson mapTo(MoralPerson thirdParty);

    @Named("physicalPerson")
    @ToAbstractPerson
    @Mapping(source = "lastName", target = "lastname")
    @Mapping(target = "subType", constant = "Individual")
    com.lombardinternational.casedefinition.v2.domain.model.PhysicalPerson mapTo(PhysicalPerson thirdParty);

    @Named("mapSubType")
    default String mapSubType(MoralPerson thirdParty) {
        if (thirdParty.getCompanyLegalForm() == null) {
            return "Company";
        }
        return switch (thirdParty.getCompanyLegalForm().getExternalId()) {
            case "FIDUCIARY" -> "Fiduciary";
            case "TRUST" -> "Trust";
            case "TRAD_COMP" -> "Trading company";
            default -> "Company";
        };
    }
}
