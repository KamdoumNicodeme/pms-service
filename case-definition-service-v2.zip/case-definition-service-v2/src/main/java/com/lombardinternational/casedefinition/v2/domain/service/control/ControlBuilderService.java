package com.lombardinternational.casedefinition.v2.domain.service.control;

import com.lombardinternational.casedefinition.v2.domain.model.CaseControlDefinition;
import com.lombardinternational.casedefinition.v2.domain.model.ScreenDescription;
import com.lombardinternational.casedefinition.v2.domain.model.WebForm;

import java.util.List;

public interface ControlBuilderService {
    void buildControl(WebForm webForm, ScreenDescription screenDescription, List<CaseControlDefinition> controls);
}
