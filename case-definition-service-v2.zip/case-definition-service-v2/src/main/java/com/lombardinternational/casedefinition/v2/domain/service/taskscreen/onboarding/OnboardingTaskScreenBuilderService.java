package com.lombardinternational.casedefinition.v2.domain.service.taskscreen.onboarding;

import com.lombardinternational.casedefinition.v2.domain.model.ScreenDescription;
import com.lombardinternational.casedefinition.v2.domain.model.WebForm;
import com.lombardinternational.casedefinition.v2.domain.service.DefinitionAssembler;
import com.lombardinternational.casedefinition.v2.domain.service.taskscreen.TaskScreenBuilderService;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@AllArgsConstructor
public class OnboardingTaskScreenBuilderService implements TaskScreenBuilderService {
    private final DefinitionAssembler definitionAssembler;

    @Override
    public ScreenDescription buildTaskScreen(WebForm webForm, ScreenDescription screenCheckList, ScreenDescription screenToFill) {
        String screenId = screenToFill == null ? null : screenToFill.getScreenId();
        if (screenId == null || screenId.isBlank()) {
            return ScreenDescription.builder().screenId(screenId).build();
        }
        return definitionAssembler.buildScreen(screenId, screenToFill, webForm);
    }
}
