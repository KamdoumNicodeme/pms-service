package com.lombardinternational.casedefinition.v2.domain.spi;

import com.lombardinternational.clients.classapp.model.PersistedBlock;
import com.lombardinternational.clients.classapp.model.Policy;
import com.lombardinternational.clients.classapp.model.PolicyValues;
import com.lombardinternational.clients.classapp.model.roles.AbstractPolicyRole;
import com.lombardinternational.clients.classapp.model.thirdparty.ThirdPartyLight;

import java.util.Collection;
import java.util.List;

public interface PolicyWebService {
    Policy getPolicy(String policyNumber);

    PolicyValues getPolicyValues(String policyNumber);

    Collection<PersistedBlock> getBlocks(String policyNumber);

    List<AbstractPolicyRole> getPolicyRole(String policyNumber);

    Collection<ThirdPartyLight> getPolicyLinks(String policyNumber);
}
