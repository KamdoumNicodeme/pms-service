package com.lombardinternational.casedefinition.v2.domain.model;

import lombok.Data;

import java.util.ArrayList;
import java.util.List;

@Data
public class BusinessTransactionProductComponent {
    private List<Payment> payments = new ArrayList<>();
    private Amount expectedAmountInPolicyCurrency;
}
