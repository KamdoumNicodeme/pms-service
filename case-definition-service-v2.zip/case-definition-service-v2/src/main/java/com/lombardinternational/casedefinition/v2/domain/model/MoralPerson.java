package com.lombardinternational.casedefinition.v2.domain.model;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
public class MoralPerson extends AbstractPerson {
    private String companyName;
    private String companyLegalForm;
}
