package com.lombardinternational.casedefinition.v2.adapter.api.web.dto;

public record TaskListRequest(WebForm webForm, ScreenDescription screenDescription, String policyNumber) {
}
