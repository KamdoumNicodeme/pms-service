package com.lombardinternational.casedefinition.v2.adapter.api.web.controller;

import com.lombardinternational.casedefinition.v2.adapter.api.web.dto.WebformSignatoryRequest;
import com.lombardinternational.casedefinition.v2.adapter.api.web.mapper.SignatoryResultMapper;
import com.lombardinternational.casedefinition.v2.adapter.api.web.mapper.WebFormMapper;
import com.lombardinternational.casedefinition.v2.domain.api.WebFormBusinessService;
import com.lombardinternational.casedefinition.v2.domain.model.SignatoryResult;
import com.lombardinternational.casedefinition.v2.domain.model.WebForm;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Tag(name = "WebForms", description = "WebForms management")
@RestController
@RequestMapping("/api/webforms")
@RequiredArgsConstructor
public class WebFormController {
    private final WebFormBusinessService webFormBusinessService;
    private final WebFormMapper webFormMapper;
    private final SignatoryResultMapper signatoryResultMapper;

    @PostMapping("signatories")
    @Operation(summary = "Generate connect signature list based on a WebformSignatoryRequest")
    public ResponseEntity<com.lombardinternational.casedefinition.v2.adapter.api.web.dto.SignatoryResult> getSignatories(
            @Valid @RequestBody WebformSignatoryRequest request) {
        WebForm webForm = webFormMapper.webFormFromDTO(request.caseInitializationData());
        SignatoryResult result = webFormBusinessService.computeSignatories(request.caseType(), request.policyNumber(), webForm);
        return ResponseEntity.ok(signatoryResultMapper.dtoFromSignatoryResult(result));
    }
}
