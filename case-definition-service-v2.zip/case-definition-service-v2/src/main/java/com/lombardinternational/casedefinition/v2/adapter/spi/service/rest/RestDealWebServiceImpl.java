package com.lombardinternational.casedefinition.v2.adapter.spi.service.rest;

import com.lombardinternational.casedefinition.v2.adapter.spi.service.rest.mapper.CaseDealMapper;
import com.lombardinternational.casedefinition.v2.domain.model.CaseDeal;
import com.lombardinternational.casedefinition.v2.domain.spi.DealWebService;
import com.lombardinternational.casemanagement.clients.casebusinesscase.client.CaseClient;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class RestDealWebServiceImpl implements DealWebService {
    private final CaseClient caseClient;
    private final CaseDealMapper caseDealMapper;

    @Override
    public List<CaseDeal> getCaseDeals(String caseDealId) {
        return caseDealMapper.mapToCaseDealList(caseClient.getCaseDeals(caseDealId));
    }
}
