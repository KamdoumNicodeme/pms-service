package com.lombardinternational.casedefinition.v2.domain.service.control.onboarding;

import com.lombardinternational.casedefinition.v2.domain.model.CaseControlDefinition;
import com.lombardinternational.casedefinition.v2.domain.model.ScreenDescription;
import com.lombardinternational.casedefinition.v2.domain.model.WebForm;
import com.lombardinternational.casedefinition.v2.domain.service.control.ControlDefinitionBuilderService;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
@AllArgsConstructor
public class OnboardingControlDefinitionBuilderService implements ControlDefinitionBuilderService {
    private final OnboardingControlSpecBuilderService controlSpecBuilderService;

    @Override
    public List<CaseControlDefinition> buildControlDefinition(WebForm webForm, ScreenDescription screenDescription) {
        CaseControlDefinition.resetControlOrder();
        final var controls = new ArrayList<CaseControlDefinition>();
        controlSpecBuilderService.buildControl(webForm, screenDescription, controls);
        return controls;
    }
}
