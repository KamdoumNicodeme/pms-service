package com.lombardinternational.casedefinition.v2.domain.service.checklist.onboarding.field;

import com.lombardinternational.casedefinition.v2.domain.model.Group;
import com.lombardinternational.casedefinition.v2.domain.model.ScreenDescription;
import com.lombardinternational.casedefinition.v2.domain.model.WebForm;
import com.lombardinternational.casedefinition.v2.domain.service.checklist.FieldBuilderService;
import org.springframework.stereotype.Service;

import java.util.Map;

@Service
public class OnboardingCaseRiskFieldsBuilderService extends OnboardingChecklistFieldsBuilderSupport implements FieldBuilderService {
    @Override
    public void buildField(WebForm webForm, ScreenDescription screenDescription, Group group) {
        var previousValues = previousValues(screenDescription);
        resetFields(group);
        buildRiskValue(group, previousValues, webForm);
        buildBlockedValue(group, previousValues, webForm);
        buildPcsReview(group, previousValues, webForm);
        buildRiskReason(group, previousValues, webForm);
        sortFields(group);
    }

    private void buildRiskValue(Group group, Map<String, String> previousValues, WebForm webForm) {
        buildField(group, new FieldRule("RISK_VALUE", FieldKind.TEXT, 1, "Overall case risk", false, false,
                "#forcedValue", "false", false, "Calculated based on checklist values", false), previousValues, webForm);
    }

    private void buildBlockedValue(Group group, Map<String, String> previousValues, WebForm webForm) {
        buildField(group, new FieldRule("BLOCKED_VALUE", FieldKind.TEXT_AREA, 2, "Actions required in CLASS to complete Docs & Controls and trigger reviews", false, false,
                "#forcedValue", "#forcedDisplayIf", false, "Calculated based on checklist values", false), previousValues, webForm);
    }

    private void buildPcsReview(Group group, Map<String, String> previousValues, WebForm webForm) {
        buildField(group, new FieldRule("PCS_REVIEW", FieldKind.SELECT, 3, "PCS Review", false, true,
                "#forcedValue", "#forcedDisplayIf", false, "Calculated based on Overall case risk", false), previousValues, webForm);
    }

    private void buildRiskReason(Group group, Map<String, String> previousValues, WebForm webForm) {
        buildField(group, new FieldRule("RISK_REASON", FieldKind.TEXT_AREA, 4, "Compliance escalation rules triggered", false, false,
                "#forcedValue", "#forcedDisplayIf", false, "Calculated based on Overall case risk", false), previousValues, webForm);
    }

}
