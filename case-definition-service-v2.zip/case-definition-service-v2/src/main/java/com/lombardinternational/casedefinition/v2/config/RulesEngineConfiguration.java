package com.lombardinternational.casedefinition.v2.config;

import org.springframework.context.annotation.Configuration;

@Configuration
public class RulesEngineConfiguration {
}
