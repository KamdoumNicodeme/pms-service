package com.lombardinternational.casedefinition.v2.adapter.api.web.mapper;

import com.lombardinternational.casedefinition.v2.domain.model.DocumentRequiredSignatory;
import com.lombardinternational.casedefinition.v2.domain.model.RequiredSignatory;
import org.mapstruct.Mapper;

import java.util.List;

@Mapper(componentModel = "spring")
public interface DocumentRequiredSignatoryMapper {
    List<DocumentRequiredSignatory> documentRequiredSignatoryFromDTO(
            List<com.lombardinternational.casedefinition.v2.adapter.api.web.dto.DocumentRequiredSignatory> documentRequiredSignatoriesDTO);

    List<com.lombardinternational.casedefinition.v2.adapter.api.web.dto.DocumentRequiredSignatory> dtoFromDocumentRequiredSignatory(
            List<DocumentRequiredSignatory> documentRequiredSignatories);

    RequiredSignatory requiredSignatoryToSignatory(
            com.lombardinternational.casedefinition.v2.adapter.api.web.dto.RequiredSignatory requiredSignatory);

    com.lombardinternational.casedefinition.v2.adapter.api.web.dto.RequiredSignatory dtoFromRequiredSignatory(RequiredSignatory requiredSignatory);

    List<com.lombardinternational.casedefinition.v2.adapter.api.web.dto.RequiredSignatory> dtoFromRequiredSignatory(
            List<RequiredSignatory> requiredSignatories);
}
