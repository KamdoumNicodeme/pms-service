package com.lombardinternational.casedefinition.v2.domain.service.checklist.onboarding.group;

import com.lombardinternational.casedefinition.v2.domain.model.Group;
import com.lombardinternational.casedefinition.v2.domain.model.ScreenDescription;
import com.lombardinternational.casedefinition.v2.domain.model.Tab;
import com.lombardinternational.casedefinition.v2.domain.model.WebForm;
import com.lombardinternational.casedefinition.v2.domain.service.checklist.GroupBuilderService;
import com.lombardinternational.casedefinition.v2.domain.service.checklist.onboarding.field.OnboardingSignatureFieldsBuilderService;
import com.lombardinternational.casedefinition.v2.domain.utils.ChecklistUtils;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import static com.lombardinternational.casedefinition.v2.domain.transaction.onboarding.rules.OnboardingChecklistIds.SIGNATURE_GROUP;

@Service
@AllArgsConstructor
public class OnboardingSignatureGroupBuilderService implements GroupBuilderService {
    private final OnboardingSignatureFieldsBuilderService fieldsBuilderService;

    @Override
    public void buildGroup(WebForm webForm, ScreenDescription screenDescription, Tab parentTab) {
        var group = ChecklistUtils.getGroupInTab(parentTab, SIGNATURE_GROUP);
        if (group == null) {
            group = Group.builder().groupId(SIGNATURE_GROUP).build();
            parentTab.getGroups().add(group);
        }

        group.setIsActive(true);
        group.setOrder(4);
        group.setTitle("Signature");
        group.setColumnsCount(2);
        group.setDisplayIf(null);
        fieldsBuilderService.buildField(webForm, screenDescription, group);
    }
}
