package com.lombardinternational.casedefinition.v2.adapter.spi.service.rest;

import com.lombardinternational.casedefinition.v2.adapter.spi.service.rest.mapper.FxRateMapper;
import com.lombardinternational.casedefinition.v2.domain.model.CurrencyExchangeRate;
import com.lombardinternational.casedefinition.v2.domain.spi.FxRateWebService;
import com.lombardinternational.clients.fxrates.client.FxRatesServiceClient;
import com.lombardinternational.clients.fxrates.model.FxRate;
import com.lombardinternational.clients.fxrates.model.FxRateFilter;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.Comparator;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Slf4j
@Service
@RequiredArgsConstructor
public class RestFxRateWebServiceImpl implements FxRateWebService {
    public static final String FX_RATES_CACHE = "FX_RATES_REST_CACHE";

    private final FxRatesServiceClient fxRatesServiceClient;
    private final FxRateMapper fxRateMapper;

    @Override
    @Cacheable(value = FX_RATES_CACHE, key = "{ #sourceCcy, #targetCcy }")
    public List<CurrencyExchangeRate> getFxRate(String sourceCcy, String targetCcy) {
        log.info("Start calling webservice FxRate for {}/{}", sourceCcy, targetCcy);

        LocalDate toDate = LocalDate.now();
        LocalDate fromDate = toDate.minusDays(5);

        FxRateFilter fxRateFilter = new FxRateFilter();
        fxRateFilter.setFromCcy(sourceCcy);
        fxRateFilter.setToCcy(targetCcy);
        fxRateFilter.setFxRateFromDate(fromDate);
        fxRateFilter.setFxRateToDate(toDate);

        List<FxRate> fxRates = fxRatesServiceClient.getValidFxRates(fxRateFilter);

        if (fxRates == null || fxRates.isEmpty()) {
            log.warn("No FX rates found for {} to {} between {} and {}", sourceCcy, targetCcy, fromDate, toDate);
            return new ArrayList<>();
        }

        FxRate latestFxRate = fxRates.stream()
                .max(Comparator.comparing(FxRate::getFxRateDate)
                        .thenComparing(FxRate::getFxRateTime, Comparator.nullsLast(Comparator.naturalOrder())))
                .orElse(null);

        return latestFxRate == null ? new ArrayList<>() : fxRateMapper.toCurrencyExchangeRates(Collections.singletonList(latestFxRate));
    }

    @CacheEvict(allEntries = true, value = FX_RATES_CACHE)
    @Scheduled(fixedDelayString = "${case-definition.fx-rates.cache-refresh-delay-ms:86400000}")
    public void refreshCacheFxRate() {
        log.info("Fx rate cache has been cleared");
    }

}
