package com.lombardinternational.casedefinition.v2.adapter.api.web.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class SignatoryResult {
    private List<DocumentRequiredSignatory> documentRequiredSignatories = new ArrayList<>();
    private Map<String, String> responseMessages = new LinkedHashMap<>();
}
