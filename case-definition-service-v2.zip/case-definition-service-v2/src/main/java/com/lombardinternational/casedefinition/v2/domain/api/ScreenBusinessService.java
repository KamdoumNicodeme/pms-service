package com.lombardinternational.casedefinition.v2.domain.api;

import com.lombardinternational.casedefinition.v2.domain.model.ScreenDescription;
import com.lombardinternational.casedefinition.v2.domain.model.WebForm;

public interface ScreenBusinessService {
    ScreenDescription computeScreenDescription(String policyNumber, String caseType, String businessTransactionNumber,
            WebForm webForm, ScreenDescription screenDescriptionToBuild);

    ScreenDescription computeTaskScreen(String caseType, WebForm webForm, ScreenDescription screenCheckList,
            ScreenDescription screenToFill);
}
