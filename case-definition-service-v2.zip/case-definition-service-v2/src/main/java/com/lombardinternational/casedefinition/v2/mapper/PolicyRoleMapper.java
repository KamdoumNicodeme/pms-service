package com.lombardinternational.casedefinition.v2.mapper;

import com.lombardinternational.casedefinition.v2.domain.model.EconomicBeneficiary;
import com.lombardinternational.casedefinition.v2.domain.model.MoralPerson;
import com.lombardinternational.casedefinition.v2.domain.model.PhysicalPerson;
import com.lombardinternational.casedefinition.v2.domain.model.PolicyRole;
import com.lombardinternational.clients.classapp.model.roles.AbstractPolicyRole;
import com.lombardinternational.clients.classapp.model.roles.Beneficiary;
import com.lombardinternational.clients.classapp.model.roles.CessionHolder;
import com.lombardinternational.clients.classapp.model.roles.EconomicBeneficialOwner;
import com.lombardinternational.clients.classapp.model.roles.Holder;
import com.lombardinternational.clients.classapp.model.roles.LifeAssured;
import com.lombardinternational.clients.classapp.model.roles.Proxy;
import com.lombardinternational.clients.classapp.model.roles.Settlor;
import com.lombardinternational.clients.classapp.model.roles.Trust;
import com.lombardinternational.clients.classapp.model.roles.Trustee;
import org.mapstruct.AfterMapping;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.SubclassMapping;

import java.util.List;
import java.util.stream.Collectors;

@Mapper(componentModel = "spring", uses = {AbstractPersonMapper.class})
public interface PolicyRoleMapper {
    List<PolicyRole> mapToList(List<AbstractPolicyRole> thirdPartyPolicyRoles);

    @Mapping(target = "roleId", source = "externalId")
    @SubclassMapping(source = Holder.class, target = com.lombardinternational.casedefinition.v2.domain.model.Holder.class)
    @SubclassMapping(source = Beneficiary.class, target = com.lombardinternational.casedefinition.v2.domain.model.Beneficiary.class)
    @SubclassMapping(source = Trust.class, target = com.lombardinternational.casedefinition.v2.domain.model.Trust.class)
    @SubclassMapping(source = Trustee.class, target = com.lombardinternational.casedefinition.v2.domain.model.Trustee.class)
    @SubclassMapping(source = LifeAssured.class, target = com.lombardinternational.casedefinition.v2.domain.model.LifeAssured.class)
    @SubclassMapping(source = EconomicBeneficialOwner.class, target = EconomicBeneficiary.class)
    @SubclassMapping(source = Settlor.class, target = com.lombardinternational.casedefinition.v2.domain.model.Settlor.class)
    @SubclassMapping(source = Proxy.class, target = com.lombardinternational.casedefinition.v2.domain.model.Proxy.class)
    @SubclassMapping(source = CessionHolder.class, target = com.lombardinternational.casedefinition.v2.domain.model.CessionHolder.class)
    PolicyRole mapRole(AbstractPolicyRole thirdPartyPolicyRole);

    @AfterMapping
    default void setMoralPhysicalPerson(@MappingTarget PolicyRole policyRole) {
        if (policyRole == null || policyRole.getThirdParties() == null) {
            return;
        }
        policyRole.setMoralPersons(policyRole.getThirdParties().stream()
                .filter(MoralPerson.class::isInstance)
                .map(MoralPerson.class::cast)
                .collect(Collectors.toList()));
        policyRole.setPhysicalPersons(policyRole.getThirdParties().stream()
                .filter(PhysicalPerson.class::isInstance)
                .map(PhysicalPerson.class::cast)
                .collect(Collectors.toList()));
    }

    @Mapping(target = "irrevocableFlag", source = "irrevocable")
    @Mapping(target = "roleId", source = "externalId")
    com.lombardinternational.casedefinition.v2.domain.model.Beneficiary mapTo(Beneficiary abstractPolicyRole);

    @Mapping(source = "taxCountry.externalId", target = "taxIsoCountryCode")
    @Mapping(target = "roleId", source = "externalId")
    com.lombardinternational.casedefinition.v2.domain.model.Holder mapTo(Holder abstractPolicyRole);
}
