package com.lombardinternational.casedefinition.v2.adapter.api.web.mapper;

import com.lombardinternational.casedefinition.v2.domain.model.WebFormField;
import org.mapstruct.Mapper;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Collection;
import java.util.List;

@Mapper(componentModel = "spring")
public abstract class CalendarWebFormFieldMapper {
    @Autowired
    protected WebFormFieldMapper webFormFieldMapper;

    public List<WebFormField> calendarWebFormFieldFromDTO(
            Collection<com.lombardinternational.casedefinition.v2.adapter.api.web.dto.CalendarWebFormField> dtos) {
        return webFormFieldMapper.webFormFieldFromDTO(dtos);
    }
}
