package com.lombardinternational.casedefinition.v2.adapter.api.web.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

import java.util.List;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class CaseControlDefinition {
    private int controlId;
    private String controlName;
    private boolean controlVisibleOnConnect;
    private int controlOrder;
    private List<String> decisionReasons;
    private String controlType;
}
