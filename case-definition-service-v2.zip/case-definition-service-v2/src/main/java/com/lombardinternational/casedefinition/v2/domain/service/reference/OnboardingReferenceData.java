package com.lombardinternational.casedefinition.v2.domain.service.reference;

import com.lombardinternational.casedefinition.v2.domain.model.SelectInputFieldOption;

import java.util.List;
import java.util.stream.Stream;

public final class OnboardingReferenceData {

    public enum YesNo {
        YES("YES", "Yes"),
        NO("NO", "No");

        private final ReferenceOption option;

        YesNo(String key, String value) {
            this.option = new ReferenceOption(key, value);
        }
    }

    public record ReferenceOption(String key, String value) {
        SelectInputFieldOption toSelectInputFieldOption() {
            return new SelectInputFieldOption(key, value);
        }
    }

    public static List<SelectInputFieldOption> yesNoOptions() {
        return Stream.of(YesNo.values())
                .map(value -> value.option.toSelectInputFieldOption())
                .toList();
    }

    public static List<SelectInputFieldOption> selectedOnly(String selectedValue) {
        if (selectedValue == null || selectedValue.isBlank()) {
            return List.of();
        }
        return List.of(new SelectInputFieldOption(selectedValue, selectedValue));
    }

    private OnboardingReferenceData() {
    }
}
