package com.lombardinternational.casedefinition.v2.domain.model;

import lombok.Data;

@Data
public class Block {
    private String externalId;
    private String blockType;
}
