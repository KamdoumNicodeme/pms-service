package com.lombardinternational.casedefinition.v2.mapper;

import com.lombardinternational.casedefinition.v2.domain.model.Block;
import com.lombardinternational.clients.classapp.model.PersistedBlock;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import java.util.Collection;
import java.util.List;

@Mapper(componentModel = "spring")
public interface BlockMapper {
    List<Block> mapToList(Collection<PersistedBlock> persistedBlockCollection);

    @Mapping(source = "blockType.label", target = "blockType")
    Block map(PersistedBlock persistedBlock);
}
