package com.lombardinternational.casedefinition.v2.domain.api;

import com.lombardinternational.casedefinition.v2.domain.model.BusinessTransaction;
import com.lombardinternational.casedefinition.v2.domain.model.Policy;

public interface BusinessTransactionService {
    Boolean hasMadeChangeOfBroker(String policyNumber);

    BusinessTransaction buildBusinessTransaction(String businessTransactionNumber, Policy policy, String caseType,
            String policyNumber);
}
