package com.lombardinternational.casedefinition.v2.domain.service.checklist.onboarding.field;

import com.lombardinternational.casedefinition.v2.domain.model.Group;
import com.lombardinternational.casedefinition.v2.domain.model.ScreenDescription;
import com.lombardinternational.casedefinition.v2.domain.model.WebForm;
import com.lombardinternational.casedefinition.v2.domain.service.checklist.FieldBuilderService;
import org.springframework.stereotype.Service;

import java.util.Map;

@Service
public class OnboardingLifeCoverFieldsBuilderService extends OnboardingChecklistFieldsBuilderSupport implements FieldBuilderService {
    @Override
    public void buildField(WebForm webForm, ScreenDescription screenDescription, Group group) {
        var previousValues = previousValues(screenDescription);
        resetFields(group);
        buildLifeCoverType(group, previousValues, webForm);
        buildSar(group, previousValues, webForm);
        buildUnderwritings(group, previousValues, webForm);
        sortFields(group);
    }

    private void buildLifeCoverType(Group group, Map<String, String> previousValues, WebForm webForm) {
        buildField(group, new FieldRule("LIFE_COVER_TYPE", FieldKind.SELECT, 1, "Life cover type capped", true, true,
                "YES\u00acYes;NO\u00acNo", null, false, null, false), previousValues, webForm);
    }

    private void buildSar(Group group, Map<String, String> previousValues, WebForm webForm) {
        buildField(group, new FieldRule("SAR", FieldKind.TEXT, 2, "SAR", true, true,
                null, "#LIFE_COVER_TYPE# == \"NO\"", false, null, false), previousValues, webForm);
    }

    private void buildUnderwritings(Group group, Map<String, String> previousValues, WebForm webForm) {
        buildField(group, new FieldRule("UNDERWRITINGS", FieldKind.SELECT, 3, "Underwritings", true, true,
                "L0;L1;L2;L3;L4;L5;L6", "#LIFE_COVER_TYPE# == \"NO\"", false, null, false), previousValues, webForm);
    }

}
