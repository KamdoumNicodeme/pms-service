package com.lombardinternational.casedefinition.v2.domain.service.checklist.onboarding.field;

import com.lombardinternational.casedefinition.v2.domain.model.Field;
import com.lombardinternational.casedefinition.v2.domain.model.Group;
import com.lombardinternational.casedefinition.v2.domain.model.NumberInputField;
import com.lombardinternational.casedefinition.v2.domain.model.ScreenDescription;
import com.lombardinternational.casedefinition.v2.domain.model.SelectInputField;
import com.lombardinternational.casedefinition.v2.domain.model.TextAreaField;
import com.lombardinternational.casedefinition.v2.domain.model.TextInputField;
import com.lombardinternational.casedefinition.v2.domain.model.WebForm;
import com.lombardinternational.casedefinition.v2.domain.model.WebFormField;
import com.lombardinternational.casedefinition.v2.domain.model.WebFormGroup;
import com.lombardinternational.casedefinition.v2.domain.service.checklist.FieldBuilderService;
import com.lombardinternational.casedefinition.v2.domain.service.reference.OnboardingReferenceData;
import com.lombardinternational.casedefinition.v2.domain.utils.ChecklistUtils;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.OptionalInt;
import java.util.stream.IntStream;
import java.util.stream.Stream;

import static com.lombardinternational.casedefinition.v2.domain.transaction.onboarding.rules.OnboardingChecklistIds.BANK_NAME_OF_ORIGINATING_ACCOUNT;
import static com.lombardinternational.casedefinition.v2.domain.transaction.onboarding.rules.OnboardingChecklistIds.BANK_NOT_IN_RESIDENCE;
import static com.lombardinternational.casedefinition.v2.domain.transaction.onboarding.rules.OnboardingChecklistIds.CLOSE_TO_EBO;
import static com.lombardinternational.casedefinition.v2.domain.transaction.onboarding.rules.OnboardingChecklistIds.COUNTRY_OF_ORIGINATING_ACCOUNT;
import static com.lombardinternational.casedefinition.v2.domain.transaction.onboarding.rules.OnboardingChecklistIds.ECONOMIC_JUSTIF;
import static com.lombardinternational.casedefinition.v2.domain.transaction.onboarding.rules.OnboardingChecklistIds.EVIDENCE_LEGAL_ENTITY;
import static com.lombardinternational.casedefinition.v2.domain.transaction.onboarding.rules.OnboardingChecklistIds.EVIDENCE_TAX_DECLARED;
import static com.lombardinternational.casedefinition.v2.domain.transaction.onboarding.rules.OnboardingChecklistIds.EXISTING_ILF;
import static com.lombardinternational.casedefinition.v2.domain.transaction.onboarding.rules.OnboardingChecklistIds.ILF_MNEMONIC;
import static com.lombardinternational.casedefinition.v2.domain.transaction.onboarding.rules.OnboardingChecklistIds.INITIAL_PREM;
import static com.lombardinternational.casedefinition.v2.domain.transaction.onboarding.rules.OnboardingChecklistIds.INVESTED_IN_ILF;
import static com.lombardinternational.casedefinition.v2.domain.transaction.onboarding.rules.OnboardingChecklistIds.IS_DEALING;
import static com.lombardinternational.casedefinition.v2.domain.transaction.onboarding.rules.OnboardingChecklistIds.IS_ROP_CASE;
import static com.lombardinternational.casedefinition.v2.domain.transaction.onboarding.rules.OnboardingChecklistIds.NAME_OF_ORIGINATING_ACCOUNT_HOLDER;
import static com.lombardinternational.casedefinition.v2.domain.transaction.onboarding.rules.OnboardingChecklistIds.NEGATIVE_FINDING_PAYERS;
import static com.lombardinternational.casedefinition.v2.domain.transaction.onboarding.rules.OnboardingChecklistIds.NUMBER_OF_ORIGINATING_ACCOUNTS;
import static com.lombardinternational.casedefinition.v2.domain.transaction.onboarding.rules.OnboardingChecklistIds.ORIGINATING_BANK_COUNTRY_RISK;
import static com.lombardinternational.casedefinition.v2.domain.transaction.onboarding.rules.OnboardingChecklistIds.PAYER_CORPORATE_ENTITY;
import static com.lombardinternational.casedefinition.v2.domain.transaction.onboarding.rules.OnboardingChecklistIds.PAYER_IN_SANCTION_LIST;
import static com.lombardinternational.casedefinition.v2.domain.transaction.onboarding.rules.OnboardingChecklistIds.PAYER_NOT_LOCATED;
import static com.lombardinternational.casedefinition.v2.domain.transaction.onboarding.rules.OnboardingChecklistIds.PAYMENT_THIRD_PARTY;
import static com.lombardinternational.casedefinition.v2.domain.transaction.onboarding.rules.OnboardingChecklistIds.PREMIUM_RECEIVED_DIFFERENT_EXPECTED;
import static com.lombardinternational.casedefinition.v2.domain.transaction.onboarding.rules.OnboardingChecklistIds.PREMIUM_WITH_ASSETS;
import static com.lombardinternational.casedefinition.v2.domain.transaction.onboarding.rules.OnboardingChecklistIds.PREMIUM_WITH_UNQ_ASSETS;
import static com.lombardinternational.casedefinition.v2.domain.transaction.onboarding.rules.OnboardingChecklistIds.RATIONALE_FOR_INVESTMENT;
import static com.lombardinternational.casedefinition.v2.domain.transaction.onboarding.rules.OnboardingChecklistIds.REFUSED_ADDITIONAL_INFO;
import static com.lombardinternational.casedefinition.v2.domain.transaction.onboarding.rules.OnboardingChecklistIds.SAME_AS_DISCLOSED;

@Service
public class OnboardingTransactionDetailsFieldsBuilderService implements FieldBuilderService {
    private static final String SOURCE_CLASS = "From CLASS";
    private static final String SOURCE_CONNECT = "From Connect";
    private static final String YES = "YES";

    @Override
    public void buildField(WebForm webForm, ScreenDescription screenDescription, Group group) {
        var previousValues = screenDescription == null ? Map.<String, String>of() : screenDescription.selectedValuesByFieldId();
        group.setFields(new ArrayList<>());

        buildPremiumWithAssets(group, previousValues, webForm);
        buildPremiumWithUnquotedAssets(group, previousValues, webForm);
        buildIsRopCase(group, previousValues, webForm);
        buildInitialPremium(group, previousValues, webForm);
        buildInvestedInIlf(group, previousValues, webForm);
        buildExistingIlf(group, previousValues, webForm);
        buildIlfMnemonic(group, previousValues, webForm);
        buildIsDealing(group, previousValues, webForm);
        buildPaymentThirdParty(group, previousValues, webForm);
        buildPayerInSanctionList(group, previousValues, webForm);
        buildNegativeFindingPayers(group, previousValues, webForm);
        buildPayerCorporateEntity(group, previousValues, webForm);
        buildPayerNotLocated(group, previousValues, webForm);
        buildEvidenceLegalEntity(group, previousValues, webForm);
        buildCloseToEbo(group, previousValues, webForm);
        buildBankNotInResidence(group, previousValues, webForm);
        buildEconomicJustification(group, previousValues, webForm);
        buildEvidenceTaxDeclared(group, previousValues, webForm);
        buildRefusedAdditionalInfo(group, previousValues, webForm);
        buildPremiumReceivedDifferentThanExpected(group, previousValues, webForm);
        buildSameAsDisclosed(group, previousValues, webForm);
        buildRationaleForInvestment(group, previousValues, webForm);
        buildOriginatingAccounts(group, previousValues, webForm);

        group.getFields().sort(Comparator.comparingInt(Field::getOrder).thenComparing(Field::getFieldId));
    }

    private void buildPremiumWithAssets(Group group, Map<String, String> previousValues, WebForm webForm) {
        var field = selectField(group, PREMIUM_WITH_ASSETS);
        apply(field, new FieldRule(1, "Premium with assets?", true, false, null, false, null), previousValues, webForm);
        field.setOptions(OnboardingReferenceData.yesNoOptions());
    }

    private void buildPremiumWithUnquotedAssets(Group group, Map<String, String> previousValues, WebForm webForm) {
        var field = selectField(group, PREMIUM_WITH_UNQ_ASSETS);
        apply(field, new FieldRule(2, "Premium with unquoted assets?", false, false, null, false, SOURCE_CONNECT),
                previousValues, webForm);
        field.setOptions(OnboardingReferenceData.selectedOnly(field.getSelectedValue()));
    }

    private void buildIsRopCase(Group group, Map<String, String> previousValues, WebForm webForm) {
        var field = selectField(group, IS_ROP_CASE);
        apply(field, new FieldRule(3, "ROP Case ?", true, true, null, false, null), previousValues, webForm);
        field.setOptions(OnboardingReferenceData.yesNoOptions());
    }

    private void buildInitialPremium(Group group, Map<String, String> previousValues, WebForm webForm) {
        var field = numberField(group, INITIAL_PREM);
        apply(field, new FieldRule(4, "Initial premium (in policy currency)", true, true,
                selectedEquals(IS_ROP_CASE, YES), false, null), previousValues, webForm);
    }

    private void buildInvestedInIlf(Group group, Map<String, String> previousValues, WebForm webForm) {
        var field = selectField(group, INVESTED_IN_ILF);
        apply(field, new FieldRule(5, "Will it be reinvested in an ILF?", true, true, null, false, null),
                previousValues, webForm);
        field.setOptions(OnboardingReferenceData.yesNoOptions());
    }

    private void buildExistingIlf(Group group, Map<String, String> previousValues, WebForm webForm) {
        var field = selectField(group, EXISTING_ILF);
        apply(field, new FieldRule(6, "Is it an existing ILF?", true, true, selectedEquals(INVESTED_IN_ILF, YES), false, null),
                previousValues, webForm);
        field.setOptions(OnboardingReferenceData.yesNoOptions());
    }

    private void buildIlfMnemonic(Group group, Map<String, String> previousValues, WebForm webForm) {
        var field = textField(group, ILF_MNEMONIC);
        apply(field, new FieldRule(7, "ILF Mnemonic", true, false, selectedEquals(EXISTING_ILF, YES), false, null),
                previousValues, webForm);
    }

    private void buildIsDealing(Group group, Map<String, String> previousValues, WebForm webForm) {
        var field = selectField(group, IS_DEALING);
        apply(field, new FieldRule(8, "Is dealing requested", true, true, null, false, null), previousValues, webForm);
        field.setOptions(OnboardingReferenceData.yesNoOptions());
    }

    private void buildPaymentThirdParty(Group group, Map<String, String> previousValues, WebForm webForm) {
        var field = selectField(group, PAYMENT_THIRD_PARTY);
        apply(field, new FieldRule(9, "Payment from a third party payer", false, true, null, true, SOURCE_CLASS),
                previousValues, webForm);
        field.setOptions(OnboardingReferenceData.selectedOnly(field.getSelectedValue()));
    }

    private void buildPayerInSanctionList(Group group, Map<String, String> previousValues, WebForm webForm) {
        var field = selectField(group, PAYER_IN_SANCTION_LIST);
        apply(field, new FieldRule(10, "Is one of the payers designated on a sanctions list?", true, true,
                thirdPartyPayerDisplayIf(), false, null), previousValues, webForm);
        field.setOptions(OnboardingReferenceData.yesNoOptions());
    }

    private void buildNegativeFindingPayers(Group group, Map<String, String> previousValues, WebForm webForm) {
        var field = selectField(group, NEGATIVE_FINDING_PAYERS);
        apply(field, new FieldRule(11, "Negative press finding / Worldcheck match (on any of the payers)?", true, true,
                thirdPartyPayerDisplayIf(), false, null), previousValues, webForm);
        field.setOptions(OnboardingReferenceData.yesNoOptions());
    }

    private void buildPayerCorporateEntity(Group group, Map<String, String> previousValues, WebForm webForm) {
        var field = selectField(group, PAYER_CORPORATE_ENTITY);
        apply(field, new FieldRule(12, "Is the payer a Corporate entity where the PH/EBO is the sole shareholder?", true, true,
                thirdPartyPayerDisplayIf(), false, null), previousValues, webForm);
        field.setOptions(OnboardingReferenceData.yesNoOptions());
    }

    private void buildPayerNotLocated(Group group, Map<String, String> previousValues, WebForm webForm) {
        var field = selectField(group, PAYER_NOT_LOCATED);
        apply(field, new FieldRule(13,
                "Is the 3rd party payer a legal entity located in a country which is not the tax country of residence "
                        + "or place of regular economic or professional activities/interests of the PH/EBO?",
                true, true, thirdPartyPayerDisplayIf(), false, null), previousValues, webForm);
        field.setOptions(OnboardingReferenceData.yesNoOptions());
    }

    private void buildEvidenceLegalEntity(Group group, Map<String, String> previousValues, WebForm webForm) {
        var field = selectField(group, EVIDENCE_LEGAL_ENTITY);
        apply(field, new FieldRule(14,
                "Did you collect supporting evidence that the legal entity is known by the tax authorities of the country "
                        + "of residence of the PH/EBO or could the legal entity  demonstrate that its establishment complies "
                        + "with the legal provisions of the country of residence of the PH/EBO?",
                true, true, selectedEquals(PAYER_NOT_LOCATED, YES), false, null), previousValues, webForm);
        field.setOptions(OnboardingReferenceData.yesNoOptions());
    }

    private void buildCloseToEbo(Group group, Map<String, String> previousValues, WebForm webForm) {
        var field = selectField(group, CLOSE_TO_EBO);
        apply(field, new FieldRule(15,
                "In case of any additional documentation collected to corroborate the tax conformity of the funds "
                        + "(e.g. annual income tax return, the regularisation documentation or memo from the tax lawyer "
                        + "of the PH/EBO), is this  supporting documentation issued by a person who is close to the PH/EBO "
                        + "and leaving room for doubt due to the potential conflict of interest?",
                true, true, null, false, null), previousValues, webForm);
        field.setOptions(OnboardingReferenceData.yesNoOptions());
    }

    private void buildBankNotInResidence(Group group, Map<String, String> previousValues, WebForm webForm) {
        var field = selectField(group, BANK_NOT_IN_RESIDENCE);
        apply(field, new FieldRule(16,
                "Are the funds paid from a bank account located in a country which is not the tax country of residence "
                        + "of the PH(s)/EBO(s)?",
                true, true, null, false, null), previousValues, webForm);
        field.setOptions(OnboardingReferenceData.yesNoOptions());
    }

    private void buildEconomicJustification(Group group, Map<String, String> previousValues, WebForm webForm) {
        var field = selectField(group, ECONOMIC_JUSTIF);
        apply(field, new FieldRule(17,
                "Is there an obvious economic justification (e.g. the PH/EBO lived in that jurisdiction, worked and/or "
                        + "works in that jurisdiction, funds were generated in that jurisdiction)?",
                true, true, selectedEquals(BANK_NOT_IN_RESIDENCE, YES), false, null), previousValues, webForm);
        field.setOptions(OnboardingReferenceData.yesNoOptions());
    }

    private void buildEvidenceTaxDeclared(Group group, Map<String, String> previousValues, WebForm webForm) {
        var field = selectField(group, EVIDENCE_TAX_DECLARED);
        apply(field, new FieldRule(18,
                "Did you collect supporting evidence that the bank account is  known by the tax authorities of the country "
                        + "of residence of the PH/EBO or that the funds have been tax declared (e.g. annual income tax , "
                        + "return regularisation documentation)?",
                true, true, selectedEquals(BANK_NOT_IN_RESIDENCE, YES) + " && " + selectedEquals(ECONOMIC_JUSTIF, "NO"),
                false, null), previousValues, webForm);
        field.setOptions(OnboardingReferenceData.yesNoOptions());
    }

    private void buildRefusedAdditionalInfo(Group group, Map<String, String> previousValues, WebForm webForm) {
        var field = selectField(group, REFUSED_ADDITIONAL_INFO);
        apply(field, new FieldRule(19, "Did the PH/EBO refuse to provide this additional supporting documentation?", true, true,
                selectedEquals(BANK_NOT_IN_RESIDENCE, YES) + " && " + selectedEquals(ECONOMIC_JUSTIF, "NO") + " && "
                        + selectedEquals(EVIDENCE_TAX_DECLARED, "NO"),
                false, null), previousValues, webForm);
        field.setOptions(OnboardingReferenceData.yesNoOptions());
    }

    private void buildPremiumReceivedDifferentThanExpected(Group group, Map<String, String> previousValues, WebForm webForm) {
        var field = selectField(group, PREMIUM_RECEIVED_DIFFERENT_EXPECTED);
        apply(field, new FieldRule(20,
                "Is the premium received different than expected one (higher amount or different payment details)?",
                true, true, null, false, null), previousValues, webForm);
        field.setOptions(OnboardingReferenceData.yesNoOptions());
    }

    private void buildSameAsDisclosed(Group group, Map<String, String> previousValues, WebForm webForm) {
        var field = selectField(group, SAME_AS_DISCLOSED);
        apply(field, new FieldRule(21,
                "Is the origin of the funds or additional funds and/or the payment details the same as disclosed in the KYC form?",
                true, true, selectedEquals(PREMIUM_RECEIVED_DIFFERENT_EXPECTED, YES), false, null), previousValues, webForm);
        field.setOptions(OnboardingReferenceData.yesNoOptions());
    }

    private void buildRationaleForInvestment(Group group, Map<String, String> previousValues, WebForm webForm) {
        var field = textAreaField(group, RATIONALE_FOR_INVESTMENT);
        apply(field, new FieldRule(22, "Rationale for investment", true, false, null, false, null), previousValues, webForm);
    }

    private void buildOriginatingAccounts(Group group, Map<String, String> previousValues, WebForm webForm) {
        var accountCount = originatingAccountCount(previousValues, webForm);
        buildNumberOfOriginatingAccounts(group, previousValues, webForm, accountCount);

        if (accountCount <= 0) {
            buildOriginatingAccountTemplateFields(group, previousValues, webForm);
        } else {
            IntStream.rangeClosed(1, accountCount)
                    .forEach(position -> buildOriginatingAccountFields(group, previousValues, webForm, position));
        }

        buildOriginatingBankCountryRisk(group, previousValues, webForm);
    }

    private void buildNumberOfOriginatingAccounts(Group group, Map<String, String> previousValues, WebForm webForm, int accountCount) {
        var field = selectField(group, NUMBER_OF_ORIGINATING_ACCOUNTS);
        apply(field, new FieldRule(23, "Number of originating accounts", false, true, null, false, null), previousValues, webForm);
        if ((field.getSelectedValue() == null || field.getSelectedValue().isBlank()) && accountCount > 0) {
            field.setSelectedValue(Integer.toString(accountCount));
        }
        field.setOptions(OnboardingReferenceData.selectedOnly(field.getSelectedValue()));
    }

    private void buildOriginatingAccountTemplateFields(Group group, Map<String, String> previousValues, WebForm webForm) {
        var holder = textField(group, NAME_OF_ORIGINATING_ACCOUNT_HOLDER);
        apply(holder, new FieldRule(24, "Account holder ID", false, true,
                originatingAccountTemplateDisplayIf(), false, null), previousValues, webForm);
        holder.setMultiple(true);

        var country = selectField(group, COUNTRY_OF_ORIGINATING_ACCOUNT);
        apply(country, new FieldRule(25, "Country of the originating bank", false, true,
                originatingAccountTemplateDisplayIf(), false, null), previousValues, webForm);
        country.setMultiple(true);
        country.setOptions(OnboardingReferenceData.selectedOnly(country.getSelectedValue()));

        var bankName = textField(group, BANK_NAME_OF_ORIGINATING_ACCOUNT);
        apply(bankName, new FieldRule(26, "Name of the bank", false, true,
                originatingAccountTemplateDisplayIf(), false, null), previousValues, webForm);
        bankName.setMultiple(true);
    }

    private void buildOriginatingAccountFields(Group group, Map<String, String> previousValues, WebForm webForm, int position) {
        var holder = textField(group, suffixed(NAME_OF_ORIGINATING_ACCOUNT_HOLDER, position));
        apply(holder, new FieldRule(24 + ((position - 1) * 3), "Account holder ID #" + position, false, true,
                null, false, null), previousValues, webForm);

        var country = selectField(group, suffixed(COUNTRY_OF_ORIGINATING_ACCOUNT, position));
        apply(country, new FieldRule(25 + ((position - 1) * 3), "Country of the originating bank #" + position, false, true,
                null, false, null), previousValues, webForm);
        country.setOptions(OnboardingReferenceData.selectedOnly(country.getSelectedValue()));

        var bankName = textField(group, suffixed(BANK_NAME_OF_ORIGINATING_ACCOUNT, position));
        apply(bankName, new FieldRule(26 + ((position - 1) * 3), "Name of the bank #" + position, false, true,
                null, false, null), previousValues, webForm);
    }

    private void buildOriginatingBankCountryRisk(Group group, Map<String, String> previousValues, WebForm webForm) {
        var field = textField(group, ORIGINATING_BANK_COUNTRY_RISK);
        apply(field, new FieldRule(200, "Riskiest country of originating bank", false, true,
                "#" + NUMBER_OF_ORIGINATING_ACCOUNTS + "# >= 1", false, null), previousValues, webForm);
    }

    private <T extends Field> T apply(T field, FieldRule rule, Map<String, String> previousValues, WebForm webForm) {
        field.setIsActive(true);
        field.setOrder(rule.order());
        field.setLabel(rule.label());
        field.setEnabled(rule.enabled());
        field.setMandatory(rule.mandatory());
        field.setDisplayIf(blankToNull(rule.displayIf()));
        field.setLabelBold(rule.labelBold());
        field.setSourceSystem(blankToNull(rule.sourceSystem()));
        field.setMultiple(null);
        field.setMaxMultiple(null);
        field.setSelectedValue(selectedValue(field.getFieldId(), previousValues, webForm));
        return field;
    }

    private SelectInputField selectField(Group group, String fieldId) {
        return switch (ChecklistUtils.getFieldInGroup(group, fieldId)) {
            case null -> {
                var field = SelectInputField.builder().fieldId(fieldId).build();
                group.getFields().add(field);
                yield field;
            }
            case SelectInputField field -> field;
            default -> throw unexpectedFieldType(fieldId, SelectInputField.class);
        };
    }

    private NumberInputField numberField(Group group, String fieldId) {
        return switch (ChecklistUtils.getFieldInGroup(group, fieldId)) {
            case null -> {
                var field = NumberInputField.builder().fieldId(fieldId).build();
                group.getFields().add(field);
                yield field;
            }
            case NumberInputField field -> field;
            default -> throw unexpectedFieldType(fieldId, NumberInputField.class);
        };
    }

    private TextInputField textField(Group group, String fieldId) {
        return switch (ChecklistUtils.getFieldInGroup(group, fieldId)) {
            case null -> {
                var field = TextInputField.builder().fieldId(fieldId).build();
                group.getFields().add(field);
                yield field;
            }
            case TextInputField field -> field;
            default -> throw unexpectedFieldType(fieldId, TextInputField.class);
        };
    }

    private TextAreaField textAreaField(Group group, String fieldId) {
        return switch (ChecklistUtils.getFieldInGroup(group, fieldId)) {
            case null -> {
                var field = TextAreaField.builder().fieldId(fieldId).build();
                group.getFields().add(field);
                yield field;
            }
            case TextAreaField field -> field;
            default -> throw unexpectedFieldType(fieldId, TextAreaField.class);
        };
    }

    private IllegalStateException unexpectedFieldType(String fieldId, Class<? extends Field> expectedType) {
        return new IllegalStateException("Field " + fieldId + " must be a " + expectedType.getSimpleName());
    }

    private String selectedValue(String fieldId, Map<String, String> previousValues, WebForm webForm) {
        return Optional.ofNullable(previousValues.get(fieldId))
                .or(() -> Optional.ofNullable(webForm).flatMap(form -> form.findFieldValue(fieldId)))
                .orElse(null);
    }

    private String blankToNull(String value) {
        return value == null || value.isBlank() ? null : value;
    }

    private int originatingAccountCount(Map<String, String> previousValues, WebForm webForm) {
        var explicitCount = parsePositiveInt(selectedValue(NUMBER_OF_ORIGINATING_ACCOUNTS, previousValues, webForm)).orElse(0);
        var countFromPreviousValues = maxOriginatingAccountSuffix(previousValues.keySet().stream());
        var countFromWebForm = maxOriginatingAccountSuffix(webFormFieldIds(webForm));
        return Stream.of(explicitCount, countFromPreviousValues, countFromWebForm).mapToInt(Integer::intValue).max().orElse(0);
    }

    private int maxOriginatingAccountSuffix(Stream<String> fieldIds) {
        return fieldIds.mapToInt(this::originatingAccountPosition).max().orElse(0);
    }

    private int originatingAccountPosition(String fieldId) {
        if (fieldId == null) {
            return 0;
        }
        return Stream.of(NAME_OF_ORIGINATING_ACCOUNT_HOLDER, COUNTRY_OF_ORIGINATING_ACCOUNT, BANK_NAME_OF_ORIGINATING_ACCOUNT)
                .map(prefix -> positionAfterPrefix(fieldId, prefix))
                .flatMapToInt(OptionalInt::stream)
                .max()
                .orElse(0);
    }

    private OptionalInt positionAfterPrefix(String fieldId, String prefix) {
        var marker = prefix + "_";
        if (!fieldId.startsWith(marker)) {
            return OptionalInt.empty();
        }
        return parsePositiveInt(fieldId.substring(marker.length()));
    }

    private OptionalInt parsePositiveInt(String value) {
        if (value == null || value.isBlank()) {
            return OptionalInt.empty();
        }
        try {
            var parsed = Integer.parseInt(value.trim());
            return parsed > 0 ? OptionalInt.of(parsed) : OptionalInt.empty();
        } catch (NumberFormatException ignored) {
            return OptionalInt.empty();
        }
    }

    private Stream<String> webFormFieldIds(WebForm webForm) {
        return Optional.ofNullable(webForm).stream()
                .flatMap(WebForm::groups)
                .flatMap(WebFormGroup::fields)
                .filter(Objects::nonNull)
                .map(WebFormField::getFieldId)
                .filter(Objects::nonNull);
    }

    private String selectedEquals(String fieldId, String expectedValue) {
        return "#" + fieldId + "# == \"" + expectedValue + "\"";
    }

    private String thirdPartyPayerDisplayIf() {
        return selectedEquals(PAYMENT_THIRD_PARTY, YES);
    }

    private String originatingAccountTemplateDisplayIf() {
        return "#" + NUMBER_OF_ORIGINATING_ACCOUNTS + "# >= $";
    }

    private String suffixed(String fieldId, int position) {
        return fieldId + "_" + position;
    }

    private record FieldRule(int order, String label, boolean enabled, boolean mandatory, String displayIf, boolean labelBold,
                             String sourceSystem) {
    }
}
