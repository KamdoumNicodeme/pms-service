package com.lombardinternational.casedefinition.v2.domain.api;

import com.lombardinternational.casedefinition.v2.domain.model.CaseControlDefinition;
import com.lombardinternational.casedefinition.v2.domain.model.CaseDocumentDefinition;
import com.lombardinternational.casedefinition.v2.domain.model.ScreenDescription;
import com.lombardinternational.casedefinition.v2.domain.model.TaskDefinition;
import com.lombardinternational.casedefinition.v2.domain.model.WebForm;

import java.util.List;

public interface CaseBusinessService {
    List<CaseDocumentDefinition> computeCaseDocumentsDefinition(String policyNumber, String caseType, WebForm webForm,
            ScreenDescription screenCheckList);

    List<CaseControlDefinition> computeCaseControlDefinitions(String caseType, WebForm webForm,
            ScreenDescription screenCheckList);

    List<TaskDefinition> computeCaseSubTasks(String policyNumber, String caseType, WebForm webForm,
            ScreenDescription screenCheckList);
}
