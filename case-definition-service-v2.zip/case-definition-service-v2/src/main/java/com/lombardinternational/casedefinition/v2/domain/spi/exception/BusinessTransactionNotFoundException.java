package com.lombardinternational.casedefinition.v2.domain.spi.exception;

public class BusinessTransactionNotFoundException extends RuntimeException {
    public BusinessTransactionNotFoundException(String message) {
        super(message);
    }
}
