package com.lombardinternational.casedefinition.v2.adapter.api.web.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class Tab {
    private String tabId;
    private String label;
    private String i18NLabelKey;
    private int order;
    private Boolean triggersRecomputeScreen;
    private String type;
    @Builder.Default
    private List<Group> groups = new ArrayList<>();
    private String displayIf;
    private Boolean isActive;
}
