package com.lombardinternational.casedefinition.v2.domain.service;

import com.lombardinternational.casedefinition.v2.domain.api.RulesEngineService;
import com.lombardinternational.casedefinition.v2.domain.model.*;
import com.lombardinternational.casedefinition.v2.domain.transaction.onboarding.rules.OnboardingTransactionIds;
import com.lombardinternational.casedefinition.v2.domain.service.factory.TransactionFactory;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Objects;

@Service
@AllArgsConstructor
public class RulesEngineServiceImpl implements RulesEngineService {
    private final TransactionFactory transactionFactory;

    @Override
    public ScreenDescription buildCheckList(WebForm webForm, ScreenDescription screenDescription, String policyNumber, String transactionNumber) {
        var checklist = serviceFor(webForm, screenDescription).buildCheckList(webForm, screenDescription, policyNumber, transactionNumber);
        cleanChecklist(checklist);
        return checklist;
    }

    @Override
    public List<TaskDefinition> buildTaskList(WebForm webForm, ScreenDescription screenDescription, String policyNumber) {
        return serviceFor(webForm, screenDescription).buildTaskList(webForm, screenDescription, policyNumber);
    }

    @Override
    public ScreenDescription buildTaskScreen(WebForm webForm, ScreenDescription screenCheckList, ScreenDescription screenToFill) {
        var taskScreen = serviceFor(webForm, screenCheckList).buildTaskScreen(webForm, screenCheckList, screenToFill);
        cleanChecklist(taskScreen);
        return taskScreen;
    }

    @Override
    public List<CaseDocumentDefinition> buildDocumentsDefinition(WebForm webForm, ScreenDescription screenDescription, String policyNumber, String transactionNumber) {
        return serviceFor(webForm, screenDescription).buildDocumentsDefinition(webForm, screenDescription, policyNumber, transactionNumber);
    }

    @Override
    public List<CaseControlDefinition> buildControlDefinition(WebForm webForm, ScreenDescription screenDescription) {
        return serviceFor(webForm, screenDescription).buildControlDefinition(webForm, screenDescription);
    }

    @Override
    public SignatoryResult buildSignatories(WebForm webForm, String policyNumber) {
        return serviceFor(webForm, null).buildSignatories(webForm, policyNumber);
    }

    private com.lombardinternational.casedefinition.v2.domain.service.factory.RulesBuilderService serviceFor(WebForm webForm, ScreenDescription screenDescription) {
        var webFormId = webForm == null || webForm.getWebFormId() == null ? OnboardingTransactionIds.WEB_FORM_ID : webForm.getWebFormId();
        var screenId = screenDescription == null ? null : screenDescription.getScreenId();
        var service = transactionFactory.getService(new TransactionKeyType(screenId, webFormId));
        if (service == null) {
            throw new UnsupportedTransactionException("case-definition-service-v2 currently supports only ONBOARDING / NEW_BUSINESS_CHECKLIST");
        }
        return service;
    }

    private void cleanChecklist(ScreenDescription screenDescription) {
        if (screenDescription == null || screenDescription.getTabs() == null) {
            return;
        }
        screenDescription.setTabs(screenDescription.getTabs().stream().filter(Objects::nonNull).filter(tab -> Boolean.TRUE.equals(tab.getIsActive()))
                .peek(tab -> tab.setGroups(tab.getGroups().stream().filter(Objects::nonNull).filter(group -> Boolean.TRUE.equals(group.getIsActive()))
                        .peek(group -> group.setFields(group.getFields().stream().filter(Objects::nonNull).filter(field -> Boolean.TRUE.equals(field.getIsActive())).toList()))
                        .toList()))
                .toList());
    }
}
