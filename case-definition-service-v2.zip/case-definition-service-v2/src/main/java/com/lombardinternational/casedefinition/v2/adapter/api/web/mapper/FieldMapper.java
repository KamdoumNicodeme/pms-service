package com.lombardinternational.casedefinition.v2.adapter.api.web.mapper;

import com.lombardinternational.casedefinition.v2.domain.model.CheckBoxField;
import com.lombardinternational.casedefinition.v2.domain.model.Field;
import com.lombardinternational.casedefinition.v2.domain.model.LabelField;
import com.lombardinternational.casedefinition.v2.domain.model.NumberInputField;
import com.lombardinternational.casedefinition.v2.domain.model.SelectInputField;
import com.lombardinternational.casedefinition.v2.domain.model.TextAreaField;
import com.lombardinternational.casedefinition.v2.domain.model.TextInputField;
import org.mapstruct.Mapper;
import org.mapstruct.Named;

import java.util.List;

@Mapper(componentModel = "spring", uses = {SelectInputFieldOptionMapper.class})
public interface FieldMapper {
    default Field map(com.lombardinternational.casedefinition.v2.adapter.api.web.dto.Field field) {
        if (field == null) {
            return null;
        }
        if (field instanceof com.lombardinternational.casedefinition.v2.adapter.api.web.dto.LabelField labelField) {
            return fromDto(labelField);
        }
        if (field instanceof com.lombardinternational.casedefinition.v2.adapter.api.web.dto.TextInputField textInputField) {
            return fromDto(textInputField);
        }
        if (field instanceof com.lombardinternational.casedefinition.v2.adapter.api.web.dto.NumberInputField numberInputField) {
            return fromDto(numberInputField);
        }
        if (field instanceof com.lombardinternational.casedefinition.v2.adapter.api.web.dto.SelectInputField selectInputField) {
            return fromDto(selectInputField);
        }
        if (field instanceof com.lombardinternational.casedefinition.v2.adapter.api.web.dto.TextAreaField textAreaField) {
            return fromDto(textAreaField);
        }
        if (field instanceof com.lombardinternational.casedefinition.v2.adapter.api.web.dto.CheckBoxField checkBoxField) {
            return fromDto(checkBoxField);
        }
        throw new IllegalArgumentException("Cannot map Field DTO subtype " + field.getClass().getName());
    }

    default com.lombardinternational.casedefinition.v2.adapter.api.web.dto.Field map(Field field) {
        if (field == null) {
            return null;
        }
        if (field instanceof LabelField labelField) {
            return toDto(labelField);
        }
        if (field instanceof TextInputField textInputField) {
            return toDto(textInputField);
        }
        if (field instanceof NumberInputField numberInputField) {
            return toDto(numberInputField);
        }
        if (field instanceof SelectInputField selectInputField) {
            return toDto(selectInputField);
        }
        if (field instanceof TextAreaField textAreaField) {
            return toDto(textAreaField);
        }
        if (field instanceof CheckBoxField checkBoxField) {
            return toDto(checkBoxField);
        }
        throw new IllegalArgumentException("Cannot map Field subtype " + field.getClass().getName());
    }

    List<Field> mapFromDto(List<com.lombardinternational.casedefinition.v2.adapter.api.web.dto.Field> fields);

    List<com.lombardinternational.casedefinition.v2.adapter.api.web.dto.Field> mapToDto(List<Field> fields);

    @Named("labelField")
    LabelField fromDto(com.lombardinternational.casedefinition.v2.adapter.api.web.dto.LabelField labelField);

    @Named("labelFieldDto")
    com.lombardinternational.casedefinition.v2.adapter.api.web.dto.LabelField toDto(LabelField labelField);

    @Named("textInputField")
    TextInputField fromDto(com.lombardinternational.casedefinition.v2.adapter.api.web.dto.TextInputField textInputField);

    @Named("textInputFieldDto")
    com.lombardinternational.casedefinition.v2.adapter.api.web.dto.TextInputField toDto(TextInputField textInputField);

    @Named("numberInputField")
    NumberInputField fromDto(com.lombardinternational.casedefinition.v2.adapter.api.web.dto.NumberInputField numberInputField);

    @Named("numberInputFieldDto")
    com.lombardinternational.casedefinition.v2.adapter.api.web.dto.NumberInputField toDto(NumberInputField numberInputField);

    @Named("selectInputField")
    SelectInputField fromDto(com.lombardinternational.casedefinition.v2.adapter.api.web.dto.SelectInputField selectInputField);

    @Named("selectInputFieldDto")
    com.lombardinternational.casedefinition.v2.adapter.api.web.dto.SelectInputField toDto(SelectInputField selectInputField);

    @Named("textAreaField")
    TextAreaField fromDto(com.lombardinternational.casedefinition.v2.adapter.api.web.dto.TextAreaField textAreaField);

    @Named("textAreaFieldDto")
    com.lombardinternational.casedefinition.v2.adapter.api.web.dto.TextAreaField toDto(TextAreaField textAreaField);

    @Named("checkBoxField")
    CheckBoxField fromDto(com.lombardinternational.casedefinition.v2.adapter.api.web.dto.CheckBoxField checkBoxField);

    @Named("checkBoxFieldDto")
    com.lombardinternational.casedefinition.v2.adapter.api.web.dto.CheckBoxField toDto(CheckBoxField checkBoxField);
}
