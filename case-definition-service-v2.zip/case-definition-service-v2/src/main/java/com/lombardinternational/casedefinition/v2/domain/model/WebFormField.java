package com.lombardinternational.casedefinition.v2.domain.model;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class WebFormField {
    private String fieldId;
    private String value;
    private String selectedValue;
    private String textValue;
    private Map<String, Object> attributes = new LinkedHashMap<>();

    public Optional<String> effectiveValue() {
        return Optional.ofNullable(selectedValue)
                .or(() -> Optional.ofNullable(value))
                .or(() -> Optional.ofNullable(textValue))
                .or(() -> attributes.values().stream().filter(Objects::nonNull).map(Object::toString).findFirst());
    }

    @JsonAnySetter
    public void setAttribute(String name, Object value) {
        attributes.put(name, value);
    }

    @JsonAnyGetter
    public Map<String, Object> getAttributes() {
        return attributes;
    }
}
