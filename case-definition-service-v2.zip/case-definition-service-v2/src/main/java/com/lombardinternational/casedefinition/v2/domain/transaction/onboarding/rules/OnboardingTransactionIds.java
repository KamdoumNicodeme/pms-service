package com.lombardinternational.casedefinition.v2.domain.transaction.onboarding.rules;

public final class OnboardingTransactionIds {
    public static final String WEB_FORM_ID = "ONBOARDING";
    public static final String WORKFLOW = "DIGITAL_ONBOARDING";
    public static final String CHECKLIST_SCREEN_ID = "NEW_BUSINESS_CHECKLIST";

    private OnboardingTransactionIds() {
    }
}
