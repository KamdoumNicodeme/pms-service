package com.lombardinternational.casedefinition.v2.domain.service;

import com.lombardinternational.casedefinition.v2.domain.api.BusinessTransactionService;
import com.lombardinternational.casedefinition.v2.domain.api.PolicyService;
import com.lombardinternational.casedefinition.v2.domain.api.ScreenBusinessService;
import com.lombardinternational.casedefinition.v2.domain.model.BusinessTransaction;
import com.lombardinternational.casedefinition.v2.domain.model.CaseDeal;
import com.lombardinternational.casedefinition.v2.domain.model.CurrencyExchangeRate;
import com.lombardinternational.casedefinition.v2.domain.model.Policy;
import com.lombardinternational.casedefinition.v2.domain.model.ScreenDescription;
import com.lombardinternational.casedefinition.v2.domain.model.WebForm;
import com.lombardinternational.casedefinition.v2.domain.spi.DealWebService;
import com.lombardinternational.casedefinition.v2.domain.spi.FxRateWebService;
import com.lombardinternational.casedefinition.v2.domain.spi.RulesWebService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class ScreenBusinessServiceImpl implements ScreenBusinessService {
    private static final List<String> CIM_CCB_CASE_TYPES = List.of("CIM", "CCB", "CIM_CCB");
    private static final String EUR = "EUR";
    private static final String CASE_ID = "CASE_ID";

    private final DealWebService dealWebService;
    private final PolicyService policyService;
    private final BusinessTransactionService businessTransactionService;
    private final RulesWebService rulesWebService;
    private final FxRateWebService fxRateWebService;

    @Override
    public ScreenDescription computeScreenDescription(String policyNumber, String caseType, String businessTransactionNumber,
            WebForm webForm, ScreenDescription screenDescriptionToBuild) {
        Policy policy = null;
        BusinessTransaction businessTransaction = null;

        if (StringUtils.hasText(policyNumber) && !CIM_CCB_CASE_TYPES.contains(caseType)) {
            policy = policyService.buildPolicy(policyNumber);
            if (StringUtils.hasText(businessTransactionNumber)) {
                businessTransaction = businessTransactionService.buildBusinessTransaction(businessTransactionNumber, policy,
                        caseType, policyNumber);
            }
        }

        List<CurrencyExchangeRate> fxRates = fxRateWebService.getFxRate(EUR, null).stream()
                .filter(rate -> EUR.equals(rate.getBaseIsoCurrencyCode()))
                .toList();

        return rulesWebService.computeScreenDescription(policy, businessTransaction, webForm, screenDescriptionToBuild,
                webForm == null ? null : getCaseDeals(webForm), fxRates);
    }

    @Override
    public ScreenDescription computeTaskScreen(String caseType, WebForm webForm, ScreenDescription screenCheckList,
            ScreenDescription screenToFill) {
        WebForm evaluatedWebForm = CIM_CCB_CASE_TYPES.contains(caseType) ? null : webForm;
        return rulesWebService.computeTaskScreen(evaluatedWebForm, screenCheckList, screenToFill);
    }

    private Map<String, CaseDeal> getCaseDeals(WebForm webForm) {
        return webForm.findFieldValue(CASE_ID)
                .filter(StringUtils::hasText)
                .map(dealWebService::getCaseDeals)
                .stream()
                .flatMap(List::stream)
                .filter(deal -> StringUtils.hasText(deal.getCaseDealId()))
                .collect(Collectors.toMap(CaseDeal::getCaseDealId, Function.identity(), (left, right) -> left));
    }
}
