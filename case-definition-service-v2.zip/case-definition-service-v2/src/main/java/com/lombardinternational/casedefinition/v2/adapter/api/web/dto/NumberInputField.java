package com.lombardinternational.casedefinition.v2.adapter.api.web.dto;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder
@NoArgsConstructor
@EqualsAndHashCode(callSuper = true)
public class NumberInputField extends Field {
    private Integer min;
    private Integer max;
    private Integer decimals;
    private Integer size;
}
