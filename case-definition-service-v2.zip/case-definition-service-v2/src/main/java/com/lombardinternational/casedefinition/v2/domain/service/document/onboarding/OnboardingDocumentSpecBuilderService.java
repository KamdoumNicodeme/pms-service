package com.lombardinternational.casedefinition.v2.domain.service.document.onboarding;

import com.lombardinternational.casedefinition.v2.domain.model.CaseDocumentDefinition;
import com.lombardinternational.casedefinition.v2.domain.model.ScreenDescription;
import com.lombardinternational.casedefinition.v2.domain.model.WebForm;
import com.lombardinternational.casedefinition.v2.domain.rules.onboarding.spec.DocumentSpec;
import com.lombardinternational.casedefinition.v2.domain.service.ConditionEvaluator;
import com.lombardinternational.casedefinition.v2.domain.service.document.AbstractDocumentBuilderService;
import com.lombardinternational.casedefinition.v2.domain.service.document.onboarding.definition.OnboardingDocumentDefinitionProvider;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.Comparator;
import java.util.List;

@Service
@RequiredArgsConstructor
public class OnboardingDocumentSpecBuilderService extends AbstractDocumentBuilderService {
    private final ConditionEvaluator conditionEvaluator;
    private final OnboardingDocumentDefinitionProvider documentDefinitionProvider;
    private DocumentSpec currentSpec;

    @Override
    public void buildDocument(WebForm webForm, ScreenDescription screenDescription, String policyNumber, String transactionNumber,
            List<CaseDocumentDefinition> documents) {
        documentDefinitionProvider.documents().stream()
                .filter(spec -> conditionEvaluator.matches(spec.conditions(), webForm, screenDescription))
                .sorted(Comparator.comparingInt(DocumentSpec::order))
                .forEach(spec -> {
                    currentSpec = spec;
                    addDocumentDefinition(resolveRelatedTo(spec.relatedTo(), policyNumber), resolveRelatedTo(spec.relatedToPolicy(), policyNumber),
                            blankToNull(spec.i18nRelatedToParam()), blankToNull(spec.relatedToThirdParty()), documents);
                });
    }

    @Override
    protected String getDocumentType() { return currentSpec.documentType(); }
    @Override
    protected String getCmsDocumentType() { return currentSpec.cmsDocumentType(); }
    @Override
    protected boolean getDocumentRequired() { return toBoolean(currentSpec.requiredExpression(), true); }
    @Override
    protected boolean getDocumentVisibleOnConnect() { return toBoolean(currentSpec.visibleExpression(), true); }
    @Override
    protected String getDescription() { return currentSpec.description(); }
    @Override
    protected String getI18NDescription() { return currentSpec.i18nDescription(); }
    @Override
    protected String getI18NDocumentRelatedTo() { return blankToNull(currentSpec.i18nRelatedTo()); }
    @Override
    protected boolean getNeverDisplayExternally() { return currentSpec.neverDisplayExternally(); }

    private boolean toBoolean(String expression, boolean defaultValue) {
        if (expression == null || expression.isBlank()) {
            return defaultValue;
        }
        if ("true".equalsIgnoreCase(expression) || "false".equalsIgnoreCase(expression)) {
            return Boolean.parseBoolean(expression);
        }
        return defaultValue;
    }

    private String resolveRelatedTo(String value, String policyNumber) {
        if (value == null || value.isBlank() || "null".equals(value)) {
            return null;
        }
        if ("relatedTo".equals(value) || "relatedToPolicy".equals(value)) {
            return policyNumber;
        }
        return value;
    }

    private String blankToNull(String value) {
        return value == null || value.isBlank() || "null".equals(value) ? null : value;
    }
}
