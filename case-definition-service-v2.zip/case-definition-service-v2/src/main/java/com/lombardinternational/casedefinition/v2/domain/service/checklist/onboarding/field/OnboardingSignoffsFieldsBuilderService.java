package com.lombardinternational.casedefinition.v2.domain.service.checklist.onboarding.field;

import com.lombardinternational.casedefinition.v2.domain.model.Group;
import com.lombardinternational.casedefinition.v2.domain.model.ScreenDescription;
import com.lombardinternational.casedefinition.v2.domain.model.WebForm;
import com.lombardinternational.casedefinition.v2.domain.service.checklist.FieldBuilderService;
import org.springframework.stereotype.Service;

import java.util.Map;

@Service
public class OnboardingSignoffsFieldsBuilderService extends OnboardingChecklistFieldsBuilderSupport implements FieldBuilderService {
    @Override
    public void buildField(WebForm webForm, ScreenDescription screenDescription, Group group) {
        var previousValues = previousValues(screenDescription);
        resetFields(group);
        buildTransactionFeedback(group, previousValues, webForm);
        sortFields(group);
    }

    private void buildTransactionFeedback(Group group, Map<String, String> previousValues, WebForm webForm) {
        buildField(group, new FieldRule("TRANSACTION_FEEDBACK", FieldKind.SELECT, 1, "Transaction feedback", true, false,
                "ACCEPTED\u00acAccepted;REJECTED\u00acRejected;REJECTED_AML\u00acRejected AML", null, false, null, false), previousValues, webForm);
    }

}
