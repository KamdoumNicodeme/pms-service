package com.lombardinternational.casedefinition.v2.domain.api;

import com.lombardinternational.casedefinition.v2.domain.model.PolicyRole;

import java.util.List;

public interface PolicyRoleService {
    Boolean policyRoleAreDifferent(List<? extends PolicyRole> policyRolesA, List<? extends PolicyRole> policyRolesB);
}
