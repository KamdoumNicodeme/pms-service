package com.lombardinternational.casedefinition.v2.adapter.api.web.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class WebFormGroup {
    private String fieldsetId;
    private String groupId;
    private String title;
    private String i18NTitleKey;
    private String type;
    @Builder.Default
    private List<WebFormField> fields = new ArrayList<>();
    @Builder.Default
    private List<BigDecimalWebFormField> bigDecimalFields = new ArrayList<>();
    @Builder.Default
    private List<BooleanWebFormField> booleanFields = new ArrayList<>();
    @Builder.Default
    private List<TextWebFormField> textFields = new ArrayList<>();
    @Builder.Default
    private List<CalendarWebFormField> calendarFields = new ArrayList<>();
    @Builder.Default
    private List<WebFormGroup> groups = new ArrayList<>();
}
