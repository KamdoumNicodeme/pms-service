package com.lombardinternational.casedefinition.v2.adapter.api.web.mapper;

import com.lombardinternational.casedefinition.v2.domain.model.TextAreaField;
import org.mapstruct.Mapper;

import java.util.List;

@Mapper(componentModel = "spring")
public interface TextAreaFieldMapper {
    List<TextAreaField> textAreaFieldFromDTO(List<com.lombardinternational.casedefinition.v2.adapter.api.web.dto.TextAreaField> dtos);
}
