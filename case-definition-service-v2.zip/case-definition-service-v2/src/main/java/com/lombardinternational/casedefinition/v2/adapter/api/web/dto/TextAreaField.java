package com.lombardinternational.casedefinition.v2.adapter.api.web.dto;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder
@NoArgsConstructor
@EqualsAndHashCode(callSuper = true)
public class TextAreaField extends Field {
    private Integer rows;
    private Integer cols;
    private Integer minChars;
    private Integer maxChars;
}
