package com.lombardinternational.casedefinition.v2.mapper;

import com.lombardinternational.casedefinition.v2.domain.model.Amount;
import com.lombardinternational.clients.classapp.model.BusinessTransactionDetails;
import com.lombardinternational.clients.classapp.model.ExternalIdRef;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring")
public interface AmountMapper {
    @Mapping(target = "isoCurrencyCode", source = "currency")
    Amount map(com.lombardinternational.clients.classapp.model.Amount amount);

    @Mapping(target = "isoCurrencyCode", source = "policyCurrency.isoCode")
    @Mapping(target = "quantity", source = "grossAmount")
    Amount mapFromBusinessTransaction(BusinessTransactionDetails businessTransaction);

    default String map(ExternalIdRef value) {
        return value == null ? null : value.getIsoCode();
    }
}
