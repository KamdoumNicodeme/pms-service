package com.lombardinternational.casedefinition.v2.domain.service.tasklist;

import com.lombardinternational.casedefinition.v2.domain.model.ScreenDescription;
import com.lombardinternational.casedefinition.v2.domain.model.TaskDefinition;
import com.lombardinternational.casedefinition.v2.domain.model.WebForm;

import java.util.List;

public interface TaskListBuilderService {
    List<TaskDefinition> buildTaskList(WebForm webForm, ScreenDescription screenDescription, String policyNumber);
}
