package com.lombardinternational.casedefinition.v2.domain.model;

import lombok.Data;

@Data
public class Fund {
    private String fundCode;
    private String fundName;
    private String fundNumber;
    private String fundSubClass;
    private boolean ilfFund;
}
