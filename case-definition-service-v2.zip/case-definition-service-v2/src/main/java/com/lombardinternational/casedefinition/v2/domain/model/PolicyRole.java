package com.lombardinternational.casedefinition.v2.domain.model;

import lombok.Data;

import java.util.ArrayList;
import java.util.List;

@Data
public class PolicyRole {
    private String externalId;
    private String roleType;
    private String roleId;
    private String taxIsoCountryCode;
    private List<AbstractPerson> thirdParties = new ArrayList<>();
    private List<MoralPerson> moralPersons = new ArrayList<>();
    private List<PhysicalPerson> physicalPersons = new ArrayList<>();
}
