package com.lombardinternational.casedefinition.v2.domain.model;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
public class Beneficiary extends PolicyRole {
    private Boolean irrevocableFlag = Boolean.FALSE;
}
