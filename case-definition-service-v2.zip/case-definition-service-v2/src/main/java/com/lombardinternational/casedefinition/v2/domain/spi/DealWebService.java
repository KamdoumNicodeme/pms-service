package com.lombardinternational.casedefinition.v2.domain.spi;

import com.lombardinternational.casedefinition.v2.domain.model.CaseDeal;

import java.util.List;

public interface DealWebService {
    List<CaseDeal> getCaseDeals(String caseDealId);
}
