package com.lombardinternational.casedefinition.v2.domain.service.checklist.onboarding.field;

import com.lombardinternational.casedefinition.v2.domain.model.Group;
import com.lombardinternational.casedefinition.v2.domain.model.ScreenDescription;
import com.lombardinternational.casedefinition.v2.domain.model.WebForm;
import com.lombardinternational.casedefinition.v2.domain.service.checklist.FieldBuilderService;
import org.springframework.stereotype.Service;

import java.util.Map;

@Service
public class OnboardingIntermediationFieldsBuilderService extends OnboardingChecklistFieldsBuilderSupport implements FieldBuilderService {
    @Override
    public void buildField(WebForm webForm, ScreenDescription screenDescription, Group group) {
        var previousValues = previousValues(screenDescription);
        resetFields(group);
        buildAppFormSigner(group, previousValues, webForm);
        buildPartnerCode(group, previousValues, webForm);
        buildPartnerName(group, previousValues, webForm);
        buildPartnerType(group, previousValues, webForm);
        buildIsPhRepresentative(group, previousValues, webForm);
        buildReferrerAuto(group, previousValues, webForm);
        buildPartnerStatus(group, previousValues, webForm);
        buildAnalysisOfNeeds(group, previousValues, webForm);
        buildNbIntermediatedDs(group, previousValues, webForm);
        buildDsConsentReceived(group, previousValues, webForm);
        buildVideoReceived(group, previousValues, webForm);
        buildClientIdentifiable(group, previousValues, webForm);
        buildHashCheckPerformed(group, previousValues, webForm);
        buildPassportCheckPerformed(group, previousValues, webForm);
        buildRequestDsProcedure(group, previousValues, webForm);
        buildVulnerableIndiciaDetected(group, previousValues, webForm);
        sortFields(group);
    }

    private void buildAppFormSigner(Group group, Map<String, String> previousValues, WebForm webForm) {
        buildField(group, new FieldRule("APP_FORM_SIGNER", FieldKind.SELECT, 1, "Application form signer", true, true,
                "BROKER\u00acBroker;ILA\u00acInternal Lombard Agent;MC\u00acMarketing Consultant", null, false, null, false), previousValues, webForm);
    }

    private void buildPartnerCode(Group group, Map<String, String> previousValues, WebForm webForm) {
        buildField(group, new FieldRule("PARTNER_CODE", FieldKind.TEXT, 2, "Introducing partner code", false, true,
                "#forcedValue", null, false, "From Connect", false), previousValues, webForm);
    }

    private void buildPartnerName(Group group, Map<String, String> previousValues, WebForm webForm) {
        buildField(group, new FieldRule("PARTNER_NAME", FieldKind.TEXT, 3, "Introducing partner name", false, true,
                "#forcedValue", null, false, "From Connect", false), previousValues, webForm);
    }

    private void buildPartnerType(Group group, Map<String, String> previousValues, WebForm webForm) {
        buildField(group, new FieldRule("PARTNER_TYPE", FieldKind.SELECT, 4, "Partner type", false, true,
                "#forcedValue", null, false, "From CLASS", false), previousValues, webForm);
    }

    private void buildIsPhRepresentative(Group group, Map<String, String> previousValues, WebForm webForm) {
        buildField(group, new FieldRule("IS_PH_REPRESENTATIVE", FieldKind.SELECT, 5, "Is the PH/EBO a representative (Director/ Shareholder/ Sales Person) of the intermediary who intermediated the policy ?", false, true,
                "#forcedValue", null, false, "Calculated based on Overall case risk", false), previousValues, webForm);
    }

    private void buildReferrerAuto(Group group, Map<String, String> previousValues, WebForm webForm) {
        buildField(group, new FieldRule("REFERRER_AUTO", FieldKind.SELECT, 6, "Referrer fully automated", true, true,
                "YES\u00acYes;NO\u00acNo", "#PARTNER_TYPE# == \"REFERRER\"", false, null, false), previousValues, webForm);
    }

    private void buildPartnerStatus(Group group, Map<String, String> previousValues, WebForm webForm) {
        buildField(group, new FieldRule("PARTNER_STATUS", FieldKind.SELECT, 7, "Is the partner status \"Active\"?", false, false,
                "YES\u00acYes;NO\u00acNo", null, false, "From Connect", false), previousValues, webForm);
    }

    private void buildAnalysisOfNeeds(Group group, Map<String, String> previousValues, WebForm webForm) {
        buildField(group, new FieldRule("ANALYSIS_OF_NEEDS", FieldKind.SELECT, 8, "Analysis of the Demands and needs/ Fact Find received?", true, true,
                "YES\u00acYes;NO\u00acNo", "#PARTNER_TYPE# == \"AGENT_EMP\" || #PARTNER_TYPE# == \"AGENT_IND\" || #PARTNER_TYPE# == \"AGENT_EXT\"", false, null, false), previousValues, webForm);
    }

    private void buildNbIntermediatedDs(Group group, Map<String, String> previousValues, WebForm webForm) {
        buildField(group, new FieldRule("NB_INTERMEDIATED_DS", FieldKind.SELECT, 9, "Has the New Business been intermediated using the Distance Selling process?", false, true,
                "#forcedValue", null, false, "From CLASS", false), previousValues, webForm);
    }

    private void buildDsConsentReceived(Group group, Map<String, String> previousValues, WebForm webForm) {
        buildField(group, new FieldRule("DS_CONSENT_RECEIVED", FieldKind.SELECT, 10, "Has the client consent for Distance Selling been received?", true, true,
                "YES\u00acYes;NO\u00acNo", "#NB_INTERMEDIATED_DS# == \"YES\" && (#PARTNER_TYPE# == \"AGENT_EMP\" || #PARTNER_TYPE# == \"AGENT_IND\")", false, null, false), previousValues, webForm);
    }

    private void buildVideoReceived(Group group, Map<String, String> previousValues, WebForm webForm) {
        buildField(group, new FieldRule("VIDEO_RECEIVED", FieldKind.SELECT, 11, "Has the video been received?", true, true,
                "YES\u00acYes;NO\u00acNo", "#NB_INTERMEDIATED_DS# == \"YES\" && (#PARTNER_TYPE# == \"AGENT_EMP\" || #PARTNER_TYPE# == \"AGENT_IND\")", false, null, false), previousValues, webForm);
    }

    private void buildClientIdentifiable(Group group, Map<String, String> previousValues, WebForm webForm) {
        buildField(group, new FieldRule("CLIENT_IDENTIFIABLE", FieldKind.SELECT, 12, "Client could be identified on the video?", true, true,
                "YES\u00acYes;NO\u00acNo", "#NB_INTERMEDIATED_DS# == \"YES\" && (#PARTNER_TYPE# == \"AGENT_EMP\" || #PARTNER_TYPE# == \"AGENT_IND\")", false, null, false), previousValues, webForm);
    }

    private void buildHashCheckPerformed(Group group, Map<String, String> previousValues, WebForm webForm) {
        buildField(group, new FieldRule("HASH_CHECK_PERFORMED", FieldKind.SELECT, 13, "Hash tool checks performed", true, true,
                "YES\u00acYes;NO\u00acNo", "#NB_INTERMEDIATED_DS# == \"YES\" && (#PARTNER_TYPE# == \"AGENT_EMP\" || #PARTNER_TYPE# == \"AGENT_IND\")", false, null, false), previousValues, webForm);
    }

    private void buildPassportCheckPerformed(Group group, Map<String, String> previousValues, WebForm webForm) {
        buildField(group, new FieldRule("PASSPORT_CHECK_PERFORMED", FieldKind.SELECT, 14, "Have the additional checks on passport been performed?", true, true,
                "YES\u00acYes;NO\u00acNo", "#NB_INTERMEDIATED_DS# == \"YES\" && (#PARTNER_TYPE# == \"AGENT_EMP\" || #PARTNER_TYPE# == \"AGENT_IND\")", false, null, false), previousValues, webForm);
    }

    private void buildRequestDsProcedure(Group group, Map<String, String> previousValues, WebForm webForm) {
        buildField(group, new FieldRule("REQUEST_DS_PROCEDURE", FieldKind.SELECT, 15, "PCS to request the distance selling procedure from the broker?", false, false,
                "#forcedValue", "#forcedDisplayIf", false, "From CLASS", false), previousValues, webForm);
    }

    private void buildVulnerableIndiciaDetected(Group group, Map<String, String> previousValues, WebForm webForm) {
        buildField(group, new FieldRule("VULNERABLE_INDICIA_DETECTED", FieldKind.SELECT, 16, "Vulnerable client indicia detected", true, true,
                "YES\u00acYes;NO\u00acNo", null, false, null, false), previousValues, webForm);
    }

}
