package com.lombardinternational.casedefinition.v2.domain.service.tasklist.onboarding;

import com.lombardinternational.casedefinition.v2.domain.model.ScreenDescription;
import com.lombardinternational.casedefinition.v2.domain.model.TaskDefinition;
import com.lombardinternational.casedefinition.v2.domain.model.WebForm;
import com.lombardinternational.casedefinition.v2.domain.rules.onboarding.spec.TaskSpec;
import com.lombardinternational.casedefinition.v2.domain.service.ConditionEvaluator;
import com.lombardinternational.casedefinition.v2.domain.service.DurationExpressionEvaluator;
import com.lombardinternational.casedefinition.v2.domain.service.tasklist.AbstractTaskBuilderService;
import com.lombardinternational.casedefinition.v2.domain.service.tasklist.onboarding.definition.OnboardingTaskDefinitionProvider;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class OnboardingTaskSpecBuilderService extends AbstractTaskBuilderService {
    private final ConditionEvaluator conditionEvaluator;
    private final OnboardingTaskDefinitionProvider taskDefinitionProvider;
    private TaskSpec currentSpec;

    @Override
    public void buildTask(WebForm webForm, ScreenDescription screenDescription, List<TaskDefinition> taskList) {
        for (TaskSpec spec : taskDefinitionProvider.tasks()) {
            if (conditionEvaluator.matches(spec.conditions(), webForm, screenDescription)) {
                currentSpec = spec;
                buildTaskDefinition(taskList);
            }
        }
    }

    @Override
    protected String getTaskName() { return currentSpec.mainTaskName(); }
    @Override
    protected int getRulePriority() { return currentSpec.order(); }
    @Override
    protected boolean getMandatory() { return currentSpec.mandatory(); }
    @Override
    protected boolean getSuggested() { return currentSpec.suggested(); }
    @Override
    protected boolean getReleasableFromSubTask() { return currentSpec.releasableFromSubTask(); }
    @Override
    protected Optional<String> getDecisionReason() {
        return Optional.ofNullable(currentSpec.reason()).filter(reason -> !reason.isBlank()).filter(reason -> !"#forcedValue".equals(reason));
    }
    @Override
    protected String getTaskDynamicScreenId() { return currentSpec.dynamicScreenId(); }
    @Override
    protected int getMainTaskExpectedDurationSeconds() { return DurationExpressionEvaluator.evaluate(currentSpec.mainTaskExpectedDuration()); }
    @Override
    protected int getSignoffExpectedDurationSeconds() { return DurationExpressionEvaluator.evaluate(currentSpec.signoffTaskExpectedDuration()); }
}
