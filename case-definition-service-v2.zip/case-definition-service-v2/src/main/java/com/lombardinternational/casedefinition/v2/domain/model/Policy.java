package com.lombardinternational.casedefinition.v2.domain.model;

import lombok.Data;

import java.util.ArrayList;
import java.util.List;

@Data
public class Policy {
    private String number;
    private String isoCurrencyCode = "EUR";
    private String businessOrigin;
    private String countryOfLawCode;
    private boolean pledged;
    private Boolean heldILF;
    private Boolean inForceforMoreThanOneYear;
    private Boolean brokerChangeWithinLast3Months;
    private Amount navInPolicyCurrency;
    private Amount navInEurCurrency;
    private Amount surrenderLiquidValue;
    private Boolean holderAndEBODifferent;
    private Boolean holderAndLifeAssuredDifferent;
    private Boolean beneficiaryAndLifeAssuredDifferent;
    private List<Block> blocks = new ArrayList<>();
    private List<Holder> holders = new ArrayList<>();
    private List<CessionHolder> cessionHolders = new ArrayList<>();
    private List<LifeAssured> lifeAssureds = new ArrayList<>();
    private List<EconomicBeneficiary> economicBeneficiaries = new ArrayList<>();
    private List<Trustee> trustees = new ArrayList<>();
    private List<Trust> trusts = new ArrayList<>();
    private List<Proxy> proxies = new ArrayList<>();
    private List<Settlor> settlors = new ArrayList<>();
    private List<Beneficiary> beneficiaries = new ArrayList<>();
    private List<Beneficiary> irrevocableBeneficiaries = new ArrayList<>();
    private List<MoralPerson> moralPersons = new ArrayList<>();
    private List<PhysicalPerson> physicalPersons = new ArrayList<>();
    private List<PolicyLink> policyLinks = new ArrayList<>();
}
