package com.lombardinternational.casedefinition.v2.adapter.spi.ruleengine;

import com.lombardinternational.casedefinition.v2.domain.api.RulesEngineService;
import com.lombardinternational.casedefinition.v2.domain.model.*;
import com.lombardinternational.casedefinition.v2.domain.spi.RulesWebService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
@RequiredArgsConstructor
public class RulesWebServiceImpl implements RulesWebService {
    private final RulesEngineService rulesEngineService;

    @Override
    public ScreenDescription computeScreenDescription(Policy policy, BusinessTransaction businessTransaction, WebForm webForm,
            ScreenDescription screenDescriptionToBuild, Map<String, CaseDeal> caseDeals, List<CurrencyExchangeRate> fxRates) {
        return rulesEngineService.buildCheckList(webForm, screenDescriptionToBuild, policyNumber(policy),
                transactionNumber(businessTransaction));
    }

    @Override
    public List<TaskDefinition> computeTaskDefinition(Policy policy, WebForm webForm, ScreenDescription screenCheckList) {
        return rulesEngineService.buildTaskList(webForm, screenCheckList, policyNumber(policy));
    }

    @Override
    public List<CaseDocumentDefinition> computeCaseDocumentsDefinition(Policy policy, WebForm webForm,
            ScreenDescription screenCheckList) {
        return rulesEngineService.buildDocumentsDefinition(webForm, screenCheckList, policyNumber(policy), null);
    }

    @Override
    public ScreenDescription computeTaskScreen(WebForm webForm, ScreenDescription screenCheckList, ScreenDescription screenToFill) {
        return rulesEngineService.buildTaskScreen(webForm, screenCheckList, screenToFill);
    }

    @Override
    public List<CaseControlDefinition> computeCaseControlDefinitions(WebForm webForm, ScreenDescription screenCheckList) {
        return rulesEngineService.buildControlDefinition(webForm, screenCheckList);
    }

    @Override
    public SignatoryResult computeSignatories(Policy policy, WebForm webForm) {
        return rulesEngineService.buildSignatories(webForm, policyNumber(policy));
    }

    private String policyNumber(Policy policy) {
        return policy == null ? null : policy.getNumber();
    }

    private String transactionNumber(BusinessTransaction businessTransaction) {
        return businessTransaction == null ? null : businessTransaction.getIdentifier();
    }
}
