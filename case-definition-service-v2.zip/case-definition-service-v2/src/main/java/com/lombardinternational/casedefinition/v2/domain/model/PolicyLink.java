package com.lombardinternational.casedefinition.v2.domain.model;

import lombok.Data;

import java.util.ArrayList;
import java.util.List;

@Data
public class PolicyLink {
    private List<MoralPerson> moralPersons = new ArrayList<>();
    private List<PhysicalPerson> physicalPersons = new ArrayList<>();
}
