package com.lombardinternational.casedefinition.v2.adapter.api.web.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class FormInitiator {
    private Long userId;
    private String userLogin;
    private String displayedName;
    private Long companyId;
    private String companyName;
    private String initiatorRole;
    private String partnerType;
}
