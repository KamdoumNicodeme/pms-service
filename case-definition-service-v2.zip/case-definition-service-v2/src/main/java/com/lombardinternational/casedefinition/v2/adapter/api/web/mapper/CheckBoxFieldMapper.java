package com.lombardinternational.casedefinition.v2.adapter.api.web.mapper;

import com.lombardinternational.casedefinition.v2.domain.model.CheckBoxField;
import org.mapstruct.Mapper;

import java.util.List;

@Mapper(componentModel = "spring")
public interface CheckBoxFieldMapper {
    List<CheckBoxField> checkBoxFieldFromDTO(List<com.lombardinternational.casedefinition.v2.adapter.api.web.dto.CheckBoxField> dtos);
}
