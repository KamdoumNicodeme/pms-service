package com.lombardinternational.casedefinition.v2.adapter.api.web.dto;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder
@NoArgsConstructor
@EqualsAndHashCode(callSuper = true)
public class TextInputField extends Field {
    private Integer size;
    private Integer minChars;
    private Integer maxChars;
}
