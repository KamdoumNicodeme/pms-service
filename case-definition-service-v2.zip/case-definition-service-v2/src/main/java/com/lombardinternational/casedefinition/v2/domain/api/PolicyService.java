package com.lombardinternational.casedefinition.v2.domain.api;

import com.lombardinternational.casedefinition.v2.domain.model.Policy;

public interface PolicyService {
    Policy buildPolicy(String policyNumber);
}
