package com.lombardinternational.casedefinition.v2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;

@SpringBootApplication
@EnableFeignClients(basePackages = {
        "com.lombardinternational.clients",
        "com.lombardinternational.casemanagement.clients"
})
public class CaseDefinitionServiceV2Application {

    public static void main(String[] args) {
        SpringApplication.run(CaseDefinitionServiceV2Application.class, args);
    }
}
