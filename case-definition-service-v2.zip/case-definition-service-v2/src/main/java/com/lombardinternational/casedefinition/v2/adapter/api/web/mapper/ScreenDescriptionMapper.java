package com.lombardinternational.casedefinition.v2.adapter.api.web.mapper;

import com.lombardinternational.casedefinition.v2.domain.model.ScreenDescription;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring", uses = {TabMapper.class})
public interface ScreenDescriptionMapper {
    ScreenDescription screenDescriptionFromDTO(com.lombardinternational.casedefinition.v2.adapter.api.web.dto.ScreenDescription screenDescriptionDTO);

    com.lombardinternational.casedefinition.v2.adapter.api.web.dto.ScreenDescription DTOFromScreenDescription(ScreenDescription screenDescription);
}
