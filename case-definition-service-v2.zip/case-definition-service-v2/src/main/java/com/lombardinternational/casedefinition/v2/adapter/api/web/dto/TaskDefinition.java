package com.lombardinternational.casedefinition.v2.adapter.api.web.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

import java.util.List;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class TaskDefinition {
    private int taskId;
    private boolean suggested;
    private boolean mandatory;
    private String mainTaskName;
    private String mainTaskDynamicScreenId;
    private int mainTaskExpectedDurationSeconds;
    private int signoffTaskExpectedDurationSeconds;
    private int taskOrder;
    private int rulePriority;
    private boolean releasableFromSubTask;
    private boolean completeRequired = true;
    private List<String> decisionReasons;
}
