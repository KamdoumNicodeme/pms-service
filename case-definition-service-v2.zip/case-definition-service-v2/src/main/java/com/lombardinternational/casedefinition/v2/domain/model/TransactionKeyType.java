package com.lombardinternational.casedefinition.v2.domain.model;

public record TransactionKeyType(String screenId, String webFormId) {
}
