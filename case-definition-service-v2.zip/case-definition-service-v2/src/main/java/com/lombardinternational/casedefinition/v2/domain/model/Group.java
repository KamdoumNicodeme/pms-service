package com.lombardinternational.casedefinition.v2.domain.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Group {
    private static final AtomicInteger currentOrder = new AtomicInteger(1);

    private String groupId;
    private String title;
    private String i18NTitleKey;
    private int order;
    @Builder.Default
    private int columnsCount = 2;
    @Builder.Default
    private List<Field> fields = new ArrayList<>();
    private String displayIf;
    @Builder.Default
    private Boolean isActive = Boolean.FALSE;

    public static void resetGroupId() {
        currentOrder.set(1);
    }

    public void incrementOrder() {
        this.order = currentOrder.getAndIncrement();
    }
}
