package com.lombardinternational.casedefinition.v2.adapter.api.web.controller;

import com.lombardinternational.casedefinition.v2.adapter.api.web.dto.CaseControlRequest;
import com.lombardinternational.casedefinition.v2.adapter.api.web.dto.CaseDocumentRequest;
import com.lombardinternational.casedefinition.v2.adapter.api.web.dto.CaseSubTaskRequest;
import com.lombardinternational.casedefinition.v2.adapter.api.web.mapper.CaseControlDefinitionMapper;
import com.lombardinternational.casedefinition.v2.adapter.api.web.mapper.CaseDocumentDefinitionMapper;
import com.lombardinternational.casedefinition.v2.adapter.api.web.mapper.ScreenDescriptionMapper;
import com.lombardinternational.casedefinition.v2.adapter.api.web.mapper.TaskDefinitionMapper;
import com.lombardinternational.casedefinition.v2.adapter.api.web.mapper.WebFormMapper;
import com.lombardinternational.casedefinition.v2.domain.api.CaseBusinessService;
import com.lombardinternational.casedefinition.v2.domain.model.CaseControlDefinition;
import com.lombardinternational.casedefinition.v2.domain.model.CaseDocumentDefinition;
import com.lombardinternational.casedefinition.v2.domain.model.ScreenDescription;
import com.lombardinternational.casedefinition.v2.domain.model.TaskDefinition;
import com.lombardinternational.casedefinition.v2.domain.model.WebForm;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@Tag(name = "Cases", description = "Cases management")
@RestController
@RequestMapping("/api/cases")
@RequiredArgsConstructor
public class CaseController {
    private final CaseBusinessService caseBusinessService;
    private final WebFormMapper webFormMapper;
    private final ScreenDescriptionMapper screenDescriptionMapper;
    private final CaseDocumentDefinitionMapper caseDocumentDefinitionMapper;
    private final CaseControlDefinitionMapper caseControlDefinitionMapper;
    private final TaskDefinitionMapper taskDefinitionMapper;

    @PostMapping("/documents")
    @Operation(summary = "Generate document list based on a CaseDocumentRequest")
    public ResponseEntity<List<com.lombardinternational.casedefinition.v2.adapter.api.web.dto.CaseDocumentDefinition>> getCaseDocuments(
            @Valid @RequestBody CaseDocumentRequest request) {
        WebForm webForm = webFormMapper.webFormFromDTO(request.caseInitializationData());
        ScreenDescription screenDescription = screenDescriptionMapper.screenDescriptionFromDTO(request.checkListOverviewData());
        List<CaseDocumentDefinition> definitions = caseBusinessService.computeCaseDocumentsDefinition(request.policyNumber(),
                request.caseType(), webForm, screenDescription);
        return ResponseEntity.ok(caseDocumentDefinitionMapper.dtoFromCaseDocumentDefinition(definitions));
    }

    @PostMapping("/subTasks")
    @Operation(summary = "Generate subtask list based on a CaseSubTaskRequest")
    public ResponseEntity<List<com.lombardinternational.casedefinition.v2.adapter.api.web.dto.TaskDefinition>> getSubTasks(
            @Valid @RequestBody CaseSubTaskRequest request) {
        WebForm webForm = webFormMapper.webFormFromDTO(request.caseInitializationData());
        ScreenDescription screenDescription = screenDescriptionMapper.screenDescriptionFromDTO(request.checkListOverviewData());
        List<TaskDefinition> definitions = caseBusinessService.computeCaseSubTasks(request.policyNumber(), request.caseType(),
                webForm, screenDescription);
        return ResponseEntity.ok(taskDefinitionMapper.map(definitions));
    }

    @PostMapping("/controls")
    @Operation(summary = "Generate control list based on a CaseControlRequest")
    public ResponseEntity<List<com.lombardinternational.casedefinition.v2.adapter.api.web.dto.CaseControlDefinition>> getControls(
            @Valid @RequestBody CaseControlRequest request) {
        WebForm webForm = webFormMapper.webFormFromDTO(request.caseInitializationData());
        ScreenDescription screenDescription = screenDescriptionMapper.screenDescriptionFromDTO(request.checkListOverviewData());
        List<CaseControlDefinition> definitions = caseBusinessService.computeCaseControlDefinitions(request.caseType(),
                webForm, screenDescription);
        return ResponseEntity.ok(caseControlDefinitionMapper.dtoFromCaseControlDefinition(definitions));
    }
}
