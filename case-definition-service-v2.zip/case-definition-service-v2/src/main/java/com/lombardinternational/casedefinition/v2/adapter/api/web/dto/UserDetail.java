package com.lombardinternational.casedefinition.v2.adapter.api.web.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class UserDetail {
    private String userId;
    private String login;
    private String firstName;
    private String lastName;
    private String userRole;
    private String clientNumber;
    private Boolean authorizedSigntory;
    private String phoneNumber;
    private String email;
}
