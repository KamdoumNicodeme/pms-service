package com.lombardinternational.casedefinition.v2.adapter.spi.service.rest;

import com.lombardinternational.casedefinition.v2.domain.spi.PolicyWebService;
import com.lombardinternational.clients.classapp.client.PolicyServiceClient;
import com.lombardinternational.clients.classapp.model.PersistedBlock;
import com.lombardinternational.clients.classapp.model.Policy;
import com.lombardinternational.clients.classapp.model.PolicyValues;
import com.lombardinternational.clients.classapp.model.roles.AbstractPolicyRole;
import com.lombardinternational.clients.classapp.model.thirdparty.ThirdPartyLight;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.Collection;
import java.util.List;

@Service
@RequiredArgsConstructor
public class RestPolicyWebServiceImpl implements PolicyWebService {
    private final PolicyServiceClient policyClient;

    @Override
    public Policy getPolicy(String policyNumber) {
        return policyClient.getPolicyDetails(policyNumber);
    }

    @Override
    public PolicyValues getPolicyValues(String policyNumber) {
        return policyClient.getPolicyValues(policyNumber, false, false);
    }

    @Override
    public Collection<PersistedBlock> getBlocks(String policyNumber) {
        return policyClient.getBlocks(policyNumber);
    }

    @Override
    public List<AbstractPolicyRole> getPolicyRole(String policyNumber) {
        return policyClient.getPolicyRoles(policyNumber, null);
    }

    @Override
    public Collection<ThirdPartyLight> getPolicyLinks(String policyNumber) {
        return policyClient.getInternalRiskRecursiveLinks(policyNumber, null);
    }
}
