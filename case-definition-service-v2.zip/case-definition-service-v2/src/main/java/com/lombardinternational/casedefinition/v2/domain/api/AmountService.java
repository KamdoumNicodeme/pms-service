package com.lombardinternational.casedefinition.v2.domain.api;

import com.lombardinternational.casedefinition.v2.domain.model.Amount;
import com.lombardinternational.casedefinition.v2.domain.model.BusinessTransaction;

public interface AmountService {
    Amount convertAmount(Amount amount, String targetCurrency);

    Amount getSumPaymentAmountInTransaction(BusinessTransaction transaction, String targetCurrency);
}
