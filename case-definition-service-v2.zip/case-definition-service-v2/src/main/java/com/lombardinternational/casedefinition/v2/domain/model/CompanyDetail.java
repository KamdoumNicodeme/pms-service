package com.lombardinternational.casedefinition.v2.domain.model;

import lombok.Data;

@Data
public class CompanyDetail {
    private String companyId;
    private String companyName;
    private String loginPrefix;
    private String partnerType;
}
