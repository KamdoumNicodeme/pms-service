package com.lombardinternational.casedefinition.v2.domain.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CaseControlDefinition {
    private static final AtomicInteger currentOrder = new AtomicInteger(1);

    private int controlId;
    private String controlName;
    @Builder.Default
    private boolean controlVisibleOnConnect = false;
    private int controlOrder;
    private List<String> decisionReasons;
    private String controlType;

    public static void resetControlOrder() {
        currentOrder.set(1);
    }

    public void incrementOrder() {
        this.controlOrder = currentOrder.getAndIncrement();
    }
}
