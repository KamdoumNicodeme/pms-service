package com.lombardinternational.casedefinition.v2.domain.service.control.onboarding;

import com.lombardinternational.casedefinition.v2.domain.model.CaseControlDefinition;
import com.lombardinternational.casedefinition.v2.domain.model.ScreenDescription;
import com.lombardinternational.casedefinition.v2.domain.model.WebForm;
import com.lombardinternational.casedefinition.v2.domain.rules.onboarding.spec.ControlSpec;
import com.lombardinternational.casedefinition.v2.domain.service.ConditionEvaluator;
import com.lombardinternational.casedefinition.v2.domain.service.control.AbstractControlBuilderService;
import com.lombardinternational.casedefinition.v2.domain.service.control.onboarding.definition.OnboardingControlDefinitionProvider;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.Comparator;
import java.util.List;

@Service
@RequiredArgsConstructor
public class OnboardingControlSpecBuilderService extends AbstractControlBuilderService {
    private final ConditionEvaluator conditionEvaluator;
    private final OnboardingControlDefinitionProvider controlDefinitionProvider;
    private ControlSpec currentSpec;

    @Override
    public void buildControl(WebForm webForm, ScreenDescription screenDescription, List<CaseControlDefinition> controls) {
        controlDefinitionProvider.controls().stream()
                .filter(spec -> conditionEvaluator.matches(spec.conditions(), webForm, screenDescription))
                .sorted(Comparator.comparingInt(ControlSpec::order))
                .forEach(spec -> {
                    currentSpec = spec;
                    controls.add(buildControlDefinition());
                });
    }

    @Override
    protected String getControlName() { return currentSpec.controlName(); }
    @Override
    protected String getControlType() { return currentSpec.controlType(); }
    @Override
    protected boolean getControlVisibleOnConnect() { return currentSpec.visibleOnConnect(); }
}
