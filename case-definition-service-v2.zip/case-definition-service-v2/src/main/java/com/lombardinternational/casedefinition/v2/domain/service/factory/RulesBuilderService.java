package com.lombardinternational.casedefinition.v2.domain.service.factory;

import com.lombardinternational.casedefinition.v2.domain.model.*;

import java.util.List;

public interface RulesBuilderService {
    ScreenDescription buildCheckList(WebForm webForm, ScreenDescription screenDescription, String policyNumber, String transactionNumber);
    List<TaskDefinition> buildTaskList(WebForm webForm, ScreenDescription screenDescription, String policyNumber);
    ScreenDescription buildTaskScreen(WebForm webForm, ScreenDescription screenCheckList, ScreenDescription screenToFill);
    List<CaseDocumentDefinition> buildDocumentsDefinition(WebForm webForm, ScreenDescription screenDescription, String policyNumber, String transactionNumber);
    List<CaseControlDefinition> buildControlDefinition(WebForm webForm, ScreenDescription screenDescription);
    SignatoryResult buildSignatories(WebForm webForm, String policyNumber);
}
