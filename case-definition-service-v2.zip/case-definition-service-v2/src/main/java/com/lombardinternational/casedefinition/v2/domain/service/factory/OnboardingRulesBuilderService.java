package com.lombardinternational.casedefinition.v2.domain.service.factory;

import com.lombardinternational.casedefinition.v2.domain.model.*;
import com.lombardinternational.casedefinition.v2.domain.service.checklist.onboarding.OnboardingChecklistBuilderService;
import com.lombardinternational.casedefinition.v2.domain.service.control.onboarding.OnboardingControlDefinitionBuilderService;
import com.lombardinternational.casedefinition.v2.domain.service.document.onboarding.OnboardingDocumentsDefinitionBuilderService;
import com.lombardinternational.casedefinition.v2.domain.service.tasklist.onboarding.OnboardingTaskListBuilderService;
import com.lombardinternational.casedefinition.v2.domain.service.taskscreen.onboarding.OnboardingTaskScreenBuilderService;
import com.lombardinternational.casedefinition.v2.domain.transaction.onboarding.signatory.OnboardingSignatoryBuilderService;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@AllArgsConstructor
public class OnboardingRulesBuilderService implements RulesBuilderService {
    private final OnboardingChecklistBuilderService checklistBuilderService;
    private final OnboardingTaskListBuilderService taskListBuilderService;
    private final OnboardingTaskScreenBuilderService taskScreenBuilderService;
    private final OnboardingDocumentsDefinitionBuilderService documentsDefinitionBuilderService;
    private final OnboardingControlDefinitionBuilderService controlDefinitionBuilderService;
    private final OnboardingSignatoryBuilderService signatoryBuilderService;

    @Override
    public ScreenDescription buildCheckList(WebForm webForm, ScreenDescription screenDescription, String policyNumber, String transactionNumber) {
        return checklistBuilderService.buildChecklist(webForm, screenDescription, policyNumber, transactionNumber);
    }

    @Override
    public List<TaskDefinition> buildTaskList(WebForm webForm, ScreenDescription screenDescription, String policyNumber) {
        return taskListBuilderService.buildTaskList(webForm, screenDescription, policyNumber);
    }

    @Override
    public ScreenDescription buildTaskScreen(WebForm webForm, ScreenDescription screenCheckList, ScreenDescription screenToFill) {
        return taskScreenBuilderService.buildTaskScreen(webForm, screenCheckList, screenToFill);
    }

    @Override
    public List<CaseDocumentDefinition> buildDocumentsDefinition(WebForm webForm, ScreenDescription screenDescription, String policyNumber, String transactionNumber) {
        return documentsDefinitionBuilderService.buildDocumentsDefinition(webForm, screenDescription, policyNumber, transactionNumber);
    }

    @Override
    public List<CaseControlDefinition> buildControlDefinition(WebForm webForm, ScreenDescription screenDescription) {
        return controlDefinitionBuilderService.buildControlDefinition(webForm, screenDescription);
    }

    @Override
    public SignatoryResult buildSignatories(WebForm webForm, String policyNumber) {
        return signatoryBuilderService.buildSignatories(webForm, policyNumber);
    }
}
