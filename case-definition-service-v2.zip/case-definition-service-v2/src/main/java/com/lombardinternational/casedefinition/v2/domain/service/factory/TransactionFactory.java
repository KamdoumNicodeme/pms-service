package com.lombardinternational.casedefinition.v2.domain.service.factory;

import com.lombardinternational.casedefinition.v2.domain.model.TransactionKeyType;
import com.lombardinternational.casedefinition.v2.domain.transaction.onboarding.rules.OnboardingTransactionIds;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;

@Component
public class TransactionFactory {
    private final Map<TransactionKeyType, RulesBuilderService> services = new HashMap<>();

    public TransactionFactory(OnboardingRulesBuilderService onboardingRulesBuilderService) {
        services.put(new TransactionKeyType(OnboardingTransactionIds.CHECKLIST_SCREEN_ID, OnboardingTransactionIds.WEB_FORM_ID), onboardingRulesBuilderService);
        services.put(new TransactionKeyType(null, OnboardingTransactionIds.WEB_FORM_ID), onboardingRulesBuilderService);
    }

    public RulesBuilderService getService(TransactionKeyType key) {
        return services.get(key);
    }
}
