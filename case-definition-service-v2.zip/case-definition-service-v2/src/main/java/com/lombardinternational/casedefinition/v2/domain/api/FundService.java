package com.lombardinternational.casedefinition.v2.domain.api;

import com.lombardinternational.casedefinition.v2.domain.model.Fund;

import java.util.List;

public interface FundService {
    List<Fund> getFunds(String policyNumber);

    Boolean containILFFund(List<Fund> funds);
}
