package com.lombardinternational.casedefinition.v2.domain.model;

import lombok.Data;

@Data
public class Payment {
    private Amount paymentAmount;
}
