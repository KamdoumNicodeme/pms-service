package com.lombardinternational.casedefinition.v2.domain.api;

import com.lombardinternational.casedefinition.v2.domain.model.SignatoryResult;
import com.lombardinternational.casedefinition.v2.domain.model.WebForm;

public interface WebFormBusinessService {
    SignatoryResult computeSignatories(String caseType, String policyNumber, WebForm webForm);
}
