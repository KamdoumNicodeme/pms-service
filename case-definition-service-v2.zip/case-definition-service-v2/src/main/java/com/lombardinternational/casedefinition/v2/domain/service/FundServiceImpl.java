package com.lombardinternational.casedefinition.v2.domain.service;

import com.lombardinternational.casedefinition.v2.domain.api.FundService;
import com.lombardinternational.casedefinition.v2.domain.model.Fund;
import com.lombardinternational.casedefinition.v2.domain.spi.FundWebService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class FundServiceImpl implements FundService {
    private final FundWebService fundWebService;

    @Override
    public List<Fund> getFunds(String policyNumber) {
        return fundWebService.getFunds(policyNumber);
    }

    @Override
    public Boolean containILFFund(List<Fund> funds) {
        return funds != null && funds.stream().anyMatch(Fund::isIlfFund);
    }
}
