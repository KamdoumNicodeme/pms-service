package com.lombardinternational.casedefinition.v2.domain.service.document.onboarding;

import com.lombardinternational.casedefinition.v2.domain.model.CaseDocumentDefinition;
import com.lombardinternational.casedefinition.v2.domain.model.ScreenDescription;
import com.lombardinternational.casedefinition.v2.domain.model.WebForm;
import com.lombardinternational.casedefinition.v2.domain.service.document.DocumentsDefinitionBuilderService;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
@AllArgsConstructor
public class OnboardingDocumentsDefinitionBuilderService implements DocumentsDefinitionBuilderService {
    private final OnboardingDocumentSpecBuilderService documentSpecBuilderService;

    @Override
    public List<CaseDocumentDefinition> buildDocumentsDefinition(WebForm webForm, ScreenDescription screenDescription, String policyNumber, String transactionNumber) {
        CaseDocumentDefinition.resetDocumentOrder();
        final var documents = new ArrayList<CaseDocumentDefinition>();
        documentSpecBuilderService.buildDocument(webForm, screenDescription, policyNumber, transactionNumber, documents);
        return documents;
    }
}
