package com.lombardinternational.casedefinition.v2.adapter.api.web.dto;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.util.ArrayList;
import java.util.List;

@Data
@SuperBuilder
@NoArgsConstructor
@EqualsAndHashCode(callSuper = true)
public class SelectInputField extends Field {
    private Integer minWidthPct;
    private Integer minWidthPx;
    @lombok.Builder.Default
    private List<SelectInputFieldOption> options = new ArrayList<>();
}
