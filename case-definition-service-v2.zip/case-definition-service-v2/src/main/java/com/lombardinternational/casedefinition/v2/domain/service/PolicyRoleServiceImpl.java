package com.lombardinternational.casedefinition.v2.domain.service;

import com.lombardinternational.casedefinition.v2.domain.api.PolicyRoleService;
import com.lombardinternational.casedefinition.v2.domain.model.PolicyRole;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Objects;

@Service
public class PolicyRoleServiceImpl implements PolicyRoleService {
    @Override
    public Boolean policyRoleAreDifferent(List<? extends PolicyRole> policyRolesA, List<? extends PolicyRole> policyRolesB) {
        if (policyRolesA == null || policyRolesB == null || policyRolesA.size() != policyRolesB.size()) {
            return true;
        }
        return policyRolesA.stream()
                .map(PolicyRole::getExternalId)
                .anyMatch(externalId -> policyRolesB.stream().noneMatch(role -> Objects.equals(externalId, role.getExternalId())));
    }
}
