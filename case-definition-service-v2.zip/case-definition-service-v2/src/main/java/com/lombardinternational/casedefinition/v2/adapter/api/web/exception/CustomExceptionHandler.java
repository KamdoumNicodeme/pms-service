package com.lombardinternational.casedefinition.v2.adapter.api.web.exception;

import com.lombardinternational.casedefinition.v2.domain.service.UnsupportedTransactionException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class CustomExceptionHandler {
    @ExceptionHandler(UnsupportedTransactionException.class)
    public ResponseEntity<ErrorResource> unsupportedTransaction(UnsupportedTransactionException ex) {
        return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                .body(ErrorResource.builder().code("UNSUPPORTED_TRANSACTION").message(ex.getMessage()).build());
    }

    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<ErrorResource> invalidRequest(MethodArgumentNotValidException ex) {
        return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                .body(ErrorResource.builder().code("INVALID_REQUEST").message(ex.getMessage()).build());
    }
}
