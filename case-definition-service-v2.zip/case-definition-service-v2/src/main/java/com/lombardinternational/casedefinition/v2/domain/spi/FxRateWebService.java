package com.lombardinternational.casedefinition.v2.domain.spi;

import com.lombardinternational.casedefinition.v2.domain.model.CurrencyExchangeRate;

import java.util.List;

public interface FxRateWebService {
    List<CurrencyExchangeRate> getFxRate(String sourceCcy, String targetCcy);
}
