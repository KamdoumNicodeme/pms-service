package com.lombardinternational.casedefinition.v2.domain.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Tab {
    private String tabId;
    private String label;
    private String i18NLabelKey;
    private int order;
    private boolean triggersRecomputeScreen;
    private String type;
    @Builder.Default
    private List<Group> groups = new ArrayList<>();
    private String displayIf;
    @Builder.Default
    private Boolean isActive = Boolean.FALSE;
}
