package com.lombardinternational.casedefinition.v2.domain.model;

import lombok.Data;

@Data
public class UserDetail {
    private String userId;
    private String login;
    private String firstName;
    private String lastName;
    private String userRole;
    private String clientNumber;
    private Boolean authorizedSigntory;
    private String phoneNumber;
    private String email;
}
