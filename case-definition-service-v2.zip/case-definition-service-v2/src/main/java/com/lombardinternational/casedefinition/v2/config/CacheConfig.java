package com.lombardinternational.casedefinition.v2.config;

import com.lombardinternational.casedefinition.v2.adapter.spi.service.rest.RestFxRateWebServiceImpl;
import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.cache.concurrent.ConcurrentMapCacheManager;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableScheduling;

@Configuration
@EnableCaching
@EnableScheduling
public class CacheConfig {
    @Bean
    public CacheManager cacheManager() {
        return new ConcurrentMapCacheManager("case-definition", RestFxRateWebServiceImpl.FX_RATES_CACHE);
    }
}
