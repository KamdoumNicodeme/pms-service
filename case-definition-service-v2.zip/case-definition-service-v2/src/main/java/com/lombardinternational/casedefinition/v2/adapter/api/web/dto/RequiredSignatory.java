package com.lombardinternational.casedefinition.v2.adapter.api.web.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

import java.util.ArrayList;
import java.util.List;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class RequiredSignatory {
    private String thirdpartyId;
    private String externalId;
    private String type;
    private String name;
    private String firstName;
    private String lastName;
    private String email;
    private String phoneNumber;
    private String label;
    private String signerId;
    private List<String> allowedActions = new ArrayList<>();
    private String onBehalfOf;
}
