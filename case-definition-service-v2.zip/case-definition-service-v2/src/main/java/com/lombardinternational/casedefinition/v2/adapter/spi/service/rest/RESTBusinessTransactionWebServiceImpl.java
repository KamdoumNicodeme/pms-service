package com.lombardinternational.casedefinition.v2.adapter.spi.service.rest;

import com.lombardinternational.casedefinition.v2.mapper.BusinessTransactionMapper;
import com.lombardinternational.casedefinition.v2.domain.model.BusinessTransaction;
import com.lombardinternational.casedefinition.v2.domain.spi.BusinessTransactionWebService;
import com.lombardinternational.clients.classapp.client.BusinessTransactionClient;
import com.lombardinternational.clients.classapp.client.PolicyServiceClient;
import com.lombardinternational.clients.classapp.model.BusinessTransactionLight;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.Collection;
import java.util.List;

@Service
@RequiredArgsConstructor
public class RESTBusinessTransactionWebServiceImpl implements BusinessTransactionWebService {
    private final BusinessTransactionClient businessTransactionClient;
    private final PolicyServiceClient policyServiceClient;
    private final BusinessTransactionMapper businessTransactionMapper;

    @Override
    public BusinessTransaction getBusinessTransaction(String businessTransactionNumber) {
        if (!StringUtils.hasText(businessTransactionNumber)) {
            return null;
        }
        return businessTransactionMapper.buildBusinessTransaction(
                businessTransactionClient.getBusinessTransaction(businessTransactionNumber));
    }

    @Override
    public List<BusinessTransaction> getBusinessTransactions(String policyNumber) {
        if (!StringUtils.hasText(policyNumber)) {
            throw new IllegalArgumentException("policyNumber cannot be null or blank.");
        }
        Collection<BusinessTransactionLight> transactions = policyServiceClient.getBusinessTransactions(policyNumber);
        return businessTransactionMapper.mapToListFromLightList(transactions);
    }
}
