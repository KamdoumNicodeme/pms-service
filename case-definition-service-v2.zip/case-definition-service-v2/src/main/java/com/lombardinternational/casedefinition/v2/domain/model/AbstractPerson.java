package com.lombardinternational.casedefinition.v2.domain.model;

import lombok.Data;

@Data
public abstract class AbstractPerson {
    private String externalId;
    private String thirdPartyId;
    private String name;
    private String firstName;
    private String lastname;
    private String fatcaStatus;
    private String subType;
}
