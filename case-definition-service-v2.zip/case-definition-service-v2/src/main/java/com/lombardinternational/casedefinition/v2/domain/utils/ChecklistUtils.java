package com.lombardinternational.casedefinition.v2.domain.utils;

import com.lombardinternational.casedefinition.v2.domain.model.Field;
import com.lombardinternational.casedefinition.v2.domain.model.Group;
import com.lombardinternational.casedefinition.v2.domain.model.ScreenDescription;
import com.lombardinternational.casedefinition.v2.domain.model.Tab;
import lombok.AccessLevel;
import lombok.NoArgsConstructor;

import java.util.Collection;
import java.util.List;
import java.util.Optional;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public final class ChecklistUtils {
    public static Tab getTabInScreenDescription(ScreenDescription screenDescription, String tabId) {
        return Optional.ofNullable(screenDescription).map(ScreenDescription::getTabs).stream().flatMap(Collection::stream)
                .filter(tab -> tabId.equals(tab.getTabId())).findFirst().orElse(null);
    }

    public static Group getGroupInTab(Tab tab, String groupId) {
        return Optional.ofNullable(tab).map(Tab::getGroups).stream().flatMap(Collection::stream)
                .filter(group -> groupId.equals(group.getGroupId())).findFirst().orElse(null);
    }

    public static Field getFieldInGroup(Group group, String fieldId) {
        return Optional.ofNullable(group).map(Group::getFields).stream().flatMap(Collection::stream)
                .filter(field -> fieldId.equals(field.getFieldId())).findFirst().orElse(null);
    }

    public static Optional<Field> getFieldById(ScreenDescription screenDescription, String fieldId) {
        return Optional.ofNullable(screenDescription).map(ScreenDescription::getTabs).stream().flatMap(Collection::stream)
                .map(Tab::getGroups).flatMap(Collection::stream).map(Group::getFields).flatMap(Collection::stream)
                .filter(field -> fieldId.equals(field.getFieldId())).findFirst();
    }

    public static List<Field> getFieldsById(ScreenDescription screenDescription, String fieldId) {
        return Optional.ofNullable(screenDescription).map(ScreenDescription::getTabs).stream().flatMap(Collection::stream)
                .map(Tab::getGroups).flatMap(Collection::stream).map(Group::getFields).flatMap(Collection::stream)
                .filter(field -> field.getFieldId() != null && field.getFieldId().startsWith(fieldId)).toList();
    }
}
