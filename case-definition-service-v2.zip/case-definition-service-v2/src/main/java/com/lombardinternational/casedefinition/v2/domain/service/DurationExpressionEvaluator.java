package com.lombardinternational.casedefinition.v2.domain.service;

public final class DurationExpressionEvaluator {
    private DurationExpressionEvaluator() {
    }

    public static int evaluate(String expression) {
        if (expression == null || expression.isBlank()) {
            return 0;
        }
        int result = 1;
        for (String part : expression.split("\\*")) {
            try {
                result = Math.multiplyExact(result, Integer.parseInt(part.trim()));
            } catch (RuntimeException ex) {
                return 0;
            }
        }
        return result;
    }
}
