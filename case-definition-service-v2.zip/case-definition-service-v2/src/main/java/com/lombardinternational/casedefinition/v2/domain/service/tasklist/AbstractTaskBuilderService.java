package com.lombardinternational.casedefinition.v2.domain.service.tasklist;

import com.lombardinternational.casedefinition.v2.domain.model.TaskDefinition;

import java.util.List;
import java.util.Optional;

public abstract class AbstractTaskBuilderService implements TaskBuilderService {
    protected void buildTaskDefinition(final List<TaskDefinition> taskList) {
        final var taskDefinition = taskList.stream().filter(task -> getTaskName().equals(task.getMainTaskName())).findFirst();
        final TaskDefinition finalTaskDefinition;
        if (taskDefinition.isEmpty()) {
            finalTaskDefinition = TaskDefinition.builder().mainTaskName(getTaskName()).mainTaskDynamicScreenId(getTaskDynamicScreenId())
                    .mainTaskExpectedDurationSeconds(getMainTaskExpectedDurationSeconds())
                    .signoffTaskExpectedDurationSeconds(getSignoffExpectedDurationSeconds()).mandatory(getMandatory()).suggested(getSuggested())
                    .releasableFromSubTask(getReleasableFromSubTask()).rulePriority(getRulePriority()).build();
            finalTaskDefinition.incrementOrder();
            taskList.add(finalTaskDefinition);
        } else {
            finalTaskDefinition = taskDefinition.get();
            if (getRulePriority() > finalTaskDefinition.getRulePriority()) {
                finalTaskDefinition.setMainTaskExpectedDurationSeconds(getMainTaskExpectedDurationSeconds());
                finalTaskDefinition.setSignoffTaskExpectedDurationSeconds(getSignoffExpectedDurationSeconds());
                finalTaskDefinition.setMandatory(getMandatory());
                finalTaskDefinition.setSuggested(getSuggested());
                finalTaskDefinition.setReleasableFromSubTask(getReleasableFromSubTask());
                finalTaskDefinition.setRulePriority(getRulePriority());
            }
        }
        addDecisionReasons(finalTaskDefinition);
    }

    protected abstract String getTaskName();
    protected int getRulePriority() { return 0; }
    protected boolean getMandatory() { return false; }
    protected boolean getSuggested() { return false; }
    protected boolean getReleasableFromSubTask() { return false; }
    protected Optional<String> getDecisionReason() { return Optional.empty(); }
    protected String getTaskDynamicScreenId() { return ""; }
    protected int getMainTaskExpectedDurationSeconds() { return 60 * 60 * 24 * 2; }
    protected int getSignoffExpectedDurationSeconds() { return 60 * 60 * 24; }

    protected void addDecisionReasons(TaskDefinition finalTaskDefinition) {
        getDecisionReason().map(reason -> reason.split("\n"))
                .ifPresent(reasons -> finalTaskDefinition.getDecisionReasons().addAll(List.of(reasons)));
    }
}
