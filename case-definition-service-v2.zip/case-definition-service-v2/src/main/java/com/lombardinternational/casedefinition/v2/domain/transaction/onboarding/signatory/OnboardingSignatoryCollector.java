package com.lombardinternational.casedefinition.v2.domain.transaction.onboarding.signatory;

import com.lombardinternational.casedefinition.v2.domain.model.RequiredSignatory;
import com.lombardinternational.casedefinition.v2.domain.model.WebForm;
import com.lombardinternational.casedefinition.v2.domain.model.WebFormGroup;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;

@Component
public class OnboardingSignatoryCollector {
    public Map<String, List<RequiredSignatory>> collectByType(WebForm webForm) {
        Map<String, List<RequiredSignatory>> signatories = new LinkedHashMap<>();
        List<RequiredSignatory> all = new ArrayList<>();

        OnboardingWebFormNavigator.allGroups(webForm)
                .map(this::toSignatory)
                .filter(Optional::isPresent)
                .map(Optional::get)
                .filter(signatory -> all.stream().noneMatch(existing -> samePerson(existing, signatory)))
                .forEach(signatory -> {
                    signatory.setSignerId("signer" + all.size());
                    all.add(signatory);
                    signatories.computeIfAbsent(signatory.getType(), ignored -> new ArrayList<>()).add(signatory);
                });

        return signatories;
    }

    private Optional<RequiredSignatory> toSignatory(WebFormGroup group) {
        var firstName = OnboardingWebFormNavigator.firstValue(group, "FIRSTNAME", "FIRST_NAME");
        var lastName = OnboardingWebFormNavigator.firstValue(group, "LASTNAME", "LAST_NAME", "SURNAME");
        var email = OnboardingWebFormNavigator.firstValue(group, "EMAIL");
        if (firstName.isEmpty() && lastName.isEmpty() && email.isEmpty()) {
            return Optional.empty();
        }

        var role = role(group);
        var label = normalize((firstName.orElse("") + " " + lastName.orElse("") + " " + email.orElse("")).replace("'", " "));
        var thirdPartyId = OnboardingWebFormNavigator.firstValue(group, "CLIENT_CONTACT_ID", "THIRDPARTY_ID", "THIRD_PARTY_ID", "USER_ID", "UUID", "ID")
                .orElse(null);

        return Optional.of(RequiredSignatory.builder()
                .type(role)
                .thirdpartyId(thirdPartyId)
                .externalId(thirdPartyId)
                .firstName(firstName.orElse(null))
                .lastName(lastName.orElse(null))
                .name(normalize((firstName.orElse("") + " " + lastName.orElse(""))))
                .email(email.orElse(null))
                .phoneNumber(OnboardingWebFormNavigator.firstValue(group, "MOBILE", "MOBILE_PHONE", "PHONE_NUMBER", "PHONE").orElse(null))
                .label(label)
                .build());
    }

    private String role(WebFormGroup group) {
        var explicit = OnboardingWebFormNavigator.firstValue(group, "SIGNATORY_TYPE", "ROLE").map(this::normalizeRole);
        if (explicit.isPresent()) {
            return explicit.get();
        }

        String groupId = OnboardingWebFormNavigator.groupId(group).toUpperCase(Locale.ROOT);
        if (groupId.contains("ADMINISTRATOR")) {
            return "ADMINISTRATOR";
        }
        if (groupId.contains("EBO") || groupId.contains("BENEFICIAL")) {
            return "ECONOMICAL_BENEFICIAL_OWNER";
        }
        if (groupId.contains("LIFE_ASSURED")) {
            return "LIFE_ASSURED";
        }
        if (groupId.contains("IRREVOCABLE") || groupId.contains("BENEFICIARY")) {
            return "IRREVOCABLE_BENEFICIARY";
        }
        if (groupId.contains("POLICY_HOLDER") || groupId.contains("PHYSICAL_PERSON")) {
            return "HOLDER";
        }
        if (groupId.contains("INTERMEDIARY") || groupId.contains("INTERMEDIATE")) {
            return "INTERMEDIATE";
        }
        if (groupId.contains("INVESTMENT_ADVISOR")) {
            return "IA";
        }
        if (groupId.contains("RTO")) {
            return "RTO";
        }
        return "SIGNATORY";
    }

    private String normalizeRole(String value) {
        return value == null ? "SIGNATORY" : value.trim().toUpperCase(Locale.ROOT);
    }

    private boolean samePerson(RequiredSignatory left, RequiredSignatory right) {
        return Objects.equals(normalize(left.getFirstName()), normalize(right.getFirstName()))
                && Objects.equals(normalize(left.getLastName()), normalize(right.getLastName()))
                && Objects.equals(normalize(left.getEmail()), normalize(right.getEmail()));
    }

    private String normalize(String value) {
        if (value == null) {
            return null;
        }
        return value.trim().replaceAll("\\s+", " ");
    }
}
