package com.lombardinternational.casedefinition.v2.mapper;

import org.mapstruct.Mapping;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

@Retention(RetentionPolicy.CLASS)
@Mapping(target = "thirdPartyId", source = "externalId")
@Mapping(target = "fatcaStatus", source = "fatcaStatus.externalId")
public @interface ToAbstractPerson {
}
