package com.lombardinternational.casedefinition.v2.adapter.api.web.mapper;

import com.lombardinternational.casedefinition.v2.domain.model.WebFormGroup;
import org.mapstruct.Mapper;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Objects;

@Mapper(componentModel = "spring")
public abstract class WebFormGroupMapper {
    @Autowired
    protected WebFormFieldMapper webFormFieldMapper;

    public WebFormGroup webFormGroupFromDTO(com.lombardinternational.casedefinition.v2.adapter.api.web.dto.WebFormGroup dto) {
        if (dto == null) {
            return null;
        }
        WebFormGroup group = new WebFormGroup();
        group.setFieldsetId(dto.getFieldsetId());
        group.setGroupId(dto.getGroupId());
        group.setFields(flattenFields(dto));
        group.setGroups(webFormGroupFromDTO(dto.getGroups()));
        return group;
    }

    public List<WebFormGroup> webFormGroupFromDTO(Collection<com.lombardinternational.casedefinition.v2.adapter.api.web.dto.WebFormGroup> dtos) {
        if (dtos == null) {
            return List.of();
        }
        return dtos.stream().map(this::webFormGroupFromDTO).filter(Objects::nonNull).toList();
    }

    public com.lombardinternational.casedefinition.v2.adapter.api.web.dto.WebFormGroup dtoFromWebFormGroup(WebFormGroup group) {
        if (group == null) {
            return null;
        }
        var dto = new com.lombardinternational.casedefinition.v2.adapter.api.web.dto.WebFormGroup();
        dto.setFieldsetId(group.getFieldsetId());
        dto.setGroupId(group.getGroupId());
        dto.setFields(webFormFieldMapper.dtoFromWebFormField(group.getFields()));
        dto.setGroups(dtoFromWebFormGroup(group.getGroups()));
        return dto;
    }

    public List<com.lombardinternational.casedefinition.v2.adapter.api.web.dto.WebFormGroup> dtoFromWebFormGroup(Collection<WebFormGroup> groups) {
        if (groups == null) {
            return List.of();
        }
        return groups.stream().map(this::dtoFromWebFormGroup).filter(Objects::nonNull).toList();
    }

    private List<com.lombardinternational.casedefinition.v2.domain.model.WebFormField> flattenFields(
            com.lombardinternational.casedefinition.v2.adapter.api.web.dto.WebFormGroup dto) {
        List<com.lombardinternational.casedefinition.v2.adapter.api.web.dto.WebFormField> allFields = new ArrayList<>();
        addAll(allFields, dto.getFields());
        addAll(allFields, dto.getTextFields());
        addAll(allFields, dto.getBooleanFields());
        addAll(allFields, dto.getBigDecimalFields());
        addAll(allFields, dto.getCalendarFields());
        return webFormFieldMapper.webFormFieldFromDTO(allFields);
    }

    private void addAll(List<com.lombardinternational.casedefinition.v2.adapter.api.web.dto.WebFormField> target,
                        Collection<? extends com.lombardinternational.casedefinition.v2.adapter.api.web.dto.WebFormField> source) {
        if (source != null) {
            target.addAll(source);
        }
    }
}
