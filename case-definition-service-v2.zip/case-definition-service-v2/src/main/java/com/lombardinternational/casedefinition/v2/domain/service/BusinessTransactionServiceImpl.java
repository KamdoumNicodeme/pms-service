package com.lombardinternational.casedefinition.v2.domain.service;

import com.lombardinternational.casedefinition.v2.domain.api.AmountService;
import com.lombardinternational.casedefinition.v2.domain.api.BusinessTransactionService;
import com.lombardinternational.casedefinition.v2.domain.model.Amount;
import com.lombardinternational.casedefinition.v2.domain.model.BusinessTransaction;
import com.lombardinternational.casedefinition.v2.domain.model.Policy;
import com.lombardinternational.casedefinition.v2.domain.spi.BusinessTransactionWebService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

@Service
@RequiredArgsConstructor
public class BusinessTransactionServiceImpl implements BusinessTransactionService {
    private static final String EUR = "EUR";

    private final BusinessTransactionWebService businessTransactionWebService;
    private final AmountService amountService;

    @Override
    public Boolean hasMadeChangeOfBroker(String policyNumber) {
        return businessTransactionWebService.getBusinessTransactions(policyNumber).stream()
                .filter(transaction -> "DISTRIBUTION_NETWORK".equals(transaction.getCategory()))
                .filter(transaction -> "CHANGE_PARTNER_STRUCTURE".equals(transaction.getSubCategory()))
                .map(BusinessTransaction::getCloseDate)
                .anyMatch(closeDate -> closeDate != null && !closeDate.isBefore(java.time.LocalDate.now().minusMonths(3)));
    }

    @Override
    public BusinessTransaction buildBusinessTransaction(String businessTransactionNumber, Policy policy, String caseType,
            String policyNumber) {
        BusinessTransaction businessTransaction = businessTransactionWebService.getBusinessTransaction(businessTransactionNumber);
        if (businessTransaction == null) {
            businessTransaction = new BusinessTransaction();
            businessTransaction.setIdentifier(businessTransactionNumber);
        }
        String policyCurrency = policy != null && StringUtils.hasText(policy.getIsoCurrencyCode()) ? policy.getIsoCurrencyCode() : EUR;
        Amount expectedAmount = amountService.getSumPaymentAmountInTransaction(businessTransaction, policyCurrency);
        businessTransaction.setExpectedAmount(expectedAmount);
        businessTransaction.setExpectedAmountEur(amountService.convertAmount(expectedAmount, EUR));
        if (businessTransaction.getTransactionAmounts() != null) {
            businessTransaction.setTransactionAmountEur(
                    amountService.convertAmount(businessTransaction.getTransactionAmounts().getGrossAmount(), EUR));
        }
        return businessTransaction;
    }
}
