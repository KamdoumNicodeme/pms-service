package com.lombardinternational.casedefinition.v2.adapter.api.web.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class Group {
    private String groupId;
    private String title;
    private String i18NTitleKey;
    private int order;
    private Integer columnsCount;
    @Builder.Default
    private List<Field> fields = new ArrayList<>();
    private String displayIf;
    private Boolean isActive;
}
