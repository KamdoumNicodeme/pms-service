package com.lombardinternational.casedefinition.v2.domain.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class RequiredSignatory {
    private String thirdpartyId;
    private String externalId;
    private String type;
    private String name;
    private String firstName;
    private String lastName;
    private String email;
    private String phoneNumber;
    private String label;
    private String signerId;
    @Builder.Default
    private List<String> allowedActions = new ArrayList<>();
    private String onBehalfOf;
}
