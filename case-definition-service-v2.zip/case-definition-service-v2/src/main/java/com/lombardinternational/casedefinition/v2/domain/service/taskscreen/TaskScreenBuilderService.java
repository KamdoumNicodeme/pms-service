package com.lombardinternational.casedefinition.v2.domain.service.taskscreen;

import com.lombardinternational.casedefinition.v2.domain.model.ScreenDescription;
import com.lombardinternational.casedefinition.v2.domain.model.WebForm;

public interface TaskScreenBuilderService {
    ScreenDescription buildTaskScreen(WebForm webForm, ScreenDescription screenCheckList, ScreenDescription screenToFill);
}
