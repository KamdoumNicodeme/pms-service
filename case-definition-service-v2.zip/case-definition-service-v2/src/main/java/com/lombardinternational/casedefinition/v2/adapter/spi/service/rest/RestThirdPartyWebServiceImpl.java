package com.lombardinternational.casedefinition.v2.adapter.spi.service.rest;

import com.lombardinternational.casedefinition.v2.domain.spi.ThirdPartyWebService;
import com.lombardinternational.clients.classapp.client.ThirdPartyServiceClient;
import com.lombardinternational.clients.classapp.model.thirdparty.ThirdParty;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class RestThirdPartyWebServiceImpl implements ThirdPartyWebService {
    private final ThirdPartyServiceClient thirdPartyClient;

    @Override
    public ThirdParty getThirdParty(String externalId) {
        return thirdPartyClient.getThirdParty(externalId);
    }
}
