package com.lombardinternational.casedefinition.v2.adapter.spi.service.rest.mapper;

import com.lombardinternational.casedefinition.v2.domain.model.Fund;
import org.mapstruct.AfterMapping;
import org.mapstruct.BeanMapping;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;

import java.util.Collection;
import java.util.List;

@Mapper(componentModel = "spring")
public interface FundMapper {
    @BeanMapping(ignoreByDefault = true)
    @Mapping(target = "fundNumber", source = "fundNumber")
    @Mapping(target = "fundSubClass", source = "typeOfSecurity")
    @Mapping(target = "fundCode", source = "fundNumber")
    Fund map(com.lombardinternational.clients.classapp.model.Fund fund);

    List<Fund> map(Collection<com.lombardinternational.clients.classapp.model.Fund> fund);

    @AfterMapping
    default void setIlfFund(@MappingTarget Fund fund) {
        if (fund != null) {
            fund.setIlfFund("ILF".equalsIgnoreCase(fund.getFundSubClass()));
        }
    }
}
