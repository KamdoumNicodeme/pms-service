package com.lombardinternational.casedefinition.v2.mapper;

import com.lombardinternational.casedefinition.v2.domain.model.BusinessTransaction;
import com.lombardinternational.clients.classapp.model.BusinessTransactionDetails;
import com.lombardinternational.clients.classapp.model.BusinessTransactionLight;
import org.mapstruct.Mapping;
import org.mapstruct.Mapper;

import java.util.Collection;
import java.util.List;

@Mapper(componentModel = "spring", uses = {AmountMapper.class})
public interface BusinessTransactionMapper {
    default BusinessTransaction buildBusinessTransaction(BusinessTransactionDetails businessTransactionDetails) {
        if (businessTransactionDetails == null) {
            return new BusinessTransaction();
        }
        return mapToBusinessTransaction(businessTransactionDetails);
    }

    @ToBusinessTransaction
    BusinessTransaction mapToBusinessTransaction(BusinessTransactionDetails businessTransactionDetails);

    @Mapping(source = "transactionId", target = "identifier")
    @Mapping(source = "transactionType", target = "type")
    @Mapping(source = "endorsementCategory", target = "category")
    @Mapping(source = "endorsementSubCategory", target = "subCategory")
    @Mapping(source = "closingDate", target = "closeDate")
    BusinessTransaction mapToBusinessTransactionFromLight(BusinessTransactionLight businessTransactionLight);

    List<BusinessTransaction> mapToListFromLightList(Collection<BusinessTransactionLight> businessTransactionLightList);
}
