package com.lombardinternational.casedefinition.v2.adapter.api.web.dto;

public record CaseSubTaskRequest(String policyNumber, String caseType, String businessTransactionNumber,
                                 WebForm caseInitializationData, ScreenDescription checkListOverviewData) {
}
