package com.lombardinternational.casedefinition.v2.config;

import io.swagger.v3.oas.models.Components;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.info.License;
import io.swagger.v3.oas.models.security.SecurityRequirement;
import io.swagger.v3.oas.models.security.SecurityScheme;
import org.springdoc.core.models.GroupedOpenApi;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class SwaggerConfig {
    private static final String SECURITY_SCHEME = "jwt";

    @Bean
    public GroupedOpenApi caseDefinitionApi() {
        return GroupedOpenApi.builder()
                .group("case-definition-service-v2")
                .displayName("case-definition-service-v2")
                .packagesToScan("com.lombardinternational.casedefinition.v2.adapter.api.web")
                .pathsToMatch("/api/**")
                .build();
    }

    @Bean
    public OpenAPI openAPI(@Value("${info.app.version:1.0.0-SNAPSHOT}") String version) {
        return new OpenAPI()
                .info(new Info()
                        .title("Case Definition Service V2 API")
                        .version(version)
                        .description("Java based ONBOARDING definitions without Excel, KIE, EMS or JMS.")
                        .license(new License().name("Lombard International Assurance"))
                        .contact(new Contact().name("IT Application Development").url("https://www.lombardinternational.com")))
                .components(new Components().addSecuritySchemes(SECURITY_SCHEME,
                        new SecurityScheme().type(SecurityScheme.Type.HTTP).scheme("bearer").bearerFormat("JWT")))
                .addSecurityItem(new SecurityRequirement().addList(SECURITY_SCHEME));
    }
}
