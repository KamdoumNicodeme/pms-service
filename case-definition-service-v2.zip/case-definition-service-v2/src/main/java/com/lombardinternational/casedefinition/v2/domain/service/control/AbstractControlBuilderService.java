package com.lombardinternational.casedefinition.v2.domain.service.control;

import com.lombardinternational.casedefinition.v2.domain.model.CaseControlDefinition;

public abstract class AbstractControlBuilderService implements ControlBuilderService {
    protected CaseControlDefinition buildControlDefinition() {
        final var controlDefinition = CaseControlDefinition.builder().controlName(getControlName()).controlType(getControlType())
                .controlVisibleOnConnect(getControlVisibleOnConnect()).build();
        controlDefinition.incrementOrder();
        return controlDefinition;
    }

    protected abstract String getControlName();
    protected abstract String getControlType();
    protected boolean getControlVisibleOnConnect() { return false; }
}
