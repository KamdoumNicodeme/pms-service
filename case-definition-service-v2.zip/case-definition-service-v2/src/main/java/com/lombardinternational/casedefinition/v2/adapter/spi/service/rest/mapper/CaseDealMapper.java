package com.lombardinternational.casedefinition.v2.adapter.spi.service.rest.mapper;

import com.lombardinternational.casedefinition.v2.domain.model.CaseDeal;
import org.mapstruct.Mapper;

import java.util.List;

@Mapper
public interface CaseDealMapper {
    List<CaseDeal> mapToCaseDealList(List<com.lombardinternational.casemanagement.clients.casebusinesscase.model.CaseDeal> cdmCaseDeals);
}
