package com.lombardinternational.casedefinition.v2.adapter.api.web.dto;

public class BooleanWebFormField extends WebFormField {
}
