package com.lombardinternational.casedefinition.v2.domain.service;

import com.lombardinternational.casedefinition.v2.domain.api.AmountService;
import com.lombardinternational.casedefinition.v2.domain.model.Amount;
import com.lombardinternational.casedefinition.v2.domain.model.BusinessTransaction;
import com.lombardinternational.casedefinition.v2.domain.model.BusinessTransactionProductComponent;
import com.lombardinternational.casedefinition.v2.domain.model.CurrencyExchangeRate;
import com.lombardinternational.casedefinition.v2.domain.model.Payment;
import com.lombardinternational.casedefinition.v2.domain.spi.FxRateWebService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Collection;
import java.util.Comparator;
import java.util.Optional;
import java.util.stream.Stream;

@Service
@RequiredArgsConstructor
public class AmountServiceImpl implements AmountService {
    private final FxRateWebService fxRateWebService;

    @Override
    public Amount convertAmount(Amount amount, String targetCurrency) {
        if (amount == null || amount.getQuantity() == null) {
            return new Amount(BigDecimal.ZERO.setScale(2, RoundingMode.HALF_UP), targetCurrency);
        }
        if (targetCurrency == null || targetCurrency.equals(amount.getIsoCurrencyCode())) {
            amount.setQuantity(amount.getQuantity().setScale(2, RoundingMode.HALF_UP));
            return amount;
        }

        Optional<CurrencyExchangeRate> exchangeRate = fxRateWebService.getFxRate(amount.getIsoCurrencyCode(), targetCurrency).stream()
                .filter(rate -> amount.getIsoCurrencyCode().equals(rate.getBaseIsoCurrencyCode()))
                .filter(rate -> targetCurrency.equals(rate.getQuotedIsoCurrencyCode()))
                .max(Comparator.comparing(CurrencyExchangeRate::getRateDate));

        BigDecimal quantity = exchangeRate
                .map(rate -> amount.getQuantity()
                        .multiply(rate.getRate().setScale(6, RoundingMode.HALF_UP))
                        .setScale(2, RoundingMode.HALF_UP))
                .orElseGet(() -> amount.getQuantity().setScale(2, RoundingMode.HALF_UP));

        return new Amount(quantity, targetCurrency);
    }

    @Override
    public Amount getSumPaymentAmountInTransaction(BusinessTransaction transaction, String targetCurrency) {
        BigDecimal sum = BigDecimal.ZERO;
        if (transaction != null) {
            sum = Optional.ofNullable(transaction.getProductComponentPayments()).map(Collection::stream).orElseGet(Stream::empty)
                    .map(BusinessTransactionProductComponent::getPayments)
                    .flatMap(payments -> Optional.ofNullable(payments).map(Collection::stream).orElseGet(Stream::empty))
                    .map(Payment::getPaymentAmount)
                    .map(amount -> convertAmount(amount, targetCurrency))
                    .map(Amount::getQuantity)
                    .reduce(BigDecimal.ZERO, BigDecimal::add);
        }

        if (BigDecimal.ZERO.compareTo(sum) == 0 && transaction != null) {
            sum = Optional.ofNullable(transaction.getProductComponentPayments()).map(Collection::stream).orElseGet(Stream::empty)
                    .map(BusinessTransactionProductComponent::getExpectedAmountInPolicyCurrency)
                    .map(amount -> convertAmount(amount, targetCurrency))
                    .map(Amount::getQuantity)
                    .reduce(BigDecimal.ZERO, BigDecimal::add);
        }
        return new Amount(sum.setScale(2, RoundingMode.HALF_UP), targetCurrency);
    }
}
