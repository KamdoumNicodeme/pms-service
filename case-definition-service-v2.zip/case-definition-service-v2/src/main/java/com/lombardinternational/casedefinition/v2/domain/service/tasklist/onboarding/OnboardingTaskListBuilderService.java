package com.lombardinternational.casedefinition.v2.domain.service.tasklist.onboarding;

import com.lombardinternational.casedefinition.v2.domain.model.ScreenDescription;
import com.lombardinternational.casedefinition.v2.domain.model.TaskDefinition;
import com.lombardinternational.casedefinition.v2.domain.model.WebForm;
import com.lombardinternational.casedefinition.v2.domain.service.tasklist.TaskListBuilderService;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
@AllArgsConstructor
public class OnboardingTaskListBuilderService implements TaskListBuilderService {
    private final OnboardingTaskSpecBuilderService taskSpecBuilderService;

    @Override
    public List<TaskDefinition> buildTaskList(WebForm webForm, ScreenDescription screenDescription, String policyNumber) {
        TaskDefinition.resetTaskOrder();
        final var taskDefinitions = new ArrayList<TaskDefinition>();
        taskSpecBuilderService.buildTask(webForm, screenDescription, taskDefinitions);
        return taskDefinitions;
    }
}
