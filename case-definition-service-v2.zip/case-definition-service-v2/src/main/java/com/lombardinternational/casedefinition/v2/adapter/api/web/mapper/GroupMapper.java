package com.lombardinternational.casedefinition.v2.adapter.api.web.mapper;

import com.lombardinternational.casedefinition.v2.domain.model.Group;
import org.mapstruct.Mapper;

import java.util.List;

@Mapper(componentModel = "spring", uses = {FieldMapper.class})
public interface GroupMapper {
    Group groupFromDTO(com.lombardinternational.casedefinition.v2.adapter.api.web.dto.Group dto);

    List<Group> groupFromDTO(List<com.lombardinternational.casedefinition.v2.adapter.api.web.dto.Group> dtos);

    com.lombardinternational.casedefinition.v2.adapter.api.web.dto.Group groupToDTO(Group group);

    List<com.lombardinternational.casedefinition.v2.adapter.api.web.dto.Group> groupToDTO(List<Group> groups);
}
