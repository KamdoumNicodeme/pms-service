package com.lombardinternational.casedefinition.v2.adapter.api.web.mapper;

import com.lombardinternational.casedefinition.v2.domain.model.SelectInputField;
import org.mapstruct.Mapper;

import java.util.List;

@Mapper(componentModel = "spring", uses = {SelectInputFieldOptionMapper.class})
public interface SelectInputFieldMapper {
    List<SelectInputField> selectInputFieldFromDTO(List<com.lombardinternational.casedefinition.v2.adapter.api.web.dto.SelectInputField> dtos);
}
