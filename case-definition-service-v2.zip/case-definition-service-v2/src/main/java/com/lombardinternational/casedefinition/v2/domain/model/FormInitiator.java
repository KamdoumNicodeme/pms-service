package com.lombardinternational.casedefinition.v2.domain.model;

import lombok.Data;

@Data
public class FormInitiator {
    private Long userId;
    private String userLogin;
    private String displayedName;
    private Long companyId;
    private String companyName;
    private String initiatorRole;
    private String partnerType;
}
