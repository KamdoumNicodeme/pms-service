package com.lombardinternational.casedefinition.v2.domain.service.tasklist;

import com.lombardinternational.casedefinition.v2.domain.model.ScreenDescription;
import com.lombardinternational.casedefinition.v2.domain.model.TaskDefinition;
import com.lombardinternational.casedefinition.v2.domain.model.WebForm;

import java.util.List;

public interface TaskBuilderService {
    void buildTask(WebForm webForm, ScreenDescription screenDescription, List<TaskDefinition> taskList);
}
