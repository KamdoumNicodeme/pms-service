package com.lombardinternational.casedefinition.v2.domain.transaction.onboarding.signatory;

import com.lombardinternational.casedefinition.v2.domain.model.WebForm;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.Locale;
import java.util.Objects;
import java.util.Optional;
import java.util.regex.Pattern;

@Component
public class OnboardingSignatureRuleMatcher {
    private static final Pattern IS_MARKET = Pattern.compile("isMarket\\(connect,\\s*\"([^\"]+)\"\\)");
    private static final Pattern IS_PRE_CONTRACTUAL = Pattern.compile("isPreContractualPackage\\(connect,\\s*\"([^\"]+)\"\\)");

    public boolean matches(SignatureDocumentSpec spec, WebForm webForm) {
        return spec.active()
                && matchesValue(spec.webFormId(), Optional.ofNullable(webForm).map(WebForm::getWebFormId).orElse(null))
                && matchesValue(spec.market(), firstValue(webForm, "TARGET_MARKET", "MARKET", "BUSINESS_ORIGIN").orElse(null))
                && matchesValue(spec.branch(), firstValue(webForm, "BRANCH").orElse(null))
                && matchesValue(spec.holderSpecificType(), holderSpecificType(webForm).orElse(null))
                && matchesValue(spec.partnerType(), firstValue(webForm, "PARTNER_TYPE").orElse(null))
                && matchesValue(spec.productType(), firstValue(webForm, "PRODUCT_CHOICE").orElse(null))
                && matchesGenericPreContractual(spec.genericPreContractualPackage(), webForm)
                && matchesValue(spec.documentLanguagePreference(), firstValue(webForm, "CORRESPONDENCE_PREFERRED_LANG", "DOCUMENT_LANGUAGE_PREFERENCE").orElse(null))
                && matchesExtraCondition(spec.extraCondition(), webForm);
    }

    private Optional<String> firstValue(WebForm webForm, String... fieldIds) {
        return OnboardingWebFormNavigator.firstValue(webForm, fieldIds).map(value -> value.trim().toUpperCase(Locale.ROOT));
    }

    private boolean matchesValue(String expected, String actual) {
        if (!OnboardingWebFormNavigator.hasText(expected)) {
            return true;
        }
        if (!OnboardingWebFormNavigator.hasText(actual)) {
            return false;
        }
        return Arrays.stream(expected.split("\\|")).map(String::trim).filter(OnboardingWebFormNavigator::hasText)
                .anyMatch(value -> value.equalsIgnoreCase(actual));
    }

    private boolean matchesGenericPreContractual(Boolean expected, WebForm webForm) {
        if (expected == null) {
            return true;
        }
        boolean actual = firstValue(webForm, "PRE_CONTRACTUAL_PACKAGE").filter("GENERIC"::equals).isPresent();
        return Objects.equals(expected, actual);
    }

    private Optional<String> holderSpecificType(WebForm webForm) {
        var explicit = firstValue(webForm, "HOLDER_SPECIFIC_TYPE", "POLICY_HOLDER_SPECIFIC_TYPE", "POLICY_HOLDER_TYPE");
        if (explicit.isPresent()) {
            return explicit;
        }
        var type = firstValue(webForm, "TYPE", "HOLDER_TYPE");
        if (type.filter("PHYSICAL"::equals).isPresent()) {
            return Optional.of("PP");
        }
        if (type.filter("MORAL"::equals).isPresent()) {
            boolean isSc = firstValue(webForm, "IS_SC").filter(this::isTrue).isPresent();
            return Optional.of(isSc ? "SC" : "PM");
        }
        return Optional.empty();
    }

    private boolean matchesExtraCondition(String condition, WebForm webForm) {
        if (!OnboardingWebFormNavigator.hasText(condition)) {
            return true;
        }
        String normalized = condition.trim();
        return switch (normalized) {
            case "isConnectAccessRequested(connect)" -> firstValue(webForm, "CONNECT_ACCESS_REQUESTED").filter(this::isTrue).isPresent();
            case "isInvestmentProfileUpgraded(connect)" -> firstValue(webForm, "UPGRADE").filter(OnboardingWebFormNavigator::hasText).isPresent();
            case "isInvestmentProfileDowngraded(connect)" -> firstValue(webForm, "DOWNGRADE").filter(OnboardingWebFormNavigator::hasText).isPresent();
            case "isDigitalCommunication(connect)" -> firstValue(webForm, "COMMUNICATION_TYPE").filter("ELECTRONIC"::equals).isPresent();
            case "isRopCase(connect)" -> firstValue(webForm, "IS_REST_OF_PREMIUM", "IS_ROP_CASE").filter(value -> isTrue(value) || "YES".equals(value)).isPresent();
            case "isSignatureRequiredByLifeAssured(connect)" -> true;
            case "isEcfInvestment(connect)" -> !OnboardingWebFormNavigator.groupsById(webForm, "EXTERNAL_COLLECTIVE_FUND").isEmpty();
            case "isSafAdvisedManagement(connect)" -> firstValue(webForm, "SAF_MANAGER").filter("MANAGEMENT_ADVISED"::equals).isPresent();
            case "isSwitchReinvestmentWhenRenunciationPeriodEnd(connect)" -> firstValue(webForm, "HAS_REINVESTMENT").filter(this::isTrue).isPresent();
            default -> matchesFunctionCondition(normalized, webForm);
        };
    }

    private boolean matchesFunctionCondition(String condition, WebForm webForm) {
        var marketMatcher = IS_MARKET.matcher(condition);
        if (marketMatcher.matches()) {
            return firstValue(webForm, "TARGET_MARKET", "MARKET", "BUSINESS_ORIGIN").filter(marketMatcher.group(1)::equals).isPresent();
        }
        var packageMatcher = IS_PRE_CONTRACTUAL.matcher(condition);
        if (packageMatcher.matches()) {
            return firstValue(webForm, "PRE_CONTRACTUAL_PACKAGE").filter(packageMatcher.group(1)::equals).isPresent();
        }
        if (condition.startsWith("!isLegalForm(connect,")) {
            return true;
        }
        if (condition.startsWith("isSpecificInvestmentStrategy(connect,")) {
            return firstValue(webForm, "INVESTMENT_STRATEGY").filter(OnboardingWebFormNavigator::hasText).isPresent();
        }
        return false;
    }

    private boolean isTrue(String value) {
        return "TRUE".equalsIgnoreCase(value) || "YES".equalsIgnoreCase(value);
    }
}
