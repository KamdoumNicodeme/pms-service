package com.lombardinternational.casedefinition.v2.domain.service.checklist.onboarding.group;

import com.lombardinternational.casedefinition.v2.domain.model.Group;
import com.lombardinternational.casedefinition.v2.domain.model.ScreenDescription;
import com.lombardinternational.casedefinition.v2.domain.model.Tab;
import com.lombardinternational.casedefinition.v2.domain.model.WebForm;
import com.lombardinternational.casedefinition.v2.domain.service.checklist.GroupBuilderService;
import com.lombardinternational.casedefinition.v2.domain.service.checklist.onboarding.field.OnboardingThirdPartyFieldsBuilderService;
import com.lombardinternational.casedefinition.v2.domain.utils.ChecklistUtils;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import static com.lombardinternational.casedefinition.v2.domain.transaction.onboarding.rules.OnboardingChecklistIds.THIRD_PARTY_GROUP;

@Service
@AllArgsConstructor
public class OnboardingThirdPartyGroupBuilderService implements GroupBuilderService {
    private final OnboardingThirdPartyFieldsBuilderService fieldsBuilderService;

    @Override
    public void buildGroup(WebForm webForm, ScreenDescription screenDescription, Tab parentTab) {
        var group = ChecklistUtils.getGroupInTab(parentTab, THIRD_PARTY_GROUP);
        if (group == null) {
            group = Group.builder().groupId(THIRD_PARTY_GROUP).build();
            parentTab.getGroups().add(group);
        }

        group.setIsActive(true);
        group.setOrder(102);
        group.setTitle("Payment from third party");
        group.setColumnsCount(2);
        group.setDisplayIf("#PAYMENT_THIRD_PARTY# == \"YES\"");
        fieldsBuilderService.buildField(webForm, screenDescription, group);
    }
}
