package com.lombardinternational.casedefinition.v2.adapter.api.web.mapper;

import com.lombardinternational.casedefinition.v2.domain.model.TaskDefinition;
import org.mapstruct.Mapper;

import java.util.List;

@Mapper(componentModel = "spring")
public interface TaskDefinitionMapper {
    com.lombardinternational.casedefinition.v2.adapter.api.web.dto.TaskDefinition map(TaskDefinition taskDefinition);

    List<com.lombardinternational.casedefinition.v2.adapter.api.web.dto.TaskDefinition> map(List<TaskDefinition> definitions);
}
