package com.lombardinternational.casedefinition.v2.domain.service.checklist.onboarding.field;

import com.lombardinternational.casedefinition.v2.domain.model.Group;
import com.lombardinternational.casedefinition.v2.domain.model.ScreenDescription;
import com.lombardinternational.casedefinition.v2.domain.model.WebForm;
import com.lombardinternational.casedefinition.v2.domain.service.checklist.FieldBuilderService;
import org.springframework.stereotype.Service;

import java.util.Map;

@Service
public class OnboardingPricingApprovalFieldsBuilderService extends OnboardingChecklistFieldsBuilderSupport implements FieldBuilderService {
    @Override
    public void buildField(WebForm webForm, ScreenDescription screenDescription, Group group) {
        var previousValues = previousValues(screenDescription);
        resetFields(group);
        buildNtaMarkupException(group, previousValues, webForm);
        buildExplainException(group, previousValues, webForm);
        buildPricingApprovalStage(group, previousValues, webForm);
        buildRationaleForException(group, previousValues, webForm);
        buildAdministrativeFee(group, previousValues, webForm);
        buildGac(group, previousValues, webForm);
        buildPolicyFee(group, previousValues, webForm);
        buildIsFamilyCase(group, previousValues, webForm);
        buildFamilyCasePolNbr(group, previousValues, webForm);
        buildFamilyCaseTotalAmount(group, previousValues, webForm);
        buildPricingApprovalChecked(group, previousValues, webForm);
        sortFields(group);
    }

    private void buildNtaMarkupException(Group group, Map<String, String> previousValues, WebForm webForm) {
        buildField(group, new FieldRule("NTA_MARKUP_EXCEPTION", FieldKind.SELECT, 1, "NTA Markup Exception?", false, false,
                null, null, false, null, false), previousValues, webForm);
    }

    private void buildExplainException(Group group, Map<String, String> previousValues, WebForm webForm) {
        buildField(group, new FieldRule("EXPLAIN_EXCEPTION", FieldKind.TEXT_AREA, 2, "Explain Exception", false, false,
                null, null, false, null, false), previousValues, webForm);
    }

    private void buildPricingApprovalStage(Group group, Map<String, String> previousValues, WebForm webForm) {
        buildField(group, new FieldRule("PRICING_APPROVAL_STAGE", FieldKind.TEXT, 3, "Pricing Approval Stage", false, false,
                null, null, false, null, false), previousValues, webForm);
    }

    private void buildRationaleForException(Group group, Map<String, String> previousValues, WebForm webForm) {
        buildField(group, new FieldRule("RATIONALE_FOR_EXCEPTION", FieldKind.TEXT, 4, "Rationale for Exception", false, false,
                null, null, false, null, false), previousValues, webForm);
    }

    private void buildAdministrativeFee(Group group, Map<String, String> previousValues, WebForm webForm) {
        buildField(group, new FieldRule("ADMINISTRATIVE_FEE", FieldKind.TEXT, 5, "Administrative Fee", false, false,
                null, null, false, null, false), previousValues, webForm);
    }

    private void buildGac(Group group, Map<String, String> previousValues, WebForm webForm) {
        buildField(group, new FieldRule("GAC", FieldKind.TEXT, 6, "GAC (#Years)", false, false,
                null, null, false, null, false), previousValues, webForm);
    }

    private void buildPolicyFee(Group group, Map<String, String> previousValues, WebForm webForm) {
        buildField(group, new FieldRule("POLICY_FEE", FieldKind.TEXT, 7, "Policy Fee", false, false,
                null, null, false, null, false), previousValues, webForm);
    }

    private void buildIsFamilyCase(Group group, Map<String, String> previousValues, WebForm webForm) {
        buildField(group, new FieldRule("IS_FAMILY_CASE", FieldKind.SELECT, 8, "It is a family case ?", true, false,
                "YES\u00acYes;NO\u00acNo", null, false, null, false), previousValues, webForm);
    }

    private void buildFamilyCasePolNbr(Group group, Map<String, String> previousValues, WebForm webForm) {
        buildField(group, new FieldRule("FAMILY_CASE_POL_NBR", FieldKind.NUMBER, 9, "How many policies in the family case", true, false,
                null, null, false, null, false), previousValues, webForm);
    }

    private void buildFamilyCaseTotalAmount(Group group, Map<String, String> previousValues, WebForm webForm) {
        buildField(group, new FieldRule("FAMILY_CASE_TOTAL_AMOUNT", FieldKind.NUMBER, 10, "Total amount invested in the family case", true, false,
                null, null, false, null, false), previousValues, webForm);
    }

    private void buildPricingApprovalChecked(Group group, Map<String, String> previousValues, WebForm webForm) {
        buildField(group, new FieldRule("PRICING_APPROVAL_CHECKED", FieldKind.SELECT, 11, "Pricing approval has been checked in CRM tab (Salesforce) and is in line with the charging structure signed by the PH in the Application form, and the premium received", true, true,
                "YES\u00acYes;NO\u00acNo", null, false, null, false), previousValues, webForm);
    }

}
