package com.lombardinternational.casedefinition.v2.adapter.api.web.dto;

public record ControlDefinitionRequest(WebForm webForm, ScreenDescription screenDescription) {
}
