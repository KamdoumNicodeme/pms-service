package com.lombardinternational.casedefinition.v2.domain.service;

import com.lombardinternational.casedefinition.v2.domain.api.PolicyService;
import com.lombardinternational.casedefinition.v2.domain.api.PolicyRoleService;
import com.lombardinternational.casedefinition.v2.domain.model.*;
import com.lombardinternational.casedefinition.v2.domain.spi.PolicyWebService;
import com.lombardinternational.casedefinition.v2.mapper.AbstractPersonMapper;
import com.lombardinternational.casedefinition.v2.mapper.PolicyMapper;
import com.lombardinternational.casedefinition.v2.mapper.PolicyRoleMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class PolicyServiceImpl implements PolicyService {
    private final PolicyWebService policyWebService;
    private final PolicyRoleMapper policyRoleMapper;
    private final PolicyMapper policyMapper;
    private final PolicyRoleService policyRoleService;
    private final AbstractPersonMapper abstractPersonMapper;

    @Override
    public Policy buildPolicy(String policyNumber) {
        Policy policy = policyMapper.map(policyWebService.getPolicy(policyNumber));
        if (policy.getNumber() == null) {
            policy.setNumber(policyNumber);
        }
        policyMapper.updatePolicyValues(policyWebService.getPolicyValues(policy.getNumber()), policy);

        buildPolicyRole(policy);
        buildPolicyLinks(policy);
        policy.setHolderAndEBODifferent(policyRoleService.policyRoleAreDifferent(policy.getHolders(), policy.getEconomicBeneficiaries()));
        policy.setHolderAndLifeAssuredDifferent(policyRoleService.policyRoleAreDifferent(policy.getHolders(), policy.getLifeAssureds()));
        policy.setBeneficiaryAndLifeAssuredDifferent(policyRoleService.policyRoleAreDifferent(policy.getBeneficiaries(), policy.getLifeAssureds()));
        return policy;
    }

    private void buildPolicyRole(Policy policy) {
        List<PolicyRole> policyRoles = policyRoleMapper.mapToList(policyWebService.getPolicyRole(policy.getNumber()));

        policy.setHolders(getSpecificRole(Holder.class, policyRoles));
        policy.setCessionHolders(getSpecificRole(CessionHolder.class, policyRoles));
        policy.setLifeAssureds(getSpecificRole(LifeAssured.class, policyRoles));
        policy.setEconomicBeneficiaries(getSpecificRole(EconomicBeneficiary.class, policyRoles));
        policy.setTrustees(getSpecificRole(Trustee.class, policyRoles));
        policy.setTrusts(getSpecificRole(Trust.class, policyRoles));
        policy.setProxies(getSpecificRole(Proxy.class, policyRoles));
        policy.setSettlors(getSpecificRole(Settlor.class, policyRoles));
        List<Beneficiary> beneficiaries = getSpecificRole(Beneficiary.class, policyRoles);
        policy.setBeneficiaries(beneficiaries.stream().filter(beneficiary -> !Boolean.TRUE.equals(beneficiary.getIrrevocableFlag())).collect(Collectors.toList()));
        policy.setIrrevocableBeneficiaries(beneficiaries.stream().filter(beneficiary -> Boolean.TRUE.equals(beneficiary.getIrrevocableFlag())).collect(Collectors.toList()));

        policy.setMoralPersons(policyRoles.stream().map(PolicyRole::getMoralPersons).flatMap(Collection::stream).distinct().collect(Collectors.toList()));
        policy.setPhysicalPersons(policyRoles.stream().map(PolicyRole::getPhysicalPersons).flatMap(Collection::stream).distinct().collect(Collectors.toList()));
    }

    private void buildPolicyLinks(Policy policy) {
        List<AbstractPerson> tpLinks = abstractPersonMapper.mapToList(policyWebService.getPolicyLinks(policy.getNumber()));
        PolicyLink policyLink = new PolicyLink();
        policyLink.setMoralPersons(tpLinks.stream().filter(MoralPerson.class::isInstance).map(MoralPerson.class::cast).collect(Collectors.toList()));
        policyLink.setPhysicalPersons(tpLinks.stream().filter(PhysicalPerson.class::isInstance).map(PhysicalPerson.class::cast).collect(Collectors.toList()));
        policy.setPolicyLinks(List.of(policyLink));
    }

    private <T extends PolicyRole> List<T> getSpecificRole(Class<T> classType, List<PolicyRole> roles) {
        return roles.stream()
                .filter(classType::isInstance)
                .map(classType::cast)
                .collect(Collectors.toList());
    }
}
