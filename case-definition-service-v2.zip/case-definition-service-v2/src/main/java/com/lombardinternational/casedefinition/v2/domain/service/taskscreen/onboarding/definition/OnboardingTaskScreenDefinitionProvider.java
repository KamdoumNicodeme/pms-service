package com.lombardinternational.casedefinition.v2.domain.service.taskscreen.onboarding.definition;

import org.springframework.stereotype.Service;

import com.lombardinternational.casedefinition.v2.domain.rules.onboarding.spec.FieldSpec;

import java.util.List;

@Service
public class OnboardingTaskScreenDefinitionProvider {

    public List<TabRule> tabs(String screenId) {
        return switch (screenId) {
            case "BAC_NEW_BUSINESS" -> bacNewBusinessTabs();
            case "COMPLEX_UNQ_NEW_BUSINESS" -> complexUnqNewBusinessTabs();
            case "COMPLIANCE_NEW_BUSINESS" -> complianceNewBusinessTabs();
            case "DOT_NEW_BUSINESS" -> dotNewBusinessTabs();
            case "EBAC_NEW_BUSINESS" -> ebacNewBusinessTabs();
            case "IC_NEW_BUSINESS" -> icNewBusinessTabs();
            case "INAD_ASSET_NEW_BUSINESS" -> inadAssetNewBusinessTabs();
            case "STRATEGY_MONITORING_NEW_BUSINESS" -> strategyMonitoringNewBusinessTabs();
            case "UNQUOTED_NEW_BUSINESS" -> unquotedNewBusinessTabs();
            default -> List.of();
        };
    }

    public List<GroupRule> groups(String screenId) {
        return switch (screenId) {
            case "BAC_NEW_BUSINESS" -> bacNewBusinessGroups();
            case "COMPLEX_UNQ_NEW_BUSINESS" -> complexUnqNewBusinessGroups();
            case "COMPLIANCE_NEW_BUSINESS" -> complianceNewBusinessGroups();
            case "DOT_NEW_BUSINESS" -> dotNewBusinessGroups();
            case "EBAC_NEW_BUSINESS" -> ebacNewBusinessGroups();
            case "IC_NEW_BUSINESS" -> icNewBusinessGroups();
            case "INAD_ASSET_NEW_BUSINESS" -> inadAssetNewBusinessGroups();
            case "STRATEGY_MONITORING_NEW_BUSINESS" -> strategyMonitoringNewBusinessGroups();
            case "UNQUOTED_NEW_BUSINESS" -> unquotedNewBusinessGroups();
            default -> List.of();
        };
    }

    public List<FieldRule> fields(String screenId) {
        return switch (screenId) {
            case "BAC_NEW_BUSINESS" -> bacNewBusinessFields();
            case "COMPLEX_UNQ_NEW_BUSINESS" -> complexUnqNewBusinessFields();
            case "COMPLIANCE_NEW_BUSINESS" -> complianceNewBusinessFields();
            case "DOT_NEW_BUSINESS" -> dotNewBusinessFields();
            case "EBAC_NEW_BUSINESS" -> ebacNewBusinessFields();
            case "IC_NEW_BUSINESS" -> icNewBusinessFields();
            case "INAD_ASSET_NEW_BUSINESS" -> inadAssetNewBusinessFields();
            case "STRATEGY_MONITORING_NEW_BUSINESS" -> strategyMonitoringNewBusinessFields();
            case "UNQUOTED_NEW_BUSINESS" -> unquotedNewBusinessFields();
            default -> List.of();
        };
    }

    private List<TabRule> bacNewBusinessTabs() {
        return List.of(
                new TabRule("BAC_NEW_BUSINESS", "TASKDEFINITION", "Task definition", "FormTab", 1, null)
        );
    }

    private List<TabRule> complexUnqNewBusinessTabs() {
        return List.of(
                new TabRule("COMPLEX_UNQ_NEW_BUSINESS", "INITIALISATION", "Initialisation", "FormTab", 1, null),
                new TabRule("COMPLEX_UNQ_NEW_BUSINESS", "TASKDEFINITION", "Task definition", "FormTab", 1, "#NUMBER_OF_COMPLEX# >= $")
        );
    }

    private List<TabRule> complianceNewBusinessTabs() {
        return List.of(
                new TabRule("COMPLIANCE_NEW_BUSINESS", "TASKDEFINITION", "Task definition", "FormTab", 1, null)
        );
    }

    private List<TabRule> dotNewBusinessTabs() {
        return List.of(
                new TabRule("DOT_NEW_BUSINESS", "TASKDEFINITION", "Task definition", "FormTab", 1, null)
        );
    }

    private List<TabRule> ebacNewBusinessTabs() {
        return List.of(
                new TabRule("EBAC_NEW_BUSINESS", "TASKDEFINITION", "Task definition", "FormTab", 1, null)
        );
    }

    private List<TabRule> icNewBusinessTabs() {
        return List.of(
                new TabRule("IC_NEW_BUSINESS", "TASKDEFINITION", "Task definition", "FormTab", 1, null)
        );
    }

    private List<TabRule> inadAssetNewBusinessTabs() {
        return List.of(
                new TabRule("INAD_ASSET_NEW_BUSINESS", "TASKDEFINITION", "Task definition", "FormTab", 1, null)
        );
    }

    private List<TabRule> strategyMonitoringNewBusinessTabs() {
        return List.of(
                new TabRule("STRATEGY_MONITORING_NEW_BUSINESS", "TASKDEFINITION", "Task definition", "FormTab", 1, null)
        );
    }

    private List<TabRule> unquotedNewBusinessTabs() {
        return List.of(
                new TabRule("UNQUOTED_NEW_BUSINESS", "TAB_NUMBER_UNQ", "Unquoted information", "FormTab", 0, null),
                new TabRule("UNQUOTED_NEW_BUSINESS", "TASKDEFINITION", "Task definition", "FormTab", 1, "#NUMBER_OF_UNQ# >= $ || #NUMBER_OF_UNQ_MANUAL# >= $")
        );
    }

    private List<GroupRule> bacNewBusinessGroups() {
        return List.of(
                new GroupRule("BAC_NEW_BUSINESS", "TASKDEFINITION", "CHECKLIST_DATA", "Physical BAC escalation", 1, 1, null)
        );
    }

    private List<GroupRule> complexUnqNewBusinessGroups() {
        return List.of(
                new GroupRule("COMPLEX_UNQ_NEW_BUSINESS", "TASKDEFINITION", "COMPLEX_ASSET_KYC", "Asset KYC documentation", 1, 2, null),
                new GroupRule("COMPLEX_UNQ_NEW_BUSINESS", "TASKDEFINITION", "COMPLEX_UNQ", "Details of complex asset", 1, 1, null),
                new GroupRule("COMPLEX_UNQ_NEW_BUSINESS", "TASKDEFINITION", "CPLX_RISK_SCORING", "Risk Scoring at Acceptance", 1, 3, null),
                new GroupRule("COMPLEX_UNQ_NEW_BUSINESS", "INITIALISATION", "DETAILS_COMPLEX", "Details of complex asset", 1, 1, null)
        );
    }

    private List<GroupRule> complianceNewBusinessGroups() {
        return List.of(
                new GroupRule("COMPLIANCE_NEW_BUSINESS", "TASKDEFINITION", "CHECKLIST_DATA", "General information", 1, 1, null)
        );
    }

    private List<GroupRule> dotNewBusinessGroups() {
        return List.of(
                new GroupRule("DOT_NEW_BUSINESS", "TASKDEFINITION", "GENERAL_INFORMATION", "General information", 1, 1, null),
                new GroupRule("DOT_NEW_BUSINESS", "TASKDEFINITION", "VALUATION", "Valuation", 2, 1, null)
        );
    }

    private List<GroupRule> ebacNewBusinessGroups() {
        return List.of(
                new GroupRule("EBAC_NEW_BUSINESS", "TASKDEFINITION", "CHECKLIST_DATA", "eBAC escalation", 1, 1, null)
        );
    }

    private List<GroupRule> icNewBusinessGroups() {
        return List.of(
                new GroupRule("IC_NEW_BUSINESS", "TASKDEFINITION", "CHECKLIST_DATA", "General information", 1, 1, null),
                new GroupRule("IC_NEW_BUSINESS", "TASKDEFINITION", "NTA", "Non Traditional Assets - Request NTA Acceptance", 3, 1, null),
                new GroupRule("IC_NEW_BUSINESS", "TASKDEFINITION", "DISTRESSED", "Distressed Assets - analyse asset and inform PCS of result", 4, 1, null),
                new GroupRule("IC_NEW_BUSINESS", "TASKDEFINITION", "INADMISSIBLE", "Inadmissible Assets in accordance with CAA Rules - inform PCS", 5, 1, null),
                new GroupRule("IC_NEW_BUSINESS", "TASKDEFINITION", "ASSETS_INADMISSIBLE", "Assets inadmissible due to country-specific investment rules", 6, 1, null),
                new GroupRule("IC_NEW_BUSINESS", "TASKDEFINITION", "ASSETS_NOT_PERMITTED", "Assets not permitted under the investment strategy", 7, 1, null),
                new GroupRule("IC_NEW_BUSINESS", "TASKDEFINITION", "COMPLEX_ASSETS", "Complex assets not permitted under limited IMA", 9, 1, null),
                new GroupRule("IC_NEW_BUSINESS", "TASKDEFINITION", "IDENTIFICATION_OF_ASSETS", "Identification of assets on the Watchlist?", 9, 1, null),
                new GroupRule("IC_NEW_BUSINESS", "TASKDEFINITION", "IDENTIFICATION_OF_SMALL_CAP", "Identification of small cap (market capitalisation lower than \u20ac 300 Mios)?", 10, 1, null),
                new GroupRule("IC_NEW_BUSINESS", "TASKDEFINITION", "IDENTIFICATION_OF_REGULATED_BUSINESS", "Identification of regulated business activity?", 11, 1, null),
                new GroupRule("IC_NEW_BUSINESS", "TASKDEFINITION", "DOCUMENTATION", null, 12, 1, null)
        );
    }

    private List<GroupRule> inadAssetNewBusinessGroups() {
        return List.of(
                new GroupRule("INAD_ASSET_NEW_BUSINESS", "TASKDEFINITION", "CHECKLIST_DATA", "Inadmissible Asset", 1, 1, null)
        );
    }

    private List<GroupRule> strategyMonitoringNewBusinessGroups() {
        return List.of(
                new GroupRule("STRATEGY_MONITORING_NEW_BUSINESS", "TASKDEFINITION", "CHECKLIST_DATA", "Strategy Monitoring", 1, 1, null)
        );
    }

    private List<GroupRule> unquotedNewBusinessGroups() {
        return List.of(
                new GroupRule("UNQUOTED_NEW_BUSINESS", "TAB_NUMBER_UNQ", "GROUP_NUMBER_UNQ", "General information", 1, 1, null),
                new GroupRule("UNQUOTED_NEW_BUSINESS", "TASKDEFINITION", "UNQUOTED", "Asset KYC documentation", 1, 1, null),
                new GroupRule("UNQUOTED_NEW_BUSINESS", "TASKDEFINITION", "ASSET_KYC", "Asset KYC documentation", 2, 1, null),
                new GroupRule("UNQUOTED_NEW_BUSINESS", "TASKDEFINITION", "WORLDCHECK", "Worldcheck", 3, 1, null),
                new GroupRule("UNQUOTED_NEW_BUSINESS", "TASKDEFINITION", "RISK", "Risk Scoring at Acceptance", 4, 1, null),
                new GroupRule("UNQUOTED_NEW_BUSINESS", "TASKDEFINITION", "NOTES", "Notes/PN/Bonds booking instruction", 5, 1, "#NTA_CATEGORY_$# == \"CAT1\" && (#SUB_TYPE_ONE_$# == \"NOTES\" || #SUB_TYPE_ONE_$# == \"DEBT\" || #SUB_TYPE_ONE_$# == \"PROM\")"),
                new GroupRule("UNQUOTED_NEW_BUSINESS", "TASKDEFINITION", "SHARES", "Shares/Units booking instruction", 5, 1, "#NTA_CATEGORY_$# == \"CAT2\" || #NTA_CATEGORY_$# == \"CAT3\" || (#NTA_CATEGORY_$# == \"CAT1\" && (#SUB_TYPE_ONE_$# != \"NOTES\" && #SUB_TYPE_ONE_$# != \"DEBT\" && #SUB_TYPE_ONE_$# != \"PROM\" && #SUB_TYPE_ONE_$# != \"\"))"),
                new GroupRule("UNQUOTED_NEW_BUSINESS", "TASKDEFINITION", "ASSET", "Asset set up", 6, 1, null)
        );
    }

    private List<FieldRule> bacNewBusinessFields() {
        return List.of(
                new FieldRule("BAC_NEW_BUSINESS", "CHECKLIST_DATA", "BAC_VALIDATION", "CheckBoxField", 1, "BAC Validation", true, true, null, null, false, null, false)
        );
    }

    private List<FieldRule> complexUnqNewBusinessFields() {
        return List.of(
                new FieldRule("COMPLEX_UNQ_NEW_BUSINESS", "COMPLEX_UNQ", "ASSET_DESC", "TextInputField", 1, "Asset description", true, true, null, null, false, null, true),
                new FieldRule("COMPLEX_UNQ_NEW_BUSINESS", "CPLX_RISK_SCORING", "CPLX_AMBER", "SelectInputField", 1, "Amber flag drivers", true, true, "SHAREHOLDING\u00acShareholding higher than 1%;INDIRECT\u00acIndirect MAR;OTHER\u00acOther", null, false, null, true),
                new FieldRule("COMPLEX_UNQ_NEW_BUSINESS", "COMPLEX_ASSET_KYC", "CPLX_BOD", "SelectInputField", 1, "The list of the BoD members of the company", true, true, "YES\u00acYes;NO\u00acNo;NA\u00acN/A", null, false, null, true),
                new FieldRule("COMPLEX_UNQ_NEW_BUSINESS", "DETAILS_COMPLEX", "NUMBER_OF_COMPLEX", "SelectInputField", 1, "Number of complex assets", true, true, "1;2;3;4;5;6;7;8;9;10", null, false, null, false),
                new FieldRule("COMPLEX_UNQ_NEW_BUSINESS", "CPLX_RISK_SCORING", "CPLX_AMBER_COMMENT", "TextAreaField", 2, "Comment", true, true, null, "#CPLX_AMBER_$# == \"OTHER\"", false, null, true),
                new FieldRule("COMPLEX_UNQ_NEW_BUSINESS", "COMPLEX_ASSET_KYC", "CPLX_CLIENT_INDEMNITY", "SelectInputField", 2, "Client indemnity letter for complex assets", true, true, "YES\u00acYes;NO\u00acNo;NA\u00acN/A", null, false, null, true),
                new FieldRule("COMPLEX_UNQ_NEW_BUSINESS", "COMPLEX_UNQ", "PRICING", "TextInputField", 2, "Pricing", true, false, null, null, false, null, true),
                new FieldRule("COMPLEX_UNQ_NEW_BUSINESS", "COMPLEX_ASSET_KYC", "CPLX_ADEQUATE_PROFILE", "SelectInputField", 3, "Adequate client investment profile / investment strategy", true, true, "YES\u00acYes;NO\u00acNo;NA\u00acN/A", null, false, null, true),
                new FieldRule("COMPLEX_UNQ_NEW_BUSINESS", "CPLX_RISK_SCORING", "CPLX_AMBER_RESULT", "SelectInputField", 3, "Result", true, true, "AMBER\u00acAmber;NA\u00acN/A", null, false, null, true),
                new FieldRule("COMPLEX_UNQ_NEW_BUSINESS", "COMPLEX_UNQ", "PRICING_EXCEPTION", "SelectInputField", 3, "Pricing exception", true, false, "YES\u00acYes;NO\u00acNo;NA\u00acN/A", null, false, null, true),
                new FieldRule("COMPLEX_UNQ_NEW_BUSINESS", "COMPLEX_ASSET_KYC", "CPLX_PROF_INVESTOR", "SelectInputField", 4, "Professional investor status", true, true, "YES\u00acYes;NO\u00acNo;NA\u00acN/A", null, false, null, true),
                new FieldRule("COMPLEX_UNQ_NEW_BUSINESS", "CPLX_RISK_SCORING", "CPLX_RED", "SelectInputField", 4, "Red flag drivers", true, true, "INSIDER\u00acInsider position;REGULATED\u00acRegulated Financial Entity;NO_AUTO\u00acNon-automated banks;LIMITED\u00acLimited IMA;OTHER\u00acOther", null, false, null, true),
                new FieldRule("COMPLEX_UNQ_NEW_BUSINESS", "COMPLEX_UNQ", "PRICING_COMMENT", "TextInputField", 4, "Comment", true, false, null, "#PRICING_EXCEPTION_$# == \"YES\"", false, null, true),
                new FieldRule("COMPLEX_UNQ_NEW_BUSINESS", "COMPLEX_UNQ", "COMPLEX_ASSET_TYPE", "SelectInputField", 5, "Complex asset type", true, true, "INSIDER\u00acInsider position;SHAREHOLDING\u00acShareholding higher than 1%;REGULATED\u00acRegulated Financial Entity;LARGEHOLDING\u00acLarge holding;OTHER\u00acOther", null, false, null, true),
                new FieldRule("COMPLEX_UNQ_NEW_BUSINESS", "COMPLEX_ASSET_KYC", "CPLX_KYC_COMMENT", "TextAreaField", 5, "Comments if any other documentation is applicable or if any of the above is N/A or if any waiver was granted", true, true, null, null, false, null, true),
                new FieldRule("COMPLEX_UNQ_NEW_BUSINESS", "CPLX_RISK_SCORING", "CPLX_RED_COMMENT", "TextAreaField", 5, "Comment", true, true, null, "#CPLX_RED_$# == \"OTHER\"", false, null, true),
                new FieldRule("COMPLEX_UNQ_NEW_BUSINESS", "COMPLEX_UNQ", "COMPLEX_ASSET_TYPE_COMMENT", "TextAreaField", 6, "Comment", true, false, null, "#COMPLEX_ASSET_TYPE_$# == \"OTHER\"", false, null, true),
                new FieldRule("COMPLEX_UNQ_NEW_BUSINESS", "COMPLEX_ASSET_KYC", "CPLX_PCS_CHECK", "SelectInputField", 6, "PCS / Compliance check", true, true, "YES\u00acYes;NO\u00acNo", null, false, null, true),
                new FieldRule("COMPLEX_UNQ_NEW_BUSINESS", "CPLX_RISK_SCORING", "CPLX_RED_RESULT", "SelectInputField", 6, "Result", true, true, "RED\u00acRed;NA\u00acN/A", null, false, null, true),
                new FieldRule("COMPLEX_UNQ_NEW_BUSINESS", "CPLX_RISK_SCORING", "CPLX_RISK_RATING", "SelectInputField", 7, "Risk rating assigned and sign-off required", true, true, "AMBER\u00acAmber case (Head of NTA Investments (or Backup) + Head of Investment Administration (or Backup));RED\u00acRed case (CIO + Head of NTA Investments (or Backup) + Head of Investment Administration (or Backup))", null, false, null, true),
                new FieldRule("COMPLEX_UNQ_NEW_BUSINESS", "COMPLEX_ASSET_KYC", "CPLX_WORLDCHECK", "SelectInputField", 7, "Worldcheck result", true, true, "PEP\u00acPEP;INSIDER\u00acInsider trading position;OTHER\u00acOther hits to be explained;NO_HIT\u00acNo hit found", null, false, null, true),
                new FieldRule("COMPLEX_UNQ_NEW_BUSINESS", "COMPLEX_UNQ", "REGISTRATION_TYPE", "SelectInputField", 7, "Registration type", true, true, "DIRECT\u00acDirect registration - administered by the custodian bank (nominatif administr\u00e9);NOMINEE\u00acNominee registration - on behalf of LIA - custodian bank Nominee;NOMINEE_THIRD\u00acNominee registration - on behalf of LIA- third party Nominee", null, false, null, true),
                new FieldRule("COMPLEX_UNQ_NEW_BUSINESS", "CPLX_RISK_SCORING", "CPLX_RISK_RATING_COMMENT", "TextAreaField", 8, "Risk rating assigned comments / mitigation action", true, true, null, null, false, null, true),
                new FieldRule("COMPLEX_UNQ_NEW_BUSINESS", "COMPLEX_ASSET_KYC", "CPLX_WORLDCHECK_COMMENT", "TextInputField", 8, "Comment", true, true, null, "#CPLX_WORLDCHECK_$# == \"OTHER\"", false, null, true),
                new FieldRule("COMPLEX_UNQ_NEW_BUSINESS", "COMPLEX_UNQ", "FCD_SIGNOFF", "SelectInputField", 8, "Full FCD sign-off", true, true, "YES\u00acYes;NO\u00acNo;NA\u00acN/A", null, false, null, true),
                new FieldRule("COMPLEX_UNQ_NEW_BUSINESS", "COMPLEX_UNQ", "FCD_COMMENT", "TextInputField", 9, "Comment", true, true, null, "#FCD_SIGNOFF_$# == \"NA\"", false, null, true),
                new FieldRule("COMPLEX_UNQ_NEW_BUSINESS", "COMPLEX_UNQ", "BAC_APPROVAL", "SelectInputField", 10, "BAC Approval & Date", true, true, "FULL\u00acFull Approval;COND\u00acConditional Approval;NA\u00acN/A", null, false, null, true),
                new FieldRule("COMPLEX_UNQ_NEW_BUSINESS", "COMPLEX_UNQ", "BAC_APPROVAL_DATE", "TextInputField", 11, "Date", true, true, null, "#BAC_APPROVAL_$# == \"FULL\" || #BAC_APPROVAL_$# == \"COND\"", false, null, true),
                new FieldRule("COMPLEX_UNQ_NEW_BUSINESS", "COMPLEX_UNQ", "BAC_APPROVAL_CONDITIONS", "TextAreaField", 12, "Please insert conditions of approval and any mitigation action to be implemented and followed-up", true, true, null, "#BAC_APPROVAL_$# == \"COND\"", false, null, true),
                new FieldRule("COMPLEX_UNQ_NEW_BUSINESS", "COMPLEX_UNQ", "BAC_APPROVAL_COMMENT", "TextAreaField", 13, "Comment", true, false, null, "#BAC_APPROVAL_$# == \"NA\"", false, null, true)
        );
    }

    private List<FieldRule> complianceNewBusinessFields() {
        return List.of(
                new FieldRule("COMPLIANCE_NEW_BUSINESS", "CHECKLIST_DATA", "TASK_RISK", "SelectInputField", 1, "Task Risk", true, false, "HIGH\u00acHigh;MEDIUM\u00acMedium;STANDARD\u00acStandard", null, false, null, false),
                new FieldRule("COMPLIANCE_NEW_BUSINESS", "CHECKLIST_DATA", "PCS_CHECKS", "SelectInputField", 2, "PCS checks performed on client(s) verification completed", true, false, "YES\u00acYes;NO\u00acNo", null, false, null, false),
                new FieldRule("COMPLIANCE_NEW_BUSINESS", "CHECKLIST_DATA", "COMPLIANCE_ADD_RESEARCH", "TextAreaField", 3, "Compliance additional research", true, false, null, null, false, null, false),
                new FieldRule("COMPLIANCE_NEW_BUSINESS", "CHECKLIST_DATA", "COMPLIANCE_RISK", "TextAreaField", 4, "Compliance risk assessment", true, false, null, null, false, null, false)
        );
    }

    private List<FieldRule> dotNewBusinessFields() {
        return List.of(
                new FieldRule("DOT_NEW_BUSINESS", "VALUATION", "CASH_CURRENT_ACCOUNT", "NumberInputField", 1, "Cash Current Account", true, false, null, null, false, null, false),
                new FieldRule("DOT_NEW_BUSINESS", "GENERAL_INFORMATION", "POLICY_CURRENCY", "TextInputField", 1, "Policy currency", false, false, "#forcedValue", null, false, null, false),
                new FieldRule("DOT_NEW_BUSINESS", "VALUATION", "CASH_CURRENT_ACCOUNT_CUR", "SelectInputField", 2, "Currency", true, false, "currenciesString", null, false, null, false),
                new FieldRule("DOT_NEW_BUSINESS", "GENERAL_INFORMATION", "CHECK_ASSET_REVIEWED", "SelectInputField", 2, "Check if assets have been reviewed by IC & make sure that portfolio submitted is on-line with the original portfolio analysed by IC If non-admissible assets -> do not included them in NBU value", true, false, "YES\u00acYes;NO\u00acNo", null, false, null, false),
                new FieldRule("DOT_NEW_BUSINESS", "GENERAL_INFORMATION", "ACC_DENO_DEFINED", "CheckBoxField", 3, "Make sure that account denomination has been defined with the FID number (NOT POLICY)", true, true, null, null, false, null, false),
                new FieldRule("DOT_NEW_BUSINESS", "VALUATION", "ASSET_VAL", "NumberInputField", 3, "Asset Valuation", true, false, null, null, false, null, false),
                new FieldRule("DOT_NEW_BUSINESS", "VALUATION", "ASSET_VAL_CUR", "SelectInputField", 4, "Currency", true, false, "currenciesString", null, false, null, false),
                new FieldRule("DOT_NEW_BUSINESS", "GENERAL_INFORMATION", "WHERE_ARE_ASSET", "SelectInputField", 4, "Where are the assets?", true, false, "PREM\u00acPremium;FUND\u00acFund;ILF\u00acILF", null, false, null, false),
                new FieldRule("DOT_NEW_BUSINESS", "GENERAL_INFORMATION", "PREPARE_TRANSFER", "CheckBoxField", 5, "Prepare transfer instruction", true, true, null, "#WHERE_ARE_ASSET# == \"PREM\"", false, null, false),
                new FieldRule("DOT_NEW_BUSINESS", "VALUATION", "TOTAL", "NumberInputField", 5, "Total", true, false, null, null, false, null, false),
                new FieldRule("DOT_NEW_BUSINESS", "GENERAL_INFORMATION", "ADD_NBU", "CheckBoxField", 6, "Add the NBU value in the CMT case", true, true, null, null, false, null, false),
                new FieldRule("DOT_NEW_BUSINESS", "VALUATION", "TOTAL_CUR", "SelectInputField", 6, "Currency", true, false, "currenciesString", null, false, null, false),
                new FieldRule("DOT_NEW_BUSINESS", "VALUATION", "ADD_PORTFOLIO", "CheckBoxField", 7, "Add bank portfolio with details of positions included in the NBU in CMT case IMPORTANT: Highlight clearly the positions to include in the booking of the NBU", true, true, null, null, false, null, false),
                new FieldRule("DOT_NEW_BUSINESS", "VALUATION", "ADD_NOTE", "CheckBoxField", 8, "If non-admissible assets/specificities: add a note in Xentis and put it in sensitive in Xentis", true, true, null, null, false, null, false),
                new FieldRule("DOT_NEW_BUSINESS", "VALUATION", "COMMENT", "TextAreaField", 9, "Comment", true, false, null, null, false, null, false)
        );
    }

    private List<FieldRule> ebacNewBusinessFields() {
        return List.of(
                new FieldRule("EBAC_NEW_BUSINESS", "CHECKLIST_DATA", "EBAC_VALIDATION", "CheckBoxField", 1, "BAC Validation", true, true, null, null, false, null, false)
        );
    }

    private List<FieldRule> icNewBusinessFields() {
        return List.of(
                new FieldRule("IC_NEW_BUSINESS", "NTA", "CONTAINED_IN_PORTFOLIO", "SelectInputField", 1, "Contained in the portfolio", true, true, "YES\u00acYes;NO\u00acNo", null, false, null, false),
                new FieldRule("IC_NEW_BUSINESS", "DISTRESSED", "CONTAINED_IN_PORTFOLIO_2", "SelectInputField", 1, "Contained in the portfolio", true, true, "YES\u00acYes;NO\u00acNo", null, false, null, false),
                new FieldRule("IC_NEW_BUSINESS", "INADMISSIBLE", "CONTAINED_IN_PORTFOLIO_3", "SelectInputField", 1, "Contained in the portfolio", true, true, "YES\u00acYes;NO\u00acNo", null, false, null, false),
                new FieldRule("IC_NEW_BUSINESS", "ASSETS_INADMISSIBLE", "CONTAINED_IN_PORTFOLIO_4", "SelectInputField", 1, "Contained in the portfolio", true, true, "YES\u00acYes;NO\u00acNo", null, false, null, false),
                new FieldRule("IC_NEW_BUSINESS", "ASSETS_NOT_PERMITTED", "CONTAINED_IN_PORTFOLIO_5", "SelectInputField", 1, "Contained in the portfolio", true, true, "YES\u00acYes;NO\u00acNo", null, false, null, false),
                new FieldRule("IC_NEW_BUSINESS", "COMPLEX_ASSETS", "CONTAINED_IN_PORTFOLIO_6", "SelectInputField", 1, "Contained in the portfolio", true, true, "YES\u00acYes;NO\u00acNo", null, false, null, false),
                new FieldRule("IC_NEW_BUSINESS", "IDENTIFICATION_OF_ASSETS", "CONTAINED_IN_PORTFOLIO_7", "SelectInputField", 1, "Contained in the portfolio", true, true, "YES\u00acYes;NO\u00acNo", null, false, null, false),
                new FieldRule("IC_NEW_BUSINESS", "IDENTIFICATION_OF_SMALL_CAP", "CONTAINED_IN_PORTFOLIO_8", "SelectInputField", 1, "Contained in the portfolio", true, true, "YES\u00acYes;NO\u00acNo", null, false, null, false),
                new FieldRule("IC_NEW_BUSINESS", "IDENTIFICATION_OF_REGULATED_BUSINESS", "CONTAINED_IN_PORTFOLIO_9", "SelectInputField", 1, "Contained in the portfolio", true, true, "YES\u00acYes;NO\u00acNo", null, false, null, false),
                new FieldRule("IC_NEW_BUSINESS", "DOCUMENTATION", "SUPPORTING_DOCUMENTATION", "SelectInputField", 1, "Supporting documentation on assets saved in Investment Compliance Portal", true, true, "YES\u00acYes;NO\u00acNo", null, false, null, false),
                new FieldRule("IC_NEW_BUSINESS", "NTA", "LIST_OF_ASSETS", "TextAreaField", 2, "List of Assets identified (Name / ISIN or similar identifier / CCY / Value)", true, true, null, "#CONTAINED_IN_PORTFOLIO# == \"YES\"", false, null, false),
                new FieldRule("IC_NEW_BUSINESS", "DISTRESSED", "LIST_OF_ASSETS_2", "TextAreaField", 2, "List of Assets identified (Name / ISIN or similar identifier / CCY / Value)", true, true, null, "#CONTAINED_IN_PORTFOLIO_2# == \"YES\"", false, null, false),
                new FieldRule("IC_NEW_BUSINESS", "INADMISSIBLE", "LIST_OF_ASSETS_3", "TextAreaField", 2, "List of Assets identified (Name / ISIN or similar identifier / CCY / Value)", true, true, null, "#CONTAINED_IN_PORTFOLIO_3# == \"YES\"", false, null, false),
                new FieldRule("IC_NEW_BUSINESS", "ASSETS_INADMISSIBLE", "LIST_OF_ASSETS_4", "TextAreaField", 2, "List of Assets identified (Name / ISIN or similar identifier / CCY / Value)", true, true, null, "#CONTAINED_IN_PORTFOLIO_4# == \"YES\"", false, null, false),
                new FieldRule("IC_NEW_BUSINESS", "ASSETS_NOT_PERMITTED", "LIST_OF_ASSETS_5", "TextAreaField", 2, "List of Assets identified (Name / ISIN or similar identifier / CCY / Value)", true, true, null, "#CONTAINED_IN_PORTFOLIO_5# == \"YES\"", false, null, false),
                new FieldRule("IC_NEW_BUSINESS", "COMPLEX_ASSETS", "LIST_OF_ASSETS_6", "TextAreaField", 2, "List of Assets identified (Name / ISIN or similar identifier / CCY / Value)", true, true, null, "#CONTAINED_IN_PORTFOLIO_6# == \"YES\"", false, null, false),
                new FieldRule("IC_NEW_BUSINESS", "IDENTIFICATION_OF_ASSETS", "LIST_OF_ASSETS_7", "TextAreaField", 2, "List of Assets identified (Name / ISIN or similar identifier / CCY / Value)", true, true, null, "#CONTAINED_IN_PORTFOLIO_7# == \"YES\"", false, null, false),
                new FieldRule("IC_NEW_BUSINESS", "IDENTIFICATION_OF_SMALL_CAP", "LIST_OF_ASSETS_8", "TextAreaField", 2, "List of Assets identified (Name / ISIN or similar identifier / CCY / Value)", true, true, null, "#CONTAINED_IN_PORTFOLIO_8# == \"YES\"", false, null, false),
                new FieldRule("IC_NEW_BUSINESS", "IDENTIFICATION_OF_REGULATED_BUSINESS", "LIST_OF_ASSETS_9", "TextAreaField", 2, "List of Assets identified (Name / ISIN or similar identifier / CCY / Value)", true, true, null, "#CONTAINED_IN_PORTFOLIO_9# == \"YES\"", false, null, false),
                new FieldRule("IC_NEW_BUSINESS", "DOCUMENTATION", "NOTES", "TextAreaField", 2, "Notes", true, false, null, null, false, null, false),
                new FieldRule("IC_NEW_BUSINESS", "NTA", "NTA_OR_PCS_INFORMED", "TextInputField", 3, "Date NTA or PCS informed", true, true, null, "#CONTAINED_IN_PORTFOLIO# == \"YES\"", false, null, false),
                new FieldRule("IC_NEW_BUSINESS", "DISTRESSED", "NTA_OR_PCS_INFORMED_2", "TextInputField", 3, "Date NTA or PCS informed", true, true, null, "#CONTAINED_IN_PORTFOLIO_2# == \"YES\"", false, null, false),
                new FieldRule("IC_NEW_BUSINESS", "INADMISSIBLE", "NTA_OR_PCS_INFORMED_3", "TextInputField", 3, "Date NTA or PCS informed", true, true, null, "#CONTAINED_IN_PORTFOLIO_3# == \"YES\"", false, null, false),
                new FieldRule("IC_NEW_BUSINESS", "ASSETS_INADMISSIBLE", "NTA_OR_PCS_INFORMED_4", "TextInputField", 3, "Date NTA or PCS informed", true, true, null, "#CONTAINED_IN_PORTFOLIO_4# == \"YES\"", false, null, false),
                new FieldRule("IC_NEW_BUSINESS", "ASSETS_NOT_PERMITTED", "NTA_OR_PCS_INFORMED_5", "TextInputField", 3, "Date NTA or PCS informed", true, true, null, "#CONTAINED_IN_PORTFOLIO_5# == \"YES\"", false, null, false),
                new FieldRule("IC_NEW_BUSINESS", "COMPLEX_ASSETS", "NTA_OR_PCS_INFORMED_6", "TextInputField", 3, "Date NTA or PCS informed", true, true, null, "#CONTAINED_IN_PORTFOLIO_6# == \"YES\"", false, null, false),
                new FieldRule("IC_NEW_BUSINESS", "IDENTIFICATION_OF_ASSETS", "NTA_OR_PCS_INFORMED_7", "TextInputField", 3, "Date NTA or PCS informed", true, true, null, "#CONTAINED_IN_PORTFOLIO_7# == \"YES\"", false, null, false),
                new FieldRule("IC_NEW_BUSINESS", "IDENTIFICATION_OF_SMALL_CAP", "NTA_OR_PCS_INFORMED_8", "TextInputField", 3, "Date NTA or PCS informed", true, true, null, "#CONTAINED_IN_PORTFOLIO_8# == \"YES\"", false, null, false),
                new FieldRule("IC_NEW_BUSINESS", "IDENTIFICATION_OF_REGULATED_BUSINESS", "NTA_OR_PCS_INFORMED_9", "TextInputField", 3, "Date NTA or PCS informed", true, true, null, "#CONTAINED_IN_PORTFOLIO_9# == \"YES\"", false, null, false),
                new FieldRule("IC_NEW_BUSINESS", "CHECKLIST_DATA", "PH_ASSETS_TRANSFERRED", "SelectInputField", 200, "Is the PH an insider to any assets transferred in?", false, false, "#forcedValue", null, false, null, false),
                new FieldRule("IC_NEW_BUSINESS", "CHECKLIST_DATA", "PH_ASSETS_TRANSFERRED_DENOMINATION", "TextInputField", 202, "Security Denomination", false, false, "#forcedValue", "#PH_ASSETS_TRANSFERRED# == \"YES\"", false, null, true),
                new FieldRule("IC_NEW_BUSINESS", "CHECKLIST_DATA", "PH_ASSETS_TRANSFERRED_ISIN", "TextInputField", 203, "ISIN", false, false, "#forcedValue", "#PH_ASSETS_TRANSFERRED# == \"YES\"", false, null, true),
                new FieldRule("IC_NEW_BUSINESS", "CHECKLIST_DATA", "INVESTMENT_MANAGER_DENOMINATION", "TextInputField", 500, "Investment Manager denomination", false, false, "#forcedValue", null, false, null, true),
                new FieldRule("IC_NEW_BUSINESS", "CHECKLIST_DATA", "INVESTMENT_MANAGER_MANDATE", "SelectInputField", 501, "Investment Manager mandate", true, false, "LIMITED\u00acLimited;UNLIMITED\u00acUnlimited;ADVISORY\u00acAdvisory;SELF_MANAGED\u00acSelf-managed", null, false, null, true),
                new FieldRule("IC_NEW_BUSINESS", "CHECKLIST_DATA", "INVESTMENT_STRATEGY", "TextInputField", 700, "Investment Strategy", true, false, null, null, false, null, false),
                new FieldRule("IC_NEW_BUSINESS", "CHECKLIST_DATA", "PROFESSIONAL_INVESTOR_FORM", "SelectInputField", 800, "Professional Investor Form signed", true, false, "YES\u00acYes;NO\u00acNo", null, false, null, false),
                new FieldRule("IC_NEW_BUSINESS", "CHECKLIST_DATA", "POLICY_TYPE_UNDER_CAA", "SelectInputField", 900, "Policy Type under the CAA Rules", true, false, "A\u00acA;B\u00acB;C\u00acC;D\u00acD", null, false, null, false),
                new FieldRule("IC_NEW_BUSINESS", "CHECKLIST_DATA", "ALTERNATIVE_INDEMNITY", "SelectInputField", 1000, "Alternative Indemnity signed", true, false, "YES\u00acYes;NO\u00acNo", null, false, null, false),
                new FieldRule("IC_NEW_BUSINESS", "CHECKLIST_DATA", "CUSTODIAN_BANK_DENOMINATION", "TextInputField", 1100, "Custodian bank denomination", false, false, "#forcedValue", null, false, null, true),
                new FieldRule("IC_NEW_BUSINESS", "CHECKLIST_DATA", "PORTFOLIO_VALUE", "NumberInputField", 1200, "Portfolio value as per bank statement", true, false, null, null, false, null, false),
                new FieldRule("IC_NEW_BUSINESS", "CHECKLIST_DATA", "PORTFOLIO_CUR", "SelectInputField", 1201, "Currency", true, false, "currenciesString", null, false, null, false),
                new FieldRule("IC_NEW_BUSINESS", "CHECKLIST_DATA", "EXPECTED_PREMIUM_VALUE", "NumberInputField", 1300, "Expected Premium if different from portfolio Value", true, false, null, null, false, null, false),
                new FieldRule("IC_NEW_BUSINESS", "CHECKLIST_DATA", "EXPECTED_PREMIUM_CUR", "SelectInputField", 1301, "Currency", true, false, "currenciesString", null, false, null, false),
                new FieldRule("IC_NEW_BUSINESS", "CHECKLIST_DATA", "IS_NTA_ASSET", "SelectInputField", 1400, "Is there any NTA assets?", false, false, "#forcedValue", null, false, null, false),
                new FieldRule("IC_NEW_BUSINESS", "CHECKLIST_DATA", "NB_NTA_ASSET", "SelectInputField", 1401, "Number of NTA", true, false, "1;2;3;4;5;6;7;8;9;10", "#IS_NTA_ASSET# >= \"YES\"", false, null, false),
                new FieldRule("IC_NEW_BUSINESS", "CHECKLIST_DATA", "NTA_TYPE_1", "TextInputField", 1402, "NTA Type #1", true, false, null, "#IS_NTA_ASSET# >= \"YES\" && #NB_NTA_ASSET# >= 1", false, null, false),
                new FieldRule("IC_NEW_BUSINESS", "CHECKLIST_DATA", "NTA_VALUE_1", "NumberInputField", 1403, "NTA expected value #1", true, false, null, "#IS_NTA_ASSET# >= \"YES\" && #NB_NTA_ASSET# >= 1", false, null, false),
                new FieldRule("IC_NEW_BUSINESS", "CHECKLIST_DATA", "NTA_VALUE_CUR_1", "SelectInputField", 1404, "Currency #1", true, false, "currenciesString", "#IS_NTA_ASSET# >= \"YES\" && #NB_NTA_ASSET# >= 1", false, null, false),
                new FieldRule("IC_NEW_BUSINESS", "CHECKLIST_DATA", "NTA_TYPE_2", "TextInputField", 1405, "NTA Type #2", true, false, null, "#IS_NTA_ASSET# >= \"YES\" && #NB_NTA_ASSET# >= 2", false, null, false),
                new FieldRule("IC_NEW_BUSINESS", "CHECKLIST_DATA", "NTA_VALUE_2", "NumberInputField", 1406, "NTA expected value #2", true, false, null, "#IS_NTA_ASSET# >= \"YES\" && #NB_NTA_ASSET# >= 2", false, null, false),
                new FieldRule("IC_NEW_BUSINESS", "CHECKLIST_DATA", "NTA_VALUE_CUR_2", "SelectInputField", 1407, "Currency #2", true, false, "currenciesString", "#IS_NTA_ASSET# >= \"YES\" && #NB_NTA_ASSET# >= 2", false, null, false),
                new FieldRule("IC_NEW_BUSINESS", "CHECKLIST_DATA", "NTA_TYPE_3", "TextInputField", 1408, "NTA Type #3", true, false, null, "#IS_NTA_ASSET# >= \"YES\" && #NB_NTA_ASSET# >= 3", false, null, false),
                new FieldRule("IC_NEW_BUSINESS", "CHECKLIST_DATA", "NTA_VALUE_3", "NumberInputField", 1409, "NTA expected value #3", true, false, null, "#IS_NTA_ASSET# >= \"YES\" && #NB_NTA_ASSET# >= 3", false, null, false),
                new FieldRule("IC_NEW_BUSINESS", "CHECKLIST_DATA", "NTA_VALUE_CUR_3", "SelectInputField", 1410, "Currency #3", true, false, "currenciesString", "#IS_NTA_ASSET# >= \"YES\" && #NB_NTA_ASSET# >= 3", false, null, false),
                new FieldRule("IC_NEW_BUSINESS", "CHECKLIST_DATA", "NTA_TYPE_4", "TextInputField", 1411, "NTA Type #4", true, false, null, "#IS_NTA_ASSET# >= \"YES\" && #NB_NTA_ASSET# >= 4", false, null, false),
                new FieldRule("IC_NEW_BUSINESS", "CHECKLIST_DATA", "NTA_VALUE_4", "NumberInputField", 1412, "NTA expected value #4", true, false, null, "#IS_NTA_ASSET# >= \"YES\" && #NB_NTA_ASSET# >= 4", false, null, false),
                new FieldRule("IC_NEW_BUSINESS", "CHECKLIST_DATA", "NTA_VALUE_CUR_4", "SelectInputField", 1413, "Currency #4", true, false, "currenciesString", "#IS_NTA_ASSET# >= \"YES\" && #NB_NTA_ASSET# >= 4", false, null, false),
                new FieldRule("IC_NEW_BUSINESS", "CHECKLIST_DATA", "NTA_TYPE_5", "TextInputField", 1414, "NTA Type #5", true, false, null, "#IS_NTA_ASSET# >= \"YES\" && #NB_NTA_ASSET# >= 5", false, null, false),
                new FieldRule("IC_NEW_BUSINESS", "CHECKLIST_DATA", "NTA_VALUE_5", "NumberInputField", 1415, "NTA expected value #5", true, false, null, "#IS_NTA_ASSET# >= \"YES\" && #NB_NTA_ASSET# >= 5", false, null, false),
                new FieldRule("IC_NEW_BUSINESS", "CHECKLIST_DATA", "NTA_VALUE_CUR_5", "SelectInputField", 1416, "Currency #5", true, false, "currenciesString", "#IS_NTA_ASSET# >= \"YES\" && #NB_NTA_ASSET# >= 5", false, null, false),
                new FieldRule("IC_NEW_BUSINESS", "CHECKLIST_DATA", "NTA_TYPE_6", "TextInputField", 1417, "NTA Type #6", true, false, null, "#IS_NTA_ASSET# >= \"YES\" && #NB_NTA_ASSET# >= 6", false, null, false),
                new FieldRule("IC_NEW_BUSINESS", "CHECKLIST_DATA", "NTA_VALUE_6", "NumberInputField", 1418, "NTA expected value #6", true, false, null, "#IS_NTA_ASSET# >= \"YES\" && #NB_NTA_ASSET# >= 6", false, null, false),
                new FieldRule("IC_NEW_BUSINESS", "CHECKLIST_DATA", "NTA_VALUE_CUR_6", "SelectInputField", 1419, "Currency #6", true, false, "currenciesString", "#IS_NTA_ASSET# >= \"YES\" && #NB_NTA_ASSET# >= 6", false, null, false),
                new FieldRule("IC_NEW_BUSINESS", "CHECKLIST_DATA", "NTA_TYPE_7", "TextInputField", 1420, "NTA Type #7", true, false, null, "#IS_NTA_ASSET# >= \"YES\" && #NB_NTA_ASSET# >= 7", false, null, false),
                new FieldRule("IC_NEW_BUSINESS", "CHECKLIST_DATA", "NTA_VALUE_7", "NumberInputField", 1421, "NTA expected value #7", true, false, null, "#IS_NTA_ASSET# >= \"YES\" && #NB_NTA_ASSET# >= 7", false, null, false),
                new FieldRule("IC_NEW_BUSINESS", "CHECKLIST_DATA", "NTA_VALUE_CUR_7", "SelectInputField", 1422, "Currency #7", true, false, "currenciesString", "#IS_NTA_ASSET# >= \"YES\" && #NB_NTA_ASSET# >= 7", false, null, false),
                new FieldRule("IC_NEW_BUSINESS", "CHECKLIST_DATA", "NTA_TYPE_8", "TextInputField", 1423, "NTA Type #8", true, false, null, "#IS_NTA_ASSET# >= \"YES\" && #NB_NTA_ASSET# >= 8", false, null, false),
                new FieldRule("IC_NEW_BUSINESS", "CHECKLIST_DATA", "NTA_VALUE_8", "NumberInputField", 1424, "NTA expected value #8", true, false, null, "#IS_NTA_ASSET# >= \"YES\" && #NB_NTA_ASSET# >= 8", false, null, false),
                new FieldRule("IC_NEW_BUSINESS", "CHECKLIST_DATA", "NTA_VALUE_CUR_8", "SelectInputField", 1425, "Currency #8", true, false, "currenciesString", "#IS_NTA_ASSET# >= \"YES\" && #NB_NTA_ASSET# >= 8", false, null, false),
                new FieldRule("IC_NEW_BUSINESS", "CHECKLIST_DATA", "NTA_TYPE_9", "TextInputField", 1426, "NTA Type #9", true, false, null, "#IS_NTA_ASSET# >= \"YES\" && #NB_NTA_ASSET# >= 9", false, null, false),
                new FieldRule("IC_NEW_BUSINESS", "CHECKLIST_DATA", "NTA_VALUE_9", "NumberInputField", 1427, "NTA expected value #9", true, false, null, "#IS_NTA_ASSET# >= \"YES\" && #NB_NTA_ASSET# >= 9", false, null, false),
                new FieldRule("IC_NEW_BUSINESS", "CHECKLIST_DATA", "NTA_VALUE_CUR_9", "SelectInputField", 1428, "Currency #9", true, false, "currenciesString", "#IS_NTA_ASSET# >= \"YES\" && #NB_NTA_ASSET# >= 9", false, null, false),
                new FieldRule("IC_NEW_BUSINESS", "CHECKLIST_DATA", "NTA_TYPE_10", "TextInputField", 1429, "NTA Type #10", true, false, null, "#IS_NTA_ASSET# >= \"YES\" && #NB_NTA_ASSET# >= 10", false, null, false),
                new FieldRule("IC_NEW_BUSINESS", "CHECKLIST_DATA", "NTA_VALUE_10", "NumberInputField", 1430, "NTA expected value #10", true, false, null, "#IS_NTA_ASSET# >= \"YES\" && #NB_NTA_ASSET# >= 10", false, null, false),
                new FieldRule("IC_NEW_BUSINESS", "CHECKLIST_DATA", "NTA_VALUE_CUR_10", "SelectInputField", 1431, "Currency #10", true, false, "currenciesString", "#IS_NTA_ASSET# >= \"YES\" && #NB_NTA_ASSET# >= 10", false, null, false),
                new FieldRule("IC_NEW_BUSINESS", "CHECKLIST_DATA", "DATE_STATEMENT", "TextInputField", 1500, "Date of portfolio statement", true, false, null, null, false, null, false),
                new FieldRule("IC_NEW_BUSINESS", "CHECKLIST_DATA", "MARKET_AND_TEAM", "TextInputField", 1600, "Market and PCS Team", false, false, "#forcedValue", null, false, null, false),
                new FieldRule("IC_NEW_BUSINESS", "CHECKLIST_DATA", "POLICY_NUMBER", "TextInputField", 1700, "Policy number", false, false, "#forcedValue", null, false, null, false),
                new FieldRule("IC_NEW_BUSINESS", "CHECKLIST_DATA", "POLICY_HOLDER_RESIDENCE_COUNTRY", "TextInputField", 1800, "Policy Holder residence country", false, false, "#forcedValue", null, false, null, false),
                new FieldRule("IC_NEW_BUSINESS", "CHECKLIST_DATA", "TRANSFERABLE_WEALTH_VALUE", "NumberInputField", 1900, "Transferable wealth of the policy holder in transferable securities", true, false, null, null, false, null, false),
                new FieldRule("IC_NEW_BUSINESS", "CHECKLIST_DATA", "TRANSFERABLE_WEALTH_CUR", "SelectInputField", 1910, "Currency", true, false, "currenciesString", null, false, null, false),
                new FieldRule("IC_NEW_BUSINESS", "CHECKLIST_DATA", "ELIGIBILITY_CHECK", "SelectInputField", 2000, "Eligibility check priority", true, false, "HIGH\u00acHigh (1 business day);MEDIUM\u00acMedium (3 business days);LOW\u00acMedium (1 week);NA\u00acN/A", null, false, null, false),
                new FieldRule("IC_NEW_BUSINESS", "CHECKLIST_DATA", "PORTFOLIO_STATEMENT", "CheckBoxField", 2100, "Portfolio statement including ISIN code securities denomination, quantity/nominal attached", true, false, null, null, false, null, false)
        );
    }

    private List<FieldRule> inadAssetNewBusinessFields() {
        return List.of(
                new FieldRule("INAD_ASSET_NEW_BUSINESS", "CHECKLIST_DATA", "INAD_ASSET", "CheckBoxField", 1, "Acknowledge & Advise IM/Partner about inadmissible asset", true, true, null, null, false, null, false)
        );
    }

    private List<FieldRule> strategyMonitoringNewBusinessFields() {
        return List.of(
                new FieldRule("STRATEGY_MONITORING_NEW_BUSINESS", "CHECKLIST_DATA", "INVEST_MANAGER_DESIGNATION", "TextInputField", 1, "Investment manager name", false, false, "#forcedValue", null, false, null, true),
                new FieldRule("STRATEGY_MONITORING_NEW_BUSINESS", "CHECKLIST_DATA", "INVEST_MANAGER_TYPE", "SelectInputField", 2, "Investment manager type", false, false, "#forcedValue", null, false, null, true),
                new FieldRule("STRATEGY_MONITORING_NEW_BUSINESS", "CHECKLIST_DATA", "RISK_PROFILE", "SelectInputField", 1000, "Risk profile", false, false, "#forcedValue", null, false, null, false),
                new FieldRule("STRATEGY_MONITORING_NEW_BUSINESS", "CHECKLIST_DATA", "POLICY_RISK_SCORE", "TextInputField", 1001, "Policy risk score (rounded)", false, false, "#forcedValue", null, false, null, false),
                new FieldRule("STRATEGY_MONITORING_NEW_BUSINESS", "CHECKLIST_DATA", "RISK_PROFILE_DEVIATION", "SelectInputField", 1002, "Deviation", false, false, "#forcedValue", null, false, null, false),
                new FieldRule("STRATEGY_MONITORING_NEW_BUSINESS", "CHECKLIST_DATA", "POLICY_TYPE", "SelectInputField", 1003, "Policy type", false, false, "#forcedValue", null, false, null, false),
                new FieldRule("STRATEGY_MONITORING_NEW_BUSINESS", "CHECKLIST_DATA", "PREFERENCE_ENVIRONMENTALLY", "SelectInputField", 1004, "ESG Preference - Environmentally sustainable investment", false, false, "#forcedValue", null, false, null, false),
                new FieldRule("STRATEGY_MONITORING_NEW_BUSINESS", "CHECKLIST_DATA", "PREFERENCE_INVESTMENT", "SelectInputField", 1005, "ESG Preference - Sustainable investment", false, false, "#forcedValue", null, false, null, false),
                new FieldRule("STRATEGY_MONITORING_NEW_BUSINESS", "CHECKLIST_DATA", "PREFERENCE_ADVERSE_IMPACTS", "SelectInputField", 1006, "ESG Preference - Product considering principal adverse impacts", false, false, "#forcedValue", null, false, null, false),
                new FieldRule("STRATEGY_MONITORING_NEW_BUSINESS", "CHECKLIST_DATA", "ESG_MANDATE_SELECTED", "SelectInputField", 1007, "Art. 8/9 ESG mandate selected?", false, false, "#forcedValue", null, false, null, true),
                new FieldRule("STRATEGY_MONITORING_NEW_BUSINESS", "CHECKLIST_DATA", "ESG_STRATEGY_NAME", "TextInputField", 1008, "ESG Stragegy Name", false, false, "#forcedValue", "#ESG_MANDATE_SELECTED_$# == \"YES_PRE_VALIDATED\" || #ESG_MANDATE_SELECTED_$# == \"YES_TO_BE_REVIEWED\"", false, null, true),
                new FieldRule("STRATEGY_MONITORING_NEW_BUSINESS", "CHECKLIST_DATA", "FURTHER_INFO", "TextAreaField", 2000, "Further information:", false, false, "#forcedValue", null, false, null, false),
                new FieldRule("STRATEGY_MONITORING_NEW_BUSINESS", "CHECKLIST_DATA", "STRATEGY_STATUS", "CheckBoxField", 2001, "Strategy review", true, true, null, null, false, null, false)
        );
    }

    private List<FieldRule> unquotedNewBusinessFields() {
        return List.of(
                new FieldRule("UNQUOTED_NEW_BUSINESS", "ASSET_KYC", "ART_INC", "SelectInputField", 1, "Article of Incorporation /Prospectus / LPA / Offering Memorandum", true, true, "YES\u00acYes;NO\u00acNo;NA\u00acN/A", "#NTA_CATEGORY_$# == \"CAT1\" && #SUB_TYPE_ONE_$# != \"\"", false, null, true),
                new FieldRule("UNQUOTED_NEW_BUSINESS", "ASSET", "ASSET_SET_UP", "SelectInputField", 1, "Asset Set up needed", true, true, "YES\u00acYes;NO\u00acNo", null, false, null, true),
                new FieldRule("UNQUOTED_NEW_BUSINESS", "RISK", "DOMICILE", "SelectInputField", 1, "Domicile (corresponding to the most restrictive one according to the look through principal until final target assets)", true, false, "ZONEA\u00acZone A _ 0pt;ZONEB\u00acZone B_ 1pt;ZONEC\u00acZone C _ 2pts", null, false, null, true),
                new FieldRule("UNQUOTED_NEW_BUSINESS", "NOTES", "N_B_ASSET_ID", "TextInputField", 1, "Asset ID (Xentis)", true, false, null, "#NTA_CATEGORY_$# == \"CAT1\" && (#SUB_TYPE_ONE_$# == \"NOTES\" || #SUB_TYPE_ONE_$# == \"DEBT\" || #SUB_TYPE_ONE_$# == \"PROM\")", false, null, true),
                new FieldRule("UNQUOTED_NEW_BUSINESS", "GROUP_NUMBER_UNQ", "NUMBER_OF_UNQ", "SelectInputField", 1, "Number of unquoted", true, false, "0;1;2;3;4;5;6;7;8;9;10", null, false, null, false),
                new FieldRule("UNQUOTED_NEW_BUSINESS", "GROUP_NUMBER_UNQ", "NUMBER_OF_UNQ_MANUAL", "SelectInputField", 1, "Number of unquoted (manual)", true, false, "1;2;3;4;5;6;7;8;9;10", null, false, null, false),
                new FieldRule("UNQUOTED_NEW_BUSINESS", "SHARES", "SHARES_ASSET_ID", "TextInputField", 1, "Asset ID (Xentis)", true, false, null, "#NTA_CATEGORY_$# == \"CAT2\" || #NTA_CATEGORY_$# == \"CAT3\" || (#NTA_CATEGORY_$# == \"CAT1\" && (#SUB_TYPE_ONE_$# != \"NOTES\" && #SUB_TYPE_ONE_$# != \"DEBT\" && #SUB_TYPE_ONE_$# != \"PROM\" && #SUB_TYPE_ONE_$# != \"\"))", false, null, true),
                new FieldRule("UNQUOTED_NEW_BUSINESS", "UNQUOTED", "UNQ_ASSET_ID", "TextInputField", 1, "UNQ Case ID (CMT reference)", true, true, "#forcedValue", null, false, null, true),
                new FieldRule("UNQUOTED_NEW_BUSINESS", "UNQUOTED", "ASSET_DESCRIPTION", "TextInputField", 2, "Asset description", true, true, "#forcedValue", null, false, null, true),
                new FieldRule("UNQUOTED_NEW_BUSINESS", "RISK", "DOMICILE_RESULT", "NumberInputField", 2, "Result", true, false, null, null, false, null, true),
                new FieldRule("UNQUOTED_NEW_BUSINESS", "NOTES", "N_B_PRICING", "SelectInputField", 2, "Pricing", true, true, "UNITS\u00acUnits;PERC\u00acPercentage", "#NTA_CATEGORY_$# == \"CAT1\" && (#SUB_TYPE_ONE_$# == \"NOTES\" || #SUB_TYPE_ONE_$# == \"DEBT\" || #SUB_TYPE_ONE_$# == \"PROM\")", false, null, true),
                new FieldRule("UNQUOTED_NEW_BUSINESS", "SHARES", "SHARES_MARKET_VALUE", "NumberInputField", 2, "Market Value", true, false, null, "#NTA_CATEGORY_$# == \"CAT2\" || #NTA_CATEGORY_$# == \"CAT3\" || (#NTA_CATEGORY_$# == \"CAT1\" && (#SUB_TYPE_ONE_$# != \"NOTES\" && #SUB_TYPE_ONE_$# != \"DEBT\" && #SUB_TYPE_ONE_$# != \"PROM\" && #SUB_TYPE_ONE_$# != \"\"))", false, null, true),
                new FieldRule("UNQUOTED_NEW_BUSINESS", "ASSET_KYC", "TRADE", "SelectInputField", 2, "Trade register extract / Certificate of Good standing", true, true, "YES\u00acYes;NO\u00acNo;NA\u00acN/A", "#NTA_CATEGORY_$# == \"CAT1\" && #SUB_TYPE_ONE_$# != \"\"", false, null, true),
                new FieldRule("UNQUOTED_NEW_BUSINESS", "ASSET_KYC", "AUDITED_ACCOUNTS", "SelectInputField", 3, "The 3 latest audited / certified accounts", true, true, "YES\u00acYes;NO\u00acNo;NA\u00acN/A", "(#NTA_CATEGORY_$# == \"CAT1\" && #SUB_TYPE_ONE_$# != \"\") || #NTA_CATEGORY_$# == \"CAT2\"", false, null, true),
                new FieldRule("UNQUOTED_NEW_BUSINESS", "RISK", "INVESTMENT_STRUCTURE", "SelectInputField", 3, "Investment Structure", true, false, "STRAIGHT\u00acStraigh forward structure _ 0 pt Police -> UQ Company -> final target investments;COMPLEX\u00acMore complex structure _ 1pt Police -> UQ Company -> SPV -> HoldCo -> final target investments;MORE_COMPLEX\u00acMore complex structure with leverage thru external financing/pleded assets _ 2pts;OTHER\u00acPolice -> UQ Company -> SPV -> HoldCo -> external financing -> final target investments/pledged", null, false, null, true),
                new FieldRule("UNQUOTED_NEW_BUSINESS", "NOTES", "N_B_MARKET_PRICE_UNITS_CUR", "SelectInputField", 3, "Currency", true, false, "currenciesString", "#N_B_PRICING_$# == \"UNITS\" && (#NTA_CATEGORY_$# == \"CAT1\" && (#SUB_TYPE_ONE_$# == \"NOTES\" || #SUB_TYPE_ONE_$# == \"DEBT\" || #SUB_TYPE_ONE_$# == \"PROM\"))", false, null, true),
                new FieldRule("UNQUOTED_NEW_BUSINESS", "UNQUOTED", "NTA_CATEGORY", "SelectInputField", 3, "NTA Category", true, true, "CAT1\u00acNTA Cat. 1 + 25% Mark-up;CAT2\u00acNTA Cat. 2 + 50% Mark-up;CAT3\u00acNTA Cat. 3 + 100% Mark-up;CAT4\u00acNTA Cat. 4", null, false, null, true),
                new FieldRule("UNQUOTED_NEW_BUSINESS", "SHARES", "SHARES_MARKET_VALUE_CUR", "SelectInputField", 3, "Currency", true, false, "currenciesString", "#NTA_CATEGORY_$# == \"CAT2\" || #NTA_CATEGORY_$# == \"CAT3\" || (#NTA_CATEGORY_$# == \"CAT1\" && (#SUB_TYPE_ONE_$# != \"NOTES\" && #SUB_TYPE_ONE_$# != \"DEBT\" && #SUB_TYPE_ONE_$# != \"PROM\" && #SUB_TYPE_ONE_$# != \"\"))", false, null, true),
                new FieldRule("UNQUOTED_NEW_BUSINESS", "RISK", "INVESTMENT_STRUCTURE_RESULT", "NumberInputField", 4, "Result", true, false, null, null, false, null, true),
                new FieldRule("UNQUOTED_NEW_BUSINESS", "ASSET_KYC", "MEMO_ART", "SelectInputField", 4, "Memorandum and Articles of Association", true, true, "YES\u00acYes;NO\u00acNo;NA\u00acN/A", "#NTA_CATEGORY_$# == \"CAT2\" || #NTA_CATEGORY_$# == \"CAT3\"", false, null, true),
                new FieldRule("UNQUOTED_NEW_BUSINESS", "NOTES", "N_B_MARKET_PRICE_UNITS", "NumberInputField", 4, "Market price per Units", true, false, null, "#N_B_PRICING_$# == \"UNITS\" && (#NTA_CATEGORY_$# == \"CAT1\" && (#SUB_TYPE_ONE_$# == \"NOTES\" || #SUB_TYPE_ONE_$# == \"DEBT\" || #SUB_TYPE_ONE_$# == \"PROM\"))", false, null, true),
                new FieldRule("UNQUOTED_NEW_BUSINESS", "UNQUOTED", "NTA_MARK_UP", "SelectInputField", 4, "NTA Mark-up exception", true, true, "YES\u00acYes;NO\u00acNo", null, false, null, true),
                new FieldRule("UNQUOTED_NEW_BUSINESS", "SHARES", "SHARES_QUANTITY_SHARES", "NumberInputField", 4, "Quantity of shares / Units", true, false, null, "#NTA_CATEGORY_$# == \"CAT2\" || #NTA_CATEGORY_$# == \"CAT3\" || (#NTA_CATEGORY_$# == \"CAT1\" && (#SUB_TYPE_ONE_$# != \"NOTES\" && #SUB_TYPE_ONE_$# != \"DEBT\" && #SUB_TYPE_ONE_$# != \"PROM\" && #SUB_TYPE_ONE_$# != \"\"))", false, null, true),
                new FieldRule("UNQUOTED_NEW_BUSINESS", "ASSET_KYC", "BOD", "SelectInputField", 5, "The list of the BoD members of the company / ID Cards of Signatories", true, true, "YES\u00acYes;NO\u00acNo;NA\u00acN/A", "(#NTA_CATEGORY_$# == \"CAT1\" && (#SUB_TYPE_ONE_$# == \"HOLD\" || #SUB_TYPE_ONE_$# == \"SHARES\" || #SUB_TYPE_ONE_$# == \"DEBT\" || #SUB_TYPE_ONE_$# == \"NOTES\" || #SUB_TYPE_ONE_$# == \"PROM\")) || #NTA_CATEGORY_$# == \"CAT2\" || #NTA_CATEGORY_$# == \"CAT3\"", false, null, true),
                new FieldRule("UNQUOTED_NEW_BUSINESS", "RISK", "CASE_SIZE", "SelectInputField", 5, "Case size (value of the OQ asset itself)", true, false, "ONE\u00ac0-EUR2.5Mios _ 0pt;TWO\u00acEUR2.5 Mios - EUR10 Mios _ 1pt;THREE\u00ac> EUR10 Mios _ 2pts", null, false, null, true),
                new FieldRule("UNQUOTED_NEW_BUSINESS", "NOTES", "N_B_QUANTITY", "NumberInputField", 5, "Quantity", true, false, null, "#N_B_PRICING_$# == \"UNITS\" && (#NTA_CATEGORY_$# == \"CAT1\" && (#SUB_TYPE_ONE_$# == \"NOTES\" || #SUB_TYPE_ONE_$# == \"DEBT\" || #SUB_TYPE_ONE_$# == \"PROM\"))", false, null, true),
                new FieldRule("UNQUOTED_NEW_BUSINESS", "UNQUOTED", "NTA_EXCEPTION", "TextAreaField", 5, "Please check the NTA Exception Log/Class", true, false, null, "#NTA_MARK_UP_$# == \"YES\"", false, null, true),
                new FieldRule("UNQUOTED_NEW_BUSINESS", "SHARES", "SHARES_MARKET_PRICE", "NumberInputField", 5, "Market price per shares / Unit", true, false, null, "#NTA_CATEGORY_$# == \"CAT2\" || #NTA_CATEGORY_$# == \"CAT3\" || (#NTA_CATEGORY_$# == \"CAT1\" && (#SUB_TYPE_ONE_$# != \"NOTES\" && #SUB_TYPE_ONE_$# != \"DEBT\" && #SUB_TYPE_ONE_$# != \"PROM\" && #SUB_TYPE_ONE_$# != \"\"))", false, null, true),
                new FieldRule("UNQUOTED_NEW_BUSINESS", "RISK", "CASE_SIZE_RESULT", "NumberInputField", 6, "Result", true, false, null, null, false, null, true),
                new FieldRule("UNQUOTED_NEW_BUSINESS", "NOTES", "N_B_MARKET_PRICE_PERCENTAGE", "NumberInputField", 6, "Market price in percentage", true, false, null, "#N_B_PRICING_$# == \"PERC\" && (#NTA_CATEGORY_$# == \"CAT1\" && (#SUB_TYPE_ONE_$# == \"NOTES\" || #SUB_TYPE_ONE_$# == \"DEBT\" || #SUB_TYPE_ONE_$# == \"PROM\"))", false, null, true),
                new FieldRule("UNQUOTED_NEW_BUSINESS", "ASSET_KYC", "SHAREHOLDERS_LIST", "SelectInputField", 6, "Shareholders / Investors list", true, true, "YES\u00acYes;NO\u00acNo;NA\u00acN/A", "(#NTA_CATEGORY_$# == \"CAT1\" && (#SUB_TYPE_ONE_$# != \"\" && #SUB_TYPE_ONE_$# != \"EU_PE_FUND\" && #SUB_TYPE_ONE_$# != \"UN_PE_FUND\" && #SUB_TYPE_ONE_$# != \"EU_RE_FUND\" && #SUB_TYPE_ONE_$# != \"UN_RE_FUND\")) || #NTA_CATEGORY_$# == \"CAT2\" || #NTA_CATEGORY_$# == \"CAT3\"", false, null, true),
                new FieldRule("UNQUOTED_NEW_BUSINESS", "SHARES", "SHARES_COMMITMENT_ASSET", "TextInputField", 6, "Commitment asset ID (Xentis)", true, false, null, "#NTA_CATEGORY_$# == \"CAT2\" || #NTA_CATEGORY_$# == \"CAT3\" || (#NTA_CATEGORY_$# == \"CAT1\" && (#SUB_TYPE_ONE_$# != \"NOTES\" && #SUB_TYPE_ONE_$# != \"DEBT\" && #SUB_TYPE_ONE_$# != \"PROM\" && #SUB_TYPE_ONE_$# != \"\"))", false, null, true),
                new FieldRule("UNQUOTED_NEW_BUSINESS", "UNQUOTED", "SUB_TYPE_FOUR", "SelectInputField", 6, "NTA Asset Sub-Type", true, true, "NOTES\u00acNotes - Bonds Unquoted;DEBT\u00acDebt instrument;PROM\u00acPromissory Note;HOLD\u00acFinancial Holding Company;EU_PE_FUND\u00acEU regulated PE fund;UN_PE_FUND\u00acUn-regulated PE fund;EU_RE_FUND\u00acEU regulated RE Fund;UN_RE_FUND\u00acUn-regulated RE fund;SHARES\u00acShares listed on an unregulated market place;REAL\u00acReal Estate - (RE directly held by Co.);IND_REAL\u00acIndirect Real Estate Holding Company;UQ_BONDS\u00acRE UQ Bonds;TRADING\u00acTrading Company;INDIRECT\u00acIndirect Trading Co", "#NTA_CATEGORY_$# == \"CAT4\"", false, null, true),
                new FieldRule("UNQUOTED_NEW_BUSINESS", "UNQUOTED", "SUB_TYPE_ONE", "SelectInputField", 6, "NTA Asset Sub-Type", true, true, "NOTES\u00acNotes - Bonds Unquoted;DEBT\u00acDebt instrument;PROM\u00acPromissory Note;HOLD\u00acFinancial Holding Company;EU_PE_FUND\u00acEU regulated PE fund;UN_PE_FUND\u00acUn-regulated PE fund;EU_RE_FUND\u00acEU regulated RE Fund;UN_RE_FUND\u00acUn-regulated RE fund;SHARES\u00acShares listed on an unregulated market place", "#NTA_CATEGORY_$# == \"CAT1\"", false, null, true),
                new FieldRule("UNQUOTED_NEW_BUSINESS", "UNQUOTED", "SUB_TYPE_THREE", "SelectInputField", 6, "NTA Asset Sub-Type", true, true, "TRADING\u00acTrading Company;INDIRECT\u00acIndirect Trading Co", "#NTA_CATEGORY_$# == \"CAT3\"", false, null, true),
                new FieldRule("UNQUOTED_NEW_BUSINESS", "UNQUOTED", "SUB_TYPE_TWO", "SelectInputField", 6, "NTA Asset Sub-Type", true, true, "REAL\u00acReal Estate - (RE directly held by Co.);IND_REAL\u00acIndirect Real Estate Holding Company;UQ_BONDS\u00acRE UQ Bonds", "#NTA_CATEGORY_$# == \"CAT2\"", false, null, true),
                new FieldRule("UNQUOTED_NEW_BUSINESS", "UNQUOTED", "ADMINISTRATOR", "TextAreaField", 7, "Administrator denomination and contact details", true, true, null, null, false, null, true),
                new FieldRule("UNQUOTED_NEW_BUSINESS", "NOTES", "N_B_NOMINAL_AMOUNT", "NumberInputField", 7, "Nominal amount", true, false, null, "#NTA_CATEGORY_$# == \"CAT1\" && (#SUB_TYPE_ONE_$# == \"NOTES\" || #SUB_TYPE_ONE_$# == \"DEBT\" || #SUB_TYPE_ONE_$# == \"PROM\")", false, null, true),
                new FieldRule("UNQUOTED_NEW_BUSINESS", "ASSET_KYC", "SHAREHOLDERS_AGREEMENT", "SelectInputField", 7, "Shareholders agreement", true, true, "YES\u00acYes;NO\u00acNo;NA\u00acN/A", "(#NTA_CATEGORY_$# == \"CAT1\" && (#SUB_TYPE_ONE_$# == \"HOLD\" || #SUB_TYPE_ONE_$# == \"SHARES\")) || #NTA_CATEGORY_$# == \"CAT3\"", false, null, true),
                new FieldRule("UNQUOTED_NEW_BUSINESS", "SHARES", "SHARES_COMMITMENT_AMOUNT", "NumberInputField", 7, "Commitment Amount", true, false, null, "#NTA_CATEGORY_$# == \"CAT2\" || #NTA_CATEGORY_$# == \"CAT3\" || (#NTA_CATEGORY_$# == \"CAT1\" && (#SUB_TYPE_ONE_$# != \"NOTES\" && #SUB_TYPE_ONE_$# != \"DEBT\" && #SUB_TYPE_ONE_$# != \"PROM\" && #SUB_TYPE_ONE_$# != \"\"))", false, null, true),
                new FieldRule("UNQUOTED_NEW_BUSINESS", "RISK", "UQ_ASSET_TYPE", "SelectInputField", 7, "UQ asset type", true, false, "REG\u00acRegulated PE funds- Zone A _ 0pt;DEBT\u00acDebt instruments (PN - PPL - Loans\u2026) other PE funds _ 1pt;FHC\u00acFHC - RE - Trading _ 2 pts", null, false, null, true),
                new FieldRule("UNQUOTED_NEW_BUSINESS", "NOTES", "N_B_ACCRUED_INTEREST", "NumberInputField", 8, "Accrued interest", true, false, null, "#NTA_CATEGORY_$# == \"CAT1\" && (#SUB_TYPE_ONE_$# == \"NOTES\" || #SUB_TYPE_ONE_$# == \"DEBT\" || #SUB_TYPE_ONE_$# == \"PROM\")", false, null, true),
                new FieldRule("UNQUOTED_NEW_BUSINESS", "UNQUOTED", "REGISTRATION", "SelectInputField", 8, "Registration type", true, true, "NOMINATIVE\u00acDirect nominative registration of LIA;DIRECT\u00acDirect registration - administered by the custodian bank (nominatif administre);NOMINEE_CUST\u00acNominee registration - on behalf of LIA - custodian bank Nominee;NOMINEE_THIRD\u00acNominee registration - on behalf of LIA - third party Nominee", null, false, null, true),
                new FieldRule("UNQUOTED_NEW_BUSINESS", "RISK", "UQ_ASSET_TYPE_RESULT", "NumberInputField", 8, "Result", true, false, null, null, false, null, true),
                new FieldRule("UNQUOTED_NEW_BUSINESS", "ASSET_KYC", "DETAILED_ACTIVITY", "SelectInputField", 9, "Detailed business activity and use of funds", true, true, "YES\u00acYes;NO\u00acNo;NA\u00acN/A", "(#NTA_CATEGORY_$# == \"CAT1\" && (#SUB_TYPE_ONE_$# == \"NOTES\" || #SUB_TYPE_ONE_$# == \"DEBT\" || #SUB_TYPE_ONE_$# == \"PROM\" || #SUB_TYPE_ONE_$# == \"HOLD\")) || #NTA_CATEGORY_$# == \"CAT2\" || #NTA_CATEGORY_$# == \"CAT3\"", false, null, true),
                new FieldRule("UNQUOTED_NEW_BUSINESS", "UNQUOTED", "FCD_SIGN_OFF", "SelectInputField", 9, "FCD Sign Off", true, true, "FULL\u00acFull FCD;LIGHT\u00acLight FCD;NA\u00acN/A", null, false, null, true),
                new FieldRule("UNQUOTED_NEW_BUSINESS", "NOTES", "N_B_COMMITMENT_AMOUNT", "NumberInputField", 9, "Commitment amount", true, false, null, "#NTA_CATEGORY_$# == \"CAT1\" && (#SUB_TYPE_ONE_$# == \"NOTES\" || #SUB_TYPE_ONE_$# == \"DEBT\" || #SUB_TYPE_ONE_$# == \"PROM\")", false, null, true),
                new FieldRule("UNQUOTED_NEW_BUSINESS", "ASSET_KYC", "RE_PROPERTIES", "SelectInputField", 9, "A statement of RE properties", true, true, "YES\u00acYes;NO\u00acNo;NA\u00acN/A", "#NTA_CATEGORY_$# == \"CAT2\"", false, null, true),
                new FieldRule("UNQUOTED_NEW_BUSINESS", "RISK", "RELIABILITY", "SelectInputField", 9, "Reliability of underlying administrators", true, false, "SUB\u00acSusidiaires or affiliates of major financial Instritution / Big4 auditors _ 0pt;MED\u00acMedium Lux fiduciaries under regulation of CSSF (FTE >20) _ 1pt;OTHER\u00acOther or Small Fiduciaries (FTE <20)/ not cooperative _ 2 pts", null, false, null, true),
                new FieldRule("UNQUOTED_NEW_BUSINESS", "UNQUOTED", "FCD_SIGN_OFF_NA", "TextAreaField", 10, "Full FCD sign-off N/A note #1", true, false, null, "#FCD_SIGN_OFF_$# == \"NA\"", false, null, true),
                new FieldRule("UNQUOTED_NEW_BUSINESS", "NOTES", "N_B_COMMITMENT_ASSET", "TextInputField", 10, "Commitment asset ID (Xentis)", true, false, null, "#NTA_CATEGORY_$# == \"CAT1\" && (#SUB_TYPE_ONE_$# == \"NOTES\" || #SUB_TYPE_ONE_$# == \"DEBT\" || #SUB_TYPE_ONE_$# == \"PROM\")", false, null, true),
                new FieldRule("UNQUOTED_NEW_BUSINESS", "RISK", "RELIABILITY_RESULT", "NumberInputField", 10, "Result", true, false, null, null, false, null, true),
                new FieldRule("UNQUOTED_NEW_BUSINESS", "ASSET_KYC", "TERM_SHEET", "SelectInputField", 10, "Term sheet of the debt instrument (e.g. debt/PN agreement)", true, true, "YES\u00acYes;NO\u00acNo;NA\u00acN/A", "(#NTA_CATEGORY_$# == \"CAT1\" && (#SUB_TYPE_ONE_$# == \"NOTES\" || #SUB_TYPE_ONE_$# == \"DEBT\" || #SUB_TYPE_ONE_$# == \"PROM\")) || #NTA_CATEGORY_$# == \"CAT2\"", false, null, true),
                new FieldRule("UNQUOTED_NEW_BUSINESS", "WORLDCHECK", "WORLDCHECK_CLEARED", "SelectInputField", 10, "Worldcheck to be performed", true, true, "YES\u00acYes;NO\u00acNo", null, false, null, true),
                new FieldRule("UNQUOTED_NEW_BUSINESS", "UNQUOTED", "BAC_APPROVAL", "SelectInputField", 11, "BAC Approval & Date", true, true, "FULL\u00acFull Approval;CONDITIONAL\u00acConditional Approval;NA\u00acN/A", null, false, null, true),
                new FieldRule("UNQUOTED_NEW_BUSINESS", "ASSET_KYC", "CONFIRMATION_ARM", "SelectInputField", 11, "Confirmation of arm\u2019s length pricing of the interest rate", true, true, "YES\u00acYes;NO\u00acNo;NA\u00acN/A", "(#NTA_CATEGORY_$# == \"CAT1\" && (#SUB_TYPE_ONE_$# == \"NOTES\" || #SUB_TYPE_ONE_$# == \"DEBT\" || #SUB_TYPE_ONE_$# == \"PROM\")) || #NTA_CATEGORY_$# == \"CAT2\"", false, null, true),
                new FieldRule("UNQUOTED_NEW_BUSINESS", "RISK", "REPORTING_QUALITY", "SelectInputField", 11, "Quality of reporting", true, false, "IFRS\u00acAudited IFRS reports / Big4 _ 0pt;AUDITED\u00acAudited - Finanacial reports with detailed notes until final target investments _ 1pt;UNAUDITED\u00acUnaudited report or audited report without any detailed notes _ 2pts", null, false, null, true),
                new FieldRule("UNQUOTED_NEW_BUSINESS", "WORLDCHECK", "WORLDCHECK_REASON", "SelectInputField", 11, "Reason", true, false, "EU\u00acEU regulated fund under the supervision of an equivalent authorita as the CSSF;OWNER\u00acLIA's ownership lower than 10%;AVAILABLE\u00acThe Directors of the company are made available by regulated corporate service provider being under the supervision of the CSSF or any equivalent authority", "#WORLDCHECK_CLEARED_$# == \"NO\"", false, null, true),
                new FieldRule("UNQUOTED_NEW_BUSINESS", "UNQUOTED", "BAC_DATE", "TextInputField", 12, "BAC Approval Date", true, true, null, "(#BAC_APPROVAL_$# == \"FULL\" || #BAC_APPROVAL_$# == \"CONDITIONAL\")", false, null, true),
                new FieldRule("UNQUOTED_NEW_BUSINESS", "ASSET_KYC", "INVESTMENT_CHART", "SelectInputField", 12, "Investment chart", true, true, "YES\u00acYes;NO\u00acNo;NA\u00acN/A", "(#NTA_CATEGORY_$# == \"CAT1\" && (#SUB_TYPE_ONE_$# != \"SHARES\" && #SUB_TYPE_ONE_$# != \"\")) || #NTA_CATEGORY_$# == \"CAT2\" || #NTA_CATEGORY_$# == \"CAT3\"", false, null, true),
                new FieldRule("UNQUOTED_NEW_BUSINESS", "RISK", "REPORTING_QUALITY_RESULT", "NumberInputField", 12, "Result", true, false, null, null, false, null, true),
                new FieldRule("UNQUOTED_NEW_BUSINESS", "WORLDCHECK", "WORLDCHECK_RESULT", "SelectInputField", 12, "Result", true, false, "DIRECTORS\u00acDirectors or Managers are PEP;INSIDER\u00acInsider trading position;OTHER\u00acOther hits to be explained;NO_HIT\u00acNo hit found", "#WORLDCHECK_CLEARED_$# == \"YES\"", false, null, true),
                new FieldRule("UNQUOTED_NEW_BUSINESS", "WORLDCHECK", "BACKGROUND_NO_HIT", "TextAreaField", 13, "Please explain mitigation actions agreed with FCC team", true, false, null, "(#WORLDCHECK_RESULT_$# != \"NO_HIT\" && #WORLDCHECK_RESULT_$# != \"\") && #WORLDCHECK_CLEARED_$# == \"YES\"", false, null, true),
                new FieldRule("UNQUOTED_NEW_BUSINESS", "WORLDCHECK", "BACKGROUND_OTHER_HIT", "TextAreaField", 13, "Please explain other HIT found", true, false, null, "#WORLDCHECK_RESULT_$# == \"OTHER\"", false, null, true),
                new FieldRule("UNQUOTED_NEW_BUSINESS", "UNQUOTED", "CONDITIONS", "TextAreaField", 13, "Please insert conditions of  approval and any mitigation action to be implemented and followed-up", true, true, null, "#BAC_APPROVAL_$# == \"CONDITIONAL\"", false, null, true),
                new FieldRule("UNQUOTED_NEW_BUSINESS", "ASSET_KYC", "LETTER_INTENT", "SelectInputField", 13, "Letter of intent & disclosure agreement", true, true, "YES\u00acYes;NO\u00acNo;NA\u00acN/A", "(#NTA_CATEGORY_$# == \"CAT1\" && (#SUB_TYPE_ONE_$# == \"NOTES\" || #SUB_TYPE_ONE_$# == \"DEBT\" || #SUB_TYPE_ONE_$# == \"PROM\" || #SUB_TYPE_ONE_$# == \"HOLD\")) || #NTA_CATEGORY_$# == \"CAT2\" || #NTA_CATEGORY_$# == \"CAT3\"", false, null, true),
                new FieldRule("UNQUOTED_NEW_BUSINESS", "RISK", "OWNERSHIP_EVIDENCE", "SelectInputField", 13, "Ownership evidence / reconcilitation", true, false, "NO_DISCREPANCY\u00acOwnership evidence until final tardet is complete - no reconciliation discrepancy _ 0pt;COMPLETE_DISCREPANCY\u00acOwnership evidence until final tardet is complete - reconciliation discrepancy noticed _ 1pt;NOT_COMPLETE_DISCREPANCY\u00acOwnership evidence until final tardet not complete - reconciliation discrepancy noticed _ 2pt", null, false, null, true),
                new FieldRule("UNQUOTED_NEW_BUSINESS", "UNQUOTED", "BAC_NA", "TextAreaField", 14, "Explanation", true, false, null, "#BAC_APPROVAL_$# == \"NA\"", false, null, true),
                new FieldRule("UNQUOTED_NEW_BUSINESS", "RISK", "OWNERSHIP_EVIDENCE_RESULT", "NumberInputField", 14, "Result", true, false, null, null, false, null, true),
                new FieldRule("UNQUOTED_NEW_BUSINESS", "ASSET_KYC", "WARRANTY_LETTER", "SelectInputField", 14, "Warranty letter", true, true, "YES\u00acYes;NO\u00acNo;NA\u00acN/A", "(#NTA_CATEGORY_$# == \"CAT1\" && (#SUB_TYPE_ONE_$# == \"NOTES\" || #SUB_TYPE_ONE_$# == \"DEBT\" || #SUB_TYPE_ONE_$# == \"PROM\" || #SUB_TYPE_ONE_$# == \"HOLD\")) || #NTA_CATEGORY_$# == \"CAT2\" || #NTA_CATEGORY_$# == \"CAT3\"", false, null, true),
                new FieldRule("UNQUOTED_NEW_BUSINESS", "RISK", "FINANCIAL_SITUATION", "SelectInputField", 15, "Fianancial situation of company", true, false, "STRING\u00acStrong financial position - positive result on a aggregate basis _ 0pt;MEDIUM\u00acMedium finanacial position - based on fair value no permanent impairment _ 1pt;BAD\u00acBad financial position - Negative Net Equity -permanet impairment _ 2pts", null, false, null, true),
                new FieldRule("UNQUOTED_NEW_BUSINESS", "ASSET_KYC", "VALUATION_DOC", "SelectInputField", 15, "Valuation documentation", true, true, "YES\u00acYes;NO\u00acNo;NA\u00acN/A", "(#NTA_CATEGORY_$# == \"CAT1\" && #SUB_TYPE_ONE_$# != \"\") || #NTA_CATEGORY_$# == \"CAT2\" || #NTA_CATEGORY_$# == \"CAT3\"", false, null, true),
                new FieldRule("UNQUOTED_NEW_BUSINESS", "RISK", "FINANCIAL_SITUATION_RESULT", "NumberInputField", 16, "Result", true, false, null, null, false, null, true),
                new FieldRule("UNQUOTED_NEW_BUSINESS", "ASSET_KYC", "TRANSFERABILITY_LETTER", "SelectInputField", 16, "Transferability letter", true, true, "YES\u00acYes;NO\u00acNo;NA\u00acN/A", "(#NTA_CATEGORY_$# == \"CAT1\" && #SUB_TYPE_ONE_$# != \"\" && #SUB_TYPE_ONE_$# != \"SHARES\") || #NTA_CATEGORY_$# == \"CAT2\" || #NTA_CATEGORY_$# == \"CAT3\"", false, null, true),
                new FieldRule("UNQUOTED_NEW_BUSINESS", "ASSET_KYC", "CLIENT_INDEMNITY", "SelectInputField", 17, "Client indemnity letter", true, true, "YES\u00acYes;NO\u00acNo;NA\u00acN/A", "(#NTA_CATEGORY_$# == \"CAT1\" && #SUB_TYPE_ONE_$# != \"\") || #NTA_CATEGORY_$# == \"CAT2\" || #NTA_CATEGORY_$# == \"CAT3\"", false, null, true),
                new FieldRule("UNQUOTED_NEW_BUSINESS", "RISK", "RED_FLAG_DRIVERS", "SelectInputField", 17, "Red flag drivers", true, false, "RISK_ACTIVITY\u00acHigh risk business activity;PEP\u00acBoD members or representatives of UQ asset are reported as PEP or a hit was found on Worldcheck;INTEREST\u00acCarried interest shares;NA\u00acN/A", null, false, null, true),
                new FieldRule("UNQUOTED_NEW_BUSINESS", "RISK", "RED_FLAG_DRIVERS_RESULT", "SelectInputField", 18, "Result", true, false, "RED\u00acRed;NA\u00acN/A", null, false, null, true),
                new FieldRule("UNQUOTED_NEW_BUSINESS", "ASSET_KYC", "ADEQUATE_PROFILE", "SelectInputField", 19, "Adquate client investment profile / investment strategy", true, true, "YES\u00acYes;NO\u00acNo;NA\u00acN/A", "(#NTA_CATEGORY_$# == \"CAT1\" && #SUB_TYPE_ONE_$# != \"\") || #NTA_CATEGORY_$# == \"CAT2\" || #NTA_CATEGORY_$# == \"CAT3\"", false, null, true),
                new FieldRule("UNQUOTED_NEW_BUSINESS", "RISK", "AMBER_FLAG_DRIVERS", "SelectInputField", 19, "Amber flag drivers", true, false, "INVOLVE1\u00acHas PH direct involvement in the management of companies which forms part of structure (Only apply for the market where influence of the PH over the assets might lead to tax requalification of the policy);CLAUSE\u00acAny specific clause in the STA/SPA that would expose the Insurer to the risk of compensating creditors of the company / tax authorities or third parties related to the unquoted assets;INVOLVE2\u00acHas PH direct involvement in the management of a listed company which forms part of structure (insider trading risk);REPORTABLE\u00acReportable asset (for tax purpose / large holding / or any other potential regulatory reporting);PLEDGE\u00acPledge in favour of Policy EBO / beneficiaries / life assured (any pledge in favour a 3rd party is prohibited);NA\u00acN/A", null, false, null, true),
                new FieldRule("UNQUOTED_NEW_BUSINESS", "ASSET_KYC", "INVESTOR_STATUS", "SelectInputField", 19, "Professional investor status", true, true, "YES\u00acYes;NO\u00acNo;NA\u00acN/A", "(#NTA_CATEGORY_$# == \"CAT1\" && #SUB_TYPE_ONE_$# != \"\") || #NTA_CATEGORY_$# == \"CAT2\" || #NTA_CATEGORY_$# == \"CAT3\"", false, null, true),
                new FieldRule("UNQUOTED_NEW_BUSINESS", "RISK", "AMBER_FLAG_DRIVERS_RESULT", "SelectInputField", 20, "Result", true, false, "AMBER\u00acAmber;NA\u00acN/A", null, false, null, true),
                new FieldRule("UNQUOTED_NEW_BUSINESS", "ASSET_KYC", "SHARE_AGREEMENT", "SelectInputField", 20, "Share/ Note /Partnership transfer agreement", true, true, "YES\u00acYes;NO\u00acNo;NA\u00acN/A", "(#NTA_CATEGORY_$# == \"CAT1\" && #SUB_TYPE_ONE_$# != \"\") || #NTA_CATEGORY_$# == \"CAT2\" || #NTA_CATEGORY_$# == \"CAT3\"", false, null, true),
                new FieldRule("UNQUOTED_NEW_BUSINESS", "ASSET_KYC", "CATE_ONE_COMMENT", "TextAreaField", 21, "Comments if any other documentation is applicable or if any of the above is N/A or if any waiver was granted", true, false, null, null, false, null, true),
                new FieldRule("UNQUOTED_NEW_BUSINESS", "RISK", "RISK_RATING", "SelectInputField", 21, "Risk rating assigned and sign-off required", true, false, "GREEN\u00acGreen (0-3) \u2013 NTA Acceptance Manager + Senior NTA Asset Analyst;YELLOW\u00acYellow (4-9) \u2013 Head of NTA Investments + NTA Acceptance Manager;AMBER\u00acAmber case (10-13) \u2013 CIO / COO or Head of Investment Administration + Head of NTA Investments;RED\u00acRed case (14-16) \u2013 CEO evidence of sign-off + CIO / COO or Head of Investment Administration + Head of NTA Investments", null, false, null, true),
                new FieldRule("UNQUOTED_NEW_BUSINESS", "ASSET_KYC", "CAA_CODE", "SelectInputField", 22, "CAA Codification", true, true, "A9A\u00acA9a. Bonds of an non-government issuer of the EEA non traded on a regulated market;A9B\u00acA9b. Bonds of a non-government issuer of the A Zone of the OECD outside EEA non traded on a regulated market;B5A\u00acB5a. Equities of an issuer of the EEA but not traded on a regulated market;B5B\u00acB5b. Equities of an issuer of the A Zone of the OECD not traded on a regulated market;C2H\u00acC2h. Investment funds of a country of the EEA / not compliant with the modified Directive 95/611/EEC (other);C5\u00acC5. Investment Funds from a country outside the A Zone of the OECD;E1\u00acE1. Real estate Investment Funds from a Country of the A Zone of the OECD;F1A\u00acF1a. Bonds outside the A Zone OECD not listed on a regulated market;F1B\u00acF1b. Equities outside A Zone OECD not listed on a regulated market", null, false, null, true),
                new FieldRule("UNQUOTED_NEW_BUSINESS", "RISK", "RISK_RATING_RESULT", "TextInputField", 22, "Result", true, false, null, null, false, null, true),
                new FieldRule("UNQUOTED_NEW_BUSINESS", "RISK", "RISK_COMMENT", "TextAreaField", 23, "Risk rating assigned comments / mitigation action", true, false, null, null, false, null, true),
                new FieldRule("UNQUOTED_NEW_BUSINESS", "RISK", "SHARE_NOTE_PARTNERSHIP_TA", "SelectInputField", 24, "Share / Note / Partnership Transfer Agreement", true, true, "FULLY_SIGNED\u00acFully signed;ELECTRONIC_TRANSFER\u00acElectronic Transfer;NOT_APPLICABLE\u00acNot applicable", null, false, null, true)
        );
    }

    public record TabRule(String screenId, String tabId, String label, String type, int order, String displayIf) {
    }

    public record GroupRule(String screenId, String tabId, String groupId, String title, int order, int columnsCount, String displayIf) {
    }

    public record FieldRule(String screenId, String groupId, String fieldId, String fieldType, int order, String label,
                            boolean enabled, boolean mandatory, String valueOptions, String displayIf, boolean labelBold,
                            String sourceSystem, boolean repeatable) {
        public FieldSpec toFieldSpec() {
            return new FieldSpec(screenId, groupId, fieldId, fieldType, order, label, enabled, mandatory, valueOptions,
                    displayIf, labelBold, sourceSystem, repeatable);
        }
    }}
