package com.lombardinternational.casedefinition.v2.adapter.api.web.controller;

import com.lombardinternational.casedefinition.v2.adapter.api.web.dto.ScreenDescriptionRequest;
import com.lombardinternational.casedefinition.v2.adapter.api.web.mapper.ScreenDescriptionMapper;
import com.lombardinternational.casedefinition.v2.adapter.api.web.mapper.WebFormMapper;
import com.lombardinternational.casedefinition.v2.domain.api.ScreenBusinessService;
import com.lombardinternational.casedefinition.v2.domain.model.ScreenDescription;
import com.lombardinternational.casedefinition.v2.domain.model.WebForm;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Tag(name = "Screens", description = "Screens management")
@RestController
@RequestMapping("/api/screens")
@RequiredArgsConstructor
public class ScreenController {
    private final ScreenBusinessService screenBusinessService;
    private final WebFormMapper webFormMapper;
    private final ScreenDescriptionMapper screenDescriptionMapper;

    @PostMapping("description")
    @Operation(summary = "Generate a ScreenDescription based on a ScreenDescriptionRequest")
    public ResponseEntity<com.lombardinternational.casedefinition.v2.adapter.api.web.dto.ScreenDescription> getScreenDescription(
            @Valid @RequestBody ScreenDescriptionRequest request) {
        WebForm webForm = webFormMapper.webFormFromDTO(request.caseInitializationData());
        ScreenDescription screenDescriptionToBuild = screenDescriptionMapper.screenDescriptionFromDTO(request.screenDescription());
        ScreenDescription screenDescription = screenBusinessService.computeScreenDescription(request.policyNumber(),
                request.caseType(), request.businessTransactionNumber(), webForm, screenDescriptionToBuild);
        return ResponseEntity.ok(screenDescriptionMapper.DTOFromScreenDescription(screenDescription));
    }

    @PostMapping("task")
    @Operation(summary = "Generate sub-task screen based on a ScreenDescriptionRequest")
    public ResponseEntity<com.lombardinternational.casedefinition.v2.adapter.api.web.dto.ScreenDescription> getTaskScreenDescription(
            @Valid @RequestBody ScreenDescriptionRequest request) {
        WebForm webForm = webFormMapper.webFormFromDTO(request.caseInitializationData());
        ScreenDescription screenCheckList = screenDescriptionMapper.screenDescriptionFromDTO(request.screenCheckList());
        ScreenDescription screenToFill = screenDescriptionMapper.screenDescriptionFromDTO(request.screenDescription());
        ScreenDescription screenDescription = screenBusinessService.computeTaskScreen(request.caseType(), webForm,
                screenCheckList, screenToFill);
        return ResponseEntity.ok(screenDescriptionMapper.DTOFromScreenDescription(screenDescription));
    }
}
