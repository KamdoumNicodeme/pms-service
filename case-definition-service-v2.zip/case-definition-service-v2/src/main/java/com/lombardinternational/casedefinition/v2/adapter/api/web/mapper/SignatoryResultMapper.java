package com.lombardinternational.casedefinition.v2.adapter.api.web.mapper;

import com.lombardinternational.casedefinition.v2.domain.model.SignatoryResult;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring", uses = {DocumentRequiredSignatoryMapper.class})
public interface SignatoryResultMapper {
    SignatoryResult signatoryResultFromDTO(com.lombardinternational.casedefinition.v2.adapter.api.web.dto.SignatoryResult dto);

    com.lombardinternational.casedefinition.v2.adapter.api.web.dto.SignatoryResult dtoFromSignatoryResult(SignatoryResult result);
}
