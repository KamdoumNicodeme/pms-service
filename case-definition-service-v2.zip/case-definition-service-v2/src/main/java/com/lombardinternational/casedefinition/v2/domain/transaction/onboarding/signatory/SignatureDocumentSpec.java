package com.lombardinternational.casedefinition.v2.domain.transaction.onboarding.signatory;

import java.util.List;
import java.util.Map;

public record SignatureDocumentSpec(boolean active, String ruleName, String webFormId, String market, String branch,
                                    String holderSpecificType, String partnerType, String productType,
                                    Boolean genericPreContractualPackage, String documentLanguagePreference,
                                    String extraCondition, String documentType, String cmsDocumentType,
                                    String secondaryDocumentRelatedTo, boolean documentMustBeGenerated,
                                    boolean documentRequiredOnConnect, String documentRelatedToExpression,
                                    List<String> requestedSignatoryTypes, List<String> secondarySignatoryTypes,
                                    List<String> allowedActions, String strategy, int documentOrder,
                                    Map<String, String> responseMessages) {
}
