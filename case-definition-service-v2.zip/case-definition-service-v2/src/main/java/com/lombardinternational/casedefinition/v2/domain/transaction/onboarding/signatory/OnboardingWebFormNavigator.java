package com.lombardinternational.casedefinition.v2.domain.transaction.onboarding.signatory;

import com.lombardinternational.casedefinition.v2.domain.model.WebForm;
import com.lombardinternational.casedefinition.v2.domain.model.WebFormField;
import com.lombardinternational.casedefinition.v2.domain.model.WebFormGroup;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Stream;

final class OnboardingWebFormNavigator {
    private OnboardingWebFormNavigator() {
    }

    static List<WebFormGroup> groupsById(WebForm webForm, String groupId) {
        if (webForm == null || groupId == null) {
            return List.of();
        }
        List<WebFormGroup> matches = new ArrayList<>();
        webForm.groups().forEach(group -> collectGroups(group, groupId, matches));
        return matches;
    }

    static Optional<String> firstValue(WebForm webForm, String... fieldIds) {
        if (webForm == null || fieldIds == null) {
            return Optional.empty();
        }
        return Stream.of(fieldIds).filter(Objects::nonNull).map(webForm::findFieldValue).filter(Optional::isPresent).map(Optional::get)
                .filter(OnboardingWebFormNavigator::hasText).findFirst();
    }

    static Optional<String> firstValue(WebFormGroup group, String... fieldIds) {
        if (group == null || fieldIds == null) {
            return Optional.empty();
        }
        return Stream.of(fieldIds).filter(Objects::nonNull).map(fieldId -> fieldValue(group, fieldId)).filter(Optional::isPresent)
                .map(Optional::get).filter(OnboardingWebFormNavigator::hasText).findFirst();
    }

    static Stream<WebFormGroup> allGroups(WebForm webForm) {
        if (webForm == null) {
            return Stream.empty();
        }
        return webForm.groups().flatMap(OnboardingWebFormNavigator::flattenGroup);
    }

    static boolean hasField(WebFormGroup group, String... fieldIds) {
        if (group == null || fieldIds == null) {
            return false;
        }
        return group.fields().map(WebFormField::getFieldId).filter(Objects::nonNull)
                .anyMatch(id -> Stream.of(fieldIds).anyMatch(id::equals));
    }

    static String groupId(WebFormGroup group) {
        if (group == null) {
            return "";
        }
        if (hasText(group.getGroupId())) {
            return group.getGroupId();
        }
        return Optional.ofNullable(group.getFieldsetId()).orElse("");
    }

    private static void collectGroups(WebFormGroup group, String groupId, List<WebFormGroup> matches) {
        if (Objects.equals(groupId, group.getGroupId()) || Objects.equals(groupId, group.getFieldsetId())) {
            matches.add(group);
        }
        if (group.getGroups() != null) {
            group.getGroups().stream().filter(Objects::nonNull).forEach(child -> collectGroups(child, groupId, matches));
        }
    }

    private static Stream<WebFormGroup> flattenGroup(WebFormGroup group) {
        Stream<WebFormGroup> current = Stream.of(group);
        Stream<WebFormGroup> children = group.getGroups() == null ? Stream.empty() : group.getGroups().stream().filter(Objects::nonNull)
                .flatMap(OnboardingWebFormNavigator::flattenGroup);
        return Stream.concat(current, children);
    }

    private static Optional<String> fieldValue(WebFormGroup group, String fieldId) {
        return group.fields().filter(field -> Objects.equals(fieldId, field.getFieldId())).findFirst().flatMap(WebFormField::effectiveValue);
    }

    static boolean hasText(String value) {
        return value != null && !value.isBlank();
    }
}
