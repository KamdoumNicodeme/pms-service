package com.lombardinternational.casedefinition.v2.domain.service.checklist;

import com.lombardinternational.casedefinition.v2.domain.model.Group;
import com.lombardinternational.casedefinition.v2.domain.model.ScreenDescription;
import com.lombardinternational.casedefinition.v2.domain.model.WebForm;

public interface FieldBuilderService {
    void buildField(WebForm webForm, ScreenDescription screenDescription, Group group);
}
