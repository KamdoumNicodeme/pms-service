package com.lombardinternational.casedefinition.v2.domain.service.checklist.onboarding.field;

import com.lombardinternational.casedefinition.v2.domain.model.Group;
import com.lombardinternational.casedefinition.v2.domain.model.ScreenDescription;
import com.lombardinternational.casedefinition.v2.domain.model.WebForm;
import com.lombardinternational.casedefinition.v2.domain.service.checklist.FieldBuilderService;
import org.springframework.stereotype.Service;

import java.util.Map;

@Service
public class OnboardingGeneralDetailsFieldsBuilderService extends OnboardingChecklistFieldsBuilderSupport implements FieldBuilderService {
    @Override
    public void buildField(WebForm webForm, ScreenDescription screenDescription, Group group) {
        var previousValues = previousValues(screenDescription);
        resetFields(group);
        buildContractType(group, previousValues, webForm);
        buildPolicyNumber(group, previousValues, webForm);
        buildPolicyCur(group, previousValues, webForm);
        buildExpectedPrem(group, previousValues, webForm);
        buildExpectedPremEur(group, previousValues, webForm);
        buildNewClient(group, previousValues, webForm);
        buildTotalBeNavPolicyEur(group, previousValues, webForm);
        buildTotalNavPolicyEur(group, previousValues, webForm);
        buildCountryOfLaw(group, previousValues, webForm);
        buildResidenceCountry(group, previousValues, webForm);
        buildRdrCompliant(group, previousValues, webForm);
        buildMarketConsultant(group, previousValues, webForm);
        buildInvestManagerCode(group, previousValues, webForm);
        buildInvestManagerName(group, previousValues, webForm);
        buildEsgMandateSelected(group, previousValues, webForm);
        buildEsgStrategyName(group, previousValues, webForm);
        buildProxyAlignImaClass(group, previousValues, webForm);
        buildCustodianCountry(group, previousValues, webForm);
        buildCustodianBankName(group, previousValues, webForm);
        buildAccountOpenedCountry(group, previousValues, webForm);
        buildAccountOpenedInEea(group, previousValues, webForm);
        buildMultiProduct(group, previousValues, webForm);
        buildNumberProduct(group, previousValues, webForm);
        buildBusinessOrigin(group, previousValues, webForm);
        buildPhResidenceCountryRisk(group, previousValues, webForm);
        buildOffShoreIndicia(group, previousValues, webForm);
        buildPhFiscalCountry(group, previousValues, webForm);
        buildTaxResidenceInconsistent(group, previousValues, webForm);
        buildPhTypeAssessment(group, previousValues, webForm);
        buildPhNonFinancial(group, previousValues, webForm);
        buildEntitySameAsFatca(group, previousValues, webForm);
        buildPhLegalEntityArrangement(group, previousValues, webForm);
        buildEvidenceKnownLegalEntity(group, previousValues, webForm);
        buildPhLegalEntity(group, previousValues, webForm);
        buildPaidFromAppointed(group, previousValues, webForm);
        buildFormerSwissPh(group, previousValues, webForm);
        buildProofDeregistrationPh(group, previousValues, webForm);
        buildThirdPartySubTypePh(group, previousValues, webForm);
        buildMrlTrustee(group, previousValues, webForm);
        buildAppFormSigned(group, previousValues, webForm);
        buildTrustResidenceCountryRisk(group, previousValues, webForm);
        buildProxyCountryRisk(group, previousValues, webForm);
        buildLaDifferentToPh(group, previousValues, webForm);
        buildLaResidenceCountryRisk(group, previousValues, webForm);
        buildFormerSwissLa(group, previousValues, webForm);
        buildProofDeregistrationLa(group, previousValues, webForm);
        buildSettlorResidenceCountryRisk(group, previousValues, webForm);
        buildAppFormSignedLa(group, previousValues, webForm);
        buildLaDifferentBen(group, previousValues, webForm);
        buildDateOfBirth(group, previousValues, webForm);
        buildPolicySignedCountry(group, previousValues, webForm);
        buildSendingAddress(group, previousValues, webForm);
        buildIrrevocableBen(group, previousValues, webForm);
        buildIrrevocableBenCountry(group, previousValues, webForm);
        buildAmlClause(group, previousValues, webForm);
        buildPhDifferentToEbo(group, previousValues, webForm);
        buildThirdPartySubTypeEbo(group, previousValues, webForm);
        buildEboResidenceCountryRisk(group, previousValues, webForm);
        buildFormerSwissEbo(group, previousValues, webForm);
        buildProofDeregistrationEbo(group, previousValues, webForm);
        buildTrusteeResidenceCountryRisk(group, previousValues, webForm);
        buildBeneficiaryResidenceCountryRisk(group, previousValues, webForm);
        buildUsIndicia(group, previousValues, webForm);
        buildFatcaFormRefused(group, previousValues, webForm);
        buildFatcaFormInconsistent(group, previousValues, webForm);
        buildTpBlock(group, previousValues, webForm);
        sortFields(group);
    }

    private void buildContractType(Group group, Map<String, String> previousValues, WebForm webForm) {
        buildField(group, new FieldRule("CONTRACT_TYPE", FieldKind.SELECT, 1, "Contract type", false, false,
                "#forcedValue", null, false, "From Connect", false), previousValues, webForm);
    }

    private void buildPolicyNumber(Group group, Map<String, String> previousValues, WebForm webForm) {
        buildField(group, new FieldRule("POLICY_NUMBER", FieldKind.TEXT, 2, "Policy number", false, false,
                "#forcedValue", null, false, "From Connect", false), previousValues, webForm);
    }

    private void buildPolicyCur(Group group, Map<String, String> previousValues, WebForm webForm) {
        buildField(group, new FieldRule("POLICY_CUR", FieldKind.TEXT, 3, "Policy ccy", false, false,
                "#forcedValue", null, false, "From Connect", false), previousValues, webForm);
    }

    private void buildExpectedPrem(Group group, Map<String, String> previousValues, WebForm webForm) {
        buildField(group, new FieldRule("EXPECTED_PREM", FieldKind.NUMBER, 4, "Expected premium (in policy currency)", false, false,
                "#forcedValue", null, false, "From Connect", false), previousValues, webForm);
    }

    private void buildExpectedPremEur(Group group, Map<String, String> previousValues, WebForm webForm) {
        buildField(group, new FieldRule("EXPECTED_PREM_EUR", FieldKind.NUMBER, 4, "Expected premium (in EUR)", false, false,
                "#forcedValue", "#POLICY_CUR# != \"EUR\"", false, "From Connect", false), previousValues, webForm);
    }

    private void buildNewClient(Group group, Map<String, String> previousValues, WebForm webForm) {
        buildField(group, new FieldRule("NEW_CLIENT", FieldKind.SELECT, 8, "New client", true, true,
                "YES\u00acYes;NO\u00acNo", null, false, null, false), previousValues, webForm);
    }

    private void buildTotalBeNavPolicyEur(Group group, Map<String, String> previousValues, WebForm webForm) {
        buildField(group, new FieldRule("TOTAL_BE_NAV_POLICY_EUR", FieldKind.NUMBER, 9, "Total existing BE NAV", false, false,
                "#forcedValue", "#NEW_CLIENT# == \"NO\" && #BUSINESS_ORIGIN# == \"BE\"", false, null, false), previousValues, webForm);
    }

    private void buildTotalNavPolicyEur(Group group, Map<String, String> previousValues, WebForm webForm) {
        buildField(group, new FieldRule("TOTAL_NAV_POLICY_EUR", FieldKind.NUMBER, 9, "Total existing NAV linked to the same EBO, excluding this expected premium", false, false,
                "#forcedValue", "#NEW_CLIENT# == \"NO\" && #BUSINESS_ORIGIN# != \"BE\"", false, null, false), previousValues, webForm);
    }

    private void buildCountryOfLaw(Group group, Map<String, String> previousValues, WebForm webForm) {
        buildField(group, new FieldRule("COUNTRY_OF_LAW", FieldKind.SELECT, 13, "Country of applicable law", false, false,
                "#forcedValue", null, false, "From Connect", false), previousValues, webForm);
    }

    private void buildResidenceCountry(Group group, Map<String, String> previousValues, WebForm webForm) {
        buildField(group, new FieldRule("RESIDENCE_COUNTRY", FieldKind.TEXT_AREA, 14, "Riskiest / Missing country of residence", false, true,
                "#forcedValue", null, false, "From CLASS", false), previousValues, webForm);
    }

    private void buildRdrCompliant(Group group, Map<String, String> previousValues, WebForm webForm) {
        buildField(group, new FieldRule("RDR_COMPLIANT", FieldKind.SELECT, 15, "Is it RDR compliant?", true, true,
                "YES\u00acYes;NO\u00acNo;NA\u00acN/A", "#COUNTRY_OF_LAW# == \"GB\"", false, null, false), previousValues, webForm);
    }

    private void buildMarketConsultant(Group group, Map<String, String> previousValues, WebForm webForm) {
        buildField(group, new FieldRule("MARKET_CONSULTANT", FieldKind.TEXT, 16, "Marketing consultant", true, false,
                null, null, false, null, false), previousValues, webForm);
    }

    private void buildInvestManagerCode(Group group, Map<String, String> previousValues, WebForm webForm) {
        buildField(group, new FieldRule("INVEST_MANAGER_CODE", FieldKind.TEXT, 100, "Investment manager code", false, false,
                "#forcedValue", null, false, "From Connect", true), previousValues, webForm);
    }

    private void buildInvestManagerName(Group group, Map<String, String> previousValues, WebForm webForm) {
        buildField(group, new FieldRule("INVEST_MANAGER_NAME", FieldKind.TEXT, 101, "Investment manager name", false, false,
                "#forcedValue", null, false, "From Connect", true), previousValues, webForm);
    }

    private void buildEsgMandateSelected(Group group, Map<String, String> previousValues, WebForm webForm) {
        buildField(group, new FieldRule("ESG_MANDATE_SELECTED", FieldKind.SELECT, 102, "Art. 8/9 ESG mandate selected?", false, false,
                "#forcedValue", null, false, "From Connect", true), previousValues, webForm);
    }

    private void buildEsgStrategyName(Group group, Map<String, String> previousValues, WebForm webForm) {
        buildField(group, new FieldRule("ESG_STRATEGY_NAME", FieldKind.TEXT, 103, "ESG Stragegy Name", false, false,
                "#forcedValue", "#ESG_MANDATE_SELECTED_$# == \"YES_PRE_VALIDATED\" || #ESG_MANDATE_SELECTED_$# == \"YES_TO_BE_REVIEWED\"", false, "From Connect", true), previousValues, webForm);
    }

    private void buildProxyAlignImaClass(Group group, Map<String, String> previousValues, WebForm webForm) {
        buildField(group, new FieldRule("PROXY_ALIGN_IMA_CLASS", FieldKind.SELECT, 104, "Proxy to IM to charge their fees (debited by partner)?", true, true,
                "YES\u00acYes;NO\u00acNo", null, false, null, true), previousValues, webForm);
    }

    private void buildCustodianCountry(Group group, Map<String, String> previousValues, WebForm webForm) {
        buildField(group, new FieldRule("CUSTODIAN_COUNTRY", FieldKind.SELECT, 105, "Custodian country", false, false,
                "#forcedValue", null, false, "From Connect", true), previousValues, webForm);
    }

    private void buildCustodianBankName(Group group, Map<String, String> previousValues, WebForm webForm) {
        buildField(group, new FieldRule("CUSTODIAN_BANK_NAME", FieldKind.TEXT, 106, "Custodian bank name", false, false,
                "#forcedValue", null, false, "From Connect", true), previousValues, webForm);
    }

    private void buildAccountOpenedCountry(Group group, Map<String, String> previousValues, WebForm webForm) {
        buildField(group, new FieldRule("ACCOUNT_OPENED_COUNTRY", FieldKind.SELECT, 107, "Account opened country", true, true,
                "countriesString", null, false, null, true), previousValues, webForm);
    }

    private void buildAccountOpenedInEea(Group group, Map<String, String> previousValues, WebForm webForm) {
        buildField(group, new FieldRule("ACCOUNT_OPENED_IN_EEA", FieldKind.SELECT, 108, "Account opened in a bank located in the EEA?", false, true,
                "#forcedValue", null, false, null, true), previousValues, webForm);
    }

    private void buildMultiProduct(Group group, Map<String, String> previousValues, WebForm webForm) {
        buildField(group, new FieldRule("MULTI_PRODUCT", FieldKind.SELECT, 200, "Multi product", false, false,
                "#forcedValue", null, false, "From Connect", false), previousValues, webForm);
    }

    private void buildNumberProduct(Group group, Map<String, String> previousValues, WebForm webForm) {
        buildField(group, new FieldRule("NUMBER_PRODUCT", FieldKind.TEXT, 201, "Number of added product", false, false,
                "#forcedValue", "#MULTI_PRODUCT# == \"YES\"", false, "From Connect", false), previousValues, webForm);
    }

    private void buildBusinessOrigin(Group group, Map<String, String> previousValues, WebForm webForm) {
        buildField(group, new FieldRule("BUSINESS_ORIGIN", FieldKind.SELECT, 700, "Business Origin", false, false,
                "#forcedValue", null, false, "From Connect", false), previousValues, webForm);
    }

    private void buildPhResidenceCountryRisk(Group group, Map<String, String> previousValues, WebForm webForm) {
        buildField(group, new FieldRule("PH_RESIDENCE_COUNTRY_RISK", FieldKind.TEXT, 704, "PH(s) residence country", false, false,
                "#forcedValue", "#forcedDisplayIf", false, "From CLASS", false), previousValues, webForm);
    }

    private void buildOffShoreIndicia(Group group, Map<String, String> previousValues, WebForm webForm) {
        buildField(group, new FieldRule("OFF_SHORE_INDICIA", FieldKind.SELECT, 705, "(Belgian Branch) Off-shore indicia found ?", false, true,
                "#forcedValue", "#forcedDisplayIf", false, "From CLASS and converted", false), previousValues, webForm);
    }

    private void buildPhFiscalCountry(Group group, Map<String, String> previousValues, WebForm webForm) {
        buildField(group, new FieldRule("PH_FISCAL_COUNTRY", FieldKind.TEXT, 706, "PH(s) fiscal country", false, false,
                "#forcedValue", null, false, "From Connect", false), previousValues, webForm);
    }

    private void buildTaxResidenceInconsistent(Group group, Map<String, String> previousValues, WebForm webForm) {
        buildField(group, new FieldRule("TAX_RESIDENCE_INCONSISTENT", FieldKind.SELECT, 707, "Is there any unjustified inconsistency in the information provided concerning the tax residence of the PH/EBO and this without any legitimate reason?", true, true,
                "YES\u00acYes;NO\u00acNo", null, false, null, false), previousValues, webForm);
    }

    private void buildPhTypeAssessment(Group group, Map<String, String> previousValues, WebForm webForm) {
        buildField(group, new FieldRule("PH_TYPE_ASSESSMENT", FieldKind.TEXT, 708, "PH type assessment", false, true,
                "#forcedValue", null, false, "From CLASS", false), previousValues, webForm);
    }

    private void buildPhNonFinancial(Group group, Map<String, String> previousValues, WebForm webForm) {
        buildField(group, new FieldRule("PH_NON_FINANCIAL", FieldKind.SELECT, 709, "Is the PH a passive Non Financial Entity (Passive NFE)?", true, true,
                "YES\u00acYes;NO\u00acNo", "#PH_TYPE_ASSESSMENT# != \"PH Type=Physical\"", false, null, false), previousValues, webForm);
    }

    private void buildEntitySameAsFatca(Group group, Map<String, String> previousValues, WebForm webForm) {
        buildField(group, new FieldRule("ENTITY_SAME_AS_FATCA", FieldKind.SELECT, 710, "Are the controlling persons of the entity as mentioned in the FATCA/CRS/AEOI form the same individuals as those identified as EBOs for AML purposes and disclosed in the KYC form?", true, true,
                "YES\u00acYes;NO\u00acNo", "#PH_TYPE_ASSESSMENT# != \"PH Type=Physical\" && #PH_NON_FINANCIAL# == \"YES\"", false, null, false), previousValues, webForm);
    }

    private void buildPhLegalEntityArrangement(Group group, Map<String, String> previousValues, WebForm webForm) {
        buildField(group, new FieldRule("PH_LEGAL_ENTITY_ARRANGEMENT", FieldKind.SELECT, 711, "Is the PH a legal entity or a legal arrangement (e.g. trust, foundation,...) located in a country which is not the tax country of residence or place of regular economic or professional activities/interests of the EBO?", true, true,
                "YES\u00acYes;NO\u00acNo;NA\u00ac(N/A for trust with professional trustee based in EU)", "#forcedDisplayIf", false, null, false), previousValues, webForm);
    }

    private void buildEvidenceKnownLegalEntity(Group group, Map<String, String> previousValues, WebForm webForm) {
        buildField(group, new FieldRule("EVIDENCE_KNOWN_LEGAL_ENTITY", FieldKind.SELECT, 712, "Did you collect supporting evidence that the legal entity or the legal arrangement is known by the tax authorities of the country of residence of the EBO or could the PH demonstrate that its establishment complies with the legal provisions of the country of residence of the PH/EBO?", true, true,
                "YES\u00acYes;NO\u00acNo", "#forcedDisplayIf", false, null, false), previousValues, webForm);
    }

    private void buildPhLegalEntity(Group group, Map<String, String> previousValues, WebForm webForm) {
        buildField(group, new FieldRule("PH_LEGAL_ENTITY", FieldKind.SELECT, 713, "Is the PH a legal entity (excluding soci\u00e9t\u00e9 simple or any legal arrangement such as trust, fideicomiso, foundation or fiduciary)?", true, true,
                "YES\u00acYes;NO\u00acNo", "#forcedDisplayIf", false, null, false), previousValues, webForm);
    }

    private void buildPaidFromAppointed(Group group, Map<String, String> previousValues, WebForm webForm) {
        buildField(group, new FieldRule("PAID_FROM_APPOINTED", FieldKind.SELECT, 714, "Is the premium paid from the appointed beneficiary who is a natural person ?", true, true,
                "YES\u00acYes;NO\u00acNo", "#PH_TYPE_ASSESSMENT# != \"PH Type=Physical\" && #PH_LEGAL_ENTITY# == \"YES\"", false, null, false), previousValues, webForm);
    }

    private void buildFormerSwissPh(Group group, Map<String, String> previousValues, WebForm webForm) {
        buildField(group, new FieldRule("FORMER_SWISS_PH", FieldKind.SELECT, 715, "Any former Swiss residency known for PH(s)", true, true,
                "YES\u00acYes;NO\u00acNo", null, false, null, false), previousValues, webForm);
    }

    private void buildProofDeregistrationPh(Group group, Map<String, String> previousValues, WebForm webForm) {
        buildField(group, new FieldRule("PROOF_DEREGISTRATION_PH", FieldKind.SELECT, 716, "Proof of deregistration known for PH(s)", true, true,
                "YES\u00acYes;NO\u00acNo", "#FORMER_SWISS_PH# == \"YES\"", false, null, false), previousValues, webForm);
    }

    private void buildThirdPartySubTypePh(Group group, Map<String, String> previousValues, WebForm webForm) {
        buildField(group, new FieldRule("THIRD_PARTY_SUB_TYPE_PH", FieldKind.TEXT, 717, "Third party sub type for PH(s)", false, false,
                "#forcedValue", null, false, "From Connect", true), previousValues, webForm);
    }

    private void buildMrlTrustee(Group group, Map<String, String> previousValues, WebForm webForm) {
        buildField(group, new FieldRule("MRL_TRUSTEE", FieldKind.SELECT, 800, "MRL Trustee in a participating juridiction", true, true,
                "YES\u00acYes;NO\u00acNo", "#forcedDisplayIf", false, null, false), previousValues, webForm);
    }

    private void buildAppFormSigned(Group group, Map<String, String> previousValues, WebForm webForm) {
        buildField(group, new FieldRule("APP_FORM_SIGNED", FieldKind.SELECT, 801, "Application Form signed by PH?", false, false,
                "YES\u00acYes;NO\u00acNo", null, false, "From Connect", false), previousValues, webForm);
    }

    private void buildTrustResidenceCountryRisk(Group group, Map<String, String> previousValues, WebForm webForm) {
        buildField(group, new FieldRule("TRUST_RESIDENCE_COUNTRY_RISK", FieldKind.TEXT, 802, "Trust residence country", false, false,
                "#forcedValue", "#forcedDisplayIf", false, "From CLASS", false), previousValues, webForm);
    }

    private void buildProxyCountryRisk(Group group, Map<String, String> previousValues, WebForm webForm) {
        buildField(group, new FieldRule("PROXY_COUNTRY_RISK", FieldKind.TEXT, 804, "Proxy residence country", false, false,
                "#forcedValue", "#forcedDisplayIf", false, "From CLASS", false), previousValues, webForm);
    }

    private void buildLaDifferentToPh(Group group, Map<String, String> previousValues, WebForm webForm) {
        buildField(group, new FieldRule("LA_DIFFERENT_TO_PH", FieldKind.SELECT, 805, "LA different to PH", false, false,
                "#forcedValue", "#forcedDisplayIf", false, "From Connect", false), previousValues, webForm);
    }

    private void buildLaResidenceCountryRisk(Group group, Map<String, String> previousValues, WebForm webForm) {
        buildField(group, new FieldRule("LA_RESIDENCE_COUNTRY_RISK", FieldKind.TEXT, 806, "LA residence country", false, false,
                "#forcedValue", "#forcedDisplayIf", false, "From CLASS", false), previousValues, webForm);
    }

    private void buildFormerSwissLa(Group group, Map<String, String> previousValues, WebForm webForm) {
        buildField(group, new FieldRule("FORMER_SWISS_LA", FieldKind.SELECT, 807, "Any former Swiss residency known for LA(s)", true, true,
                "YES\u00acYes;NO\u00acNo", "#LA_DIFFERENT_TO_PH# == \"YES\"", false, null, false), previousValues, webForm);
    }

    private void buildProofDeregistrationLa(Group group, Map<String, String> previousValues, WebForm webForm) {
        buildField(group, new FieldRule("PROOF_DEREGISTRATION_LA", FieldKind.SELECT, 808, "Proof of deregistration received for LA(s)", true, true,
                "YES\u00acYes;NO\u00acNo", "#FORMER_SWISS_LA# == \"YES\"", false, null, false), previousValues, webForm);
    }

    private void buildSettlorResidenceCountryRisk(Group group, Map<String, String> previousValues, WebForm webForm) {
        buildField(group, new FieldRule("SETTLOR_RESIDENCE_COUNTRY_RISK", FieldKind.TEXT, 808, "Settlor residence country", false, false,
                "#forcedValue", "#forcedDisplayIf", false, "From CLASS", false), previousValues, webForm);
    }

    private void buildAppFormSignedLa(Group group, Map<String, String> previousValues, WebForm webForm) {
        buildField(group, new FieldRule("APP_FORM_SIGNED_LA", FieldKind.SELECT, 809, "Application Form signed by LA?", true, true,
                "YES\u00acYes;NO\u00acNo", "#LA_DIFFERENT_TO_PH# == \"YES\"", false, null, false), previousValues, webForm);
    }

    private void buildLaDifferentBen(Group group, Map<String, String> previousValues, WebForm webForm) {
        buildField(group, new FieldRule("LA_DIFFERENT_BEN", FieldKind.SELECT, 810, "LA different to BEN", true, true,
                "YES\u00acYes;NO\u00acNo", "#forcedDisplayIf", false, null, false), previousValues, webForm);
    }

    private void buildDateOfBirth(Group group, Map<String, String> previousValues, WebForm webForm) {
        buildField(group, new FieldRule("DATE_OF_BIRTH", FieldKind.TEXT, 811, "Age of youngest LA", true, true,
                null, null, false, null, false), previousValues, webForm);
    }

    private void buildPolicySignedCountry(Group group, Map<String, String> previousValues, WebForm webForm) {
        buildField(group, new FieldRule("POLICY_SIGNED_COUNTRY", FieldKind.SELECT, 812, "Policy Signed Country", true, true,
                "countriesString", null, false, null, false), previousValues, webForm);
    }

    private void buildSendingAddress(Group group, Map<String, String> previousValues, WebForm webForm) {
        buildField(group, new FieldRule("SENDING_ADDRESS", FieldKind.SELECT, 813, "Sending Address Country", false, false,
                "#forcedValue", null, false, "From Connect", false), previousValues, webForm);
    }

    private void buildIrrevocableBen(Group group, Map<String, String> previousValues, WebForm webForm) {
        buildField(group, new FieldRule("IRREVOCABLE_BEN", FieldKind.SELECT, 815, "Irrevocable BEN", false, false,
                "#forcedValue", null, false, "From CLASS", false), previousValues, webForm);
    }

    private void buildIrrevocableBenCountry(Group group, Map<String, String> previousValues, WebForm webForm) {
        buildField(group, new FieldRule("IRREVOCABLE_BEN_COUNTRY", FieldKind.TEXT, 816, "Irrevocable BEN residence country", false, false,
                "#forcedValue", "#forcedDisplayIf", false, "From CLASS", false), previousValues, webForm);
    }

    private void buildAmlClause(Group group, Map<String, String> previousValues, WebForm webForm) {
        buildField(group, new FieldRule("AML_CLAUSE", FieldKind.SELECT, 817, "AML clause ticked", true, true,
                "YES\u00acYes;NO\u00acNo", null, false, null, false), previousValues, webForm);
    }

    private void buildPhDifferentToEbo(Group group, Map<String, String> previousValues, WebForm webForm) {
        buildField(group, new FieldRule("PH_DIFFERENT_TO_EBO", FieldKind.SELECT, 818, "PH different to EBO", false, false,
                "#forcedValue", null, false, "From CLASS", false), previousValues, webForm);
    }

    private void buildThirdPartySubTypeEbo(Group group, Map<String, String> previousValues, WebForm webForm) {
        buildField(group, new FieldRule("THIRD_PARTY_SUB_TYPE_EBO", FieldKind.TEXT, 819, "PH different to Third party sub type for EBO", false, false,
                "#forcedValue", "#PH_DIFFERENT_TO_EBO# == \"YES\"", false, "From CLASS", false), previousValues, webForm);
    }

    private void buildEboResidenceCountryRisk(Group group, Map<String, String> previousValues, WebForm webForm) {
        buildField(group, new FieldRule("EBO_RESIDENCE_COUNTRY_RISK", FieldKind.TEXT, 820, "EBO residence country", false, false,
                "#forcedValue", "#forcedDisplayIf", false, "From CLASS", false), previousValues, webForm);
    }

    private void buildFormerSwissEbo(Group group, Map<String, String> previousValues, WebForm webForm) {
        buildField(group, new FieldRule("FORMER_SWISS_EBO", FieldKind.SELECT, 821, "Any former Swiss residency known for EBO(s)", true, true,
                "YES\u00acYes;NO\u00acNo", "#PH_DIFFERENT_TO_EBO# == \"YES\"", false, null, false), previousValues, webForm);
    }

    private void buildProofDeregistrationEbo(Group group, Map<String, String> previousValues, WebForm webForm) {
        buildField(group, new FieldRule("PROOF_DEREGISTRATION_EBO", FieldKind.SELECT, 822, "Proof of deregistration received for EBO(s)", true, true,
                "YES\u00acYes;NO\u00acNo", "#FORMER_SWISS_EBO# == \"YES\"", false, null, false), previousValues, webForm);
    }

    private void buildTrusteeResidenceCountryRisk(Group group, Map<String, String> previousValues, WebForm webForm) {
        buildField(group, new FieldRule("TRUSTEE_RESIDENCE_COUNTRY_RISK", FieldKind.TEXT, 900, "Trustee residence country", false, false,
                "#forcedValue", "#forcedDisplayIf", false, "From CLASS", false), previousValues, webForm);
    }

    private void buildBeneficiaryResidenceCountryRisk(Group group, Map<String, String> previousValues, WebForm webForm) {
        buildField(group, new FieldRule("BENEFICIARY_RESIDENCE_COUNTRY_RISK", FieldKind.TEXT, 917, "Beneficiary residence country", false, false,
                "#forcedValue", "#forcedDisplayIf", false, "From CLASS", false), previousValues, webForm);
    }

    private void buildUsIndicia(Group group, Map<String, String> previousValues, WebForm webForm) {
        buildField(group, new FieldRule("US_INDICIA", FieldKind.SELECT, 950, "US indicia detected", true, true,
                "YES\u00acYes;NO\u00acNo", null, false, null, false), previousValues, webForm);
    }

    private void buildFatcaFormRefused(Group group, Map<String, String> previousValues, WebForm webForm) {
        buildField(group, new FieldRule("FATCA_FORM_REFUSED", FieldKind.SELECT, 951, "Did the PH/EBO refuse to sign the FATCA/CRS/AEOI forms and this after several reminders to sign them?", true, true,
                "YES\u00acYes;NO\u00acNo", null, false, null, false), previousValues, webForm);
    }

    private void buildFatcaFormInconsistent(Group group, Map<String, String> previousValues, WebForm webForm) {
        buildField(group, new FieldRule("FATCA_FORM_INCONSISTENT", FieldKind.SELECT, 952, "Is there any unjustified inconsistency between the information provided in the FATCA/CRS/AEOI form and the information collected for AML/KYC purposes (e.g. TIN, tax residency, etc.) and this without any legitimate reason?", true, true,
                "YES\u00acYes;NO\u00acNo", null, false, null, false), previousValues, webForm);
    }

    private void buildTpBlock(Group group, Map<String, String> previousValues, WebForm webForm) {
        buildField(group, new FieldRule("TP_BLOCK", FieldKind.SELECT, 1001, "Transaction block in CLASS for compliance", false, false,
                "#forcedValue", null, false, "From CLASS", false), previousValues, webForm);
    }

}
