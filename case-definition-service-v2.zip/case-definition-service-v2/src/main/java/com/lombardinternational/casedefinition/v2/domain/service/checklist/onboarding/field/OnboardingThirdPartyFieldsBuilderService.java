package com.lombardinternational.casedefinition.v2.domain.service.checklist.onboarding.field;

import com.lombardinternational.casedefinition.v2.domain.model.Group;
import com.lombardinternational.casedefinition.v2.domain.model.ScreenDescription;
import com.lombardinternational.casedefinition.v2.domain.model.WebForm;
import com.lombardinternational.casedefinition.v2.domain.service.checklist.FieldBuilderService;
import org.springframework.stereotype.Service;

import java.util.Map;

@Service
public class OnboardingThirdPartyFieldsBuilderService extends OnboardingChecklistFieldsBuilderSupport implements FieldBuilderService {
    @Override
    public void buildField(WebForm webForm, ScreenDescription screenDescription, Group group) {
        var previousValues = previousValues(screenDescription);
        resetFields(group);
        buildThirdPartyName(group, previousValues, webForm);
        buildLinkThirdPartyPh(group, previousValues, webForm);
        buildAdditionalInfoLink(group, previousValues, webForm);
        buildReasonThirdPartyPayment(group, previousValues, webForm);
        buildThirdPartyCountry(group, previousValues, webForm);
        buildThirdPartyCountryRisk(group, previousValues, webForm);
        sortFields(group);
    }

    private void buildThirdPartyName(Group group, Map<String, String> previousValues, WebForm webForm) {
        buildField(group, new FieldRule("THIRD_PARTY_NAME", FieldKind.TEXT, 1, "3rd party ID", false, true,
                "#forcedValue", null, false, "From Class", true), previousValues, webForm);
    }

    private void buildLinkThirdPartyPh(Group group, Map<String, String> previousValues, WebForm webForm) {
        buildField(group, new FieldRule("LINK_THIRD_PARTY_PH", FieldKind.SELECT, 2, "Link between 3rd party and PH", false, true,
                "#forcedValue", null, false, "From Class", true), previousValues, webForm);
    }

    private void buildAdditionalInfoLink(Group group, Map<String, String> previousValues, WebForm webForm) {
        buildField(group, new FieldRule("ADDITIONAL_INFO_LINK", FieldKind.TEXT_AREA, 3, "Additional info on link between 3rd party and PH", true, false,
                null, "#LINK_THIRD_PARTY_PH# == \"other\"", false, null, false), previousValues, webForm);
    }

    private void buildReasonThirdPartyPayment(Group group, Map<String, String> previousValues, WebForm webForm) {
        buildField(group, new FieldRule("REASON_THIRD_PARTY_PAYMENT", FieldKind.TEXT, 3, "Reason for 3rd party payment", true, false,
                "#forcedValue", null, false, null, true), previousValues, webForm);
    }

    private void buildThirdPartyCountry(Group group, Map<String, String> previousValues, WebForm webForm) {
        buildField(group, new FieldRule("THIRD_PARTY_COUNTRY", FieldKind.SELECT, 4, "3rd party country", false, true,
                "#forcedValue", null, false, "From Class", true), previousValues, webForm);
    }

    private void buildThirdPartyCountryRisk(Group group, Map<String, String> previousValues, WebForm webForm) {
        buildField(group, new FieldRule("THIRD_PARTY_COUNTRY_RISK", FieldKind.TEXT, 10000, "Highest 3rd party risk", false, false,
                "#forcedValue", null, false, "Highest 3rd party risk from Class", false), previousValues, webForm);
    }

}
