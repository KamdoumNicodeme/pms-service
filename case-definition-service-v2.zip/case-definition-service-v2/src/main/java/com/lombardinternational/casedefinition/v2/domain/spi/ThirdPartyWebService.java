package com.lombardinternational.casedefinition.v2.domain.spi;

public interface ThirdPartyWebService {
    com.lombardinternational.clients.classapp.model.thirdparty.ThirdParty getThirdParty(String externalId);
}
