package com.lombardinternational.casedefinition.v2.domain.service.checklist.onboarding.field;

import com.lombardinternational.casedefinition.v2.domain.model.CheckBoxField;
import com.lombardinternational.casedefinition.v2.domain.model.Field;
import com.lombardinternational.casedefinition.v2.domain.model.Group;
import com.lombardinternational.casedefinition.v2.domain.model.NumberInputField;
import com.lombardinternational.casedefinition.v2.domain.model.ScreenDescription;
import com.lombardinternational.casedefinition.v2.domain.model.SelectInputField;
import com.lombardinternational.casedefinition.v2.domain.model.SelectInputFieldOption;
import com.lombardinternational.casedefinition.v2.domain.model.TextAreaField;
import com.lombardinternational.casedefinition.v2.domain.model.TextInputField;
import com.lombardinternational.casedefinition.v2.domain.model.WebForm;
import com.lombardinternational.casedefinition.v2.domain.utils.ChecklistUtils;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Optional;

public abstract class OnboardingChecklistFieldsBuilderSupport {

    protected Map<String, String> previousValues(ScreenDescription screenDescription) {
        return screenDescription == null ? Map.of() : screenDescription.selectedValuesByFieldId();
    }

    protected void resetFields(Group group) {
        group.setFields(new ArrayList<>());
    }

    protected void sortFields(Group group) {
        group.getFields().sort(Comparator.comparingInt(Field::getOrder).thenComparing(Field::getFieldId));
    }

    protected Field buildField(Group group, FieldRule rule, Map<String, String> previousValues, WebForm webForm) {
        var field = field(group, rule.fieldId(), rule.kind());
        field.setIsActive(true);
        field.setOrder(rule.order());
        field.setLabel(rule.label());
        field.setEnabled(rule.enabled());
        field.setMandatory(rule.mandatory());
        field.setDisplayIf(blankToNull(rule.displayIf()));
        field.setLabelBold(rule.labelBold());
        field.setSourceSystem(blankToNull(rule.sourceSystem()));
        field.setSelectedValue(resolveSelectedValue(rule, previousValues, webForm));
        if (field instanceof SelectInputField selectInputField) {
            selectInputField.setOptions(parseOptions(rule.valueOptions()));
        }
        return field;
    }

    private Field field(Group group, String fieldId, FieldKind kind) {
        return switch (ChecklistUtils.getFieldInGroup(group, fieldId)) {
            case null -> {
                var field = switch (kind) {
                    case SELECT -> SelectInputField.builder().fieldId(fieldId).build();
                    case NUMBER -> NumberInputField.builder().fieldId(fieldId).build();
                    case TEXT_AREA -> TextAreaField.builder().fieldId(fieldId).build();
                    case CHECK_BOX -> CheckBoxField.builder().fieldId(fieldId).build();
                    case TEXT -> TextInputField.builder().fieldId(fieldId).build();
                };
                group.getFields().add(field);
                yield field;
            }
            case SelectInputField field when kind == FieldKind.SELECT -> field;
            case NumberInputField field when kind == FieldKind.NUMBER -> field;
            case TextAreaField field when kind == FieldKind.TEXT_AREA -> field;
            case CheckBoxField field when kind == FieldKind.CHECK_BOX -> field;
            case TextInputField field when kind == FieldKind.TEXT -> field;
            default -> throw new IllegalStateException("Field " + fieldId + " must be a " + kind.fieldClass().getSimpleName());
        };
    }

    private String resolveSelectedValue(FieldRule rule, Map<String, String> previousValues, WebForm webForm) {
        return Optional.ofNullable(previousValues.get(rule.fieldId()))
                .or(() -> selectedValueFromWebForm(rule, webForm))
                .or(() -> selectedValueFromStaticValue(rule.valueOptions()))
                .orElse(null);
    }

    private Optional<String> selectedValueFromWebForm(FieldRule rule, WebForm webForm) {
        if (!"#forcedValue".equals(rule.valueOptions()) || webForm == null) {
            return Optional.empty();
        }
        return webForm.findFieldValue(rule.fieldId());
    }

    private Optional<String> selectedValueFromStaticValue(String valueOptions) {
        if (valueOptions == null || valueOptions.isBlank() || valueOptions.startsWith("#") || looksLikeOptionList(valueOptions)
                || valueOptions.endsWith("String")) {
            return Optional.empty();
        }
        return Optional.of(valueOptions);
    }

    private List<SelectInputFieldOption> parseOptions(String valueOptions) {
        if (valueOptions == null || valueOptions.isBlank() || valueOptions.startsWith("#") || valueOptions.endsWith("String")
                || !looksLikeOptionList(valueOptions)) {
            return List.of();
        }
        List<SelectInputFieldOption> options = new ArrayList<>();
        for (String item : valueOptions.split(";")) {
            if (item.isBlank()) {
                continue;
            }
            String[] parts = item.split("\u00ac", 2);
            String key = parts[0].trim();
            String value = parts.length > 1 ? parts[1].trim() : key;
            options.add(new SelectInputFieldOption(key, value));
        }
        return options;
    }

    private boolean looksLikeOptionList(String valueOptions) {
        return valueOptions.contains(";") || valueOptions.contains("\u00ac");
    }

    private String blankToNull(String value) {
        return value == null || value.isBlank() ? null : value;
    }

    protected enum FieldKind {
        SELECT(SelectInputField.class),
        NUMBER(NumberInputField.class),
        TEXT(TextInputField.class),
        TEXT_AREA(TextAreaField.class),
        CHECK_BOX(CheckBoxField.class);

        private final Class<? extends Field> fieldClass;

        FieldKind(Class<? extends Field> fieldClass) {
            this.fieldClass = fieldClass;
        }

        Class<? extends Field> fieldClass() {
            return fieldClass;
        }
    }

    protected record FieldRule(String fieldId, FieldKind kind, int order, String label, boolean enabled, boolean mandatory,
                               String valueOptions, String displayIf, boolean labelBold, String sourceSystem, boolean repeatable) {
    }
}
