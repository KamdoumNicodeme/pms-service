package com.lombardinternational.casedefinition.v2.adapter.api.web.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

import java.util.ArrayList;
import java.util.List;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class DocumentRequiredSignatory {
    private String documentType;
    private String documentRelatedTo;
    private boolean documentMustBeGenerated;
    private boolean documentRequiredOnConnect;
    private String description;
    private String i18NDescription;
    private int documentOrder;
    private List<RequiredSignatory> requiredSignatories = new ArrayList<>();
    private String cmsDocumentType;
}
