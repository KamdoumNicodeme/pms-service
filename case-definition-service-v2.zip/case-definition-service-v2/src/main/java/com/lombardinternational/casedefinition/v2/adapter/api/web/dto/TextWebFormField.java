package com.lombardinternational.casedefinition.v2.adapter.api.web.dto;

public class TextWebFormField extends WebFormField {
}
