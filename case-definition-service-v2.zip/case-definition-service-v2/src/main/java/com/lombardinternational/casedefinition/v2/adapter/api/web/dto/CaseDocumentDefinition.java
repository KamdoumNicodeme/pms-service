package com.lombardinternational.casedefinition.v2.adapter.api.web.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class CaseDocumentDefinition {
    private String documentType;
    private String documentRelatedTo;
    private String i18NDocumentRelatedTo;
    private String i18NDocumentRelatedToParam;
    private String relatedToPolicyNumber;
    private String relatedToThirdpartyId;
    private boolean documentRequired;
    private boolean documentVisibleOnConnect;
    private String copyBusinessKey;
    private String originalBusinessKey;
    private String exceptionBusinessKey;
    private int documentOrder;
    private String description;
    private String i18NDescription;
    private String documentSharepointId;
    private String cmsDocumentType;
    private boolean neverDisplayExternally;
}
