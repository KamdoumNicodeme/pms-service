package com.lombardinternational.casedefinition.v2.adapter.spi.service.rest.mapper;

import com.lombardinternational.casedefinition.v2.domain.model.CurrencyExchangeRate;
import com.lombardinternational.clients.fxrates.model.FxRate;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import java.util.List;

@Mapper
public interface FxRateMapper {
    @Mapping(source = "source", target = "provider")
    @Mapping(source = "fxRateDate", target = "rateDate")
    @Mapping(source = "fxRateTime", target = "rateTime")
    @Mapping(source = "bareRate", target = "rate")
    @Mapping(source = "fromCcy", target = "baseIsoCurrencyCode")
    @Mapping(source = "toCcy", target = "quotedIsoCurrencyCode")
    CurrencyExchangeRate toCurrencyExchangeRate(FxRate fxRate);

    List<CurrencyExchangeRate> toCurrencyExchangeRates(List<FxRate> fxRates);
}
