package com.lombardinternational.casedefinition.v2.adapter.api.web.dto;

public record ScreenDescriptionRequest(String policyNumber, String caseType, String businessTransactionNumber,
                                       WebForm caseInitializationData, ScreenDescription screenDescription,
                                       ScreenDescription screenCheckList) {
}
