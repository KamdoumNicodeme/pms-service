package com.lombardinternational.casedefinition.v2.config;

import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import java.math.BigDecimal;
import java.util.LinkedHashMap;
import java.util.Map;

@Getter
@Setter
@Configuration
@ConfigurationProperties(prefix = "case-definition.fx-rates")
public class FxRateProperties {
    private String defaultTargetCurrency = "EUR";
    private long cacheRefreshDelayMs = 86_400_000L;
    private Map<String, BigDecimal> rates = new LinkedHashMap<>();
}
