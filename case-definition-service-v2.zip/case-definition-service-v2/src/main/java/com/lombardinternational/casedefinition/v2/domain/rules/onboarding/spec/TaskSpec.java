package com.lombardinternational.casedefinition.v2.domain.rules.onboarding.spec;

import java.util.List;

public record TaskSpec(boolean mandatory, boolean suggested, String mainTaskName, String dynamicScreenId, int order,
                       String mainTaskExpectedDuration, String signoffTaskExpectedDuration, boolean releasableFromSubTask,
                       String reason, List<String> conditions, String technicalAction, String ruleName) {
}
