package com.lombardinternational.casedefinition.v2.domain.model;

import lombok.Data;

@Data
public class ThirdParty {
    private String externalId;
    private String name;
}
