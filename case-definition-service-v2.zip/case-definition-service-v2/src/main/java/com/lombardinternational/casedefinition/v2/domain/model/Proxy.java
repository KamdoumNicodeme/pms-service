package com.lombardinternational.casedefinition.v2.domain.model;

public class Proxy extends PolicyRole {
}
