package com.lombardinternational.casedefinition.v2.adapter.api.web.mapper;

import com.lombardinternational.casedefinition.v2.domain.model.WebFormField;
import org.mapstruct.Mapper;

import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Objects;

@Mapper(componentModel = "spring")
public interface WebFormFieldMapper {
    default WebFormField webFormFieldFromDTO(com.lombardinternational.casedefinition.v2.adapter.api.web.dto.WebFormField dto) {
        if (dto == null) {
            return null;
        }
        WebFormField field = new WebFormField();
        field.setFieldId(dto.getFieldId());
        field.setValue(toStringValue(dto.getValue()));
        field.setSelectedValue(dto.getSelectedValue());
        field.setTextValue(dto.getTextValue());
        field.setAttributes(dto.getAttributes() == null ? new LinkedHashMap<>() : new LinkedHashMap<>(dto.getAttributes()));
        if (dto.getLabel() != null) {
            field.getAttributes().put("label", dto.getLabel());
        }
        return field;
    }

    default com.lombardinternational.casedefinition.v2.adapter.api.web.dto.WebFormField dtoFromWebFormField(WebFormField field) {
        if (field == null) {
            return null;
        }
        var dto = new com.lombardinternational.casedefinition.v2.adapter.api.web.dto.WebFormField();
        dto.setFieldId(field.getFieldId());
        dto.setValue(field.getValue());
        dto.setSelectedValue(field.getSelectedValue());
        dto.setTextValue(field.getTextValue());
        dto.setAttributes(field.getAttributes() == null ? new LinkedHashMap<>() : new LinkedHashMap<>(field.getAttributes()));
        Object label = dto.getAttributes().remove("label");
        dto.setLabel(toStringValue(label));
        return dto;
    }

    default List<WebFormField> webFormFieldFromDTO(Collection<? extends com.lombardinternational.casedefinition.v2.adapter.api.web.dto.WebFormField> dtos) {
        if (dtos == null) {
            return List.of();
        }
        return dtos.stream().map(this::webFormFieldFromDTO).filter(Objects::nonNull).toList();
    }

    default List<com.lombardinternational.casedefinition.v2.adapter.api.web.dto.WebFormField> dtoFromWebFormField(Collection<WebFormField> fields) {
        if (fields == null) {
            return List.of();
        }
        return fields.stream().map(this::dtoFromWebFormField).filter(Objects::nonNull).toList();
    }

    default String toStringValue(Object value) {
        return value == null ? null : value.toString();
    }
}
