package com.lombardinternational.casedefinition.v2.domain.service.checklist.onboarding;

import com.lombardinternational.casedefinition.v2.domain.model.Group;
import com.lombardinternational.casedefinition.v2.domain.model.ScreenDescription;
import com.lombardinternational.casedefinition.v2.domain.model.Tab;
import com.lombardinternational.casedefinition.v2.domain.model.WebForm;
import com.lombardinternational.casedefinition.v2.domain.transaction.onboarding.rules.OnboardingTransactionIds;
import com.lombardinternational.casedefinition.v2.domain.service.checklist.ChecklistBuilderService;
import com.lombardinternational.casedefinition.v2.domain.service.checklist.GroupBuilderService;
import com.lombardinternational.casedefinition.v2.domain.service.checklist.onboarding.group.OnboardingCaseRiskGroupBuilderService;
import com.lombardinternational.casedefinition.v2.domain.service.checklist.onboarding.group.OnboardingDueDiligenceGroupBuilderService;
import com.lombardinternational.casedefinition.v2.domain.service.checklist.onboarding.group.OnboardingGeneralDetailsGroupBuilderService;
import com.lombardinternational.casedefinition.v2.domain.service.checklist.onboarding.group.OnboardingIntermediationGroupBuilderService;
import com.lombardinternational.casedefinition.v2.domain.service.checklist.onboarding.group.OnboardingLifeCoverGroupBuilderService;
import com.lombardinternational.casedefinition.v2.domain.service.checklist.onboarding.group.OnboardingPricingApprovalGroupBuilderService;
import com.lombardinternational.casedefinition.v2.domain.service.checklist.onboarding.group.OnboardingSignatureGroupBuilderService;
import com.lombardinternational.casedefinition.v2.domain.service.checklist.onboarding.group.OnboardingSignoffsGroupBuilderService;
import com.lombardinternational.casedefinition.v2.domain.service.checklist.onboarding.group.OnboardingThirdPartyGroupBuilderService;
import com.lombardinternational.casedefinition.v2.domain.service.checklist.onboarding.group.OnboardingTransactionDetailsGroupBuilderService;
import com.lombardinternational.casedefinition.v2.domain.service.checklist.onboarding.enrichment.ExpectedPremiumInEurEnrichmentService;
import com.lombardinternational.casedefinition.v2.domain.utils.ChecklistUtils;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.Comparator;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static com.lombardinternational.casedefinition.v2.domain.transaction.onboarding.rules.OnboardingChecklistIds.CHECKLIST_TAB;

@Service
@AllArgsConstructor
public class OnboardingChecklistBuilderService implements ChecklistBuilderService {
    private final OnboardingGeneralDetailsGroupBuilderService generalDetailsGroupBuilderService;
    private final OnboardingLifeCoverGroupBuilderService lifeCoverGroupBuilderService;
    private final OnboardingIntermediationGroupBuilderService intermediationGroupBuilderService;
    private final OnboardingSignatureGroupBuilderService signatureGroupBuilderService;
    private final OnboardingPricingApprovalGroupBuilderService pricingApprovalGroupBuilderService;
    private final OnboardingSignoffsGroupBuilderService signoffsGroupBuilderService;
    private final OnboardingDueDiligenceGroupBuilderService dueDiligenceGroupBuilderService;
    private final OnboardingTransactionDetailsGroupBuilderService transactionDetailsGroupBuilderService;
    private final OnboardingThirdPartyGroupBuilderService thirdPartyGroupBuilderService;
    private final OnboardingCaseRiskGroupBuilderService caseRiskGroupBuilderService;
    private final ExpectedPremiumInEurEnrichmentService expectedPremiumInEurEnrichmentService;

    @Override
    public ScreenDescription buildChecklist(WebForm webForm, ScreenDescription screenDescription, String policyNumber, String transactionNumber) {
        final var checklistScreen = Optional.ofNullable(screenDescription)
                .orElseGet(() -> ScreenDescription.builder().screenId(OnboardingTransactionIds.CHECKLIST_SCREEN_ID).build());
        checklistScreen.setScreenId(OnboardingTransactionIds.CHECKLIST_SCREEN_ID);

        final var checklistTab = Optional.ofNullable(ChecklistUtils.getTabInScreenDescription(checklistScreen, CHECKLIST_TAB))
                .orElse(Tab.builder().tabId(CHECKLIST_TAB).order(1).type("FormTab").label("Checklist").build());
        checklistTab.setIsActive(true);
        checklistScreen.setTabs(Collections.singletonList(checklistTab));

        Group.resetGroupId();
        List<GroupBuilderService> groupBuilderServices = List.of(
                generalDetailsGroupBuilderService,
                lifeCoverGroupBuilderService,
                intermediationGroupBuilderService,
                signatureGroupBuilderService,
                pricingApprovalGroupBuilderService,
                signoffsGroupBuilderService,
                dueDiligenceGroupBuilderService,
                transactionDetailsGroupBuilderService,
                thirdPartyGroupBuilderService,
                caseRiskGroupBuilderService
        );
        groupBuilderServices.forEach(groupBuilderService -> groupBuilderService.buildGroup(webForm, checklistScreen, checklistTab));
        checklistTab.getGroups().sort(Comparator.comparingInt(Group::getOrder).thenComparing(Group::getGroupId));
        expectedPremiumInEurEnrichmentService.enrich(checklistScreen, webForm);
        return checklistScreen;
    }
}
