package com.lombardinternational.casedefinition.v2.domain.service.checklist.onboarding.group;

import com.lombardinternational.casedefinition.v2.domain.model.Group;
import com.lombardinternational.casedefinition.v2.domain.model.ScreenDescription;
import com.lombardinternational.casedefinition.v2.domain.model.Tab;
import com.lombardinternational.casedefinition.v2.domain.model.WebForm;
import com.lombardinternational.casedefinition.v2.domain.service.checklist.GroupBuilderService;
import com.lombardinternational.casedefinition.v2.domain.service.checklist.onboarding.field.OnboardingTransactionDetailsFieldsBuilderService;
import com.lombardinternational.casedefinition.v2.domain.utils.ChecklistUtils;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import static com.lombardinternational.casedefinition.v2.domain.transaction.onboarding.rules.OnboardingChecklistIds.TRANSACTIONS_DETAILS_GROUP;

@Service
@AllArgsConstructor
public class OnboardingTransactionDetailsGroupBuilderService implements GroupBuilderService {
    private final OnboardingTransactionDetailsFieldsBuilderService fieldsBuilderService;

    @Override
    public void buildGroup(WebForm webForm, ScreenDescription screenDescription, Tab parentTab) {
        var transactionDetailsGroup = ChecklistUtils.getGroupInTab(parentTab, TRANSACTIONS_DETAILS_GROUP);
        if (transactionDetailsGroup == null) {
            transactionDetailsGroup = Group.builder().groupId(TRANSACTIONS_DETAILS_GROUP).build();
            parentTab.getGroups().add(transactionDetailsGroup);
        }

        transactionDetailsGroup.setIsActive(true);
        transactionDetailsGroup.setOrder(100);
        transactionDetailsGroup.setTitle("Transaction details");
        transactionDetailsGroup.setColumnsCount(2);
        transactionDetailsGroup.setDisplayIf(null);
        fieldsBuilderService.buildField(webForm, screenDescription, transactionDetailsGroup);
    }
}
