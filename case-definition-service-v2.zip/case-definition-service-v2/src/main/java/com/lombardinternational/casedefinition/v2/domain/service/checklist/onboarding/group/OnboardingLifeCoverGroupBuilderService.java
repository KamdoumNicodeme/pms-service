package com.lombardinternational.casedefinition.v2.domain.service.checklist.onboarding.group;

import com.lombardinternational.casedefinition.v2.domain.model.Group;
import com.lombardinternational.casedefinition.v2.domain.model.ScreenDescription;
import com.lombardinternational.casedefinition.v2.domain.model.Tab;
import com.lombardinternational.casedefinition.v2.domain.model.WebForm;
import com.lombardinternational.casedefinition.v2.domain.service.checklist.GroupBuilderService;
import com.lombardinternational.casedefinition.v2.domain.service.checklist.onboarding.field.OnboardingLifeCoverFieldsBuilderService;
import com.lombardinternational.casedefinition.v2.domain.utils.ChecklistUtils;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import static com.lombardinternational.casedefinition.v2.domain.transaction.onboarding.rules.OnboardingChecklistIds.LIFE_COVER_GROUP;

@Service
@AllArgsConstructor
public class OnboardingLifeCoverGroupBuilderService implements GroupBuilderService {
    private final OnboardingLifeCoverFieldsBuilderService fieldsBuilderService;

    @Override
    public void buildGroup(WebForm webForm, ScreenDescription screenDescription, Tab parentTab) {
        var group = ChecklistUtils.getGroupInTab(parentTab, LIFE_COVER_GROUP);
        if (group == null) {
            group = Group.builder().groupId(LIFE_COVER_GROUP).build();
            parentTab.getGroups().add(group);
        }

        group.setIsActive(true);
        group.setOrder(2);
        group.setTitle("Life Cover Type");
        group.setColumnsCount(2);
        group.setDisplayIf("#CONTRACT_TYPE# == \"Capitalised policy\"");
        fieldsBuilderService.buildField(webForm, screenDescription, group);
    }
}
