package com.lombardinternational.casedefinition.v2.domain.model;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Stream;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class WebForm {
    private UserDetail userDetail;
    private CompanyDetail companyDetail;
    private FormInitiator formInitiator;
    private String webFormId;
    private String webFormWorkFlow;
    @JsonAlias({"groups", "caseInitializationData"})
    private List<WebFormGroup> webFormGroups = new ArrayList<>();

    public Optional<String> findFieldValue(String fieldId) {
        return groups().map(group -> group.findFieldValue(fieldId)).filter(Optional::isPresent).map(Optional::get).findFirst();
    }

    public Stream<WebFormGroup> groups() {
        if (webFormGroups == null) {
            return Stream.empty();
        }
        return webFormGroups.stream().filter(Objects::nonNull);
    }
}
