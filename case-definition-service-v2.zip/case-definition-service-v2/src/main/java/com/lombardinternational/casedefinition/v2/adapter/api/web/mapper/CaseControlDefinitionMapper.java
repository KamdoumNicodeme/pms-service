package com.lombardinternational.casedefinition.v2.adapter.api.web.mapper;

import com.lombardinternational.casedefinition.v2.domain.model.CaseControlDefinition;
import org.mapstruct.Mapper;

import java.util.List;

@Mapper(componentModel = "spring")
public interface CaseControlDefinitionMapper {
    List<com.lombardinternational.casedefinition.v2.adapter.api.web.dto.CaseControlDefinition> dtoFromCaseControlDefinition(
            List<CaseControlDefinition> definitions);
}
