package com.lombardinternational.casedefinition.v2.domain.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Stream;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class ScreenDescription {
    private String screenId;
    @Builder.Default
    private List<Tab> tabs = new ArrayList<>();

    public Optional<Field> findField(String fieldId) {
        return fields().filter(field -> Objects.equals(field.getFieldId(), fieldId)).findFirst();
    }

    public Map<String, String> selectedValuesByFieldId() {
        Map<String, String> values = new LinkedHashMap<>();
        fields().filter(field -> field.getSelectedValue() != null).forEach(field -> values.put(field.getFieldId(), field.getSelectedValue()));
        return values;
    }

    public Stream<Field> fields() {
        if (tabs == null) {
            return Stream.empty();
        }
        return tabs.stream()
                .filter(Objects::nonNull)
                .flatMap(tab -> tab.getGroups() == null ? Stream.empty() : tab.getGroups().stream())
                .filter(Objects::nonNull)
                .flatMap(group -> group.getFields() == null ? Stream.empty() : group.getFields().stream())
                .filter(Objects::nonNull);
    }
}
