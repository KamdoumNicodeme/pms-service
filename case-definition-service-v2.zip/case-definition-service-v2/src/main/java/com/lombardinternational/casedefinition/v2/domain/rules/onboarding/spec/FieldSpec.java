package com.lombardinternational.casedefinition.v2.domain.rules.onboarding.spec;

public record FieldSpec(String screenId, String groupId, String fieldId, String fieldType, int order, String label,
                        boolean enabled, boolean mandatory, String valueOptions, String displayIf, boolean labelBold,
                        String sourceSystem, boolean repeatable) {
}
