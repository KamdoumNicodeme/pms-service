package com.lombardinternational.casedefinition.v2.adapter.api.web.mapper;

import com.lombardinternational.casedefinition.v2.domain.model.FormInitiator;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface FormInitiatorlMapper {
    FormInitiator formInitiatorFromDTO(com.lombardinternational.casedefinition.v2.adapter.api.web.dto.FormInitiator dto);

    com.lombardinternational.casedefinition.v2.adapter.api.web.dto.FormInitiator dtoFromFormInitiator(FormInitiator formInitiator);
}
