package com.lombardinternational.casedefinition.v2.domain.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.concurrent.atomic.AtomicInteger;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CaseDocumentDefinition {
    private static final AtomicInteger currentOrder = new AtomicInteger(1);

    private String documentType;
    private String documentRelatedTo;
    private String i18NDocumentRelatedTo;
    private String i18NDocumentRelatedToParam;
    private String relatedToPolicyNumber;
    private String relatedToThirdpartyId;
    @Builder.Default
    private boolean documentRequired = false;
    @Builder.Default
    private boolean documentVisibleOnConnect = false;
    private String copyBusinessKey;
    private String originalBusinessKey;
    private String exceptionBusinessKey;
    private int documentOrder;
    private String description;
    private String i18NDescription;
    private String documentSharepointId;
    private String cmsDocumentType;
    @Builder.Default
    private boolean neverDisplayExternally = false;

    public static void resetDocumentOrder() {
        currentOrder.set(1);
    }

    public void incrementOrder() {
        this.documentOrder = currentOrder.getAndIncrement();
    }
}
