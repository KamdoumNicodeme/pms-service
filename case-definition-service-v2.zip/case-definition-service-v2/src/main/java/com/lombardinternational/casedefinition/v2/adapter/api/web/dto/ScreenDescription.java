package com.lombardinternational.casedefinition.v2.adapter.api.web.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class ScreenDescription {
    private LocalDate loadTimeStamp;
    @NotBlank(message = "screenId is mandatory")
    private String screenId;
    private ScreenDescription inputedScreenDescription;
    @Builder.Default
    private List<Tab> tabs = new ArrayList<>();
}
