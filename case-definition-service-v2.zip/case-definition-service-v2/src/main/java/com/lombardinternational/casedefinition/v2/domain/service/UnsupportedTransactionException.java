package com.lombardinternational.casedefinition.v2.domain.service;

public class UnsupportedTransactionException extends RuntimeException {
    public UnsupportedTransactionException(String message) {
        super(message);
    }
}
