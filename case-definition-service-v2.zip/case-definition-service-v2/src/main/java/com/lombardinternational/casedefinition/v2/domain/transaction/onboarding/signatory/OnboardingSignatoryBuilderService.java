package com.lombardinternational.casedefinition.v2.domain.transaction.onboarding.signatory;

import com.lombardinternational.casedefinition.v2.domain.model.DocumentRequiredSignatory;
import com.lombardinternational.casedefinition.v2.domain.model.RequiredSignatory;
import com.lombardinternational.casedefinition.v2.domain.model.SignatoryResult;
import com.lombardinternational.casedefinition.v2.domain.model.WebForm;
import com.lombardinternational.casedefinition.v2.domain.transaction.onboarding.signatory.definition.OnboardingSignatureDefinitionProvider;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class OnboardingSignatoryBuilderService {
    private final OnboardingSignatureRuleMatcher matcher;
    private final OnboardingSignatoryCollector signatoryCollector;
    private final OnboardingSignatureDefinitionProvider signatureDefinitionProvider;

    public SignatoryResult buildSignatories(WebForm webForm, String policyNumber) {
        var signatoriesByType = signatoryCollector.collectByType(webForm);
        Map<String, String> responseMessages = new LinkedHashMap<>();

        var documents = signatureDefinitionProvider.documents().stream()
                .filter(spec -> matcher.matches(spec, webForm))
                .peek(spec -> responseMessages.putAll(spec.responseMessages()))
                .sorted(Comparator.comparingInt(SignatureDocumentSpec::documentOrder).thenComparing(SignatureDocumentSpec::ruleName))
                .map(spec -> buildDocument(spec, signatoriesByType, policyNumber))
                .toList();

        responseMessages.putIfAbsent("STATUS", "OK");
        responseMessages.putIfAbsent("MESSAGE", "");
        responseMessages.putIfAbsent("MESSAGE_I18N", "");

        return SignatoryResult.builder()
                .documentRequiredSignatories(documents)
                .responseMessages(responseMessages)
                .build();
    }

    private DocumentRequiredSignatory buildDocument(SignatureDocumentSpec spec, Map<String, List<RequiredSignatory>> signatoriesByType,
            String policyNumber) {
        return DocumentRequiredSignatory.builder()
                .documentType(spec.documentType())
                .cmsDocumentType(spec.cmsDocumentType())
                .documentRelatedTo(resolveRelatedTo(spec, policyNumber))
                .documentMustBeGenerated(spec.documentMustBeGenerated())
                .documentRequiredOnConnect(spec.documentRequiredOnConnect())
                .documentOrder(spec.documentOrder())
                .requiredSignatories(requiredSignatories(spec, signatoriesByType))
                .build();
    }

    private String resolveRelatedTo(SignatureDocumentSpec spec, String policyNumber) {
        if (OnboardingWebFormNavigator.hasText(spec.secondaryDocumentRelatedTo())) {
            return spec.secondaryDocumentRelatedTo();
        }
        if ("relatedTo".equals(spec.documentRelatedToExpression()) || "relatedToPolicy".equals(spec.documentRelatedToExpression())) {
            return policyNumber;
        }
        return Optional.ofNullable(spec.documentRelatedToExpression()).filter(OnboardingWebFormNavigator::hasText).orElse(policyNumber);
    }

    private List<RequiredSignatory> requiredSignatories(SignatureDocumentSpec spec, Map<String, List<RequiredSignatory>> signatoriesByType) {
        if (spec.requestedSignatoryTypes().contains("DYNAMIC")) {
            return signatoriesByType.values().stream().flatMap(List::stream).map(signatory -> copyWithAllowedActions(signatory, spec.allowedActions()))
                    .toList();
        }
        return spec.requestedSignatoryTypes().stream()
                .map(this::normalizeRequestedType)
                .flatMap(type -> signatoriesByType.getOrDefault(type, List.of()).stream())
                .map(signatory -> copyWithAllowedActions(signatory, spec.allowedActions()))
                .toList();
    }

    private String normalizeRequestedType(String type) {
        return switch (type) {
            case "ADMINISTRATOR_CONTROLLING_PERSON" -> "ADMINISTRATOR";
            case "IRREVOCABLE_BENEFICIARY" -> "IRREVOCABLE_BENEFICIARY";
            default -> type;
        };
    }

    private RequiredSignatory copyWithAllowedActions(RequiredSignatory source, List<String> allowedActions) {
        return RequiredSignatory.builder()
                .thirdpartyId(source.getThirdpartyId())
                .externalId(source.getExternalId())
                .type(finalType(source.getType()))
                .name(source.getName())
                .firstName(source.getFirstName())
                .lastName(source.getLastName())
                .email(source.getEmail())
                .phoneNumber(source.getPhoneNumber())
                .label(source.getLabel())
                .signerId(source.getSignerId())
                .allowedActions(allowedActions)
                .onBehalfOf(source.getOnBehalfOf())
                .build();
    }

    private String finalType(String type) {
        return switch (type) {
            case "ADMINISTRATOR_CONTROLLING_PERSON" -> "ADMINISTRATOR";
            case "IRREVOCABLE_BENEFICIARY" -> "BENEFICIARY";
            default -> type;
        };
    }
}
