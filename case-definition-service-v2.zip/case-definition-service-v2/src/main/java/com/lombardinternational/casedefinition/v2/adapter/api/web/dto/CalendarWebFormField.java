package com.lombardinternational.casedefinition.v2.adapter.api.web.dto;

public class CalendarWebFormField extends WebFormField {
}
