package com.lombardinternational.casedefinition.v2.domain.model;

public class Settlor extends PolicyRole {
}
