package com.lombardinternational.casedefinition.v2.domain.spi;

import com.lombardinternational.casedefinition.v2.domain.model.*;

import java.util.List;
import java.util.Map;

public interface RulesWebService {
    ScreenDescription computeScreenDescription(Policy policy, BusinessTransaction businessTransaction, WebForm webForm,
            ScreenDescription screenDescriptionToBuild, Map<String, CaseDeal> caseDeals, List<CurrencyExchangeRate> fxRates);

    List<TaskDefinition> computeTaskDefinition(Policy policy, WebForm webForm, ScreenDescription screenCheckList);

    List<CaseDocumentDefinition> computeCaseDocumentsDefinition(Policy policy, WebForm webForm,
            ScreenDescription screenCheckList);

    ScreenDescription computeTaskScreen(WebForm webForm, ScreenDescription screenCheckList, ScreenDescription screenToFill);

    List<CaseControlDefinition> computeCaseControlDefinitions(WebForm webForm, ScreenDescription screenCheckList);

    SignatoryResult computeSignatories(Policy policy, WebForm webForm);
}
