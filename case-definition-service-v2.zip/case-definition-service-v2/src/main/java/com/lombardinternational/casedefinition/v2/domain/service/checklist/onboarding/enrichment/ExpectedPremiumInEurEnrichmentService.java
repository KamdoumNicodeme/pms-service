package com.lombardinternational.casedefinition.v2.domain.service.checklist.onboarding.enrichment;

import com.lombardinternational.casedefinition.v2.domain.api.AmountService;
import com.lombardinternational.casedefinition.v2.domain.model.Amount;
import com.lombardinternational.casedefinition.v2.domain.model.Field;
import com.lombardinternational.casedefinition.v2.domain.model.ScreenDescription;
import com.lombardinternational.casedefinition.v2.domain.model.WebForm;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.Locale;
import java.util.Optional;

import static com.lombardinternational.casedefinition.v2.domain.transaction.onboarding.rules.OnboardingChecklistIds.EXPECTED_PREM;
import static com.lombardinternational.casedefinition.v2.domain.transaction.onboarding.rules.OnboardingChecklistIds.EXPECTED_PREM_EUR;
import static com.lombardinternational.casedefinition.v2.domain.transaction.onboarding.rules.OnboardingChecklistIds.POLICY_CUR;

@Service
@RequiredArgsConstructor
public class ExpectedPremiumInEurEnrichmentService {
    private static final String EUR = "EUR";

    private final AmountService amountService;

    public void enrich(ScreenDescription checklist, WebForm webForm) {
        var targetField = checklist.findField(EXPECTED_PREM_EUR).orElse(null);
        if (targetField == null || hasText(targetField.getSelectedValue())) {
            return;
        }

        var policyCurrency = valueOf(checklist, webForm, POLICY_CUR).map(this::normalizeCurrency).orElse(null);
        if (!hasText(policyCurrency) || EUR.equals(policyCurrency)) {
            return;
        }

        valueOf(checklist, webForm, EXPECTED_PREM)
                .flatMap(this::parseAmount)
                .map(amount -> new Amount(amount, policyCurrency))
                .map(amount -> amountService.convertAmount(amount, EUR))
                .map(Amount::getQuantity)
                .map(BigDecimal::toPlainString)
                .ifPresent(targetField::setSelectedValue);
    }

    private Optional<String> valueOf(ScreenDescription checklist, WebForm webForm, String fieldId) {
        return checklist.findField(fieldId).map(Field::getSelectedValue).filter(this::hasText)
                .or(() -> webForm == null ? Optional.empty() : webForm.findFieldValue(fieldId));
    }

    private Optional<BigDecimal> parseAmount(String value) {
        try {
            return Optional.of(new BigDecimal(value.replace(" ", "").replace(",", ".")));
        } catch (NumberFormatException ex) {
            return Optional.empty();
        }
    }

    private String normalizeCurrency(String currency) {
        return currency == null ? null : currency.trim().toUpperCase(Locale.ROOT);
    }

    private boolean hasText(String value) {
        return value != null && !value.isBlank();
    }
}
