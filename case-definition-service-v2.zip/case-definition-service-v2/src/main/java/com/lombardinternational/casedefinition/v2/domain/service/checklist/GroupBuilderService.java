package com.lombardinternational.casedefinition.v2.domain.service.checklist;

import com.lombardinternational.casedefinition.v2.domain.model.ScreenDescription;
import com.lombardinternational.casedefinition.v2.domain.model.Tab;
import com.lombardinternational.casedefinition.v2.domain.model.WebForm;

public interface GroupBuilderService {
    void buildGroup(WebForm webForm, ScreenDescription screenDescription, Tab parentTab);
}
