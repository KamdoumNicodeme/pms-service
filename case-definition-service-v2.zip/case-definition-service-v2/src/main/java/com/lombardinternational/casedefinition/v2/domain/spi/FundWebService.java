package com.lombardinternational.casedefinition.v2.domain.spi;

import com.lombardinternational.casedefinition.v2.domain.model.Fund;

import java.util.List;

public interface FundWebService {
    List<Fund> getFunds(String policyNumber);
}
