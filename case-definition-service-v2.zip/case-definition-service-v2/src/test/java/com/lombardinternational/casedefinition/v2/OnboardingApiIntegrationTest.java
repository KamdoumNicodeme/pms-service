package com.lombardinternational.casedefinition.v2;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.lombardinternational.casedefinition.v2.adapter.api.web.dto.CaseControlRequest;
import com.lombardinternational.casedefinition.v2.adapter.api.web.dto.CaseDocumentRequest;
import com.lombardinternational.casedefinition.v2.adapter.api.web.dto.CaseSubTaskRequest;
import com.lombardinternational.casedefinition.v2.adapter.api.web.dto.ScreenDescription;
import com.lombardinternational.casedefinition.v2.adapter.api.web.dto.ScreenDescriptionRequest;
import com.lombardinternational.casedefinition.v2.adapter.api.web.dto.WebForm;
import com.lombardinternational.casedefinition.v2.adapter.api.web.dto.WebformSignatoryRequest;
import com.lombardinternational.casedefinition.v2.domain.transaction.onboarding.rules.OnboardingTransactionIds;
import com.lombardinternational.casemanagement.clients.casebusinesscase.client.CaseClient;
import com.lombardinternational.clients.classapp.client.BusinessTransactionClient;
import com.lombardinternational.clients.classapp.client.FundServiceClient;
import com.lombardinternational.clients.classapp.client.PolicyServiceClient;
import com.lombardinternational.clients.classapp.client.ThirdPartyServiceClient;
import com.lombardinternational.clients.fxrates.client.FxRatesServiceClient;
import com.lombardinternational.clients.fxrates.model.FxRate;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.not;
import static org.hamcrest.Matchers.empty;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@AutoConfigureMockMvc
class OnboardingApiIntegrationTest {
    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @MockBean
    private FxRatesServiceClient fxRatesServiceClient;

    @MockBean
    private PolicyServiceClient policyServiceClient;

    @MockBean
    private FundServiceClient fundServiceClient;

    @MockBean
    private BusinessTransactionClient businessTransactionClient;

    @MockBean
    private ThirdPartyServiceClient thirdPartyServiceClient;

    @MockBean
    private CaseClient caseClient;

    @Test
    void exposesLegacyV1StyleEndpointsThroughDomainServicesAndSpi() throws Exception {
        when(fxRatesServiceClient.getValidFxRates(any())).thenReturn(List.of(fxRate("EUR", "USD", "1.087")));
        WebForm webForm = onboardingWebForm();
        ScreenDescription checklistRequest = ScreenDescription.builder().screenId(OnboardingTransactionIds.CHECKLIST_SCREEN_ID).build();
        ScreenDescription taskScreenRequest = ScreenDescription.builder().screenId("UNQUOTED_NEW_BUSINESS").build();

        mockMvc.perform(post("/api/screens/description")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsBytes(new ScreenDescriptionRequest(null, "ONBOARDING",
                                "BT001", webForm, checklistRequest, null))))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.screenId", is(OnboardingTransactionIds.CHECKLIST_SCREEN_ID)))
                .andExpect(jsonPath("$.tabs[0].groups", not(empty())));

        mockMvc.perform(post("/api/screens/task")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsBytes(new ScreenDescriptionRequest(null, "ONBOARDING",
                                "BT001", webForm, taskScreenRequest, checklistRequest))))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.screenId", is("UNQUOTED_NEW_BUSINESS")));

        mockMvc.perform(post("/api/cases/documents")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsBytes(new CaseDocumentRequest(null, "ONBOARDING",
                                "BT001", webForm, checklistRequest))))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", not(empty())));

        mockMvc.perform(post("/api/cases/controls")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsBytes(new CaseControlRequest("ONBOARDING", "BT001",
                                webForm, checklistRequest))))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", not(empty())));

        mockMvc.perform(post("/api/cases/subTasks")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsBytes(new CaseSubTaskRequest(null, "ONBOARDING",
                                "BT001", webForm, checklistRequest))))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", not(empty())));

        mockMvc.perform(post("/api/webforms/signatories")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsBytes(new WebformSignatoryRequest(null, "ONBOARDING", webForm))))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.responseMessages.STATUS", is("OK")));
    }

    @Test
    void exposesOpenApiDocumentation() throws Exception {
        mockMvc.perform(org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get("/v3/api-docs"))
                .andExpect(status().isOk());
    }

    private WebForm onboardingWebForm() {
        WebForm webForm = new WebForm();
        webForm.setWebFormId(OnboardingTransactionIds.WEB_FORM_ID);
        webForm.setWebFormWorkFlow(OnboardingTransactionIds.WORKFLOW);
        return webForm;
    }

    private FxRate fxRate(String from, String to, String rate) {
        FxRate fxRate = new FxRate();
        fxRate.setFromCcy(from);
        fxRate.setToCcy(to);
        fxRate.setBareRate(new BigDecimal(rate));
        fxRate.setSource("test");
        fxRate.setFxRateDate(LocalDate.now());
        fxRate.setFxRateTime(LocalTime.now());
        return fxRate;
    }
}
