package com.lombardinternational.casedefinition.v2;

import com.lombardinternational.casedefinition.v2.domain.model.ScreenDescription;
import com.lombardinternational.casedefinition.v2.domain.model.SelectInputField;
import com.lombardinternational.casedefinition.v2.domain.model.WebForm;
import com.lombardinternational.casedefinition.v2.domain.model.WebFormField;
import com.lombardinternational.casedefinition.v2.domain.model.WebFormGroup;
import com.lombardinternational.casedefinition.v2.domain.model.NumberInputField;
import com.lombardinternational.casedefinition.v2.adapter.spi.service.rest.RestFxRateWebServiceImpl;
import com.lombardinternational.casedefinition.v2.domain.api.RulesEngineService;
import com.lombardinternational.casedefinition.v2.domain.spi.FxRateWebService;
import com.lombardinternational.casedefinition.v2.domain.transaction.onboarding.rules.OnboardingTransactionIds;
import com.lombardinternational.casemanagement.clients.casebusinesscase.client.CaseClient;
import com.lombardinternational.clients.classapp.client.BusinessTransactionClient;
import com.lombardinternational.clients.classapp.client.FundServiceClient;
import com.lombardinternational.clients.classapp.client.PolicyServiceClient;
import com.lombardinternational.clients.classapp.client.ThirdPartyServiceClient;
import com.lombardinternational.clients.fxrates.client.FxRatesServiceClient;
import com.lombardinternational.clients.fxrates.model.FxRate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.boot.test.context.SpringBootTest;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Map;
import java.util.List;

import static com.lombardinternational.casedefinition.v2.domain.transaction.onboarding.rules.OnboardingChecklistIds.CASE_RISK_GROUP;
import static com.lombardinternational.casedefinition.v2.domain.transaction.onboarding.rules.OnboardingChecklistIds.DUE_DILIGENCE_GROUP;
import static com.lombardinternational.casedefinition.v2.domain.transaction.onboarding.rules.OnboardingChecklistIds.GENERAL_DETAILS_GROUP;
import static com.lombardinternational.casedefinition.v2.domain.transaction.onboarding.rules.OnboardingChecklistIds.INITIAL_PREM;
import static com.lombardinternational.casedefinition.v2.domain.transaction.onboarding.rules.OnboardingChecklistIds.INTERMEDIATION_GROUP;
import static com.lombardinternational.casedefinition.v2.domain.transaction.onboarding.rules.OnboardingChecklistIds.IS_ROP_CASE;
import static com.lombardinternational.casedefinition.v2.domain.transaction.onboarding.rules.OnboardingChecklistIds.LIFE_COVER_GROUP;
import static com.lombardinternational.casedefinition.v2.domain.transaction.onboarding.rules.OnboardingChecklistIds.PRICING_APPROVAL_GROUP;
import static com.lombardinternational.casedefinition.v2.domain.transaction.onboarding.rules.OnboardingChecklistIds.SIGNATURE_GROUP;
import static com.lombardinternational.casedefinition.v2.domain.transaction.onboarding.rules.OnboardingChecklistIds.SIGNOFFS_GROUP;
import static com.lombardinternational.casedefinition.v2.domain.transaction.onboarding.rules.OnboardingChecklistIds.THIRD_PARTY_GROUP;
import static com.lombardinternational.casedefinition.v2.domain.transaction.onboarding.rules.OnboardingChecklistIds.TRANSACTIONS_DETAILS_GROUP;
import static com.lombardinternational.casedefinition.v2.domain.transaction.onboarding.rules.OnboardingChecklistIds.EXPECTED_PREM_EUR;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.NONE)
class OnboardingRulesEngineServiceTest {
    @Autowired
    private RulesEngineService service;

    @Autowired
    private FxRateWebService fxRateWebService;

    @Autowired
    private RestFxRateWebServiceImpl restFxRateWebService;

    @MockBean
    private FxRatesServiceClient fxRatesServiceClient;

    @MockBean
    private PolicyServiceClient policyServiceClient;

    @MockBean
    private FundServiceClient fundServiceClient;

    @MockBean
    private BusinessTransactionClient businessTransactionClient;

    @MockBean
    private ThirdPartyServiceClient thirdPartyServiceClient;

    @MockBean
    private CaseClient caseClient;

    @Test
    void buildsOnboardingChecklistFromJavaRules() {
        WebForm webForm = onboardingWebForm();
        ScreenDescription input = ScreenDescription.builder().screenId(OnboardingTransactionIds.CHECKLIST_SCREEN_ID).build();

        ScreenDescription checklist = service.buildCheckList(webForm, input, "P001", "BT001");

        assertThat(checklist.getScreenId()).isEqualTo(OnboardingTransactionIds.CHECKLIST_SCREEN_ID);
        assertThat(checklist.getTabs()).extracting("tabId").contains("CHECKLIST");
        assertThat(checklist.findField("LIFE_COVER_TYPE")).isPresent();
        assertThat(checklist.findField("SAR")).isPresent();
        assertThat(checklist.findField("UNDERWRITINGS")).isPresent();
        assertThat(((SelectInputField) checklist.findField("LIFE_COVER_TYPE").orElseThrow()).getOptions()).isNotEmpty();
    }

    @Test
    void buildsAllChecklistGroupsAndFieldsFromExplicitJavaRules() {
        WebForm webForm = onboardingWebForm();
        ScreenDescription input = ScreenDescription.builder().screenId(OnboardingTransactionIds.CHECKLIST_SCREEN_ID).build();

        ScreenDescription checklist = service.buildCheckList(webForm, input, "P001", "BT001");

        assertThat(checklist.getTabs()).singleElement().satisfies(tab ->
                assertThat(tab.getGroups()).extracting("groupId").containsExactly(
                        GENERAL_DETAILS_GROUP,
                        LIFE_COVER_GROUP,
                        INTERMEDIATION_GROUP,
                        SIGNATURE_GROUP,
                        PRICING_APPROVAL_GROUP,
                        SIGNOFFS_GROUP,
                        DUE_DILIGENCE_GROUP,
                        TRANSACTIONS_DETAILS_GROUP,
                        THIRD_PARTY_GROUP,
                        CASE_RISK_GROUP
                ));
        assertThat(checklist.fields()).hasSize(168);
    }

    @Test
    void buildsRopCaseFromExplicitJavaRules() {
        WebForm webForm = onboardingWebForm();
        ScreenDescription input = ScreenDescription.builder().screenId(OnboardingTransactionIds.CHECKLIST_SCREEN_ID).build();

        ScreenDescription checklist = service.buildCheckList(webForm, input, "P001", "BT001");

        var ropCase = (SelectInputField) checklist.findField(IS_ROP_CASE).orElseThrow();
        assertThat(ropCase.getLabel()).isEqualTo("ROP Case ?");
        assertThat(ropCase.getMandatory()).isTrue();
        assertThat(ropCase.getOptions()).extracting("key").containsExactly("YES", "NO");

        var initialPremium = checklist.findField(INITIAL_PREM).orElseThrow();
        assertThat(initialPremium).isInstanceOf(NumberInputField.class);
        assertThat(initialPremium.getDisplayIf()).isEqualTo("#IS_ROP_CASE# == \"YES\"");
    }

    @Test
    void buildsAllTaskScreensFromExplicitJavaDefinitions() {
        WebForm webForm = onboardingWebForm();
        Map<String, int[]> expectedStats = Map.of(
                "BAC_NEW_BUSINESS", new int[]{1, 1, 1},
                "COMPLEX_UNQ_NEW_BUSINESS", new int[]{2, 4, 30},
                "COMPLIANCE_NEW_BUSINESS", new int[]{1, 1, 4},
                "DOT_NEW_BUSINESS", new int[]{1, 2, 15},
                "EBAC_NEW_BUSINESS", new int[]{1, 1, 1},
                "IC_NEW_BUSINESS", new int[]{1, 11, 83},
                "INAD_ASSET_NEW_BUSINESS", new int[]{1, 1, 1},
                "STRATEGY_MONITORING_NEW_BUSINESS", new int[]{1, 1, 13},
                "UNQUOTED_NEW_BUSINESS", new int[]{2, 8, 88}
        );

        expectedStats.forEach((screenId, stats) -> {
            var taskScreen = service.buildTaskScreen(webForm, null, ScreenDescription.builder().screenId(screenId).build());
            var groupCount = taskScreen.getTabs().stream().flatMap(tab -> tab.getGroups().stream()).count();

            assertThat(taskScreen.getTabs()).hasSize(stats[0]);
            assertThat(groupCount).isEqualTo(stats[1]);
            assertThat(taskScreen.fields()).hasSize(stats[2]);
        });
    }

    @Test
    void buildsTaskDefinitionsWithSimpleConditionsAndMergesReasonsByTaskName() {
        WebForm webForm = onboardingWebForm();
        ScreenDescription checklist = service.buildCheckList(webForm, ScreenDescription.builder().screenId(OnboardingTransactionIds.CHECKLIST_SCREEN_ID).build(), "P001", "BT001");
        checklist.findField("INSIDER").orElseThrow().setSelectedValue("YES");

        var tasks = service.buildTaskList(webForm, checklist, "P001");

        assertThat(tasks).extracting("mainTaskName").contains("Compliance check", "Strategy Monitoring");
        assertThat(tasks.stream().filter(task -> "Compliance check".equals(task.getMainTaskName())).count()).isEqualTo(1);
    }

    @Test
    void buildsDocumentsAndControls() {
        WebForm webForm = onboardingWebForm();
        ScreenDescription checklist = service.buildCheckList(webForm, ScreenDescription.builder().screenId(OnboardingTransactionIds.CHECKLIST_SCREEN_ID).build(), "P001", "BT001");

        assertThat(service.buildDocumentsDefinition(webForm, checklist, "P001", "BT001")).isNotEmpty();
        assertThat(service.buildControlDefinition(webForm, checklist)).isNotEmpty();
    }

    @Test
    void enrichesExpectedPremiumInEurFromConfiguredFxRates() {
        when(fxRatesServiceClient.getValidFxRates(any())).thenReturn(List.of(fxRate("USD", "EUR", "0.92")));
        WebForm webForm = onboardingWebForm(field("POLICY_CUR", "USD"), field("EXPECTED_PREM", "1000"));

        ScreenDescription checklist = service.buildCheckList(webForm, ScreenDescription.builder().screenId(OnboardingTransactionIds.CHECKLIST_SCREEN_ID).build(), "P001", "BT001");

        assertThat(checklist.findField(EXPECTED_PREM_EUR)).hasValueSatisfying(field -> assertThat(field.getSelectedValue()).isEqualTo("920.00"));
    }

    @Test
    void cachesFxRatesAtRestSpiLevelUntilExplicitRefresh() {
        restFxRateWebService.refreshCacheFxRate();
        when(fxRatesServiceClient.getValidFxRates(any()))
                .thenReturn(List.of(fxRate("USD", "EUR", "0.92")))
                .thenReturn(List.of(fxRate("USD", "EUR", "0.50")));

        assertThat(fxRateWebService.getFxRate("USD", "EUR"))
                .singleElement()
                .satisfies(rate -> assertThat(rate.getRate()).isEqualByComparingTo("0.92"));

        assertThat(fxRateWebService.getFxRate("USD", "EUR"))
                .singleElement()
                .satisfies(rate -> assertThat(rate.getRate()).isEqualByComparingTo("0.92"));
        verify(fxRatesServiceClient, times(1)).getValidFxRates(any());

        restFxRateWebService.refreshCacheFxRate();

        assertThat(fxRateWebService.getFxRate("USD", "EUR"))
                .singleElement()
                .satisfies(rate -> assertThat(rate.getRate()).isEqualByComparingTo("0.50"));
        verify(fxRatesServiceClient, times(2)).getValidFxRates(any());
    }

    @Test
    void buildsOnboardingSignatoryDocumentsFromJavaRules() {
        WebForm webForm = onboardingWebForm(
                field("TARGET_MARKET", "BE"),
                field("HOLDER_SPECIFIC_TYPE", "PP"),
                field("DOCUMENT_LANGUAGE_PREFERENCE", "FR"),
                field("CONNECT_ACCESS_REQUESTED", "true"));
        WebFormGroup holder = group("POLICY_HOLDER_PHYSICAL",
                field("FIRSTNAME", "Jean"),
                field("LASTNAME", "Dupont"),
                field("EMAIL", "jean.dupont@example.test"),
                field("MOBILE", "+352000000"),
                field("CLIENT_CONTACT_ID", "TP001"));
        webForm.setWebFormGroups(List.of(holder, webForm.getWebFormGroups().getFirst()));

        var result = service.buildSignatories(webForm, "P001");

        assertThat(result.getResponseMessages()).containsEntry("STATUS", "OK");
        assertThat(result.getDocumentRequiredSignatories()).extracting("documentType").contains("CONNECT1017");
        assertThat(result.getDocumentRequiredSignatories().stream()
                .filter(document -> "CONNECT1017".equals(document.getDocumentType()))
                .flatMap(document -> document.getRequiredSignatories().stream()))
                .anySatisfy(signatory -> {
                    assertThat(signatory.getType()).isEqualTo("HOLDER");
                    assertThat(signatory.getAllowedActions()).contains("DOWNLOAD");
                });
    }

    private WebForm onboardingWebForm() {
        return onboardingWebForm(new WebFormField[0]);
    }

    private WebForm onboardingWebForm(WebFormField... fields) {
        WebForm webForm = new WebForm();
        webForm.setWebFormId(OnboardingTransactionIds.WEB_FORM_ID);
        webForm.setWebFormWorkFlow(OnboardingTransactionIds.WORKFLOW);
        webForm.setWebFormGroups(List.of(group("ROOT", fields)));
        return webForm;
    }

    private WebFormGroup group(String groupId, WebFormField... fields) {
        WebFormGroup group = new WebFormGroup();
        group.setGroupId(groupId);
        group.setFields(List.of(fields));
        return group;
    }

    private WebFormField field(String fieldId, String value) {
        WebFormField field = new WebFormField();
        field.setFieldId(fieldId);
        field.setSelectedValue(value);
        return field;
    }

    private FxRate fxRate(String from, String to, String rate) {
        FxRate fxRate = new FxRate();
        fxRate.setFromCcy(from);
        fxRate.setToCcy(to);
        fxRate.setBareRate(new BigDecimal(rate));
        fxRate.setSource("test");
        fxRate.setFxRateDate(LocalDate.now());
        fxRate.setFxRateTime(LocalTime.now());
        return fxRate;
    }
}
