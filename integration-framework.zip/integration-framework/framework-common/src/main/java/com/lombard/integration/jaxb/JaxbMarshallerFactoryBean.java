package com.lombard.integration.jaxb;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;

import org.springframework.beans.factory.FactoryBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import org.springframework.util.Assert;
import org.springframework.util.ClassUtils;

import com.lombard.integration.util.ModelUtils;

/**
 * Factory bean that checked what is exactly available in the classpath before creating the marshaller.
 * <p>
 * To avoid to have CSM and CSM 2.2 in the classpath.
 * 
 * @author wvandenberghe
 * 
 */
public final class JaxbMarshallerFactoryBean implements FactoryBean < Jaxb2Marshaller >, InitializingBean {

    private Jaxb2Marshaller marshaller;

    private Marshaller.Listener marshallerListener;

    private Unmarshaller.Listener unmarshallerListener;

    /**
     * Set a listener to modify marshalling behaviour.
     * 
     * @param marshallerListener
     */
    public void setMarshallerListener(Marshaller.Listener marshallerListener) {
        this.marshallerListener = marshallerListener;
    }

    /**
     * Set a listener to modifiy unmashalling behaviour.
     * 
     * @param unmarshallerListener
     */
    public void setUnmarshallerListener(Unmarshaller.Listener unmarshallerListener) {
        this.unmarshallerListener = unmarshallerListener;
    }

    /**
     * {@inheritDoc}
     */
    public void afterPropertiesSet() throws Exception {
        List < String > contextPaths = new ArrayList < String >(4);
        if (ModelUtils.isCsmPresent()) {
            contextPaths.add("com.lombard.csm");
        }
        if (ModelUtils.isCsm22Present()) {
            contextPaths.add("com.lombard.integration.fwk.schema.csm.v2_2");
        }
        if (ModelUtils.isCdmPresent()) {
            contextPaths.add("com.lombard.cdm");
        }
        if (ModelUtils.isCdm22Present()) {
            contextPaths.add("com.lombard.integration.fwk.schema.cdm.v2_2");
        }
        if (ModelUtils.isDocumentsPresent()) {
            contextPaths.add("com.lombard.documents");
        }

        Assert.notEmpty(contextPaths, "Canonical model is missing in the classpath");

        marshaller = new Jaxb2Marshaller();
        marshaller.setContextPaths(contextPaths.toArray(new String[contextPaths.size()]));

        if (marshallerListener != null) {
            marshaller.setMarshallerListener(marshallerListener);
        }

        if (unmarshallerListener != null) {
            marshaller.setUnmarshallerListener(unmarshallerListener);
        }

        marshaller.setBeanClassLoader(ClassUtils.getDefaultClassLoader());
        marshaller.afterPropertiesSet();
    }

    /**
     * {@inheritDoc}
     */
    public Jaxb2Marshaller getObject() throws Exception {
        return marshaller;
    }

    /**
     * {@inheritDoc}
     */
    public Class < ? > getObjectType() {
        return Jaxb2Marshaller.class;
    }

    /**
     * {@inheritDoc}
     */
    public boolean isSingleton() {
        return true;
    }

}
