package com.lombard.integration.ntf.properties.transformer;

/**
 * 
 * @author JZAPADKA
 * 
 * @param <T>
 */
public interface BusinessKeyValueTransformer< T > {

    /**
     * Get a specific toString according to the class type
     * 
     * @return
     */
    < O extends T > String transform(O obj);

    /**
     * Return the class type
     * 
     * @return
     */
    Class < T > getClassType();

}
