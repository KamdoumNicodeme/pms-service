package com.lombard.integration.ntf.validation;

import javax.jms.Message;

import com.lombard.integration.ntf.NotificationException;

/**
 * Validator dedicated to notification sending/receiving.
 * <p>
 * Internal use only.
 * 
 * @author wvandenberghe
 * 
 */
public interface NotificationValidator {

    /**
     * 
     * @param message
     * @return
     * @throws NotificationException
     */
    boolean handleOnPublish(Message message) throws NotificationException;

    /**
     * 
     * @param message
     * @return
     * @throws NotificationException
     */
    boolean handleOnConsume(Message message) throws NotificationException;

}
