package com.lombard.integration.fwk.cxf.interceptors.properties;

import java.util.ArrayList;
import java.util.List;

import org.apache.cxf.binding.soap.SoapMessage;
import org.apache.cxf.binding.soap.interceptor.AbstractSoapInterceptor;
import org.apache.cxf.interceptor.Fault;
import org.apache.cxf.phase.Phase;
import org.apache.cxf.transport.jms.JMSConstants;
import org.apache.cxf.transport.jms.JMSMessageHeadersType;
import org.apache.cxf.transport.jms.JMSPropertyType;

import com.lombard.integration.fwk.properties.FWKPropertiesManagement;
import com.lombard.integration.fwk.properties.FWKProperty;

public class FWKPropertiesOutInterceptor extends AbstractSoapInterceptor {

	public FWKPropertiesOutInterceptor() {
		super(Phase.SEND);
	}

	public void handleMessage(final SoapMessage aMessage) 
	throws Fault {
		makeClientHeaders(aMessage);
		makeServerHeaders(aMessage);
	}	
	
	private void makeServerHeaders(SoapMessage aMessage) {
		final JMSMessageHeadersType messageProperties = prepareMessageHeaders(aMessage, JMSConstants.JMS_SERVER_RESPONSE_HEADERS);
		messageProperties.getProperty().addAll(getProperties());		
	}

	private void makeClientHeaders(SoapMessage aMessage) {
		final JMSMessageHeadersType messageProperties = prepareMessageHeaders(aMessage, JMSConstants.JMS_CLIENT_REQUEST_HEADERS);
		messageProperties.getProperty().addAll(getProperties());		
	}

	/**
	 * <p>Method prepares message headers for use. Preparation consists of 
	 * creating and setting (to soap message) new properties if they do alerady 
	 * not exists.</p>
	 * 
	 * @param aMessage
	 * @param aPropertyName
	 * @return message properties to use
	 */
	private JMSMessageHeadersType prepareMessageHeaders(final SoapMessage aMessage, final String aPropertyName) {
		JMSMessageHeadersType messageProperties = (JMSMessageHeadersType) aMessage.get(aPropertyName);
		if (messageProperties == null) {
			messageProperties = new JMSMessageHeadersType();
			aMessage.put(aPropertyName, messageProperties);
		}
		
		return messageProperties;
	}
	
	/**
	 * <p>Method builds list with properties that are going to be set to the
	 * outgoing message</p>
	 * 
	 * @return
	 */
	private List<JMSPropertyType> getProperties() {
		final List<JMSPropertyType> resultProps = new ArrayList<JMSPropertyType>();
		
		for (FWKProperty key : FWKProperty.values()) {
			final String value = FWKPropertiesManagement.getProperty(key);
			final JMSPropertyType prop = new JMSPropertyType();
			prop.setName(key.toString());
			prop.setValue(value);
			
			resultProps.add(prop);
			
		}
		
		return resultProps;
	}
	
}
