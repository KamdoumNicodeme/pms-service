package com.lombard.integration.fwk.properties;

import java.util.HashMap;
import java.util.Map;

@Deprecated
public final class FWKPropertiesManagement {

    public static final String USER_PROPERTY = "FWKUser";

    private static ThreadLocal < Map < FWKProperty, String >> localProperties =
            new ThreadLocal < Map < FWKProperty, String >>();

    private FWKPropertiesManagement() {

    }

    public static Map < FWKProperty, String > getProperties() {
        if (localProperties.get() == null) {
            localProperties.set(new HashMap < FWKProperty, String >());
        }
        return localProperties.get();
    }

    public static void setProperties(Map < FWKProperty, String > aProperties) {
        localProperties.set(aProperties);
    }

    public static String getProperty(FWKProperty aKey) {
        return getProperties().get(aKey);
    }

    public static void putProperty(FWKProperty aKey, String aValue) {
        getProperties().put(aKey, aValue);
    }
}
