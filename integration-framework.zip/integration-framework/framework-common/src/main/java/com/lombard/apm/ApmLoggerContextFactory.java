package com.lombard.apm;

import static com.lombard.apm.logger.ApmLoggerConstants.*;

import java.lang.reflect.Method;
import java.util.UUID;

import org.aopalliance.intercept.MethodInvocation;
import org.springframework.util.ReflectionUtils;

import com.lombard.apm.logger.ApmLoggerContext;

public class ApmLoggerContextFactory {

    private static ApmLoggerContextFactory INSTANCE;

    public static ApmLoggerContextFactory getInstance() {

        if (INSTANCE == null) {
            INSTANCE = new ApmLoggerContextFactory();

        }
        return INSTANCE;
    }

    public ApmLoggerContext createApmLoggerContext() {

        ApmLoggerContext loggerContext = new ApmLoggerContext();
        loggerContext.addParam(PARAM_CORRELATION_ID, UUID.randomUUID().toString());
        loggerContext.addParam(PARAM_APPLICATION_LAYER, "INTEGRATION");
        loggerContext.addParam(PARAM_INITIATOR_NODE, getCurrentNode());
        loggerContext.addParam(PARAM_APPLICATION_NODE, getCurrentNode());

        return loggerContext;
    }

    public ApmLoggerContext createApmLoggerContext(MethodInvocation methodInvocation) {

        ApmLoggerContext loggerContext = createApmLoggerContext();

        Object[] arguments = methodInvocation.getArguments();

        if (arguments != null && arguments.length == 1) {

            if (arguments[0] != null && "AbstractRequest".equals(arguments[0].getClass().getSuperclass().getSimpleName())) {
                // We don't know the CSM version and moreover it is better not to create a dependency to the framework catalog:
                // ==> use the reflection.
                Object csmRequest = arguments[0];
                loggerContext.addParam(PARAM_ACTIVITY_NAME, methodInvocation.getMethod().getDeclaringClass().getSimpleName());
                loggerContext.addParam(PARAM_TASK_NAME, methodInvocation.getMethod().getName());
                Object correlationHandler = getFieldValue(csmRequest, "getCorrelationHandler");
                if (correlationHandler != null) {
                    String id = (String) getFieldValue(correlationHandler, "getId");
                    if (id != null) {
                        loggerContext.addParam(PARAM_CORRELATION_ID, id);
                    }
                    Object initiator = getFieldValue(correlationHandler, "getInitiator");
                    if (initiator != null) {
                        Object initiatorIdType = getFieldValue(initiator, "getName");
                        if (initiatorIdType != null) {
                            String initiatorName = initiatorIdType.toString();
                            loggerContext.addParam(PARAM_INITIATOR_NAME, initiatorName);
                            loggerContext.addParam(PARAM_APPLICATION_NAME, initiatorName);
                        }
                        String initiatorNode = (String) getFieldValue(initiator, "getNode");
                        if (initiatorNode != null) {
                            loggerContext.addParam(PARAM_INITIATOR_NODE, initiatorNode);
                        }
                    }

                }
            }
        }

        return loggerContext;
    }

    private Object getFieldValue(Object sourceObject, String getterFieldName) {

        if (sourceObject == null || getterFieldName == null) {
            return null;
        }
        Method getterMethod = ReflectionUtils.findMethod(sourceObject.getClass(), getterFieldName);
        if (getterMethod == null) {
            return null;
        }
        return ReflectionUtils.invokeMethod(getterMethod, sourceObject);

    }

    private String getCurrentNode() {

        return System.getenv("COMPUTERNAME");
    }

}
