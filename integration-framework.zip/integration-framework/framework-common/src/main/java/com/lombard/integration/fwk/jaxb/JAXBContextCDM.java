package com.lombard.integration.fwk.jaxb;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;

public abstract class JAXBContextCDM extends JAXBContext {

    /**
     * 
     * @param usedSchema
     *            comma-separated list of cdm/csm version with underscore instead of . (e.g. v2_1, v2_2)
     * @return
     * @throws JAXBException
     */
    public static JAXBContext newInstance(String usedSchema) throws JAXBException {

        if (usedSchema == null) {
            throw new IllegalArgumentException(
                    "Configuration unavailable: please set usedSchema property in bean definition");
        }

        StringBuilder sb = new StringBuilder();
        int i = 0;
        for (String schema : usedSchema.split(",")) {
            if (i++ > 0) {
                sb.append(':');
            }
            
            sb.append("com.lombard.integration.fwk.schema.csm.").append(schema);
        }

        return JAXBContext.newInstance(sb.toString());
    }

}
