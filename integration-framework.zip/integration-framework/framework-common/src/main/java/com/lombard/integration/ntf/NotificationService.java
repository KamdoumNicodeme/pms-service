package com.lombard.integration.ntf;

import com.lombard.csm.Notification;
import com.lombard.integration.sub.GenericService;

/**
 * Service dedicated to notifications publishing and consuming.
 * 
 * @author wvandenberghe
 * @see {@link Notification}
 */
public interface NotificationService extends GenericService < Notification > {

    public void sendOrReceive(Notification toSendOrReceive);
}
