package com.lombard.integration.ntf.config;

import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.beans.factory.support.BeanDefinitionBuilder;
import org.springframework.beans.factory.support.ManagedList;
import org.springframework.beans.factory.xml.ParserContext;
import org.springframework.expression.spel.standard.SpelExpressionParser;
import org.w3c.dom.Element;

import com.lombard.integration.config.AbstractIntfwkDefinitionParser;
import com.lombard.integration.ntf.converter.DefaultNotificationMessageConverter;
import com.lombard.integration.ntf.properties.SimpleBusinessKeyEvaluator;
import com.lombard.integration.ntf.properties.transformer.CalendarBusinessKeyValueTransformer;
import com.lombard.integration.ntf.properties.transformer.DateBusinessKeyValueTransformer;
import com.lombard.integration.ntf.properties.transformer.DefaultBusinessKeyValueTransformer;
import com.lombard.integration.ntf.validation.XmlNotificationBodyValidator;

/**
 * Definition parser dedicated to message based communication.
 * 
 * @author wvandenberghe
 * 
 */
public abstract class AbstractMessagingDefinitionParser extends AbstractIntfwkDefinitionParser {

    /**
     * Create a notification parser and configure it.
     * 
     * @param element
     * @return
     */
    protected BeanDefinition parseNotificationValidator(Element element) {
        BeanDefinitionBuilder builder =
                BeanDefinitionBuilder.genericBeanDefinition(XmlNotificationBodyValidator.class);

        boolean validate = Boolean.parseBoolean(element.getAttribute(VALIDATE_ATT));
        builder.addPropertyValue("publicationValidate", validate);
        builder.addPropertyValue("consumptionValidate", validate);

        String schemas = element.getAttribute(SCHEMAS_ATT);
        builder.addPropertyValue("schemas", schemas);

        return builder.getBeanDefinition();
    }

    /**
     * Create message converter.
     * 
     * @param element
     * @param parserContext
     * @return
     */
    protected BeanDefinition parseMessageConverter(Element element, ParserContext parserContext) {
        BeanDefinitionBuilder builder =
                BeanDefinitionBuilder.genericBeanDefinition(DefaultNotificationMessageConverter.class);

        // jaxb2Marshaller
        String marshaller = element.getAttribute(MARSHALLER_ATT);
        if (marshaller.length() > 0) {
            builder.addPropertyReference("marshaller", marshaller);
        } else {
            String jaxbMarshaller = getJaxbMarshaller(parserContext);
            builder.addPropertyReference("marshaller", jaxbMarshaller);
        }

        String unmarshaller = element.getAttribute(UNMARSHALLER_ATT);
        if (unmarshaller.length() > 0) {
            builder.addPropertyReference("unmarshaller", unmarshaller);
        } else {
            String jaxbUnmarshaller = getJaxbMarshaller(parserContext);
            builder.addPropertyReference("unmarshaller", jaxbUnmarshaller);
        }

        BeanDefinition validator = parseNotificationValidator(element);
        builder.addPropertyValue("validator", validator);

        return builder.getBeanDefinition();
    }

    /**
     * Get new business key evaluator
     * 
     * @return
     */
    protected BeanDefinition getBusinessKeyEvaluator() {
        BeanDefinitionBuilder builder =
                BeanDefinitionBuilder.genericBeanDefinition(SimpleBusinessKeyEvaluator.class);

        BeanDefinition expressionParser = getExpressionParser();
        builder.addPropertyValue("expressionParser", expressionParser);

        ManagedList < BeanDefinition > transformers = new ManagedList < BeanDefinition >(3);
        transformers.add(getDateBusinessKeyEvaluatorTransformer());
        transformers.add(getCalendarBusinessKeyEvaluatorTransformer());
        transformers.add(getDefaultBusinessKeyEvaluatorTransformer());
        builder.addPropertyValue("transformers", transformers);

        return builder.getBeanDefinition();
    }

    /**
     * Get expression parser
     * 
     * @return
     */
    private BeanDefinition getExpressionParser() {
        BeanDefinitionBuilder builder = BeanDefinitionBuilder.genericBeanDefinition(SpelExpressionParser.class);

        return builder.getBeanDefinition();
    }

    private BeanDefinition getDateBusinessKeyEvaluatorTransformer() {
        BeanDefinitionBuilder builder =
                BeanDefinitionBuilder.genericBeanDefinition(DateBusinessKeyValueTransformer.class);

        return builder.getBeanDefinition();
    }

    private BeanDefinition getCalendarBusinessKeyEvaluatorTransformer() {
        BeanDefinitionBuilder builder =
                BeanDefinitionBuilder.genericBeanDefinition(CalendarBusinessKeyValueTransformer.class);

        BeanDefinition delegate = getDateBusinessKeyEvaluatorTransformer();
        builder.addPropertyValue("delegate", delegate);

        return builder.getBeanDefinition();
    }

    private BeanDefinition getDefaultBusinessKeyEvaluatorTransformer() {
        BeanDefinitionBuilder builder =
                BeanDefinitionBuilder.genericBeanDefinition(DefaultBusinessKeyValueTransformer.class);

        return builder.getBeanDefinition();
    }
}
