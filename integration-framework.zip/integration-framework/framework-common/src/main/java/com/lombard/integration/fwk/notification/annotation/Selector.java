package com.lombard.integration.fwk.notification.annotation;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Inherited;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import com.lombard.csm.BusinessContext;

/**
 * Mark a method as eligible to consume a particular notification type described by businessContext.
 * 
 * @author wvandenberghe
 * @see Consumer
 */
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.METHOD)
@Inherited
@Documented
public @interface Selector {

    /**
     * Consume notifications which contains a business context of this type.
     * 
     * @return the business context to select
     */
    Class < ? extends BusinessContext > businessContext() default BusinessContext.class;

    /**
     * Subscribe to gateway channel
     * 
     * @return
     */
    String channel() default "";
}
