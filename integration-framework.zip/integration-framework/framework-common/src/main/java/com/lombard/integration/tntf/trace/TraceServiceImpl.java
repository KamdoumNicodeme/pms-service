package com.lombard.integration.tntf.trace;

import javax.jms.ConnectionFactory;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.core.task.TaskExecutor;
import org.springframework.jms.support.converter.MessageConverter;
import org.springframework.util.Assert;

import com.lombard.cdm.ActivityHandler;

/**
 * Implementation of {@link TraceService} in an asynchronous manner.
 * 
 * @author wvandenberghe
 * @see TraceService
 */
public class TraceServiceImpl implements TraceService, InitializingBean {

    private static final Log log = LogFactory.getLog(TraceServiceImpl.class);

    private static final String DEFAULT_QUEUE_NAME = "TNTF.TRACE";

    private TaskExecutor taskExecutor;

    private ConnectionFactory connectionFactory;
    private ConnectionFactory syncConnectionFactory;

    private MessageConverter messageConverter;

    private String queueName;

    private TraceService traceService;
    private TraceService synchronousTraceService;

    /**
     * Set task excutor and initialize it.
     * 
     * @param taskExecutor
     */
    public void setTaskExecutor(TaskExecutor taskExecutor) {

        this.taskExecutor = taskExecutor;

        // avoid not initialized exception
        if (this.taskExecutor instanceof InitializingBean) {
            try {
                ((InitializingBean) this.taskExecutor).afterPropertiesSet();
            } catch (Exception e) {
                throw new IllegalStateException("Error while initializing TaskExecutor", e);
            }
        }
    }

    /**
     * Set connection factory.
     * 
     * @param connectionFactory
     */
    public void setConnectionFactory(ConnectionFactory connectionFactory) {

        this.connectionFactory = connectionFactory;
    }

    public void setSyncConnectionFactory(ConnectionFactory syncConnectionFactory) {

        this.syncConnectionFactory = syncConnectionFactory;
    }

    /**
     * Set message converter.
     * 
     * @param messageConverter
     */
    public void setMessageConverter(MessageConverter messageConverter) {

        this.messageConverter = messageConverter;
    }

    /**
     * Set queue name.
     * 
     * @param queueName
     */
    public void setQueueName(String queueName) {

        this.queueName = queueName;
    }

    /**
     * Get queue name.
     * 
     * @return if not set, return TNTF.TRACE
     */
    protected String getQueueName() {

        return (queueName == null) ? DEFAULT_QUEUE_NAME : queueName;
    }

    /**
     * {@inheritDoc}
     */
    public void afterPropertiesSet() throws Exception {

        Assert.notNull(connectionFactory, "'connectionFactory' is mandatory");
        traceService = buildTraceServiceForConnFact(connectionFactory);

        if (syncConnectionFactory != null) {
            synchronousTraceService = buildTraceServiceForConnFact(syncConnectionFactory);
        } else {
            synchronousTraceService = traceService;
        }

    }

    private TraceService buildTraceServiceForConnFact(final ConnectionFactory connFact) {

        final TraceServiceProxyFactoryBean factoryBean = new TraceServiceProxyFactoryBean();
        factoryBean.setConnectionFactory(connFact);
        factoryBean.setMessageConverter(messageConverter);
        factoryBean.setQueueName(getQueueName());

        factoryBean.afterPropertiesSet();
        final TraceService traceServiceResult = (TraceService) factoryBean.getObject();

        return traceServiceResult;
    }

    /**
     * Send the activity handler to the tracing tool.
     * 
     */
    public void trace(final ActivityHandler toSendOrReceive) {

        taskExecutor.execute(new Runnable() {

            /**
             * Send tracing in a asynchronous manner.
             */
            public void run() {

                if (traceService != null) {
                    try {
                        traceService.trace(toSendOrReceive);
                    } catch (Exception e) {
                        log.error("Error occured while sending trace.", e);
                    }
                } else {
                    log.warn("Cannot send trace, tracer not initialized.");
                }
            }
        });
    }

    public void traceSynchronous(ActivityHandler toSendOrReceive) {

        if (synchronousTraceService != null) {
            try {
                synchronousTraceService.trace(toSendOrReceive);
            } catch (Exception e) {
                log.error("Error occured while sending trace in synchronous mode.", e);
            }
        } else {
            log.warn("Cannot send trace in synchronous mode, the tracer not initialized.");
        }

    }

}
