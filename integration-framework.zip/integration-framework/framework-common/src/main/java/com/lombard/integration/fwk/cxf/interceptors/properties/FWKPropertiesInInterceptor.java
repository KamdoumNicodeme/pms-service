package com.lombard.integration.fwk.cxf.interceptors.properties;

import java.util.List;
import java.util.Map;

import org.apache.cxf.binding.soap.SoapMessage;
import org.apache.cxf.binding.soap.interceptor.AbstractSoapInterceptor;
import org.apache.cxf.helpers.CastUtils;
import org.apache.cxf.interceptor.AttachmentInInterceptor;
import org.apache.cxf.interceptor.Fault;
import org.apache.cxf.message.Message;
import org.apache.cxf.phase.Phase;

import com.lombard.integration.fwk.properties.FWKPropertiesManagement;
import com.lombard.integration.fwk.properties.FWKProperty;

public class FWKPropertiesInInterceptor extends AbstractSoapInterceptor {

    public FWKPropertiesInInterceptor() {
        super(Phase.RECEIVE);
        addBefore(AttachmentInInterceptor.class.getName());
    }

    public void handleMessage(final SoapMessage aMessage) throws Fault {

        @SuppressWarnings("rawtypes")
        Map < String, List < String >> headers = CastUtils.cast((Map) aMessage.get(Message.PROTOCOL_HEADERS));
        if (headers != null) {
            addProperties(headers);
        }
    }

    private void addProperties(final Map < String, List < String >> headers) {
        for (FWKProperty p : FWKProperty.values()) {
            final List < String > propertyList = headers.get(p.toString());
            if (propertyList != null && propertyList.size() > 0) {
                FWKPropertiesManagement.putProperty(p, propertyList.get(0));
            }
        }
    }

}
