package com.lombard.integration.jaxb;

import java.lang.reflect.Field;
import java.util.List;

import javax.xml.bind.Marshaller.Listener;
import javax.xml.bind.annotation.XmlIDREF;
import javax.xml.bind.annotation.XmlList;

import org.springframework.util.ReflectionUtils;

import com.lombard.cdm.AbstractEntity;
import com.lombard.integration.util.ModelUtils;

/**
 * Check The collection with xmlIDRef and XMLList that are null or empty and set it up to null;
 * 
 * We want to avoid <bankAccounts></bankAccounts> empty when we marshall the class.
 * 
 * @author CLONFILS
 * 
 */
public class CollectionJaxBListener extends Listener {

    /**
     * {@inheritDoc}
     */
    @SuppressWarnings("rawtypes")
    @Override
    public void beforeMarshal(final Object source) {

        if (ModelUtils.isCdmPresent() && source instanceof AbstractEntity) {
            try {
                ReflectionUtils.doWithFields(source.getClass(), new ReflectionUtils.FieldCallback() {

                    public void doWith(Field field) throws IllegalArgumentException, IllegalAccessException {

                        field.setAccessible(true);
                        Object value = field.get(source);
                        if (value instanceof List && ((List) value).isEmpty()) {
                            field.set(source, null);
                        }
                    }
                }, new ReflectionUtils.FieldFilter() {

                    public boolean matches(Field field) {

                        return field.isAnnotationPresent(XmlIDREF.class) && field.isAnnotationPresent(XmlList.class);
                    }
                });
            } catch (IllegalArgumentException e) {
                throw new IllegalStateException(e);
            }
        }
        super.beforeMarshal(source);
    }

}
