package com.lombard.integration.ntf.properties;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.expression.EvaluationContext;
import org.springframework.expression.Expression;
import org.springframework.expression.ExpressionParser;
import org.springframework.expression.ParseException;
import org.springframework.util.Assert;
import org.springframework.util.CollectionUtils;

import com.lombard.integration.fwk.notification.annotation.BusinessKey;
import com.lombard.integration.ntf.properties.transformer.BusinessKeyValueTransformer;
import com.lombard.integration.ntf.properties.transformer.DefaultBusinessKeyValueTransformer;

/**
 * Simple business key evaluator.
 * 
 * @author wvandenberghe
 * @see BusinessKey
 */
public class SimpleBusinessKeyEvaluator extends AbstractBusinessKeyEvaluator implements InitializingBean {

    private static final Log logger = LogFactory.getLog(SimpleBusinessKeyEvaluator.class);

    /**
     * Cache used to retrieve expressions.
     */
    private ConcurrentMap < String, Expression > expressionCache = new ConcurrentHashMap < String, Expression >();

    private ExpressionParser expressionParser;

    /**
     * List of class type used to get the correct toString() method
     */
    private List < BusinessKeyValueTransformer < ? >> transformers;

    /**
     * Set expression parser
     * 
     * @param expressionParser
     */
    public void setExpressionParser(ExpressionParser expressionParser) {
        this.expressionParser = expressionParser;
    }

    /**
     * Get transformers for evaluation results that need to be transformed to String, such as Date, Calendar...
     * 
     * @return the transformers
     */
    public List < BusinessKeyValueTransformer < ? >> getTransformers() {
        return transformers;
    }

    /**
     * Set transformers for evaluation results that need to be transformed to String, such as Date, Calendar...
     * 
     * @param classTypeList
     *            the transformers to set
     */
    public void setTransformers(List < BusinessKeyValueTransformer < ? >> classTypeList) {
        List < BusinessKeyValueTransformer < ? >> list =
                new ArrayList < BusinessKeyValueTransformer < ? > >(classTypeList);

        Collections.sort(list, new Comparator < BusinessKeyValueTransformer < ? > >() {
            public int compare(BusinessKeyValueTransformer < ? > o1, BusinessKeyValueTransformer < ? > o2) {
                if (o1.getClassType() == o2.getClassType()) {
                    return 0;
                }

                return o1.getClassType().isAssignableFrom(o2.getClassType()) ? 1 : -1;
            }
        });

        this.transformers = list;
    }

    /**
     * {@inheritDoc}
     */
    public void afterPropertiesSet() throws Exception {
        Assert.notNull(expressionParser, "Property 'expressionParser' is mandatory");
        if (CollectionUtils.isEmpty(getTransformers())) {
            List < BusinessKeyValueTransformer < ? >> defaultList =
                    new ArrayList < BusinessKeyValueTransformer < ? > >();
            defaultList.add(new DefaultBusinessKeyValueTransformer());
            setTransformers(defaultList);
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    protected String evaluate(EvaluationContext context, String expression) {
        // no need of synchronized as only double putIfAbsent can occur
        Expression exp = expressionCache.get(expression);
        if (exp == null) {
            try {
                exp = expressionParser.parseExpression(expression);
            } catch (ParseException e) {
                if (logger.isErrorEnabled()) {
                    logger.error("Error occured while parsing expression [" + expression + "]", e);
                }

                return null;
            }
        }
        expressionCache.putIfAbsent(expression, exp);

        String result = null;
        try {
            final Object value = exp.getValue(context);
            if (value != null) {
                // get the correct toString method
                for (BusinessKeyValueTransformer < ? > transformer : transformers) {
                    if (transformer.getClassType().isAssignableFrom(value.getClass())) {
                        result = applyTransformer(transformer, value);
                        break;
                    }
                }
            }
        } catch (Exception e) {
            // catch all as Spring ParseException does not encapsulate non Spring exception
            if (logger.isTraceEnabled()) {
                logger.trace("Error occured while evaluating expression [" + expression + "]", e);
            }
        }

        if (logger.isTraceEnabled()) {
            logger.trace("Expression '" + expression + "' evaluated to '" + result + "'");
        }

        return result;
    }

    private < T > String applyTransformer(BusinessKeyValueTransformer < T > transformer, Object value) {
        return transformer.transform(transformer.getClassType().cast(value));
    }
}
