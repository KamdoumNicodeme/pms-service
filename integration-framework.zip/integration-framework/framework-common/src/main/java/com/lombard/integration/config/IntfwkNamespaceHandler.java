package com.lombard.integration.config;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.xml.BeanDefinitionParser;
import org.springframework.beans.factory.xml.NamespaceHandlerSupport;
import org.springframework.util.ClassUtils;

/**
 * Handler for integration framework namespace (intfwk).
 * <p>
 * Support <code>client</code> element to define client settings, and <code>service-definitions</code> element to
 * define multiple service definition.
 * 
 * @author wvandenberghe
 * 
 */
public class IntfwkNamespaceHandler extends NamespaceHandlerSupport {

    private static final Log LOG = LogFactory.getLog(IntfwkNamespaceHandler.class);

    private enum NamespaceParser {
        CLIENT("client", "com.lombard.integration.ws.client.config.ClientDefinitionParser"),
        SERVICES("service-definitions",
                "com.lombard.integration.ws.server.config.ServiceDefinitionsDefinitionParser"), INIT_SERVICES(
                "init-service", "com.lombard.integration.ws.server.config.InitServiceDefinitionParser"),
        NOTIF_PUBLISHER("notif-publisher",
                "com.lombard.integration.ntf.pub.config.NotificationPublisherDefinitionParser"), NOTIF_CONSUMER(
                "notif-consumer", "com.lombard.integration.ntf.sub.config.NotificationConsumerDefinitionParser"),
        TRACER("tracer", "com.lombard.integration.tntf.trace.config.TracerDefinitionParser"), GTW_CONSUMER(
                "gtw-consumer", "com.lombard.integration.gtw.sub.config.GatewayConsumerDefinitionParser");

        private final String elementName;

        private final String className;

        /**
         * Constructor from XML element name and class name parser implementation.
         * 
         * @param elementName
         *            XML element name
         * @param className
         *            class name parser implementation
         */
        private NamespaceParser(String elementName, String className) {
            this.elementName = elementName;
            this.className = className;
        }

        /**
         * Get XML element name.
         * 
         * @return
         */
        public String getElementName() {
            return elementName;
        }

        /**
         * Get class name parser implementation.
         * 
         * @return
         */
        public String getClassName() {
            return className;
        }
    }

    /**
     * {@inheritDoc}
     */
    public void init() {
        // for each element in the enumeration, try to get a parser for it
        for (NamespaceParser namespaceParser : NamespaceParser.values()) {
            BeanDefinitionParser parser = getBeanDefinitionParser(namespaceParser.getClassName());
            if (parser != null) {
                registerBeanDefinitionParser(namespaceParser.getElementName(), parser);
            }
        }
    }

    /**
     * Get an instance of this className.
     * 
     * @param className
     *            name of the class to instanciate
     * @return a bean definition parser if this class name can be instanciate and is a BeanDefinitionParser
     *         implementation, else, null
     */
    private BeanDefinitionParser getBeanDefinitionParser(String className) {
        if (ClassUtils.isPresent(className, null)) {
            try {
                // try to load the class
                final Class < ? > beanDefinitionParserClass = ClassUtils.forName(className, null);
                if (beanDefinitionParserClass != null) {
                    // check if its a BeanDefinitionParser
                    if (ClassUtils.isAssignable(BeanDefinitionParser.class, beanDefinitionParserClass)) {
                        // create an object by invoking its default constructor
                        return (BeanDefinitionParser) beanDefinitionParserClass.newInstance();
                    }
                    LOG.error("Class " + className + " is not an implementation of BeanDefinitionParser");
                }
            } catch (ClassNotFoundException e) {
                LOG.warn("Class " + className + " was not found!");
            } catch (InstantiationException e) {
                LOG.warn("Class " + className
                        + " cannot be instanciated. A public default constructor is mandatory.");
            } catch (IllegalAccessException e) {
                LOG.warn("Class "
                        + className
                        + " cannot be accessed. Check if the default constructor is public or the class is accessible.");
            }
        }

        return null;
    }

}
