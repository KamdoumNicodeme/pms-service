package com.lombard.integration.ntf.pub.config;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.StringWriter;

import javax.xml.bind.JAXBElement;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.oxm.XmlMappingException;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.lombard.csm.Notification;
import com.lombard.integration.ntf.pub.NotificationSignatureManager;
import com.lombardinternational.crypto.dsig.InvalidSignatureException;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("/com/lombard/integration/ntf/pub/config/jaxb-context.xml")
public class NotificationSignatureManagerTest {

	@Autowired
	NotificationSignatureManager signatureManager;

	@Autowired
	Jaxb2Marshaller jaxb2Marshaller;

	@Test
	public void testContextLoads() {

	}

	@Test
	public void testDeserializationWithJAXB()
			throws InvalidSignatureException, XmlMappingException, FileNotFoundException {
		// GIVEN
		String source = "src/test/resources/com/lombard/integration/ntf/pub/jaxb_serialization_issue_notification.xml";
		Notification notif = ((JAXBElement<Notification>) jaxb2Marshaller
				.unmarshal(new StreamSource((new FileInputStream(source))))).getValue();

		// WHEN
		Notification signedNotification = signatureManager.sign(notif);
		StringWriter sw = new StringWriter();
		// AND
		jaxb2Marshaller.marshal(signedNotification, new StreamResult(sw));
		String value = sw.toString();

		// THEN
		Assert.assertFalse("JAXB serialization bug https://github.com/javaee/jaxb-v2/issues/1028 is present!",
				value.matches(".*X509Data.*xsi:nil.*"));
		signatureManager.validate(signedNotification);
	}

}
