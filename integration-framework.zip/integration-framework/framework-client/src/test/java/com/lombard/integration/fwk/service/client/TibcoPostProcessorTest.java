package com.lombard.integration.fwk.service.client;

import java.util.Enumeration;
import java.util.NoSuchElementException;

import javax.jms.JMSException;
import javax.jms.Message;

import org.junit.Test;
import org.mockito.Mockito;
import org.springframework.jms.core.MessagePostProcessor;

import com.lombard.integration.ws.client.tibco.TibcoPostProcessor;

public class TibcoPostProcessorTest {

    @Test
    public void testPostProcessMessage() throws JMSException {
        Message message = Mockito.mock(Message.class);

        Mockito.when(message.getPropertyNames()).thenReturn(new Enumeration < String >() {

            private String[] enumeration = {"SOAPJMS_soapAction", "JMSExpiration"};
            private int currentIndex = -1;

            public String nextElement() {
                if (!hasMoreElements()) {
                    throw new NoSuchElementException("No more elemsnts");
                }

                currentIndex++;
                return enumeration[currentIndex];
            }

            public boolean hasMoreElements() {
                return currentIndex < enumeration.length - 1;
            }
        });
        Mockito.when(message.getObjectProperty("SOAPJMS_soapAction")).thenReturn("\"/GetMandateList\"");

        MessagePostProcessor postProcessor = new TibcoPostProcessor();
        postProcessor.postProcessMessage(message);

        Mockito.verify(message).setObjectProperty("SoapAction", "\"/GetMandateList\"");
    }
}
