package com.lombard.integration.fwk.common.client.notification;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.TextMessage;
import javax.xml.bind.UnmarshalException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.lombard.integration.fwk.common.server.notification.AbstractNotificationListener;
import com.lombard.integration.fwk.schema.csm.v2_2.PushInboxMessagesRequest;

public class NotfTestListener extends AbstractNotificationListener {

    private Log logger = LogFactory.getLog(getClass());
    private PushInboxMessagesRequest pushInboxMessagesRequest;

    public synchronized void onMessage(Message message) {
        // TODO Auto-generated method stub
        logger.info("NEW MESSAGE - Test NotificationListener - message: " + message.toString());

        // unmarshall
        try {
            pushInboxMessagesRequest =
                    parseNotification(((TextMessage) message).getText(), PushInboxMessagesRequest.class);
        } catch (UnmarshalException e) {
            logger.error("" + e.getMessage());
        } catch (JMSException e) {
            logger.error("" + e.getMessage());
        }

        notifyAll();
    }

    /* Used by Unit Test to check the message */
    public PushInboxMessagesRequest getPushInboxMessagesRequest() {
        return pushInboxMessagesRequest;
    }
}
