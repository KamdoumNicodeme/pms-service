package com.lombard.integration.ntf.pub.config;

import java.util.Set;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.AnnotatedBeanDefinition;
import org.springframework.beans.factory.config.AutowireCapableBeanFactory;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.beans.factory.config.BeanDefinitionHolder;
import org.springframework.beans.factory.support.AbstractBeanDefinition;
import org.springframework.beans.factory.support.BeanDefinitionBuilder;
import org.springframework.beans.factory.xml.ParserContext;
import org.springframework.context.annotation.ClassPathScanningCandidateComponentProvider;
import org.springframework.core.type.filter.AnnotationTypeFilter;
import org.w3c.dom.Element;

import com.lombard.integration.fwk.notification.annotation.Publisher;
import com.lombard.integration.ntf.NotificationService;
import com.lombard.integration.ntf.config.AbstractMessagingDefinitionParser;
import com.lombard.integration.ntf.pub.NotificationPublisherProxyFactoryBean;
import com.lombard.integration.ntf.pub.NotificationServiceProxyFactoryBean;

/**
 * Parser dedicated to notification client declaration.
 * <p>
 * It injects a proxied instance of {@link NotificationService} to be used as a notification publisher. An additional mechanism allow developer to
 * use its own interface instead of the default one.
 * </p>
 * <p>
 * A complete configuration sample:
 * 
 * <pre>
 * &lt;intfwk:notif-publisher 
 *      id-type="ELOMBARD" 
 *      destination="TEST.NOTIF" 
 *      connection-factory="connectionFactory"
 *      marshaller="marshaller"
 *      unmarshaller="unMarshaller"
 *      base-package="com.lombard.integration.framework.notification.client" />
 * </pre>
 * 
 * </p>
 * <p>
 * Framework common provides a default connection factory (ntiConnectionFactory) and a default marshaller and unmarshaller. The default destination
 * is: NTF.ESB.CORE. The standard configuration should looks like:
 * 
 * <pre>
 * &lt;intfwk:notif-publisher 
 *      id-type="ELOMBARD" 
 *      base-package="com.lombard.integration.framework.notification.client" />
 * </pre>
 * 
 * Where base-package define where to look for interface for notification publication. If it's omitted, the mechanism to look for publishers
 * interfaces is not used.
 * </p>
 * 
 * @author wvandenberghe
 * 
 */
public class NotificationPublisherDefinitionParser extends AbstractMessagingDefinitionParser {

    private static final String BASE_PACKAGE_ATT = "base-package";

    private static final String DEFAULT_CONNECTION_FACTORY = "ntiConnectionFactory";

    private static final String DEFAULT_DESTINATION_NAME = "NTF.ESB.CORE";

    private static final Log logger = LogFactory.getLog(NotificationPublisherDefinitionParser.class);

    /**
     * {@inheritDoc}
     */
    @Override
    protected AbstractBeanDefinition parseInternal(Element element, ParserContext parserContext) {

        BeanDefinitionBuilder builder = BeanDefinitionBuilder.genericBeanDefinition(NotificationServiceProxyFactoryBean.class);

        String connectionFactory = element.getAttribute(CONNECTION_FACTORY_ATT);
        if (connectionFactory.trim().length() == 0) {
            connectionFactory = getDefaultConnectionFactoryReference();
        }

        builder.addPropertyReference("connectionFactory", connectionFactory);

        builder.addPropertyValue("serviceInterface", NotificationService.class);

        String destinationName = element.getAttribute(DESTINATION_ATT);
        if (destinationName == null || destinationName.trim().length() == 0) {
            destinationName = DEFAULT_DESTINATION_NAME;
        }
        builder.addPropertyValue("queueName", destinationName);

        builder.addPropertyValue("receiveTimeout", 1);

        String idTypeAsStr = element.getAttribute(ID_TYPE_ATT);
        builder.addPropertyValue("idType", idTypeAsStr);

        BeanDefinition messageConverter = parseMessageConverter(element, parserContext);
        builder.addPropertyValue("messageConverter", messageConverter);

        builder.setAutowireMode(AutowireCapableBeanFactory.AUTOWIRE_BY_TYPE);

        String basePackage = element.getAttribute(BASE_PACKAGE_ATT);
        if (basePackage.trim().length() > 0) {
            final String notificationServiceName = resolveId(element, builder.getBeanDefinition(), parserContext);
            Set<BeanDefinition> publishers = detectNotificationPublishers(element, parserContext);

            for (BeanDefinition beanDefinition : publishers) {
                if (logger.isDebugEnabled()) {
                    logger.debug(String.format("Register notification publisher [%s]", beanDefinition.getBeanClassName()));
                }
                registerNotificationPublisher(beanDefinition, parserContext, notificationServiceName, idTypeAsStr);
            }
        }

        return builder.getBeanDefinition();
    }

    @Override
    protected String getDefaultConnectionFactoryReference() {

        return DEFAULT_CONNECTION_FACTORY;
    }

    /**
     * Detect notification publisher based on {@link Publisher} annotation.
     * 
     * @param element
     * @param parserContext
     * @return Set of BeanDefinition corresponding to detected bean
     */
    protected Set<BeanDefinition> detectNotificationPublishers(Element element, ParserContext parserContext) {

        ClassPathScanningCandidateComponentProvider componentProvider = new PublisherComponentProvider();
        componentProvider.setResourceLoader(parserContext.getReaderContext().getResourceLoader());

        final String basePackage = element.getAttribute(BASE_PACKAGE_ATT);
        return componentProvider.findCandidateComponents(basePackage);
    }

    /**
     * Register publisher interface
     * 
     * @param beanDefinition
     * @param parserContext
     * @param notificationServiceId
     */
    private void registerNotificationPublisher(BeanDefinition beanDefinition, ParserContext parserContext, String notificationServiceId,
            String idTypeAsStr) {

        BeanDefinitionBuilder builder = BeanDefinitionBuilder.genericBeanDefinition(NotificationPublisherProxyFactoryBean.class);

        builder.addPropertyValue("publisherInterface", beanDefinition.getBeanClassName());

        BeanDefinition businessKeyEvalutor = getBusinessKeyEvaluator();
        builder.addPropertyValue("businessKeyEvaluator", businessKeyEvalutor);

        builder.addPropertyReference("notificationService", notificationServiceId);

        builder.addPropertyValue("idType", idTypeAsStr);

        registerBeanDefinition(
                new BeanDefinitionHolder(builder.getBeanDefinition(), parserContext.getReaderContext().generateBeanName(beanDefinition)),
                parserContext.getRegistry());
    }

    /**
     * Custom classpath scanner to get interfaces annotated by {@link Publisher}
     * 
     * @author wvandenberghe
     * 
     */
    static class PublisherComponentProvider extends ClassPathScanningCandidateComponentProvider {

        /**
         * Default constructor.
         */
        public PublisherComponentProvider() {

            super(false);

            addIncludeFilter(new AnnotationTypeFilter(Publisher.class, false));
        }

        /**
         * {@inheritDoc}
         */
        @Override
        protected boolean isCandidateComponent(AnnotatedBeanDefinition beanDefinition) {

            return beanDefinition.getMetadata().isInterface();
        }
    }
}
