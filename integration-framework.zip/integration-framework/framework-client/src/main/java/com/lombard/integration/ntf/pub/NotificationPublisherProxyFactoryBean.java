package com.lombard.integration.ntf.pub;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.aop.framework.ProxyFactory;
import org.springframework.beans.factory.FactoryBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.core.annotation.AnnotationUtils;
import org.springframework.util.Assert;
import org.springframework.util.ReflectionUtils;

import com.lombard.csm.BusinessContext;
import com.lombard.integration.fwk.notification.annotation.BusinessContextAware;
import com.lombard.integration.fwk.notification.annotation.BusinessKey;
import com.lombard.integration.fwk.notification.annotation.BusinessKeys;

/**
 * 
 * @author wvandenberghe
 * 
 */
public class NotificationPublisherProxyFactoryBean extends NotificationPublisherMethodInterceptor implements
        FactoryBean < Object >, InitializingBean {

    private final Map < Method, List < BusinessKey > > businessKeyMapping =
            new HashMap < Method, List < BusinessKey > >();

    private Class < ? > publisherInterface;

    private Object proxy;

    private boolean isBusinessContextAware = false;

    /**
     * Relation between BusinessContext Class and Business Key
     */
    private final Map < Class < ? >, Method > parameterTypeMapping = new HashMap < Class < ? >, Method >();

    /**
     * 
     * @param publisherInterface
     */
    public void setPublisherInterface(Class < ? > publisherInterface) {
        this.publisherInterface = publisherInterface;

        checkIfBusinessContextAware(publisherInterface);
        registerBusinessKeyMapping(publisherInterface);
    }

    /**
     * {@inheritDoc}
     */
    public void afterPropertiesSet() throws Exception {
        Assert.notNull(publisherInterface, "Property ' publisherInterface' is mandatory");

        proxy = new ProxyFactory(publisherInterface, this).getProxy();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    protected List < BusinessKey > getBusinessKeys(Method method, BusinessContext businessContext) {
        List < BusinessKey > businessKeys =
                (businessKeyMapping.containsKey(method)) ? businessKeyMapping.get(method)
                        : new ArrayList < BusinessKey >();

        if (AnnotationUtils.findAnnotation(method, BusinessContextAware.class) != null) {
            if (logger.isDebugEnabled()) {
                logger.debug("Found BusinessContextAware on " + method.getName()
                        + ". Apply business keys for business context : "
                        + businessContext.getClass().getSimpleName() + ".");
            }

            Method m = parameterTypeMapping.get(businessContext.getClass());
            if (m != null) {
                businessKeys.addAll(getBusinessKeys(m, businessContext));
            }
        }

        return businessKeys;
    }

    /**
     * 
     */
    @Override
    protected void registerBusinessKeyMapping(final Class < ? > publisher) {
        // register business keys
        ReflectionUtils.doWithMethods(publisher, new ReflectionUtils.MethodCallback() {

            public void doWith(Method method) throws IllegalArgumentException, IllegalAccessException {
                BusinessKeys businessKeys = AnnotationUtils.findAnnotation(method, BusinessKeys.class);
                final List < BusinessKey > businessKeyList = new ArrayList < BusinessKey >();
                for (BusinessKey businessKey : businessKeys.value()) {
                    checkBusinessKey(publisher, method, businessKey);

                    businessKeyList.add(businessKey);
                }
                businessKeyMapping.put(method, businessKeyList);
            }
        }, new ReflectionUtils.MethodFilter() {

            public boolean matches(Method method) {
                return AnnotationUtils.findAnnotation(method, BusinessKeys.class) != null;
            }
        });

        // register business key
        ReflectionUtils.doWithMethods(publisher, new ReflectionUtils.MethodCallback() {

            public void doWith(Method method) throws IllegalArgumentException, IllegalAccessException {
                BusinessKey businessKey = AnnotationUtils.findAnnotation(method, BusinessKey.class);
                checkBusinessKey(publisher, method, businessKey);
                if (businessKeyMapping.containsKey(method)) {
                    businessKeyMapping.get(method).add(businessKey);
                } else {
                    businessKeyMapping.put(method, Collections.singletonList(businessKey));
                }
            }
        }, new ReflectionUtils.MethodFilter() {

            public boolean matches(Method method) {
                return AnnotationUtils.findAnnotation(method, BusinessKey.class) != null;
            }
        });

        // register parameter types
        if (isBusinessContextAware) {
            ReflectionUtils.doWithMethods(publisher, new ReflectionUtils.MethodCallback() {

                public void doWith(Method method) throws IllegalArgumentException, IllegalAccessException {
                    Class < ? > parameterType = method.getParameterTypes()[0];
                    if (parameterTypeMapping.containsKey(parameterType)) {
                        Method m = parameterTypeMapping.get(parameterType);
                        throw new IllegalArgumentException("A method serving " + parameterType.getSimpleName()
                                + " is already registered on " + publisher.getSimpleName() + "." + m.getName());
                    }

                    parameterTypeMapping.put(parameterType, method);
                }
            }, new ReflectionUtils.MethodFilter() {

                public boolean matches(Method method) {
                    return method.getParameterTypes().length == 1
                            && BusinessContext.class.isAssignableFrom(method.getParameterTypes()[0]);
                }
            });
        }
    }

    /**
     * 
     */
    public Object getObject() throws Exception {
        return proxy;
    }

    /**
     * 
     */
    public Class < ? > getObjectType() {
        return publisherInterface;
    }

    /**
     * 
     */
    public boolean isSingleton() {
        return true;
    }

    /**
     * 
     * @param publisherClass
     * @return
     */
    private void checkIfBusinessContextAware(final Class < ? > publisherClass) {
        ReflectionUtils.doWithMethods(publisherClass, new ReflectionUtils.MethodCallback() {

            public void doWith(Method method) throws IllegalArgumentException, IllegalAccessException {
                isBusinessContextAware = true;
            }
        }, new ReflectionUtils.MethodFilter() {

            public boolean matches(Method method) {
                return AnnotationUtils.findAnnotation(method, BusinessContextAware.class) != null;
            }
        });
    }

    private void checkBusinessKey(Class < ? > publisher, Method method, BusinessKey businessKey) {
        if (businessKey.name().trim().length() == 0) {
            throw new IllegalArgumentException("Property 'name' of BusinessKey on "
                    + publisher.getClass().getSimpleName() + "." + method.getName());
        }
        if (businessKey.expression().trim().length() == 0) {
            throw new IllegalArgumentException("Property 'expression' of BusinessKey on "
                    + publisher.getClass().getSimpleName() + "." + method.getName());
        }

        if (logger.isDebugEnabled()) {
            logger.debug("Business key [" + businessKey.name() + ":" + businessKey.expression() + "] registered");
        }
    }
}
