package com.lombard.integration.ws.client.support;

import java.beans.PropertyDescriptor;
import java.lang.reflect.Field;

import javax.jws.WebService;

import org.springframework.beans.BeansException;
import org.springframework.beans.PropertyValues;
import org.springframework.beans.factory.config.InstantiationAwareBeanPostProcessorAdapter;
import org.springframework.core.Ordered;
import org.springframework.core.PriorityOrdered;
import org.springframework.util.ReflectionUtils;

import com.lombard.integration.fwk.service.annotation.ClientConfig;
import com.lombard.integration.ws.client.WebServiceClientMetadataRegistry;

/**
 * Apply configuration contained by {@link ClientConfig} to the web service client.
 * 
 * @author wvandenberghe
 * 
 */
public class ClientConfigPostProcessor extends InstantiationAwareBeanPostProcessorAdapter implements PriorityOrdered {

    /**
     * {@inheritDoc}
     */
    public int getOrder() {
        return Ordered.LOWEST_PRECEDENCE;
    }

    /**
     * {@inheritDoc}
     */
    public PropertyValues postProcessPropertyValues(PropertyValues pvs, PropertyDescriptor[] pds, Object bean,
            final String beanName) throws BeansException {
        ReflectionUtils.doWithFields(bean.getClass(), new ReflectionUtils.FieldCallback() {

            public void doWith(Field field) throws IllegalArgumentException, IllegalAccessException {
                registerMetadata(field);
            }
        }, CLIENTCONFIG_ANNOT);

        return pvs;
    }

    private void registerMetadata(Field field) {
        WebService annotation = field.getType().getAnnotation(WebService.class);
        if (annotation == null) {
            throw new IllegalArgumentException(
                    "[ClientConfig] annotation must not be placed on bean that are not a Web Service Client");
        }

        ClientConfig clientConfig = field.getAnnotation(ClientConfig.class);

        // set the timeout
        if (clientConfig.timeout() < 0) {
            throw new IllegalArgumentException("'timeout' must not be lower than 0");
        }

        WebServiceClientMetadataRegistry.instance().setAllMetadata(annotation, clientConfig.timeout(),
                clientConfig.validate());
    }

    /**
     * 
     */
    private static final ReflectionUtils.FieldFilter CLIENTCONFIG_ANNOT = new ReflectionUtils.FieldFilter() {

        public boolean matches(Field field) {
            return field.isAnnotationPresent(ClientConfig.class);
        }
    };

}
