package com.lombard.integration.ws.client.soap;

import java.io.IOException;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.util.Assert;
import org.springframework.ws.WebServiceMessage;
import org.springframework.ws.soap.SoapMessage;
import org.springframework.ws.soap.client.SoapFaultClientException;
import org.springframework.ws.soap.client.core.SoapFaultMessageResolver;

import com.lombard.integration.ws.client.BusinessException;
import com.lombard.integration.ws.client.TechnicalException;

/**
 * Tibco ESB fault message resolver.
 * <p>
 * Catch some SOAP fault and throw the corresponding exception:
 * <ul>
 * <li>TechnicalError: {@link TechnicalException}</li>
 * <li>BusinessError: {@link BusinessException}</li>
 * </ul>
 * 
 * @author wvandenberghe
 * 
 */
public class DefaultFaultMessageResolver extends SoapFaultMessageResolver {

    /**
     * {@inheritDoc}
     */
    public void resolveFault(WebServiceMessage message) throws IOException {
        if (message instanceof SoapMessage) {
            SoapMessage soapMessage = (SoapMessage) message;

            String reason = soapMessage.getFaultReason();
            if (reason != null) {
                FaultReason faultReason = FaultReason.getFaultReasonFromName(reason);
                if (faultReason != null) {
                    SoapFaultClientException toBeThrown = faultReason.getException(soapMessage);

                    if (toBeThrown != null) {
                        throw toBeThrown;
                    }
                }
            }
        }

        super.resolveFault(message);
    }

    /**
     * 
     * @author wvandenberghe
     * 
     */
    enum FaultReason {

        TECHNICALERROR("TechnicalError", TechnicalException.class), BUSINESSERROR("BusinessError",
                BusinessException.class);

        private static final Log logger = LogFactory.getLog(FaultReason.class);

        private final String name;
        private final Class < ? > exceptionClass;

        /**
         * 
         * @param name
         * @param exceptionClass
         */
        private FaultReason(final String name, final Class < ? > exceptionClass) {
            this.name = name;
            this.exceptionClass = exceptionClass;
        }

        /**
         * 
         * @param message
         * @return
         */
        public SoapFaultClientException getException(SoapMessage message) {
            try {
                Constructor < ? > constructor = exceptionClass.getConstructor(SoapMessage.class);
                return (SoapFaultClientException) constructor.newInstance(message);
            } catch (NoSuchMethodException e) {
                logger.error(e);
                return null;
            } catch (IllegalArgumentException e) {
                logger.error(e);
                return null;
            } catch (InstantiationException e) {
                logger.error(e);
                return null;
            } catch (IllegalAccessException e) {
                logger.error(e);
                return null;
            } catch (InvocationTargetException e) {
                logger.error(e);
                return null;
            }
        }

        /**
         * 
         * @return
         */
        public String getName() {
            return name;
        }

        /**
         * 
         * @param name
         * @return
         */
        public static FaultReason getFaultReasonFromName(String name) {
            Assert.notNull(name, "'name' cannot be null");

            for (FaultReason faultReason : FaultReason.values()) {
                if (name.contains(faultReason.getName())) {
                    return faultReason;
                }
            }

            return null;
        }
    }
}
