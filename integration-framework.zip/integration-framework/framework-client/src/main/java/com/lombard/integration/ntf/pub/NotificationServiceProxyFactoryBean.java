package com.lombard.integration.ntf.pub;

import javax.jms.JMSException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.remoting.support.RemoteInvocation;
import org.springframework.remoting.support.RemoteInvocationResult;
import org.springframework.util.Assert;

import com.lombard.cdm.IdType;
import com.lombard.csm.Notification;
import com.lombard.integration.fwk.utils.CorrelationHandlerBuilder;
import com.lombard.integration.ntf.NotificationService;
import com.lombard.integration.pubsub.TransactionalServiceProxyFactoryBean;

/**
 * Factory for {@link NotificationService} to publish messages.
 * 
 * @author wvandenberghe
 * 
 */
public class NotificationServiceProxyFactoryBean extends TransactionalServiceProxyFactoryBean {

    private static final Log log = LogFactory.getLog(NotificationServiceProxyFactoryBean.class);

    private IdType idType;

    /**
     * Get application name.
     * 
     * @return
     */
    protected IdType getIdType() {

        return idType;
    }

    /**
     * Set application name.
     * 
     * @param idType
     */
    public void setIdType(IdType idType) {

        this.idType = idType;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void afterPropertiesSet() {

        super.afterPropertiesSet();

        Assert.notNull(getIdType(), "'idType' is mandatory");
    }

    /**
     * Execute the given remote invocation, sending an invoker request message
     * to this accessor's target queue and waiting for a corresponding response.
     * 
     * @param invocation
     *            the RemoteInvocation to execute
     * @return the RemoteInvocationResult object
     * @throws JMSException
     *             in case of JMS failure
     * @see #doExecuteRequest
     */
    @Override
    protected RemoteInvocationResult executeRequest(RemoteInvocation invocation) throws JMSException {

        final Object[] arguments = invocation.getArguments();

        if (arguments.length == 1 && arguments[0] instanceof Notification) {
            final Notification notification = (Notification) arguments[0];

            if (notification.getCorrelationHandler() != null) {
                // ensure correlation handler follow up
                notification.setCorrelationHandler(CorrelationHandlerBuilder.from(notification.getCorrelationHandler()).build());
            } else {
                notification.setCorrelationHandler(CorrelationHandlerBuilder.from(getIdType()).build());
            }
        } else {
            log.warn("Remote invocation is not compliant with NotificationService");
        }

        return super.executeRequest(invocation);
    }

}
