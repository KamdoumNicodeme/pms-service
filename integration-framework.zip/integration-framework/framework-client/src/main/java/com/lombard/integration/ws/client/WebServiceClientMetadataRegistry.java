package com.lombard.integration.ws.client;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

import javax.jws.WebService;

/**
 * Registry for web service client metadata such as request validation and timeout.
 * 
 * @author wvandenberghe
 * 
 */
public final class WebServiceClientMetadataRegistry {

    /**
     * Concrete registry
     */
    private ConcurrentMap < WebService, WebServiceClientMetadata > registry =
            new ConcurrentHashMap < WebService, WebServiceClientMetadataRegistry.WebServiceClientMetadata >();

    /**
     * Default constructor
     */
    private WebServiceClientMetadataRegistry() {
    }

    /**
     * Get the unique registry instance
     * 
     * @return registry instance
     */
    public static final WebServiceClientMetadataRegistry instance() {
        return WebServiceClientMetadataRegistryHolder.instanceHolder;
    }

    /**
     * 
     * @param webService
     * @return
     */
    public WebServiceClientMetadata getMetadata(WebService webService) {
        synchronized (registry) {
            if (registry.containsKey(webService)) {
                return registry.get(webService);
            } else {
                WebServiceClientMetadata metadata = new WebServiceClientMetadata();
                registry.put(webService, metadata);
                return metadata;
            }
        }
    }

    /**
     * 
     * @param webService
     * @return
     */
    public long getTimeoutMetadata(WebService webService) {
        WebServiceClientMetadata metadata = getMetadata(webService);
        return metadata.getTimeout();
    }

    /**
     * 
     * @param webService
     * @param timeout
     */
    public void setTimeoutMetadata(WebService webService, long timeout) {
        synchronized (registry) {
            WebServiceClientMetadata metadata = null;
            if (registry.containsKey(webService)) {
                WebServiceClientMetadata currentMetadata = registry.get(webService);
                if (timeout > currentMetadata.getTimeout()) {
                    metadata = new WebServiceClientMetadata(timeout, currentMetadata.isValidate());
                } else {
                    metadata = currentMetadata;
                }
            } else {
                metadata = new WebServiceClientMetadata(timeout);
            }
            registry.put(webService, metadata);
        }
    }

    /**
     * 
     * @param webService
     * @param validate
     */
    public void setValidateMetadata(WebService webService, boolean validate) {
        synchronized (registry) {
            WebServiceClientMetadata metadata = null;
            if (registry.containsKey(webService)) {
                WebServiceClientMetadata currentMetadata = registry.get(webService);
                metadata = new WebServiceClientMetadata(currentMetadata.getTimeout(), validate);
            } else {
                metadata = new WebServiceClientMetadata(validate);
            }
            registry.put(webService, metadata);
        }
    }

    /**
     * 
     * @param webService
     * @param timeout
     * @param validate
     */
    public void setAllMetadata(WebService webService, long timeout, boolean validate) {
        synchronized (registry) {
            setTimeoutMetadata(webService, timeout);
            setValidateMetadata(webService, validate);
        }
    }

    /**
     * 
     * @author wvandenberghe
     * 
     */
    public class WebServiceClientMetadata {

        private final long timeout;
        private final boolean validate;

        /**
         * Default constructor.
         * <p>
         * <ul>
         * <li>
         * timeout: 10 s</li>
         * <li>
         * validate: false</li>
         * </ul>
         */
        public WebServiceClientMetadata() {
            this(10000, false);
        }

        /**
         * 
         * @param timeout
         * @param validate
         */
        public WebServiceClientMetadata(long timeout, boolean validate) {
            this.timeout = timeout;
            this.validate = validate;
        }

        /**
         * 
         * @param timeout
         */
        public WebServiceClientMetadata(long timeout) {
            this(timeout, false);
        }

        /**
         * 
         * @param validate
         */
        public WebServiceClientMetadata(boolean validate) {
            this(10000, validate);
        }

        /**
         * Request/response timeout
         * 
         * @return
         */
        public long getTimeout() {
            return timeout;
        }

        /**
         * Request validated
         * 
         * @return
         */
        public boolean isValidate() {
            return validate;
        }

    }

    /**
     * Rgistry holder to create a singleton in a thread safe manner.
     * 
     * @author wvandenberghe
     * 
     */
    private static final class WebServiceClientMetadataRegistryHolder {

        /**
         * Unique registry instance
         */
        private static final WebServiceClientMetadataRegistry instanceHolder =
                new WebServiceClientMetadataRegistry();

        /**
         * Default constructor
         */
        private WebServiceClientMetadataRegistryHolder() {

        }
    }
}
