package com.lombard.integration.ws.client;

import javax.jws.WebService;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.aop.framework.ProxyFactory;
import org.springframework.beans.factory.BeanClassLoaderAware;
import org.springframework.beans.factory.FactoryBean;
import org.springframework.core.annotation.AnnotationUtils;
import org.springframework.util.Assert;
import org.springframework.util.ClassUtils;

/**
 * 
 * @author wvandenberghe
 * 
 */
public class WebServiceClientProxyFactoryBean extends WebServiceClientMethodInterceptor implements
        FactoryBean < Object >, BeanClassLoaderAware {

    private static Log logger = LogFactory.getLog(WebServiceClientProxyFactoryBean.class);

    private Class < ? > serviceInterface;

    private WebService webService;

    private ClassLoader beanClassLoader = ClassUtils.getDefaultClassLoader();

    private Object proxy;

    /**
     * 
     * @param serviceInterface
     */
    public void setServiceInterface(Class < ? > serviceInterface) {
        if (serviceInterface == null || !serviceInterface.isInterface()) {
            throw new IllegalArgumentException("'serviceInterface' must be an interface");
        }
        this.serviceInterface = serviceInterface;
    }

    /**
     * 
     */
    public void setBeanClassLoader(ClassLoader classLoader) {
        this.beanClassLoader = classLoader;
    }

    /**
     * 
     */
    @Override
    public void afterPropertiesSet() throws Exception {
        super.afterPropertiesSet();

        Assert.notNull(serviceInterface, "Property 'serviceInterface' is required");

        webService = AnnotationUtils.findAnnotation(serviceInterface, WebService.class);

        Assert.notNull(webService, "Failed to register service interface [" + serviceInterface.getName()
                + "]. Timeout and validation annotation based settings cannot be take in account.");
        logger.info("Register web service interface [" + serviceInterface.getName() + "]");

        proxy = new ProxyFactory(serviceInterface, this).getProxy(beanClassLoader);
    }

    /**
     * 
     */
    public Object getObject() throws Exception {
        return proxy;
    }

    /**
     * 
     */
    public Class < ? > getObjectType() {
        return serviceInterface;
    }

    /**
     * 
     */
    public boolean isSingleton() {
        return true;
    }

    /**
     * 
     */
    @Override
    protected long getTimeout() {
        return WebServiceClientMetadataRegistry.instance().getTimeoutMetadata(webService);
    }
}
