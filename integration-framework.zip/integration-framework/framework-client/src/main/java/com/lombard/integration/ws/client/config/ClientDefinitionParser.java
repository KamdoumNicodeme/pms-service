package com.lombard.integration.ws.client.config;

import javax.jms.ConnectionFactory;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.beans.factory.support.AbstractBeanDefinition;
import org.springframework.beans.factory.support.BeanDefinitionBuilder;
import org.springframework.beans.factory.xml.ParserContext;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import org.springframework.ws.client.core.WebServiceTemplate;
import org.springframework.ws.client.support.interceptor.PayloadValidatingInterceptor;
import org.springframework.ws.transport.jms.JmsMessageSender;
import org.w3c.dom.Element;

import com.lombard.integration.ws.client.DefaultDestinationProvider;
import com.lombard.integration.ws.client.WebServiceClientProxyFactoryBean;
import com.lombard.integration.ws.client.soap.DefaultFaultMessageResolver;
import com.lombard.integration.ws.client.tibco.TibcoPostProcessor;
import com.lombard.integration.ws.config.AbstractServiceDefinitionParser;

/**
 * Parser for client definition.
 * <p>
 * By default, this client publish messages over JMS in non persistent manner and the messages are in byte format.
 * <p>
 * It use the {@link ConnectionFactory}, {@link org.springframework.ws.WebServiceMessageFactory} and {@link Jaxb2Marshaller} define in the context.
 * 
 * @author wvandenberghe
 * 
 */
public class ClientDefinitionParser extends AbstractServiceDefinitionParser {

    private static final String DEFAULT_CONNECTION_FACTORY = "svcConnectionFactory";
    private static final String DEFAULT_LEGACY_CONNECTION_FACTORY = "legConnectionFactory";
    private static final String LEGACY_SERVICES_PREFIX = "com.lombard.integration.fwk.services";

    /**
     * {@inheritDoc}
     */
    @Override
    protected AbstractBeanDefinition parseInternal(Element element, ParserContext parserContext) {

        BeanDefinitionBuilder builder = BeanDefinitionBuilder.genericBeanDefinition(WebServiceClientProxyFactoryBean.class);

        String clazz = element.getAttribute(CLASS_ATT);
        builder.addPropertyValue("serviceInterface", clazz);

        String applicationId = element.getAttribute(ID_TYPE_ATT);
        builder.addPropertyValue("idType", applicationId);

        BeanDefinition webServiceTemplate = parseWebServiceTemplate(element, parserContext);
        builder.addPropertyValue("webServiceTemplate", webServiceTemplate);

        return builder.getBeanDefinition();
    }

    /**
     * Create the {@link WebServiceTemplate} bean definition.
     * 
     * @param element
     * @return {@link WebServiceTemplate} bean definition
     */
    private BeanDefinition parseWebServiceTemplate(Element element, ParserContext parserContext) {

        BeanDefinitionBuilder builder = BeanDefinitionBuilder.genericBeanDefinition(WebServiceTemplate.class);

        String messageFactory = getMessageFactory(parserContext);
        builder.addConstructorArgReference(messageFactory);

        BeanDefinition messageSender = parseMessageSender(element);
        builder.addPropertyValue("messageSender", messageSender);

        BeanDefinition destinationResolver = parseDestinationProvider(element);
        builder.addPropertyValue("destinationProvider", destinationResolver);

        String marshaller = element.getAttribute(MARSHALLER_ATT);
        if (marshaller.length() > 0) {
            builder.addPropertyReference("marshaller", marshaller);
        } else {
            String jaxbMarshaller = getJaxbMarshaller(parserContext);
            builder.addPropertyReference("marshaller", jaxbMarshaller);
        }

        String unmarshaller = element.getAttribute(UNMARSHALLER_ATT);
        if (unmarshaller.length() > 0) {
            builder.addPropertyReference("unmarshaller", unmarshaller);
        } else {
            String jaxbUnmarshaller = getJaxbMarshaller(parserContext);
            builder.addPropertyReference("unmarshaller", jaxbUnmarshaller);
        }

        BeanDefinition interceptor = parseClientInterceptor(element);
        builder.addPropertyValue("interceptors", interceptor);

        BeanDefinition resolver = parseFaultMessageResolver();
        builder.addPropertyValue("faultMessageResolver", resolver);

        return builder.getBeanDefinition();
    }

    /**
     * 
     * @param element
     * @return
     */
    private BeanDefinition parseDestinationProvider(Element element) {

        BeanDefinitionBuilder builder = BeanDefinitionBuilder.genericBeanDefinition(DefaultDestinationProvider.class);

        String destination = element.getAttribute(DESTINATION_ATT);
        builder.addPropertyValue("destinationName", destination);

        long timeout = Long.parseLong(element.getAttribute("timeout"));
        builder.addPropertyValue("defaultTimeout", timeout);

        String clazz = element.getAttribute(CLASS_ATT);
        builder.addPropertyValue("webServiceInterface", clazz);

        return builder.getBeanDefinition();
    }

    /**
     * Create {@link DefaultFaultMessageResolver}
     * 
     * @return
     */
    private BeanDefinition parseFaultMessageResolver() {

        BeanDefinitionBuilder builder = BeanDefinitionBuilder.genericBeanDefinition(DefaultFaultMessageResolver.class);

        return builder.getBeanDefinition();
    }

    /**
     * Parse element to build a {@link org.springframework.ws.client.support.interceptor.ClientInterceptor}.
     * 
     * @param element
     * @return
     */
    private BeanDefinition parseClientInterceptor(Element element) {

        BeanDefinitionBuilder builder = BeanDefinitionBuilder.genericBeanDefinition(PayloadValidatingInterceptor.class);

        String schemas = element.getAttribute(SCHEMAS_ATT);
        builder.addPropertyValue(SCHEMAS_ATT, schemas);

        boolean validateRequest = Boolean.parseBoolean(element.getAttribute(VALIDATE_ATT));
        builder.addPropertyValue("validateRequest", validateRequest);

        return builder.getBeanDefinition();
    }

    /**
     * Parse a {@link JmsMessageSender} object and configure it from the {@link ConnectionFactory}.
     * 
     * @param element
     * @param parserContext
     * @return
     */
    private BeanDefinition parseMessageSender(Element element) {

        BeanDefinitionBuilder builder = BeanDefinitionBuilder.genericBeanDefinition(JmsMessageSender.class);

        builder.addPropertyValue("pubSubDomain", false);

        String connectionFactory = element.getAttribute(CONNECTION_FACTORY_ATT);
        if (connectionFactory.trim().length() == 0) {
            connectionFactory = getDefaultConnectionFactoryReference(element.getAttribute(CLASS_ATT));
        }
        builder.addPropertyReference("connectionFactory", connectionFactory);

        BeanDefinition postProcessor = getPostProcessor();
        builder.addPropertyValue("postProcessor", postProcessor);

        return builder.getBeanDefinition();
    }

    protected String getDefaultConnectionFactoryReference(final String serviceInterfaceName) {

        if (StringUtils.isNotBlank(serviceInterfaceName) && serviceInterfaceName.startsWith(LEGACY_SERVICES_PREFIX)) {
            return DEFAULT_LEGACY_CONNECTION_FACTORY;
        } else {
            return DEFAULT_CONNECTION_FACTORY;
        }
    }

    @Override
    protected String getDefaultConnectionFactoryReference() {

        return DEFAULT_CONNECTION_FACTORY;
    }

    /**
     * Get a post processor for JMS message.
     * <p>
     * To be executed just before sending JMS messages.
     * 
     * @return
     */
    private BeanDefinition getPostProcessor() {

        BeanDefinitionBuilder builder = BeanDefinitionBuilder.genericBeanDefinition(TibcoPostProcessor.class);

        return builder.getBeanDefinition();
    }

}
