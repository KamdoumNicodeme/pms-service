package com.lombard.integration.ntf.pub;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;

import org.springframework.oxm.jaxb.Jaxb2Marshaller;

import com.lombard.csm.Notification;
import com.lombardinternational.crypto.dsig.KeystoreAccessor;
import com.lombardinternational.crypto.dsig.TypedSignatureManager;

public class NotificationSignatureManager extends TypedSignatureManager<Notification> {

    public NotificationSignatureManager(final KeystoreAccessor keystoreAccessor, Jaxb2Marshaller jaxb2Marshaller)
            throws JAXBException, IllegalAccessException, SecurityException, NoSuchFieldException, IllegalArgumentException, NoSuchMethodException,
            InvocationTargetException {

        super(keystoreAccessor, getMarshaller(jaxb2Marshaller), getUnmarshaller(jaxb2Marshaller));

    }

    private static Marshaller getMarshaller(Jaxb2Marshaller jaxb2Marshaller)
            throws SecurityException, NoSuchMethodException, IllegalArgumentException, IllegalAccessException, InvocationTargetException {

        Method method = jaxb2Marshaller.getClass().getDeclaredMethod("createMarshaller");
        method.setAccessible(true);
        Object r = method.invoke(jaxb2Marshaller);
        return (Marshaller) r;
    }

    private static Unmarshaller getUnmarshaller(Jaxb2Marshaller jaxb2Marshaller)
            throws SecurityException, NoSuchMethodException, IllegalArgumentException, IllegalAccessException, InvocationTargetException {

        Method method = jaxb2Marshaller.getClass().getDeclaredMethod("createUnmarshaller");
        method.setAccessible(true);
        Object r = method.invoke(jaxb2Marshaller);
        return (Unmarshaller) r;
    }
}
