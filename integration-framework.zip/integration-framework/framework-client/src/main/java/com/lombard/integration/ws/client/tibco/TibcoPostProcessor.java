package com.lombard.integration.ws.client.tibco;

import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import javax.jms.JMSException;
import javax.jms.Message;

import org.springframework.jms.core.MessagePostProcessor;

/**
 * Post processor dedicated to Tibco usage.
 * <p>
 * As Spring WS publish SOAP action under SOAPJMS_SoapAction property name, it must be renamed to be understood by
 * Tibco adapters that are listening for SoapAction.
 * 
 * @author wvandenberghe
 * 
 */
public class TibcoPostProcessor implements MessagePostProcessor {

    private static final String SOAPJMS_HEADER = "SOAPJMS_";

    /**
     * {@inheritDoc}
     */
    public Message postProcessMessage(Message message) throws JMSException {
        @SuppressWarnings("rawtypes")
        Enumeration names = message.getPropertyNames();
        // use temporary map to avoid concurrency issue (exceptions)
        Map < String, Object > properties = new HashMap < String, Object >();
        while (names.hasMoreElements()) {
            String name = (String) names.nextElement();
            Object value = message.getObjectProperty(name);

            // check property name for SOAPJMS_
            if (name.contains(SOAPJMS_HEADER)) {
                // if found: add property with property without SOAP_JMS_
                String nameBody = name.replace(SOAPJMS_HEADER, "");
                String upperCase = nameBody.substring(0, 1).toUpperCase() + nameBody.substring(1);

                properties.put(upperCase, value);
            }
        }

        // apply them all to the message header
        for (Entry < String, Object > entry : properties.entrySet()) {
            message.setObjectProperty(entry.getKey(), entry.getValue());
        }

        return message;
    }

}
