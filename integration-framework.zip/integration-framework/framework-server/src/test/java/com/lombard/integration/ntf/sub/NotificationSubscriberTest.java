package com.lombard.integration.ntf.sub;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.Session;

import org.hamcrest.CoreMatchers;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.core.io.Resource;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.core.MessageCreator;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.lombard.csm.IncomingFeeBusinessContext;
import com.lombard.csm.Notification;
import com.lombard.integration.ntf.NotificationService;

@ContextConfiguration("classpath:/com/lombard/integration/ntf/sub/notification_sub-context.xml")
@RunWith(SpringJUnit4ClassRunner.class)
public class NotificationSubscriberTest implements NotificationService {

    @Autowired
    private JmsTemplate jmsTemplate;

    @Autowired
    private ApplicationContext applicationContext;

    private static boolean notified = false;

    @Test(timeout = 10000)
    public void testConsume() throws JMSException, IOException, InterruptedException {
        Resource resource =
                applicationContext.getResource("classpath:/com/lombard/integration/ntf/sub/incomingFee.xml");
        InputStream stream = null;
        ByteArrayOutputStream out = null;

        try {
            stream = resource.getInputStream();
            out = new ByteArrayOutputStream();

            byte[] buffer = new byte[4096];
            int bufferLength = 0;
            while ((bufferLength = stream.read(buffer)) != -1) {
                out.write(buffer, 0, bufferLength);
            }
            sendAsText(out.toString());

            while (!notified) {
                Thread.sleep(1000);
            }

            Assert.assertTrue(notified);
        } finally {
            if (stream != null) {
                try {
                    stream.close();
                } catch (IOException e1) {

                }
            }

            if (out != null) {
                try {
                    out.close();
                } catch (IOException e1) {

                }
            }
        }
    }

    private void sendAsText(final String text) {
        jmsTemplate.send("TEST.NOTIF", new MessageCreator() {

            public Message createMessage(Session session) throws JMSException {
                return session.createTextMessage(text);
            }
        });
    }

    public void sendOrReceive(Notification notification) {
        notified = true;
        Assert.assertNotNull(notification);
        Assert.assertNotNull(notification.getBusinessContext());
        Assert.assertThat(notification.getBusinessContext(),
                CoreMatchers.instanceOf(IncomingFeeBusinessContext.class));
    }

}
