package com.lombard.integration.ws.server.config;

import static org.hamcrest.CoreMatchers.anyOf;
import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.instanceOf;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThat;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import junit.framework.Assert;

import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.jms.listener.DefaultMessageListenerContainer;
import org.springframework.ws.server.EndpointMapping;
import org.springframework.ws.soap.server.SoapMessageDispatcher;
import org.springframework.ws.transport.WebServiceMessageReceiver;
import org.springframework.ws.transport.jms.WebServiceMessageListener;

import com.lombard.integration.ws.server.soap.SoapActionMethodEndpointMapping;
import com.lombard.integration.ws.server.support.ServiceDefinitionPostProcessor;

/**
 * Test to only validate configuration.
 * 
 * @author wvandenberghe
 * 
 */
public class DefinitionParserTest {

    @Test
    public void testServiceDefinitions() {
        ApplicationContext applicationContext =
                new ClassPathXmlApplicationContext(
                        "/com/lombard/integration/ws/server/config/service_definitions-context.xml");

        DefaultMessageListenerContainer container =
                applicationContext.getBean(DefaultMessageListenerContainer.class);
        testEndpoint(container, "TEST.WS", MandateServiceImpl.class);
    }

    @Test
    public void testInitServices() {
        ApplicationContext applicationContext =
                new ClassPathXmlApplicationContext(
                        "/com/lombard/integration/ws/server/config/init_services-context.xml");

        // check post processor existence
        applicationContext.getBean(ServiceDefinitionPostProcessor.class);

        DefaultMessageListenerContainer container =
                applicationContext.getBean(DefaultMessageListenerContainer.class);
        testEndpoint(container, "TEST.WS", MandateServiceImplWithAnnotation.class);
    }

    @SuppressWarnings("unchecked")
    @Test
    public void testMix() {
        ApplicationContext applicationContext =
                new ClassPathXmlApplicationContext("/com/lombard/integration/ws/server/config/mix-context.xml");

        // check post processor existence
        applicationContext.getBean(ServiceDefinitionPostProcessor.class);

        Map < String, DefaultMessageListenerContainer > beansMap =
                applicationContext.getBeansOfType(DefaultMessageListenerContainer.class);
        assertEquals("2 container must be listening", 2, beansMap.size());
        for (Entry < String, DefaultMessageListenerContainer > entry : beansMap.entrySet()) {
            DefaultMessageListenerContainer container = entry.getValue();
            assertThat(container.getDestinationName(), anyOf(equalTo("TEST.WS"), equalTo("TEST.INIT.WS")));

            if (container.getDestinationName().equals("TEST.WS")) {
                testEndpoint(container, "TEST.WS", MandateServiceImpl.class);
            } else if (container.getDestinationName().equals("TEST.INIT.WS")) {
                testEndpoint(container, "TEST.INIT.WS", MandateServiceImplWithAnnotation.class);
            } else {
                Assert.fail("Unknown destination " + container.getDestinationName());
            }
        }

    }

    private List < Object > getEndpoints(DefaultMessageListenerContainer container) {
        Object messageListener = container.getMessageListener();
        if (messageListener instanceof WebServiceMessageListener) {
            WebServiceMessageListener wsMessageListener = (WebServiceMessageListener) messageListener;
            WebServiceMessageReceiver wsMessageReceiver = wsMessageListener.getMessageReceiver();
            if (wsMessageReceiver instanceof SoapMessageDispatcher) {
                SoapMessageDispatcher messageDispatcher = (SoapMessageDispatcher) wsMessageReceiver;

                List < Object > result = new ArrayList < Object >();
                for (EndpointMapping em : messageDispatcher.getEndpointMappings()) {
                    if (em instanceof SoapActionMethodEndpointMapping) {
                        SoapActionMethodEndpointMapping endpointMapping = (SoapActionMethodEndpointMapping) em;
                        result.addAll(Arrays.asList(endpointMapping.getEndpoints()));
                    }
                }

                return result;
            }
        }

        Assert.fail("Malformed message listener container");
        return new ArrayList < Object >();
    }

    private void testEndpoint(DefaultMessageListenerContainer container, String destinationName, Class < ? > endpoint) {
        assertEquals("Destination name must be '" + destinationName + "'", destinationName,
                container.getDestinationName());
        assertEquals("One endpoint expected", 1, getEndpoints(container).size());
        assertThat(endpoint.getSimpleName() + " endpoint expected", getEndpoints(container).get(0),
                instanceOf(endpoint));
    }
}
