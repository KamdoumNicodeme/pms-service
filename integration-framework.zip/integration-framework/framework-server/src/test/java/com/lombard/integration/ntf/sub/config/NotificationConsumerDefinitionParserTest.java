package com.lombard.integration.ntf.sub.config;

import org.hamcrest.CoreMatchers;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.lombard.csm.AssetDescriptionBusinessContext;
import com.lombard.csm.AssetPositionBusinessContext;
import com.lombard.csm.CorporateActionConfirmationBusinessContext;
import com.lombard.csm.FundBusinessContext;
import com.lombard.csm.Notification;
import com.lombard.csm.TradeConfirmationBusinessContext;
import com.lombard.csm.TradeOrderBusinessContext;
import com.lombard.integration.sub.mapping.MethodEndpointMapper;
import com.lombard.integration.sub.mapping.EndpointMapper.EndpointMapping;

@ContextConfiguration("classpath:/com/lombard/integration/ntf/sub/config/ntf-context.xml")
@RunWith(SpringJUnit4ClassRunner.class)
public class NotificationConsumerDefinitionParserTest {

    @Autowired
    private MethodEndpointMapper endpointMapper;

    @Test
    public void testDefault() {
        EndpointMapping endpointMapping =
                endpointMapper.getEndpointMapping(AssetPositionBusinessContext.class.getSimpleName());

        checkEndpointMapping(endpointMapping, Notification.class, "defaultConsumer", 0);
    }

    @Test
    public void testSelector() {
        EndpointMapping endpointMapping =
                endpointMapper.getEndpointMapping(TradeConfirmationBusinessContext.class.getSimpleName());

        checkEndpointMapping(endpointMapping, Notification.class, "selectorBasedConsumer", 0);
    }

    @Test
    public void testArgumentBased() {
        EndpointMapping endpointMapping =
                endpointMapper.getEndpointMapping(TradeOrderBusinessContext.class.getSimpleName());

        checkEndpointMapping(endpointMapping, TradeOrderBusinessContext.class, "argumentBasedConsumer", 0);
    }

    @Test
    public void testOneBusinessKey() {
        EndpointMapping endpointMapping =
                endpointMapper.getEndpointMapping(CorporateActionConfirmationBusinessContext.class.getSimpleName());

        checkEndpointMapping(endpointMapping, CorporateActionConfirmationBusinessContext.class,
                "oneBusinessKeyConsumer", 1);
    }

    @Test
    public void testBusinessKeyBundle() {
        EndpointMapping endpointMapping =
                endpointMapper.getEndpointMapping(FundBusinessContext.class.getSimpleName());

        checkEndpointMapping(endpointMapping, FundBusinessContext.class, "businessKeyBundleConsumer", 2);
    }

    @Test
    public void testAggregateBusinessKey() {
        EndpointMapping endpointMapping =
                endpointMapper.getEndpointMapping(AssetDescriptionBusinessContext.class.getSimpleName());

        checkEndpointMapping(endpointMapping, AssetDescriptionBusinessContext.class,
                "agglomerateBusinessKeysConsumer", 3);
    }

    private void checkEndpointMapping(EndpointMapping actual, Class < ? > argumentType, String methodName,
            int bkCount) {
        Assert.assertNotNull(actual);
        Assert.assertThat(actual.getEndpoint(), CoreMatchers.instanceOf(NotificationConsumer.class));
        Assert.assertEquals(argumentType, actual.getArgumentType());
        Assert.assertEquals(methodName, actual.getMethod().getName());
        Assert.assertEquals(bkCount, actual.getBusinessKeys().size());
    }
}
