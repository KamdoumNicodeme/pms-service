package com.lombard.integration.ws.server;

import javax.jws.WebService;

@WebService
public interface WebServiceInterface {

}
