package com.lombard.integration.gtw.sub;

import java.util.Map;
import java.util.Map.Entry;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.Session;

import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.core.MessageCreator;
import org.springframework.jms.support.converter.SimpleMessageConverter;
import org.springframework.util.Assert;

import com.lombard.integration.gtw.sub.config.GatewayConsumerDefinitionParser;
import com.lombard.integration.sub.HeaderKey;
import com.lombard.integration.sub.ResponseManager;

public class GatewayResponseManager implements ResponseManager {

    private final SimpleMessageConverter converter = new SimpleMessageConverter();
    private JmsTemplate gtwResponseJmsTemplate;
    private String channel;

    public void setGtwResponseJmsTemplate(final JmsTemplate gtwResponseJmsTemplate) {

        this.gtwResponseJmsTemplate = gtwResponseJmsTemplate;
    }

    public void setChannel(final String channel) {

        this.channel = channel;
    }

    public void processResponse(final Object response, final Map<String,String> headers) {

        Assert.notNull(gtwResponseJmsTemplate.getDefaultDestinationName(),
                "The response's destination can't be null. Set the property " + GatewayConsumerDefinitionParser.RESPONSE_DESTINATION);

        gtwResponseJmsTemplate.send(new MessageCreator() {

            public Message createMessage(Session session) throws JMSException {

                final Message msg = converter.toMessage(response, session);
                for (Entry<String,String> entry : headers.entrySet()) {
                    msg.setStringProperty(entry.getKey(), entry.getValue());
                }
                if (channel != null) {
                    msg.setStringProperty(HeaderKey.CHANNEL.getKey(), channel);
                }
                return msg;
            }
        });
    }

}
