package com.lombard.integration.ntf.sub;

import javax.jms.Message;

import com.lombard.cdm.ApplicationContext;
import com.lombard.cdm.CorrelationHandler;
import com.lombard.cdm.IdType;
import com.lombard.csm.Notification;
import com.lombard.integration.sub.InvocationContextDelegate;
import com.lombard.integration.sub.InvocationContextFactory;

/**
 * 
 * @author wvandenberghe
 * 
 */
public class NotificationInvocationContextFactory implements InvocationContextFactory < Notification > {

    /**
     * {@inheritDoc}
     */
    public InvocationContext < Notification > create(Message message, Notification invokedOn) {
        return new InvocationContextDelegate < Notification >(message, invokedOn) {
            public String getCorrelationId() {
                return (getCorrelationHandler() != null) ? getCorrelationHandler().getId() : null;
            }

            public String getFlowName() {
                return getInvokedOn().getBusinessContext().getClass().getSimpleName();
            }

            public IdType getInitiatorName() {
                return (getInitiator() != null) ? getInitiator().getName() : null;
            }

            public String getInitiatorNode() {
                return getInvokedOn().getCorrelationHandler().getInitiator().getNode();
            }

            private CorrelationHandler getCorrelationHandler() {
                return getInvokedOn().getCorrelationHandler();
            }

            private ApplicationContext getInitiator() {
                CorrelationHandler correlationHandler = getCorrelationHandler();

                if (correlationHandler != null) {
                    return correlationHandler.getInitiator();
                }

                return null;
            }
        };
    }

}
