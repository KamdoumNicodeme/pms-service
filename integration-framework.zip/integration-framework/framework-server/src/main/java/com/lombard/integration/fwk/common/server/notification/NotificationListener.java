package com.lombard.integration.fwk.common.server.notification;

import javax.jms.MessageListener;

public interface NotificationListener extends MessageListener {

}
