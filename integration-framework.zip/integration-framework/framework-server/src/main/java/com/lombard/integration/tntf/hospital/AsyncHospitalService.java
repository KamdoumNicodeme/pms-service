package com.lombard.integration.tntf.hospital;

import javax.jms.ConnectionFactory;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.core.task.TaskExecutor;
import org.springframework.jms.support.converter.MessageConverter;
import org.springframework.util.Assert;

import com.lombard.cdm.ActivityHandler;

/**
 * Implementation of {@link HospitalService} in an asynchronous manner.
 * 
 * @author wvandenberghe
 * 
 */
public class AsyncHospitalService implements HospitalService, InitializingBean {

    private static final Log log = LogFactory.getLog(AsyncHospitalService.class);

    private static final String DEFAULT_QUEUE_NAME = "TNTF.HOSPITAL";

    private TaskExecutor taskExecutor;

    private ConnectionFactory connectionFactory;

    private MessageConverter messageConverter;

    private String queueName;

    private HospitalService hospitalService;

    /**
     * 
     * @param taskExecutor
     */
    public void setTaskExecutor(TaskExecutor taskExecutor) {

        this.taskExecutor = taskExecutor;
    }

    /**
     * Set connection factory.
     * 
     * @param connectionFactory
     */
    public void setConnectionFactory(ConnectionFactory connectionFactory) {

        this.connectionFactory = connectionFactory;
    }

    /**
     * Set message converter.
     * 
     * @param messageConverter
     */
    public void setMessageConverter(MessageConverter messageConverter) {

        this.messageConverter = messageConverter;
    }

    /**
     * Set queue name.
     * 
     * @param queueName
     */
    public void setQueueName(String queueName) {

        this.queueName = queueName;
    }

    /**
     * Get queue name.
     * 
     * @return if not set, return TNTF.TRACE
     */
    protected String getQueueName() {

        return (queueName == null) ? DEFAULT_QUEUE_NAME : queueName;
    }

    /**
     * {@inheritDoc}
     */
    public void afterPropertiesSet() throws Exception {

        Assert.notNull(connectionFactory, "'connectionFactory' is mandatory");

        HospitalServiceProxyFactoryBean factoryBean = new HospitalServiceProxyFactoryBean();
        factoryBean.setConnectionFactory(connectionFactory);
        factoryBean.setMessageConverter(messageConverter);
        factoryBean.setQueueName(getQueueName());

        factoryBean.afterPropertiesSet();
        hospitalService = (HospitalService) factoryBean.getObject();
    }

    /**
     * Send the activity handler to the tracing tool.
     */
    public void hospitalize(final ActivityHandler activityHandler) {

        taskExecutor.execute(new Runnable() {

            /**
             * Send tracing in a asynchronous manner.
             */
            public void run() {

                if (hospitalService != null) {
                    try {
                        hospitalService.hospitalize(activityHandler);
                    } catch (Exception e) {
                        log.error("Error occured while sending notification to hospital", e);
                    }
                } else {
                    log.warn("Cannot send trace, tracer not initialized");
                }
            }
        });
    }
}
