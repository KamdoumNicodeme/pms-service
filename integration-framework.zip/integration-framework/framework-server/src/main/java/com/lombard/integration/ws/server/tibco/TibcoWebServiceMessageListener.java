package com.lombard.integration.ws.server.tibco;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.Session;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.ws.transport.jms.WebServiceMessageListener;

import com.tibco.tibjms.TibjmsBytesMessage;

/**
 * Listener to add some missing properties in case of Tibco web service client.
 * <p>
 * When Tibco request a web service, some properties needed by Spring-WS are missing:
 * <ul>
 * <li>SOAPJMS_soapAction</li>
 * <li>SOAPJMS_contentType</li>
 * </ul>
 * 
 * @author wvandenberghe
 * 
 */
public class TibcoWebServiceMessageListener extends WebServiceMessageListener {

    private static final Log logger = LogFactory.getLog(TibcoWebServiceMessageListener.class);

    private static final String CONTENT_TYPE = "Content_Type";

    private static final String SOAP_ACTION = "SoapAction";

    private static final String DEFAULT_CONTENT_TYPE = "text/xml";

    private static final String JMS_SOAP_ACTION = "SOAPJMS_soapAction";

    private static final String JMS_CONTENT_TYPE = "SOAPJMS_contentType";

    /**
     * {@inheritDoc}
     */
    @Override
    public void onMessage(Message message, Session session) throws JMSException {
        if (message instanceof TibjmsBytesMessage) {
            final TibjmsBytesMessage originalMessage = (TibjmsBytesMessage) message;

            // wrap message for modification
            final TibjmsMessageWrapper wrapper = new TibjmsMessageWrapper(originalMessage);

            if (!wrapper.propertyExists(JMS_SOAP_ACTION)) {
                final String soapAction = wrapper.getStringProperty(SOAP_ACTION);
                wrapper.setStringProperty(JMS_SOAP_ACTION, soapAction);

                if (logger.isDebugEnabled()) {
                    logger.debug("Add [SOAPJMS_soapAction] property: " + soapAction);
                }
            }

            if (!wrapper.propertyExists(JMS_CONTENT_TYPE)) {
                wrapper.setStringProperty(CONTENT_TYPE, DEFAULT_CONTENT_TYPE);
                wrapper.setStringProperty(JMS_CONTENT_TYPE, DEFAULT_CONTENT_TYPE);

                if (logger.isDebugEnabled()) {
                    logger.debug("Add [SOAPJMS_contentType] property: " + DEFAULT_CONTENT_TYPE);
                }
            }
        }
        // this.setPostProcessor(postProcessor)
        super.onMessage(message, session);
    }
}
