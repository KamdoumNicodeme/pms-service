package com.lombard.integration.ws.server.jaxb;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;

import javax.xml.bind.JAXBException;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import javax.xml.transform.Source;
import javax.xml.transform.TransformerException;
import javax.xml.transform.stream.StreamResult;

import org.springframework.core.MethodParameter;
import org.springframework.util.Assert;
import org.springframework.ws.context.MessageContext;
import org.springframework.ws.server.endpoint.adapter.method.MethodArgumentResolver;
import org.springframework.ws.server.endpoint.adapter.method.MethodReturnValueHandler;
import org.springframework.xml.transform.TransformerObjectSupport;

/**
 * A JAXB payload processor implementation to support element annotated {@link XmlType} but not
 * {@link XmlRootElement}.
 * 
 * @author wvandenberghe
 * 
 */
public class SimpleJaxbPayloadMethodProcessor extends TransformerObjectSupport implements MethodArgumentResolver,
        MethodReturnValueHandler {

    private MethodArgumentResolver argumentResolverDelegate;

    private MethodReturnValueHandler returnValueDelegate;

    /**
     * Set the delegate payload method processor used to resolve arguments.
     * 
     * @param argumentResolverDelegate
     */
    public void setArgumentResolverDelegate(MethodArgumentResolver argumentResolverDelegate) {
        this.argumentResolverDelegate = argumentResolverDelegate;
    }

    /**
     * Set the delegate payload method processor used to handle return value.
     * 
     * @param returnValueDelegate
     */
    public void setReturnValueDelegate(MethodReturnValueHandler returnValueDelegate) {
        this.returnValueDelegate = returnValueDelegate;
    }

    /**
     * {@inheritDoc}
     * <p/>
     * This implementation gets checks if the given parameter is annotated with
     * {@link org.springframework.ws.server.endpoint.annotation.RequestPayload}, and invokes
     * {@link #supportsRequestPayloadParameter(org.springframework.core.MethodParameter)} afterwards.
     */
    public final boolean supportsParameter(MethodParameter parameter) {
        Assert.isTrue(parameter.getParameterIndex() >= 0, "Parameter index larger smaller than 0");
        Class < ? > parameterType = parameter.getParameterType();
        return parameterType.isAnnotationPresent(XmlType.class);
    }

    /**
     * {@inheritDoc}
     */
    public Object resolveArgument(MessageContext messageContext, MethodParameter parameter) throws JAXBException {
        try {
            return argumentResolverDelegate.resolveArgument(messageContext, parameter);
        } catch (JAXBException e) {
            // re throw exception
            throw e;
        } catch (Exception e) {
            // encapsulate it
            throw new JAXBException(e);
        }
    }

    /**
     * {@inheritDoc}
     * <p/>
     * This implementation gets checks if the method of the given return type is annotated with
     * {@link org.springframework.ws.server.endpoint.annotation.ResponsePayload} , and invokes
     * {@link #supportsResponsePayloadReturnType(org.springframework.core.MethodParameter)} afterwards.
     */
    public final boolean supportsReturnType(MethodParameter returnType) {
        Assert.isTrue(returnType.getParameterIndex() == -1, "Parameter index is not -1");
        Class < ? > parameterType = returnType.getParameterType();
        return parameterType.isAnnotationPresent(XmlType.class);
    }

    /**
     * {@inheritDoc}
     */
    public void handleReturnValue(MessageContext messageContext, MethodParameter returnType, Object returnValue)
            throws JAXBException {
        try {
            returnValueDelegate.handleReturnValue(messageContext, returnType, returnValue);
        } catch (Exception e) {
            if (e instanceof JAXBException) {
                throw (JAXBException) e;
            }
            throw new JAXBException(e);
        }
    }

    /**
     * Converts the given source to a byte array input stream.
     * 
     * @param source
     *            the source to convert
     * @return the input stream
     * @throws javax.xml.transform.TransformerException
     *             in case of transformation errors
     */
    protected ByteArrayInputStream convertToByteArrayInputStream(Source source) throws TransformerException {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        transform(source, new StreamResult(bos));
        return new ByteArrayInputStream(bos.toByteArray());
    }

}
