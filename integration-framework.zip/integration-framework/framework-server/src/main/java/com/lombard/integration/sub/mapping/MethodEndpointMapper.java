package com.lombard.integration.sub.mapping;

import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.core.annotation.AnnotationUtils;

import com.lombard.integration.fwk.notification.annotation.BusinessKey;
import com.lombard.integration.fwk.notification.annotation.BusinessKeys;

/**
 * Implement a default behaviour based on method metadata.
 * 
 * @author wvandenberghe
 * 
 */
public class MethodEndpointMapper extends AbstractEndpointMapper {

    private static final Log logger = LogFactory.getLog(MethodEndpointMapper.class);

    private ConcurrentMap < String, EndpointMapping > endpointMappings =
            new ConcurrentHashMap < String, EndpointMapping >();

    private EndpointMapping defaultEndpointMapping;

    private Class < ? > consumedType;

    private SelectorExtractor selectorExtractor;

    /**
     * 
     * @param consumedType
     */
    public void setConsumedType(Class < ? > consumedType) {
        this.consumedType = consumedType;
    }

    /**
     * 
     * @param selectorExtractor
     */
    public void setSelectorExtractor(SelectorExtractor selectorExtractor) {
        this.selectorExtractor = selectorExtractor;
    }

    /**
     * {@inheritDoc}
     */
    public EndpointMapping getEndpointMapping(String flowName) {
        if (flowName == null) {
            throw new IllegalArgumentException("'flowName' must not be null");
        }

        EndpointMapping em = endpointMappings.get(flowName);

        return (em == null) ? defaultEndpointMapping : em;
    }

    @Override
    protected void registerEndpointMethodMapping(Object endpoint, Method method) {
        Map < String, String > businessKeyList = getBusinessKeys(endpoint, method);

        String selector = selectorExtractor.extract(method);
        Class < ? >[] parameters = method.getParameterTypes();
        // case of business context is filled
        if (selector != null) {
            EndpointMapping em = new DefaultEndpointMapping(businessKeyList, endpoint, method, parameters[0]);

            EndpointMapping previousEm = endpointMappings.putIfAbsent(selector, em);

            if (previousEm != null) {
                throw new IllegalStateException("Conflict detected between endpoints [" + previousEm.toString()
                        + "] and  [" + em.toString() + "]");
            }

            if (logger.isInfoEnabled()) {
                logger.info("Endpoint registered " + em.toString());
            }

            return;
        }

        // case of default endpoint
        if (parameters.length == 1 && consumedType.isAssignableFrom(parameters[0])) {
            EndpointMapping newDefaultEm =
                    new DefaultEndpointMapping(businessKeyList, endpoint, method, consumedType);
            if (defaultEndpointMapping != null) {
                throw new IllegalStateException("Conflict detected between endpoints ["
                        + defaultEndpointMapping.toString() + "] and [" + newDefaultEm.toString() + "]");
            }
            defaultEndpointMapping = newDefaultEm;

            if (logger.isInfoEnabled()) {
                logger.info("Default endpoint registered " + defaultEndpointMapping.toString());
            }

            return;
        }

        if (logger.isDebugEnabled()) {
            logger.debug("Endpoint not registered " + endpoint.getClass().getSimpleName() + "." + method.getName());
        }

    }

    /**
     * Get selector from the method
     * 
     * @param method
     *            method from which selector must be extracted
     * @return selector
     */
    // protected abstract String getSelector(Method method);

    /**
     * 
     * @param endpoint
     * @param method
     * @return
     */
    private Map < String, String > getBusinessKeys(Object endpoint, Method method) {
        final Map < String, String > businessKeyList = new HashMap < String, String >();
        final BusinessKeys businessKeys = AnnotationUtils.findAnnotation(method, BusinessKeys.class);
        if (businessKeys != null) {
            for (BusinessKey businessKey : businessKeys.value()) {
                if (businessKey.name().trim().length() == 0) {
                    throw new IllegalArgumentException("Property 'name' of BusinessKey on "
                            + endpoint.getClass().getSimpleName() + "." + method.getName());
                }
                if (businessKey.expression().trim().length() == 0) {
                    throw new IllegalArgumentException("Property 'expression' of BusinessKey on "
                            + endpoint.getClass().getSimpleName() + "." + method.getName());
                }

                if (logger.isDebugEnabled()) {
                    logger.debug("Business key [" + businessKey.name() + ":" + businessKey.expression()
                            + "] registered");
                }

                businessKeyList.put(businessKey.name(), businessKey.expression());
            }
        }

        // in case there is one annotation
        final BusinessKey businessKey = AnnotationUtils.findAnnotation(method, BusinessKey.class);
        if (businessKey != null) {
            if (logger.isDebugEnabled()) {
                logger.debug("Business key [" + businessKey.name() + ":" + businessKey.expression() + "] registered");
            }
            businessKeyList.put(businessKey.name(), businessKey.expression());
        }

        return businessKeyList;
    }

    /**
     * Convenient interface to extract selector from method and its potential annotations.
     * 
     * @author wvandenberghe
     * 
     */
    public interface SelectorExtractor {

        /**
         * Extract selector as String from method
         * 
         * @param method
         * @return
         */
        String extract(Method method);
    }

}
