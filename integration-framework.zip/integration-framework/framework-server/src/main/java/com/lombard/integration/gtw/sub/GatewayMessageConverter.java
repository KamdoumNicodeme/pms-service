package com.lombard.integration.gtw.sub;

import javax.jms.JMSException;
import javax.jms.Message;

import org.springframework.jms.support.converter.MessageConversionException;
import org.springframework.jms.support.converter.SimpleMessageConverter;
import org.springframework.remoting.support.RemoteInvocation;

/**
 * Specialized converter to get the remote invocation targeted by this message.
 * 
 * @author wvandenberghe
 * 
 */
public class GatewayMessageConverter extends SimpleMessageConverter {

    private static final String GTW_SERVICE_METHOD_NAME = "processContent";

    /**
     * {@inheritDoc}
     */
    @Override
    public Object fromMessage(Message message) throws JMSException, MessageConversionException {

        Object content = super.fromMessage(message);

        RemoteInvocation remoteInvocation = new RemoteInvocation(GTW_SERVICE_METHOD_NAME, new Class[] { String.class }, new Object[] { content });

        return remoteInvocation;
    }
}
