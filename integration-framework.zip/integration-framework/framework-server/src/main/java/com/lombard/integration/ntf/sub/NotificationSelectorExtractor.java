package com.lombard.integration.ntf.sub;

import java.lang.reflect.Method;

import org.springframework.core.annotation.AnnotationUtils;

import com.lombard.csm.BusinessContext;
import com.lombard.integration.fwk.notification.annotation.Selector;
import com.lombard.integration.sub.mapping.MethodEndpointMapper.SelectorExtractor;

/**
 * 
 * @author wvandenberghe
 * 
 */
public class NotificationSelectorExtractor implements SelectorExtractor {

    /**
     * {@inheritDoc}
     */
    public String extract(Method method) {
        final Class < ? >[] parameters = method.getParameterTypes();

        // get the business context type
        final Selector selector = AnnotationUtils.findAnnotation(method, Selector.class);
        if (selector != null) {
            return selector.businessContext().getSimpleName();
        } else {
            if (parameters.length == 1 && BusinessContext.class.isAssignableFrom(parameters[0])) {
                return parameters[0].getSimpleName();
            }
        }

        return null;
    }

}
