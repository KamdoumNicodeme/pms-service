package com.lombard.integration.sub.support;

import java.lang.annotation.Annotation;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.BeanPostProcessor;

import com.lombard.integration.sub.mapping.EndpointMapper;

/**
 * Post processor able to register metadata for routing and tracing based on a provided marker annotation.
 * 
 * @author wvandenberghe
 */
public class SubscriberBeanPostProcessor implements BeanPostProcessor {

    private static final Log logger = LogFactory.getLog(SubscriberBeanPostProcessor.class);

    private EndpointMapper endpointMapper;

    private Class < ? extends Annotation > annotationType;

    /**
     * Set endpoint mapper.
     * 
     * @param endpointMapper
     */
    public void setEndpointMapper(EndpointMapper endpointMapper) {
        this.endpointMapper = endpointMapper;
    }

    /**
     * Set the annotation on which analysis should be done
     * 
     * @param annotationType
     *            marker annotation type
     */
    public void setAnnotationType(Class < ? extends Annotation > annotationType) {
        this.annotationType = annotationType;
    }

    /**
     * {@inheritDoc}
     */
    public Object postProcessBeforeInitialization(Object bean, String beanName) throws BeansException {
        if (bean.getClass().isAnnotationPresent(annotationType)) {
            Object[] endpoints = endpointMapper.getEndpoints();

            Object[] newEndpoints = null;
            if (endpoints != null) {
                newEndpoints = new Object[endpoints.length + 1];
                System.arraycopy(endpoints, 0, newEndpoints, 0, endpoints.length);
            } else {
                newEndpoints = new Object[1];
            }

            newEndpoints[newEndpoints.length - 1] = bean;

            if (logger.isInfoEnabled()) {
                logger.info("Subscriber registered " + bean.getClass().getName());
            }
            endpointMapper.setEndpoints(newEndpoints);
        }

        return bean;
    }

    /**
     * {@inheritDoc}
     */
    public Object postProcessAfterInitialization(Object bean, String beanName) throws BeansException {
        return bean;
    }

}
