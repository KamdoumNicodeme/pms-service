package com.lombard.integration.sub;

import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.Queue;
import javax.jms.TextMessage;
import javax.jms.Topic;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.jms.support.JmsUtils;

import com.lombard.cdm.IdType;
import com.lombard.integration.sub.InvocationContextFactory.InvocationContext;

/**
 * Invocation based on subscription for JMS message.
 * 
 * @author wvandenberghe
 * 
 * @param <T>
 *            type of the invocation context
 */
public abstract class InvocationContextDelegate< T > implements InvocationContext < T > {

    private static final String INITIATOR_NODE = "[I-i][N-n][I-i][T-t][I-i][A-a][T-t][O-o][R-r][N-n][O-o][D-d][E-e]";

    private static final String INITIATOR_NAME = "[I-i][N-n][I-i][T-t][I-i][A-a][T-t][O-o][R-r][N-n][A-a][M-m][E-e]";

    private static final String CORRELATION_ID = "[C-c][O-o][R-r][R-r][E-e][L-l][A-a][T-t][I-i][O-o][N-n][I-i][D-d]";

    private static final Log logger = LogFactory.getLog(InvocationContextDelegate.class);

    private final Message message;

    private final T invokedOn;

    private Map < String, String > properties;

    /**
     * Build an invocation from a JMS message
     * 
     * @param message
     *            JMS message
     */
    public InvocationContextDelegate(Message message, T invokedOn) {
        if (!(message instanceof TextMessage)) {
            throw new IllegalArgumentException("'Message' must be an instance of 'TextMessage'");
        }

        this.message = message;
        this.invokedOn = invokedOn;

        initInvocation();
    }

    private void initInvocation() {
        properties = new HashMap < String, String >();
        try {
            @SuppressWarnings("unchecked")
            Enumeration < String > names = message.getPropertyNames();
            while (names.hasMoreElements()) {
                String name = names.nextElement();
                if (!name.matches("[J-j][M-m][S-s]")) {
                    String value = getProperty(name);
                    if (value != null && value.trim().length() > 0) {
                        properties.put(name, value);
                    }
                }
            }
        } catch (JMSException e) {
            logger.error(JmsUtils.buildExceptionMessage(e));
        }
    }

    /**
     * {@inheritDoc}
     */
    public final T getInvokedOn() {
        return (T) invokedOn;
    }

    /**
     * Get destination name
     * 
     * @return queue name if destination is a queue, topic name if destination is a topic. Return null if an
     *         exception is thrown.
     */
    public String getDestinationName() {
        try {
            final Destination destination = message.getJMSDestination();
            return (destination instanceof Queue) ? ((Queue) destination).getQueueName() : ((Topic) destination)
                    .getTopicName();
        } catch (JMSException e) {
            return null;
        }
    }

    /**
     * Get property value
     * 
     * @param property
     *            property name
     * @return property value
     */
    protected String getProperty(String property) {
        try {
            return message.getStringProperty(property);
        } catch (JMSException e) {
            return null;
        }
    }

    /**
     * {@inheritDoc}
     */
    public String getPayload() {
        try {
            return (message instanceof TextMessage) ? ((TextMessage) message).getText() : null;
        } catch (JMSException e) {
            return null;
        }
    }

    /**
     * {@inheritDoc}
     */
    public Map < String, String > getProperties() {
        return properties;
    }

    /**
     * {@inheritDoc}
     */
    public String getCorrelationId() {
        for (Entry < String, String > entry : getProperties().entrySet()) {
            if (entry.getKey().matches(CORRELATION_ID)) {
                return entry.getValue();
            }
        }
        return null;
    }

    /**
     * {@inheritDoc}
     */
    public IdType getInitiatorName() {
        for (Entry < String, String > entry : getProperties().entrySet()) {
            if (entry.getKey().matches(INITIATOR_NAME)) {
                return IdType.valueOf(entry.getValue());
            }
        }
        return null;
    }

    /**
     * {@inheritDoc}
     */
    public String getInitiatorNode() {
        for (Entry < String, String > entry : getProperties().entrySet()) {
            if (entry.getKey().matches(INITIATOR_NODE)) {
                return entry.getValue();
            }
        }
        return null;
    }

}
