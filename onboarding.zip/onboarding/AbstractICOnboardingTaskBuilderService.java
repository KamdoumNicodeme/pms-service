package com.lombardinternational.casemanagement.service.decision.domain.service.tasklist.onboarding;

public abstract class AbstractICOnboardingTaskBuilderService extends AbstractOnboardingTaskBuilderService {

    @Override
    public String getTaskName() {

        return "IC-Asset";
    }

    @Override
    public String getTaskDynamicScreenId() {

        return "IC_NEW_BUSINESS";
    }

    @Override
    public int getRulePriority() {

        return 10;
    }
}
