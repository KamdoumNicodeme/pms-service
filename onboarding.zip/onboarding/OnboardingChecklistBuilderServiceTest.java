package com.lombardinternational.casemanagement.service.decision.domain.service.checklist.onboarding;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Group;
import com.lombardinternational.casemanagement.service.decision.domain.service.checklist.onboarding.enrichment.ExpectedPremiumInEurEnrichmentService;
import com.lombardinternational.casemanagement.service.decision.domain.service.checklist.onboarding.group.OnboardingCaseRiskGroupBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.checklist.onboarding.group.OnboardingDueDiligenceGroupBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.checklist.onboarding.group.OnboardingGeneralDetailsGroupBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.checklist.onboarding.group.OnboardingIntermediationGroupBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.checklist.onboarding.group.OnboardingLifeCoverGroupBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.checklist.onboarding.group.OnboardingPricingApprovalGroupBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.checklist.onboarding.group.OnboardingSignatureGroupBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.checklist.onboarding.group.OnboardingSignoffsGroupBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.checklist.onboarding.group.OnboardingThirdPartyGroupBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.checklist.onboarding.group.OnboardingTransactionDetailsGroupBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.utils.ChecklistUtils;
import com.lombardinternational.casemanagement.service.decision.domain.utils.PolicyBuilderServiceHelper;
import com.lombardinternational.casemanagement.service.decision.domain.utils.ScreenDescriptionBuilderServiceHelper;
import com.lombardinternational.casemanagement.service.decision.domain.utils.TransactionBuilderServiceHelper;
import com.lombardinternational.casemanagement.service.decision.domain.utils.WebFormBuilderServiceHelper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.OnboardingChecklistIds.CHECKLIST_TAB;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
class OnboardingChecklistBuilderServiceTest {

    @InjectMocks
    private OnboardingChecklistBuilderService builderService;

    @Mock
    private OnboardingGeneralDetailsGroupBuilderService generalDetailsGroupBuilderService;
    @Mock
    private OnboardingLifeCoverGroupBuilderService lifeCoverGroupBuilderService;
    @Mock
    private OnboardingIntermediationGroupBuilderService intermediationGroupBuilderService;
    @Mock
    private OnboardingSignatureGroupBuilderService signatureGroupBuilderService;
    @Mock
    private OnboardingPricingApprovalGroupBuilderService pricingApprovalGroupBuilderService;
    @Mock
    private OnboardingSignoffsGroupBuilderService signoffsGroupBuilderService;
    @Mock
    private OnboardingDueDiligenceGroupBuilderService dueDiligenceGroupBuilderService;
    @Mock
    private OnboardingTransactionDetailsGroupBuilderService transactionDetailsGroupBuilderService;
    @Mock
    private OnboardingThirdPartyGroupBuilderService thirdPartyGroupBuilderService;
    @Mock
    private OnboardingCaseRiskGroupBuilderService caseRiskGroupBuilderService;
    @Mock
    private ExpectedPremiumInEurEnrichmentService expectedPremiumInEurEnrichmentService;

    @BeforeEach
    void initTest() {

        Group.resetGroupId();
    }

    @Test
    void buildOnboardingChecklistOK() {

        var policy = PolicyBuilderServiceHelper.createPolicy();
        var webForm = WebFormBuilderServiceHelper.createWebForm();
        var transaction = TransactionBuilderServiceHelper.createTransaction();
        var screenDescription = ScreenDescriptionBuilderServiceHelper.createChecklistScreenDescription();

        var result = builderService.buildChecklist(webForm, screenDescription, policy, transaction);

        var checklist = ChecklistUtils.getTabInScreenDescription(result, CHECKLIST_TAB);
        assertNotNull(checklist);
        assertEquals("FormTab", checklist.getType());
        assertEquals("Checklist", checklist.getLabel());
        assertEquals(1, checklist.getOrder());
        verify(generalDetailsGroupBuilderService, times(1)).buildGroup(any(), any(), any(), any(), any(), any());
        verify(lifeCoverGroupBuilderService, times(1)).buildGroup(any(), any(), any(), any(), any(), any());
        verify(intermediationGroupBuilderService, times(1)).buildGroup(any(), any(), any(), any(), any(), any());
        verify(signatureGroupBuilderService, times(1)).buildGroup(any(), any(), any(), any(), any(), any());
        verify(pricingApprovalGroupBuilderService, times(1)).buildGroup(any(), any(), any(), any(), any(), any());
        verify(signoffsGroupBuilderService, times(1)).buildGroup(any(), any(), any(), any(), any(), any());
        verify(dueDiligenceGroupBuilderService, times(1)).buildGroup(any(), any(), any(), any(), any(), any());
        verify(transactionDetailsGroupBuilderService, times(1)).buildGroup(any(), any(), any(), any(), any(), any());
        verify(thirdPartyGroupBuilderService, times(1)).buildGroup(any(), any(), any(), any(), any(), any());
        verify(caseRiskGroupBuilderService, times(1)).buildGroup(any(), any(), any(), any(), any(), any());
        verify(expectedPremiumInEurEnrichmentService, times(1)).enrich(result, webForm);
    }
}
