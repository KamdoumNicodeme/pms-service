package com.lombardinternational.casemanagement.service.decision.domain.service.tasklist.onboarding;

public abstract class AbstractUnquotedOnboardingTaskBuilderService extends AbstractOnboardingTaskBuilderService {

    @Override
    public String getTaskName() {

        return "Unquoted";
    }

    @Override
    public String getTaskDynamicScreenId() {

        return "UNQUOTED_NEW_BUSINESS";
    }

    @Override
    public int getRulePriority() {

        return 60;
    }

    @Override
    public int getMainTaskExpectedDurationSeconds() {

        return THIRTY_DAYS;
    }
}
