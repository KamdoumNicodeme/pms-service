package com.lombardinternational.casemanagement.service.decision.domain.service.checklist.onboarding;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Group;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Tab;
import com.lombardinternational.casemanagement.service.decision.domain.model.policy.Policy;
import com.lombardinternational.casemanagement.service.decision.domain.model.transaction.BusinessTransaction;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.utils.constants.OnboardingTransactionIds;
import com.lombardinternational.casemanagement.service.decision.domain.service.checklist.ChecklistBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.checklist.GroupBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.checklist.onboarding.group.OnboardingCaseRiskGroupBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.checklist.onboarding.group.OnboardingDueDiligenceGroupBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.checklist.onboarding.group.OnboardingGeneralDetailsGroupBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.checklist.onboarding.group.OnboardingIntermediationGroupBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.checklist.onboarding.group.OnboardingLifeCoverGroupBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.checklist.onboarding.group.OnboardingPricingApprovalGroupBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.checklist.onboarding.group.OnboardingSignatureGroupBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.checklist.onboarding.group.OnboardingSignoffsGroupBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.checklist.onboarding.group.OnboardingThirdPartyGroupBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.checklist.onboarding.group.OnboardingTransactionDetailsGroupBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.checklist.onboarding.enrichment.ExpectedPremiumInEurEnrichmentService;
import com.lombardinternational.casemanagement.service.decision.domain.utils.ChecklistUtils;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.OnboardingChecklistIds.CHECKLIST_TAB;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.RulesConstants.BLOCKED;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.RulesConstants.EXCEPTION;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.RulesConstants.HIGH;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.RulesConstants.MEDIUM;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.RulesConstants.PROHIBITED;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.RulesConstants.STANDARD;

@Service
@AllArgsConstructor
public class OnboardingChecklistBuilderService implements ChecklistBuilderService {
    private final OnboardingGeneralDetailsGroupBuilderService generalDetailsGroupBuilderService;
    private final OnboardingLifeCoverGroupBuilderService lifeCoverGroupBuilderService;
    private final OnboardingIntermediationGroupBuilderService intermediationGroupBuilderService;
    private final OnboardingSignatureGroupBuilderService signatureGroupBuilderService;
    private final OnboardingPricingApprovalGroupBuilderService pricingApprovalGroupBuilderService;
    private final OnboardingSignoffsGroupBuilderService signoffsGroupBuilderService;
    private final OnboardingDueDiligenceGroupBuilderService dueDiligenceGroupBuilderService;
    private final OnboardingTransactionDetailsGroupBuilderService transactionDetailsGroupBuilderService;
    private final OnboardingThirdPartyGroupBuilderService thirdPartyGroupBuilderService;
    private final OnboardingCaseRiskGroupBuilderService caseRiskGroupBuilderService;
    private final ExpectedPremiumInEurEnrichmentService expectedPremiumInEurEnrichmentService;

    @Override
    public ScreenDescription buildChecklist(final WebForm webForm, final ScreenDescription screenDescription, final Policy policy,
            final BusinessTransaction transaction) {
        final var checklistScreen = Optional.ofNullable(screenDescription)
                .orElseGet(() -> ScreenDescription.builder().screenId(OnboardingTransactionIds.CHECKLIST_SCREEN_ID).build());
        checklistScreen.setScreenId(OnboardingTransactionIds.CHECKLIST_SCREEN_ID);

        final var checklistTab = Optional.ofNullable(ChecklistUtils.getTabInScreenDescription(checklistScreen, CHECKLIST_TAB))
                .orElse(Tab.builder().tabId(CHECKLIST_TAB).order(1).type("FormTab").label("Checklist").build());
        checklistTab.setIsActive(true);
        checklistScreen.setTabs(Collections.singletonList(checklistTab));

        Group.resetGroupId();
        List<GroupBuilderService> groupBuilderServices = List.of(
                generalDetailsGroupBuilderService,
                lifeCoverGroupBuilderService,
                intermediationGroupBuilderService,
                signatureGroupBuilderService,
                pricingApprovalGroupBuilderService,
                signoffsGroupBuilderService,
                dueDiligenceGroupBuilderService,
                transactionDetailsGroupBuilderService,
                thirdPartyGroupBuilderService,
                caseRiskGroupBuilderService
        );
        Map<String,List<String>> overallCaseRisk = Map.of(PROHIBITED, new ArrayList<>(), HIGH, new ArrayList<>(), EXCEPTION, new ArrayList<>(),
                MEDIUM, new ArrayList<>(), STANDARD, new ArrayList<>(), BLOCKED, new ArrayList<>());
        groupBuilderServices.forEach(groupBuilderService -> groupBuilderService.buildGroup(webForm, checklistScreen, checklistTab, policy,
                transaction, overallCaseRisk));
        expectedPremiumInEurEnrichmentService.enrich(checklistScreen, webForm);
        return checklistScreen;
    }
}
