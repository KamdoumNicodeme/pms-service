package com.lombardinternational.casemanagement.service.decision.domain.service.checklist.onboarding.field;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.CheckBoxField;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.SelectInputField;
import com.lombardinternational.casemanagement.service.decision.domain.utils.FieldHelper;
import java.util.concurrent.atomic.AtomicInteger;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.OnboardingChecklistIds.*;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ReferenceConstants.PROVIDER_DOMAIN;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ReferenceConstants.SIGNATURE_DOMAIN;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
class OnboardingSignatureFieldsBuilderServiceTest extends OnboardingFieldsBuilderTestSupport {

    @InjectMocks
    private OnboardingSignatureFieldsBuilderService builderService;

    @Test
    void buildSignatureFieldsOK() {

        var group = group(SIGNATURE_GROUP);
        var testOrder = new AtomicInteger(1);

        builderService.buildField(webForm(), screenDescription(), group, policy(), transaction(), overallCaseRisk());

        assertEquals(6, group.getFields().size());
        FieldHelper.testSelectFieldValueAndIncr(SIGNATURE_TYPE, SelectInputField.class, group, null, testOrder, null, true, true, 3);
        FieldHelper.testSelectFieldValueAndIncr(PROVIDER, SelectInputField.class, group, null, testOrder, "true", false, true, 2);
        FieldHelper.testFieldValueAndIncr(EU_AUTHORISED_PROVIDER, CheckBoxField.class, group, null, testOrder,
                "(#SIGNATURE_TYPE# == \"ELECTRONIC\" || #SIGNATURE_TYPE# == \"MULTIPLE\") && #PROVIDER# == \"PARTNER_ESIGN_SERVICE\"",
                true, true);
        FieldHelper.testFieldValueAndIncr(CLIENT_IDENTIFICATION_VALIDATION, CheckBoxField.class, group, null, testOrder,
                "(#SIGNATURE_TYPE# == \"ELECTRONIC\" || #SIGNATURE_TYPE# == \"MULTIPLE\") && (#PROVIDER# == \"PARTNER_ESIGN_SERVICE\" || #PROVIDER# == \"INTERNAL_PROVIDER\")",
                true, true);
        FieldHelper.testFieldValueAndIncr(MULTIFACTOR_AUTHENTICATION, CheckBoxField.class, group, null, testOrder,
                "(#SIGNATURE_TYPE# == \"ELECTRONIC\" || #SIGNATURE_TYPE# == \"MULTIPLE\") && #PROVIDER# == \"PARTNER_ESIGN_SERVICE\"",
                true, true);
        FieldHelper.testFieldValueAndIncr(ORIGINAL_SIGNED_DOCUMENT_AUDIT_LOG_CMT, CheckBoxField.class, group, null, testOrder,
                "(#SIGNATURE_TYPE# == \"ELECTRONIC\" || #SIGNATURE_TYPE# == \"MULTIPLE\") && (#PROVIDER# == \"PARTNER_ESIGN_SERVICE\" || #PROVIDER# == \"INTERNAL_PROVIDER\")",
                true, true);
        assertEquals(6, testOrder.get() - 1);
        verify(referenceDataRepositoryService).getReferenceDataOptionsByDomain(SIGNATURE_DOMAIN);
        verify(referenceDataRepositoryService).getReferenceDataOptionsByDomain(PROVIDER_DOMAIN);
    }
}
