package com.lombardinternational.casemanagement.service.decision.domain.service.checklist.onboarding.field;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.NumberInputField;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.SelectInputField;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.TextAreaField;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.TextInputField;
import com.lombardinternational.casemanagement.service.decision.domain.utils.ChecklistUtils;
import com.lombardinternational.casemanagement.service.decision.domain.utils.FieldHelper;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.OnboardingChecklistIds.*;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ReferenceConstants.COUNTRY_DOMAIN;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ReferenceConstants.YES_NO_DOMAIN;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
class OnboardingTransactionDetailsFieldsBuilderServiceTest extends OnboardingFieldsBuilderTestSupport {

    @InjectMocks
    private OnboardingTransactionDetailsFieldsBuilderService builderService;

    @Test
    void buildTransactionDetailsFieldsOK() {

        var group = group(TRANSACTIONS_DETAILS_GROUP);

        builderService.buildField(webForm(), screenDescription(), group, policy(), transaction(), overallCaseRisk());

        assertEquals(27, group.getFields().size());
        FieldHelper.testSelectFieldValue(PREMIUM_WITH_ASSETS, SelectInputField.class, group, null, 1, null, false, true, 2);
        FieldHelper.testSelectFieldValue(PREMIUM_WITH_UNQ_ASSETS, SelectInputField.class, group, null, 2, null, false, false, 2);
        FieldHelper.testSelectFieldValue(IS_ROP_CASE, SelectInputField.class, group, null, 3, null, true, true, 2);
        FieldHelper.testFieldValue(INITIAL_PREM, NumberInputField.class, group, null, 4, "#IS_ROP_CASE# == \"YES\"", true, true);
        FieldHelper.testFieldValue(RATIONALE_FOR_INVESTMENT, TextAreaField.class, group, null, 22, null, false, true);
        FieldHelper.testSelectFieldValue(NUMBER_OF_ORIGINATING_ACCOUNTS, SelectInputField.class, group, null, 23, null, true, false, 0);
        FieldHelper.testFieldValue(NAME_OF_ORIGINATING_ACCOUNT_HOLDER, TextInputField.class, group, null, 24,
                "#NUMBER_OF_ORIGINATING_ACCOUNTS# >= $", true, false);
        FieldHelper.testSelectFieldValue(COUNTRY_OF_ORIGINATING_ACCOUNT, SelectInputField.class, group, null, 25,
                "#NUMBER_OF_ORIGINATING_ACCOUNTS# >= $", true, false, 3);
        FieldHelper.testFieldValue(BANK_NAME_OF_ORIGINATING_ACCOUNT, TextInputField.class, group, null, 26,
                "#NUMBER_OF_ORIGINATING_ACCOUNTS# >= $", true, false);
        FieldHelper.testFieldValue(ORIGINATING_BANK_COUNTRY_RISK, TextInputField.class, group, null, 27,
                "#NUMBER_OF_ORIGINATING_ACCOUNTS# >= 1", true, false);
        verify(referenceDataRepositoryService, org.mockito.Mockito.atLeastOnce()).getReferenceDataOptionsByDomain(YES_NO_DOMAIN);
        verify(referenceDataRepositoryService).getReferenceDataOptionsByDomainAndSelectedValue(COUNTRY_DOMAIN, null);
    }

    @Test
    void buildTransactionDetailsFieldsCreatesSuffixedOriginatingAccountFieldsWhenCountAlreadyExists() {

        var group = group(TRANSACTIONS_DETAILS_GROUP);
        group.getFields().add(SelectInputField.builder().fieldId(NUMBER_OF_ORIGINATING_ACCOUNTS).selectedValue("2").build());

        builderService.buildField(webForm(), screenDescription(), group, policy(), transaction(), overallCaseRisk());

        assertEquals(30, group.getFields().size());
        FieldHelper.testSelectFieldValue(NUMBER_OF_ORIGINATING_ACCOUNTS, SelectInputField.class, group, "2", 23, null, true, false, 1);
        FieldHelper.testFieldValue(NAME_OF_ORIGINATING_ACCOUNT_HOLDER + "_1", TextInputField.class, group, null, 24, null, true, false);
        FieldHelper.testSelectFieldValue(COUNTRY_OF_ORIGINATING_ACCOUNT + "_1", SelectInputField.class, group, null, 25, null, true, false, 3);
        FieldHelper.testFieldValue(BANK_NAME_OF_ORIGINATING_ACCOUNT + "_1", TextInputField.class, group, null, 26, null, true, false);
        FieldHelper.testFieldValue(NAME_OF_ORIGINATING_ACCOUNT_HOLDER + "_2", TextInputField.class, group, null, 27, null, true, false);
        FieldHelper.testSelectFieldValue(COUNTRY_OF_ORIGINATING_ACCOUNT + "_2", SelectInputField.class, group, null, 28, null, true, false, 3);
        FieldHelper.testFieldValue(BANK_NAME_OF_ORIGINATING_ACCOUNT + "_2", TextInputField.class, group, null, 29, null, true, false);
        FieldHelper.testFieldValue(ORIGINATING_BANK_COUNTRY_RISK, TextInputField.class, group, null, 30,
                "#NUMBER_OF_ORIGINATING_ACCOUNTS# >= 1", true, false);
        org.junit.jupiter.api.Assertions.assertNull(ChecklistUtils.getFieldInGroup(group, NAME_OF_ORIGINATING_ACCOUNT_HOLDER));
        org.junit.jupiter.api.Assertions.assertNull(ChecklistUtils.getFieldInGroup(group, COUNTRY_OF_ORIGINATING_ACCOUNT));
        org.junit.jupiter.api.Assertions.assertNull(ChecklistUtils.getFieldInGroup(group, BANK_NAME_OF_ORIGINATING_ACCOUNT));
    }
}
