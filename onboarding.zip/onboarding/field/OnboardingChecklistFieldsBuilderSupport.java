package com.lombardinternational.casemanagement.service.decision.domain.service.checklist.onboarding.field;

import com.lombardinternational.casemanagement.service.decision.domain.model.webform.BigDecimalWebFormField;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.BooleanWebFormField;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.CalendarWebFormField;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.TextWebFormField;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebFormField;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebFormGroup;
import com.lombardinternational.casemanagement.service.decision.domain.utils.WebformUtils;
import java.util.Collection;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Stream;

public abstract class OnboardingChecklistFieldsBuilderSupport {

    protected Optional<String> selectedValueFromWebForm(String fieldId, WebForm webForm) {
        if (fieldId == null || webForm == null || webForm.getGroups() == null) {
            return Optional.empty();
        }
        return Optional.ofNullable(WebformUtils.getFirstWebFormField(webForm, fieldId))
                .map(this::webFormFieldValue)
                .filter(value -> value != null && !value.isBlank() && !"N/A".equals(value));
    }

    protected Stream<String> webFormFieldIds(WebForm webForm) {
        return Optional.ofNullable(webForm)
                .map(WebForm::getGroups)
                .stream()
                .flatMap(Collection::stream)
                .flatMap(this::webFormFieldIds)
                .filter(Objects::nonNull);
    }

    private Stream<String> webFormFieldIds(WebFormGroup group) {
        if (group == null) {
            return Stream.empty();
        }
        var currentGroupFieldIds = Stream.of(group.getBigDecimalFields(), group.getBooleanFields(), group.getCalendarFields(), group.getTextFields())
                .filter(Objects::nonNull)
                .flatMap(Collection::stream)
                .map(WebFormField::getFieldId);
        var childGroupFieldIds = Optional.ofNullable(group.getGroups())
                .stream()
                .flatMap(Collection::stream)
                .flatMap(this::webFormFieldIds);
        return Stream.concat(currentGroupFieldIds, childGroupFieldIds);
    }

    private String webFormFieldValue(WebFormField field) {
        return switch (field) {
            case BooleanWebFormField booleanField -> booleanField.getValue() == null ? null : booleanField.getValue().toString();
            case BigDecimalWebFormField decimalField -> decimalField.getValue() == null ? null : decimalField.getValue().toPlainString();
            case CalendarWebFormField calendarField -> calendarField.getValue() == null ? null : calendarField.getValue().toString();
            case TextWebFormField textField -> textField.getValue();
            case null, default -> null;
        };
    }
}
