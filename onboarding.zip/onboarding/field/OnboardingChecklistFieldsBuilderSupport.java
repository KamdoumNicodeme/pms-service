package com.lombardinternational.casemanagement.service.decision.domain.service.checklist.onboarding.field;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.CheckBoxField;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Field;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Group;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.NumberInputField;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.SelectInputField;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.SelectInputFieldOption;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.TextAreaField;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.TextInputField;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.BigDecimalWebFormField;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.BooleanWebFormField;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.CalendarWebFormField;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.TextWebFormField;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebFormField;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebFormGroup;
import com.lombardinternational.casemanagement.service.decision.domain.utils.ChecklistUtils;
import com.lombardinternational.casemanagement.service.decision.domain.utils.WebformUtils;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Stream;

public abstract class OnboardingChecklistFieldsBuilderSupport {

    protected Field applyField(Group group, OnboardingFieldDefinition rule, WebForm webForm) {
        var field = field(group, rule.fieldId(), rule.kind());
        field.setIsActive(true);
        field.incrementOrder();
        field.setLabel(rule.label());
        field.setEnabled(rule.enabled());
        field.setMandatory(rule.mandatory());
        field.setDisplayIf(blankToNull(rule.displayIf()));
        field.setLabelBold(rule.labelBold());
        field.setSourceSystem(blankToNull(rule.sourceSystem()));
        applySelectedValue(field, rule, webForm);
        if (field instanceof SelectInputField selectInputField) {
            selectInputField.setOptions(parseOptions(rule.valueOptions()));
        }
        return field;
    }

    private Field field(Group group, String fieldId, FieldKind kind) {
        return switch (ChecklistUtils.getFieldInGroup(group, fieldId)) {
            case null -> {
                var field = switch (kind) {
                    case SELECT -> SelectInputField.builder().fieldId(fieldId).build();
                    case NUMBER -> NumberInputField.builder().fieldId(fieldId).build();
                    case TEXT_AREA -> TextAreaField.builder().fieldId(fieldId).build();
                    case CHECK_BOX -> CheckBoxField.builder().fieldId(fieldId).build();
                    case TEXT -> TextInputField.builder().fieldId(fieldId).build();
                };
                group.getFields().add(field);
                yield field;
            }
            case SelectInputField field when kind == FieldKind.SELECT -> field;
            case NumberInputField field when kind == FieldKind.NUMBER -> field;
            case TextAreaField field when kind == FieldKind.TEXT_AREA -> field;
            case CheckBoxField field when kind == FieldKind.CHECK_BOX -> field;
            case TextInputField field when kind == FieldKind.TEXT -> field;
            default -> throw new IllegalStateException("Field " + fieldId + " must be a " + kind.fieldClass().getSimpleName());
        };
    }

    private void applySelectedValue(Field field, OnboardingFieldDefinition rule, WebForm webForm) {
        if ("#forcedValue".equals(rule.valueOptions())) {
            selectedValueFromWebForm(rule.fieldId(), webForm).ifPresent(field::setSelectedValue);
            return;
        }
        if (field.getSelectedValue() == null) {
            selectedValueFromStaticValue(rule.valueOptions()).ifPresent(field::setSelectedValue);
        }
    }

    protected Optional<String> selectedValueFromWebForm(String fieldId, WebForm webForm) {
        if (fieldId == null || webForm == null || webForm.getGroups() == null) {
            return Optional.empty();
        }
        return Optional.ofNullable(WebformUtils.getFirstWebFormField(webForm, fieldId))
                .map(this::webFormFieldValue)
                .filter(value -> value != null && !value.isBlank() && !"N/A".equals(value));
    }

    protected Stream<String> webFormFieldIds(WebForm webForm) {
        return Optional.ofNullable(webForm)
                .map(WebForm::getGroups)
                .stream()
                .flatMap(Collection::stream)
                .flatMap(this::webFormFieldIds)
                .filter(Objects::nonNull);
    }

    private Stream<String> webFormFieldIds(WebFormGroup group) {
        if (group == null) {
            return Stream.empty();
        }
        var currentGroupFieldIds = Stream.of(group.getBigDecimalFields(), group.getBooleanFields(), group.getCalendarFields(), group.getTextFields())
                .filter(Objects::nonNull)
                .flatMap(Collection::stream)
                .map(WebFormField::getFieldId);
        var childGroupFieldIds = Optional.ofNullable(group.getGroups())
                .stream()
                .flatMap(Collection::stream)
                .flatMap(this::webFormFieldIds);
        return Stream.concat(currentGroupFieldIds, childGroupFieldIds);
    }

    private String webFormFieldValue(WebFormField field) {
        return switch (field) {
            case BooleanWebFormField booleanField -> booleanField.getValue() == null ? null : booleanField.getValue().toString();
            case BigDecimalWebFormField decimalField -> decimalField.getValue() == null ? null : decimalField.getValue().toPlainString();
            case CalendarWebFormField calendarField -> calendarField.getValue() == null ? null : calendarField.getValue().toString();
            case TextWebFormField textField -> textField.getValue();
            case null, default -> null;
        };
    }

    private Optional<String> selectedValueFromStaticValue(String valueOptions) {
        if (valueOptions == null || valueOptions.isBlank() || valueOptions.startsWith("#") || looksLikeOptionList(valueOptions)
                || valueOptions.endsWith("String")) {
            return Optional.empty();
        }
        return Optional.of(valueOptions);
    }

    private List<SelectInputFieldOption> parseOptions(String valueOptions) {
        if (valueOptions == null || valueOptions.isBlank() || valueOptions.startsWith("#") || valueOptions.endsWith("String")
                || !looksLikeOptionList(valueOptions)) {
            return List.of();
        }
        List<SelectInputFieldOption> options = new ArrayList<>();
        for (String item : valueOptions.split(";")) {
            if (item.isBlank()) {
                continue;
            }
            String[] parts = item.split("\u00ac", 2);
            String key = parts[0].trim();
            String value = parts.length > 1 ? parts[1].trim() : key;
            options.add(new SelectInputFieldOption(key, value));
        }
        return options;
    }

    private boolean looksLikeOptionList(String valueOptions) {
        return valueOptions.contains(";") || valueOptions.contains("\u00ac");
    }

    private String blankToNull(String value) {
        return value == null || value.isBlank() ? null : value;
    }

    protected enum FieldKind {
        SELECT(SelectInputField.class),
        NUMBER(NumberInputField.class),
        TEXT(TextInputField.class),
        TEXT_AREA(TextAreaField.class),
        CHECK_BOX(CheckBoxField.class);

        private final Class<? extends Field> fieldClass;

        FieldKind(Class<? extends Field> fieldClass) {
            this.fieldClass = fieldClass;
        }

        Class<? extends Field> fieldClass() {
            return fieldClass;
        }
    }

    protected record OnboardingFieldDefinition(String fieldId, FieldKind kind, String label, boolean enabled, boolean mandatory,
                               String valueOptions, String displayIf, boolean labelBold, String sourceSystem, boolean repeatable) {
    }
}
