package com.lombardinternational.casemanagement.service.decision.domain.service.checklist.onboarding.field;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Field;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Group;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.NumberInputField;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.policy.Policy;
import com.lombardinternational.casemanagement.service.decision.domain.model.transaction.BusinessTransaction;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.SelectInputField;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.TextAreaField;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.TextInputField;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.checklist.FieldBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.checklist.onboarding.reference.OnboardingReferenceData;
import com.lombardinternational.casemanagement.service.decision.domain.utils.ChecklistUtils;
import org.springframework.stereotype.Service;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.OnboardingChecklistIds.*;

import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.OptionalInt;
import java.util.stream.IntStream;
import java.util.stream.Stream;

@Service
public class OnboardingTransactionDetailsFieldsBuilderService extends OnboardingChecklistFieldsBuilderSupport implements FieldBuilderService {
    private static final String SOURCE_CLASS = "From CLASS";
    private static final String SOURCE_CONNECT = "From Connect";
    private static final String YES = "YES";

    @Override
    public void buildField(final WebForm webForm, final ScreenDescription screenDescription, final Group group, final Policy policy, final BusinessTransaction transaction, final Map<String,List<String>> overallCaseRisk) {
        Field.resetFieldId();

        evaluatePremiumWithAssets(group, webForm);
        evaluatePremiumWithUnquotedAssets(group, webForm);
        evaluateIsRopCase(group, webForm);
        evaluateInitialPremium(group, webForm);
        evaluateInvestedInIlf(group, webForm);
        evaluateExistingIlf(group, webForm);
        evaluateIlfMnemonic(group, webForm);
        evaluateIsDealing(group, webForm);
        evaluatePaymentThirdParty(group, webForm);
        evaluatePayerInSanctionList(group, webForm);
        evaluateNegativeFindingPayers(group, webForm);
        evaluatePayerCorporateEntity(group, webForm);
        evaluatePayerNotLocated(group, webForm);
        evaluateEvidenceLegalEntity(group, webForm);
        evaluateCloseToEbo(group, webForm);
        evaluateBankNotInResidence(group, webForm);
        evaluateEconomicJustification(group, webForm);
        evaluateEvidenceTaxDeclared(group, webForm);
        evaluateRefusedAdditionalInfo(group, webForm);
        evaluatePremiumReceivedDifferentThanExpected(group, webForm);
        evaluateSameAsDisclosed(group, webForm);
        evaluateRationaleForInvestment(group, webForm);
        evaluateOriginatingAccounts(group, webForm);

    }

    private void evaluatePremiumWithAssets(Group group, WebForm webForm) {
        var field = selectField(group, PREMIUM_WITH_ASSETS);
        apply(field, new FieldAttributes("Premium with assets?", true, false, null, false, null), webForm);
        field.setOptions(OnboardingReferenceData.yesNoOptions());
    }

    private void evaluatePremiumWithUnquotedAssets(Group group, WebForm webForm) {
        var field = selectField(group, PREMIUM_WITH_UNQ_ASSETS);
        apply(field, new FieldAttributes("Premium with unquoted assets?", false, false, null, false, SOURCE_CONNECT),
                webForm);
        field.setOptions(OnboardingReferenceData.selectedOnly(field.getSelectedValue()));
    }

    private void evaluateIsRopCase(Group group, WebForm webForm) {
        var field = selectField(group, IS_ROP_CASE);
        apply(field, new FieldAttributes("ROP Case ?", true, true, null, false, null), webForm);
        field.setOptions(OnboardingReferenceData.yesNoOptions());
    }

    private void evaluateInitialPremium(Group group, WebForm webForm) {
        var field = numberField(group, INITIAL_PREM);
        apply(field, new FieldAttributes("Initial premium (in policy currency)", true, true,
                selectedEquals(IS_ROP_CASE, YES), false, null), webForm);
    }

    private void evaluateInvestedInIlf(Group group, WebForm webForm) {
        var field = selectField(group, INVESTED_IN_ILF);
        apply(field, new FieldAttributes("Will it be reinvested in an ILF?", true, true, null, false, null),
                webForm);
        field.setOptions(OnboardingReferenceData.yesNoOptions());
    }

    private void evaluateExistingIlf(Group group, WebForm webForm) {
        var field = selectField(group, EXISTING_ILF);
        apply(field, new FieldAttributes("Is it an existing ILF?", true, true, selectedEquals(INVESTED_IN_ILF, YES), false, null),
                webForm);
        field.setOptions(OnboardingReferenceData.yesNoOptions());
    }

    private void evaluateIlfMnemonic(Group group, WebForm webForm) {
        var field = textField(group, ILF_MNEMONIC);
        apply(field, new FieldAttributes("ILF Mnemonic", true, false, selectedEquals(EXISTING_ILF, YES), false, null),
                webForm);
    }

    private void evaluateIsDealing(Group group, WebForm webForm) {
        var field = selectField(group, IS_DEALING);
        apply(field, new FieldAttributes("Is dealing requested", true, true, null, false, null), webForm);
        field.setOptions(OnboardingReferenceData.yesNoOptions());
    }

    private void evaluatePaymentThirdParty(Group group, WebForm webForm) {
        var field = selectField(group, PAYMENT_THIRD_PARTY);
        apply(field, new FieldAttributes("Payment from a third party payer", false, true, null, true, SOURCE_CLASS),
                webForm);
        field.setOptions(OnboardingReferenceData.selectedOnly(field.getSelectedValue()));
    }

    private void evaluatePayerInSanctionList(Group group, WebForm webForm) {
        var field = selectField(group, PAYER_IN_SANCTION_LIST);
        apply(field, new FieldAttributes("Is one of the payers designated on a sanctions list?", true, true,
                thirdPartyPayerDisplayIf(), false, null), webForm);
        field.setOptions(OnboardingReferenceData.yesNoOptions());
    }

    private void evaluateNegativeFindingPayers(Group group, WebForm webForm) {
        var field = selectField(group, NEGATIVE_FINDING_PAYERS);
        apply(field, new FieldAttributes("Negative press finding / Worldcheck match (on any of the payers)?", true, true,
                thirdPartyPayerDisplayIf(), false, null), webForm);
        field.setOptions(OnboardingReferenceData.yesNoOptions());
    }

    private void evaluatePayerCorporateEntity(Group group, WebForm webForm) {
        var field = selectField(group, PAYER_CORPORATE_ENTITY);
        apply(field, new FieldAttributes("Is the payer a Corporate entity where the PH/EBO is the sole shareholder?", true, true,
                thirdPartyPayerDisplayIf(), false, null), webForm);
        field.setOptions(OnboardingReferenceData.yesNoOptions());
    }

    private void evaluatePayerNotLocated(Group group, WebForm webForm) {
        var field = selectField(group, PAYER_NOT_LOCATED);
        apply(field, new FieldAttributes("Is the 3rd party payer a legal entity located in a country which is not the tax country of residence "
                        + "or place of regular economic or professional activities/interests of the PH/EBO?",
                true, true, thirdPartyPayerDisplayIf(), false, null), webForm);
        field.setOptions(OnboardingReferenceData.yesNoOptions());
    }

    private void evaluateEvidenceLegalEntity(Group group, WebForm webForm) {
        var field = selectField(group, EVIDENCE_LEGAL_ENTITY);
        apply(field, new FieldAttributes("Did you collect supporting evidence that the legal entity is known by the tax authorities of the country "
                        + "of residence of the PH/EBO or could the legal entity  demonstrate that its establishment complies "
                        + "with the legal provisions of the country of residence of the PH/EBO?",
                true, true, selectedEquals(PAYER_NOT_LOCATED, YES), false, null), webForm);
        field.setOptions(OnboardingReferenceData.yesNoOptions());
    }

    private void evaluateCloseToEbo(Group group, WebForm webForm) {
        var field = selectField(group, CLOSE_TO_EBO);
        apply(field, new FieldAttributes("In case of any additional documentation collected to corroborate the tax conformity of the funds "
                        + "(e.g. annual income tax return, the regularisation documentation or memo from the tax lawyer "
                        + "of the PH/EBO), is this  supporting documentation issued by a person who is close to the PH/EBO "
                        + "and leaving room for doubt due to the potential conflict of interest?",
                true, true, null, false, null), webForm);
        field.setOptions(OnboardingReferenceData.yesNoOptions());
    }

    private void evaluateBankNotInResidence(Group group, WebForm webForm) {
        var field = selectField(group, BANK_NOT_IN_RESIDENCE);
        apply(field, new FieldAttributes("Are the funds paid from a bank account located in a country which is not the tax country of residence "
                        + "of the PH(s)/EBO(s)?",
                true, true, null, false, null), webForm);
        field.setOptions(OnboardingReferenceData.yesNoOptions());
    }

    private void evaluateEconomicJustification(Group group, WebForm webForm) {
        var field = selectField(group, ECONOMIC_JUSTIF);
        apply(field, new FieldAttributes("Is there an obvious economic justification (e.g. the PH/EBO lived in that jurisdiction, worked and/or "
                        + "works in that jurisdiction, funds were generated in that jurisdiction)?",
                true, true, selectedEquals(BANK_NOT_IN_RESIDENCE, YES), false, null), webForm);
        field.setOptions(OnboardingReferenceData.yesNoOptions());
    }

    private void evaluateEvidenceTaxDeclared(Group group, WebForm webForm) {
        var field = selectField(group, EVIDENCE_TAX_DECLARED);
        apply(field, new FieldAttributes("Did you collect supporting evidence that the bank account is  known by the tax authorities of the country "
                        + "of residence of the PH/EBO or that the funds have been tax declared (e.g. annual income tax , "
                        + "return regularisation documentation)?",
                true, true, selectedEquals(BANK_NOT_IN_RESIDENCE, YES) + " && " + selectedEquals(ECONOMIC_JUSTIF, "NO"),
                false, null), webForm);
        field.setOptions(OnboardingReferenceData.yesNoOptions());
    }

    private void evaluateRefusedAdditionalInfo(Group group, WebForm webForm) {
        var field = selectField(group, REFUSED_ADDITIONAL_INFO);
        apply(field, new FieldAttributes("Did the PH/EBO refuse to provide this additional supporting documentation?", true, true,
                selectedEquals(BANK_NOT_IN_RESIDENCE, YES) + " && " + selectedEquals(ECONOMIC_JUSTIF, "NO") + " && "
                        + selectedEquals(EVIDENCE_TAX_DECLARED, "NO"),
                false, null), webForm);
        field.setOptions(OnboardingReferenceData.yesNoOptions());
    }

    private void evaluatePremiumReceivedDifferentThanExpected(Group group, WebForm webForm) {
        var field = selectField(group, PREMIUM_RECEIVED_DIFFERENT_EXPECTED);
        apply(field, new FieldAttributes("Is the premium received different than expected one (higher amount or different payment details)?",
                true, true, null, false, null), webForm);
        field.setOptions(OnboardingReferenceData.yesNoOptions());
    }

    private void evaluateSameAsDisclosed(Group group, WebForm webForm) {
        var field = selectField(group, SAME_AS_DISCLOSED);
        apply(field, new FieldAttributes("Is the origin of the funds or additional funds and/or the payment details the same as disclosed in the KYC form?",
                true, true, selectedEquals(PREMIUM_RECEIVED_DIFFERENT_EXPECTED, YES), false, null), webForm);
        field.setOptions(OnboardingReferenceData.yesNoOptions());
    }

    private void evaluateRationaleForInvestment(Group group, WebForm webForm) {
        var field = textAreaField(group, RATIONALE_FOR_INVESTMENT);
        apply(field, new FieldAttributes("Rationale for investment", true, false, null, false, null), webForm);
    }

    private void evaluateOriginatingAccounts(Group group, WebForm webForm) {
        var accountCount = originatingAccountCount(group, webForm);
        evaluateNumberOfOriginatingAccounts(group, webForm, accountCount);

        if (accountCount <= 0) {
            evaluateOriginatingAccountTemplateFields(group, webForm);
        } else {
            IntStream.rangeClosed(1, accountCount)
                    .forEach(position -> evaluateOriginatingAccountFields(group, webForm, position));
        }

        evaluateOriginatingBankCountryRisk(group, webForm);
    }

    private void evaluateNumberOfOriginatingAccounts(Group group, WebForm webForm, int accountCount) {
        var field = selectField(group, NUMBER_OF_ORIGINATING_ACCOUNTS);
        apply(field, new FieldAttributes("Number of originating accounts", false, true, null, false, null), webForm);
        if ((field.getSelectedValue() == null || field.getSelectedValue().isBlank()) && accountCount > 0) {
            field.setSelectedValue(Integer.toString(accountCount));
        }
        field.setOptions(OnboardingReferenceData.selectedOnly(field.getSelectedValue()));
    }

    private void evaluateOriginatingAccountTemplateFields(Group group, WebForm webForm) {
        var holder = textField(group, NAME_OF_ORIGINATING_ACCOUNT_HOLDER);
        apply(holder, new FieldAttributes("Account holder ID", false, true,
                originatingAccountTemplateDisplayIf(), false, null), webForm);
        holder.setMultiple(true);

        var country = selectField(group, COUNTRY_OF_ORIGINATING_ACCOUNT);
        apply(country, new FieldAttributes("Country of the originating bank", false, true,
                originatingAccountTemplateDisplayIf(), false, null), webForm);
        country.setMultiple(true);
        country.setOptions(OnboardingReferenceData.selectedOnly(country.getSelectedValue()));

        var bankName = textField(group, BANK_NAME_OF_ORIGINATING_ACCOUNT);
        apply(bankName, new FieldAttributes("Name of the bank", false, true,
                originatingAccountTemplateDisplayIf(), false, null), webForm);
        bankName.setMultiple(true);
    }

    private void evaluateOriginatingAccountFields(Group group, WebForm webForm, int position) {
        var holder = textField(group, suffixed(NAME_OF_ORIGINATING_ACCOUNT_HOLDER, position));
        apply(holder, new FieldAttributes("Account holder ID #" + position, false, true,
                null, false, null), webForm);

        var country = selectField(group, suffixed(COUNTRY_OF_ORIGINATING_ACCOUNT, position));
        apply(country, new FieldAttributes("Country of the originating bank #" + position, false, true,
                null, false, null), webForm);
        country.setOptions(OnboardingReferenceData.selectedOnly(country.getSelectedValue()));

        var bankName = textField(group, suffixed(BANK_NAME_OF_ORIGINATING_ACCOUNT, position));
        apply(bankName, new FieldAttributes("Name of the bank #" + position, false, true,
                null, false, null), webForm);
    }

    private void evaluateOriginatingBankCountryRisk(Group group, WebForm webForm) {
        var field = textField(group, ORIGINATING_BANK_COUNTRY_RISK);
        apply(field, new FieldAttributes("Riskiest country of originating bank", false, true,
                "#" + NUMBER_OF_ORIGINATING_ACCOUNTS + "# >= 1", false, null), webForm);
    }

    private <T extends Field> T apply(T field, FieldAttributes rule, WebForm webForm) {
        field.setIsActive(true);
        field.incrementOrder();
        field.setLabel(rule.label());
        field.setEnabled(rule.enabled());
        field.setMandatory(rule.mandatory());
        field.setDisplayIf(blankToNull(rule.displayIf()));
        field.setLabelBold(rule.labelBold());
        field.setSourceSystem(blankToNull(rule.sourceSystem()));
        field.setMultiple(null);
        field.setMaxMultiple(null);
        field.setSelectedValue(selectedValue(field, webForm));
        return field;
    }

    private SelectInputField selectField(Group group, String fieldId) {
        return switch (ChecklistUtils.getFieldInGroup(group, fieldId)) {
            case null -> {
                var field = SelectInputField.builder().fieldId(fieldId).build();
                group.getFields().add(field);
                yield field;
            }
            case SelectInputField field -> field;
            default -> throw unexpectedFieldType(fieldId, SelectInputField.class);
        };
    }

    private NumberInputField numberField(Group group, String fieldId) {
        return switch (ChecklistUtils.getFieldInGroup(group, fieldId)) {
            case null -> {
                var field = NumberInputField.builder().fieldId(fieldId).build();
                group.getFields().add(field);
                yield field;
            }
            case NumberInputField field -> field;
            default -> throw unexpectedFieldType(fieldId, NumberInputField.class);
        };
    }

    private TextInputField textField(Group group, String fieldId) {
        return switch (ChecklistUtils.getFieldInGroup(group, fieldId)) {
            case null -> {
                var field = TextInputField.builder().fieldId(fieldId).build();
                group.getFields().add(field);
                yield field;
            }
            case TextInputField field -> field;
            default -> throw unexpectedFieldType(fieldId, TextInputField.class);
        };
    }

    private TextAreaField textAreaField(Group group, String fieldId) {
        return switch (ChecklistUtils.getFieldInGroup(group, fieldId)) {
            case null -> {
                var field = TextAreaField.builder().fieldId(fieldId).build();
                group.getFields().add(field);
                yield field;
            }
            case TextAreaField field -> field;
            default -> throw unexpectedFieldType(fieldId, TextAreaField.class);
        };
    }

    private IllegalStateException unexpectedFieldType(String fieldId, Class<? extends Field> expectedType) {
        return new IllegalStateException("Field " + fieldId + " must be a " + expectedType.getSimpleName());
    }

    private String selectedValue(Field field, WebForm webForm) {
        return selectedValueFromWebForm(field.getFieldId(), webForm)
                .orElse(field.getSelectedValue());
    }

    private String blankToNull(String value) {
        return value == null || value.isBlank() ? null : value;
    }

    private int originatingAccountCount(Group group, WebForm webForm) {
        var explicitCount = parsePositiveInt(selectedValueFromGroup(group, NUMBER_OF_ORIGINATING_ACCOUNTS)
                .or(() -> selectedValueFromWebForm(NUMBER_OF_ORIGINATING_ACCOUNTS, webForm))
                .orElse(null)).orElse(0);
        var countFromGroup = maxOriginatingAccountSuffix(groupFieldIds(group));
        var countFromWebForm = maxOriginatingAccountSuffix(webFormFieldIds(webForm));
        return Stream.of(explicitCount, countFromGroup, countFromWebForm).mapToInt(Integer::intValue).max().orElse(0);
    }

    private Optional<String> selectedValueFromGroup(Group group, String fieldId) {
        return Optional.ofNullable(ChecklistUtils.getFieldInGroup(group, fieldId))
                .map(Field::getSelectedValue)
                .filter(value -> value != null && !value.isBlank());
    }

    private Stream<String> groupFieldIds(Group group) {
        return Optional.ofNullable(group)
                .map(Group::getFields)
                .stream()
                .flatMap(Collection::stream)
                .filter(Objects::nonNull)
                .map(Field::getFieldId)
                .filter(Objects::nonNull);
    }

    private int maxOriginatingAccountSuffix(Stream<String> fieldIds) {
        return fieldIds.mapToInt(this::originatingAccountPosition).max().orElse(0);
    }

    private int originatingAccountPosition(String fieldId) {
        if (fieldId == null) {
            return 0;
        }
        return Stream.of(NAME_OF_ORIGINATING_ACCOUNT_HOLDER, COUNTRY_OF_ORIGINATING_ACCOUNT, BANK_NAME_OF_ORIGINATING_ACCOUNT)
                .map(prefix -> positionAfterPrefix(fieldId, prefix))
                .flatMapToInt(OptionalInt::stream)
                .max()
                .orElse(0);
    }

    private OptionalInt positionAfterPrefix(String fieldId, String prefix) {
        var marker = prefix + "_";
        if (!fieldId.startsWith(marker)) {
            return OptionalInt.empty();
        }
        return parsePositiveInt(fieldId.substring(marker.length()));
    }

    private OptionalInt parsePositiveInt(String value) {
        if (value == null || value.isBlank()) {
            return OptionalInt.empty();
        }
        try {
            var parsed = Integer.parseInt(value.trim());
            return parsed > 0 ? OptionalInt.of(parsed) : OptionalInt.empty();
        } catch (NumberFormatException ignored) {
            return OptionalInt.empty();
        }
    }

    private String selectedEquals(String fieldId, String expectedValue) {
        return "#" + fieldId + "# == \"" + expectedValue + "\"";
    }

    private String thirdPartyPayerDisplayIf() {
        return selectedEquals(PAYMENT_THIRD_PARTY, YES);
    }

    private String originatingAccountTemplateDisplayIf() {
        return "#" + NUMBER_OF_ORIGINATING_ACCOUNTS + "# >= $";
    }

    private String suffixed(String fieldId, int position) {
        return fieldId + "_" + position;
    }

    private record FieldAttributes(String label, boolean enabled, boolean mandatory, String displayIf, boolean labelBold,
                             String sourceSystem) {
    }
}
