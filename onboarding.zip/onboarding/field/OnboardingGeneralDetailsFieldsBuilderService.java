package com.lombardinternational.casemanagement.service.decision.domain.service.checklist.onboarding.field;

import com.lombardinternational.casemanagement.service.decision.domain.model.policy.Policy;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.*;
import com.lombardinternational.casemanagement.service.decision.domain.model.transaction.BusinessTransaction;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.checklist.FieldBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.spi.repository.ReferenceDataRepositoryService;
import com.lombardinternational.casemanagement.service.decision.domain.utils.ChecklistUtils;
import java.util.List;
import java.util.Map;
import org.springframework.stereotype.Service;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.OnboardingChecklistIds.*;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ReferenceConstants.*;

@Service
public class OnboardingGeneralDetailsFieldsBuilderService extends OnboardingChecklistFieldsBuilderSupport implements FieldBuilderService {
    private final ReferenceDataRepositoryService referenceDataRepositoryService;

    public OnboardingGeneralDetailsFieldsBuilderService(ReferenceDataRepositoryService referenceDataRepositoryService) {
        this.referenceDataRepositoryService = referenceDataRepositoryService;
    }

    @Override
    public void buildField(final WebForm webForm, final ScreenDescription screenDescription, final Group group, final Policy policy, final BusinessTransaction transaction, final Map<String,List<String>> overallCaseRisk) {
        Field.resetFieldId();

        evaluateContractType(group, webForm);

        evaluatePolicyNumber(group, webForm);

        evaluatePolicyCur(group, webForm);

        evaluateExpectedPrem(group, webForm);

        evaluateExpectedPremEur(group, webForm);

        evaluateNewClient(group, webForm);

        evaluateTotalBeNavPolicyEur(group, webForm);

        evaluateTotalNavPolicyEur(group, webForm);

        evaluateCountryOfLaw(group, webForm);

        evaluateResidenceCountry(group, webForm);

        evaluateRdrCompliant(group, webForm);

        evaluateMarketConsultant(group, webForm);

        evaluateInvestManagerCode(group, webForm);

        evaluateInvestManagerName(group, webForm);

        evaluateEsgMandateSelected(group, webForm);

        evaluateEsgStrategyName(group, webForm);

        evaluateProxyAlignImaClass(group, webForm);

        evaluateCustodianCountry(group, webForm);

        evaluateCustodianBankName(group, webForm);

        evaluateAccountOpenedCountry(group, webForm);

        evaluateAccountOpenedInEea(group, webForm);

        evaluateMultiProduct(group, webForm);

        evaluateNumberProduct(group, webForm);

        evaluateBusinessOrigin(group, webForm);

        evaluatePhResidenceCountryRisk(group, webForm);

        evaluateOffShoreIndicia(group, webForm);

        evaluatePhFiscalCountry(group, webForm);

        evaluateTaxResidenceInconsistent(group, webForm);

        evaluatePhTypeAssessment(group, webForm);

        evaluatePhNonFinancial(group, webForm);

        evaluateEntitySameAsFatca(group, webForm);

        evaluatePhLegalEntityArrangement(group, webForm);

        evaluateEvidenceKnownLegalEntity(group, webForm);

        evaluatePhLegalEntity(group, webForm);

        evaluatePaidFromAppointed(group, webForm);

        evaluateFormerSwissPh(group, webForm);

        evaluateProofDeregistrationPh(group, webForm);

        evaluateThirdPartySubTypePh(group, webForm);

        evaluateMrlTrustee(group, webForm);

        evaluateAppFormSigned(group, webForm);

        evaluateTrustResidenceCountryRisk(group, webForm);

        evaluateProxyCountryRisk(group, webForm);

        evaluateLaDifferentToPh(group, webForm);

        evaluateLaResidenceCountryRisk(group, webForm);

        evaluateFormerSwissLa(group, webForm);

        evaluateProofDeregistrationLa(group, webForm);

        evaluateSettlorResidenceCountryRisk(group, webForm);

        evaluateAppFormSignedLa(group, webForm);

        evaluateLaDifferentBen(group, webForm);

        evaluateDateOfBirth(group, webForm);

        evaluatePolicySignedCountry(group, webForm);

        evaluateSendingAddress(group, webForm);

        evaluateIrrevocableBen(group, webForm);

        evaluateIrrevocableBenCountry(group, webForm);

        evaluateAmlClause(group, webForm);

        evaluatePhDifferentToEbo(group, webForm);

        evaluateThirdPartySubTypeEbo(group, webForm);

        evaluateEboResidenceCountryRisk(group, webForm);

        evaluateFormerSwissEbo(group, webForm);

        evaluateProofDeregistrationEbo(group, webForm);

        evaluateTrusteeResidenceCountryRisk(group, webForm);

        evaluateBeneficiaryResidenceCountryRisk(group, webForm);

        evaluateUsIndicia(group, webForm);

        evaluateFatcaFormRefused(group, webForm);

        evaluateFatcaFormInconsistent(group, webForm);

        evaluateTpBlock(group, webForm);

    }

    private void evaluateContractType(Group group, WebForm webForm) {
        var contractType = (SelectInputField) ChecklistUtils.getFieldInGroup(group, CONTRACT_TYPE);
        if (contractType == null) {
            contractType = SelectInputField.builder().fieldId(CONTRACT_TYPE).build();
            group.getFields().add(contractType);
        }
        contractType.setIsActive(true);
        contractType.incrementOrder();
        contractType.setLabel("Contract type");
        contractType.setEnabled(false);
        contractType.setMandatory(false);
        contractType.setDisplayIf(null);
        contractType.setLabelBold(false);
        contractType.setSourceSystem("From Connect");
        selectedValueFromWebForm(CONTRACT_TYPE, webForm).ifPresent(contractType::setSelectedValue);
    }

    private void evaluatePolicyNumber(Group group, WebForm webForm) {
        var policyNumber = (TextInputField) ChecklistUtils.getFieldInGroup(group, POLICY_NUMBER);
        if (policyNumber == null) {
            policyNumber = TextInputField.builder().fieldId(POLICY_NUMBER).build();
            group.getFields().add(policyNumber);
        }
        policyNumber.setIsActive(true);
        policyNumber.incrementOrder();
        policyNumber.setLabel("Policy number");
        policyNumber.setEnabled(false);
        policyNumber.setMandatory(false);
        policyNumber.setDisplayIf(null);
        policyNumber.setLabelBold(false);
        policyNumber.setSourceSystem("From Connect");
        selectedValueFromWebForm(POLICY_NUMBER, webForm).ifPresent(policyNumber::setSelectedValue);
    }

    private void evaluatePolicyCur(Group group, WebForm webForm) {
        var policyCur = (TextInputField) ChecklistUtils.getFieldInGroup(group, POLICY_CUR);
        if (policyCur == null) {
            policyCur = TextInputField.builder().fieldId(POLICY_CUR).build();
            group.getFields().add(policyCur);
        }
        policyCur.setIsActive(true);
        policyCur.incrementOrder();
        policyCur.setLabel("Policy ccy");
        policyCur.setEnabled(false);
        policyCur.setMandatory(false);
        policyCur.setDisplayIf(null);
        policyCur.setLabelBold(false);
        policyCur.setSourceSystem("From Connect");
        selectedValueFromWebForm(POLICY_CUR, webForm).ifPresent(policyCur::setSelectedValue);
    }

    private void evaluateExpectedPrem(Group group, WebForm webForm) {
        var expectedPrem = (NumberInputField) ChecklistUtils.getFieldInGroup(group, EXPECTED_PREM);
        if (expectedPrem == null) {
            expectedPrem = NumberInputField.builder().fieldId(EXPECTED_PREM).build();
            group.getFields().add(expectedPrem);
        }
        expectedPrem.setIsActive(true);
        expectedPrem.incrementOrder();
        expectedPrem.setLabel("Expected premium (in policy currency)");
        expectedPrem.setEnabled(false);
        expectedPrem.setMandatory(false);
        expectedPrem.setDisplayIf(null);
        expectedPrem.setLabelBold(false);
        expectedPrem.setSourceSystem("From Connect");
        selectedValueFromWebForm(EXPECTED_PREM, webForm).ifPresent(expectedPrem::setSelectedValue);
    }

    private void evaluateExpectedPremEur(Group group, WebForm webForm) {
        var expectedPremEur = (NumberInputField) ChecklistUtils.getFieldInGroup(group, EXPECTED_PREM_EUR);
        if (expectedPremEur == null) {
            expectedPremEur = NumberInputField.builder().fieldId(EXPECTED_PREM_EUR).build();
            group.getFields().add(expectedPremEur);
        }
        expectedPremEur.setIsActive(true);
        expectedPremEur.incrementOrder();
        expectedPremEur.setLabel("Expected premium (in EUR)");
        expectedPremEur.setEnabled(false);
        expectedPremEur.setMandatory(false);
        expectedPremEur.setDisplayIf("#POLICY_CUR# != \"EUR\"");
        expectedPremEur.setLabelBold(false);
        expectedPremEur.setSourceSystem("From Connect");
        selectedValueFromWebForm(EXPECTED_PREM_EUR, webForm).ifPresent(expectedPremEur::setSelectedValue);
    }

    private void evaluateNewClient(Group group, WebForm webForm) {
        var newClient = (SelectInputField) ChecklistUtils.getFieldInGroup(group, NEW_CLIENT);
        if (newClient == null) {
            newClient = SelectInputField.builder().fieldId(NEW_CLIENT).build();
            group.getFields().add(newClient);
        }
        newClient.setIsActive(true);
        newClient.incrementOrder();
        newClient.setLabel("New client");
        newClient.setEnabled(true);
        newClient.setMandatory(true);
        newClient.setDisplayIf(null);
        newClient.setLabelBold(false);
        newClient.setSourceSystem(null);
        newClient.setOptions(referenceDataRepositoryService.getReferenceDataOptionsByDomain(YES_NO_DOMAIN));
    }

    private void evaluateTotalBeNavPolicyEur(Group group, WebForm webForm) {
        var totalBeNavPolicyEur = (NumberInputField) ChecklistUtils.getFieldInGroup(group, TOTAL_BE_NAV_POLICY_EUR);
        if (totalBeNavPolicyEur == null) {
            totalBeNavPolicyEur = NumberInputField.builder().fieldId(TOTAL_BE_NAV_POLICY_EUR).build();
            group.getFields().add(totalBeNavPolicyEur);
        }
        totalBeNavPolicyEur.setIsActive(true);
        totalBeNavPolicyEur.incrementOrder();
        totalBeNavPolicyEur.setLabel("Total existing BE NAV");
        totalBeNavPolicyEur.setEnabled(false);
        totalBeNavPolicyEur.setMandatory(false);
        totalBeNavPolicyEur.setDisplayIf("#NEW_CLIENT# == \"NO\" && #BUSINESS_ORIGIN# == \"BE\"");
        totalBeNavPolicyEur.setLabelBold(false);
        totalBeNavPolicyEur.setSourceSystem(null);
        selectedValueFromWebForm(TOTAL_BE_NAV_POLICY_EUR, webForm).ifPresent(totalBeNavPolicyEur::setSelectedValue);
    }

    private void evaluateTotalNavPolicyEur(Group group, WebForm webForm) {
        var totalNavPolicyEur = (NumberInputField) ChecklistUtils.getFieldInGroup(group, TOTAL_NAV_POLICY_EUR);
        if (totalNavPolicyEur == null) {
            totalNavPolicyEur = NumberInputField.builder().fieldId(TOTAL_NAV_POLICY_EUR).build();
            group.getFields().add(totalNavPolicyEur);
        }
        totalNavPolicyEur.setIsActive(true);
        totalNavPolicyEur.incrementOrder();
        totalNavPolicyEur.setLabel("Total existing NAV linked to the same EBO, excluding this expected premium");
        totalNavPolicyEur.setEnabled(false);
        totalNavPolicyEur.setMandatory(false);
        totalNavPolicyEur.setDisplayIf("#NEW_CLIENT# == \"NO\" && #BUSINESS_ORIGIN# != \"BE\"");
        totalNavPolicyEur.setLabelBold(false);
        totalNavPolicyEur.setSourceSystem(null);
        selectedValueFromWebForm(TOTAL_NAV_POLICY_EUR, webForm).ifPresent(totalNavPolicyEur::setSelectedValue);
    }

    private void evaluateCountryOfLaw(Group group, WebForm webForm) {
        var countryOfLaw = (SelectInputField) ChecklistUtils.getFieldInGroup(group, COUNTRY_OF_LAW);
        if (countryOfLaw == null) {
            countryOfLaw = SelectInputField.builder().fieldId(COUNTRY_OF_LAW).build();
            group.getFields().add(countryOfLaw);
        }
        countryOfLaw.setIsActive(true);
        countryOfLaw.incrementOrder();
        countryOfLaw.setLabel("Country of applicable law");
        countryOfLaw.setEnabled(false);
        countryOfLaw.setMandatory(false);
        countryOfLaw.setDisplayIf(null);
        countryOfLaw.setLabelBold(false);
        countryOfLaw.setSourceSystem("From Connect");
        selectedValueFromWebForm(COUNTRY_OF_LAW, webForm).ifPresent(countryOfLaw::setSelectedValue);
        countryOfLaw.setOptions(referenceDataRepositoryService.getReferenceDataOptionsByDomainAndSelectedValue(COUNTRY_DOMAIN,
                countryOfLaw.getSelectedValue()));
    }

    private void evaluateResidenceCountry(Group group, WebForm webForm) {
        var residenceCountry = (TextAreaField) ChecklistUtils.getFieldInGroup(group, RESIDENCE_COUNTRY);
        if (residenceCountry == null) {
            residenceCountry = TextAreaField.builder().fieldId(RESIDENCE_COUNTRY).build();
            group.getFields().add(residenceCountry);
        }
        residenceCountry.setIsActive(true);
        residenceCountry.incrementOrder();
        residenceCountry.setLabel("Riskiest / Missing country of residence");
        residenceCountry.setEnabled(false);
        residenceCountry.setMandatory(true);
        residenceCountry.setDisplayIf(null);
        residenceCountry.setLabelBold(false);
        residenceCountry.setSourceSystem("From CLASS");
        selectedValueFromWebForm(RESIDENCE_COUNTRY, webForm).ifPresent(residenceCountry::setSelectedValue);
    }

    private void evaluateRdrCompliant(Group group, WebForm webForm) {
        var rdrCompliant = (SelectInputField) ChecklistUtils.getFieldInGroup(group, RDR_COMPLIANT);
        if (rdrCompliant == null) {
            rdrCompliant = SelectInputField.builder().fieldId(RDR_COMPLIANT).build();
            group.getFields().add(rdrCompliant);
        }
        rdrCompliant.setIsActive(true);
        rdrCompliant.incrementOrder();
        rdrCompliant.setLabel("Is it RDR compliant?");
        rdrCompliant.setEnabled(true);
        rdrCompliant.setMandatory(true);
        rdrCompliant.setDisplayIf("#COUNTRY_OF_LAW# == \"GB\"");
        rdrCompliant.setLabelBold(false);
        rdrCompliant.setSourceSystem(null);
        rdrCompliant.setOptions(referenceDataRepositoryService.getReferenceDataOptionsByDomain(YES_NO_NA_NEW_BUSINESS_VALUES_DOMAIN));
    }

    private void evaluateMarketConsultant(Group group, WebForm webForm) {
        var marketConsultant = (TextInputField) ChecklistUtils.getFieldInGroup(group, MARKET_CONSULTANT);
        if (marketConsultant == null) {
            marketConsultant = TextInputField.builder().fieldId(MARKET_CONSULTANT).build();
            group.getFields().add(marketConsultant);
        }
        marketConsultant.setIsActive(true);
        marketConsultant.incrementOrder();
        marketConsultant.setLabel("Marketing consultant");
        marketConsultant.setEnabled(true);
        marketConsultant.setMandatory(false);
        marketConsultant.setDisplayIf(null);
        marketConsultant.setLabelBold(false);
        marketConsultant.setSourceSystem(null);
    }

    private void evaluateInvestManagerCode(Group group, WebForm webForm) {
        var investManagerCode = (TextInputField) ChecklistUtils.getFieldInGroup(group, INVEST_MANAGER_CODE);
        if (investManagerCode == null) {
            investManagerCode = TextInputField.builder().fieldId(INVEST_MANAGER_CODE).build();
            group.getFields().add(investManagerCode);
        }
        investManagerCode.setIsActive(true);
        investManagerCode.incrementOrder();
        investManagerCode.setLabel("Investment manager code");
        investManagerCode.setEnabled(false);
        investManagerCode.setMandatory(false);
        investManagerCode.setDisplayIf(null);
        investManagerCode.setLabelBold(false);
        investManagerCode.setSourceSystem("From Connect");
        selectedValueFromWebForm(INVEST_MANAGER_CODE, webForm).ifPresent(investManagerCode::setSelectedValue);
    }

    private void evaluateInvestManagerName(Group group, WebForm webForm) {
        var investManagerName = (TextInputField) ChecklistUtils.getFieldInGroup(group, INVEST_MANAGER_NAME);
        if (investManagerName == null) {
            investManagerName = TextInputField.builder().fieldId(INVEST_MANAGER_NAME).build();
            group.getFields().add(investManagerName);
        }
        investManagerName.setIsActive(true);
        investManagerName.incrementOrder();
        investManagerName.setLabel("Investment manager name");
        investManagerName.setEnabled(false);
        investManagerName.setMandatory(false);
        investManagerName.setDisplayIf(null);
        investManagerName.setLabelBold(false);
        investManagerName.setSourceSystem("From Connect");
        selectedValueFromWebForm(INVEST_MANAGER_NAME, webForm).ifPresent(investManagerName::setSelectedValue);
    }

    private void evaluateEsgMandateSelected(Group group, WebForm webForm) {
        var esgMandateSelected = (SelectInputField) ChecklistUtils.getFieldInGroup(group, ESG_MANDATE_SELECTED);
        if (esgMandateSelected == null) {
            esgMandateSelected = SelectInputField.builder().fieldId(ESG_MANDATE_SELECTED).build();
            group.getFields().add(esgMandateSelected);
        }
        esgMandateSelected.setIsActive(true);
        esgMandateSelected.incrementOrder();
        esgMandateSelected.setLabel("Art. 8/9 ESG mandate selected?");
        esgMandateSelected.setEnabled(false);
        esgMandateSelected.setMandatory(false);
        esgMandateSelected.setDisplayIf(null);
        esgMandateSelected.setLabelBold(false);
        esgMandateSelected.setSourceSystem("From Connect");
        selectedValueFromWebForm(ESG_MANDATE_SELECTED, webForm).ifPresent(esgMandateSelected::setSelectedValue);
    }

    private void evaluateEsgStrategyName(Group group, WebForm webForm) {
        var esgStrategyName = (TextInputField) ChecklistUtils.getFieldInGroup(group, ESG_STRATEGY_NAME);
        if (esgStrategyName == null) {
            esgStrategyName = TextInputField.builder().fieldId(ESG_STRATEGY_NAME).build();
            group.getFields().add(esgStrategyName);
        }
        esgStrategyName.setIsActive(true);
        esgStrategyName.incrementOrder();
        esgStrategyName.setLabel("ESG Stragegy Name");
        esgStrategyName.setEnabled(false);
        esgStrategyName.setMandatory(false);
        esgStrategyName.setDisplayIf("#ESG_MANDATE_SELECTED_$# == \"YES_PRE_VALIDATED\" || #ESG_MANDATE_SELECTED_$# == \"YES_TO_BE_REVIEWED\"");
        esgStrategyName.setLabelBold(false);
        esgStrategyName.setSourceSystem("From Connect");
        selectedValueFromWebForm(ESG_STRATEGY_NAME, webForm).ifPresent(esgStrategyName::setSelectedValue);
    }

    private void evaluateProxyAlignImaClass(Group group, WebForm webForm) {
        var proxyAlignImaClass = (SelectInputField) ChecklistUtils.getFieldInGroup(group, PROXY_ALIGN_IMA_CLASS);
        if (proxyAlignImaClass == null) {
            proxyAlignImaClass = SelectInputField.builder().fieldId(PROXY_ALIGN_IMA_CLASS).build();
            group.getFields().add(proxyAlignImaClass);
        }
        proxyAlignImaClass.setIsActive(true);
        proxyAlignImaClass.incrementOrder();
        proxyAlignImaClass.setLabel("Proxy to IM to charge their fees (debited by partner)?");
        proxyAlignImaClass.setEnabled(true);
        proxyAlignImaClass.setMandatory(true);
        proxyAlignImaClass.setDisplayIf(null);
        proxyAlignImaClass.setLabelBold(false);
        proxyAlignImaClass.setSourceSystem(null);
        proxyAlignImaClass.setOptions(referenceDataRepositoryService.getReferenceDataOptionsByDomain(YES_NO_DOMAIN));
    }

    private void evaluateCustodianCountry(Group group, WebForm webForm) {
        var custodianCountry = (SelectInputField) ChecklistUtils.getFieldInGroup(group, CUSTODIAN_COUNTRY);
        if (custodianCountry == null) {
            custodianCountry = SelectInputField.builder().fieldId(CUSTODIAN_COUNTRY).build();
            group.getFields().add(custodianCountry);
        }
        custodianCountry.setIsActive(true);
        custodianCountry.incrementOrder();
        custodianCountry.setLabel("Custodian country");
        custodianCountry.setEnabled(false);
        custodianCountry.setMandatory(false);
        custodianCountry.setDisplayIf(null);
        custodianCountry.setLabelBold(false);
        custodianCountry.setSourceSystem("From Connect");
        selectedValueFromWebForm(CUSTODIAN_COUNTRY, webForm).ifPresent(custodianCountry::setSelectedValue);
    }

    private void evaluateCustodianBankName(Group group, WebForm webForm) {
        var custodianBankName = (TextInputField) ChecklistUtils.getFieldInGroup(group, CUSTODIAN_BANK_NAME);
        if (custodianBankName == null) {
            custodianBankName = TextInputField.builder().fieldId(CUSTODIAN_BANK_NAME).build();
            group.getFields().add(custodianBankName);
        }
        custodianBankName.setIsActive(true);
        custodianBankName.incrementOrder();
        custodianBankName.setLabel("Custodian bank name");
        custodianBankName.setEnabled(false);
        custodianBankName.setMandatory(false);
        custodianBankName.setDisplayIf(null);
        custodianBankName.setLabelBold(false);
        custodianBankName.setSourceSystem("From Connect");
        selectedValueFromWebForm(CUSTODIAN_BANK_NAME, webForm).ifPresent(custodianBankName::setSelectedValue);
    }

    private void evaluateAccountOpenedCountry(Group group, WebForm webForm) {
        var accountOpenedCountry = (SelectInputField) ChecklistUtils.getFieldInGroup(group, ACCOUNT_OPENED_COUNTRY);
        if (accountOpenedCountry == null) {
            accountOpenedCountry = SelectInputField.builder().fieldId(ACCOUNT_OPENED_COUNTRY).build();
            group.getFields().add(accountOpenedCountry);
        }
        accountOpenedCountry.setIsActive(true);
        accountOpenedCountry.incrementOrder();
        accountOpenedCountry.setLabel("Account opened country");
        accountOpenedCountry.setEnabled(true);
        accountOpenedCountry.setMandatory(true);
        accountOpenedCountry.setDisplayIf(null);
        accountOpenedCountry.setLabelBold(false);
        accountOpenedCountry.setSourceSystem(null);
        accountOpenedCountry.setOptions(referenceDataRepositoryService.getReferenceDataOptionsByDomain(COUNTRY_DOMAIN));
    }

    private void evaluateAccountOpenedInEea(Group group, WebForm webForm) {
        var accountOpenedInEea = (SelectInputField) ChecklistUtils.getFieldInGroup(group, ACCOUNT_OPENED_IN_EEA);
        if (accountOpenedInEea == null) {
            accountOpenedInEea = SelectInputField.builder().fieldId(ACCOUNT_OPENED_IN_EEA).build();
            group.getFields().add(accountOpenedInEea);
        }
        accountOpenedInEea.setIsActive(true);
        accountOpenedInEea.incrementOrder();
        accountOpenedInEea.setLabel("Account opened in a bank located in the EEA?");
        accountOpenedInEea.setEnabled(false);
        accountOpenedInEea.setMandatory(true);
        accountOpenedInEea.setDisplayIf(null);
        accountOpenedInEea.setLabelBold(false);
        accountOpenedInEea.setSourceSystem(null);
        selectedValueFromWebForm(ACCOUNT_OPENED_IN_EEA, webForm).ifPresent(accountOpenedInEea::setSelectedValue);
    }

    private void evaluateMultiProduct(Group group, WebForm webForm) {
        var multiProduct = (SelectInputField) ChecklistUtils.getFieldInGroup(group, MULTI_PRODUCT);
        if (multiProduct == null) {
            multiProduct = SelectInputField.builder().fieldId(MULTI_PRODUCT).build();
            group.getFields().add(multiProduct);
        }
        multiProduct.setIsActive(true);
        multiProduct.incrementOrder();
        multiProduct.setLabel("Multi product");
        multiProduct.setEnabled(false);
        multiProduct.setMandatory(false);
        multiProduct.setDisplayIf(null);
        multiProduct.setLabelBold(false);
        multiProduct.setSourceSystem("From Connect");
        selectedValueFromWebForm(MULTI_PRODUCT, webForm).ifPresent(multiProduct::setSelectedValue);
    }

    private void evaluateNumberProduct(Group group, WebForm webForm) {
        var numberProduct = (TextInputField) ChecklistUtils.getFieldInGroup(group, NUMBER_PRODUCT);
        if (numberProduct == null) {
            numberProduct = TextInputField.builder().fieldId(NUMBER_PRODUCT).build();
            group.getFields().add(numberProduct);
        }
        numberProduct.setIsActive(true);
        numberProduct.incrementOrder();
        numberProduct.setLabel("Number of added product");
        numberProduct.setEnabled(false);
        numberProduct.setMandatory(false);
        numberProduct.setDisplayIf("#MULTI_PRODUCT# == \"YES\"");
        numberProduct.setLabelBold(false);
        numberProduct.setSourceSystem("From Connect");
        selectedValueFromWebForm(NUMBER_PRODUCT, webForm).ifPresent(numberProduct::setSelectedValue);
    }

    private void evaluateBusinessOrigin(Group group, WebForm webForm) {
        var businessOrigin = (SelectInputField) ChecklistUtils.getFieldInGroup(group, BUSINESS_ORIGIN);
        if (businessOrigin == null) {
            businessOrigin = SelectInputField.builder().fieldId(BUSINESS_ORIGIN).build();
            group.getFields().add(businessOrigin);
        }
        businessOrigin.setIsActive(true);
        businessOrigin.incrementOrder();
        businessOrigin.setLabel("Business Origin");
        businessOrigin.setEnabled(false);
        businessOrigin.setMandatory(false);
        businessOrigin.setDisplayIf(null);
        businessOrigin.setLabelBold(false);
        businessOrigin.setSourceSystem("From Connect");
        selectedValueFromWebForm(BUSINESS_ORIGIN, webForm).ifPresent(businessOrigin::setSelectedValue);
    }

    private void evaluatePhResidenceCountryRisk(Group group, WebForm webForm) {
        var phResidenceCountryRisk = (TextInputField) ChecklistUtils.getFieldInGroup(group, PH_RESIDENCE_COUNTRY_RISK);
        if (phResidenceCountryRisk == null) {
            phResidenceCountryRisk = TextInputField.builder().fieldId(PH_RESIDENCE_COUNTRY_RISK).build();
            group.getFields().add(phResidenceCountryRisk);
        }
        phResidenceCountryRisk.setIsActive(true);
        phResidenceCountryRisk.incrementOrder();
        phResidenceCountryRisk.setLabel("PH(s) residence country");
        phResidenceCountryRisk.setEnabled(false);
        phResidenceCountryRisk.setMandatory(false);
        phResidenceCountryRisk.setDisplayIf("#forcedDisplayIf");
        phResidenceCountryRisk.setLabelBold(false);
        phResidenceCountryRisk.setSourceSystem("From CLASS");
        selectedValueFromWebForm(PH_RESIDENCE_COUNTRY_RISK, webForm).ifPresent(phResidenceCountryRisk::setSelectedValue);
    }

    private void evaluateOffShoreIndicia(Group group, WebForm webForm) {
        var offShoreIndicia = (SelectInputField) ChecklistUtils.getFieldInGroup(group, OFF_SHORE_INDICIA);
        if (offShoreIndicia == null) {
            offShoreIndicia = SelectInputField.builder().fieldId(OFF_SHORE_INDICIA).build();
            group.getFields().add(offShoreIndicia);
        }
        offShoreIndicia.setIsActive(true);
        offShoreIndicia.incrementOrder();
        offShoreIndicia.setLabel("(Belgian Branch) Off-shore indicia found ?");
        offShoreIndicia.setEnabled(false);
        offShoreIndicia.setMandatory(true);
        offShoreIndicia.setDisplayIf("#forcedDisplayIf");
        offShoreIndicia.setLabelBold(false);
        offShoreIndicia.setSourceSystem("From CLASS and converted");
        selectedValueFromWebForm(OFF_SHORE_INDICIA, webForm).ifPresent(offShoreIndicia::setSelectedValue);
    }

    private void evaluatePhFiscalCountry(Group group, WebForm webForm) {
        var phFiscalCountry = (TextInputField) ChecklistUtils.getFieldInGroup(group, PH_FISCAL_COUNTRY);
        if (phFiscalCountry == null) {
            phFiscalCountry = TextInputField.builder().fieldId(PH_FISCAL_COUNTRY).build();
            group.getFields().add(phFiscalCountry);
        }
        phFiscalCountry.setIsActive(true);
        phFiscalCountry.incrementOrder();
        phFiscalCountry.setLabel("PH(s) fiscal country");
        phFiscalCountry.setEnabled(false);
        phFiscalCountry.setMandatory(false);
        phFiscalCountry.setDisplayIf(null);
        phFiscalCountry.setLabelBold(false);
        phFiscalCountry.setSourceSystem("From Connect");
        selectedValueFromWebForm(PH_FISCAL_COUNTRY, webForm).ifPresent(phFiscalCountry::setSelectedValue);
    }

    private void evaluateTaxResidenceInconsistent(Group group, WebForm webForm) {
        var taxResidenceInconsistent = (SelectInputField) ChecklistUtils.getFieldInGroup(group, TAX_RESIDENCE_INCONSISTENT);
        if (taxResidenceInconsistent == null) {
            taxResidenceInconsistent = SelectInputField.builder().fieldId(TAX_RESIDENCE_INCONSISTENT).build();
            group.getFields().add(taxResidenceInconsistent);
        }
        taxResidenceInconsistent.setIsActive(true);
        taxResidenceInconsistent.incrementOrder();
        taxResidenceInconsistent.setLabel("Is there any unjustified inconsistency in the information provided concerning the tax residence of the PH/EBO and this without any legitimate reason?");
        taxResidenceInconsistent.setEnabled(true);
        taxResidenceInconsistent.setMandatory(true);
        taxResidenceInconsistent.setDisplayIf(null);
        taxResidenceInconsistent.setLabelBold(false);
        taxResidenceInconsistent.setSourceSystem(null);
        taxResidenceInconsistent.setOptions(referenceDataRepositoryService.getReferenceDataOptionsByDomain(YES_NO_DOMAIN));
    }

    private void evaluatePhTypeAssessment(Group group, WebForm webForm) {
        var phTypeAssessment = (TextInputField) ChecklistUtils.getFieldInGroup(group, PH_TYPE_ASSESSMENT);
        if (phTypeAssessment == null) {
            phTypeAssessment = TextInputField.builder().fieldId(PH_TYPE_ASSESSMENT).build();
            group.getFields().add(phTypeAssessment);
        }
        phTypeAssessment.setIsActive(true);
        phTypeAssessment.incrementOrder();
        phTypeAssessment.setLabel("PH type assessment");
        phTypeAssessment.setEnabled(false);
        phTypeAssessment.setMandatory(true);
        phTypeAssessment.setDisplayIf(null);
        phTypeAssessment.setLabelBold(false);
        phTypeAssessment.setSourceSystem("From CLASS");
        selectedValueFromWebForm(PH_TYPE_ASSESSMENT, webForm).ifPresent(phTypeAssessment::setSelectedValue);
    }

    private void evaluatePhNonFinancial(Group group, WebForm webForm) {
        var phNonFinancial = (SelectInputField) ChecklistUtils.getFieldInGroup(group, PH_NON_FINANCIAL);
        if (phNonFinancial == null) {
            phNonFinancial = SelectInputField.builder().fieldId(PH_NON_FINANCIAL).build();
            group.getFields().add(phNonFinancial);
        }
        phNonFinancial.setIsActive(true);
        phNonFinancial.incrementOrder();
        phNonFinancial.setLabel("Is the PH a passive Non Financial Entity (Passive NFE)?");
        phNonFinancial.setEnabled(true);
        phNonFinancial.setMandatory(true);
        phNonFinancial.setDisplayIf("#PH_TYPE_ASSESSMENT# != \"PH Type=Physical\"");
        phNonFinancial.setLabelBold(false);
        phNonFinancial.setSourceSystem(null);
        phNonFinancial.setOptions(referenceDataRepositoryService.getReferenceDataOptionsByDomain(YES_NO_DOMAIN));
    }

    private void evaluateEntitySameAsFatca(Group group, WebForm webForm) {
        var entitySameAsFatca = (SelectInputField) ChecklistUtils.getFieldInGroup(group, ENTITY_SAME_AS_FATCA);
        if (entitySameAsFatca == null) {
            entitySameAsFatca = SelectInputField.builder().fieldId(ENTITY_SAME_AS_FATCA).build();
            group.getFields().add(entitySameAsFatca);
        }
        entitySameAsFatca.setIsActive(true);
        entitySameAsFatca.incrementOrder();
        entitySameAsFatca.setLabel("Are the controlling persons of the entity as mentioned in the FATCA/CRS/AEOI form the same individuals as those identified as EBOs for AML purposes and disclosed in the KYC form?");
        entitySameAsFatca.setEnabled(true);
        entitySameAsFatca.setMandatory(true);
        entitySameAsFatca.setDisplayIf("#PH_TYPE_ASSESSMENT# != \"PH Type=Physical\" && #PH_NON_FINANCIAL# == \"YES\"");
        entitySameAsFatca.setLabelBold(false);
        entitySameAsFatca.setSourceSystem(null);
        entitySameAsFatca.setOptions(referenceDataRepositoryService.getReferenceDataOptionsByDomain(YES_NO_DOMAIN));
    }

    private void evaluatePhLegalEntityArrangement(Group group, WebForm webForm) {
        var phLegalEntityArrangement = (SelectInputField) ChecklistUtils.getFieldInGroup(group, PH_LEGAL_ENTITY_ARRANGEMENT);
        if (phLegalEntityArrangement == null) {
            phLegalEntityArrangement = SelectInputField.builder().fieldId(PH_LEGAL_ENTITY_ARRANGEMENT).build();
            group.getFields().add(phLegalEntityArrangement);
        }
        phLegalEntityArrangement.setIsActive(true);
        phLegalEntityArrangement.incrementOrder();
        phLegalEntityArrangement.setLabel("Is the PH a legal entity or a legal arrangement (e.g. trust, foundation,...) located in a country which is not the tax country of residence or place of regular economic or professional activities/interests of the EBO?");
        phLegalEntityArrangement.setEnabled(true);
        phLegalEntityArrangement.setMandatory(true);
        phLegalEntityArrangement.setDisplayIf("#forcedDisplayIf");
        phLegalEntityArrangement.setLabelBold(false);
        phLegalEntityArrangement.setSourceSystem(null);
        phLegalEntityArrangement.setOptions(List.of(new SelectInputFieldOption("YES", "Yes"), new SelectInputFieldOption("NO", "No"), new SelectInputFieldOption("NA", "(N/A for trust with professional trustee based in EU)")));
    }

    private void evaluateEvidenceKnownLegalEntity(Group group, WebForm webForm) {
        var evidenceKnownLegalEntity = (SelectInputField) ChecklistUtils.getFieldInGroup(group, EVIDENCE_KNOWN_LEGAL_ENTITY);
        if (evidenceKnownLegalEntity == null) {
            evidenceKnownLegalEntity = SelectInputField.builder().fieldId(EVIDENCE_KNOWN_LEGAL_ENTITY).build();
            group.getFields().add(evidenceKnownLegalEntity);
        }
        evidenceKnownLegalEntity.setIsActive(true);
        evidenceKnownLegalEntity.incrementOrder();
        evidenceKnownLegalEntity.setLabel("Did you collect supporting evidence that the legal entity or the legal arrangement is known by the tax authorities of the country of residence of the EBO or could the PH demonstrate that its establishment complies with the legal provisions of the country of residence of the PH/EBO?");
        evidenceKnownLegalEntity.setEnabled(true);
        evidenceKnownLegalEntity.setMandatory(true);
        evidenceKnownLegalEntity.setDisplayIf("#forcedDisplayIf");
        evidenceKnownLegalEntity.setLabelBold(false);
        evidenceKnownLegalEntity.setSourceSystem(null);
        evidenceKnownLegalEntity.setOptions(referenceDataRepositoryService.getReferenceDataOptionsByDomain(YES_NO_DOMAIN));
    }

    private void evaluatePhLegalEntity(Group group, WebForm webForm) {
        var phLegalEntity = (SelectInputField) ChecklistUtils.getFieldInGroup(group, PH_LEGAL_ENTITY);
        if (phLegalEntity == null) {
            phLegalEntity = SelectInputField.builder().fieldId(PH_LEGAL_ENTITY).build();
            group.getFields().add(phLegalEntity);
        }
        phLegalEntity.setIsActive(true);
        phLegalEntity.incrementOrder();
        phLegalEntity.setLabel("Is the PH a legal entity (excluding soci\u00e9t\u00e9 simple or any legal arrangement such as trust, fideicomiso, foundation or fiduciary)?");
        phLegalEntity.setEnabled(true);
        phLegalEntity.setMandatory(true);
        phLegalEntity.setDisplayIf("#forcedDisplayIf");
        phLegalEntity.setLabelBold(false);
        phLegalEntity.setSourceSystem(null);
        phLegalEntity.setOptions(referenceDataRepositoryService.getReferenceDataOptionsByDomain(YES_NO_DOMAIN));
    }

    private void evaluatePaidFromAppointed(Group group, WebForm webForm) {
        var paidFromAppointed = (SelectInputField) ChecklistUtils.getFieldInGroup(group, PAID_FROM_APPOINTED);
        if (paidFromAppointed == null) {
            paidFromAppointed = SelectInputField.builder().fieldId(PAID_FROM_APPOINTED).build();
            group.getFields().add(paidFromAppointed);
        }
        paidFromAppointed.setIsActive(true);
        paidFromAppointed.incrementOrder();
        paidFromAppointed.setLabel("Is the premium paid from the appointed beneficiary who is a natural person ?");
        paidFromAppointed.setEnabled(true);
        paidFromAppointed.setMandatory(true);
        paidFromAppointed.setDisplayIf("#PH_TYPE_ASSESSMENT# != \"PH Type=Physical\" && #PH_LEGAL_ENTITY# == \"YES\"");
        paidFromAppointed.setLabelBold(false);
        paidFromAppointed.setSourceSystem(null);
        paidFromAppointed.setOptions(referenceDataRepositoryService.getReferenceDataOptionsByDomain(YES_NO_DOMAIN));
    }

    private void evaluateFormerSwissPh(Group group, WebForm webForm) {
        var formerSwissPh = (SelectInputField) ChecklistUtils.getFieldInGroup(group, FORMER_SWISS_PH);
        if (formerSwissPh == null) {
            formerSwissPh = SelectInputField.builder().fieldId(FORMER_SWISS_PH).build();
            group.getFields().add(formerSwissPh);
        }
        formerSwissPh.setIsActive(true);
        formerSwissPh.incrementOrder();
        formerSwissPh.setLabel("Any former Swiss residency known for PH(s)");
        formerSwissPh.setEnabled(true);
        formerSwissPh.setMandatory(true);
        formerSwissPh.setDisplayIf(null);
        formerSwissPh.setLabelBold(false);
        formerSwissPh.setSourceSystem(null);
        formerSwissPh.setOptions(referenceDataRepositoryService.getReferenceDataOptionsByDomain(YES_NO_DOMAIN));
    }

    private void evaluateProofDeregistrationPh(Group group, WebForm webForm) {
        var proofDeregistrationPh = (SelectInputField) ChecklistUtils.getFieldInGroup(group, PROOF_DEREGISTRATION_PH);
        if (proofDeregistrationPh == null) {
            proofDeregistrationPh = SelectInputField.builder().fieldId(PROOF_DEREGISTRATION_PH).build();
            group.getFields().add(proofDeregistrationPh);
        }
        proofDeregistrationPh.setIsActive(true);
        proofDeregistrationPh.incrementOrder();
        proofDeregistrationPh.setLabel("Proof of deregistration known for PH(s)");
        proofDeregistrationPh.setEnabled(true);
        proofDeregistrationPh.setMandatory(true);
        proofDeregistrationPh.setDisplayIf("#FORMER_SWISS_PH# == \"YES\"");
        proofDeregistrationPh.setLabelBold(false);
        proofDeregistrationPh.setSourceSystem(null);
        proofDeregistrationPh.setOptions(referenceDataRepositoryService.getReferenceDataOptionsByDomain(YES_NO_DOMAIN));
    }

    private void evaluateThirdPartySubTypePh(Group group, WebForm webForm) {
        var thirdPartySubTypePh = (TextInputField) ChecklistUtils.getFieldInGroup(group, THIRD_PARTY_SUB_TYPE_PH);
        if (thirdPartySubTypePh == null) {
            thirdPartySubTypePh = TextInputField.builder().fieldId(THIRD_PARTY_SUB_TYPE_PH).build();
            group.getFields().add(thirdPartySubTypePh);
        }
        thirdPartySubTypePh.setIsActive(true);
        thirdPartySubTypePh.incrementOrder();
        thirdPartySubTypePh.setLabel("Third party sub type for PH(s)");
        thirdPartySubTypePh.setEnabled(false);
        thirdPartySubTypePh.setMandatory(false);
        thirdPartySubTypePh.setDisplayIf(null);
        thirdPartySubTypePh.setLabelBold(false);
        thirdPartySubTypePh.setSourceSystem("From Connect");
        selectedValueFromWebForm(THIRD_PARTY_SUB_TYPE_PH, webForm).ifPresent(thirdPartySubTypePh::setSelectedValue);
    }

    private void evaluateMrlTrustee(Group group, WebForm webForm) {
        var mrlTrustee = (SelectInputField) ChecklistUtils.getFieldInGroup(group, MRL_TRUSTEE);
        if (mrlTrustee == null) {
            mrlTrustee = SelectInputField.builder().fieldId(MRL_TRUSTEE).build();
            group.getFields().add(mrlTrustee);
        }
        mrlTrustee.setIsActive(true);
        mrlTrustee.incrementOrder();
        mrlTrustee.setLabel("MRL Trustee in a participating juridiction");
        mrlTrustee.setEnabled(true);
        mrlTrustee.setMandatory(true);
        mrlTrustee.setDisplayIf("#forcedDisplayIf");
        mrlTrustee.setLabelBold(false);
        mrlTrustee.setSourceSystem(null);
        mrlTrustee.setOptions(referenceDataRepositoryService.getReferenceDataOptionsByDomain(YES_NO_DOMAIN));
    }

    private void evaluateAppFormSigned(Group group, WebForm webForm) {
        var appFormSigned = (SelectInputField) ChecklistUtils.getFieldInGroup(group, APP_FORM_SIGNED);
        if (appFormSigned == null) {
            appFormSigned = SelectInputField.builder().fieldId(APP_FORM_SIGNED).build();
            group.getFields().add(appFormSigned);
        }
        appFormSigned.setIsActive(true);
        appFormSigned.incrementOrder();
        appFormSigned.setLabel("Application Form signed by PH?");
        appFormSigned.setEnabled(false);
        appFormSigned.setMandatory(false);
        appFormSigned.setDisplayIf(null);
        appFormSigned.setLabelBold(false);
        appFormSigned.setSourceSystem("From Connect");
        appFormSigned.setOptions(referenceDataRepositoryService.getReferenceDataOptionsByDomain(YES_NO_DOMAIN));
    }

    private void evaluateTrustResidenceCountryRisk(Group group, WebForm webForm) {
        var trustResidenceCountryRisk = (TextInputField) ChecklistUtils.getFieldInGroup(group, TRUST_RESIDENCE_COUNTRY_RISK);
        if (trustResidenceCountryRisk == null) {
            trustResidenceCountryRisk = TextInputField.builder().fieldId(TRUST_RESIDENCE_COUNTRY_RISK).build();
            group.getFields().add(trustResidenceCountryRisk);
        }
        trustResidenceCountryRisk.setIsActive(true);
        trustResidenceCountryRisk.incrementOrder();
        trustResidenceCountryRisk.setLabel("Trust residence country");
        trustResidenceCountryRisk.setEnabled(false);
        trustResidenceCountryRisk.setMandatory(false);
        trustResidenceCountryRisk.setDisplayIf("#forcedDisplayIf");
        trustResidenceCountryRisk.setLabelBold(false);
        trustResidenceCountryRisk.setSourceSystem("From CLASS");
        selectedValueFromWebForm(TRUST_RESIDENCE_COUNTRY_RISK, webForm).ifPresent(trustResidenceCountryRisk::setSelectedValue);
    }

    private void evaluateProxyCountryRisk(Group group, WebForm webForm) {
        var proxyCountryRisk = (TextInputField) ChecklistUtils.getFieldInGroup(group, PROXY_COUNTRY_RISK);
        if (proxyCountryRisk == null) {
            proxyCountryRisk = TextInputField.builder().fieldId(PROXY_COUNTRY_RISK).build();
            group.getFields().add(proxyCountryRisk);
        }
        proxyCountryRisk.setIsActive(true);
        proxyCountryRisk.incrementOrder();
        proxyCountryRisk.setLabel("Proxy residence country");
        proxyCountryRisk.setEnabled(false);
        proxyCountryRisk.setMandatory(false);
        proxyCountryRisk.setDisplayIf("#forcedDisplayIf");
        proxyCountryRisk.setLabelBold(false);
        proxyCountryRisk.setSourceSystem("From CLASS");
        selectedValueFromWebForm(PROXY_COUNTRY_RISK, webForm).ifPresent(proxyCountryRisk::setSelectedValue);
    }

    private void evaluateLaDifferentToPh(Group group, WebForm webForm) {
        var laDifferentToPh = (SelectInputField) ChecklistUtils.getFieldInGroup(group, LA_DIFFERENT_TO_PH);
        if (laDifferentToPh == null) {
            laDifferentToPh = SelectInputField.builder().fieldId(LA_DIFFERENT_TO_PH).build();
            group.getFields().add(laDifferentToPh);
        }
        laDifferentToPh.setIsActive(true);
        laDifferentToPh.incrementOrder();
        laDifferentToPh.setLabel("LA different to PH");
        laDifferentToPh.setEnabled(false);
        laDifferentToPh.setMandatory(false);
        laDifferentToPh.setDisplayIf("#forcedDisplayIf");
        laDifferentToPh.setLabelBold(false);
        laDifferentToPh.setSourceSystem("From Connect");
        selectedValueFromWebForm(LA_DIFFERENT_TO_PH, webForm).ifPresent(laDifferentToPh::setSelectedValue);
    }

    private void evaluateLaResidenceCountryRisk(Group group, WebForm webForm) {
        var laResidenceCountryRisk = (TextInputField) ChecklistUtils.getFieldInGroup(group, LA_RESIDENCE_COUNTRY_RISK);
        if (laResidenceCountryRisk == null) {
            laResidenceCountryRisk = TextInputField.builder().fieldId(LA_RESIDENCE_COUNTRY_RISK).build();
            group.getFields().add(laResidenceCountryRisk);
        }
        laResidenceCountryRisk.setIsActive(true);
        laResidenceCountryRisk.incrementOrder();
        laResidenceCountryRisk.setLabel("LA residence country");
        laResidenceCountryRisk.setEnabled(false);
        laResidenceCountryRisk.setMandatory(false);
        laResidenceCountryRisk.setDisplayIf("#forcedDisplayIf");
        laResidenceCountryRisk.setLabelBold(false);
        laResidenceCountryRisk.setSourceSystem("From CLASS");
        selectedValueFromWebForm(LA_RESIDENCE_COUNTRY_RISK, webForm).ifPresent(laResidenceCountryRisk::setSelectedValue);
    }

    private void evaluateFormerSwissLa(Group group, WebForm webForm) {
        var formerSwissLa = (SelectInputField) ChecklistUtils.getFieldInGroup(group, FORMER_SWISS_LA);
        if (formerSwissLa == null) {
            formerSwissLa = SelectInputField.builder().fieldId(FORMER_SWISS_LA).build();
            group.getFields().add(formerSwissLa);
        }
        formerSwissLa.setIsActive(true);
        formerSwissLa.incrementOrder();
        formerSwissLa.setLabel("Any former Swiss residency known for LA(s)");
        formerSwissLa.setEnabled(true);
        formerSwissLa.setMandatory(true);
        formerSwissLa.setDisplayIf("#LA_DIFFERENT_TO_PH# == \"YES\"");
        formerSwissLa.setLabelBold(false);
        formerSwissLa.setSourceSystem(null);
        formerSwissLa.setOptions(referenceDataRepositoryService.getReferenceDataOptionsByDomain(YES_NO_DOMAIN));
    }

    private void evaluateProofDeregistrationLa(Group group, WebForm webForm) {
        var proofDeregistrationLa = (SelectInputField) ChecklistUtils.getFieldInGroup(group, PROOF_DEREGISTRATION_LA);
        if (proofDeregistrationLa == null) {
            proofDeregistrationLa = SelectInputField.builder().fieldId(PROOF_DEREGISTRATION_LA).build();
            group.getFields().add(proofDeregistrationLa);
        }
        proofDeregistrationLa.setIsActive(true);
        proofDeregistrationLa.incrementOrder();
        proofDeregistrationLa.setLabel("Proof of deregistration received for LA(s)");
        proofDeregistrationLa.setEnabled(true);
        proofDeregistrationLa.setMandatory(true);
        proofDeregistrationLa.setDisplayIf("#FORMER_SWISS_LA# == \"YES\"");
        proofDeregistrationLa.setLabelBold(false);
        proofDeregistrationLa.setSourceSystem(null);
        proofDeregistrationLa.setOptions(referenceDataRepositoryService.getReferenceDataOptionsByDomain(YES_NO_DOMAIN));
    }

    private void evaluateSettlorResidenceCountryRisk(Group group, WebForm webForm) {
        var settlorResidenceCountryRisk = (TextInputField) ChecklistUtils.getFieldInGroup(group, SETTLOR_RESIDENCE_COUNTRY_RISK);
        if (settlorResidenceCountryRisk == null) {
            settlorResidenceCountryRisk = TextInputField.builder().fieldId(SETTLOR_RESIDENCE_COUNTRY_RISK).build();
            group.getFields().add(settlorResidenceCountryRisk);
        }
        settlorResidenceCountryRisk.setIsActive(true);
        settlorResidenceCountryRisk.incrementOrder();
        settlorResidenceCountryRisk.setLabel("Settlor residence country");
        settlorResidenceCountryRisk.setEnabled(false);
        settlorResidenceCountryRisk.setMandatory(false);
        settlorResidenceCountryRisk.setDisplayIf("#forcedDisplayIf");
        settlorResidenceCountryRisk.setLabelBold(false);
        settlorResidenceCountryRisk.setSourceSystem("From CLASS");
        selectedValueFromWebForm(SETTLOR_RESIDENCE_COUNTRY_RISK, webForm).ifPresent(settlorResidenceCountryRisk::setSelectedValue);
    }

    private void evaluateAppFormSignedLa(Group group, WebForm webForm) {
        var appFormSignedLa = (SelectInputField) ChecklistUtils.getFieldInGroup(group, APP_FORM_SIGNED_LA);
        if (appFormSignedLa == null) {
            appFormSignedLa = SelectInputField.builder().fieldId(APP_FORM_SIGNED_LA).build();
            group.getFields().add(appFormSignedLa);
        }
        appFormSignedLa.setIsActive(true);
        appFormSignedLa.incrementOrder();
        appFormSignedLa.setLabel("Application Form signed by LA?");
        appFormSignedLa.setEnabled(true);
        appFormSignedLa.setMandatory(true);
        appFormSignedLa.setDisplayIf("#LA_DIFFERENT_TO_PH# == \"YES\"");
        appFormSignedLa.setLabelBold(false);
        appFormSignedLa.setSourceSystem(null);
        appFormSignedLa.setOptions(referenceDataRepositoryService.getReferenceDataOptionsByDomain(YES_NO_DOMAIN));
    }

    private void evaluateLaDifferentBen(Group group, WebForm webForm) {
        var laDifferentBen = (SelectInputField) ChecklistUtils.getFieldInGroup(group, LA_DIFFERENT_BEN);
        if (laDifferentBen == null) {
            laDifferentBen = SelectInputField.builder().fieldId(LA_DIFFERENT_BEN).build();
            group.getFields().add(laDifferentBen);
        }
        laDifferentBen.setIsActive(true);
        laDifferentBen.incrementOrder();
        laDifferentBen.setLabel("LA different to BEN");
        laDifferentBen.setEnabled(true);
        laDifferentBen.setMandatory(true);
        laDifferentBen.setDisplayIf("#forcedDisplayIf");
        laDifferentBen.setLabelBold(false);
        laDifferentBen.setSourceSystem(null);
        laDifferentBen.setOptions(referenceDataRepositoryService.getReferenceDataOptionsByDomain(YES_NO_DOMAIN));
    }

    private void evaluateDateOfBirth(Group group, WebForm webForm) {
        var dateOfBirth = (TextInputField) ChecklistUtils.getFieldInGroup(group, DATE_OF_BIRTH);
        if (dateOfBirth == null) {
            dateOfBirth = TextInputField.builder().fieldId(DATE_OF_BIRTH).build();
            group.getFields().add(dateOfBirth);
        }
        dateOfBirth.setIsActive(true);
        dateOfBirth.incrementOrder();
        dateOfBirth.setLabel("Age of youngest LA");
        dateOfBirth.setEnabled(true);
        dateOfBirth.setMandatory(true);
        dateOfBirth.setDisplayIf(null);
        dateOfBirth.setLabelBold(false);
        dateOfBirth.setSourceSystem(null);
    }

    private void evaluatePolicySignedCountry(Group group, WebForm webForm) {
        var policySignedCountry = (SelectInputField) ChecklistUtils.getFieldInGroup(group, POLICY_SIGNED_COUNTRY);
        if (policySignedCountry == null) {
            policySignedCountry = SelectInputField.builder().fieldId(POLICY_SIGNED_COUNTRY).build();
            group.getFields().add(policySignedCountry);
        }
        policySignedCountry.setIsActive(true);
        policySignedCountry.incrementOrder();
        policySignedCountry.setLabel("Policy Signed Country");
        policySignedCountry.setEnabled(true);
        policySignedCountry.setMandatory(true);
        policySignedCountry.setDisplayIf(null);
        policySignedCountry.setLabelBold(false);
        policySignedCountry.setSourceSystem(null);
        policySignedCountry.setOptions(referenceDataRepositoryService.getReferenceDataOptionsByDomain(COUNTRY_DOMAIN));
    }

    private void evaluateSendingAddress(Group group, WebForm webForm) {
        var sendingAddress = (SelectInputField) ChecklistUtils.getFieldInGroup(group, SENDING_ADDRESS);
        if (sendingAddress == null) {
            sendingAddress = SelectInputField.builder().fieldId(SENDING_ADDRESS).build();
            group.getFields().add(sendingAddress);
        }
        sendingAddress.setIsActive(true);
        sendingAddress.incrementOrder();
        sendingAddress.setLabel("Sending Address Country");
        sendingAddress.setEnabled(false);
        sendingAddress.setMandatory(false);
        sendingAddress.setDisplayIf(null);
        sendingAddress.setLabelBold(false);
        sendingAddress.setSourceSystem("From Connect");
        selectedValueFromWebForm(SENDING_ADDRESS, webForm).ifPresent(sendingAddress::setSelectedValue);
    }

    private void evaluateIrrevocableBen(Group group, WebForm webForm) {
        var irrevocableBen = (SelectInputField) ChecklistUtils.getFieldInGroup(group, IRREVOCABLE_BEN);
        if (irrevocableBen == null) {
            irrevocableBen = SelectInputField.builder().fieldId(IRREVOCABLE_BEN).build();
            group.getFields().add(irrevocableBen);
        }
        irrevocableBen.setIsActive(true);
        irrevocableBen.incrementOrder();
        irrevocableBen.setLabel("Irrevocable BEN");
        irrevocableBen.setEnabled(false);
        irrevocableBen.setMandatory(false);
        irrevocableBen.setDisplayIf(null);
        irrevocableBen.setLabelBold(false);
        irrevocableBen.setSourceSystem("From CLASS");
        selectedValueFromWebForm(IRREVOCABLE_BEN, webForm).ifPresent(irrevocableBen::setSelectedValue);
    }

    private void evaluateIrrevocableBenCountry(Group group, WebForm webForm) {
        var irrevocableBenCountry = (TextInputField) ChecklistUtils.getFieldInGroup(group, IRREVOCABLE_BEN_COUNTRY);
        if (irrevocableBenCountry == null) {
            irrevocableBenCountry = TextInputField.builder().fieldId(IRREVOCABLE_BEN_COUNTRY).build();
            group.getFields().add(irrevocableBenCountry);
        }
        irrevocableBenCountry.setIsActive(true);
        irrevocableBenCountry.incrementOrder();
        irrevocableBenCountry.setLabel("Irrevocable BEN residence country");
        irrevocableBenCountry.setEnabled(false);
        irrevocableBenCountry.setMandatory(false);
        irrevocableBenCountry.setDisplayIf("#forcedDisplayIf");
        irrevocableBenCountry.setLabelBold(false);
        irrevocableBenCountry.setSourceSystem("From CLASS");
        selectedValueFromWebForm(IRREVOCABLE_BEN_COUNTRY, webForm).ifPresent(irrevocableBenCountry::setSelectedValue);
    }

    private void evaluateAmlClause(Group group, WebForm webForm) {
        var amlClause = (SelectInputField) ChecklistUtils.getFieldInGroup(group, AML_CLAUSE);
        if (amlClause == null) {
            amlClause = SelectInputField.builder().fieldId(AML_CLAUSE).build();
            group.getFields().add(amlClause);
        }
        amlClause.setIsActive(true);
        amlClause.incrementOrder();
        amlClause.setLabel("AML clause ticked");
        amlClause.setEnabled(true);
        amlClause.setMandatory(true);
        amlClause.setDisplayIf(null);
        amlClause.setLabelBold(false);
        amlClause.setSourceSystem(null);
        amlClause.setOptions(referenceDataRepositoryService.getReferenceDataOptionsByDomain(YES_NO_DOMAIN));
    }

    private void evaluatePhDifferentToEbo(Group group, WebForm webForm) {
        var phDifferentToEbo = (SelectInputField) ChecklistUtils.getFieldInGroup(group, PH_DIFFERENT_TO_EBO);
        if (phDifferentToEbo == null) {
            phDifferentToEbo = SelectInputField.builder().fieldId(PH_DIFFERENT_TO_EBO).build();
            group.getFields().add(phDifferentToEbo);
        }
        phDifferentToEbo.setIsActive(true);
        phDifferentToEbo.incrementOrder();
        phDifferentToEbo.setLabel("PH different to EBO");
        phDifferentToEbo.setEnabled(false);
        phDifferentToEbo.setMandatory(false);
        phDifferentToEbo.setDisplayIf(null);
        phDifferentToEbo.setLabelBold(false);
        phDifferentToEbo.setSourceSystem("From CLASS");
        selectedValueFromWebForm(PH_DIFFERENT_TO_EBO, webForm).ifPresent(phDifferentToEbo::setSelectedValue);
    }

    private void evaluateThirdPartySubTypeEbo(Group group, WebForm webForm) {
        var thirdPartySubTypeEbo = (TextInputField) ChecklistUtils.getFieldInGroup(group, THIRD_PARTY_SUB_TYPE_EBO);
        if (thirdPartySubTypeEbo == null) {
            thirdPartySubTypeEbo = TextInputField.builder().fieldId(THIRD_PARTY_SUB_TYPE_EBO).build();
            group.getFields().add(thirdPartySubTypeEbo);
        }
        thirdPartySubTypeEbo.setIsActive(true);
        thirdPartySubTypeEbo.incrementOrder();
        thirdPartySubTypeEbo.setLabel("PH different to Third party sub type for EBO");
        thirdPartySubTypeEbo.setEnabled(false);
        thirdPartySubTypeEbo.setMandatory(false);
        thirdPartySubTypeEbo.setDisplayIf("#PH_DIFFERENT_TO_EBO# == \"YES\"");
        thirdPartySubTypeEbo.setLabelBold(false);
        thirdPartySubTypeEbo.setSourceSystem("From CLASS");
        selectedValueFromWebForm(THIRD_PARTY_SUB_TYPE_EBO, webForm).ifPresent(thirdPartySubTypeEbo::setSelectedValue);
    }

    private void evaluateEboResidenceCountryRisk(Group group, WebForm webForm) {
        var eboResidenceCountryRisk = (TextInputField) ChecklistUtils.getFieldInGroup(group, EBO_RESIDENCE_COUNTRY_RISK);
        if (eboResidenceCountryRisk == null) {
            eboResidenceCountryRisk = TextInputField.builder().fieldId(EBO_RESIDENCE_COUNTRY_RISK).build();
            group.getFields().add(eboResidenceCountryRisk);
        }
        eboResidenceCountryRisk.setIsActive(true);
        eboResidenceCountryRisk.incrementOrder();
        eboResidenceCountryRisk.setLabel("EBO residence country");
        eboResidenceCountryRisk.setEnabled(false);
        eboResidenceCountryRisk.setMandatory(false);
        eboResidenceCountryRisk.setDisplayIf("#forcedDisplayIf");
        eboResidenceCountryRisk.setLabelBold(false);
        eboResidenceCountryRisk.setSourceSystem("From CLASS");
        selectedValueFromWebForm(EBO_RESIDENCE_COUNTRY_RISK, webForm).ifPresent(eboResidenceCountryRisk::setSelectedValue);
    }

    private void evaluateFormerSwissEbo(Group group, WebForm webForm) {
        var formerSwissEbo = (SelectInputField) ChecklistUtils.getFieldInGroup(group, FORMER_SWISS_EBO);
        if (formerSwissEbo == null) {
            formerSwissEbo = SelectInputField.builder().fieldId(FORMER_SWISS_EBO).build();
            group.getFields().add(formerSwissEbo);
        }
        formerSwissEbo.setIsActive(true);
        formerSwissEbo.incrementOrder();
        formerSwissEbo.setLabel("Any former Swiss residency known for EBO(s)");
        formerSwissEbo.setEnabled(true);
        formerSwissEbo.setMandatory(true);
        formerSwissEbo.setDisplayIf("#PH_DIFFERENT_TO_EBO# == \"YES\"");
        formerSwissEbo.setLabelBold(false);
        formerSwissEbo.setSourceSystem(null);
        formerSwissEbo.setOptions(referenceDataRepositoryService.getReferenceDataOptionsByDomain(YES_NO_DOMAIN));
    }

    private void evaluateProofDeregistrationEbo(Group group, WebForm webForm) {
        var proofDeregistrationEbo = (SelectInputField) ChecklistUtils.getFieldInGroup(group, PROOF_DEREGISTRATION_EBO);
        if (proofDeregistrationEbo == null) {
            proofDeregistrationEbo = SelectInputField.builder().fieldId(PROOF_DEREGISTRATION_EBO).build();
            group.getFields().add(proofDeregistrationEbo);
        }
        proofDeregistrationEbo.setIsActive(true);
        proofDeregistrationEbo.incrementOrder();
        proofDeregistrationEbo.setLabel("Proof of deregistration received for EBO(s)");
        proofDeregistrationEbo.setEnabled(true);
        proofDeregistrationEbo.setMandatory(true);
        proofDeregistrationEbo.setDisplayIf("#FORMER_SWISS_EBO# == \"YES\"");
        proofDeregistrationEbo.setLabelBold(false);
        proofDeregistrationEbo.setSourceSystem(null);
        proofDeregistrationEbo.setOptions(referenceDataRepositoryService.getReferenceDataOptionsByDomain(YES_NO_DOMAIN));
    }

    private void evaluateTrusteeResidenceCountryRisk(Group group, WebForm webForm) {
        var trusteeResidenceCountryRisk = (TextInputField) ChecklistUtils.getFieldInGroup(group, TRUSTEE_RESIDENCE_COUNTRY_RISK);
        if (trusteeResidenceCountryRisk == null) {
            trusteeResidenceCountryRisk = TextInputField.builder().fieldId(TRUSTEE_RESIDENCE_COUNTRY_RISK).build();
            group.getFields().add(trusteeResidenceCountryRisk);
        }
        trusteeResidenceCountryRisk.setIsActive(true);
        trusteeResidenceCountryRisk.incrementOrder();
        trusteeResidenceCountryRisk.setLabel("Trustee residence country");
        trusteeResidenceCountryRisk.setEnabled(false);
        trusteeResidenceCountryRisk.setMandatory(false);
        trusteeResidenceCountryRisk.setDisplayIf("#forcedDisplayIf");
        trusteeResidenceCountryRisk.setLabelBold(false);
        trusteeResidenceCountryRisk.setSourceSystem("From CLASS");
        selectedValueFromWebForm(TRUSTEE_RESIDENCE_COUNTRY_RISK, webForm).ifPresent(trusteeResidenceCountryRisk::setSelectedValue);
    }

    private void evaluateBeneficiaryResidenceCountryRisk(Group group, WebForm webForm) {
        var beneficiaryResidenceCountryRisk = (TextInputField) ChecklistUtils.getFieldInGroup(group, BENEFICIARY_RESIDENCE_COUNTRY_RISK);
        if (beneficiaryResidenceCountryRisk == null) {
            beneficiaryResidenceCountryRisk = TextInputField.builder().fieldId(BENEFICIARY_RESIDENCE_COUNTRY_RISK).build();
            group.getFields().add(beneficiaryResidenceCountryRisk);
        }
        beneficiaryResidenceCountryRisk.setIsActive(true);
        beneficiaryResidenceCountryRisk.incrementOrder();
        beneficiaryResidenceCountryRisk.setLabel("Beneficiary residence country");
        beneficiaryResidenceCountryRisk.setEnabled(false);
        beneficiaryResidenceCountryRisk.setMandatory(false);
        beneficiaryResidenceCountryRisk.setDisplayIf("#forcedDisplayIf");
        beneficiaryResidenceCountryRisk.setLabelBold(false);
        beneficiaryResidenceCountryRisk.setSourceSystem("From CLASS");
        selectedValueFromWebForm(BENEFICIARY_RESIDENCE_COUNTRY_RISK, webForm).ifPresent(beneficiaryResidenceCountryRisk::setSelectedValue);
    }

    private void evaluateUsIndicia(Group group, WebForm webForm) {
        var usIndicia = (SelectInputField) ChecklistUtils.getFieldInGroup(group, US_INDICIA);
        if (usIndicia == null) {
            usIndicia = SelectInputField.builder().fieldId(US_INDICIA).build();
            group.getFields().add(usIndicia);
        }
        usIndicia.setIsActive(true);
        usIndicia.incrementOrder();
        usIndicia.setLabel("US indicia detected");
        usIndicia.setEnabled(true);
        usIndicia.setMandatory(true);
        usIndicia.setDisplayIf(null);
        usIndicia.setLabelBold(false);
        usIndicia.setSourceSystem(null);
        usIndicia.setOptions(referenceDataRepositoryService.getReferenceDataOptionsByDomain(YES_NO_DOMAIN));
    }

    private void evaluateFatcaFormRefused(Group group, WebForm webForm) {
        var fatcaFormRefused = (SelectInputField) ChecklistUtils.getFieldInGroup(group, FATCA_FORM_REFUSED);
        if (fatcaFormRefused == null) {
            fatcaFormRefused = SelectInputField.builder().fieldId(FATCA_FORM_REFUSED).build();
            group.getFields().add(fatcaFormRefused);
        }
        fatcaFormRefused.setIsActive(true);
        fatcaFormRefused.incrementOrder();
        fatcaFormRefused.setLabel("Did the PH/EBO refuse to sign the FATCA/CRS/AEOI forms and this after several reminders to sign them?");
        fatcaFormRefused.setEnabled(true);
        fatcaFormRefused.setMandatory(true);
        fatcaFormRefused.setDisplayIf(null);
        fatcaFormRefused.setLabelBold(false);
        fatcaFormRefused.setSourceSystem(null);
        fatcaFormRefused.setOptions(referenceDataRepositoryService.getReferenceDataOptionsByDomain(YES_NO_DOMAIN));
    }

    private void evaluateFatcaFormInconsistent(Group group, WebForm webForm) {
        var fatcaFormInconsistent = (SelectInputField) ChecklistUtils.getFieldInGroup(group, FATCA_FORM_INCONSISTENT);
        if (fatcaFormInconsistent == null) {
            fatcaFormInconsistent = SelectInputField.builder().fieldId(FATCA_FORM_INCONSISTENT).build();
            group.getFields().add(fatcaFormInconsistent);
        }
        fatcaFormInconsistent.setIsActive(true);
        fatcaFormInconsistent.incrementOrder();
        fatcaFormInconsistent.setLabel("Is there any unjustified inconsistency between the information provided in the FATCA/CRS/AEOI form and the information collected for AML/KYC purposes (e.g. TIN, tax residency, etc.) and this without any legitimate reason?");
        fatcaFormInconsistent.setEnabled(true);
        fatcaFormInconsistent.setMandatory(true);
        fatcaFormInconsistent.setDisplayIf(null);
        fatcaFormInconsistent.setLabelBold(false);
        fatcaFormInconsistent.setSourceSystem(null);
        fatcaFormInconsistent.setOptions(referenceDataRepositoryService.getReferenceDataOptionsByDomain(YES_NO_DOMAIN));
    }

    private void evaluateTpBlock(Group group, WebForm webForm) {
        var tpBlock = (SelectInputField) ChecklistUtils.getFieldInGroup(group, TP_BLOCK);
        if (tpBlock == null) {
            tpBlock = SelectInputField.builder().fieldId(TP_BLOCK).build();
            group.getFields().add(tpBlock);
        }
        tpBlock.setIsActive(true);
        tpBlock.incrementOrder();
        tpBlock.setLabel("Transaction block in CLASS for compliance");
        tpBlock.setEnabled(false);
        tpBlock.setMandatory(false);
        tpBlock.setDisplayIf(null);
        tpBlock.setLabelBold(false);
        tpBlock.setSourceSystem("From CLASS");
        selectedValueFromWebForm(TP_BLOCK, webForm).ifPresent(tpBlock::setSelectedValue);
    }
}
