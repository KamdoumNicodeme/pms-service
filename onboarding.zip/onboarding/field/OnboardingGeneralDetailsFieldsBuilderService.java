package com.lombardinternational.casemanagement.service.decision.domain.service.checklist.onboarding.field;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Field;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Group;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.policy.Policy;
import com.lombardinternational.casemanagement.service.decision.domain.model.transaction.BusinessTransaction;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.checklist.FieldBuilderService;
import org.springframework.stereotype.Service;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.OnboardingChecklistIds.*;

import java.util.List;
import java.util.Map;

@Service
public class OnboardingGeneralDetailsFieldsBuilderService extends OnboardingChecklistFieldsBuilderSupport implements FieldBuilderService {
    @Override
    public void buildField(final WebForm webForm, final ScreenDescription screenDescription, final Group group, final Policy policy, final BusinessTransaction transaction, final Map<String,List<String>> overallCaseRisk) {
        Field.resetFieldId();
        evaluateContractType(group, webForm);
        evaluatePolicyNumber(group, webForm);
        evaluatePolicyCur(group, webForm);
        evaluateExpectedPrem(group, webForm);
        evaluateExpectedPremEur(group, webForm);
        evaluateNewClient(group, webForm);
        evaluateTotalBeNavPolicyEur(group, webForm);
        evaluateTotalNavPolicyEur(group, webForm);
        evaluateCountryOfLaw(group, webForm);
        evaluateResidenceCountry(group, webForm);
        evaluateRdrCompliant(group, webForm);
        evaluateMarketConsultant(group, webForm);
        evaluateInvestManagerCode(group, webForm);
        evaluateInvestManagerName(group, webForm);
        evaluateEsgMandateSelected(group, webForm);
        evaluateEsgStrategyName(group, webForm);
        evaluateProxyAlignImaClass(group, webForm);
        evaluateCustodianCountry(group, webForm);
        evaluateCustodianBankName(group, webForm);
        evaluateAccountOpenedCountry(group, webForm);
        evaluateAccountOpenedInEea(group, webForm);
        evaluateMultiProduct(group, webForm);
        evaluateNumberProduct(group, webForm);
        evaluateBusinessOrigin(group, webForm);
        evaluatePhResidenceCountryRisk(group, webForm);
        evaluateOffShoreIndicia(group, webForm);
        evaluatePhFiscalCountry(group, webForm);
        evaluateTaxResidenceInconsistent(group, webForm);
        evaluatePhTypeAssessment(group, webForm);
        evaluatePhNonFinancial(group, webForm);
        evaluateEntitySameAsFatca(group, webForm);
        evaluatePhLegalEntityArrangement(group, webForm);
        evaluateEvidenceKnownLegalEntity(group, webForm);
        evaluatePhLegalEntity(group, webForm);
        evaluatePaidFromAppointed(group, webForm);
        evaluateFormerSwissPh(group, webForm);
        evaluateProofDeregistrationPh(group, webForm);
        evaluateThirdPartySubTypePh(group, webForm);
        evaluateMrlTrustee(group, webForm);
        evaluateAppFormSigned(group, webForm);
        evaluateTrustResidenceCountryRisk(group, webForm);
        evaluateProxyCountryRisk(group, webForm);
        evaluateLaDifferentToPh(group, webForm);
        evaluateLaResidenceCountryRisk(group, webForm);
        evaluateFormerSwissLa(group, webForm);
        evaluateProofDeregistrationLa(group, webForm);
        evaluateSettlorResidenceCountryRisk(group, webForm);
        evaluateAppFormSignedLa(group, webForm);
        evaluateLaDifferentBen(group, webForm);
        evaluateDateOfBirth(group, webForm);
        evaluatePolicySignedCountry(group, webForm);
        evaluateSendingAddress(group, webForm);
        evaluateIrrevocableBen(group, webForm);
        evaluateIrrevocableBenCountry(group, webForm);
        evaluateAmlClause(group, webForm);
        evaluatePhDifferentToEbo(group, webForm);
        evaluateThirdPartySubTypeEbo(group, webForm);
        evaluateEboResidenceCountryRisk(group, webForm);
        evaluateFormerSwissEbo(group, webForm);
        evaluateProofDeregistrationEbo(group, webForm);
        evaluateTrusteeResidenceCountryRisk(group, webForm);
        evaluateBeneficiaryResidenceCountryRisk(group, webForm);
        evaluateUsIndicia(group, webForm);
        evaluateFatcaFormRefused(group, webForm);
        evaluateFatcaFormInconsistent(group, webForm);
        evaluateTpBlock(group, webForm);
    }

    private void evaluateContractType(Group group, WebForm webForm) {
        applyField(group, new OnboardingFieldDefinition(CONTRACT_TYPE, FieldKind.SELECT, "Contract type", false, false,
                "#forcedValue", null, false, "From Connect", false), webForm);
    }

    private void evaluatePolicyNumber(Group group, WebForm webForm) {
        applyField(group, new OnboardingFieldDefinition(POLICY_NUMBER, FieldKind.TEXT, "Policy number", false, false,
                "#forcedValue", null, false, "From Connect", false), webForm);
    }

    private void evaluatePolicyCur(Group group, WebForm webForm) {
        applyField(group, new OnboardingFieldDefinition(POLICY_CUR, FieldKind.TEXT, "Policy ccy", false, false,
                "#forcedValue", null, false, "From Connect", false), webForm);
    }

    private void evaluateExpectedPrem(Group group, WebForm webForm) {
        applyField(group, new OnboardingFieldDefinition(EXPECTED_PREM, FieldKind.NUMBER, "Expected premium (in policy currency)", false, false,
                "#forcedValue", null, false, "From Connect", false), webForm);
    }

    private void evaluateExpectedPremEur(Group group, WebForm webForm) {
        applyField(group, new OnboardingFieldDefinition(EXPECTED_PREM_EUR, FieldKind.NUMBER, "Expected premium (in EUR)", false, false,
                "#forcedValue", "#POLICY_CUR# != \"EUR\"", false, "From Connect", false), webForm);
    }

    private void evaluateNewClient(Group group, WebForm webForm) {
        applyField(group, new OnboardingFieldDefinition(NEW_CLIENT, FieldKind.SELECT, "New client", true, true,
                "YES\u00acYes;NO\u00acNo", null, false, null, false), webForm);
    }

    private void evaluateTotalBeNavPolicyEur(Group group, WebForm webForm) {
        applyField(group, new OnboardingFieldDefinition(TOTAL_BE_NAV_POLICY_EUR, FieldKind.NUMBER, "Total existing BE NAV", false, false,
                "#forcedValue", "#NEW_CLIENT# == \"NO\" && #BUSINESS_ORIGIN# == \"BE\"", false, null, false), webForm);
    }

    private void evaluateTotalNavPolicyEur(Group group, WebForm webForm) {
        applyField(group, new OnboardingFieldDefinition(TOTAL_NAV_POLICY_EUR, FieldKind.NUMBER, "Total existing NAV linked to the same EBO, excluding this expected premium", false, false,
                "#forcedValue", "#NEW_CLIENT# == \"NO\" && #BUSINESS_ORIGIN# != \"BE\"", false, null, false), webForm);
    }

    private void evaluateCountryOfLaw(Group group, WebForm webForm) {
        applyField(group, new OnboardingFieldDefinition(COUNTRY_OF_LAW, FieldKind.SELECT, "Country of applicable law", false, false,
                "#forcedValue", null, false, "From Connect", false), webForm);
    }

    private void evaluateResidenceCountry(Group group, WebForm webForm) {
        applyField(group, new OnboardingFieldDefinition(RESIDENCE_COUNTRY, FieldKind.TEXT_AREA, "Riskiest / Missing country of residence", false, true,
                "#forcedValue", null, false, "From CLASS", false), webForm);
    }

    private void evaluateRdrCompliant(Group group, WebForm webForm) {
        applyField(group, new OnboardingFieldDefinition(RDR_COMPLIANT, FieldKind.SELECT, "Is it RDR compliant?", true, true,
                "YES\u00acYes;NO\u00acNo;NA\u00acN/A", "#COUNTRY_OF_LAW# == \"GB\"", false, null, false), webForm);
    }

    private void evaluateMarketConsultant(Group group, WebForm webForm) {
        applyField(group, new OnboardingFieldDefinition(MARKET_CONSULTANT, FieldKind.TEXT, "Marketing consultant", true, false,
                null, null, false, null, false), webForm);
    }

    private void evaluateInvestManagerCode(Group group, WebForm webForm) {
        applyField(group, new OnboardingFieldDefinition(INVEST_MANAGER_CODE, FieldKind.TEXT, "Investment manager code", false, false,
                "#forcedValue", null, false, "From Connect", true), webForm);
    }

    private void evaluateInvestManagerName(Group group, WebForm webForm) {
        applyField(group, new OnboardingFieldDefinition(INVEST_MANAGER_NAME, FieldKind.TEXT, "Investment manager name", false, false,
                "#forcedValue", null, false, "From Connect", true), webForm);
    }

    private void evaluateEsgMandateSelected(Group group, WebForm webForm) {
        applyField(group, new OnboardingFieldDefinition(ESG_MANDATE_SELECTED, FieldKind.SELECT, "Art. 8/9 ESG mandate selected?", false, false,
                "#forcedValue", null, false, "From Connect", true), webForm);
    }

    private void evaluateEsgStrategyName(Group group, WebForm webForm) {
        applyField(group, new OnboardingFieldDefinition(ESG_STRATEGY_NAME, FieldKind.TEXT, "ESG Stragegy Name", false, false,
                "#forcedValue", "#ESG_MANDATE_SELECTED_$# == \"YES_PRE_VALIDATED\" || #ESG_MANDATE_SELECTED_$# == \"YES_TO_BE_REVIEWED\"", false, "From Connect", true), webForm);
    }

    private void evaluateProxyAlignImaClass(Group group, WebForm webForm) {
        applyField(group, new OnboardingFieldDefinition(PROXY_ALIGN_IMA_CLASS, FieldKind.SELECT, "Proxy to IM to charge their fees (debited by partner)?", true, true,
                "YES\u00acYes;NO\u00acNo", null, false, null, true), webForm);
    }

    private void evaluateCustodianCountry(Group group, WebForm webForm) {
        applyField(group, new OnboardingFieldDefinition(CUSTODIAN_COUNTRY, FieldKind.SELECT, "Custodian country", false, false,
                "#forcedValue", null, false, "From Connect", true), webForm);
    }

    private void evaluateCustodianBankName(Group group, WebForm webForm) {
        applyField(group, new OnboardingFieldDefinition(CUSTODIAN_BANK_NAME, FieldKind.TEXT, "Custodian bank name", false, false,
                "#forcedValue", null, false, "From Connect", true), webForm);
    }

    private void evaluateAccountOpenedCountry(Group group, WebForm webForm) {
        applyField(group, new OnboardingFieldDefinition(ACCOUNT_OPENED_COUNTRY, FieldKind.SELECT, "Account opened country", true, true,
                "countriesString", null, false, null, true), webForm);
    }

    private void evaluateAccountOpenedInEea(Group group, WebForm webForm) {
        applyField(group, new OnboardingFieldDefinition(ACCOUNT_OPENED_IN_EEA, FieldKind.SELECT, "Account opened in a bank located in the EEA?", false, true,
                "#forcedValue", null, false, null, true), webForm);
    }

    private void evaluateMultiProduct(Group group, WebForm webForm) {
        applyField(group, new OnboardingFieldDefinition(MULTI_PRODUCT, FieldKind.SELECT, "Multi product", false, false,
                "#forcedValue", null, false, "From Connect", false), webForm);
    }

    private void evaluateNumberProduct(Group group, WebForm webForm) {
        applyField(group, new OnboardingFieldDefinition(NUMBER_PRODUCT, FieldKind.TEXT, "Number of added product", false, false,
                "#forcedValue", "#MULTI_PRODUCT# == \"YES\"", false, "From Connect", false), webForm);
    }

    private void evaluateBusinessOrigin(Group group, WebForm webForm) {
        applyField(group, new OnboardingFieldDefinition(BUSINESS_ORIGIN, FieldKind.SELECT, "Business Origin", false, false,
                "#forcedValue", null, false, "From Connect", false), webForm);
    }

    private void evaluatePhResidenceCountryRisk(Group group, WebForm webForm) {
        applyField(group, new OnboardingFieldDefinition(PH_RESIDENCE_COUNTRY_RISK, FieldKind.TEXT, "PH(s) residence country", false, false,
                "#forcedValue", "#forcedDisplayIf", false, "From CLASS", false), webForm);
    }

    private void evaluateOffShoreIndicia(Group group, WebForm webForm) {
        applyField(group, new OnboardingFieldDefinition(OFF_SHORE_INDICIA, FieldKind.SELECT, "(Belgian Branch) Off-shore indicia found ?", false, true,
                "#forcedValue", "#forcedDisplayIf", false, "From CLASS and converted", false), webForm);
    }

    private void evaluatePhFiscalCountry(Group group, WebForm webForm) {
        applyField(group, new OnboardingFieldDefinition(PH_FISCAL_COUNTRY, FieldKind.TEXT, "PH(s) fiscal country", false, false,
                "#forcedValue", null, false, "From Connect", false), webForm);
    }

    private void evaluateTaxResidenceInconsistent(Group group, WebForm webForm) {
        applyField(group, new OnboardingFieldDefinition(TAX_RESIDENCE_INCONSISTENT, FieldKind.SELECT, "Is there any unjustified inconsistency in the information provided concerning the tax residence of the PH/EBO and this without any legitimate reason?", true, true,
                "YES\u00acYes;NO\u00acNo", null, false, null, false), webForm);
    }

    private void evaluatePhTypeAssessment(Group group, WebForm webForm) {
        applyField(group, new OnboardingFieldDefinition(PH_TYPE_ASSESSMENT, FieldKind.TEXT, "PH type assessment", false, true,
                "#forcedValue", null, false, "From CLASS", false), webForm);
    }

    private void evaluatePhNonFinancial(Group group, WebForm webForm) {
        applyField(group, new OnboardingFieldDefinition(PH_NON_FINANCIAL, FieldKind.SELECT, "Is the PH a passive Non Financial Entity (Passive NFE)?", true, true,
                "YES\u00acYes;NO\u00acNo", "#PH_TYPE_ASSESSMENT# != \"PH Type=Physical\"", false, null, false), webForm);
    }

    private void evaluateEntitySameAsFatca(Group group, WebForm webForm) {
        applyField(group, new OnboardingFieldDefinition(ENTITY_SAME_AS_FATCA, FieldKind.SELECT, "Are the controlling persons of the entity as mentioned in the FATCA/CRS/AEOI form the same individuals as those identified as EBOs for AML purposes and disclosed in the KYC form?", true, true,
                "YES\u00acYes;NO\u00acNo", "#PH_TYPE_ASSESSMENT# != \"PH Type=Physical\" && #PH_NON_FINANCIAL# == \"YES\"", false, null, false), webForm);
    }

    private void evaluatePhLegalEntityArrangement(Group group, WebForm webForm) {
        applyField(group, new OnboardingFieldDefinition(PH_LEGAL_ENTITY_ARRANGEMENT, FieldKind.SELECT, "Is the PH a legal entity or a legal arrangement (e.g. trust, foundation,...) located in a country which is not the tax country of residence or place of regular economic or professional activities/interests of the EBO?", true, true,
                "YES\u00acYes;NO\u00acNo;NA\u00ac(N/A for trust with professional trustee based in EU)", "#forcedDisplayIf", false, null, false), webForm);
    }

    private void evaluateEvidenceKnownLegalEntity(Group group, WebForm webForm) {
        applyField(group, new OnboardingFieldDefinition(EVIDENCE_KNOWN_LEGAL_ENTITY, FieldKind.SELECT, "Did you collect supporting evidence that the legal entity or the legal arrangement is known by the tax authorities of the country of residence of the EBO or could the PH demonstrate that its establishment complies with the legal provisions of the country of residence of the PH/EBO?", true, true,
                "YES\u00acYes;NO\u00acNo", "#forcedDisplayIf", false, null, false), webForm);
    }

    private void evaluatePhLegalEntity(Group group, WebForm webForm) {
        applyField(group, new OnboardingFieldDefinition(PH_LEGAL_ENTITY, FieldKind.SELECT, "Is the PH a legal entity (excluding soci\u00e9t\u00e9 simple or any legal arrangement such as trust, fideicomiso, foundation or fiduciary)?", true, true,
                "YES\u00acYes;NO\u00acNo", "#forcedDisplayIf", false, null, false), webForm);
    }

    private void evaluatePaidFromAppointed(Group group, WebForm webForm) {
        applyField(group, new OnboardingFieldDefinition(PAID_FROM_APPOINTED, FieldKind.SELECT, "Is the premium paid from the appointed beneficiary who is a natural person ?", true, true,
                "YES\u00acYes;NO\u00acNo", "#PH_TYPE_ASSESSMENT# != \"PH Type=Physical\" && #PH_LEGAL_ENTITY# == \"YES\"", false, null, false), webForm);
    }

    private void evaluateFormerSwissPh(Group group, WebForm webForm) {
        applyField(group, new OnboardingFieldDefinition(FORMER_SWISS_PH, FieldKind.SELECT, "Any former Swiss residency known for PH(s)", true, true,
                "YES\u00acYes;NO\u00acNo", null, false, null, false), webForm);
    }

    private void evaluateProofDeregistrationPh(Group group, WebForm webForm) {
        applyField(group, new OnboardingFieldDefinition(PROOF_DEREGISTRATION_PH, FieldKind.SELECT, "Proof of deregistration known for PH(s)", true, true,
                "YES\u00acYes;NO\u00acNo", "#FORMER_SWISS_PH# == \"YES\"", false, null, false), webForm);
    }

    private void evaluateThirdPartySubTypePh(Group group, WebForm webForm) {
        applyField(group, new OnboardingFieldDefinition(THIRD_PARTY_SUB_TYPE_PH, FieldKind.TEXT, "Third party sub type for PH(s)", false, false,
                "#forcedValue", null, false, "From Connect", true), webForm);
    }

    private void evaluateMrlTrustee(Group group, WebForm webForm) {
        applyField(group, new OnboardingFieldDefinition(MRL_TRUSTEE, FieldKind.SELECT, "MRL Trustee in a participating juridiction", true, true,
                "YES\u00acYes;NO\u00acNo", "#forcedDisplayIf", false, null, false), webForm);
    }

    private void evaluateAppFormSigned(Group group, WebForm webForm) {
        applyField(group, new OnboardingFieldDefinition(APP_FORM_SIGNED, FieldKind.SELECT, "Application Form signed by PH?", false, false,
                "YES\u00acYes;NO\u00acNo", null, false, "From Connect", false), webForm);
    }

    private void evaluateTrustResidenceCountryRisk(Group group, WebForm webForm) {
        applyField(group, new OnboardingFieldDefinition(TRUST_RESIDENCE_COUNTRY_RISK, FieldKind.TEXT, "Trust residence country", false, false,
                "#forcedValue", "#forcedDisplayIf", false, "From CLASS", false), webForm);
    }

    private void evaluateProxyCountryRisk(Group group, WebForm webForm) {
        applyField(group, new OnboardingFieldDefinition(PROXY_COUNTRY_RISK, FieldKind.TEXT, "Proxy residence country", false, false,
                "#forcedValue", "#forcedDisplayIf", false, "From CLASS", false), webForm);
    }

    private void evaluateLaDifferentToPh(Group group, WebForm webForm) {
        applyField(group, new OnboardingFieldDefinition(LA_DIFFERENT_TO_PH, FieldKind.SELECT, "LA different to PH", false, false,
                "#forcedValue", "#forcedDisplayIf", false, "From Connect", false), webForm);
    }

    private void evaluateLaResidenceCountryRisk(Group group, WebForm webForm) {
        applyField(group, new OnboardingFieldDefinition(LA_RESIDENCE_COUNTRY_RISK, FieldKind.TEXT, "LA residence country", false, false,
                "#forcedValue", "#forcedDisplayIf", false, "From CLASS", false), webForm);
    }

    private void evaluateFormerSwissLa(Group group, WebForm webForm) {
        applyField(group, new OnboardingFieldDefinition(FORMER_SWISS_LA, FieldKind.SELECT, "Any former Swiss residency known for LA(s)", true, true,
                "YES\u00acYes;NO\u00acNo", "#LA_DIFFERENT_TO_PH# == \"YES\"", false, null, false), webForm);
    }

    private void evaluateProofDeregistrationLa(Group group, WebForm webForm) {
        applyField(group, new OnboardingFieldDefinition(PROOF_DEREGISTRATION_LA, FieldKind.SELECT, "Proof of deregistration received for LA(s)", true, true,
                "YES\u00acYes;NO\u00acNo", "#FORMER_SWISS_LA# == \"YES\"", false, null, false), webForm);
    }

    private void evaluateSettlorResidenceCountryRisk(Group group, WebForm webForm) {
        applyField(group, new OnboardingFieldDefinition(SETTLOR_RESIDENCE_COUNTRY_RISK, FieldKind.TEXT, "Settlor residence country", false, false,
                "#forcedValue", "#forcedDisplayIf", false, "From CLASS", false), webForm);
    }

    private void evaluateAppFormSignedLa(Group group, WebForm webForm) {
        applyField(group, new OnboardingFieldDefinition(APP_FORM_SIGNED_LA, FieldKind.SELECT, "Application Form signed by LA?", true, true,
                "YES\u00acYes;NO\u00acNo", "#LA_DIFFERENT_TO_PH# == \"YES\"", false, null, false), webForm);
    }

    private void evaluateLaDifferentBen(Group group, WebForm webForm) {
        applyField(group, new OnboardingFieldDefinition(LA_DIFFERENT_BEN, FieldKind.SELECT, "LA different to BEN", true, true,
                "YES\u00acYes;NO\u00acNo", "#forcedDisplayIf", false, null, false), webForm);
    }

    private void evaluateDateOfBirth(Group group, WebForm webForm) {
        applyField(group, new OnboardingFieldDefinition(DATE_OF_BIRTH, FieldKind.TEXT, "Age of youngest LA", true, true,
                null, null, false, null, false), webForm);
    }

    private void evaluatePolicySignedCountry(Group group, WebForm webForm) {
        applyField(group, new OnboardingFieldDefinition(POLICY_SIGNED_COUNTRY, FieldKind.SELECT, "Policy Signed Country", true, true,
                "countriesString", null, false, null, false), webForm);
    }

    private void evaluateSendingAddress(Group group, WebForm webForm) {
        applyField(group, new OnboardingFieldDefinition(SENDING_ADDRESS, FieldKind.SELECT, "Sending Address Country", false, false,
                "#forcedValue", null, false, "From Connect", false), webForm);
    }

    private void evaluateIrrevocableBen(Group group, WebForm webForm) {
        applyField(group, new OnboardingFieldDefinition(IRREVOCABLE_BEN, FieldKind.SELECT, "Irrevocable BEN", false, false,
                "#forcedValue", null, false, "From CLASS", false), webForm);
    }

    private void evaluateIrrevocableBenCountry(Group group, WebForm webForm) {
        applyField(group, new OnboardingFieldDefinition(IRREVOCABLE_BEN_COUNTRY, FieldKind.TEXT, "Irrevocable BEN residence country", false, false,
                "#forcedValue", "#forcedDisplayIf", false, "From CLASS", false), webForm);
    }

    private void evaluateAmlClause(Group group, WebForm webForm) {
        applyField(group, new OnboardingFieldDefinition(AML_CLAUSE, FieldKind.SELECT, "AML clause ticked", true, true,
                "YES\u00acYes;NO\u00acNo", null, false, null, false), webForm);
    }

    private void evaluatePhDifferentToEbo(Group group, WebForm webForm) {
        applyField(group, new OnboardingFieldDefinition(PH_DIFFERENT_TO_EBO, FieldKind.SELECT, "PH different to EBO", false, false,
                "#forcedValue", null, false, "From CLASS", false), webForm);
    }

    private void evaluateThirdPartySubTypeEbo(Group group, WebForm webForm) {
        applyField(group, new OnboardingFieldDefinition(THIRD_PARTY_SUB_TYPE_EBO, FieldKind.TEXT, "PH different to Third party sub type for EBO", false, false,
                "#forcedValue", "#PH_DIFFERENT_TO_EBO# == \"YES\"", false, "From CLASS", false), webForm);
    }

    private void evaluateEboResidenceCountryRisk(Group group, WebForm webForm) {
        applyField(group, new OnboardingFieldDefinition(EBO_RESIDENCE_COUNTRY_RISK, FieldKind.TEXT, "EBO residence country", false, false,
                "#forcedValue", "#forcedDisplayIf", false, "From CLASS", false), webForm);
    }

    private void evaluateFormerSwissEbo(Group group, WebForm webForm) {
        applyField(group, new OnboardingFieldDefinition(FORMER_SWISS_EBO, FieldKind.SELECT, "Any former Swiss residency known for EBO(s)", true, true,
                "YES\u00acYes;NO\u00acNo", "#PH_DIFFERENT_TO_EBO# == \"YES\"", false, null, false), webForm);
    }

    private void evaluateProofDeregistrationEbo(Group group, WebForm webForm) {
        applyField(group, new OnboardingFieldDefinition(PROOF_DEREGISTRATION_EBO, FieldKind.SELECT, "Proof of deregistration received for EBO(s)", true, true,
                "YES\u00acYes;NO\u00acNo", "#FORMER_SWISS_EBO# == \"YES\"", false, null, false), webForm);
    }

    private void evaluateTrusteeResidenceCountryRisk(Group group, WebForm webForm) {
        applyField(group, new OnboardingFieldDefinition(TRUSTEE_RESIDENCE_COUNTRY_RISK, FieldKind.TEXT, "Trustee residence country", false, false,
                "#forcedValue", "#forcedDisplayIf", false, "From CLASS", false), webForm);
    }

    private void evaluateBeneficiaryResidenceCountryRisk(Group group, WebForm webForm) {
        applyField(group, new OnboardingFieldDefinition(BENEFICIARY_RESIDENCE_COUNTRY_RISK, FieldKind.TEXT, "Beneficiary residence country", false, false,
                "#forcedValue", "#forcedDisplayIf", false, "From CLASS", false), webForm);
    }

    private void evaluateUsIndicia(Group group, WebForm webForm) {
        applyField(group, new OnboardingFieldDefinition(US_INDICIA, FieldKind.SELECT, "US indicia detected", true, true,
                "YES\u00acYes;NO\u00acNo", null, false, null, false), webForm);
    }

    private void evaluateFatcaFormRefused(Group group, WebForm webForm) {
        applyField(group, new OnboardingFieldDefinition(FATCA_FORM_REFUSED, FieldKind.SELECT, "Did the PH/EBO refuse to sign the FATCA/CRS/AEOI forms and this after several reminders to sign them?", true, true,
                "YES\u00acYes;NO\u00acNo", null, false, null, false), webForm);
    }

    private void evaluateFatcaFormInconsistent(Group group, WebForm webForm) {
        applyField(group, new OnboardingFieldDefinition(FATCA_FORM_INCONSISTENT, FieldKind.SELECT, "Is there any unjustified inconsistency between the information provided in the FATCA/CRS/AEOI form and the information collected for AML/KYC purposes (e.g. TIN, tax residency, etc.) and this without any legitimate reason?", true, true,
                "YES\u00acYes;NO\u00acNo", null, false, null, false), webForm);
    }

    private void evaluateTpBlock(Group group, WebForm webForm) {
        applyField(group, new OnboardingFieldDefinition(TP_BLOCK, FieldKind.SELECT, "Transaction block in CLASS for compliance", false, false,
                "#forcedValue", null, false, "From CLASS", false), webForm);
    }

}
