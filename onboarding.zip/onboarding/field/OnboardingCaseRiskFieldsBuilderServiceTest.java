package com.lombardinternational.casemanagement.service.decision.domain.service.checklist.onboarding.field;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.SelectInputField;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.TextAreaField;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.TextInputField;
import com.lombardinternational.casemanagement.service.decision.domain.utils.FieldHelper;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.OnboardingChecklistIds.*;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ReferenceConstants.COMPLIANCE_LEVEL_DOMAIN;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
class OnboardingCaseRiskFieldsBuilderServiceTest extends OnboardingFieldsBuilderTestSupport {

    @InjectMocks
    private OnboardingCaseRiskFieldsBuilderService builderService;

    @Test
    void buildCaseRiskFieldsOK() {

        var group = group(CASE_RISK_GROUP);

        builderService.buildField(webForm(), screenDescription(), group, policy(), transaction(), overallCaseRisk());

        assertEquals(4, group.getFields().size());
        FieldHelper.testFieldValue(RISK_VALUE, TextInputField.class, group, null, 1, "false", false, false);
        FieldHelper.testFieldValue(BLOCKED_VALUE, TextAreaField.class, group, null, 2, "#forcedDisplayIf", false, false);
        FieldHelper.testSelectFieldValue(PCS_REVIEW, SelectInputField.class, group, null, 3, "#forcedDisplayIf", true, false, 7);
        FieldHelper.testFieldValue(RISK_REASON, TextAreaField.class, group, null, 4, "#forcedDisplayIf", false, false);
        verify(referenceDataRepositoryService).getReferenceDataOptionsByDomainAndSelectedValue(COMPLIANCE_LEVEL_DOMAIN, null);
    }
}
