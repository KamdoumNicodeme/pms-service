package com.lombardinternational.casemanagement.service.decision.domain.service.checklist.onboarding.field;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Field;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Group;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.policy.Policy;
import com.lombardinternational.casemanagement.service.decision.domain.model.transaction.BusinessTransaction;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.checklist.FieldBuilderService;
import org.springframework.stereotype.Service;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.OnboardingChecklistIds.*;

import java.util.List;
import java.util.Map;

@Service
public class OnboardingSignatureFieldsBuilderService extends OnboardingChecklistFieldsBuilderSupport implements FieldBuilderService {
    @Override
    public void buildField(final WebForm webForm, final ScreenDescription screenDescription, final Group group, final Policy policy, final BusinessTransaction transaction, final Map<String,List<String>> overallCaseRisk) {
        Field.resetFieldId();
        evaluateSignatureType(group, webForm);
        evaluateProvider(group, webForm);
        evaluateEuAuthorisedProvider(group, webForm);
        evaluateClientIdentificationValidation(group, webForm);
        evaluateMultifactorAuthentication(group, webForm);
        evaluateOriginalSignedDocumentAuditLogCmt(group, webForm);
    }

    private void evaluateSignatureType(Group group, WebForm webForm) {
        applyField(group, new OnboardingFieldDefinition(SIGNATURE_TYPE, FieldKind.SELECT, "Signature Type?", true, true,
                "ELECTRONIC\u00acElectronic;WET\u00acWet;MULTIPLE\u00acMultiple", null, false, null, false), webForm);
    }

    private void evaluateProvider(Group group, WebForm webForm) {
        applyField(group, new OnboardingFieldDefinition(PROVIDER, FieldKind.SELECT, "Provider?", true, false,
                "INTERNAL_PROVIDER\u00acInternal Provider;PARTNER_ESIGN_SERVICE\u00acPartner e-signature service", "true", false, "false", false), webForm);
    }

    private void evaluateEuAuthorisedProvider(Group group, WebForm webForm) {
        applyField(group, new OnboardingFieldDefinition(EU_AUTHORISED_PROVIDER, FieldKind.CHECK_BOX, "EU authorised Provider?", true, true,
                null, "(#SIGNATURE_TYPE# == \"ELECTRONIC\" || #SIGNATURE_TYPE# == \"MULTIPLE\") && #PROVIDER# == \"PARTNER_ESIGN_SERVICE\"", false, null, false), webForm);
    }

    private void evaluateClientIdentificationValidation(Group group, WebForm webForm) {
        applyField(group, new OnboardingFieldDefinition(CLIENT_IDENTIFICATION_VALIDATION, FieldKind.CHECK_BOX, "Client Identification & Validation?", true, true,
                null, "(#SIGNATURE_TYPE# == \"ELECTRONIC\" || #SIGNATURE_TYPE# == \"MULTIPLE\") && (#PROVIDER# == \"PARTNER_ESIGN_SERVICE\" || #PROVIDER# == \"INTERNAL_PROVIDER\")", false, null, false), webForm);
    }

    private void evaluateMultifactorAuthentication(Group group, WebForm webForm) {
        applyField(group, new OnboardingFieldDefinition(MULTIFACTOR_AUTHENTICATION, FieldKind.CHECK_BOX, "Multifactor Authentication?", true, true,
                null, "(#SIGNATURE_TYPE# == \"ELECTRONIC\" || #SIGNATURE_TYPE# == \"MULTIPLE\") && #PROVIDER# == \"PARTNER_ESIGN_SERVICE\"", false, null, false), webForm);
    }

    private void evaluateOriginalSignedDocumentAuditLogCmt(Group group, WebForm webForm) {
        applyField(group, new OnboardingFieldDefinition(ORIGINAL_SIGNED_DOCUMENT_AUDIT_LOG_CMT, FieldKind.CHECK_BOX, "Original Signed Document + Audit Log in CMT?", true, true,
                null, "(#SIGNATURE_TYPE# == \"ELECTRONIC\" || #SIGNATURE_TYPE# == \"MULTIPLE\") && (#PROVIDER# == \"PARTNER_ESIGN_SERVICE\" || #PROVIDER# == \"INTERNAL_PROVIDER\")", false, null, false), webForm);
    }

}
