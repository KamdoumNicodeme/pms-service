package com.lombardinternational.casemanagement.service.decision.domain.service.checklist.onboarding.field;

import com.lombardinternational.casemanagement.service.decision.domain.model.policy.Policy;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.*;
import com.lombardinternational.casemanagement.service.decision.domain.model.transaction.BusinessTransaction;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.checklist.FieldBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.spi.repository.ReferenceDataRepositoryService;
import com.lombardinternational.casemanagement.service.decision.domain.utils.ChecklistUtils;
import java.util.List;
import java.util.Map;
import org.springframework.stereotype.Service;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.OnboardingChecklistIds.*;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ReferenceConstants.*;

@Service
public class OnboardingSignatureFieldsBuilderService extends OnboardingChecklistFieldsBuilderSupport implements FieldBuilderService {
    private final ReferenceDataRepositoryService referenceDataRepositoryService;

    public OnboardingSignatureFieldsBuilderService(ReferenceDataRepositoryService referenceDataRepositoryService) {
        this.referenceDataRepositoryService = referenceDataRepositoryService;
    }

    @Override
    public void buildField(final WebForm webForm, final ScreenDescription screenDescription, final Group group, final Policy policy, final BusinessTransaction transaction, final Map<String,List<String>> overallCaseRisk) {
        Field.resetFieldId();

        evaluateSignatureType(group, webForm);

        evaluateProvider(group, webForm);

        evaluateEuAuthorisedProvider(group, webForm);

        evaluateClientIdentificationValidation(group, webForm);

        evaluateMultifactorAuthentication(group, webForm);

        evaluateOriginalSignedDocumentAuditLogCmt(group, webForm);

    }

    private void evaluateSignatureType(Group group, WebForm webForm) {
        var signatureType = (SelectInputField) ChecklistUtils.getFieldInGroup(group, SIGNATURE_TYPE);
        if (signatureType == null) {
            signatureType = SelectInputField.builder().fieldId(SIGNATURE_TYPE).build();
            group.getFields().add(signatureType);
        }
        signatureType.setIsActive(true);
        signatureType.incrementOrder();
        signatureType.setLabel("Signature Type?");
        signatureType.setEnabled(true);
        signatureType.setMandatory(true);
        signatureType.setDisplayIf(null);
        signatureType.setLabelBold(false);
        signatureType.setSourceSystem(null);
        signatureType.setOptions(referenceDataRepositoryService.getReferenceDataOptionsByDomain(SIGNATURE_DOMAIN));
    }

    private void evaluateProvider(Group group, WebForm webForm) {
        var provider = (SelectInputField) ChecklistUtils.getFieldInGroup(group, PROVIDER);
        if (provider == null) {
            provider = SelectInputField.builder().fieldId(PROVIDER).build();
            group.getFields().add(provider);
        }
        provider.setIsActive(true);
        provider.incrementOrder();
        provider.setLabel("Provider?");
        provider.setEnabled(true);
        provider.setMandatory(false);
        provider.setDisplayIf("true");
        provider.setLabelBold(false);
        provider.setSourceSystem("false");
        provider.setOptions(referenceDataRepositoryService.getReferenceDataOptionsByDomain(PROVIDER_DOMAIN));
    }

    private void evaluateEuAuthorisedProvider(Group group, WebForm webForm) {
        var euAuthorisedProvider = (CheckBoxField) ChecklistUtils.getFieldInGroup(group, EU_AUTHORISED_PROVIDER);
        if (euAuthorisedProvider == null) {
            euAuthorisedProvider = CheckBoxField.builder().fieldId(EU_AUTHORISED_PROVIDER).build();
            group.getFields().add(euAuthorisedProvider);
        }
        euAuthorisedProvider.setIsActive(true);
        euAuthorisedProvider.incrementOrder();
        euAuthorisedProvider.setLabel("EU authorised Provider?");
        euAuthorisedProvider.setEnabled(true);
        euAuthorisedProvider.setMandatory(true);
        euAuthorisedProvider.setDisplayIf("(#SIGNATURE_TYPE# == \"ELECTRONIC\" || #SIGNATURE_TYPE# == \"MULTIPLE\") && #PROVIDER# == \"PARTNER_ESIGN_SERVICE\"");
        euAuthorisedProvider.setLabelBold(false);
        euAuthorisedProvider.setSourceSystem(null);
    }

    private void evaluateClientIdentificationValidation(Group group, WebForm webForm) {
        var clientIdentificationValidation = (CheckBoxField) ChecklistUtils.getFieldInGroup(group, CLIENT_IDENTIFICATION_VALIDATION);
        if (clientIdentificationValidation == null) {
            clientIdentificationValidation = CheckBoxField.builder().fieldId(CLIENT_IDENTIFICATION_VALIDATION).build();
            group.getFields().add(clientIdentificationValidation);
        }
        clientIdentificationValidation.setIsActive(true);
        clientIdentificationValidation.incrementOrder();
        clientIdentificationValidation.setLabel("Client Identification & Validation?");
        clientIdentificationValidation.setEnabled(true);
        clientIdentificationValidation.setMandatory(true);
        clientIdentificationValidation.setDisplayIf("(#SIGNATURE_TYPE# == \"ELECTRONIC\" || #SIGNATURE_TYPE# == \"MULTIPLE\") && (#PROVIDER# == \"PARTNER_ESIGN_SERVICE\" || #PROVIDER# == \"INTERNAL_PROVIDER\")");
        clientIdentificationValidation.setLabelBold(false);
        clientIdentificationValidation.setSourceSystem(null);
    }

    private void evaluateMultifactorAuthentication(Group group, WebForm webForm) {
        var multifactorAuthentication = (CheckBoxField) ChecklistUtils.getFieldInGroup(group, MULTIFACTOR_AUTHENTICATION);
        if (multifactorAuthentication == null) {
            multifactorAuthentication = CheckBoxField.builder().fieldId(MULTIFACTOR_AUTHENTICATION).build();
            group.getFields().add(multifactorAuthentication);
        }
        multifactorAuthentication.setIsActive(true);
        multifactorAuthentication.incrementOrder();
        multifactorAuthentication.setLabel("Multifactor Authentication?");
        multifactorAuthentication.setEnabled(true);
        multifactorAuthentication.setMandatory(true);
        multifactorAuthentication.setDisplayIf("(#SIGNATURE_TYPE# == \"ELECTRONIC\" || #SIGNATURE_TYPE# == \"MULTIPLE\") && #PROVIDER# == \"PARTNER_ESIGN_SERVICE\"");
        multifactorAuthentication.setLabelBold(false);
        multifactorAuthentication.setSourceSystem(null);
    }

    private void evaluateOriginalSignedDocumentAuditLogCmt(Group group, WebForm webForm) {
        var originalSignedDocumentAuditLogCmt = (CheckBoxField) ChecklistUtils.getFieldInGroup(group, ORIGINAL_SIGNED_DOCUMENT_AUDIT_LOG_CMT);
        if (originalSignedDocumentAuditLogCmt == null) {
            originalSignedDocumentAuditLogCmt = CheckBoxField.builder().fieldId(ORIGINAL_SIGNED_DOCUMENT_AUDIT_LOG_CMT).build();
            group.getFields().add(originalSignedDocumentAuditLogCmt);
        }
        originalSignedDocumentAuditLogCmt.setIsActive(true);
        originalSignedDocumentAuditLogCmt.incrementOrder();
        originalSignedDocumentAuditLogCmt.setLabel("Original Signed Document + Audit Log in CMT?");
        originalSignedDocumentAuditLogCmt.setEnabled(true);
        originalSignedDocumentAuditLogCmt.setMandatory(true);
        originalSignedDocumentAuditLogCmt.setDisplayIf("(#SIGNATURE_TYPE# == \"ELECTRONIC\" || #SIGNATURE_TYPE# == \"MULTIPLE\") && (#PROVIDER# == \"PARTNER_ESIGN_SERVICE\" || #PROVIDER# == \"INTERNAL_PROVIDER\")");
        originalSignedDocumentAuditLogCmt.setLabelBold(false);
        originalSignedDocumentAuditLogCmt.setSourceSystem(null);
    }
}
