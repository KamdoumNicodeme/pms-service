package com.lombardinternational.casemanagement.service.decision.domain.service.checklist.onboarding.field;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.NumberInputField;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.SelectInputField;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.TextInputField;
import com.lombardinternational.casemanagement.service.decision.domain.utils.FieldHelper;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.OnboardingChecklistIds.*;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ReferenceConstants.COUNTRY_DOMAIN;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ReferenceConstants.YES_NO_DOMAIN;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ReferenceConstants.YES_NO_NA_NEW_BUSINESS_VALUES_DOMAIN;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
class OnboardingGeneralDetailsFieldsBuilderServiceTest extends OnboardingFieldsBuilderTestSupport {

    @InjectMocks
    private OnboardingGeneralDetailsFieldsBuilderService builderService;

    @Test
    void buildGeneralDetailsFieldsOK() {

        var group = group(GENERAL_DETAILS_GROUP);

        builderService.buildField(webForm(), screenDescription(), group, policy(), transaction(), overallCaseRisk());

        assertEquals(66, group.getFields().size());
        FieldHelper.testFieldValue(CONTRACT_TYPE, SelectInputField.class, group, null, 1, null, false, false);
        FieldHelper.testFieldValue(POLICY_NUMBER, TextInputField.class, group, null, 2, null, false, false);
        FieldHelper.testFieldValue(EXPECTED_PREM, NumberInputField.class, group, null, 4, null, false, false);
        FieldHelper.testSelectFieldValue(NEW_CLIENT, SelectInputField.class, group, null, 6, null, true, true, 2);
        FieldHelper.testSelectFieldValue(COUNTRY_OF_LAW, SelectInputField.class, group, null, 9, null, false, false, 3);
        FieldHelper.testSelectFieldValue(RDR_COMPLIANT, SelectInputField.class, group, null, 11, "#COUNTRY_OF_LAW# == \"GB\"", true, true, 3);
        FieldHelper.testSelectFieldValue(ACCOUNT_OPENED_COUNTRY, SelectInputField.class, group, null, 20, null, true, true, 3);
        FieldHelper.testSelectFieldValue(US_INDICIA, SelectInputField.class, group, null, 63, null, true, true, 2);
        FieldHelper.testFieldValue(TP_BLOCK, SelectInputField.class, group, null, 66, null, false, false);
        verify(referenceDataRepositoryService, org.mockito.Mockito.atLeastOnce()).getReferenceDataOptionsByDomain(YES_NO_DOMAIN);
        verify(referenceDataRepositoryService, org.mockito.Mockito.atLeastOnce()).getReferenceDataOptionsByDomain(COUNTRY_DOMAIN);
        verify(referenceDataRepositoryService).getReferenceDataOptionsByDomainAndSelectedValue(COUNTRY_DOMAIN, null);
        verify(referenceDataRepositoryService).getReferenceDataOptionsByDomain(YES_NO_NA_NEW_BUSINESS_VALUES_DOMAIN);
    }
}
