package com.lombardinternational.casemanagement.service.decision.domain.service.checklist.onboarding.field;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.NumberInputField;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.SelectInputField;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.TextAreaField;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.TextInputField;
import com.lombardinternational.casemanagement.service.decision.domain.utils.FieldHelper;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.OnboardingChecklistIds.*;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ReferenceConstants.YES_NO_DOMAIN;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
class OnboardingPricingApprovalFieldsBuilderServiceTest extends OnboardingFieldsBuilderTestSupport {

    @InjectMocks
    private OnboardingPricingApprovalFieldsBuilderService builderService;

    @Test
    void buildPricingApprovalFieldsOK() {

        var group = group(PRICING_APPROVAL_GROUP);

        builderService.buildField(webForm(), screenDescription(), group, policy(), transaction(), overallCaseRisk());

        assertEquals(11, group.getFields().size());
        FieldHelper.testFieldValue(NTA_MARKUP_EXCEPTION, SelectInputField.class, group, null, 1, null, false, false);
        FieldHelper.testFieldValue(EXPLAIN_EXCEPTION, TextAreaField.class, group, null, 2, null, false, false);
        FieldHelper.testFieldValue(PRICING_APPROVAL_STAGE, TextInputField.class, group, null, 3, null, false, false);
        FieldHelper.testSelectFieldValue(IS_FAMILY_CASE, SelectInputField.class, group, null, 8, null, false, true, 2);
        FieldHelper.testFieldValue(FAMILY_CASE_POL_NBR, NumberInputField.class, group, null, 9, null, false, true);
        FieldHelper.testSelectFieldValue(PRICING_APPROVAL_CHECKED, SelectInputField.class, group, null, 11, null, true, true, 2);
        verify(referenceDataRepositoryService, org.mockito.Mockito.times(2)).getReferenceDataOptionsByDomain(YES_NO_DOMAIN);
    }
}
