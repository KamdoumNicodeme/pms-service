package com.lombardinternational.casemanagement.service.decision.domain.service.checklist.onboarding.field;

import com.lombardinternational.casemanagement.service.decision.domain.model.policy.Policy;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.*;
import com.lombardinternational.casemanagement.service.decision.domain.model.transaction.BusinessTransaction;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.checklist.FieldBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.spi.repository.ReferenceDataRepositoryService;
import com.lombardinternational.casemanagement.service.decision.domain.utils.ChecklistUtils;
import java.util.List;
import java.util.Map;
import org.springframework.stereotype.Service;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.OnboardingChecklistIds.*;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ReferenceConstants.*;

@Service
public class OnboardingDueDiligenceFieldsBuilderService extends OnboardingChecklistFieldsBuilderSupport implements FieldBuilderService {
    private final ReferenceDataRepositoryService referenceDataRepositoryService;

    public OnboardingDueDiligenceFieldsBuilderService(ReferenceDataRepositoryService referenceDataRepositoryService) {
        this.referenceDataRepositoryService = referenceDataRepositoryService;
    }

    @Override
    public void buildField(final WebForm webForm, final ScreenDescription screenDescription, final Group group, final Policy policy, final BusinessTransaction transaction, final Map<String,List<String>> overallCaseRisk) {
        Field.resetFieldId();

        evaluateIndustry(group, webForm);

        evaluatePosition(group, webForm);

        evaluateBackgroundDetails(group, webForm);

        evaluateRiskAssessment(group, webForm);

        evaluatePep(group, webForm);

        evaluateOriginatorPep(group, webForm);

        evaluateIsPepPayer(group, webForm);

        evaluateTccSigned(group, webForm);

        evaluateTccSignedRefused(group, webForm);

        evaluateIntroducingPartnerSigned(group, webForm);

        evaluateInfoProvidedVerified(group, webForm);

        evaluateNegativeFinding(group, webForm);

        evaluateNegativeFindingThirdParty(group, webForm);

        evaluateAtLeastOneSowOfKind(group, webForm);

        evaluateOriginatorWorldCheck(group, webForm);

        evaluateIsOnSanctionList(group, webForm);

        evaluateInsider(group, webForm);

        evaluateIsPhEboGoldenVisa(group, webForm);

        evaluateAnnualIncome(group, webForm);

        evaluate20PercentIncome(group, webForm);

        evaluateSourceOfWealth(group, webForm);

        evaluateMinimumWealth(group, webForm);

        evaluateWealthAllocationOk(group, webForm);

        evaluateWealthOriginatingCountry1Risk(group, webForm);

        evaluateWealthOriginatingCountry2Risk(group, webForm);

        evaluateWealthAllocation(group, webForm);

        evaluateTotalWealth(group, webForm);

        evaluateKycSupportingDocuments(group, webForm);

    }

    private void evaluateIndustry(Group group, WebForm webForm) {
        var industry = (SelectInputField) ChecklistUtils.getFieldInGroup(group, INDUSTRY);
        if (industry == null) {
            industry = SelectInputField.builder().fieldId(INDUSTRY).build();
            group.getFields().add(industry);
        }
        industry.setIsActive(true);
        industry.incrementOrder();
        industry.setLabel("Industry");
        industry.setEnabled(false);
        industry.setMandatory(true);
        industry.setDisplayIf(null);
        industry.setLabelBold(false);
        industry.setSourceSystem("From CLASS");
        selectedValueFromWebForm(INDUSTRY, webForm).ifPresent(industry::setSelectedValue);
        industry.setOptions(referenceDataRepositoryService.getReferenceDataOptionsByDomainAndSelectedValue(INDUSTRY_SECTOR_DOMAIN,
                industry.getSelectedValue()));
    }

    private void evaluatePosition(Group group, WebForm webForm) {
        var position = (SelectInputField) ChecklistUtils.getFieldInGroup(group, POSITION);
        if (position == null) {
            position = SelectInputField.builder().fieldId(POSITION).build();
            group.getFields().add(position);
        }
        position.setIsActive(true);
        position.incrementOrder();
        position.setLabel("Position");
        position.setEnabled(false);
        position.setMandatory(false);
        position.setDisplayIf("#forcedDisplayIf");
        position.setLabelBold(false);
        position.setSourceSystem("From CLASS");
        selectedValueFromWebForm(POSITION, webForm).ifPresent(position::setSelectedValue);
        position.setOptions(referenceDataRepositoryService.getReferenceDataOptionsByDomainAndSelectedValue(PROFESSION_DOMAIN,
                position.getSelectedValue()));
    }

    private void evaluateBackgroundDetails(Group group, WebForm webForm) {
        var backgroundDetails = (TextAreaField) ChecklistUtils.getFieldInGroup(group, BACKGROUND_DETAILS);
        if (backgroundDetails == null) {
            backgroundDetails = TextAreaField.builder().fieldId(BACKGROUND_DETAILS).build();
            group.getFields().add(backgroundDetails);
        }
        backgroundDetails.setIsActive(true);
        backgroundDetails.incrementOrder();
        backgroundDetails.setLabel("Profession background details");
        backgroundDetails.setEnabled(true);
        backgroundDetails.setMandatory(true);
        backgroundDetails.setDisplayIf(null);
        backgroundDetails.setLabelBold(false);
        backgroundDetails.setSourceSystem(null);
    }

    private void evaluateRiskAssessment(Group group, WebForm webForm) {
        var riskAssessment = (TextAreaField) ChecklistUtils.getFieldInGroup(group, RISK_ASSESSMENT);
        if (riskAssessment == null) {
            riskAssessment = TextAreaField.builder().fieldId(RISK_ASSESSMENT).build();
            group.getFields().add(riskAssessment);
        }
        riskAssessment.setIsActive(true);
        riskAssessment.incrementOrder();
        riskAssessment.setLabel("Profession risk assessment");
        riskAssessment.setEnabled(true);
        riskAssessment.setMandatory(true);
        riskAssessment.setDisplayIf(null);
        riskAssessment.setLabelBold(false);
        riskAssessment.setSourceSystem(null);
    }

    private void evaluatePep(Group group, WebForm webForm) {
        var pep = (SelectInputField) ChecklistUtils.getFieldInGroup(group, PEP);
        if (pep == null) {
            pep = SelectInputField.builder().fieldId(PEP).build();
            group.getFields().add(pep);
        }
        pep.setIsActive(true);
        pep.incrementOrder();
        pep.setLabel("Is there a PEP on the policy");
        pep.setEnabled(false);
        pep.setMandatory(true);
        pep.setDisplayIf(null);
        pep.setLabelBold(false);
        pep.setSourceSystem(null);
        selectedValueFromWebForm(PEP, webForm).ifPresent(pep::setSelectedValue);
    }

    private void evaluateOriginatorPep(Group group, WebForm webForm) {
        var originatorPep = (SelectInputField) ChecklistUtils.getFieldInGroup(group, ORIGINATOR_PEP);
        if (originatorPep == null) {
            originatorPep = SelectInputField.builder().fieldId(ORIGINATOR_PEP).build();
            group.getFields().add(originatorPep);
        }
        originatorPep.setIsActive(true);
        originatorPep.incrementOrder();
        originatorPep.setLabel("Is the Originator, linked to the source of funds to be invested, a PEP?");
        originatorPep.setEnabled(true);
        originatorPep.setMandatory(true);
        originatorPep.setDisplayIf("#forcedDisplayIf");
        originatorPep.setLabelBold(false);
        originatorPep.setSourceSystem(null);
        originatorPep.setOptions(referenceDataRepositoryService.getReferenceDataOptionsByDomain(YES_NO_DOMAIN));
    }

    private void evaluateIsPepPayer(Group group, WebForm webForm) {
        var isPepPayer = (SelectInputField) ChecklistUtils.getFieldInGroup(group, IS_PEP_PAYER);
        if (isPepPayer == null) {
            isPepPayer = SelectInputField.builder().fieldId(IS_PEP_PAYER).build();
            group.getFields().add(isPepPayer);
        }
        isPepPayer.setIsActive(true);
        isPepPayer.incrementOrder();
        isPepPayer.setLabel("Is one of the payer a PEP?");
        isPepPayer.setEnabled(true);
        isPepPayer.setMandatory(true);
        isPepPayer.setDisplayIf("#forcedDisplayIf");
        isPepPayer.setLabelBold(false);
        isPepPayer.setSourceSystem(null);
        isPepPayer.setOptions(referenceDataRepositoryService.getReferenceDataOptionsByDomain(YES_NO_DOMAIN));
    }

    private void evaluateTccSigned(Group group, WebForm webForm) {
        var tccSigned = (SelectInputField) ChecklistUtils.getFieldInGroup(group, TCC_SIGNED);
        if (tccSigned == null) {
            tccSigned = SelectInputField.builder().fieldId(TCC_SIGNED).build();
            group.getFields().add(tccSigned);
        }
        tccSigned.setIsActive(true);
        tccSigned.incrementOrder();
        tccSigned.setLabel("TCC duly signed received?");
        tccSigned.setEnabled(true);
        tccSigned.setMandatory(true);
        tccSigned.setDisplayIf(null);
        tccSigned.setLabelBold(false);
        tccSigned.setSourceSystem(null);
        tccSigned.setOptions(referenceDataRepositoryService.getReferenceDataOptionsByDomain(YES_NO_DOMAIN));
    }

    private void evaluateTccSignedRefused(Group group, WebForm webForm) {
        var tccSignedRefused = (SelectInputField) ChecklistUtils.getFieldInGroup(group, TCC_SIGNED_REFUSED);
        if (tccSignedRefused == null) {
            tccSignedRefused = SelectInputField.builder().fieldId(TCC_SIGNED_REFUSED).build();
            group.getFields().add(tccSignedRefused);
        }
        tccSignedRefused.setIsActive(true);
        tccSignedRefused.incrementOrder();
        tccSignedRefused.setLabel("Did the PH/EBO refuse to sign the TCC and this after several reminders to sign the form?");
        tccSignedRefused.setEnabled(true);
        tccSignedRefused.setMandatory(true);
        tccSignedRefused.setDisplayIf("#TCC_SIGNED# == \"NO\"");
        tccSignedRefused.setLabelBold(false);
        tccSignedRefused.setSourceSystem(null);
        tccSignedRefused.setOptions(referenceDataRepositoryService.getReferenceDataOptionsByDomain(YES_NO_DOMAIN));
    }

    private void evaluateIntroducingPartnerSigned(Group group, WebForm webForm) {
        var introducingPartnerSigned = (SelectInputField) ChecklistUtils.getFieldInGroup(group, INTRODUCING_PARTNER_SIGNED);
        if (introducingPartnerSigned == null) {
            introducingPartnerSigned = SelectInputField.builder().fieldId(INTRODUCING_PARTNER_SIGNED).build();
            group.getFields().add(introducingPartnerSigned);
        }
        introducingPartnerSigned.setIsActive(true);
        introducingPartnerSigned.incrementOrder();
        introducingPartnerSigned.setLabel("Introducing partner signs KYC questionnaire");
        introducingPartnerSigned.setEnabled(true);
        introducingPartnerSigned.setMandatory(true);
        introducingPartnerSigned.setDisplayIf(null);
        introducingPartnerSigned.setLabelBold(false);
        introducingPartnerSigned.setSourceSystem(null);
        introducingPartnerSigned.setOptions(referenceDataRepositoryService.getReferenceDataOptionsByDomain(YES_NO_DOMAIN));
    }

    private void evaluateInfoProvidedVerified(Group group, WebForm webForm) {
        var infoProvidedVerified = (SelectInputField) ChecklistUtils.getFieldInGroup(group, INFO_PROVIDED_VERIFIED);
        if (infoProvidedVerified == null) {
            infoProvidedVerified = SelectInputField.builder().fieldId(INFO_PROVIDED_VERIFIED).build();
            group.getFields().add(infoProvidedVerified);
        }
        infoProvidedVerified.setIsActive(true);
        infoProvidedVerified.incrementOrder();
        infoProvidedVerified.setLabel("Info provided on KYC questionnaire could be verified");
        infoProvidedVerified.setEnabled(true);
        infoProvidedVerified.setMandatory(true);
        infoProvidedVerified.setDisplayIf(null);
        infoProvidedVerified.setLabelBold(false);
        infoProvidedVerified.setSourceSystem(null);
        infoProvidedVerified.setOptions(referenceDataRepositoryService.getReferenceDataOptionsByDomain(YES_NO_DOMAIN));
    }

    private void evaluateNegativeFinding(Group group, WebForm webForm) {
        var negativeFinding = (SelectInputField) ChecklistUtils.getFieldInGroup(group, NEGATIVE_FINDING);
        if (negativeFinding == null) {
            negativeFinding = SelectInputField.builder().fieldId(NEGATIVE_FINDING).build();
            group.getFields().add(negativeFinding);
        }
        negativeFinding.setIsActive(true);
        negativeFinding.incrementOrder();
        negativeFinding.setLabel("Negative press finding / World check match (on all roles on policy)");
        negativeFinding.setEnabled(false);
        negativeFinding.setMandatory(true);
        negativeFinding.setDisplayIf(null);
        negativeFinding.setLabelBold(false);
        negativeFinding.setSourceSystem(null);
        selectedValueFromWebForm(NEGATIVE_FINDING, webForm).ifPresent(negativeFinding::setSelectedValue);
    }

    private void evaluateNegativeFindingThirdParty(Group group, WebForm webForm) {
        var negativeFindingThirdParty = (TextInputField) ChecklistUtils.getFieldInGroup(group, NEGATIVE_FINDING_THIRD_PARTY);
        if (negativeFindingThirdParty == null) {
            negativeFindingThirdParty = TextInputField.builder().fieldId(NEGATIVE_FINDING_THIRD_PARTY).build();
            group.getFields().add(negativeFindingThirdParty);
        }
        negativeFindingThirdParty.setIsActive(true);
        negativeFindingThirdParty.incrementOrder();
        negativeFindingThirdParty.setLabel("Negative press finding / Worldcheck match on following Third party(ies)");
        negativeFindingThirdParty.setEnabled(false);
        negativeFindingThirdParty.setMandatory(false);
        negativeFindingThirdParty.setDisplayIf("#forcedDisplayIf");
        negativeFindingThirdParty.setLabelBold(false);
        negativeFindingThirdParty.setSourceSystem(null);
        selectedValueFromWebForm(NEGATIVE_FINDING_THIRD_PARTY, webForm).ifPresent(negativeFindingThirdParty::setSelectedValue);
    }

    private void evaluateAtLeastOneSowOfKind(Group group, WebForm webForm) {
        var atLeastOneSowOfKind = (SelectInputField) ChecklistUtils.getFieldInGroup(group, AT_LEAST_ONE_SOW_OF_KIND);
        if (atLeastOneSowOfKind == null) {
            atLeastOneSowOfKind = SelectInputField.builder().fieldId(AT_LEAST_ONE_SOW_OF_KIND).build();
            group.getFields().add(atLeastOneSowOfKind);
        }
        atLeastOneSowOfKind.setIsActive(true);
        atLeastOneSowOfKind.incrementOrder();
        atLeastOneSowOfKind.setLabel("Invisible field : used as display if condition for ORIGINATOR_WORLD_CHECK");
        atLeastOneSowOfKind.setEnabled(false);
        atLeastOneSowOfKind.setMandatory(true);
        atLeastOneSowOfKind.setDisplayIf("false");
        atLeastOneSowOfKind.setLabelBold(false);
        atLeastOneSowOfKind.setSourceSystem(null);
        selectedValueFromWebForm(AT_LEAST_ONE_SOW_OF_KIND, webForm).ifPresent(atLeastOneSowOfKind::setSelectedValue);
    }

    private void evaluateOriginatorWorldCheck(Group group, WebForm webForm) {
        var originatorWorldCheck = (SelectInputField) ChecklistUtils.getFieldInGroup(group, ORIGINATOR_WORLD_CHECK);
        if (originatorWorldCheck == null) {
            originatorWorldCheck = SelectInputField.builder().fieldId(ORIGINATOR_WORLD_CHECK).build();
            group.getFields().add(originatorWorldCheck);
        }
        originatorWorldCheck.setIsActive(true);
        originatorWorldCheck.incrementOrder();
        originatorWorldCheck.setLabel("World check match or negative press found on originator");
        originatorWorldCheck.setEnabled(true);
        originatorWorldCheck.setMandatory(true);
        originatorWorldCheck.setDisplayIf("#forcedDisplayIf");
        originatorWorldCheck.setLabelBold(false);
        originatorWorldCheck.setSourceSystem(null);
        originatorWorldCheck.setOptions(referenceDataRepositoryService.getReferenceDataOptionsByDomain(YES_NO_DOMAIN));
    }

    private void evaluateIsOnSanctionList(Group group, WebForm webForm) {
        var isOnSanctionList = (SelectInputField) ChecklistUtils.getFieldInGroup(group, IS_ON_SANCTION_LIST);
        if (isOnSanctionList == null) {
            isOnSanctionList = SelectInputField.builder().fieldId(IS_ON_SANCTION_LIST).build();
            group.getFields().add(isOnSanctionList);
        }
        isOnSanctionList.setIsActive(true);
        isOnSanctionList.incrementOrder();
        isOnSanctionList.setLabel("Is there any person designated on a sanctions list on the policy?");
        isOnSanctionList.setEnabled(false);
        isOnSanctionList.setMandatory(true);
        isOnSanctionList.setDisplayIf(null);
        isOnSanctionList.setLabelBold(false);
        isOnSanctionList.setSourceSystem(null);
        selectedValueFromWebForm(IS_ON_SANCTION_LIST, webForm).ifPresent(isOnSanctionList::setSelectedValue);
    }

    private void evaluateInsider(Group group, WebForm webForm) {
        var insider = (SelectInputField) ChecklistUtils.getFieldInGroup(group, INSIDER);
        if (insider == null) {
            insider = SelectInputField.builder().fieldId(INSIDER).build();
            group.getFields().add(insider);
        }
        insider.setIsActive(true);
        insider.incrementOrder();
        insider.setLabel("Is the person an insider to any assets invested in the policy?");
        insider.setEnabled(false);
        insider.setMandatory(false);
        insider.setDisplayIf(null);
        insider.setLabelBold(false);
        insider.setSourceSystem(null);
        selectedValueFromWebForm(INSIDER, webForm).ifPresent(insider::setSelectedValue);
    }

    private void evaluateIsPhEboGoldenVisa(Group group, WebForm webForm) {
        var isPhEboGoldenVisa = (SelectInputField) ChecklistUtils.getFieldInGroup(group, IS_PH_EBO_GOLDEN_VISA);
        if (isPhEboGoldenVisa == null) {
            isPhEboGoldenVisa = SelectInputField.builder().fieldId(IS_PH_EBO_GOLDEN_VISA).build();
            group.getFields().add(isPhEboGoldenVisa);
        }
        isPhEboGoldenVisa.setIsActive(true);
        isPhEboGoldenVisa.incrementOrder();
        isPhEboGoldenVisa.setLabel("Is the PH / EBO a country national who applied for residence rights or citizenship in exchange of capital transfers purchase of property or government bonds or investment in corporate entities (who has a Golden Visa) or a Golden Passport");
        isPhEboGoldenVisa.setEnabled(false);
        isPhEboGoldenVisa.setMandatory(true);
        isPhEboGoldenVisa.setDisplayIf(null);
        isPhEboGoldenVisa.setLabelBold(false);
        isPhEboGoldenVisa.setSourceSystem(null);
        selectedValueFromWebForm(IS_PH_EBO_GOLDEN_VISA, webForm).ifPresent(isPhEboGoldenVisa::setSelectedValue);
    }

    private void evaluateAnnualIncome(Group group, WebForm webForm) {
        var annualIncome = (TextInputField) ChecklistUtils.getFieldInGroup(group, ANNUAL_INCOME);
        if (annualIncome == null) {
            annualIncome = TextInputField.builder().fieldId(ANNUAL_INCOME).build();
            group.getFields().add(annualIncome);
        }
        annualIncome.setIsActive(true);
        annualIncome.incrementOrder();
        annualIncome.setLabel("Annual Income");
        annualIncome.setEnabled(false);
        annualIncome.setMandatory(false);
        annualIncome.setDisplayIf(null);
        annualIncome.setLabelBold(false);
        annualIncome.setSourceSystem("From CLASS");
        selectedValueFromWebForm(ANNUAL_INCOME, webForm).ifPresent(annualIncome::setSelectedValue);
    }

    private void evaluate20PercentIncome(Group group, WebForm webForm) {
        var field20PercentIncome = (SelectInputField) ChecklistUtils.getFieldInGroup(group, _20_PERCENT_INCOME);
        if (field20PercentIncome == null) {
            field20PercentIncome = SelectInputField.builder().fieldId(_20_PERCENT_INCOME).build();
            group.getFields().add(field20PercentIncome);
        }
        field20PercentIncome.setIsActive(true);
        field20PercentIncome.incrementOrder();
        field20PercentIncome.setLabel("A portion of wealth is from inheritance / Gift / Donation / Divorce");
        field20PercentIncome.setEnabled(false);
        field20PercentIncome.setMandatory(false);
        field20PercentIncome.setDisplayIf(null);
        field20PercentIncome.setLabelBold(false);
        field20PercentIncome.setSourceSystem("From Connect");
        selectedValueFromWebForm(_20_PERCENT_INCOME, webForm).ifPresent(field20PercentIncome::setSelectedValue);
    }

    private void evaluateSourceOfWealth(Group group, WebForm webForm) {
        var sourceOfWealth = (TextInputField) ChecklistUtils.getFieldInGroup(group, SOURCE_OF_WEALTH);
        if (sourceOfWealth == null) {
            sourceOfWealth = TextInputField.builder().fieldId(SOURCE_OF_WEALTH).build();
            group.getFields().add(sourceOfWealth);
        }
        sourceOfWealth.setIsActive(true);
        sourceOfWealth.incrementOrder();
        sourceOfWealth.setLabel("Source of wealth description");
        sourceOfWealth.setEnabled(true);
        sourceOfWealth.setMandatory(false);
        sourceOfWealth.setDisplayIf(null);
        sourceOfWealth.setLabelBold(false);
        sourceOfWealth.setSourceSystem(null);
    }

    private void evaluateMinimumWealth(Group group, WebForm webForm) {
        var minimumWealth = (SelectInputField) ChecklistUtils.getFieldInGroup(group, MINIMUM_WEALTH);
        if (minimumWealth == null) {
            minimumWealth = SelectInputField.builder().fieldId(MINIMUM_WEALTH).build();
            group.getFields().add(minimumWealth);
        }
        minimumWealth.setIsActive(true);
        minimumWealth.incrementOrder();
        minimumWealth.setLabel("Minimum wealth > 250000\u20ac in transferrable assets (not including property)");
        minimumWealth.setEnabled(true);
        minimumWealth.setMandatory(true);
        minimumWealth.setDisplayIf(null);
        minimumWealth.setLabelBold(false);
        minimumWealth.setSourceSystem(null);
        minimumWealth.setOptions(referenceDataRepositoryService.getReferenceDataOptionsByDomain(YES_NO_DOMAIN));
    }

    private void evaluateWealthAllocationOk(Group group, WebForm webForm) {
        var wealthAllocationOk = (SelectInputField) ChecklistUtils.getFieldInGroup(group, WEALTH_ALLOCATION_OK);
        if (wealthAllocationOk == null) {
            wealthAllocationOk = SelectInputField.builder().fieldId(WEALTH_ALLOCATION_OK).build();
            group.getFields().add(wealthAllocationOk);
        }
        wealthAllocationOk.setIsActive(true);
        wealthAllocationOk.incrementOrder();
        wealthAllocationOk.setLabel("Wealth allocation in line with source");
        wealthAllocationOk.setEnabled(true);
        wealthAllocationOk.setMandatory(true);
        wealthAllocationOk.setDisplayIf(null);
        wealthAllocationOk.setLabelBold(false);
        wealthAllocationOk.setSourceSystem(null);
        wealthAllocationOk.setOptions(referenceDataRepositoryService.getReferenceDataOptionsByDomain(YES_NO_DOMAIN));
    }

    private void evaluateWealthOriginatingCountry1Risk(Group group, WebForm webForm) {
        var wealthOriginatingCountry1Risk = (TextInputField) ChecklistUtils.getFieldInGroup(group, WEALTH_ORIGINATING_COUNTRY_1_RISK);
        if (wealthOriginatingCountry1Risk == null) {
            wealthOriginatingCountry1Risk = TextInputField.builder().fieldId(WEALTH_ORIGINATING_COUNTRY_1_RISK).build();
            group.getFields().add(wealthOriginatingCountry1Risk);
        }
        wealthOriginatingCountry1Risk.setIsActive(true);
        wealthOriginatingCountry1Risk.incrementOrder();
        wealthOriginatingCountry1Risk.setLabel("Country 1 origin of premium");
        wealthOriginatingCountry1Risk.setEnabled(false);
        wealthOriginatingCountry1Risk.setMandatory(true);
        wealthOriginatingCountry1Risk.setDisplayIf(null);
        wealthOriginatingCountry1Risk.setLabelBold(false);
        wealthOriginatingCountry1Risk.setSourceSystem("From CLASS");
        selectedValueFromWebForm(WEALTH_ORIGINATING_COUNTRY_1_RISK, webForm).ifPresent(wealthOriginatingCountry1Risk::setSelectedValue);
    }

    private void evaluateWealthOriginatingCountry2Risk(Group group, WebForm webForm) {
        var wealthOriginatingCountry2Risk = (TextInputField) ChecklistUtils.getFieldInGroup(group, WEALTH_ORIGINATING_COUNTRY_2_RISK);
        if (wealthOriginatingCountry2Risk == null) {
            wealthOriginatingCountry2Risk = TextInputField.builder().fieldId(WEALTH_ORIGINATING_COUNTRY_2_RISK).build();
            group.getFields().add(wealthOriginatingCountry2Risk);
        }
        wealthOriginatingCountry2Risk.setIsActive(true);
        wealthOriginatingCountry2Risk.incrementOrder();
        wealthOriginatingCountry2Risk.setLabel("Country 2 origin of premium");
        wealthOriginatingCountry2Risk.setEnabled(false);
        wealthOriginatingCountry2Risk.setMandatory(false);
        wealthOriginatingCountry2Risk.setDisplayIf(null);
        wealthOriginatingCountry2Risk.setLabelBold(false);
        wealthOriginatingCountry2Risk.setSourceSystem("From CLASS");
        selectedValueFromWebForm(WEALTH_ORIGINATING_COUNTRY_2_RISK, webForm).ifPresent(wealthOriginatingCountry2Risk::setSelectedValue);
    }

    private void evaluateWealthAllocation(Group group, WebForm webForm) {
        var wealthAllocation = (TextInputField) ChecklistUtils.getFieldInGroup(group, WEALTH_ALLOCATION);
        if (wealthAllocation == null) {
            wealthAllocation = TextInputField.builder().fieldId(WEALTH_ALLOCATION).build();
            group.getFields().add(wealthAllocation);
        }
        wealthAllocation.setIsActive(true);
        wealthAllocation.incrementOrder();
        wealthAllocation.setLabel("Wealth allocation");
        wealthAllocation.setEnabled(true);
        wealthAllocation.setMandatory(true);
        wealthAllocation.setDisplayIf(null);
        wealthAllocation.setLabelBold(false);
        wealthAllocation.setSourceSystem(null);
    }

    private void evaluateTotalWealth(Group group, WebForm webForm) {
        var totalWealth = (TextInputField) ChecklistUtils.getFieldInGroup(group, TOTAL_WEALTH);
        if (totalWealth == null) {
            totalWealth = TextInputField.builder().fieldId(TOTAL_WEALTH).build();
            group.getFields().add(totalWealth);
        }
        totalWealth.setIsActive(true);
        totalWealth.incrementOrder();
        totalWealth.setLabel("Total wealth");
        totalWealth.setEnabled(false);
        totalWealth.setMandatory(false);
        totalWealth.setDisplayIf(null);
        totalWealth.setLabelBold(false);
        totalWealth.setSourceSystem("From Connect");
        selectedValueFromWebForm(TOTAL_WEALTH, webForm).ifPresent(totalWealth::setSelectedValue);
    }

    private void evaluateKycSupportingDocuments(Group group, WebForm webForm) {
        var kycSupportingDocuments = (SelectInputField) ChecklistUtils.getFieldInGroup(group, KYC_SUPPORTING_DOCUMENTS);
        if (kycSupportingDocuments == null) {
            kycSupportingDocuments = SelectInputField.builder().fieldId(KYC_SUPPORTING_DOCUMENTS).build();
            group.getFields().add(kycSupportingDocuments);
        }
        kycSupportingDocuments.setIsActive(true);
        kycSupportingDocuments.incrementOrder();
        kycSupportingDocuments.setLabel("Are all KYC supporting documents (and if applicable the ones on the tax conformity of the funds) consistent and not altered (i.e. anomalies/ inconsistencies in the POR, documentation to corroborate the SOF/SOW such as no VAT number, no invoice number, no address, incorrect amount etc.)");
        kycSupportingDocuments.setEnabled(true);
        kycSupportingDocuments.setMandatory(true);
        kycSupportingDocuments.setDisplayIf(null);
        kycSupportingDocuments.setLabelBold(false);
        kycSupportingDocuments.setSourceSystem(null);
        kycSupportingDocuments.setOptions(referenceDataRepositoryService.getReferenceDataOptionsByDomain(YES_NO_DOMAIN));
    }
}
