package com.lombardinternational.casemanagement.service.decision.domain.service.checklist.onboarding.field;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Field;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Group;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.policy.Policy;
import com.lombardinternational.casemanagement.service.decision.domain.model.transaction.BusinessTransaction;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.checklist.FieldBuilderService;
import org.springframework.stereotype.Service;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.OnboardingChecklistIds.*;

import java.util.List;
import java.util.Map;

@Service
public class OnboardingDueDiligenceFieldsBuilderService extends OnboardingChecklistFieldsBuilderSupport implements FieldBuilderService {
    @Override
    public void buildField(final WebForm webForm, final ScreenDescription screenDescription, final Group group, final Policy policy, final BusinessTransaction transaction, final Map<String,List<String>> overallCaseRisk) {
        Field.resetFieldId();
        evaluateIndustry(group, webForm);
        evaluatePosition(group, webForm);
        evaluateBackgroundDetails(group, webForm);
        evaluateRiskAssessment(group, webForm);
        evaluatePep(group, webForm);
        evaluateOriginatorPep(group, webForm);
        evaluateIsPepPayer(group, webForm);
        evaluateTccSigned(group, webForm);
        evaluateTccSignedRefused(group, webForm);
        evaluateIntroducingPartnerSigned(group, webForm);
        evaluateInfoProvidedVerified(group, webForm);
        evaluateNegativeFinding(group, webForm);
        evaluateNegativeFindingThirdParty(group, webForm);
        evaluateAtLeastOneSowOfKind(group, webForm);
        evaluateOriginatorWorldCheck(group, webForm);
        evaluateIsOnSanctionList(group, webForm);
        evaluateInsider(group, webForm);
        evaluateIsPhEboGoldenVisa(group, webForm);
        evaluateAnnualIncome(group, webForm);
        evaluate20PercentIncome(group, webForm);
        evaluateSourceOfWealth(group, webForm);
        evaluateMinimumWealth(group, webForm);
        evaluateWealthAllocationOk(group, webForm);
        evaluateWealthOriginatingCountry1Risk(group, webForm);
        evaluateWealthOriginatingCountry2Risk(group, webForm);
        evaluateWealthAllocation(group, webForm);
        evaluateTotalWealth(group, webForm);
        evaluateKycSupportingDocuments(group, webForm);
    }

    private void evaluateIndustry(Group group, WebForm webForm) {
        applyField(group, new OnboardingFieldDefinition(INDUSTRY, FieldKind.SELECT, "Industry", false, true,
                "#forcedValue", null, false, "From CLASS", true), webForm);
    }

    private void evaluatePosition(Group group, WebForm webForm) {
        applyField(group, new OnboardingFieldDefinition(POSITION, FieldKind.SELECT, "Position", false, false,
                "#forcedValue", "#forcedDisplayIf", false, "From CLASS", true), webForm);
    }

    private void evaluateBackgroundDetails(Group group, WebForm webForm) {
        applyField(group, new OnboardingFieldDefinition(BACKGROUND_DETAILS, FieldKind.TEXT_AREA, "Profession background details", true, true,
                null, null, false, null, false), webForm);
    }

    private void evaluateRiskAssessment(Group group, WebForm webForm) {
        applyField(group, new OnboardingFieldDefinition(RISK_ASSESSMENT, FieldKind.TEXT_AREA, "Profession risk assessment", true, true,
                null, null, false, null, false), webForm);
    }

    private void evaluatePep(Group group, WebForm webForm) {
        applyField(group, new OnboardingFieldDefinition(PEP, FieldKind.SELECT, "Is there a PEP on the policy", false, true,
                "#forcedValue", null, false, null, false), webForm);
    }

    private void evaluateOriginatorPep(Group group, WebForm webForm) {
        applyField(group, new OnboardingFieldDefinition(ORIGINATOR_PEP, FieldKind.SELECT, "Is the Originator, linked to the source of funds to be invested, a PEP?", true, true,
                "YES\u00acYes;NO\u00acNo", "#forcedDisplayIf", false, null, false), webForm);
    }

    private void evaluateIsPepPayer(Group group, WebForm webForm) {
        applyField(group, new OnboardingFieldDefinition(IS_PEP_PAYER, FieldKind.SELECT, "Is one of the payer a PEP?", true, true,
                "YES\u00acYes;NO\u00acNo", "#forcedDisplayIf", false, null, false), webForm);
    }

    private void evaluateTccSigned(Group group, WebForm webForm) {
        applyField(group, new OnboardingFieldDefinition(TCC_SIGNED, FieldKind.SELECT, "TCC duly signed received?", true, true,
                "YES\u00acYes;NO\u00acNo", null, false, null, false), webForm);
    }

    private void evaluateTccSignedRefused(Group group, WebForm webForm) {
        applyField(group, new OnboardingFieldDefinition(TCC_SIGNED_REFUSED, FieldKind.SELECT, "Did the PH/EBO refuse to sign the TCC and this after several reminders to sign the form?", true, true,
                "YES\u00acYes;NO\u00acNo", "#TCC_SIGNED# == \"NO\"", false, null, false), webForm);
    }

    private void evaluateIntroducingPartnerSigned(Group group, WebForm webForm) {
        applyField(group, new OnboardingFieldDefinition(INTRODUCING_PARTNER_SIGNED, FieldKind.SELECT, "Introducing partner signs KYC questionnaire", true, true,
                "YES\u00acYes;NO\u00acNo", null, false, null, false), webForm);
    }

    private void evaluateInfoProvidedVerified(Group group, WebForm webForm) {
        applyField(group, new OnboardingFieldDefinition(INFO_PROVIDED_VERIFIED, FieldKind.SELECT, "Info provided on KYC questionnaire could be verified", true, true,
                "YES\u00acYes;NO\u00acNo", null, false, null, false), webForm);
    }

    private void evaluateNegativeFinding(Group group, WebForm webForm) {
        applyField(group, new OnboardingFieldDefinition(NEGATIVE_FINDING, FieldKind.SELECT, "Negative press finding / World check match (on all roles on policy)", false, true,
                "#forcedValue", null, false, null, false), webForm);
    }

    private void evaluateNegativeFindingThirdParty(Group group, WebForm webForm) {
        applyField(group, new OnboardingFieldDefinition(NEGATIVE_FINDING_THIRD_PARTY, FieldKind.TEXT, "Negative press finding / Worldcheck match on following Third party(ies)", false, false,
                "#forcedValue", "#forcedDisplayIf", false, null, false), webForm);
    }

    private void evaluateAtLeastOneSowOfKind(Group group, WebForm webForm) {
        applyField(group, new OnboardingFieldDefinition(AT_LEAST_ONE_SOW_OF_KIND, FieldKind.SELECT, "Invisible field : used as display if condition for ORIGINATOR_WORLD_CHECK", false, true,
                "#forcedValue", "false", false, null, false), webForm);
    }

    private void evaluateOriginatorWorldCheck(Group group, WebForm webForm) {
        applyField(group, new OnboardingFieldDefinition(ORIGINATOR_WORLD_CHECK, FieldKind.SELECT, "World check match or negative press found on originator", true, true,
                "YES\u00acYes;NO\u00acNo", "#forcedDisplayIf", false, null, false), webForm);
    }

    private void evaluateIsOnSanctionList(Group group, WebForm webForm) {
        applyField(group, new OnboardingFieldDefinition(IS_ON_SANCTION_LIST, FieldKind.SELECT, "Is there any person designated on a sanctions list on the policy?", false, true,
                "#forcedValue", null, false, null, false), webForm);
    }

    private void evaluateInsider(Group group, WebForm webForm) {
        applyField(group, new OnboardingFieldDefinition(INSIDER, FieldKind.SELECT, "Is the person an insider to any assets invested in the policy?", false, false,
                "#forcedValue", null, false, null, false), webForm);
    }

    private void evaluateIsPhEboGoldenVisa(Group group, WebForm webForm) {
        applyField(group, new OnboardingFieldDefinition(IS_PH_EBO_GOLDEN_VISA, FieldKind.SELECT, "Is the PH / EBO a country national who applied for residence rights or citizenship in exchange of capital transfers purchase of property or government bonds or investment in corporate entities (who has a Golden Visa) or a Golden Passport", false, true,
                "#forcedValue", null, false, null, false), webForm);
    }

    private void evaluateAnnualIncome(Group group, WebForm webForm) {
        applyField(group, new OnboardingFieldDefinition(ANNUAL_INCOME, FieldKind.TEXT, "Annual Income", false, false,
                "#forcedValue", null, false, "From CLASS", true), webForm);
    }

    private void evaluate20PercentIncome(Group group, WebForm webForm) {
        applyField(group, new OnboardingFieldDefinition(_20_PERCENT_INCOME, FieldKind.SELECT, "A portion of wealth is from inheritance / Gift / Donation / Divorce", false, false,
                "#forcedValue", null, false, "From Connect", true), webForm);
    }

    private void evaluateSourceOfWealth(Group group, WebForm webForm) {
        applyField(group, new OnboardingFieldDefinition(SOURCE_OF_WEALTH, FieldKind.TEXT, "Source of wealth description", true, false,
                null, null, false, null, true), webForm);
    }

    private void evaluateMinimumWealth(Group group, WebForm webForm) {
        applyField(group, new OnboardingFieldDefinition(MINIMUM_WEALTH, FieldKind.SELECT, "Minimum wealth > 250000\u20ac in transferrable assets (not including property)", true, true,
                "YES\u00acYes;NO\u00acNo", null, false, null, true), webForm);
    }

    private void evaluateWealthAllocationOk(Group group, WebForm webForm) {
        applyField(group, new OnboardingFieldDefinition(WEALTH_ALLOCATION_OK, FieldKind.SELECT, "Wealth allocation in line with source", true, true,
                "YES\u00acYes;NO\u00acNo", null, false, null, true), webForm);
    }

    private void evaluateWealthOriginatingCountry1Risk(Group group, WebForm webForm) {
        applyField(group, new OnboardingFieldDefinition(WEALTH_ORIGINATING_COUNTRY_1_RISK, FieldKind.TEXT, "Country 1 origin of premium", false, true,
                "#forcedValue", null, false, "From CLASS", true), webForm);
    }

    private void evaluateWealthOriginatingCountry2Risk(Group group, WebForm webForm) {
        applyField(group, new OnboardingFieldDefinition(WEALTH_ORIGINATING_COUNTRY_2_RISK, FieldKind.TEXT, "Country 2 origin of premium", false, false,
                "#forcedValue", null, false, "From CLASS", true), webForm);
    }

    private void evaluateWealthAllocation(Group group, WebForm webForm) {
        applyField(group, new OnboardingFieldDefinition(WEALTH_ALLOCATION, FieldKind.TEXT, "Wealth allocation", true, true,
                null, null, false, null, true), webForm);
    }

    private void evaluateTotalWealth(Group group, WebForm webForm) {
        applyField(group, new OnboardingFieldDefinition(TOTAL_WEALTH, FieldKind.TEXT, "Total wealth", false, false,
                "#forcedValue", null, false, "From Connect", true), webForm);
    }

    private void evaluateKycSupportingDocuments(Group group, WebForm webForm) {
        applyField(group, new OnboardingFieldDefinition(KYC_SUPPORTING_DOCUMENTS, FieldKind.SELECT, "Are all KYC supporting documents (and if applicable the ones on the tax conformity of the funds) consistent and not altered (i.e. anomalies/ inconsistencies in the POR, documentation to corroborate the SOF/SOW such as no VAT number, no invoice number, no address, incorrect amount etc.)", true, true,
                "YES\u00acYes;NO\u00acNo", null, false, null, false), webForm);
    }

}
