package com.lombardinternational.casemanagement.service.decision.domain.service.checklist.onboarding.field;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.SelectInputField;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.TextAreaField;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.TextInputField;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.TextWebFormField;
import com.lombardinternational.casemanagement.service.decision.domain.utils.ChecklistUtils;
import com.lombardinternational.casemanagement.service.decision.domain.utils.FieldHelper;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.OnboardingChecklistIds.*;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ReferenceConstants.INDUSTRY_SECTOR_DOMAIN;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ReferenceConstants.PROFESSION_DOMAIN;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ReferenceConstants.YES_NO_DOMAIN;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
class OnboardingDueDiligenceFieldsBuilderServiceTest extends OnboardingFieldsBuilderTestSupport {

    @InjectMocks
    private OnboardingDueDiligenceFieldsBuilderService builderService;

    @Test
    void buildDueDiligenceFieldsOK() {

        var group = group(DUE_DILIGENCE_GROUP);

        builderService.buildField(webForm(), screenDescription(), group, policy(), transaction(), overallCaseRisk());

        assertEquals(28, group.getFields().size());
        FieldHelper.testSelectFieldValue(INDUSTRY, SelectInputField.class, group, null, 1, null, true, false, 3);
        FieldHelper.testSelectFieldValue(POSITION, SelectInputField.class, group, null, 2, "#forcedDisplayIf", false, false, 3);
        FieldHelper.testFieldValue(BACKGROUND_DETAILS, TextAreaField.class, group, null, 3, null, true, true);
        FieldHelper.testFieldValue(RISK_ASSESSMENT, TextAreaField.class, group, null, 4, null, true, true);
        FieldHelper.testFieldValue(PEP, SelectInputField.class, group, null, 5, null, true, false);
        FieldHelper.testSelectFieldValue(ORIGINATOR_PEP, SelectInputField.class, group, null, 6, "#forcedDisplayIf", true, true, 2);
        FieldHelper.testSelectFieldValue(KYC_SUPPORTING_DOCUMENTS, SelectInputField.class, group, null, 28, null, true, true, 2);
        verify(referenceDataRepositoryService).getReferenceDataOptionsByDomainAndSelectedValue(INDUSTRY_SECTOR_DOMAIN, null);
        verify(referenceDataRepositoryService).getReferenceDataOptionsByDomainAndSelectedValue(PROFESSION_DOMAIN, null);
        verify(referenceDataRepositoryService, org.mockito.Mockito.atLeastOnce()).getReferenceDataOptionsByDomain(YES_NO_DOMAIN);
    }

    @Test
    void buildDueDiligenceFieldsUsesForcedValuesAndSelectedReferenceOptions() {

        var group = group(DUE_DILIGENCE_GROUP);
        var webForm = webFormWithTextFields(TextWebFormField.builder().fieldId(INDUSTRY).value("agri").build(),
                TextWebFormField.builder().fieldId(POSITION).value("lawyer").build());

        builderService.buildField(webForm, screenDescription(), group, policy(), transaction(), overallCaseRisk());

        var industry = (SelectInputField) ChecklistUtils.getFieldInGroup(group, INDUSTRY);
        var position = (SelectInputField) ChecklistUtils.getFieldInGroup(group, POSITION);
        assertEquals("agri", industry.getSelectedValue());
        assertEquals(1, industry.getOptions().size());
        assertEquals("agri", industry.getOptions().getFirst().getKey());
        assertEquals("lawyer", position.getSelectedValue());
        assertEquals(1, position.getOptions().size());
        assertEquals("lawyer", position.getOptions().getFirst().getKey());
        verify(referenceDataRepositoryService).getReferenceDataOptionsByDomainAndSelectedValue(INDUSTRY_SECTOR_DOMAIN, "agri");
        verify(referenceDataRepositoryService).getReferenceDataOptionsByDomainAndSelectedValue(PROFESSION_DOMAIN, "lawyer");
    }
}
