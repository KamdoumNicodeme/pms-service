package com.lombardinternational.casemanagement.service.decision.domain.service.checklist.onboarding.field;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Field;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Group;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.policy.Policy;
import com.lombardinternational.casemanagement.service.decision.domain.model.transaction.BusinessTransaction;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.checklist.FieldBuilderService;
import org.springframework.stereotype.Service;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.OnboardingChecklistIds.*;

import java.util.List;
import java.util.Map;

@Service
public class OnboardingPricingApprovalFieldsBuilderService extends OnboardingChecklistFieldsBuilderSupport implements FieldBuilderService {
    @Override
    public void buildField(final WebForm webForm, final ScreenDescription screenDescription, final Group group, final Policy policy, final BusinessTransaction transaction, final Map<String,List<String>> overallCaseRisk) {
        Field.resetFieldId();
        evaluateNtaMarkupException(group, webForm);
        evaluateExplainException(group, webForm);
        evaluatePricingApprovalStage(group, webForm);
        evaluateRationaleForException(group, webForm);
        evaluateAdministrativeFee(group, webForm);
        evaluateGac(group, webForm);
        evaluatePolicyFee(group, webForm);
        evaluateIsFamilyCase(group, webForm);
        evaluateFamilyCasePolNbr(group, webForm);
        evaluateFamilyCaseTotalAmount(group, webForm);
        evaluatePricingApprovalChecked(group, webForm);
    }

    private void evaluateNtaMarkupException(Group group, WebForm webForm) {
        applyField(group, new OnboardingFieldDefinition(NTA_MARKUP_EXCEPTION, FieldKind.SELECT, "NTA Markup Exception?", false, false,
                null, null, false, null, false), webForm);
    }

    private void evaluateExplainException(Group group, WebForm webForm) {
        applyField(group, new OnboardingFieldDefinition(EXPLAIN_EXCEPTION, FieldKind.TEXT_AREA, "Explain Exception", false, false,
                null, null, false, null, false), webForm);
    }

    private void evaluatePricingApprovalStage(Group group, WebForm webForm) {
        applyField(group, new OnboardingFieldDefinition(PRICING_APPROVAL_STAGE, FieldKind.TEXT, "Pricing Approval Stage", false, false,
                null, null, false, null, false), webForm);
    }

    private void evaluateRationaleForException(Group group, WebForm webForm) {
        applyField(group, new OnboardingFieldDefinition(RATIONALE_FOR_EXCEPTION, FieldKind.TEXT, "Rationale for Exception", false, false,
                null, null, false, null, false), webForm);
    }

    private void evaluateAdministrativeFee(Group group, WebForm webForm) {
        applyField(group, new OnboardingFieldDefinition(ADMINISTRATIVE_FEE, FieldKind.TEXT, "Administrative Fee", false, false,
                null, null, false, null, false), webForm);
    }

    private void evaluateGac(Group group, WebForm webForm) {
        applyField(group, new OnboardingFieldDefinition(GAC, FieldKind.TEXT, "GAC (#Years)", false, false,
                null, null, false, null, false), webForm);
    }

    private void evaluatePolicyFee(Group group, WebForm webForm) {
        applyField(group, new OnboardingFieldDefinition(POLICY_FEE, FieldKind.TEXT, "Policy Fee", false, false,
                null, null, false, null, false), webForm);
    }

    private void evaluateIsFamilyCase(Group group, WebForm webForm) {
        applyField(group, new OnboardingFieldDefinition(IS_FAMILY_CASE, FieldKind.SELECT, "It is a family case ?", true, false,
                "YES\u00acYes;NO\u00acNo", null, false, null, false), webForm);
    }

    private void evaluateFamilyCasePolNbr(Group group, WebForm webForm) {
        applyField(group, new OnboardingFieldDefinition(FAMILY_CASE_POL_NBR, FieldKind.NUMBER, "How many policies in the family case", true, false,
                null, null, false, null, false), webForm);
    }

    private void evaluateFamilyCaseTotalAmount(Group group, WebForm webForm) {
        applyField(group, new OnboardingFieldDefinition(FAMILY_CASE_TOTAL_AMOUNT, FieldKind.NUMBER, "Total amount invested in the family case", true, false,
                null, null, false, null, false), webForm);
    }

    private void evaluatePricingApprovalChecked(Group group, WebForm webForm) {
        applyField(group, new OnboardingFieldDefinition(PRICING_APPROVAL_CHECKED, FieldKind.SELECT, "Pricing approval has been checked in CRM tab (Salesforce) and is in line with the charging structure signed by the PH in the Application form, and the premium received", true, true,
                "YES\u00acYes;NO\u00acNo", null, false, null, false), webForm);
    }

}
