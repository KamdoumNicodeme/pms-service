package com.lombardinternational.casemanagement.service.decision.domain.service.checklist.onboarding.field;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Field;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Group;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.policy.Policy;
import com.lombardinternational.casemanagement.service.decision.domain.model.transaction.BusinessTransaction;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.checklist.FieldBuilderService;
import org.springframework.stereotype.Service;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.OnboardingChecklistIds.*;

import java.util.List;
import java.util.Map;

@Service
public class OnboardingLifeCoverFieldsBuilderService extends OnboardingChecklistFieldsBuilderSupport implements FieldBuilderService {
    @Override
    public void buildField(final WebForm webForm, final ScreenDescription screenDescription, final Group group, final Policy policy, final BusinessTransaction transaction, final Map<String,List<String>> overallCaseRisk) {
        Field.resetFieldId();
        evaluateLifeCoverType(group, webForm);
        evaluateSar(group, webForm);
        evaluateUnderwritings(group, webForm);
    }

    private void evaluateLifeCoverType(Group group, WebForm webForm) {
        applyField(group, new OnboardingFieldDefinition(LIFE_COVER_TYPE, FieldKind.SELECT, "Life cover type capped", true, true,
                "YES\u00acYes;NO\u00acNo", null, false, null, false), webForm);
    }

    private void evaluateSar(Group group, WebForm webForm) {
        applyField(group, new OnboardingFieldDefinition(SAR, FieldKind.TEXT, "SAR", true, true,
                null, "#LIFE_COVER_TYPE# == \"NO\"", false, null, false), webForm);
    }

    private void evaluateUnderwritings(Group group, WebForm webForm) {
        applyField(group, new OnboardingFieldDefinition(UNDERWRITINGS, FieldKind.SELECT, "Underwritings", true, true,
                "L0;L1;L2;L3;L4;L5;L6", "#LIFE_COVER_TYPE# == \"NO\"", false, null, false), webForm);
    }

}
