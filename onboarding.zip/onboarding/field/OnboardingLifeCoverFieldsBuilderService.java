package com.lombardinternational.casemanagement.service.decision.domain.service.checklist.onboarding.field;

import com.lombardinternational.casemanagement.service.decision.domain.model.policy.Policy;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.*;
import com.lombardinternational.casemanagement.service.decision.domain.model.transaction.BusinessTransaction;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.checklist.FieldBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.spi.repository.ReferenceDataRepositoryService;
import com.lombardinternational.casemanagement.service.decision.domain.utils.ChecklistUtils;
import java.util.List;
import java.util.Map;
import org.springframework.stereotype.Service;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ChecklistFieldConstants.UNDER_WRITINGS_OPTIONS;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.OnboardingChecklistIds.*;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ReferenceConstants.*;

@Service
public class OnboardingLifeCoverFieldsBuilderService extends OnboardingChecklistFieldsBuilderSupport implements FieldBuilderService {
    private final ReferenceDataRepositoryService referenceDataRepositoryService;

    public OnboardingLifeCoverFieldsBuilderService(ReferenceDataRepositoryService referenceDataRepositoryService) {
        this.referenceDataRepositoryService = referenceDataRepositoryService;
    }

    @Override
    public void buildField(final WebForm webForm, final ScreenDescription screenDescription, final Group group, final Policy policy, final BusinessTransaction transaction, final Map<String,List<String>> overallCaseRisk) {
        Field.resetFieldId();

        evaluateLifeCoverType(group, webForm);

        evaluateSar(group, webForm);

        evaluateUnderwritings(group, webForm);

    }

    private void evaluateLifeCoverType(Group group, WebForm webForm) {
        var lifeCoverType = (SelectInputField) ChecklistUtils.getFieldInGroup(group, LIFE_COVER_TYPE);
        if (lifeCoverType == null) {
            lifeCoverType = SelectInputField.builder().fieldId(LIFE_COVER_TYPE).build();
            group.getFields().add(lifeCoverType);
        }
        lifeCoverType.setIsActive(true);
        lifeCoverType.incrementOrder();
        lifeCoverType.setLabel("Life cover type capped");
        lifeCoverType.setEnabled(true);
        lifeCoverType.setMandatory(true);
        lifeCoverType.setDisplayIf(null);
        lifeCoverType.setLabelBold(false);
        lifeCoverType.setSourceSystem(null);
        lifeCoverType.setOptions(referenceDataRepositoryService.getReferenceDataOptionsByDomain(YES_NO_DOMAIN));
    }

    private void evaluateSar(Group group, WebForm webForm) {
        var sar = (TextInputField) ChecklistUtils.getFieldInGroup(group, SAR);
        if (sar == null) {
            sar = TextInputField.builder().fieldId(SAR).build();
            group.getFields().add(sar);
        }
        sar.setIsActive(true);
        sar.incrementOrder();
        sar.setLabel("SAR");
        sar.setEnabled(true);
        sar.setMandatory(true);
        sar.setDisplayIf("#LIFE_COVER_TYPE# == \"NO\"");
        sar.setLabelBold(false);
        sar.setSourceSystem(null);
    }

    private void evaluateUnderwritings(Group group, WebForm webForm) {
        var underwritings = (SelectInputField) ChecklistUtils.getFieldInGroup(group, UNDERWRITINGS);
        if (underwritings == null) {
            underwritings = SelectInputField.builder().fieldId(UNDERWRITINGS).build();
            group.getFields().add(underwritings);
        }
        underwritings.setIsActive(true);
        underwritings.incrementOrder();
        underwritings.setLabel("Underwritings");
        underwritings.setEnabled(true);
        underwritings.setMandatory(true);
        underwritings.setDisplayIf("#LIFE_COVER_TYPE# == \"NO\"");
        underwritings.setLabelBold(false);
        underwritings.setSourceSystem(null);
        underwritings.setOptions(referenceDataRepositoryService.getReferenceDataOptionsByDomain(UNDER_WRITINGS_OPTIONS));
    }
}
