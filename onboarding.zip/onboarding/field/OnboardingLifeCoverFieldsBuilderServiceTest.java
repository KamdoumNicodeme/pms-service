package com.lombardinternational.casemanagement.service.decision.domain.service.checklist.onboarding.field;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.SelectInputField;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.TextInputField;
import com.lombardinternational.casemanagement.service.decision.domain.utils.FieldHelper;
import java.util.concurrent.atomic.AtomicInteger;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ChecklistFieldConstants.UNDER_WRITINGS_OPTIONS;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.OnboardingChecklistIds.*;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ReferenceConstants.YES_NO_DOMAIN;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
class OnboardingLifeCoverFieldsBuilderServiceTest extends OnboardingFieldsBuilderTestSupport {

    @InjectMocks
    private OnboardingLifeCoverFieldsBuilderService builderService;

    @Test
    void buildLifeCoverFieldsOK() {

        var group = group(LIFE_COVER_GROUP);
        var testOrder = new AtomicInteger(1);

        builderService.buildField(webForm(), screenDescription(), group, policy(), transaction(), overallCaseRisk());

        assertEquals(3, group.getFields().size());
        FieldHelper.testSelectFieldValueAndIncr(LIFE_COVER_TYPE, SelectInputField.class, group, null, testOrder, null, true, true, 2);
        FieldHelper.testFieldValueAndIncr(SAR, TextInputField.class, group, null, testOrder, "#LIFE_COVER_TYPE# == \"NO\"", true, true);
        FieldHelper.testSelectFieldValueAndIncr(UNDERWRITINGS, SelectInputField.class, group, null, testOrder,
                "#LIFE_COVER_TYPE# == \"NO\"", true, true, 7);
        assertEquals(3, testOrder.get() - 1);
        verify(referenceDataRepositoryService).getReferenceDataOptionsByDomain(YES_NO_DOMAIN);
        verify(referenceDataRepositoryService).getReferenceDataOptionsByDomain(UNDER_WRITINGS_OPTIONS);
    }

    @Test
    void buildLifeCoverFieldsReusesExistingFieldWithoutDuplicatingIt() {

        var group = group(LIFE_COVER_GROUP);
        group.getFields().add(SelectInputField.builder().fieldId(LIFE_COVER_TYPE).selectedValue("YES").build());

        builderService.buildField(webForm(), screenDescription(), group, policy(), transaction(), overallCaseRisk());

        assertEquals(3, group.getFields().size());
        FieldHelper.testSelectFieldValue(LIFE_COVER_TYPE, SelectInputField.class, group, "YES", 1, null, true, true, 2);
    }
}
