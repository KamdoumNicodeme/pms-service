package com.lombardinternational.casemanagement.service.decision.domain.service.checklist.onboarding.field;

import com.lombardinternational.casemanagement.service.decision.domain.model.policy.Policy;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.*;
import com.lombardinternational.casemanagement.service.decision.domain.model.transaction.BusinessTransaction;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.checklist.FieldBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.spi.repository.ReferenceDataRepositoryService;
import com.lombardinternational.casemanagement.service.decision.domain.utils.ChecklistUtils;
import java.util.List;
import java.util.Map;
import org.springframework.stereotype.Service;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.OnboardingChecklistIds.*;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ReferenceConstants.*;

@Service
public class OnboardingThirdPartyFieldsBuilderService extends OnboardingChecklistFieldsBuilderSupport implements FieldBuilderService {
    private final ReferenceDataRepositoryService referenceDataRepositoryService;

    public OnboardingThirdPartyFieldsBuilderService(ReferenceDataRepositoryService referenceDataRepositoryService) {
        this.referenceDataRepositoryService = referenceDataRepositoryService;
    }

    @Override
    public void buildField(final WebForm webForm, final ScreenDescription screenDescription, final Group group, final Policy policy, final BusinessTransaction transaction, final Map<String,List<String>> overallCaseRisk) {
        Field.resetFieldId();

        evaluateThirdPartyName(group, webForm);

        evaluateLinkThirdPartyPh(group, webForm);

        evaluateAdditionalInfoLink(group, webForm);

        evaluateReasonThirdPartyPayment(group, webForm);

        evaluateThirdPartyCountry(group, webForm);

        evaluateThirdPartyCountryRisk(group, webForm);

    }

    private void evaluateThirdPartyName(Group group, WebForm webForm) {
        var thirdPartyName = (TextInputField) ChecklistUtils.getFieldInGroup(group, THIRD_PARTY_NAME);
        if (thirdPartyName == null) {
            thirdPartyName = TextInputField.builder().fieldId(THIRD_PARTY_NAME).build();
            group.getFields().add(thirdPartyName);
        }
        thirdPartyName.setIsActive(true);
        thirdPartyName.incrementOrder();
        thirdPartyName.setLabel("3rd party ID");
        thirdPartyName.setEnabled(false);
        thirdPartyName.setMandatory(true);
        thirdPartyName.setDisplayIf(null);
        thirdPartyName.setLabelBold(false);
        thirdPartyName.setSourceSystem("From Class");
        selectedValueFromWebForm(THIRD_PARTY_NAME, webForm).ifPresent(thirdPartyName::setSelectedValue);
    }

    private void evaluateLinkThirdPartyPh(Group group, WebForm webForm) {
        var linkThirdPartyPh = (SelectInputField) ChecklistUtils.getFieldInGroup(group, LINK_THIRD_PARTY_PH);
        if (linkThirdPartyPh == null) {
            linkThirdPartyPh = SelectInputField.builder().fieldId(LINK_THIRD_PARTY_PH).build();
            group.getFields().add(linkThirdPartyPh);
        }
        linkThirdPartyPh.setIsActive(true);
        linkThirdPartyPh.incrementOrder();
        linkThirdPartyPh.setLabel("Link between 3rd party and PH");
        linkThirdPartyPh.setEnabled(false);
        linkThirdPartyPh.setMandatory(true);
        linkThirdPartyPh.setDisplayIf(null);
        linkThirdPartyPh.setLabelBold(false);
        linkThirdPartyPh.setSourceSystem("From Class");
        selectedValueFromWebForm(LINK_THIRD_PARTY_PH, webForm).ifPresent(linkThirdPartyPh::setSelectedValue);
        linkThirdPartyPh.setOptions(referenceDataRepositoryService.getReferenceDataOptionsByDomainAndSelectedValue(THIRD_PARTY_TYPE_DOMAIN,
                linkThirdPartyPh.getSelectedValue()));
    }

    private void evaluateAdditionalInfoLink(Group group, WebForm webForm) {
        var additionalInfoLink = (TextAreaField) ChecklistUtils.getFieldInGroup(group, ADDITIONAL_INFO_LINK);
        if (additionalInfoLink == null) {
            additionalInfoLink = TextAreaField.builder().fieldId(ADDITIONAL_INFO_LINK).build();
            group.getFields().add(additionalInfoLink);
        }
        additionalInfoLink.setIsActive(true);
        additionalInfoLink.incrementOrder();
        additionalInfoLink.setLabel("Additional info on link between 3rd party and PH");
        additionalInfoLink.setEnabled(true);
        additionalInfoLink.setMandatory(false);
        additionalInfoLink.setDisplayIf("#LINK_THIRD_PARTY_PH# == \"other\"");
        additionalInfoLink.setLabelBold(false);
        additionalInfoLink.setSourceSystem(null);
    }

    private void evaluateReasonThirdPartyPayment(Group group, WebForm webForm) {
        var reasonThirdPartyPayment = (TextInputField) ChecklistUtils.getFieldInGroup(group, REASON_THIRD_PARTY_PAYMENT);
        if (reasonThirdPartyPayment == null) {
            reasonThirdPartyPayment = TextInputField.builder().fieldId(REASON_THIRD_PARTY_PAYMENT).build();
            group.getFields().add(reasonThirdPartyPayment);
        }
        reasonThirdPartyPayment.setIsActive(true);
        reasonThirdPartyPayment.incrementOrder();
        reasonThirdPartyPayment.setLabel("Reason for 3rd party payment");
        reasonThirdPartyPayment.setEnabled(true);
        reasonThirdPartyPayment.setMandatory(false);
        reasonThirdPartyPayment.setDisplayIf(null);
        reasonThirdPartyPayment.setLabelBold(false);
        reasonThirdPartyPayment.setSourceSystem(null);
        selectedValueFromWebForm(REASON_THIRD_PARTY_PAYMENT, webForm).ifPresent(reasonThirdPartyPayment::setSelectedValue);
    }

    private void evaluateThirdPartyCountry(Group group, WebForm webForm) {
        var thirdPartyCountry = (SelectInputField) ChecklistUtils.getFieldInGroup(group, THIRD_PARTY_COUNTRY);
        if (thirdPartyCountry == null) {
            thirdPartyCountry = SelectInputField.builder().fieldId(THIRD_PARTY_COUNTRY).build();
            group.getFields().add(thirdPartyCountry);
        }
        thirdPartyCountry.setIsActive(true);
        thirdPartyCountry.incrementOrder();
        thirdPartyCountry.setLabel("3rd party country");
        thirdPartyCountry.setEnabled(false);
        thirdPartyCountry.setMandatory(true);
        thirdPartyCountry.setDisplayIf(null);
        thirdPartyCountry.setLabelBold(false);
        thirdPartyCountry.setSourceSystem("From Class");
        selectedValueFromWebForm(THIRD_PARTY_COUNTRY, webForm).ifPresent(thirdPartyCountry::setSelectedValue);
        thirdPartyCountry.setOptions(referenceDataRepositoryService.getReferenceDataOptionsByDomainAndSelectedValue(COUNTRY_DOMAIN,
                thirdPartyCountry.getSelectedValue()));
    }

    private void evaluateThirdPartyCountryRisk(Group group, WebForm webForm) {
        var thirdPartyCountryRisk = (TextInputField) ChecklistUtils.getFieldInGroup(group, THIRD_PARTY_COUNTRY_RISK);
        if (thirdPartyCountryRisk == null) {
            thirdPartyCountryRisk = TextInputField.builder().fieldId(THIRD_PARTY_COUNTRY_RISK).build();
            group.getFields().add(thirdPartyCountryRisk);
        }
        thirdPartyCountryRisk.setIsActive(true);
        thirdPartyCountryRisk.incrementOrder();
        thirdPartyCountryRisk.setLabel("Highest 3rd party risk");
        thirdPartyCountryRisk.setEnabled(false);
        thirdPartyCountryRisk.setMandatory(false);
        thirdPartyCountryRisk.setDisplayIf(null);
        thirdPartyCountryRisk.setLabelBold(false);
        thirdPartyCountryRisk.setSourceSystem("Highest 3rd party risk from Class");
        selectedValueFromWebForm(THIRD_PARTY_COUNTRY_RISK, webForm).ifPresent(thirdPartyCountryRisk::setSelectedValue);
    }
}
