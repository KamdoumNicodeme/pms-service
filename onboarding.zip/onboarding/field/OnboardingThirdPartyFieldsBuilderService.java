package com.lombardinternational.casemanagement.service.decision.domain.service.checklist.onboarding.field;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Field;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Group;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.policy.Policy;
import com.lombardinternational.casemanagement.service.decision.domain.model.transaction.BusinessTransaction;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.checklist.FieldBuilderService;
import org.springframework.stereotype.Service;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.OnboardingChecklistIds.*;

import java.util.List;
import java.util.Map;

@Service
public class OnboardingThirdPartyFieldsBuilderService extends OnboardingChecklistFieldsBuilderSupport implements FieldBuilderService {
    @Override
    public void buildField(final WebForm webForm, final ScreenDescription screenDescription, final Group group, final Policy policy, final BusinessTransaction transaction, final Map<String,List<String>> overallCaseRisk) {
        Field.resetFieldId();
        evaluateThirdPartyName(group, webForm);
        evaluateLinkThirdPartyPh(group, webForm);
        evaluateAdditionalInfoLink(group, webForm);
        evaluateReasonThirdPartyPayment(group, webForm);
        evaluateThirdPartyCountry(group, webForm);
        evaluateThirdPartyCountryRisk(group, webForm);
    }

    private void evaluateThirdPartyName(Group group, WebForm webForm) {
        applyField(group, new OnboardingFieldDefinition(THIRD_PARTY_NAME, FieldKind.TEXT, "3rd party ID", false, true,
                "#forcedValue", null, false, "From Class", true), webForm);
    }

    private void evaluateLinkThirdPartyPh(Group group, WebForm webForm) {
        applyField(group, new OnboardingFieldDefinition(LINK_THIRD_PARTY_PH, FieldKind.SELECT, "Link between 3rd party and PH", false, true,
                "#forcedValue", null, false, "From Class", true), webForm);
    }

    private void evaluateAdditionalInfoLink(Group group, WebForm webForm) {
        applyField(group, new OnboardingFieldDefinition(ADDITIONAL_INFO_LINK, FieldKind.TEXT_AREA, "Additional info on link between 3rd party and PH", true, false,
                null, "#LINK_THIRD_PARTY_PH# == \"other\"", false, null, false), webForm);
    }

    private void evaluateReasonThirdPartyPayment(Group group, WebForm webForm) {
        applyField(group, new OnboardingFieldDefinition(REASON_THIRD_PARTY_PAYMENT, FieldKind.TEXT, "Reason for 3rd party payment", true, false,
                "#forcedValue", null, false, null, true), webForm);
    }

    private void evaluateThirdPartyCountry(Group group, WebForm webForm) {
        applyField(group, new OnboardingFieldDefinition(THIRD_PARTY_COUNTRY, FieldKind.SELECT, "3rd party country", false, true,
                "#forcedValue", null, false, "From Class", true), webForm);
    }

    private void evaluateThirdPartyCountryRisk(Group group, WebForm webForm) {
        applyField(group, new OnboardingFieldDefinition(THIRD_PARTY_COUNTRY_RISK, FieldKind.TEXT, "Highest 3rd party risk", false, false,
                "#forcedValue", null, false, "Highest 3rd party risk from Class", false), webForm);
    }

}
