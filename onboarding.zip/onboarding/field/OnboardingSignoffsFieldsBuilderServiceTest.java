package com.lombardinternational.casemanagement.service.decision.domain.service.checklist.onboarding.field;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.SelectInputField;
import com.lombardinternational.casemanagement.service.decision.domain.utils.FieldHelper;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.OnboardingChecklistIds.*;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ReferenceConstants.TRANSACTION_FEEDBACK_DOMAIN;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
class OnboardingSignoffsFieldsBuilderServiceTest extends OnboardingFieldsBuilderTestSupport {

    @InjectMocks
    private OnboardingSignoffsFieldsBuilderService builderService;

    @Test
    void buildSignoffsFieldsOK() {

        var group = group(SIGNOFFS_GROUP);

        builderService.buildField(webForm(), screenDescription(), group, policy(), transaction(), overallCaseRisk());

        assertEquals(1, group.getFields().size());
        FieldHelper.testSelectFieldValue(TRANSACTION_FEEDBACK, SelectInputField.class, group, null, 1, null, false, true, 3);
        verify(referenceDataRepositoryService).getReferenceDataOptionsByDomain(TRANSACTION_FEEDBACK_DOMAIN);
    }
}
