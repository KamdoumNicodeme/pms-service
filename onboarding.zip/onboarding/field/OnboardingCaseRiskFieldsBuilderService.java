package com.lombardinternational.casemanagement.service.decision.domain.service.checklist.onboarding.field;

import com.lombardinternational.casemanagement.service.decision.domain.model.policy.Policy;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.*;
import com.lombardinternational.casemanagement.service.decision.domain.model.transaction.BusinessTransaction;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.checklist.FieldBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.spi.repository.ReferenceDataRepositoryService;
import com.lombardinternational.casemanagement.service.decision.domain.utils.ChecklistUtils;
import java.util.List;
import java.util.Map;
import org.springframework.stereotype.Service;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.OnboardingChecklistIds.*;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ReferenceConstants.*;

@Service
public class OnboardingCaseRiskFieldsBuilderService extends OnboardingChecklistFieldsBuilderSupport implements FieldBuilderService {
    private final ReferenceDataRepositoryService referenceDataRepositoryService;

    public OnboardingCaseRiskFieldsBuilderService(ReferenceDataRepositoryService referenceDataRepositoryService) {
        this.referenceDataRepositoryService = referenceDataRepositoryService;
    }

    @Override
    public void buildField(final WebForm webForm, final ScreenDescription screenDescription, final Group group, final Policy policy, final BusinessTransaction transaction, final Map<String,List<String>> overallCaseRisk) {
        Field.resetFieldId();

        evaluateRiskValue(group, webForm);

        evaluateBlockedValue(group, webForm);

        evaluatePcsReview(group, webForm);

        evaluateRiskReason(group, webForm);

    }

    private void evaluateRiskValue(Group group, WebForm webForm) {
        var riskValue = (TextInputField) ChecklistUtils.getFieldInGroup(group, RISK_VALUE);
        if (riskValue == null) {
            riskValue = TextInputField.builder().fieldId(RISK_VALUE).build();
            group.getFields().add(riskValue);
        }
        riskValue.setIsActive(true);
        riskValue.incrementOrder();
        riskValue.setLabel("Overall case risk");
        riskValue.setEnabled(false);
        riskValue.setMandatory(false);
        riskValue.setDisplayIf("false");
        riskValue.setLabelBold(false);
        riskValue.setSourceSystem("Calculated based on checklist values");
        selectedValueFromWebForm(RISK_VALUE, webForm).ifPresent(riskValue::setSelectedValue);
    }

    private void evaluateBlockedValue(Group group, WebForm webForm) {
        var blockedValue = (TextAreaField) ChecklistUtils.getFieldInGroup(group, BLOCKED_VALUE);
        if (blockedValue == null) {
            blockedValue = TextAreaField.builder().fieldId(BLOCKED_VALUE).build();
            group.getFields().add(blockedValue);
        }
        blockedValue.setIsActive(true);
        blockedValue.incrementOrder();
        blockedValue.setLabel("Actions required in CLASS to complete Docs & Controls and trigger reviews");
        blockedValue.setEnabled(false);
        blockedValue.setMandatory(false);
        blockedValue.setDisplayIf("#forcedDisplayIf");
        blockedValue.setLabelBold(false);
        blockedValue.setSourceSystem("Calculated based on checklist values");
        selectedValueFromWebForm(BLOCKED_VALUE, webForm).ifPresent(blockedValue::setSelectedValue);
    }

    private void evaluatePcsReview(Group group, WebForm webForm) {
        var pcsReview = (SelectInputField) ChecklistUtils.getFieldInGroup(group, PCS_REVIEW);
        if (pcsReview == null) {
            pcsReview = SelectInputField.builder().fieldId(PCS_REVIEW).build();
            group.getFields().add(pcsReview);
        }
        pcsReview.setIsActive(true);
        pcsReview.incrementOrder();
        pcsReview.setLabel("PCS Review");
        pcsReview.setEnabled(false);
        pcsReview.setMandatory(true);
        pcsReview.setDisplayIf("#forcedDisplayIf");
        pcsReview.setLabelBold(false);
        pcsReview.setSourceSystem("Calculated based on Overall case risk");
        selectedValueFromWebForm(PCS_REVIEW, webForm).ifPresent(pcsReview::setSelectedValue);
        pcsReview.setOptions(referenceDataRepositoryService.getReferenceDataOptionsByDomainAndSelectedValue(COMPLIANCE_LEVEL_DOMAIN,
                pcsReview.getSelectedValue()));
    }

    private void evaluateRiskReason(Group group, WebForm webForm) {
        var riskReason = (TextAreaField) ChecklistUtils.getFieldInGroup(group, RISK_REASON);
        if (riskReason == null) {
            riskReason = TextAreaField.builder().fieldId(RISK_REASON).build();
            group.getFields().add(riskReason);
        }
        riskReason.setIsActive(true);
        riskReason.incrementOrder();
        riskReason.setLabel("Compliance escalation rules triggered");
        riskReason.setEnabled(false);
        riskReason.setMandatory(false);
        riskReason.setDisplayIf("#forcedDisplayIf");
        riskReason.setLabelBold(false);
        riskReason.setSourceSystem("Calculated based on Overall case risk");
        selectedValueFromWebForm(RISK_REASON, webForm).ifPresent(riskReason::setSelectedValue);
    }
}
