package com.lombardinternational.casemanagement.service.decision.domain.service.checklist.onboarding.field;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Field;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Group;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.policy.Policy;
import com.lombardinternational.casemanagement.service.decision.domain.model.transaction.BusinessTransaction;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.checklist.FieldBuilderService;
import org.springframework.stereotype.Service;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.OnboardingChecklistIds.*;

import java.util.List;
import java.util.Map;

@Service
public class OnboardingCaseRiskFieldsBuilderService extends OnboardingChecklistFieldsBuilderSupport implements FieldBuilderService {
    @Override
    public void buildField(final WebForm webForm, final ScreenDescription screenDescription, final Group group, final Policy policy, final BusinessTransaction transaction, final Map<String,List<String>> overallCaseRisk) {
        Field.resetFieldId();
        evaluateRiskValue(group, webForm);
        evaluateBlockedValue(group, webForm);
        evaluatePcsReview(group, webForm);
        evaluateRiskReason(group, webForm);
    }

    private void evaluateRiskValue(Group group, WebForm webForm) {
        applyField(group, new OnboardingFieldDefinition(RISK_VALUE, FieldKind.TEXT, "Overall case risk", false, false,
                "#forcedValue", "false", false, "Calculated based on checklist values", false), webForm);
    }

    private void evaluateBlockedValue(Group group, WebForm webForm) {
        applyField(group, new OnboardingFieldDefinition(BLOCKED_VALUE, FieldKind.TEXT_AREA, "Actions required in CLASS to complete Docs & Controls and trigger reviews", false, false,
                "#forcedValue", "#forcedDisplayIf", false, "Calculated based on checklist values", false), webForm);
    }

    private void evaluatePcsReview(Group group, WebForm webForm) {
        applyField(group, new OnboardingFieldDefinition(PCS_REVIEW, FieldKind.SELECT, "PCS Review", false, true,
                "#forcedValue", "#forcedDisplayIf", false, "Calculated based on Overall case risk", false), webForm);
    }

    private void evaluateRiskReason(Group group, WebForm webForm) {
        applyField(group, new OnboardingFieldDefinition(RISK_REASON, FieldKind.TEXT_AREA, "Compliance escalation rules triggered", false, false,
                "#forcedValue", "#forcedDisplayIf", false, "Calculated based on Overall case risk", false), webForm);
    }

}
