package com.lombardinternational.casemanagement.service.decision.domain.service.checklist.onboarding.field;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Field;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Group;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.policy.Policy;
import com.lombardinternational.casemanagement.service.decision.domain.model.transaction.BusinessTransaction;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.checklist.FieldBuilderService;
import org.springframework.stereotype.Service;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.OnboardingChecklistIds.*;

import java.util.List;
import java.util.Map;

@Service
public class OnboardingIntermediationFieldsBuilderService extends OnboardingChecklistFieldsBuilderSupport implements FieldBuilderService {
    @Override
    public void buildField(final WebForm webForm, final ScreenDescription screenDescription, final Group group, final Policy policy, final BusinessTransaction transaction, final Map<String,List<String>> overallCaseRisk) {
        Field.resetFieldId();
        evaluateAppFormSigner(group, webForm);
        evaluatePartnerCode(group, webForm);
        evaluatePartnerName(group, webForm);
        evaluatePartnerType(group, webForm);
        evaluateIsPhRepresentative(group, webForm);
        evaluateReferrerAuto(group, webForm);
        evaluatePartnerStatus(group, webForm);
        evaluateAnalysisOfNeeds(group, webForm);
        evaluateNbIntermediatedDs(group, webForm);
        evaluateDsConsentReceived(group, webForm);
        evaluateVideoReceived(group, webForm);
        evaluateClientIdentifiable(group, webForm);
        evaluateHashCheckPerformed(group, webForm);
        evaluatePassportCheckPerformed(group, webForm);
        evaluateRequestDsProcedure(group, webForm);
        evaluateVulnerableIndiciaDetected(group, webForm);
    }

    private void evaluateAppFormSigner(Group group, WebForm webForm) {
        applyField(group, new OnboardingFieldDefinition(APP_FORM_SIGNER, FieldKind.SELECT, "Application form signer", true, true,
                "BROKER\u00acBroker;ILA\u00acInternal Lombard Agent;MC\u00acMarketing Consultant", null, false, null, false), webForm);
    }

    private void evaluatePartnerCode(Group group, WebForm webForm) {
        applyField(group, new OnboardingFieldDefinition(PARTNER_CODE, FieldKind.TEXT, "Introducing partner code", false, true,
                "#forcedValue", null, false, "From Connect", false), webForm);
    }

    private void evaluatePartnerName(Group group, WebForm webForm) {
        applyField(group, new OnboardingFieldDefinition(PARTNER_NAME, FieldKind.TEXT, "Introducing partner name", false, true,
                "#forcedValue", null, false, "From Connect", false), webForm);
    }

    private void evaluatePartnerType(Group group, WebForm webForm) {
        applyField(group, new OnboardingFieldDefinition(PARTNER_TYPE, FieldKind.SELECT, "Partner type", false, true,
                "#forcedValue", null, false, "From CLASS", false), webForm);
    }

    private void evaluateIsPhRepresentative(Group group, WebForm webForm) {
        applyField(group, new OnboardingFieldDefinition(IS_PH_REPRESENTATIVE, FieldKind.SELECT, "Is the PH/EBO a representative (Director/ Shareholder/ Sales Person) of the intermediary who intermediated the policy ?", false, true,
                "#forcedValue", null, false, "Calculated based on Overall case risk", false), webForm);
    }

    private void evaluateReferrerAuto(Group group, WebForm webForm) {
        applyField(group, new OnboardingFieldDefinition(REFERRER_AUTO, FieldKind.SELECT, "Referrer fully automated", true, true,
                "YES\u00acYes;NO\u00acNo", "#PARTNER_TYPE# == \"REFERRER\"", false, null, false), webForm);
    }

    private void evaluatePartnerStatus(Group group, WebForm webForm) {
        applyField(group, new OnboardingFieldDefinition(PARTNER_STATUS, FieldKind.SELECT, "Is the partner status \"Active\"?", false, false,
                "YES\u00acYes;NO\u00acNo", null, false, "From Connect", false), webForm);
    }

    private void evaluateAnalysisOfNeeds(Group group, WebForm webForm) {
        applyField(group, new OnboardingFieldDefinition(ANALYSIS_OF_NEEDS, FieldKind.SELECT, "Analysis of the Demands and needs/ Fact Find received?", true, true,
                "YES\u00acYes;NO\u00acNo", "#PARTNER_TYPE# == \"AGENT_EMP\" || #PARTNER_TYPE# == \"AGENT_IND\" || #PARTNER_TYPE# == \"AGENT_EXT\"", false, null, false), webForm);
    }

    private void evaluateNbIntermediatedDs(Group group, WebForm webForm) {
        applyField(group, new OnboardingFieldDefinition(NB_INTERMEDIATED_DS, FieldKind.SELECT, "Has the New Business been intermediated using the Distance Selling process?", false, true,
                "#forcedValue", null, false, "From CLASS", false), webForm);
    }

    private void evaluateDsConsentReceived(Group group, WebForm webForm) {
        applyField(group, new OnboardingFieldDefinition(DS_CONSENT_RECEIVED, FieldKind.SELECT, "Has the client consent for Distance Selling been received?", true, true,
                "YES\u00acYes;NO\u00acNo", "#NB_INTERMEDIATED_DS# == \"YES\" && (#PARTNER_TYPE# == \"AGENT_EMP\" || #PARTNER_TYPE# == \"AGENT_IND\")", false, null, false), webForm);
    }

    private void evaluateVideoReceived(Group group, WebForm webForm) {
        applyField(group, new OnboardingFieldDefinition(VIDEO_RECEIVED, FieldKind.SELECT, "Has the video been received?", true, true,
                "YES\u00acYes;NO\u00acNo", "#NB_INTERMEDIATED_DS# == \"YES\" && (#PARTNER_TYPE# == \"AGENT_EMP\" || #PARTNER_TYPE# == \"AGENT_IND\")", false, null, false), webForm);
    }

    private void evaluateClientIdentifiable(Group group, WebForm webForm) {
        applyField(group, new OnboardingFieldDefinition(CLIENT_IDENTIFIABLE, FieldKind.SELECT, "Client could be identified on the video?", true, true,
                "YES\u00acYes;NO\u00acNo", "#NB_INTERMEDIATED_DS# == \"YES\" && (#PARTNER_TYPE# == \"AGENT_EMP\" || #PARTNER_TYPE# == \"AGENT_IND\")", false, null, false), webForm);
    }

    private void evaluateHashCheckPerformed(Group group, WebForm webForm) {
        applyField(group, new OnboardingFieldDefinition(HASH_CHECK_PERFORMED, FieldKind.SELECT, "Hash tool checks performed", true, true,
                "YES\u00acYes;NO\u00acNo", "#NB_INTERMEDIATED_DS# == \"YES\" && (#PARTNER_TYPE# == \"AGENT_EMP\" || #PARTNER_TYPE# == \"AGENT_IND\")", false, null, false), webForm);
    }

    private void evaluatePassportCheckPerformed(Group group, WebForm webForm) {
        applyField(group, new OnboardingFieldDefinition(PASSPORT_CHECK_PERFORMED, FieldKind.SELECT, "Have the additional checks on passport been performed?", true, true,
                "YES\u00acYes;NO\u00acNo", "#NB_INTERMEDIATED_DS# == \"YES\" && (#PARTNER_TYPE# == \"AGENT_EMP\" || #PARTNER_TYPE# == \"AGENT_IND\")", false, null, false), webForm);
    }

    private void evaluateRequestDsProcedure(Group group, WebForm webForm) {
        applyField(group, new OnboardingFieldDefinition(REQUEST_DS_PROCEDURE, FieldKind.SELECT, "PCS to request the distance selling procedure from the broker?", false, false,
                "#forcedValue", "#forcedDisplayIf", false, "From CLASS", false), webForm);
    }

    private void evaluateVulnerableIndiciaDetected(Group group, WebForm webForm) {
        applyField(group, new OnboardingFieldDefinition(VULNERABLE_INDICIA_DETECTED, FieldKind.SELECT, "Vulnerable client indicia detected", true, true,
                "YES\u00acYes;NO\u00acNo", null, false, null, false), webForm);
    }

}
