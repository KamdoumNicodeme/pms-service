package com.lombardinternational.casemanagement.service.decision.domain.service.checklist.onboarding.field;

import com.lombardinternational.casemanagement.service.decision.domain.model.policy.Policy;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.*;
import com.lombardinternational.casemanagement.service.decision.domain.model.transaction.BusinessTransaction;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.checklist.FieldBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.spi.repository.ReferenceDataRepositoryService;
import com.lombardinternational.casemanagement.service.decision.domain.utils.ChecklistUtils;
import java.util.List;
import java.util.Map;
import org.springframework.stereotype.Service;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.OnboardingChecklistIds.*;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ReferenceConstants.*;

@Service
public class OnboardingIntermediationFieldsBuilderService extends OnboardingChecklistFieldsBuilderSupport implements FieldBuilderService {
    private final ReferenceDataRepositoryService referenceDataRepositoryService;

    public OnboardingIntermediationFieldsBuilderService(ReferenceDataRepositoryService referenceDataRepositoryService) {
        this.referenceDataRepositoryService = referenceDataRepositoryService;
    }

    @Override
    public void buildField(final WebForm webForm, final ScreenDescription screenDescription, final Group group, final Policy policy, final BusinessTransaction transaction, final Map<String,List<String>> overallCaseRisk) {
        Field.resetFieldId();

        evaluateAppFormSigner(group, webForm);

        evaluatePartnerCode(group, webForm);

        evaluatePartnerName(group, webForm);

        evaluatePartnerType(group, webForm);

        evaluateIsPhRepresentative(group, webForm);

        evaluateReferrerAuto(group, webForm);

        evaluatePartnerStatus(group, webForm);

        evaluateAnalysisOfNeeds(group, webForm);

        evaluateNbIntermediatedDs(group, webForm);

        evaluateDsConsentReceived(group, webForm);

        evaluateVideoReceived(group, webForm);

        evaluateClientIdentifiable(group, webForm);

        evaluateHashCheckPerformed(group, webForm);

        evaluatePassportCheckPerformed(group, webForm);

        evaluateRequestDsProcedure(group, webForm);

        evaluateVulnerableIndiciaDetected(group, webForm);

    }

    private void evaluateAppFormSigner(Group group, WebForm webForm) {
        var appFormSigner = (SelectInputField) ChecklistUtils.getFieldInGroup(group, APP_FORM_SIGNER);
        if (appFormSigner == null) {
            appFormSigner = SelectInputField.builder().fieldId(APP_FORM_SIGNER).build();
            group.getFields().add(appFormSigner);
        }
        appFormSigner.setIsActive(true);
        appFormSigner.incrementOrder();
        appFormSigner.setLabel("Application form signer");
        appFormSigner.setEnabled(true);
        appFormSigner.setMandatory(true);
        appFormSigner.setDisplayIf(null);
        appFormSigner.setLabelBold(false);
        appFormSigner.setSourceSystem(null);
        appFormSigner.setOptions(List.of(new SelectInputFieldOption("BROKER", "Broker"), new SelectInputFieldOption("ILA", "Internal Lombard Agent"), new SelectInputFieldOption("MC", "Marketing Consultant")));
    }

    private void evaluatePartnerCode(Group group, WebForm webForm) {
        var partnerCode = (TextInputField) ChecklistUtils.getFieldInGroup(group, PARTNER_CODE);
        if (partnerCode == null) {
            partnerCode = TextInputField.builder().fieldId(PARTNER_CODE).build();
            group.getFields().add(partnerCode);
        }
        partnerCode.setIsActive(true);
        partnerCode.incrementOrder();
        partnerCode.setLabel("Introducing partner code");
        partnerCode.setEnabled(false);
        partnerCode.setMandatory(true);
        partnerCode.setDisplayIf(null);
        partnerCode.setLabelBold(false);
        partnerCode.setSourceSystem("From Connect");
        selectedValueFromWebForm(PARTNER_CODE, webForm).ifPresent(partnerCode::setSelectedValue);
    }

    private void evaluatePartnerName(Group group, WebForm webForm) {
        var partnerName = (TextInputField) ChecklistUtils.getFieldInGroup(group, PARTNER_NAME);
        if (partnerName == null) {
            partnerName = TextInputField.builder().fieldId(PARTNER_NAME).build();
            group.getFields().add(partnerName);
        }
        partnerName.setIsActive(true);
        partnerName.incrementOrder();
        partnerName.setLabel("Introducing partner name");
        partnerName.setEnabled(false);
        partnerName.setMandatory(true);
        partnerName.setDisplayIf(null);
        partnerName.setLabelBold(false);
        partnerName.setSourceSystem("From Connect");
        selectedValueFromWebForm(PARTNER_NAME, webForm).ifPresent(partnerName::setSelectedValue);
    }

    private void evaluatePartnerType(Group group, WebForm webForm) {
        var partnerType = (SelectInputField) ChecklistUtils.getFieldInGroup(group, PARTNER_TYPE);
        if (partnerType == null) {
            partnerType = SelectInputField.builder().fieldId(PARTNER_TYPE).build();
            group.getFields().add(partnerType);
        }
        partnerType.setIsActive(true);
        partnerType.incrementOrder();
        partnerType.setLabel("Partner type");
        partnerType.setEnabled(false);
        partnerType.setMandatory(true);
        partnerType.setDisplayIf(null);
        partnerType.setLabelBold(false);
        partnerType.setSourceSystem("From CLASS");
        selectedValueFromWebForm(PARTNER_TYPE, webForm).ifPresent(partnerType::setSelectedValue);
        partnerType.setOptions(referenceDataRepositoryService.getReferenceDataOptionsByDomainAndSelectedValue(PARTNER_TYPE_DOMAIN,
                partnerType.getSelectedValue()));
    }

    private void evaluateIsPhRepresentative(Group group, WebForm webForm) {
        var isPhRepresentative = (SelectInputField) ChecklistUtils.getFieldInGroup(group, IS_PH_REPRESENTATIVE);
        if (isPhRepresentative == null) {
            isPhRepresentative = SelectInputField.builder().fieldId(IS_PH_REPRESENTATIVE).build();
            group.getFields().add(isPhRepresentative);
        }
        isPhRepresentative.setIsActive(true);
        isPhRepresentative.incrementOrder();
        isPhRepresentative.setLabel("Is the PH/EBO a representative (Director/ Shareholder/ Sales Person) of the intermediary who intermediated the policy ?");
        isPhRepresentative.setEnabled(false);
        isPhRepresentative.setMandatory(true);
        isPhRepresentative.setDisplayIf(null);
        isPhRepresentative.setLabelBold(false);
        isPhRepresentative.setSourceSystem("Calculated based on Overall case risk");
        selectedValueFromWebForm(IS_PH_REPRESENTATIVE, webForm).ifPresent(isPhRepresentative::setSelectedValue);
    }

    private void evaluateReferrerAuto(Group group, WebForm webForm) {
        var referrerAuto = (SelectInputField) ChecklistUtils.getFieldInGroup(group, REFERRER_AUTO);
        if (referrerAuto == null) {
            referrerAuto = SelectInputField.builder().fieldId(REFERRER_AUTO).build();
            group.getFields().add(referrerAuto);
        }
        referrerAuto.setIsActive(true);
        referrerAuto.incrementOrder();
        referrerAuto.setLabel("Referrer fully automated");
        referrerAuto.setEnabled(true);
        referrerAuto.setMandatory(true);
        referrerAuto.setDisplayIf("#PARTNER_TYPE# == \"REFERRER\"");
        referrerAuto.setLabelBold(false);
        referrerAuto.setSourceSystem(null);
        referrerAuto.setOptions(referenceDataRepositoryService.getReferenceDataOptionsByDomain(YES_NO_DOMAIN));
    }

    private void evaluatePartnerStatus(Group group, WebForm webForm) {
        var partnerStatus = (SelectInputField) ChecklistUtils.getFieldInGroup(group, PARTNER_STATUS);
        if (partnerStatus == null) {
            partnerStatus = SelectInputField.builder().fieldId(PARTNER_STATUS).build();
            group.getFields().add(partnerStatus);
        }
        partnerStatus.setIsActive(true);
        partnerStatus.incrementOrder();
        partnerStatus.setLabel("Is the partner status \"Active\"?");
        partnerStatus.setEnabled(false);
        partnerStatus.setMandatory(false);
        partnerStatus.setDisplayIf(null);
        partnerStatus.setLabelBold(false);
        partnerStatus.setSourceSystem("From Connect");
        partnerStatus.setOptions(referenceDataRepositoryService.getReferenceDataOptionsByDomain(YES_NO_DOMAIN));
    }

    private void evaluateAnalysisOfNeeds(Group group, WebForm webForm) {
        var analysisOfNeeds = (SelectInputField) ChecklistUtils.getFieldInGroup(group, ANALYSIS_OF_NEEDS);
        if (analysisOfNeeds == null) {
            analysisOfNeeds = SelectInputField.builder().fieldId(ANALYSIS_OF_NEEDS).build();
            group.getFields().add(analysisOfNeeds);
        }
        analysisOfNeeds.setIsActive(true);
        analysisOfNeeds.incrementOrder();
        analysisOfNeeds.setLabel("Analysis of the Demands and needs/ Fact Find received?");
        analysisOfNeeds.setEnabled(true);
        analysisOfNeeds.setMandatory(true);
        analysisOfNeeds.setDisplayIf("#PARTNER_TYPE# == \"AGENT_EMP\" || #PARTNER_TYPE# == \"AGENT_IND\" || #PARTNER_TYPE# == \"AGENT_EXT\"");
        analysisOfNeeds.setLabelBold(false);
        analysisOfNeeds.setSourceSystem(null);
        analysisOfNeeds.setOptions(referenceDataRepositoryService.getReferenceDataOptionsByDomain(YES_NO_DOMAIN));
    }

    private void evaluateNbIntermediatedDs(Group group, WebForm webForm) {
        var nbIntermediatedDs = (SelectInputField) ChecklistUtils.getFieldInGroup(group, NB_INTERMEDIATED_DS);
        if (nbIntermediatedDs == null) {
            nbIntermediatedDs = SelectInputField.builder().fieldId(NB_INTERMEDIATED_DS).build();
            group.getFields().add(nbIntermediatedDs);
        }
        nbIntermediatedDs.setIsActive(true);
        nbIntermediatedDs.incrementOrder();
        nbIntermediatedDs.setLabel("Has the New Business been intermediated using the Distance Selling process?");
        nbIntermediatedDs.setEnabled(false);
        nbIntermediatedDs.setMandatory(true);
        nbIntermediatedDs.setDisplayIf(null);
        nbIntermediatedDs.setLabelBold(false);
        nbIntermediatedDs.setSourceSystem("From CLASS");
        selectedValueFromWebForm(NB_INTERMEDIATED_DS, webForm).ifPresent(nbIntermediatedDs::setSelectedValue);
    }

    private void evaluateDsConsentReceived(Group group, WebForm webForm) {
        var dsConsentReceived = (SelectInputField) ChecklistUtils.getFieldInGroup(group, DS_CONSENT_RECEIVED);
        if (dsConsentReceived == null) {
            dsConsentReceived = SelectInputField.builder().fieldId(DS_CONSENT_RECEIVED).build();
            group.getFields().add(dsConsentReceived);
        }
        dsConsentReceived.setIsActive(true);
        dsConsentReceived.incrementOrder();
        dsConsentReceived.setLabel("Has the client consent for Distance Selling been received?");
        dsConsentReceived.setEnabled(true);
        dsConsentReceived.setMandatory(true);
        dsConsentReceived.setDisplayIf("#NB_INTERMEDIATED_DS# == \"YES\" && (#PARTNER_TYPE# == \"AGENT_EMP\" || #PARTNER_TYPE# == \"AGENT_IND\")");
        dsConsentReceived.setLabelBold(false);
        dsConsentReceived.setSourceSystem(null);
        dsConsentReceived.setOptions(referenceDataRepositoryService.getReferenceDataOptionsByDomain(YES_NO_DOMAIN));
    }

    private void evaluateVideoReceived(Group group, WebForm webForm) {
        var videoReceived = (SelectInputField) ChecklistUtils.getFieldInGroup(group, VIDEO_RECEIVED);
        if (videoReceived == null) {
            videoReceived = SelectInputField.builder().fieldId(VIDEO_RECEIVED).build();
            group.getFields().add(videoReceived);
        }
        videoReceived.setIsActive(true);
        videoReceived.incrementOrder();
        videoReceived.setLabel("Has the video been received?");
        videoReceived.setEnabled(true);
        videoReceived.setMandatory(true);
        videoReceived.setDisplayIf("#NB_INTERMEDIATED_DS# == \"YES\" && (#PARTNER_TYPE# == \"AGENT_EMP\" || #PARTNER_TYPE# == \"AGENT_IND\")");
        videoReceived.setLabelBold(false);
        videoReceived.setSourceSystem(null);
        videoReceived.setOptions(referenceDataRepositoryService.getReferenceDataOptionsByDomain(YES_NO_DOMAIN));
    }

    private void evaluateClientIdentifiable(Group group, WebForm webForm) {
        var clientIdentifiable = (SelectInputField) ChecklistUtils.getFieldInGroup(group, CLIENT_IDENTIFIABLE);
        if (clientIdentifiable == null) {
            clientIdentifiable = SelectInputField.builder().fieldId(CLIENT_IDENTIFIABLE).build();
            group.getFields().add(clientIdentifiable);
        }
        clientIdentifiable.setIsActive(true);
        clientIdentifiable.incrementOrder();
        clientIdentifiable.setLabel("Client could be identified on the video?");
        clientIdentifiable.setEnabled(true);
        clientIdentifiable.setMandatory(true);
        clientIdentifiable.setDisplayIf("#NB_INTERMEDIATED_DS# == \"YES\" && (#PARTNER_TYPE# == \"AGENT_EMP\" || #PARTNER_TYPE# == \"AGENT_IND\")");
        clientIdentifiable.setLabelBold(false);
        clientIdentifiable.setSourceSystem(null);
        clientIdentifiable.setOptions(referenceDataRepositoryService.getReferenceDataOptionsByDomain(YES_NO_DOMAIN));
    }

    private void evaluateHashCheckPerformed(Group group, WebForm webForm) {
        var hashCheckPerformed = (SelectInputField) ChecklistUtils.getFieldInGroup(group, HASH_CHECK_PERFORMED);
        if (hashCheckPerformed == null) {
            hashCheckPerformed = SelectInputField.builder().fieldId(HASH_CHECK_PERFORMED).build();
            group.getFields().add(hashCheckPerformed);
        }
        hashCheckPerformed.setIsActive(true);
        hashCheckPerformed.incrementOrder();
        hashCheckPerformed.setLabel("Hash tool checks performed");
        hashCheckPerformed.setEnabled(true);
        hashCheckPerformed.setMandatory(true);
        hashCheckPerformed.setDisplayIf("#NB_INTERMEDIATED_DS# == \"YES\" && (#PARTNER_TYPE# == \"AGENT_EMP\" || #PARTNER_TYPE# == \"AGENT_IND\")");
        hashCheckPerformed.setLabelBold(false);
        hashCheckPerformed.setSourceSystem(null);
        hashCheckPerformed.setOptions(referenceDataRepositoryService.getReferenceDataOptionsByDomain(YES_NO_DOMAIN));
    }

    private void evaluatePassportCheckPerformed(Group group, WebForm webForm) {
        var passportCheckPerformed = (SelectInputField) ChecklistUtils.getFieldInGroup(group, PASSPORT_CHECK_PERFORMED);
        if (passportCheckPerformed == null) {
            passportCheckPerformed = SelectInputField.builder().fieldId(PASSPORT_CHECK_PERFORMED).build();
            group.getFields().add(passportCheckPerformed);
        }
        passportCheckPerformed.setIsActive(true);
        passportCheckPerformed.incrementOrder();
        passportCheckPerformed.setLabel("Have the additional checks on passport been performed?");
        passportCheckPerformed.setEnabled(true);
        passportCheckPerformed.setMandatory(true);
        passportCheckPerformed.setDisplayIf("#NB_INTERMEDIATED_DS# == \"YES\" && (#PARTNER_TYPE# == \"AGENT_EMP\" || #PARTNER_TYPE# == \"AGENT_IND\")");
        passportCheckPerformed.setLabelBold(false);
        passportCheckPerformed.setSourceSystem(null);
        passportCheckPerformed.setOptions(referenceDataRepositoryService.getReferenceDataOptionsByDomain(YES_NO_DOMAIN));
    }

    private void evaluateRequestDsProcedure(Group group, WebForm webForm) {
        var requestDsProcedure = (SelectInputField) ChecklistUtils.getFieldInGroup(group, REQUEST_DS_PROCEDURE);
        if (requestDsProcedure == null) {
            requestDsProcedure = SelectInputField.builder().fieldId(REQUEST_DS_PROCEDURE).build();
            group.getFields().add(requestDsProcedure);
        }
        requestDsProcedure.setIsActive(true);
        requestDsProcedure.incrementOrder();
        requestDsProcedure.setLabel("PCS to request the distance selling procedure from the broker?");
        requestDsProcedure.setEnabled(false);
        requestDsProcedure.setMandatory(false);
        requestDsProcedure.setDisplayIf("#forcedDisplayIf");
        requestDsProcedure.setLabelBold(false);
        requestDsProcedure.setSourceSystem("From CLASS");
        selectedValueFromWebForm(REQUEST_DS_PROCEDURE, webForm).ifPresent(requestDsProcedure::setSelectedValue);
    }

    private void evaluateVulnerableIndiciaDetected(Group group, WebForm webForm) {
        var vulnerableIndiciaDetected = (SelectInputField) ChecklistUtils.getFieldInGroup(group, VULNERABLE_INDICIA_DETECTED);
        if (vulnerableIndiciaDetected == null) {
            vulnerableIndiciaDetected = SelectInputField.builder().fieldId(VULNERABLE_INDICIA_DETECTED).build();
            group.getFields().add(vulnerableIndiciaDetected);
        }
        vulnerableIndiciaDetected.setIsActive(true);
        vulnerableIndiciaDetected.incrementOrder();
        vulnerableIndiciaDetected.setLabel("Vulnerable client indicia detected");
        vulnerableIndiciaDetected.setEnabled(true);
        vulnerableIndiciaDetected.setMandatory(true);
        vulnerableIndiciaDetected.setDisplayIf(null);
        vulnerableIndiciaDetected.setLabelBold(false);
        vulnerableIndiciaDetected.setSourceSystem(null);
        vulnerableIndiciaDetected.setOptions(referenceDataRepositoryService.getReferenceDataOptionsByDomain(YES_NO_DOMAIN));
    }
}
