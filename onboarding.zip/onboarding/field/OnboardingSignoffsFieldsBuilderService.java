package com.lombardinternational.casemanagement.service.decision.domain.service.checklist.onboarding.field;

import com.lombardinternational.casemanagement.service.decision.domain.model.policy.Policy;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.*;
import com.lombardinternational.casemanagement.service.decision.domain.model.transaction.BusinessTransaction;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.checklist.FieldBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.spi.repository.ReferenceDataRepositoryService;
import com.lombardinternational.casemanagement.service.decision.domain.utils.ChecklistUtils;
import java.util.List;
import java.util.Map;
import org.springframework.stereotype.Service;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.OnboardingChecklistIds.*;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ReferenceConstants.*;

@Service
public class OnboardingSignoffsFieldsBuilderService extends OnboardingChecklistFieldsBuilderSupport implements FieldBuilderService {
    private final ReferenceDataRepositoryService referenceDataRepositoryService;

    public OnboardingSignoffsFieldsBuilderService(ReferenceDataRepositoryService referenceDataRepositoryService) {
        this.referenceDataRepositoryService = referenceDataRepositoryService;
    }

    @Override
    public void buildField(final WebForm webForm, final ScreenDescription screenDescription, final Group group, final Policy policy, final BusinessTransaction transaction, final Map<String,List<String>> overallCaseRisk) {
        Field.resetFieldId();

        evaluateTransactionFeedback(group, webForm);

    }

    private void evaluateTransactionFeedback(Group group, WebForm webForm) {
        var transactionFeedback = (SelectInputField) ChecklistUtils.getFieldInGroup(group, TRANSACTION_FEEDBACK);
        if (transactionFeedback == null) {
            transactionFeedback = SelectInputField.builder().fieldId(TRANSACTION_FEEDBACK).build();
            group.getFields().add(transactionFeedback);
        }
        transactionFeedback.setIsActive(true);
        transactionFeedback.incrementOrder();
        transactionFeedback.setLabel("Transaction feedback");
        transactionFeedback.setEnabled(true);
        transactionFeedback.setMandatory(false);
        transactionFeedback.setDisplayIf(null);
        transactionFeedback.setLabelBold(false);
        transactionFeedback.setSourceSystem(null);
        transactionFeedback.setOptions(referenceDataRepositoryService.getReferenceDataOptionsByDomain(TRANSACTION_FEEDBACK_DOMAIN));
    }
}
