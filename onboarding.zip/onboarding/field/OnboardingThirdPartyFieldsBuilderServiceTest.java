package com.lombardinternational.casemanagement.service.decision.domain.service.checklist.onboarding.field;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.SelectInputField;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.TextAreaField;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.TextInputField;
import com.lombardinternational.casemanagement.service.decision.domain.utils.FieldHelper;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.OnboardingChecklistIds.*;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ReferenceConstants.COUNTRY_DOMAIN;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ReferenceConstants.THIRD_PARTY_TYPE_DOMAIN;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
class OnboardingThirdPartyFieldsBuilderServiceTest extends OnboardingFieldsBuilderTestSupport {

    @InjectMocks
    private OnboardingThirdPartyFieldsBuilderService builderService;

    @Test
    void buildThirdPartyFieldsOK() {

        var group = group(THIRD_PARTY_GROUP);

        builderService.buildField(webForm(), screenDescription(), group, policy(), transaction(), overallCaseRisk());

        assertEquals(6, group.getFields().size());
        FieldHelper.testFieldValue(THIRD_PARTY_NAME, TextInputField.class, group, null, 1, null, true, false);
        FieldHelper.testSelectFieldValue(LINK_THIRD_PARTY_PH, SelectInputField.class, group, null, 2, null, true, false, 4);
        FieldHelper.testFieldValue(ADDITIONAL_INFO_LINK, TextAreaField.class, group, null, 3, "#LINK_THIRD_PARTY_PH# == \"other\"", false, true);
        FieldHelper.testSelectFieldValue(THIRD_PARTY_COUNTRY, SelectInputField.class, group, null, 5, null, true, false, 3);
        verify(referenceDataRepositoryService).getReferenceDataOptionsByDomainAndSelectedValue(THIRD_PARTY_TYPE_DOMAIN, null);
        verify(referenceDataRepositoryService).getReferenceDataOptionsByDomainAndSelectedValue(COUNTRY_DOMAIN, null);
    }
}
