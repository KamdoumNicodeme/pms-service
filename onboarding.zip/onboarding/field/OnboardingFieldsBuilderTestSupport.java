package com.lombardinternational.casemanagement.service.decision.domain.service.checklist.onboarding.field;

import com.lombardinternational.casemanagement.service.decision.domain.model.policy.Policy;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Group;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.SelectInputFieldOption;
import com.lombardinternational.casemanagement.service.decision.domain.model.transaction.BusinessTransaction;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.TextWebFormField;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebFormGroup;
import com.lombardinternational.casemanagement.service.decision.domain.spi.repository.ReferenceDataRepositoryService;
import com.lombardinternational.casemanagement.service.decision.domain.utils.PolicyBuilderServiceHelper;
import com.lombardinternational.casemanagement.service.decision.domain.utils.ReferenceServiceHelper;
import com.lombardinternational.casemanagement.service.decision.domain.utils.TransactionBuilderServiceHelper;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.BeforeEach;
import org.mockito.Mock;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ChecklistFieldConstants.UNDER_WRITINGS_OPTIONS;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ReferenceConstants.*;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.lenient;

abstract class OnboardingFieldsBuilderTestSupport {

    @Mock
    protected ReferenceDataRepositoryService referenceDataRepositoryService;

    @BeforeEach
    void initReferenceDataRepositoryService() {

        lenient().when(referenceDataRepositoryService.getReferenceDataOptionsByDomain(anyString()))
                .thenAnswer(invocation -> referenceOptions(invocation.getArgument(0)));
        lenient().when(referenceDataRepositoryService.getReferenceDataOptionsByDomainAndSelectedValue(anyString(), org.mockito.ArgumentMatchers.any()))
                .thenAnswer(invocation -> selectedReferenceOptions(invocation.getArgument(0), invocation.getArgument(1)));
    }

    protected Policy policy() {

        return PolicyBuilderServiceHelper.createPolicy();
    }

    protected WebForm webForm() {

        return new WebForm();
    }

    protected WebForm webFormWithTextFields(TextWebFormField... fields) {

        return WebForm.builder()
                .groups(List.of(WebFormGroup.builder().textFields(List.of(fields)).build()))
                .build();
    }

    protected BusinessTransaction transaction() {

        return TransactionBuilderServiceHelper.createTransaction();
    }

    protected ScreenDescription screenDescription() {

        return new ScreenDescription();
    }

    protected Map<String,List<String>> overallCaseRisk() {

        return Map.of("BLOCKED", new ArrayList<>());
    }

    protected Group group(String groupId) {

        return Group.builder().groupId(groupId).build();
    }

    private List<SelectInputFieldOption> selectedReferenceOptions(String domain, String selectedValue) {

        var options = referenceOptions(domain);
        if (selectedValue == null) {
            return options;
        }
        return options.stream()
                .filter(option -> option.getKey().equalsIgnoreCase(selectedValue))
                .toList();
    }

    private List<SelectInputFieldOption> referenceOptions(String domain) {

        return switch (domain) {
            case YES_NO_DOMAIN -> ReferenceServiceHelper.getYesNoOptions();
            case YES_NO_NA_NEW_BUSINESS_VALUES_DOMAIN -> ReferenceServiceHelper.getYesNoNaOptions();
            case COUNTRY_DOMAIN -> ReferenceServiceHelper.getCountryOptions();
            case INDUSTRY_SECTOR_DOMAIN -> ReferenceServiceHelper.getIndustrySectorOptions();
            case PROFESSION_DOMAIN -> ReferenceServiceHelper.getProfessionOptions();
            case THIRD_PARTY_TYPE_DOMAIN -> ReferenceServiceHelper.getThirdPartyTypeOptions();
            case PARTNER_TYPE_DOMAIN -> ReferenceServiceHelper.getPartnerTypeOptions();
            case COMPLIANCE_LEVEL_DOMAIN -> ReferenceServiceHelper.getComplianceLevelOptions();
            case SIGNATURE_DOMAIN -> ReferenceServiceHelper.getSignatureDomain();
            case PROVIDER_DOMAIN -> ReferenceServiceHelper.getProviderDomain();
            case TRANSACTION_FEEDBACK_DOMAIN -> ReferenceServiceHelper.getTransactionFeedbackOptions();
            case UNDER_WRITINGS_OPTIONS -> ReferenceServiceHelper.getUnderWritingsOptions();
            default -> List.of();
        };
    }
}
