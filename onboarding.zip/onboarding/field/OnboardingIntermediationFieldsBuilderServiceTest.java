package com.lombardinternational.casemanagement.service.decision.domain.service.checklist.onboarding.field;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.SelectInputField;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.TextInputField;
import com.lombardinternational.casemanagement.service.decision.domain.utils.ChecklistUtils;
import com.lombardinternational.casemanagement.service.decision.domain.utils.FieldHelper;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.OnboardingChecklistIds.*;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ReferenceConstants.PARTNER_TYPE_DOMAIN;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ReferenceConstants.YES_NO_DOMAIN;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
class OnboardingIntermediationFieldsBuilderServiceTest extends OnboardingFieldsBuilderTestSupport {

    @InjectMocks
    private OnboardingIntermediationFieldsBuilderService builderService;

    @Test
    void buildIntermediationFieldsOK() {

        var group = group(INTERMEDIATION_GROUP);

        builderService.buildField(webForm(), screenDescription(), group, policy(), transaction(), overallCaseRisk());

        assertEquals(16, group.getFields().size());
        FieldHelper.testSelectFieldValue(APP_FORM_SIGNER, SelectInputField.class, group, null, 1, null, true, true, 3);
        FieldHelper.testFieldValue(PARTNER_CODE, TextInputField.class, group, null, 2, null, true, false);
        FieldHelper.testFieldValue(PARTNER_NAME, TextInputField.class, group, null, 3, null, true, false);
        FieldHelper.testSelectFieldValue(PARTNER_TYPE, SelectInputField.class, group, null, 4, null, true, false, 4);
        FieldHelper.testSelectFieldValue(DS_CONSENT_RECEIVED, SelectInputField.class, group, null, 10,
                "#NB_INTERMEDIATED_DS# == \"YES\" && (#PARTNER_TYPE# == \"AGENT_EMP\" || #PARTNER_TYPE# == \"AGENT_IND\")", true, true, 2);
        FieldHelper.testSelectFieldValue(VULNERABLE_INDICIA_DETECTED, SelectInputField.class, group, null, 16, null, true, true, 2);
        var signer = (SelectInputField) ChecklistUtils.getFieldInGroup(group, APP_FORM_SIGNER);
        assertEquals("BROKER", signer.getOptions().getFirst().getKey());
        verify(referenceDataRepositoryService).getReferenceDataOptionsByDomainAndSelectedValue(PARTNER_TYPE_DOMAIN, null);
        verify(referenceDataRepositoryService, org.mockito.Mockito.atLeastOnce()).getReferenceDataOptionsByDomain(YES_NO_DOMAIN);
    }
}
