package com.lombardinternational.casemanagement.service.decision.domain.service.checklist.onboarding.enrichment;

import com.lombardinternational.casemanagement.service.decision.domain.service.AmountService;
import com.lombardinternational.casemanagement.service.decision.domain.model.policy.Amount;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Field;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.utils.ChecklistUtils;
import com.lombardinternational.casemanagement.service.decision.domain.utils.WebformUtils;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.Locale;
import java.util.Optional;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.OnboardingChecklistIds.EXPECTED_PREM;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.OnboardingChecklistIds.EXPECTED_PREM_EUR;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.OnboardingChecklistIds.POLICY_CUR;

@Service
@RequiredArgsConstructor
public class ExpectedPremiumInEurEnrichmentService {
    private static final String EUR = "EUR";

    private final AmountService amountService;

    public void enrich(ScreenDescription checklist, WebForm webForm) {
        var targetField = ChecklistUtils.getFieldById(checklist, EXPECTED_PREM_EUR).orElse(null);
        if (targetField == null || hasText(targetField.getSelectedValue())) {
            return;
        }

        var policyCurrency = valueOf(checklist, webForm, POLICY_CUR).map(this::normalizeCurrency).orElse(null);
        if (!hasText(policyCurrency) || EUR.equals(policyCurrency)) {
            return;
        }

        valueOf(checklist, webForm, EXPECTED_PREM)
                .flatMap(this::parseAmount)
                .map(amount -> new Amount(amount, policyCurrency))
                .map(amount -> amountService.convertAmount(amount, EUR))
                .map(Amount::getQuantity)
                .map(BigDecimal::toPlainString)
                .ifPresent(targetField::setSelectedValue);
    }

    private Optional<String> valueOf(ScreenDescription checklist, WebForm webForm, String fieldId) {
        return ChecklistUtils.getFieldById(checklist, fieldId)
                .map(Field::getSelectedValue)
                .filter(this::hasText)
                .or(() -> valueOf(webForm, fieldId));
    }

    private Optional<String> valueOf(WebForm webForm, String fieldId) {
        if (webForm == null || webForm.getGroups() == null) {
            return Optional.empty();
        }
        return Optional.ofNullable(WebformUtils.getFirstWebFormField(webForm, fieldId))
                .map(WebformUtils::getValueForWebFormField)
                .filter(this::hasText)
                .filter(value -> !"N/A".equals(value));
    }

    private Optional<BigDecimal> parseAmount(String value) {
        try {
            return Optional.of(new BigDecimal(value.replace(" ", "").replace(",", ".")));
        } catch (NumberFormatException ex) {
            return Optional.empty();
        }
    }

    private String normalizeCurrency(String currency) {
        return currency == null ? null : currency.trim().toUpperCase(Locale.ROOT);
    }

    private boolean hasText(String value) {
        return value != null && !value.isBlank();
    }
}
