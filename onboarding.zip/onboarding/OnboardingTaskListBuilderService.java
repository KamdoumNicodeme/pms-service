package com.lombardinternational.casemanagement.service.decision.domain.service.tasklist.onboarding;

import com.lombardinternational.casemanagement.service.decision.domain.model.policy.Policy;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.TaskDefinition;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.tasklist.AbstractTaskBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.tasklist.TaskListBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.tasklist.onboarding.task.common.AmlSignOffOnboardingTaskBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.tasklist.onboarding.task.common.ComplexOnboardingTaskBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.tasklist.onboarding.task.common.DailyOperationsTeamOnboardingTaskBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.tasklist.onboarding.task.common.EbacEscalationOnboardingTaskBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.tasklist.onboarding.task.common.FreeSubTaskOnboardingTaskBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.tasklist.onboarding.task.common.FreeTaskOnboardingTaskBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.tasklist.onboarding.task.common.InadmissibleAssetOnboardingTaskBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.tasklist.onboarding.task.common.NtaNotificationOnboardingTaskBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.tasklist.onboarding.task.common.PhysicalBacEscalationOnboardingTaskBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.tasklist.onboarding.task.common.StrategyMonitoringOnboardingTaskBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.tasklist.onboarding.task.compliance.DefaultOptionalComplianceOnboardingTaskBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.tasklist.onboarding.task.compliance.EboResidenceTaxComplianceTaskBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.tasklist.onboarding.task.compliance.ItalianBranchPepComplianceTaskBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.tasklist.onboarding.task.compliance.MarketAbuseComplianceTaskBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.tasklist.onboarding.task.compliance.PcsReviewEscalationComplianceTaskBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.tasklist.onboarding.task.compliance.ResidenceVsFiscalCountryComplianceTaskBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.tasklist.onboarding.task.compliance.TccNotSignedComplianceTaskBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.tasklist.onboarding.task.ic.DefaultOptionalICOnboardingTaskBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.tasklist.onboarding.task.ic.PremiumWithAssetsICOnboardingTaskBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.tasklist.onboarding.task.unquoted.DefaultOptionalUnquotedOnboardingTaskBuilderService;
import java.util.ArrayList;
import java.util.List;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@AllArgsConstructor
public class OnboardingTaskListBuilderService implements TaskListBuilderService {

    private final PcsReviewEscalationComplianceTaskBuilderService pcsReviewEscalationComplianceTaskBuilderService;
    private final MarketAbuseComplianceTaskBuilderService marketAbuseComplianceTaskBuilderService;
    private final ItalianBranchPepComplianceTaskBuilderService italianBranchPepComplianceTaskBuilderService;
    private final EboResidenceTaxComplianceTaskBuilderService eboResidenceTaxComplianceTaskBuilderService;
    private final ResidenceVsFiscalCountryComplianceTaskBuilderService residenceVsFiscalCountryComplianceTaskBuilderService;
    private final TccNotSignedComplianceTaskBuilderService tccNotSignedComplianceTaskBuilderService;
    private final DefaultOptionalComplianceOnboardingTaskBuilderService defaultOptionalComplianceOnboardingTaskBuilderService;
    private final PremiumWithAssetsICOnboardingTaskBuilderService premiumWithAssetsICOnboardingTaskBuilderService;
    private final DefaultOptionalICOnboardingTaskBuilderService defaultOptionalICOnboardingTaskBuilderService;
    private final DefaultOptionalUnquotedOnboardingTaskBuilderService defaultOptionalUnquotedOnboardingTaskBuilderService;
    private final StrategyMonitoringOnboardingTaskBuilderService strategyMonitoringOnboardingTaskBuilderService;
    private final DailyOperationsTeamOnboardingTaskBuilderService dailyOperationsTeamOnboardingTaskBuilderService;
    private final ComplexOnboardingTaskBuilderService complexOnboardingTaskBuilderService;
    private final EbacEscalationOnboardingTaskBuilderService ebacEscalationOnboardingTaskBuilderService;
    private final PhysicalBacEscalationOnboardingTaskBuilderService physicalBacEscalationOnboardingTaskBuilderService;
    private final InadmissibleAssetOnboardingTaskBuilderService inadmissibleAssetOnboardingTaskBuilderService;
    private final NtaNotificationOnboardingTaskBuilderService ntaNotificationOnboardingTaskBuilderService;
    private final FreeTaskOnboardingTaskBuilderService freeTaskOnboardingTaskBuilderService;
    private final FreeSubTaskOnboardingTaskBuilderService freeSubTaskOnboardingTaskBuilderService;
    private final AmlSignOffOnboardingTaskBuilderService amlSignOffOnboardingTaskBuilderService;

    @Override
    public List<TaskDefinition> buildTaskList(final Policy policy, final WebForm webForm, final ScreenDescription screenDescription) {

        TaskDefinition.resetTaskOrder();
        List<AbstractTaskBuilderService> taskBuilderServices = List.of(pcsReviewEscalationComplianceTaskBuilderService,
                marketAbuseComplianceTaskBuilderService, italianBranchPepComplianceTaskBuilderService,
                eboResidenceTaxComplianceTaskBuilderService, residenceVsFiscalCountryComplianceTaskBuilderService,
                tccNotSignedComplianceTaskBuilderService, defaultOptionalComplianceOnboardingTaskBuilderService,
                premiumWithAssetsICOnboardingTaskBuilderService, defaultOptionalICOnboardingTaskBuilderService,
                defaultOptionalUnquotedOnboardingTaskBuilderService, strategyMonitoringOnboardingTaskBuilderService,
                dailyOperationsTeamOnboardingTaskBuilderService, complexOnboardingTaskBuilderService,
                ebacEscalationOnboardingTaskBuilderService, physicalBacEscalationOnboardingTaskBuilderService,
                inadmissibleAssetOnboardingTaskBuilderService, ntaNotificationOnboardingTaskBuilderService,
                freeTaskOnboardingTaskBuilderService, freeSubTaskOnboardingTaskBuilderService, amlSignOffOnboardingTaskBuilderService);

        final var taskDefinitions = new ArrayList<TaskDefinition>();
        taskBuilderServices.forEach(service -> service.buildTask(policy, webForm, screenDescription, taskDefinitions));
        return taskDefinitions;
    }
}
