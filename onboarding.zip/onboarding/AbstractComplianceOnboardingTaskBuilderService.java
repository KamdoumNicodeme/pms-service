package com.lombardinternational.casemanagement.service.decision.domain.service.tasklist.onboarding;

public abstract class AbstractComplianceOnboardingTaskBuilderService extends AbstractOnboardingTaskBuilderService {

    @Override
    public String getTaskName() {

        return "Compliance check";
    }

    @Override
    public String getTaskDynamicScreenId() {

        return "COMPLIANCE_NEW_BUSINESS";
    }

    @Override
    public int getRulePriority() {

        return 10;
    }
}
