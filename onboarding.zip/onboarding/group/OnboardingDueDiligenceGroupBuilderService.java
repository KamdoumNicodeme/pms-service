package com.lombardinternational.casemanagement.service.decision.domain.service.checklist.onboarding.group;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Group;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.policy.Policy;
import com.lombardinternational.casemanagement.service.decision.domain.model.transaction.BusinessTransaction;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Tab;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.checklist.GroupBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.checklist.onboarding.field.OnboardingDueDiligenceFieldsBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.utils.RulesUtils;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.OnboardingChecklistIds.DUE_DILIGENCE_GROUP;

@Service
@AllArgsConstructor
public class OnboardingDueDiligenceGroupBuilderService implements GroupBuilderService {
    private final OnboardingDueDiligenceFieldsBuilderService fieldsBuilderService;

    @Override
    public void buildGroup(final WebForm webForm, final ScreenDescription screenDescription, final Tab parentTab, final Policy policy, final BusinessTransaction transaction, final Map<String,List<String>> overallCaseRisk) {
        var group = RulesUtils.getGroupInTab(parentTab, DUE_DILIGENCE_GROUP);
        if (group == null) {
            group = Group.builder().groupId(DUE_DILIGENCE_GROUP).build();
            parentTab.getGroups().add(group);
        }

        group.setIsActive(true);
        group.incrementOrder();
        group.setTitle("Due diligence - EBO and related parties to the policy");
        group.setColumnsCount(2);
        group.setDisplayIf(null);
        fieldsBuilderService.buildField(webForm, screenDescription, group, policy, transaction, overallCaseRisk);
    }
}
