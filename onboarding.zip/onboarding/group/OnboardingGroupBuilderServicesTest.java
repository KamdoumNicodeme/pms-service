package com.lombardinternational.casemanagement.service.decision.domain.service.checklist.onboarding.group;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Group;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Tab;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.checklist.GroupBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.checklist.onboarding.field.OnboardingCaseRiskFieldsBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.checklist.onboarding.field.OnboardingDueDiligenceFieldsBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.checklist.onboarding.field.OnboardingGeneralDetailsFieldsBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.checklist.onboarding.field.OnboardingIntermediationFieldsBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.checklist.onboarding.field.OnboardingLifeCoverFieldsBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.checklist.onboarding.field.OnboardingPricingApprovalFieldsBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.checklist.onboarding.field.OnboardingSignatureFieldsBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.checklist.onboarding.field.OnboardingSignoffsFieldsBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.checklist.onboarding.field.OnboardingThirdPartyFieldsBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.checklist.onboarding.field.OnboardingTransactionDetailsFieldsBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.utils.PolicyBuilderServiceHelper;
import com.lombardinternational.casemanagement.service.decision.domain.utils.TransactionBuilderServiceHelper;
import java.util.ArrayList;
import java.util.Map;
import java.util.function.Consumer;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.OnboardingChecklistIds.*;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
class OnboardingGroupBuilderServicesTest {

    @Mock
    private OnboardingGeneralDetailsFieldsBuilderService generalDetailsFieldsBuilderService;
    @Mock
    private OnboardingLifeCoverFieldsBuilderService lifeCoverFieldsBuilderService;
    @Mock
    private OnboardingIntermediationFieldsBuilderService intermediationFieldsBuilderService;
    @Mock
    private OnboardingSignatureFieldsBuilderService signatureFieldsBuilderService;
    @Mock
    private OnboardingPricingApprovalFieldsBuilderService pricingApprovalFieldsBuilderService;
    @Mock
    private OnboardingSignoffsFieldsBuilderService signoffsFieldsBuilderService;
    @Mock
    private OnboardingDueDiligenceFieldsBuilderService dueDiligenceFieldsBuilderService;
    @Mock
    private OnboardingTransactionDetailsFieldsBuilderService transactionDetailsFieldsBuilderService;
    @Mock
    private OnboardingThirdPartyFieldsBuilderService thirdPartyFieldsBuilderService;
    @Mock
    private OnboardingCaseRiskFieldsBuilderService caseRiskFieldsBuilderService;

    @BeforeEach
    void initTest() {

        Group.resetGroupId();
    }

    @Test
    void buildGeneralDetailsGroupOK() {

        assertBuildsGroup(new OnboardingGeneralDetailsGroupBuilderService(generalDetailsFieldsBuilderService), GENERAL_DETAILS_GROUP,
                "General details - New Business", null);
        verify(generalDetailsFieldsBuilderService, times(1)).buildField(any(), any(), any(), any(), any(), any());
    }

    @Test
    void buildLifeCoverGroupOK() {

        assertBuildsGroup(new OnboardingLifeCoverGroupBuilderService(lifeCoverFieldsBuilderService), LIFE_COVER_GROUP, "Life Cover Type",
                "#CONTRACT_TYPE# == \"Capitalised policy\"");
        verify(lifeCoverFieldsBuilderService, times(1)).buildField(any(), any(), any(), any(), any(), any());
    }

    @Test
    void buildIntermediationGroupOK() {

        assertBuildsGroup(new OnboardingIntermediationGroupBuilderService(intermediationFieldsBuilderService), INTERMEDIATION_GROUP,
                "Intermediation", null);
        verify(intermediationFieldsBuilderService, times(1)).buildField(any(), any(), any(), any(), any(), any());
    }

    @Test
    void buildSignatureGroupOK() {

        assertBuildsGroup(new OnboardingSignatureGroupBuilderService(signatureFieldsBuilderService), SIGNATURE_GROUP, "Signature", null);
        verify(signatureFieldsBuilderService, times(1)).buildField(any(), any(), any(), any(), any(), any());
    }

    @Test
    void buildPricingApprovalGroupOK() {

        assertBuildsGroup(new OnboardingPricingApprovalGroupBuilderService(pricingApprovalFieldsBuilderService), PRICING_APPROVAL_GROUP,
                "Pricing Approval", null);
        verify(pricingApprovalFieldsBuilderService, times(1)).buildField(any(), any(), any(), any(), any(), any());
    }

    @Test
    void buildSignoffsGroupOK() {

        assertBuildsGroup(new OnboardingSignoffsGroupBuilderService(signoffsFieldsBuilderService), SIGNOFFS_GROUP, "Sign offs", null);
        verify(signoffsFieldsBuilderService, times(1)).buildField(any(), any(), any(), any(), any(), any());
    }

    @Test
    void buildDueDiligenceGroupOK() {

        assertBuildsGroup(new OnboardingDueDiligenceGroupBuilderService(dueDiligenceFieldsBuilderService), DUE_DILIGENCE_GROUP,
                "Due diligence - EBO and related parties to the policy", null);
        verify(dueDiligenceFieldsBuilderService, times(1)).buildField(any(), any(), any(), any(), any(), any());
    }

    @Test
    void buildTransactionDetailsGroupOK() {

        assertBuildsGroup(new OnboardingTransactionDetailsGroupBuilderService(transactionDetailsFieldsBuilderService), TRANSACTIONS_DETAILS_GROUP,
                "Transaction details", null);
        verify(transactionDetailsFieldsBuilderService, times(1)).buildField(any(), any(), any(), any(), any(), any());
    }

    @Test
    void buildThirdPartyGroupOK() {

        assertBuildsGroup(new OnboardingThirdPartyGroupBuilderService(thirdPartyFieldsBuilderService), THIRD_PARTY_GROUP, "Payment from third party",
                "#PAYMENT_THIRD_PARTY# == \"YES\"");
        verify(thirdPartyFieldsBuilderService, times(1)).buildField(any(), any(), any(), any(), any(), any());
    }

    @Test
    void buildCaseRiskGroupOK() {

        assertBuildsGroup(new OnboardingCaseRiskGroupBuilderService(caseRiskFieldsBuilderService), CASE_RISK_GROUP, "Escalation level", null);
        verify(caseRiskFieldsBuilderService, times(1)).buildField(any(), any(), any(), any(), any(), any());
    }

    @Test
    void buildGroupReusesExistingGroup() {

        var builderService = new OnboardingGeneralDetailsGroupBuilderService(generalDetailsFieldsBuilderService);
        var existingGroup = Group.builder().groupId(GENERAL_DETAILS_GROUP).build();

        assertBuildsGroup(builderService, GENERAL_DETAILS_GROUP, "General details - New Business", null, tab -> tab.getGroups().add(existingGroup));
        verify(generalDetailsFieldsBuilderService, times(1)).buildField(any(), any(), any(), any(), any(), any());
    }

    private void assertBuildsGroup(GroupBuilderService builderService, String groupId, String title, String displayIf) {

        assertBuildsGroup(builderService, groupId, title, displayIf, tab -> {
        });
    }

    private void assertBuildsGroup(GroupBuilderService builderService, String groupId, String title, String displayIf,
            Consumer<Tab> tabCustomizer) {

        var webForm = new WebForm();
        var screenDescription = new ScreenDescription();
        var tab = new Tab();
        var policy = PolicyBuilderServiceHelper.createPolicy();
        var transaction = TransactionBuilderServiceHelper.createTransaction();

        tabCustomizer.accept(tab);
        builderService.buildGroup(webForm, screenDescription, tab, policy, transaction, Map.of("BLOCKED", new ArrayList<>()));

        assertEquals(1, tab.getGroups().size());
        var group = tab.getGroups().getFirst();
        assertEquals(groupId, group.getGroupId());
        assertTrue(group.getIsActive());
        assertEquals(1, group.getOrder());
        assertEquals(title, group.getTitle());
        assertEquals(2, group.getColumnsCount());
        assertEquals(displayIf, group.getDisplayIf());
    }
}
