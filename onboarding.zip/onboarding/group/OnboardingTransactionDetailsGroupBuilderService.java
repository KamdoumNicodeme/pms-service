package com.lombardinternational.casemanagement.service.decision.domain.service.checklist.onboarding.group;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Group;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.policy.Policy;
import com.lombardinternational.casemanagement.service.decision.domain.model.transaction.BusinessTransaction;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Tab;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.checklist.GroupBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.checklist.onboarding.field.OnboardingTransactionDetailsFieldsBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.utils.RulesUtils;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.OnboardingChecklistIds.TRANSACTIONS_DETAILS_GROUP;

@Service
@AllArgsConstructor
public class OnboardingTransactionDetailsGroupBuilderService implements GroupBuilderService {
    private final OnboardingTransactionDetailsFieldsBuilderService fieldsBuilderService;

    @Override
    public void buildGroup(final WebForm webForm, final ScreenDescription screenDescription, final Tab parentTab, final Policy policy, final BusinessTransaction transaction, final Map<String,List<String>> overallCaseRisk) {
        var transactionDetailsGroup = RulesUtils.getGroupInTab(parentTab, TRANSACTIONS_DETAILS_GROUP);
        if (transactionDetailsGroup == null) {
            transactionDetailsGroup = Group.builder().groupId(TRANSACTIONS_DETAILS_GROUP).build();
            parentTab.getGroups().add(transactionDetailsGroup);
        }

        transactionDetailsGroup.setIsActive(true);
        transactionDetailsGroup.incrementOrder();
        transactionDetailsGroup.setTitle("Transaction details");
        transactionDetailsGroup.setColumnsCount(2);
        transactionDetailsGroup.setDisplayIf(null);
        fieldsBuilderService.buildField(webForm, screenDescription, transactionDetailsGroup, policy, transaction, overallCaseRisk);
    }
}
