package com.lombardinternational.casemanagement.service.decision.domain.service.tasklist.onboarding;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Field;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.service.tasklist.AbstractTaskBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.utils.ChecklistUtils;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.Optional;

public abstract class AbstractOnboardingTaskBuilderService extends AbstractTaskBuilderService {

    protected static final int ONE_DAY = 60 * 60 * 24;
    protected static final int TWO_DAYS = ONE_DAY * 2;
    protected static final int THIRTY_DAYS = ONE_DAY * 30;

    protected static final String YES = "YES";
    protected static final String NO = "NO";

    protected Optional<String> fieldValue(final ScreenDescription screenDescription, final String fieldId) {

        return ChecklistUtils.getFieldById(screenDescription, fieldId).map(Field::getSelectedValue)
                .filter(value -> value != null && !value.isBlank());
    }

    protected boolean fieldEquals(final ScreenDescription screenDescription, final String fieldId, final String expectedValue) {

        return fieldValue(screenDescription, fieldId).map(expectedValue::equals).orElse(false);
    }

    protected boolean fieldNotEquals(final ScreenDescription screenDescription, final String fieldId, final String expectedValue) {

        return fieldValue(screenDescription, fieldId).map(value -> !expectedValue.equals(value)).orElse(false);
    }

    protected boolean fieldIn(final ScreenDescription screenDescription, final String fieldId, final Collection<String> expectedValues) {

        return fieldValue(screenDescription, fieldId).map(expectedValues::contains).orElse(false);
    }

    protected boolean fieldHasText(final ScreenDescription screenDescription, final String fieldId) {

        return fieldValue(screenDescription, fieldId).isPresent();
    }

    protected boolean disjointCountries(final String firstCountries, final String secondCountries) {

        return !extractCountries(firstCountries).isEmpty() && !extractCountries(secondCountries).isEmpty()
                && java.util.Collections.disjoint(extractCountries(firstCountries), extractCountries(secondCountries));
    }

    protected List<String> extractCountries(final String countries) {

        if (countries == null || countries.isBlank() || countries.startsWith("NOT CALCULATED") || countries.startsWith("N/A")) {
            return List.of();
        }

        var source = countries;
        if (countries.matches("^(PROHIBITED|HIGH|EXCEPTION|MEDIUM|STANDARD).*$")) {
            var parts = countries.split("-", 2);
            if (parts.length > 1) {
                source = parts[1];
            }
        }

        return Arrays.stream(source.replace(",", " ").replace(";", " ").split("\\s+"))
                .map(String::trim)
                .filter(value -> !value.isBlank())
                .filter(value -> !"N/A".equals(value))
                .toList();
    }

    @Override
    public int getSignoffExpectedDurationSeconds() {

        return ONE_DAY;
    }
}
