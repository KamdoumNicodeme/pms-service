package com.lombardinternational.casemanagement.service.decision.domain.service.tasklist.onboarding.task.ic;

import com.lombardinternational.casemanagement.service.decision.domain.model.policy.Policy;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.TaskDefinition;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.tasklist.onboarding.AbstractICOnboardingTaskBuilderService;
import java.util.List;
import java.util.Optional;
import org.springframework.stereotype.Service;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.OnboardingChecklistIds.PREMIUM_WITH_ASSETS;

@Service
public class PremiumWithAssetsICOnboardingTaskBuilderService extends AbstractICOnboardingTaskBuilderService {

    @Override
    public void buildTask(final Policy policy, final WebForm webForm, final ScreenDescription screenDescription,
            final List<TaskDefinition> taskList) {

        if (fieldEquals(screenDescription, PREMIUM_WITH_ASSETS, YES)) {
            buildTaskDefinition(taskList);
        }
    }

    @Override
    protected boolean getMandatory() {

        return true;
    }

    @Override
    protected Optional<String> getDecisionReason() {

        return Optional.of("Escalation to Investment Compliance - Premium with assets");
    }
}
