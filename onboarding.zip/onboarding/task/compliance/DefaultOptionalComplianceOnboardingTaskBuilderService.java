package com.lombardinternational.casemanagement.service.decision.domain.service.tasklist.onboarding.task.compliance;

import com.lombardinternational.casemanagement.service.decision.domain.model.policy.Policy;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.TaskDefinition;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.tasklist.onboarding.AbstractComplianceOnboardingTaskBuilderService;
import java.util.List;
import org.springframework.stereotype.Service;

@Service
public class DefaultOptionalComplianceOnboardingTaskBuilderService extends AbstractComplianceOnboardingTaskBuilderService {

    @Override
    public void buildTask(final Policy policy, final WebForm webForm, final ScreenDescription screenDescription,
            final List<TaskDefinition> taskList) {

        buildTaskDefinition(taskList);
    }
}
