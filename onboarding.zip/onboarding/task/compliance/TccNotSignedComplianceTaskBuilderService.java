package com.lombardinternational.casemanagement.service.decision.domain.service.tasklist.onboarding.task.compliance;

import com.lombardinternational.casemanagement.service.decision.domain.model.policy.Policy;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.TaskDefinition;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.tasklist.onboarding.AbstractComplianceOnboardingTaskBuilderService;
import java.util.List;
import java.util.Optional;
import org.springframework.stereotype.Service;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.OnboardingChecklistIds.TCC_SIGNED;

@Service
public class TccNotSignedComplianceTaskBuilderService extends AbstractComplianceOnboardingTaskBuilderService {

    @Override
    public void buildTask(final Policy policy, final WebForm webForm, final ScreenDescription screenDescription,
            final List<TaskDefinition> taskList) {

        if (fieldEquals(screenDescription, TCC_SIGNED, NO)) {
            buildTaskDefinition(taskList);
        }
    }

    @Override
    protected boolean getMandatory() {

        return true;
    }

    @Override
    protected Optional<String> getDecisionReason() {

        return Optional.of("Check with client why no TCC signed AND Escalation to Tax Compliance - if refused again (No TCC)");
    }
}
