package com.lombardinternational.casemanagement.service.decision.domain.service.tasklist.onboarding.task.compliance;

import com.lombardinternational.casemanagement.service.decision.domain.model.policy.Policy;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.TaskDefinition;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.tasklist.onboarding.AbstractComplianceOnboardingTaskBuilderService;
import java.util.List;
import java.util.Optional;
import org.springframework.stereotype.Service;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.OnboardingChecklistIds.BUSINESS_ORIGIN;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.OnboardingChecklistIds.PCS_REVIEW;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.OnboardingChecklistIds.RISK_REASON;

@Service
public class PcsReviewEscalationComplianceTaskBuilderService extends AbstractComplianceOnboardingTaskBuilderService {

    private static final List<String> COMPLIANCE_ESCALATION_VALUES = List.of("None (Compliance escalation required)", "Senior sign-off");

    private String decisionReason;

    @Override
    public void buildTask(final Policy policy, final WebForm webForm, final ScreenDescription screenDescription,
            final List<TaskDefinition> taskList) {

        decisionReason = fieldValue(screenDescription, RISK_REASON).orElse(null);
        if (fieldNotEquals(screenDescription, BUSINESS_ORIGIN, "IT") && fieldIn(screenDescription, PCS_REVIEW, COMPLIANCE_ESCALATION_VALUES)
                && decisionReason != null) {
            buildTaskDefinition(taskList);
        }
    }

    @Override
    protected boolean getMandatory() {

        return true;
    }

    @Override
    protected Optional<String> getDecisionReason() {

        return Optional.ofNullable(decisionReason);
    }
}
