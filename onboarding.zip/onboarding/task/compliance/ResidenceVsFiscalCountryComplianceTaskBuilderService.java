package com.lombardinternational.casemanagement.service.decision.domain.service.tasklist.onboarding.task.compliance;

import com.lombardinternational.casemanagement.service.decision.domain.model.policy.Policy;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.TaskDefinition;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.tasklist.onboarding.AbstractComplianceOnboardingTaskBuilderService;
import java.util.List;
import java.util.Optional;
import org.springframework.stereotype.Service;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.OnboardingChecklistIds.PH_FISCAL_COUNTRY;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.OnboardingChecklistIds.PH_RESIDENCE_COUNTRY_RISK;

@Service
public class ResidenceVsFiscalCountryComplianceTaskBuilderService extends AbstractComplianceOnboardingTaskBuilderService {

    @Override
    public void buildTask(final Policy policy, final WebForm webForm, final ScreenDescription screenDescription,
            final List<TaskDefinition> taskList) {

        var residenceCountries = fieldValue(screenDescription, PH_RESIDENCE_COUNTRY_RISK).orElse(null);
        var fiscalCountries = fieldValue(screenDescription, PH_FISCAL_COUNTRY).orElse(null);
        if (disjointCountries(residenceCountries, fiscalCountries)) {
            buildTaskDefinition(taskList);
        }
    }

    @Override
    protected boolean getMandatory() {

        return true;
    }

    @Override
    protected Optional<String> getDecisionReason() {

        return Optional.of("Contact client to obtain explanation (Residence vs fiscal country) or correct information AND If not sensible explanation obtained - Escalation to Compliance");
    }
}
