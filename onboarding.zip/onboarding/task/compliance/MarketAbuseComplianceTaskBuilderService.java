package com.lombardinternational.casemanagement.service.decision.domain.service.tasklist.onboarding.task.compliance;

import com.lombardinternational.casemanagement.service.decision.domain.model.policy.Policy;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.TaskDefinition;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.tasklist.onboarding.AbstractComplianceOnboardingTaskBuilderService;
import java.util.List;
import java.util.Optional;
import org.springframework.stereotype.Service;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.OnboardingChecklistIds.INSIDER;

@Service
public class MarketAbuseComplianceTaskBuilderService extends AbstractComplianceOnboardingTaskBuilderService {

    @Override
    public void buildTask(final Policy policy, final WebForm webForm, final ScreenDescription screenDescription,
            final List<TaskDefinition> taskList) {

        if (fieldEquals(screenDescription, INSIDER, YES)) {
            buildTaskDefinition(taskList);
        }
    }

    @Override
    protected boolean getMandatory() {

        return true;
    }

    @Override
    protected Optional<String> getDecisionReason() {

        return Optional.of("Market abuse");
    }
}
