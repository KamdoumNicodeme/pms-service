package com.lombardinternational.casemanagement.service.decision.domain.service.tasklist.onboarding.task.compliance;

import com.lombardinternational.casemanagement.service.decision.domain.model.policy.Policy;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.TaskDefinition;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.tasklist.onboarding.AbstractComplianceOnboardingTaskBuilderService;
import java.util.List;
import java.util.Optional;
import org.springframework.stereotype.Service;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.OnboardingChecklistIds.EBO_RESIDENCE_COUNTRY_RISK;

@Service
public class EboResidenceTaxComplianceTaskBuilderService extends AbstractComplianceOnboardingTaskBuilderService {

    private static final List<String> TAX_COMPLIANCE_COUNTRIES = List.of("AS", "BS", "GU", "KN", "NA", "TT", "VI", "WS");

    @Override
    public void buildTask(final Policy policy, final WebForm webForm, final ScreenDescription screenDescription,
            final List<TaskDefinition> taskList) {

        if (fieldValue(screenDescription, EBO_RESIDENCE_COUNTRY_RISK).map(this::extractCountries)
                .map(countries -> countries.stream().anyMatch(TAX_COMPLIANCE_COUNTRIES::contains)).orElse(false)) {
            buildTaskDefinition(taskList);
        }
    }

    @Override
    protected boolean getMandatory() {

        return true;
    }

    @Override
    protected Optional<String> getDecisionReason() {

        return Optional.of("TCC signed by fiscal adviser OR Tax return AND Escalation to Tax Compliance - if No TCC");
    }
}
