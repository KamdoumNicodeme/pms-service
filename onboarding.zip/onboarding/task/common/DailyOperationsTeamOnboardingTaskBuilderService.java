package com.lombardinternational.casemanagement.service.decision.domain.service.tasklist.onboarding.task.common;

import com.lombardinternational.casemanagement.service.decision.domain.model.policy.Policy;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.TaskDefinition;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.tasklist.onboarding.AbstractOnboardingTaskBuilderService;
import java.util.List;
import org.springframework.stereotype.Service;

@Service
public class DailyOperationsTeamOnboardingTaskBuilderService extends AbstractOnboardingTaskBuilderService {

    @Override
    public void buildTask(final Policy policy, final WebForm webForm, final ScreenDescription screenDescription,
            final List<TaskDefinition> taskList) {

        buildTaskDefinition(taskList);
    }

    @Override
    public String getTaskName() {

        return "Daily Operations Team";
    }

    @Override
    public String getTaskDynamicScreenId() {

        return "DOT_NEW_BUSINESS";
    }

    @Override
    public int getRulePriority() {

        return 10;
    }

    @Override
    protected boolean getReleasableFromSubTask() {

        return true;
    }
}
