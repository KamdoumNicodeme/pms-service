package com.lombardinternational.casemanagement.service.decision.domain.service.checklist.addition.group;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.lombardinternational.casemanagement.service.decision.domain.model.policy.Policy;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Group;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Tab;
import com.lombardinternational.casemanagement.service.decision.domain.model.transaction.BusinessTransaction;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.checklist.GroupBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.checklist.addition.field.SignatureFieldBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.utils.RulesUtils;

import lombok.RequiredArgsConstructor;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ChecklistFieldConstants.*;

@Service
@RequiredArgsConstructor
public class SignatureGroupBuilderService implements GroupBuilderService {

    private final SignatureFieldBuilderService signatureFieldBuilderService;

    @Override
    public void buildGroup(final WebForm webForm, final ScreenDescription screenDescription, final Tab parentTab, final Policy policy,
            final BusinessTransaction transaction, final Map<String,List<String>> overallCaseRisk) {

        var signature = RulesUtils.getGroupInTab(parentTab, SIGNATURE_GROUP);
        if (signature == null) {
            signature = Group.builder().groupId(SIGNATURE_GROUP).build();
            parentTab.getGroups().add(signature);
        }
        signature.setIsActive(true);
        signature.incrementOrder();
        signature.setTitle("Signature");
        signatureFieldBuilderService.buildField(webForm, screenDescription, signature, policy, transaction, overallCaseRisk);
    }

}
