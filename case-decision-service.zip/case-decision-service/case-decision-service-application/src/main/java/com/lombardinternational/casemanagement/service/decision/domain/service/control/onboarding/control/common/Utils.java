package com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control.common;

import java.util.List;

import com.lombardinternational.casemanagement.service.decision.domain.utils.Constraint;
import com.lombardinternational.casemanagement.service.decision.domain.utils.FieldConstraint;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class Utils {

    public static FieldConstraint createConstraint(String fieldId, Constraint constraintType, List<String> values) {

        return FieldConstraint.builder().fieldId(fieldId).constraint(constraintType).values(values).build();
    }

    public static FieldConstraint createConstraintWithMultiple(String fieldId, Constraint constraintType, boolean multiple, List<String> values) {

        return FieldConstraint.builder().fieldId(fieldId).constraint(constraintType).multiple(multiple).values(values).build();
    }

    public static FieldConstraint createConstraintWithMultipleAndExactMatch(String fieldId, Constraint constraintType, boolean multiple,
            boolean exactMatch, List<String> values) {

        return FieldConstraint.builder().fieldId(fieldId).constraint(constraintType).multiple(multiple).exactMatch(exactMatch).values(values)
                .build();
    }

    public static FieldConstraint createConstraintWithNegate(String fieldId, Constraint constraintType, List<String> values, boolean negate) {

        return FieldConstraint.builder().fieldId(fieldId).constraint(constraintType).negate(negate).values(values).build();
    }

    public static FieldConstraint createConstraintWithNegateSplit(String fieldId, Constraint constraintType, boolean negate, boolean split,
            String tokenizer, List<String> values) {

        return FieldConstraint.builder().fieldId(fieldId).constraint(constraintType).negate(negate).split(split).tokenizer(tokenizer)
                .values(values).build();
    }

    public static FieldConstraint createConstraintWithMarket(String fieldId, Constraint constraintType, final List<String> markets) {

        return FieldConstraint.builder().fieldId(fieldId).constraint(constraintType).values(markets).build();
    }
}
