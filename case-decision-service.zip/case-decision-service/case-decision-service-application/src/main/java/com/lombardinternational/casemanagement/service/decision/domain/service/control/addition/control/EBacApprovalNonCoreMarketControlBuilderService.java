package com.lombardinternational.casemanagement.service.decision.domain.service.control.addition.control;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ControlDefinition;
import com.lombardinternational.casemanagement.service.decision.domain.utils.ControlUtils;
import org.springframework.stereotype.Service;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.AbstractControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.utils.Constraint;
import com.lombardinternational.casemanagement.service.decision.domain.utils.FieldConstraint;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ControlConstants.*;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ChecklistFieldConstants.*;

@Service
public class EBacApprovalNonCoreMarketControlBuilderService extends AbstractControlBuilderService {

    // TODO: Export this to repository service to query reference country with a filter non core market or any other filter
    private static final List<String> coreMarket = Arrays.asList("BE", "BR", "CL", "CO", "CY", "DE", "ES", "FI", "FR", "GB", "GG", "GI", "IL",
            "IT", "LU", "MT", "MX", "NO", "PE", "PT", "SE", "TR");
    // TODO: Identify the name of this list so that we can create a specific property for the filter as for core market
    private static final List<String> bisNonCoreMarket = Arrays.asList("CH", "CY", "GI", "BR", "CL", "CO", "MX", "PE", "TR", "IL");

    @Override
    public ControlDefinition buildControl(final WebForm webForm, final ScreenDescription screenDescription) {

        final var constraints1 = new ArrayList<FieldConstraint>();
        constraints1.add(FieldConstraint.builder().fieldId(TRANSACTION_FEEDBACK).constraint(Constraint.EQUALS)
                .values(Collections.singletonList("ACCEPTED")).build());
        constraints1
                .add(FieldConstraint.builder().fieldId(BAC_APPROVAL).constraint(Constraint.EQUALS).values(Collections.singletonList(NO)).build());
        constraints1.add(FieldConstraint.builder().fieldId(BUSINESS_ORIGIN).constraint(Constraint.IN).values(Arrays.asList("LU", "BE")).build());
        // Considering the refactor of residence country field in TCM-1855 it will be split with a space
        constraints1.add(FieldConstraint.builder().fieldId(PH_RESIDENCE_COUNTRY).constraint(Constraint.DISJOINT).split(true).tokenizer(" ")
                .values(coreMarket).build());

        final var constraints2 = ControlUtils.verifyPhEboLaResidenceCountryOnMarkets(bisNonCoreMarket, false);
        if (constraints1.stream().allMatch(constraint -> constraint.test(screenDescription)) && constraints2.stream().anyMatch(constraint -> constraint.test(screenDescription))) {
            return buildControlDefinition();
        }
        return null;
    }

    @Override
    public String getControlName() {

        return EBAC_APPROVAL_NON_CORE_NAME;
    }

    @Override
    public String getControlType() {

        return EBAC_APPROVAL_NON_CORE_TYPE;
    }
}
