package com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control;

import org.springframework.stereotype.Service;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ControlDefinition;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.AbstractControlBuilderService;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ControlConstants.VERIFICATION_DATA_SYNCHRONIZATION_BEFORE_COMPLETION_NAME;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ControlConstants.VERIFICATION_DATA_SYNCHRONIZATION_BEFORE_COMPLETION_TYPE;

@Service(value = "onboardingVerificationDataSynchronizationBeforeCompletionControlBuilderService")
public class VerificationDataSynchronizationBeforeCompletionControlBuilderService extends AbstractControlBuilderService {

    @Override
    public ControlDefinition buildControl(WebForm webForm, ScreenDescription screenDescription) {

        return buildControlDefinition();
    }

    @Override
    protected String getControlName() {

        return VERIFICATION_DATA_SYNCHRONIZATION_BEFORE_COMPLETION_NAME;
    }

    @Override
    protected String getControlType() {

        return VERIFICATION_DATA_SYNCHRONIZATION_BEFORE_COMPLETION_TYPE;
    }
}
