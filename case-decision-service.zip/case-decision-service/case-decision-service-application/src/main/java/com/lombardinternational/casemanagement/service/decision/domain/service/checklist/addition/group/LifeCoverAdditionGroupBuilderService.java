package com.lombardinternational.casemanagement.service.decision.domain.service.checklist.addition.group;

import java.util.List;
import java.util.Map;
import java.util.Objects;

import org.springframework.stereotype.Service;

import com.lombardinternational.casemanagement.service.decision.domain.model.policy.Policy;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Group;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Tab;
import com.lombardinternational.casemanagement.service.decision.domain.model.transaction.BusinessTransaction;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.checklist.GroupBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.checklist.addition.field.LifeCoverFieldsBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.utils.RulesUtils;

import lombok.AllArgsConstructor;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ChecklistFieldConstants.*;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.RulesConstants.*;

@Service
@AllArgsConstructor
public class LifeCoverAdditionGroupBuilderService implements GroupBuilderService {

    private final LifeCoverFieldsBuilderService lifeCoverFieldsBuilderService;

    @Override
    public void buildGroup(final WebForm webForm, final ScreenDescription screenDescription, final Tab parentTab, final Policy policy,
            final BusinessTransaction business, final Map<String,List<String>> overallCaseRisk) {

        var lifeCover = RulesUtils.getGroupInTab(parentTab, LIFE_COVER_GROUP);
        if (lifeCover == null) {
            lifeCover = Group.builder().groupId(LIFE_COVER_GROUP).build();
            parentTab.getGroups().add(lifeCover);
        }
        lifeCover.setIsActive(true);
        lifeCover.incrementOrder();
        lifeCover.setTitle("Life Cover Type");
        var forcedDisplayIf = !Objects.equals(policy.getPolicyType(), CAPITALISED_POLICY);
        lifeCover.setDisplayIf(String.valueOf(forcedDisplayIf));
        if (forcedDisplayIf) {
            lifeCoverFieldsBuilderService.buildField(webForm, screenDescription, lifeCover, policy, business, overallCaseRisk);
        }
    }
}
