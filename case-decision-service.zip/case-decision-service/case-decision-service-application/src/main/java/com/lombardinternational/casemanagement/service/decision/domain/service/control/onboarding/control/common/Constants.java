package com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control.common;

import java.util.List;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class Constants {

    public static final String BROKER = "BROKER";
    public static final String MC = "MC";
    public static final String CH = "CH";
    public static final String EXPECTED_PREM_AMOUNT = "25000000";
    public static final String COMPANY = "Company";
    public static final String TRADING_COMPANY = "Trading company";
    public static final String FIDUCIARY = "Fiduciary";
    public static final String TRUST = "Trust";
    public static final String PH_TYPE_PHYSIQUE = "PH Type=Physical";
    public static final String ELECTRONIC = "ELECTRONIC";
    public static final String MULTIPLE = "MULTIPLE";
    public static final String INDIVIDUAL = "Individual";
    public static final String BROK_ACCO = "brok_acco";
    public static final String TAX_AUTH = "tax_auth";
    public static final String TRANSF_COMP = "transf_comp";

    public static final List<String> MARKETS = List.of("AT", "BE", "BG", "CY", "CZ", "DE", "DK", "EE", "ES", "FI", "FR", "GB", "GR", "HU", "IE",
            "IS", "IT", "LI", "LT", "LU", "LV", "MT", "NL", "NO", "PL", "PT", "RO", "SE", "SI", "SK");

}
