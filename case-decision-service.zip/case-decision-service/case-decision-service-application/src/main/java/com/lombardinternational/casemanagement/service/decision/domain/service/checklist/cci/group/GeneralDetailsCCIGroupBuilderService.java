package com.lombardinternational.casemanagement.service.decision.domain.service.checklist.cci.group;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.lombardinternational.casemanagement.service.decision.domain.model.policy.Policy;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Group;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Tab;
import com.lombardinternational.casemanagement.service.decision.domain.model.transaction.BusinessTransaction;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.checklist.GroupBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.checklist.cci.field.GeneralDetailsCCIFieldsBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.utils.RulesUtils;

import lombok.AllArgsConstructor;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ChecklistFieldConstants.*;

@Service
@AllArgsConstructor
public class GeneralDetailsCCIGroupBuilderService implements GroupBuilderService {

    private final GeneralDetailsCCIFieldsBuilderService generalDetailsCCIFieldsBuilderService;

    @Override
    public void buildGroup(final WebForm webForm, final ScreenDescription screenDescription, final Tab parentTab, final Policy policy,
            final BusinessTransaction transaction, final Map<String,List<String>> overallCaseRisk) {

        var generalDetails = RulesUtils.getGroupInTab(parentTab, GENERAL_DETAILS_GROUP);
        if (generalDetails == null) {
            generalDetails = Group.builder().groupId(GENERAL_DETAILS_GROUP).build();
            parentTab.getGroups().add(generalDetails);
        }
        generalDetails.setIsActive(true);
        generalDetails.incrementOrder();
        generalDetails.setTitle("General details - Change of client information");
        generalDetailsCCIFieldsBuilderService.buildField(webForm, screenDescription, generalDetails, policy, transaction, overallCaseRisk);
    }
}
