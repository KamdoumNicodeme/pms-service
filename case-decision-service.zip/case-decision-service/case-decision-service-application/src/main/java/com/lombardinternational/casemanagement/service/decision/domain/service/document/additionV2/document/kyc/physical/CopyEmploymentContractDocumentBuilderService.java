package com.lombardinternational.casemanagement.service.decision.domain.service.document.additionV2.document.kyc.physical;

import java.util.List;

import org.springframework.stereotype.Service;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.DocumentDefinition;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebFormGroup;
import com.lombardinternational.casemanagement.service.decision.domain.service.document.additionV2.document.kyc.DocumentUtilsBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.utils.WebformUtils;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.DocumentConstants.COPY_EMPLOYMENT_CONTRACT_FORM_DESCRIPTION;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.DocumentConstants.COPY_EMPLOYMENT_CONTRACT_FORM_I18N_DESCRIPTION;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.DocumentConstants.EBO_I18N_DOCUMENT_RELATED_TO;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.DocumentConstants.KYC_DOCUMENT_CMS_DOC_TYPE;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.DocumentConstants.KYC_DOCUMENT_DOC_TYPE;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.RulesConstants.TRUE;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.WebFormFieldConstants.*;

@Service
public class CopyEmploymentContractDocumentBuilderService extends DocumentUtilsBuilderService {

    @Override
    public void buildDocument(final WebForm webForm, final ScreenDescription screenDescription, String transactionNumber,
            List<DocumentDefinition> documents) {

        for (WebFormGroup group : getEboKycs(webForm, false)) {
            var hasProfessionalActivity = WebformUtils.getWebFormFieldValueById(group, HAS_PROFESSIONAL_ACTIVITY_WF);
            if (TRUE.equalsIgnoreCase(hasProfessionalActivity)) {
                var eboId = WebformUtils.getWebFormFieldValueById(group, EBO_ID_WF);
                var eboName = WebformUtils.getWebFormFieldValueById(group, EBO_NAME_WF);
                var relatedTo = "Ebo " + eboName;
                var relatedToPolicy = WebformUtils.getWebFormFieldValueById(webForm, POLICY_NUMBER_WF);
                buildDocumentDefinition(relatedTo, relatedToPolicy, eboName, eboId, documents);
            }
        }
    }

    @Override
    protected String getDocumentType() {

        return KYC_DOCUMENT_DOC_TYPE;
    }

    @Override
    protected String getCmsDocumentType() {

        return KYC_DOCUMENT_CMS_DOC_TYPE;
    }

    @Override
    protected String getDescription() {

        return COPY_EMPLOYMENT_CONTRACT_FORM_DESCRIPTION;
    }

    @Override
    protected String getI18NDescription() {

        return COPY_EMPLOYMENT_CONTRACT_FORM_I18N_DESCRIPTION;
    }

    @Override
    protected String getI18NDocumentRelatedTo() {

        return EBO_I18N_DOCUMENT_RELATED_TO;
    }

    @Override
    protected boolean getDocumentVisibleOnConnect() {

        return true;
    }

    @Override
    protected boolean getDocumentRequired() {

        return true;
    }
}
