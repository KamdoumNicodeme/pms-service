package com.lombardinternational.casemanagement.service.decision.domain.service.control.addition.control;

import java.util.ArrayList;
import java.util.Collections;

import org.springframework.stereotype.Service;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ControlDefinition;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.AbstractControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.utils.ChecklistUtils;
import com.lombardinternational.casemanagement.service.decision.domain.utils.Constraint;
import com.lombardinternational.casemanagement.service.decision.domain.utils.FieldConstraint;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ChecklistFieldConstants.*;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ControlConstants.*;

@Service
public class PhTaxCountryDifferentApplicableLawControlBuilderService extends AbstractControlBuilderService {

    @Override
    public ControlDefinition buildControl(WebForm webForm, ScreenDescription screenDescription) {

        var countryOfApplicableLaw = ChecklistUtils.getFieldById(screenDescription, COUNTRY_OF_APPLICABLE_LAW).orElse(null);
        if (countryOfApplicableLaw != null) {
            final var constraints = new ArrayList<FieldConstraint>();
            constraints.add(FieldConstraint.builder().fieldId(TAX_COUNTRY).constraint(Constraint.EQUALS).negate(true)
                    .values(Collections.singletonList(countryOfApplicableLaw.getSelectedValue())).build());
            if (constraints.stream().anyMatch(constraint -> constraint.test(screenDescription))) {
                return buildControlDefinition();
            }
        }
        return null;
    }

    @Override
    protected String getControlName() {

        return PH_TAX_COUNTRY_DIFFERENT_APPLICABLE_LAW_NAME;
    }

    @Override
    protected String getControlType() {

        return PH_TAX_COUNTRY_DIFFERENT_APPLICABLE_LAW_TYPE;
    }
}
