package com.lombardinternational.casemanagement.service.decision.domain.service.checklist.common.field;

import com.lombardinternational.casemanagement.service.decision.domain.model.policy.Amount;
import com.lombardinternational.casemanagement.service.decision.domain.model.policy.Policy;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Group;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.NumberInputField;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.SelectInputField;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.TextInputField;
import com.lombardinternational.casemanagement.service.decision.domain.model.transaction.BusinessTransaction;
import com.lombardinternational.casemanagement.service.decision.domain.spi.repository.ReferenceDataRepositoryService;
import com.lombardinternational.casemanagement.service.decision.domain.utils.ChecklistUtils;
import org.apache.commons.lang3.StringUtils;

import java.math.BigDecimal;
import java.util.Optional;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ChecklistFieldConstants.*;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ReferenceConstants.COUNTRY_DOMAIN;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ReferenceConstants.YES_NO_DOMAIN;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.RulesConstants.NO;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.RulesConstants.YES;

public class CommonGeneralDetailsFieldsBuilderService {

    public static void evaluateContractType(final Group group, final Policy policy) {

        var contractType = (TextInputField) ChecklistUtils.getFieldInGroup(group, CONTRACT_TYPE);
        if (contractType == null) {
            contractType = TextInputField.builder().fieldId(CONTRACT_TYPE).build();
            group.getFields().add(contractType);
        }
        contractType.setIsActive(true);
        contractType.incrementOrder();
        contractType.setLabel("Contract type");
        contractType.setSourceSystem("Policy type from CLASS");
        contractType.setSelectedValue(policy.getPolicyType());
    }

    public static void evaluatePolicyNumber(final Group group, final Policy policy) {

        var policyNumber = (TextInputField) ChecklistUtils.getFieldInGroup(group, POLICY_NUMBER);
        if (policyNumber == null) {
            policyNumber = TextInputField.builder().fieldId(POLICY_NUMBER).build();
            group.getFields().add(policyNumber);
        }
        policyNumber.setIsActive(true);
        policyNumber.incrementOrder();
        policyNumber.setLabel("Policy number");
        policyNumber.setSourceSystem("Policy number from CLASS");
        policyNumber.setSelectedValue(policy.getNumber());
    }

    public static void evaluatePolicyCurrency(final Group group, final Policy policy) {

        var policyCurrency = (TextInputField) ChecklistUtils.getFieldInGroup(group, POLICY_CURRENCY);
        if (policyCurrency == null) {
            policyCurrency = TextInputField.builder().fieldId(POLICY_CURRENCY).build();
            group.getFields().add(policyCurrency);
        }
        policyCurrency.setIsActive(true);
        policyCurrency.incrementOrder();
        policyCurrency.setLabel("Policy currency");
        policyCurrency.setSourceSystem("Policy currency from CLASS");
        policyCurrency.setSelectedValue(policy.getIsoCurrencyCode());
    }

    public static void evaluateBusinessOrigin(final Group group, final Policy policy,
            final ReferenceDataRepositoryService referenceDataRepositoryService) {

        var businessOrigin = (SelectInputField) ChecklistUtils.getFieldInGroup(group, BUSINESS_ORIGIN);
        if (businessOrigin == null) {
            businessOrigin = SelectInputField.builder().fieldId(BUSINESS_ORIGIN).build();
            group.getFields().add(businessOrigin);
        }
        businessOrigin.setIsActive(true);
        businessOrigin.incrementOrder();
        businessOrigin.setLabel("Business origin");
        businessOrigin.setSourceSystem("Business origin from CLASS");
        businessOrigin.setSelectedValue(policy.getBusinessOrigin());
        businessOrigin.setOptions(
                referenceDataRepositoryService.getReferenceDataOptionsByDomainAndSelectedValue(COUNTRY_DOMAIN, businessOrigin.getSelectedValue()));
    }

    public static void evaluateCountryOfApplicableLaw(final Group group, final Policy policy,
            final ReferenceDataRepositoryService referenceDataRepositoryService) {

        var countryOfApplicableLaw = (SelectInputField) ChecklistUtils.getFieldInGroup(group, COUNTRY_OF_APPLICABLE_LAW);
        if (countryOfApplicableLaw == null) {
            countryOfApplicableLaw = SelectInputField.builder().fieldId(COUNTRY_OF_APPLICABLE_LAW).build();
            group.getFields().add(countryOfApplicableLaw);
        }
        countryOfApplicableLaw.setIsActive(true);
        countryOfApplicableLaw.incrementOrder();
        countryOfApplicableLaw.setLabel("Country of applicable law");
        countryOfApplicableLaw.setSourceSystem("Country of applicable law from CLASS");
        countryOfApplicableLaw.setSelectedValue(policy.getCountryOfLawCode());
        countryOfApplicableLaw.setOptions(referenceDataRepositoryService.getReferenceDataOptionsByDomainAndSelectedValue(COUNTRY_DOMAIN,
                countryOfApplicableLaw.getSelectedValue()));
    }

    public static void evaluatePolicyNavEur(final Group group, final Policy policy) {

        var policyNavEur = (NumberInputField) ChecklistUtils.getFieldInGroup(group, POLICY_NAV_EUR);
        if (policyNavEur == null) {
            policyNavEur = NumberInputField.builder().fieldId(POLICY_NAV_EUR).build();
            group.getFields().add(policyNavEur);
        }
        policyNavEur.setIsActive(true);
        policyNavEur.incrementOrder();
        policyNavEur.setLabel("Policy NAV, excluding this expected premium (in EUR)");
        policyNavEur.setSourceSystem("Policy value (in EUR) from CLASS");
        policyNavEur.setDisplayIf("#" + BUSINESS_ORIGIN + "# != \"BE\"");
        policyNavEur.setSelectedValue(policy.getNavInEurCurrency() != null ? policy.getNavInEurCurrency().getQuantity().toPlainString() : null);
    }

    public static void evaluateExpectedTransactionAmount(final Group group, final BusinessTransaction transaction) {

        var expectedTransactionAmount = (NumberInputField) ChecklistUtils.getFieldInGroup(group, TRANSACTION_AMOUNT_CUR);
        if (expectedTransactionAmount == null) {
            expectedTransactionAmount = NumberInputField.builder().fieldId(TRANSACTION_AMOUNT_CUR).build();
            group.getFields().add(expectedTransactionAmount);
        }
        expectedTransactionAmount.setIsActive(true);
        expectedTransactionAmount.incrementOrder();
        expectedTransactionAmount.setLabel("Expected premium (in policy currency)");
        expectedTransactionAmount.setSourceSystem("Transaction amount from Connect");
        expectedTransactionAmount.setSelectedValue(
                Optional.ofNullable(transaction.getExpectedAmount()).map(Amount::getQuantity).map(BigDecimal::toPlainString).orElse(null));
    }

    public static void evaluateExpectedTransactionAmountEur(final Group group, final Policy policy, final BusinessTransaction transaction) {

        var expectedTransactionAmountEur = (NumberInputField) ChecklistUtils.getFieldInGroup(group, TRANSACTION_AMOUNT);
        if (!"EUR".equals(policy.getIsoCurrencyCode())) {
            if (expectedTransactionAmountEur == null) {
                expectedTransactionAmountEur = NumberInputField.builder().fieldId(TRANSACTION_AMOUNT).build();
                group.getFields().add(expectedTransactionAmountEur);
            }
            expectedTransactionAmountEur.setIsActive(true);
            expectedTransactionAmountEur.incrementOrder();
            expectedTransactionAmountEur.setLabel("Expected premium (in EUR)");
            expectedTransactionAmountEur.setSourceSystem("Transaction amount in EUR from CLASS");
            expectedTransactionAmountEur.setSelectedValue(
                    Optional.ofNullable(transaction.getExpectedAmountEur()).map(Amount::getQuantity).map(BigDecimal::toPlainString).orElse(null));

        }
    }

    public static void evaluateBePolicyNavEur(final Group group, final BusinessTransaction transaction) {

        var bePolicyNavEur = (NumberInputField) ChecklistUtils.getFieldInGroup(group, BE_POLICY_NAV_EUR);
        if (bePolicyNavEur == null) {
            bePolicyNavEur = NumberInputField.builder().fieldId(BE_POLICY_NAV_EUR).build();
            group.getFields().add(bePolicyNavEur);
        }
        bePolicyNavEur.setIsActive(true);
        bePolicyNavEur.incrementOrder();
        bePolicyNavEur.setLabel("Total BE policies NAV (in EUR)");
        bePolicyNavEur.setSourceSystem("Policy value (in EUR) from CLASS");
        bePolicyNavEur.setDisplayIf("#" + BUSINESS_ORIGIN + "# == \"BE\"");
        if (transaction.getEboPolicyNav() != null) {
            final var value = Optional.ofNullable(transaction.getEboPolicyNav().getPolicyNavByBranch()).stream()
                    .filter(nav -> nav.containsKey("LIA-BE")).map(nav -> nav.get("LIA-BE").toPlainString()).findFirst();
            bePolicyNavEur.setSelectedValue(value.orElse(BigDecimal.ZERO.toPlainString()));
        }
    }

    public static void evaluateIsMultiSupport(final Group group, final Policy policy, final ReferenceDataRepositoryService referenceDataRepositoryService) {

        var isMultiSupport = (SelectInputField) ChecklistUtils.getFieldInGroup(group, IS_MULTISUPPORT);
        if (isMultiSupport == null) {
            isMultiSupport = SelectInputField.builder().fieldId(IS_MULTISUPPORT).build();
            group.getFields().add(isMultiSupport);
        }
        isMultiSupport.setIsActive(true);
        isMultiSupport.incrementOrder();
        isMultiSupport.setLabel("Is multisupport? (hidden)");
        isMultiSupport.setDisplayIf("false");
        isMultiSupport.setSourceSystem("From Class");
        isMultiSupport.setSelectedValue(StringUtils.isNoneEmpty(policy.getMasterProduct()) ? YES : NO);
        isMultiSupport.setOptions(
                referenceDataRepositoryService.getReferenceDataOptionsByDomainAndSelectedValue(YES_NO_DOMAIN, isMultiSupport.getSelectedValue()));
    }
}
