package com.lombardinternational.casemanagement.service.decision.domain.service.checklist.addition.group;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.lombardinternational.casemanagement.service.decision.domain.model.policy.Policy;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Group;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Tab;
import com.lombardinternational.casemanagement.service.decision.domain.model.transaction.BusinessTransaction;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.checklist.GroupBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.checklist.addition.field.ThirdPartyAdditionFieldsBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.utils.RulesUtils;

import lombok.AllArgsConstructor;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ChecklistFieldConstants.*;

@Service
@AllArgsConstructor
public class ThirdPartyAdditionGroupBuilderService implements GroupBuilderService {

    private final ThirdPartyAdditionFieldsBuilderService thirdPartyAdditionFieldsBuilderService;

    @Override
    public void buildGroup(final WebForm webForm, final ScreenDescription screenDescription, final Tab parentTab, final Policy policy,
            final BusinessTransaction transaction, final Map<String,List<String>> overallCaseRisk) {

        var addedInfo = RulesUtils.getGroupInTab(parentTab, THIRD_PARTY_GROUP);
        if (addedInfo == null) {
            addedInfo = Group.builder().groupId(THIRD_PARTY_GROUP).build();
            parentTab.getGroups().add(addedInfo);
        }
        addedInfo.setIsActive(true);
        addedInfo.incrementOrder();
        addedInfo.setTitle("Payment from third party");
        addedInfo.setDisplayIf("#" + PAYMENT_THIRD_PARTY + "# == \"YES\"");
        thirdPartyAdditionFieldsBuilderService.buildField(webForm, screenDescription, addedInfo, policy, transaction, overallCaseRisk);
    }
}
