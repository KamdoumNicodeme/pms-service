package com.lombardinternational.casemanagement.service.decision.domain.service.checklist.rop.field;

import java.util.List;
import java.util.Map;
import java.util.stream.IntStream;

import org.springframework.stereotype.Service;

import com.lombardinternational.casemanagement.service.decision.domain.model.policy.Policy;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Field;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Group;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.transaction.BusinessTransaction;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.checklist.FieldBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.spi.repository.ReferenceDataRepositoryService;
import com.lombardinternational.casemanagement.service.decision.domain.utils.ChecklistUtils;

import lombok.AllArgsConstructor;

import static com.lombardinternational.casemanagement.service.decision.domain.service.checklist.common.field.CommonThirdPartyFieldsBuilderService.*;

@Service
@AllArgsConstructor
public class ThirdPartyRopFieldsBuilderService implements FieldBuilderService {

    public static final String SOURCE_SYSTEM = "From Class";
    private final ReferenceDataRepositoryService referenceDataRepositoryService;

    @Override
    public void buildField(final WebForm webForm, final ScreenDescription screenDescription, final Group group, final Policy policy,
            final BusinessTransaction transaction, final Map<String,List<String>> overallCaseRisk) {

        Field.resetFieldId();
        var payments = ChecklistUtils.getMoneyInTransactionPaymentDetails(transaction);
        IntStream.range(1, payments.size() + 1).forEach(i -> {
            var paymentDetails = payments.get(i - 1);
            evaluateThirdPartyName(group, paymentDetails, i);
            evaluateLinkThirdPartyPh(group, paymentDetails, i, referenceDataRepositoryService);
            evaluateReasonThirdPartyPayment(group, i);
            evaluateThirdPartyCountry(group, paymentDetails, i, referenceDataRepositoryService);
        });
        evaluateThirdPartyCountryRisk(group, transaction);
    }
}
