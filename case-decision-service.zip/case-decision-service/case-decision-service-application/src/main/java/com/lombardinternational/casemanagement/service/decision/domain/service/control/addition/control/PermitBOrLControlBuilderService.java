package com.lombardinternational.casemanagement.service.decision.domain.service.control.addition.control;

import java.util.List;

import org.springframework.stereotype.Service;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ControlDefinition;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.AbstractControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.utils.ControlUtils;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ControlConstants.*;

@Service
public class PermitBOrLControlBuilderService extends AbstractControlBuilderService {

    private static final List<String> markets = List.of("CH");

    @Override
    public ControlDefinition buildControl(final WebForm webForm, final ScreenDescription screenDescription) {

        // Considering the refactor of residence country field in TCM-1855 it will be split with a space
        final var constraints = ControlUtils.verifyPhEboLaResidenceCountryOnMarkets(markets, true);

        if (constraints.stream().anyMatch(constraint -> constraint.test(screenDescription))) {
            return buildControlDefinition();
        }
        return null;
    }

    @Override
    public String getControlName() {

        return PERMIT_B_L_NAME;
    }

    @Override
    public String getControlType() {

        return PERMIT_B_L_TYPE;
    }
}
