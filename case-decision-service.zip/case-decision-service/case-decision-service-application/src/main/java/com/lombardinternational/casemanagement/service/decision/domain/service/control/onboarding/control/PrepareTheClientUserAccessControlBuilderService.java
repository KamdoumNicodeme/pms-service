package com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control;

import org.springframework.stereotype.Service;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ControlDefinition;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.AbstractControlBuilderService;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ControlConstants.*;

@Service
public class PrepareTheClientUserAccessControlBuilderService extends AbstractControlBuilderService {

    @Override
    public ControlDefinition buildControl(final WebForm webForm, final ScreenDescription screenDescription) {

        return buildControlDefinition();
    }

    @Override
    protected String getControlName() {

        return PREPARE_THE_CLIENT_USER_ACCESS_IN_SECURE_CONNECT_NAME;
    }

    @Override
    protected String getControlType() {

        return PREPARE_THE_CLIENT_USER_ACCESS_IN_SECURE_CONNECT_NAME_TYPE;
    }
}
