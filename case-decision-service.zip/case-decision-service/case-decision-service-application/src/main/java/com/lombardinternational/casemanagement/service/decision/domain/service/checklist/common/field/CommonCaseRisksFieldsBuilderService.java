package com.lombardinternational.casemanagement.service.decision.domain.service.checklist.common.field;

import java.util.List;
import java.util.Map;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Group;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.SelectInputField;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.TextAreaField;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.TextInputField;
import com.lombardinternational.casemanagement.service.decision.domain.model.transaction.BusinessTransaction;
import com.lombardinternational.casemanagement.service.decision.domain.service.checklist.RiskValueBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.spi.repository.ReferenceDataRepositoryService;
import com.lombardinternational.casemanagement.service.decision.domain.utils.ChecklistUtils;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ChecklistFieldConstants.*;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ReferenceConstants.*;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.RulesConstants.*;

public class CommonCaseRisksFieldsBuilderService {

    public static void evaluateOverallCaseRisk(final Group group, ScreenDescription screenDescription, BusinessTransaction transaction,
            final Map<String,List<String>> overallCaseRisk, final RiskValueBuilderService riskValueRopBuilderService) {

        var riskValue = (TextInputField) ChecklistUtils.getFieldInGroup(group, RISK_VALUE);
        if (riskValue == null) {
            riskValue = TextInputField.builder().fieldId(RISK_VALUE).build();
            group.getFields().add(riskValue);
        }
        riskValue.setIsActive(true);
        riskValue.incrementOrder();
        riskValue.setLabel("Overall case risk");
        riskValue.setDisplayIf("false");
        riskValue.setSourceSystem("Calculated based on checklist values");
        riskValue.setSelectedValue(riskValueRopBuilderService.computeRiskValueRules(screenDescription, transaction, overallCaseRisk));
    }

    public static void evaluateBlockedValue(final Group group, final Map<String,List<String>> overallCaseRisk) {

        var blockedValue = (TextAreaField) ChecklistUtils.getFieldInGroup(group, BLOCKED_VALUE);
        if (blockedValue == null) {
            blockedValue = TextAreaField.builder().fieldId(BLOCKED_VALUE).build();
            group.getFields().add(blockedValue);
        }
        blockedValue.setIsActive(true);
        blockedValue.incrementOrder();
        blockedValue.setLabel("Actions required in CLASS to complete Docs & Controls and trigger reviews");

        var forcedValue = "";
        var forcedDisplayIf = "false";
        var blockList = overallCaseRisk.get(BLOCKED);
        if (!blockList.isEmpty()) {
            forcedValue = String.join("\n", blockList);
            forcedDisplayIf = "true";
        }

        blockedValue.setDisplayIf(forcedDisplayIf);
        blockedValue.setSelectedValue(forcedValue);
        blockedValue.setSourceSystem("Calculated based on Checklist values");
    }

    public static void evaluatePCSReview(final Group group, final Map<String,List<String>> overallCaseRisk,
            final ReferenceDataRepositoryService referenceDataRepositoryService) {

        var pcsReview = (SelectInputField) ChecklistUtils.getFieldInGroup(group, PCS_REVIEW);
        if (pcsReview == null) {
            pcsReview = SelectInputField.builder().fieldId(PCS_REVIEW).build();
            group.getFields().add(pcsReview);
            pcsReview.setSelectedValue(null);
        }
        pcsReview.setIsActive(true);
        pcsReview.incrementOrder();
        pcsReview.setLabel("PCS Review");

        var forcedDisplayIf = "false";
        var forcedValue = "";

        var blockList = overallCaseRisk.get(BLOCKED);

        if (blockList.isEmpty()) {
            var caseValue = ChecklistUtils.getFieldInGroup(group, RISK_VALUE).getSelectedValue();

            forcedDisplayIf = "true";
            forcedValue = switch ((caseValue != null) ? caseValue : PCS_STANDARD) {
            case HIGH -> PCS_COMPLIANCE;
            case MEDIUM -> PCS_SENIOR;
            default -> PCS_STANDARD;
            };
        } else {
            forcedValue = null;
        }
        pcsReview.setMandatory(true);
        pcsReview.setDisplayIf(forcedDisplayIf);
        pcsReview.setSelectedValue(forcedValue);
        pcsReview.setOptions(referenceDataRepositoryService.getReferenceDataOptionsByDomainAndSelectedValue(COMPLIANCE_LEVEL_DOMAIN,
                pcsReview.getSelectedValue()));
        pcsReview.setSourceSystem("Calculated based on Overall case risk");

    }

    public static void evaluateRiskReason(final Group group, final Map<String,List<String>> overallCaseRisk) {

        var riskReason = (TextAreaField) ChecklistUtils.getFieldInGroup(group, RISK_REASON);
        if (riskReason == null) {
            riskReason = TextAreaField.builder().fieldId(RISK_REASON).build();
            group.getFields().add(riskReason);
        }
        riskReason.setIsActive(true);
        riskReason.incrementOrder();
        riskReason.setLabel("Compliance escalation rules triggered");

        var forcedValue = "";
        var forcedDisplayIf = "false";

        var blockList = overallCaseRisk.get(BLOCKED);
        var caseValue = ChecklistUtils.getFieldInGroup(group, RISK_VALUE).getSelectedValue();

        if (blockList.isEmpty() && caseValue != null && caseValue.matches(HIGH)) {
            var reasonList = overallCaseRisk.get(caseValue);
            forcedValue = String.join("\n", reasonList);
            forcedDisplayIf = "true";
        }
        riskReason.setDisplayIf(forcedDisplayIf);
        riskReason.setSelectedValue(forcedValue);
        riskReason.setSourceSystem("Calculated based on Overall case risk");
    }
}
