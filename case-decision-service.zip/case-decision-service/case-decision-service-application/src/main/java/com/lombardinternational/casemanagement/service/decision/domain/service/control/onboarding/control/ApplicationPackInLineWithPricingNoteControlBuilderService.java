package com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control;

import java.util.Collections;
import java.util.List;
import java.util.stream.Stream;

import org.springframework.stereotype.Service;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ControlDefinition;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.AbstractControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.utils.Constraint;
import com.lombardinternational.casemanagement.service.decision.domain.utils.FieldConstraint;

import static com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control.common.Constants.EXPECTED_PREM_AMOUNT;
import static com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control.common.Utils.createConstraintWithNegate;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ChecklistFieldConstants.EXPECTED_PREM;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ControlConstants.APPLICATION_PACK_IN_LINE_WITH_PRICING_NOTE_NAME;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ControlConstants.APPLICATION_PACK_IN_LINE_WITH_PRICING_NOTE_TYPE;

@Service
public class ApplicationPackInLineWithPricingNoteControlBuilderService extends AbstractControlBuilderService {

    @Override
    public ControlDefinition buildControl(WebForm webForm, ScreenDescription screenDescription) {

        final List<FieldConstraint> constraints =
                List.of(createConstraintWithNegate(EXPECTED_PREM, Constraint.LESS, Collections.singletonList(EXPECTED_PREM_AMOUNT), Boolean.TRUE));
        if (Stream.of(constraints).anyMatch(group -> group.stream().allMatch(constraint -> constraint.test(screenDescription)))) {
            return buildControlDefinition();
        }
        return null;

    }

    @Override
    protected String getControlName() {

        return APPLICATION_PACK_IN_LINE_WITH_PRICING_NOTE_NAME;
    }

    @Override
    protected String getControlType() {

        return APPLICATION_PACK_IN_LINE_WITH_PRICING_NOTE_TYPE;
    }

}
