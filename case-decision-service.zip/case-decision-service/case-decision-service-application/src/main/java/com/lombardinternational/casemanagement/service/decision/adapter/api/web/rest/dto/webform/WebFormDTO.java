package com.lombardinternational.casemanagement.service.decision.adapter.api.web.rest.dto.webform;

import java.util.List;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class WebFormDTO {

    private String webFormId;
    private UserDetailDTO userDetail;
    private CompanyDetailDTO companyDetail;
    private String webFormWorkFlow;
    private List<WebFormGroupDTO> groups;
}
