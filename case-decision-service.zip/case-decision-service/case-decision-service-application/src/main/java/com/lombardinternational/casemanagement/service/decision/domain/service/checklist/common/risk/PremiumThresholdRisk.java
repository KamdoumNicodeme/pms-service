package com.lombardinternational.casemanagement.service.decision.domain.service.checklist.common.risk;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Field;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.utils.ChecklistUtils;
import com.lombardinternational.casemanagement.service.decision.domain.utils.constants.CaseRisk;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ChecklistFieldConstants.*;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.RulesConstants.*;

public class PremiumThresholdRisk {

    public static CaseRisk premiumThreshold(final ScreenDescription screenDescription, final Map<String,List<String>> overallCaseRisk) {

        var transactionAmountString = ChecklistUtils.getFieldById(screenDescription, TRANSACTION_AMOUNT).map(Field::getSelectedValue).orElse("0");
        var transactionAmount = new BigDecimal(transactionAmountString);

        var policiesAmountString = ChecklistUtils.getFieldById(screenDescription, ALL_POLICY_NAV_EUR).map(Field::getSelectedValue).orElse("0");
        var policiesAmount = new BigDecimal(policiesAmountString);

        var bePoliciesAmountString = ChecklistUtils.getFieldById(screenDescription, BE_POLICY_NAV_EUR).map(Field::getSelectedValue).orElse("0");
        var bePoliciesAmount = new BigDecimal(bePoliciesAmountString);

        var contractType = ChecklistUtils.getFieldById(screenDescription, CONTRACT_TYPE).map(Field::getSelectedValue).orElse(null);
        var isBusinessOriginBE =
                (ChecklistUtils.getFieldById(screenDescription, BUSINESS_ORIGIN).map(Field::getSelectedValue).stream().allMatch("BE"::equals));

        // Premium amount threshold met
        if (!isBusinessOriginBE) {
            var firstSlice = new BigDecimal("2500000.0");
            var secondSlice = new BigDecimal("10000000.0");

            if (transactionAmount.add(policiesAmount.remainder(secondSlice)).divide(secondSlice).compareTo(BigDecimal.ONE) >= 0) {
                (overallCaseRisk.get(HIGH)).add("Premium amount threshold met");
                return CaseRisk.CASE_RISK_HIGH;
            } else if ((transactionAmount.compareTo(firstSlice) >= 0 || (transactionAmount.compareTo(firstSlice) < 0
                    && policiesAmount.compareTo(firstSlice) < 0 && transactionAmount.add(policiesAmount).compareTo(firstSlice) >= 0))) {
                return CaseRisk.CASE_RISK_MEDIUM;
            }

        } else {
            var sum = transactionAmount.add(bePoliciesAmount);
            BigDecimal firstSlice = BigDecimal.ZERO, secondSlice = BigDecimal.ZERO, maxSlice = BigDecimal.ZERO;
            var reasonBe = "";
            var isTriggered = false;

            if (INVESTMENT_POLICY.equals(contractType)) {
                firstSlice = new BigDecimal("1000000.0");
                secondSlice = new BigDecimal("5000000.0");
                maxSlice = new BigDecimal("5000000.0");
                reasonBe = "Premium amount threshold met (BE investment)";
                isTriggered = true;
            } else if (CAPITALISED_POLICY.equals(contractType)) {
                firstSlice = new BigDecimal("2500000.0");
                secondSlice = new BigDecimal("5000000.0");
                maxSlice = new BigDecimal("10000000.0");
                reasonBe = "Premium amount threshold met (BE capitalized)";
                isTriggered = true;
            }

            if (isTriggered && sum.compareTo(firstSlice) >= 0) {
                if (sum.compareTo(maxSlice) >= 0
                        && transactionAmount.add(bePoliciesAmount.remainder(secondSlice)).divide(secondSlice).compareTo(BigDecimal.ONE) >= 0) {
                    (overallCaseRisk.get(HIGH)).add(reasonBe);
                    return CaseRisk.CASE_RISK_HIGH;
                } else if (sum.compareTo(maxSlice) < 0
                        && transactionAmount.add(bePoliciesAmount.remainder(firstSlice)).divide(firstSlice).compareTo(BigDecimal.ONE) >= 0) {
                    return CaseRisk.CASE_RISK_MEDIUM;
                }
            }
        }
        return CaseRisk.CASE_RISK_STANDARD;
    }
}
