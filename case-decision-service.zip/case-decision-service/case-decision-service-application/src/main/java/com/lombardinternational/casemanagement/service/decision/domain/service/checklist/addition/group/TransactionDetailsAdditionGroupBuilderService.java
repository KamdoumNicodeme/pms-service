package com.lombardinternational.casemanagement.service.decision.domain.service.checklist.addition.group;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.lombardinternational.casemanagement.service.decision.domain.model.policy.Policy;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Group;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Tab;
import com.lombardinternational.casemanagement.service.decision.domain.model.transaction.BusinessTransaction;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.checklist.GroupBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.checklist.addition.field.TransactionDetailsAdditionFieldsBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.utils.RulesUtils;

import lombok.AllArgsConstructor;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ChecklistFieldConstants.*;

@Service
@AllArgsConstructor
public class TransactionDetailsAdditionGroupBuilderService implements GroupBuilderService {

    private final TransactionDetailsAdditionFieldsBuilderService transactionDetailsAdditionFieldsBuilderService;

    @Override
    public void buildGroup(final WebForm webForm, final ScreenDescription screenDescription, final Tab parentTab, final Policy policy,
            final BusinessTransaction business, final Map<String,List<String>> overallCaseRisk) {

        var transactionDetails = RulesUtils.getGroupInTab(parentTab, TRANSACTION_DETAILS_GROUP);
        if (transactionDetails == null) {
            transactionDetails = Group.builder().groupId(TRANSACTION_DETAILS_GROUP).build();
            parentTab.getGroups().add(transactionDetails);
        }
        transactionDetails.setIsActive(true);
        transactionDetails.incrementOrder();
        transactionDetails.setTitle("Transaction details");
        transactionDetailsAdditionFieldsBuilderService.buildField(webForm, screenDescription, transactionDetails, policy, business,
                overallCaseRisk);
    }
}
