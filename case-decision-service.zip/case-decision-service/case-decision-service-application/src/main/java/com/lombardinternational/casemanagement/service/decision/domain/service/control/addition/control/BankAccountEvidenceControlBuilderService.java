package com.lombardinternational.casemanagement.service.decision.domain.service.control.addition.control;

import java.util.ArrayList;
import java.util.Collections;

import org.springframework.stereotype.Service;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ControlDefinition;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.AbstractControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.utils.Constraint;
import com.lombardinternational.casemanagement.service.decision.domain.utils.FieldConstraint;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ChecklistFieldConstants.*;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ControlConstants.*;

@Service
public class BankAccountEvidenceControlBuilderService extends AbstractControlBuilderService {

    @Override
    public ControlDefinition buildControl(final WebForm webForm, final ScreenDescription screenDescription) {

        final var constraints = new ArrayList<FieldConstraint>();
        constraints.add(FieldConstraint.builder().fieldId(FUND_COUNTRY_DIFFER_TAX_COUNTRY).constraint(Constraint.EQUALS)
                .values(Collections.singletonList(YES)).build());
        constraints.add(FieldConstraint.builder().fieldId(ECONOMIC_JUSTIFICATION).constraint(Constraint.EQUALS)
                .values(Collections.singletonList(NO)).build());
        constraints.add(FieldConstraint.builder().fieldId(EVIDENCE_BANK_ACCOUNT_KNOWN).constraint(Constraint.EQUALS)
                .values(Collections.singletonList(NO)).build());
        constraints.add(FieldConstraint.builder().fieldId(PH_REFUSE_TO_PROVIDE_EVIDENCE).constraint(Constraint.EQUALS)
                .values(Collections.singletonList(YES)).build());
        if (constraints.stream().allMatch(constraint -> constraint.test(screenDescription))) {
            return buildControlDefinition();
        }
        return null;
    }

    @Override
    public String getControlName() {

        return BANK_ACCOUNT_EVIDENCE_NAME;
    }

    @Override
    public String getControlType() {

        return BANK_ACCOUNT_EVIDENCE_TYPE;
    }
}
