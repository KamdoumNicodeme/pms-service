package com.lombardinternational.casemanagement.service.decision.adapter.api.web.rest.dto.screen;

import java.util.List;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class TabDTO {

    private String tabId;
    private String label;
    private String i18NLabelKey;
    private int order;
    private boolean triggersRecomputeScreen;
    private String type;
    private List<GroupDTO> groups;
    private String displayIf;
}
