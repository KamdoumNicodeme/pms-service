package com.lombardinternational.casemanagement.service.decision.domain.service.checklist.common.risk;

import java.util.List;
import java.util.Map;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.transaction.BusinessTransaction;
import com.lombardinternational.casemanagement.service.decision.domain.utils.ChecklistUtils;
import com.lombardinternational.casemanagement.service.decision.domain.utils.constants.CaseRisk;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.RulesUtils.*;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ChecklistFieldConstants.*;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.RulesConstants.*;

public class GoldenVisaRisk {

    public static CaseRisk goldenVisa(final ScreenDescription screenDescription, final BusinessTransaction transaction,
            final Map<String,List<String>> overallCaseRisk) {

        if (ChecklistUtils.getFieldById(screenDescription, IS_PH_EBO_GOLDEN_VISA).isPresent()
                && ChecklistUtils.getFieldById(screenDescription, IS_PH_EBO_GOLDEN_VISA).get().getSelectedValue() != null) {
            String goldenVisa = getRiskFactorAnswerDescription(transaction, INT_RF_013);
            if (YES.equalsIgnoreCase(goldenVisa)) {
                overallCaseRisk.get(HIGH).add("PH Golden Visa / passport");
                return CaseRisk.CASE_RISK_HIGH;
            }
        }
        return CaseRisk.CASE_RISK_STANDARD;
    }
}
