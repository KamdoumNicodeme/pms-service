package com.lombardinternational.casemanagement.service.decision.domain.service.checklist.common.risk;

import java.util.List;
import java.util.Map;

import com.lombardinternational.casemanagement.service.decision.domain.model.transaction.BusinessTransaction;
import com.lombardinternational.casemanagement.service.decision.domain.utils.constants.CaseRisk;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.RulesUtils.*;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.RulesConstants.*;

public class IndustrySectorRisk {

    public static CaseRisk industrySector(final BusinessTransaction transaction, final Map<String,List<String>> overallCaseRisk) {

        String industrySectorRiskLevel = getRiskFactorLevel(transaction, INT_RF_003);
        String industrySectorRiskData = getRiskFactorData(transaction, INT_RF_003);

        if (HIGH.equalsIgnoreCase(industrySectorRiskLevel)) {
            overallCaseRisk.get(HIGH).add("EBO/originator industry sector :" + industrySectorRiskData);
            return CaseRisk.CASE_RISK_HIGH;
        } else if (MEDIUM.equalsIgnoreCase(industrySectorRiskLevel)) {
            return CaseRisk.CASE_RISK_MEDIUM;
        }
        return CaseRisk.CASE_RISK_STANDARD;

    }
}
