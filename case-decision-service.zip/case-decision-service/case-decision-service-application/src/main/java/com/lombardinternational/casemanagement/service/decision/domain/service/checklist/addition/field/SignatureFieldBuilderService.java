package com.lombardinternational.casemanagement.service.decision.domain.service.checklist.addition.field;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.lombardinternational.casemanagement.service.decision.domain.model.policy.Policy;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.CheckBoxField;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Field;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Group;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.SelectInputField;
import com.lombardinternational.casemanagement.service.decision.domain.model.transaction.BusinessTransaction;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.checklist.FieldBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.spi.repository.ReferenceDataRepositoryService;
import com.lombardinternational.casemanagement.service.decision.domain.utils.ChecklistUtils;

import lombok.RequiredArgsConstructor;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ChecklistFieldConstants.*;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ReferenceConstants.*;

@Service
@RequiredArgsConstructor
public class SignatureFieldBuilderService implements FieldBuilderService {

    private final ReferenceDataRepositoryService referenceDataRepositoryService;

    @Override
    public void buildField(final WebForm webForm, final ScreenDescription screenDescription, final Group group, final Policy policy,
            final BusinessTransaction transaction, final Map<String,List<String>> overallCaseRisk) {

        Field.resetFieldId();
        evaluateSignatureType(group);
        evaluateProvider(group);
        evaluateAuthorizedProvider(group);
        evaluateClientValidation(group);
        evaluateMultiFactorAuthentication(group);
        evaluateOriginalSignedDocument(group);
    }

    private void evaluateSignatureType(final Group group) {

        var signatureType = (SelectInputField) ChecklistUtils.getFieldInGroup(group, SIGNATURE_TYPE);
        if (signatureType == null) {
            signatureType = SelectInputField.builder().fieldId(SIGNATURE_TYPE).build();
            group.getFields().add(signatureType);
        }
        signatureType.setIsActive(Boolean.TRUE);
        signatureType.setLabel("Signature Type?");
        signatureType.setMandatory(Boolean.TRUE);
        signatureType.setEnabled(Boolean.TRUE);
        signatureType.incrementOrder();
        signatureType.setOptions(referenceDataRepositoryService.getReferenceDataOptionsByDomain(SIGNATURE_DOMAIN));

    }

    private void evaluateProvider(Group group) {

        var provider = (SelectInputField) ChecklistUtils.getFieldInGroup(group, PROVIDER_GROUP);
        if (provider == null) {
            provider = SelectInputField.builder().fieldId(PROVIDER_GROUP).build();
            group.getFields().add(provider);
        }
        provider.setIsActive(Boolean.TRUE);
        provider.setLabel("Provider?");
        provider.setMandatory(Boolean.TRUE);
        provider.setEnabled(Boolean.TRUE);
        provider.incrementOrder();
        provider.setOptions(referenceDataRepositoryService.getReferenceDataOptionsByDomain(PROVIDER_DOMAIN));
        provider.setDisplayIf("#" + SIGNATURE_TYPE + "# == \"ELECTRONIC\" " + "|| " + "#" + SIGNATURE_TYPE + "# == \"MULTIPLE\"");

    }

    private void evaluateAuthorizedProvider(final Group group) {

        var authorizedProvicer = (CheckBoxField) ChecklistUtils.getFieldInGroup(group, EU_AUTHORIZED_PROVIDER_GROUP);
        if (authorizedProvicer == null) {
            authorizedProvicer = CheckBoxField.builder().fieldId(EU_AUTHORIZED_PROVIDER_GROUP).build();
            group.getFields().add(authorizedProvicer);
        }
        authorizedProvicer.setIsActive(Boolean.TRUE);
        authorizedProvicer.setLabel("EU authorised Provider?");
        authorizedProvicer.setMandatory(Boolean.TRUE);
        authorizedProvicer.setEnabled(Boolean.TRUE);
        authorizedProvicer.incrementOrder();
        authorizedProvicer.setDisplayIf("(#" + SIGNATURE_TYPE + "# == \"ELECTRONIC\"" + " || " + "#" + SIGNATURE_TYPE + "# == \"MULTIPLE\") && #"
                + PROVIDER + "# == \"PARTNER_ESIGN_SERVICE\"");
    }

    private void evaluateClientValidation(final Group group) {

        var clientValidation = (CheckBoxField) ChecklistUtils.getFieldInGroup(group, CLIENT_IDENTIFICATION_VALIDATION);
        if (clientValidation == null) {
            clientValidation = CheckBoxField.builder().fieldId(CLIENT_IDENTIFICATION_VALIDATION).build();
            group.getFields().add(clientValidation);
        }
        clientValidation.setIsActive(Boolean.TRUE);
        clientValidation.setLabel("Client Identification & Validation?");
        clientValidation.setMandatory(Boolean.TRUE);
        clientValidation.setEnabled(Boolean.TRUE);
        clientValidation.incrementOrder();
        clientValidation.setDisplayIf("(#" + SIGNATURE_TYPE + "# == \"ELECTRONIC\"" + " || " + "#" + SIGNATURE_TYPE + "# == \"MULTIPLE\") && (#"
                + PROVIDER + "# == \"PARTNER_ESIGN_SERVICE\"" + " || #" + PROVIDER + "# == \"INTERNAL_PROVIDER\")");

    }

    private void evaluateMultiFactorAuthentication(final Group group) {

        var multiAuthentication = (CheckBoxField) ChecklistUtils.getFieldInGroup(group, MULTIFACTOR_AUTHENTICATION);
        if (multiAuthentication == null) {
            multiAuthentication = CheckBoxField.builder().fieldId(MULTIFACTOR_AUTHENTICATION).build();
            group.getFields().add(multiAuthentication);
        }
        multiAuthentication.setIsActive(Boolean.TRUE);
        multiAuthentication.setLabel("Multifactor Authentication?");
        multiAuthentication.setMandatory(Boolean.TRUE);
        multiAuthentication.setEnabled(Boolean.TRUE);
        multiAuthentication.incrementOrder();
        multiAuthentication.setDisplayIf("(#" + SIGNATURE_TYPE + "# == \"ELECTRONIC\"" + " || " + "#" + SIGNATURE_TYPE + "# == \"MULTIPLE\") && #"
                + PROVIDER + "# == \"PARTNER_ESIGN_SERVICE\"");

    }

    private void evaluateOriginalSignedDocument(final Group group) {

        var originalSignedDocument = (CheckBoxField) ChecklistUtils.getFieldInGroup(group, ORIGNAL_SIGNED_DOCUMENT_AUDIT_LOG_CMT);
        if (originalSignedDocument == null) {
            originalSignedDocument = CheckBoxField.builder().fieldId(ORIGNAL_SIGNED_DOCUMENT_AUDIT_LOG_CMT).build();
            group.getFields().add(originalSignedDocument);
        }
        originalSignedDocument.setIsActive(Boolean.TRUE);
        originalSignedDocument.setLabel("Original Signed Document + Audit Log in CMT?");
        originalSignedDocument.setMandatory(Boolean.TRUE);
        originalSignedDocument.setEnabled(Boolean.TRUE);
        originalSignedDocument.incrementOrder();
        originalSignedDocument.setDisplayIf("(#" + SIGNATURE_TYPE + "# == \"ELECTRONIC\"" + " || " + "#" + SIGNATURE_TYPE
                + "# == \"MULTIPLE\") && (#" + PROVIDER + "# == \"PARTNER_ESIGN_SERVICE\"" + " || #" + PROVIDER + "# == \"INTERNAL_PROVIDER\")");

    }
}
