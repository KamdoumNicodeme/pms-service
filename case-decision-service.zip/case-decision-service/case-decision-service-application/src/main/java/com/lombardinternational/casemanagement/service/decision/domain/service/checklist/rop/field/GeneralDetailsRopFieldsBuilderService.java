package com.lombardinternational.casemanagement.service.decision.domain.service.checklist.rop.field;

import com.lombardinternational.casemanagement.service.decision.domain.model.policy.AbstractPerson;
import com.lombardinternational.casemanagement.service.decision.domain.model.policy.Policy;
import com.lombardinternational.casemanagement.service.decision.domain.model.policy.SourceOfFunds;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Field;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Group;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.SelectInputField;
import com.lombardinternational.casemanagement.service.decision.domain.model.transaction.BusinessTransaction;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.checklist.FieldBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.spi.repository.ReferenceDataRepositoryService;
import com.lombardinternational.casemanagement.service.decision.domain.utils.ChecklistUtils;
import com.lombardinternational.casemanagement.service.decision.domain.utils.WebformUtils;
import com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ChecklistFieldConstants;
import com.lombardinternational.casemanagement.service.decision.domain.utils.constants.WebFormFieldConstants;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
import java.util.Objects;

import static com.lombardinternational.casemanagement.service.decision.domain.service.checklist.common.field.CommonGeneralDetailsFieldsBuilderService.*;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ChecklistFieldConstants.INSIDER;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ReferenceConstants.YES_NO_DOMAIN;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.RulesConstants.NO;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.RulesConstants.YES;

@Service
@AllArgsConstructor
public class GeneralDetailsRopFieldsBuilderService implements FieldBuilderService {

    private final ReferenceDataRepositoryService referenceDataRepositoryService;

    @Override
    public void buildField(final WebForm webForm, final ScreenDescription screenDescription, final Group group, final Policy policy,
            final BusinessTransaction transaction, final Map<String,List<String>> overallCaseRisk) {

        Field.resetFieldId();
        evaluateContractType(group, policy);
        evaluatePolicyNumber(group, policy);
        evaluatePolicyCurrency(group, policy);
        evaluateIsMultiSupport(group, policy, referenceDataRepositoryService);
        evaluateBusinessOrigin(group, policy, referenceDataRepositoryService);
        evaluateCountryOfApplicableLaw(group, policy, referenceDataRepositoryService);
        evaluatePolicyNavEur(group, policy);
        evaluateBePolicyNavEur(group, transaction);
        evaluateExpectedTransactionAmount(group, transaction);
        evaluateExpectedTransactionAmountEur(group, policy, transaction);
        evaluateIsItTheLastInstallment(group, webForm);
        evaluateInsider(group, policy);
    }

    private void evaluateIsItTheLastInstallment(final Group group, final WebForm webForm) {

        var isItTheLastInstallment = (SelectInputField) ChecklistUtils.getFieldInGroup(group, ChecklistFieldConstants.IS_IT_THE_LAST_INSTALLMENT);
        if (isItTheLastInstallment == null) {
            isItTheLastInstallment = SelectInputField.builder().fieldId(ChecklistFieldConstants.IS_IT_THE_LAST_INSTALLMENT).build();
            group.getFields().add(isItTheLastInstallment);
        }
        isItTheLastInstallment.setIsActive(true);
        isItTheLastInstallment.incrementOrder();
        isItTheLastInstallment.setLabel("Is it the last installment?");
        var isItTheLastInstallmentValue = WebformUtils.getWebFormFieldValueById(webForm, WebFormFieldConstants.IS_IT_THE_LAST_INSTALLMENT);
        isItTheLastInstallment.setSelectedValue("true".equals(isItTheLastInstallmentValue) ? YES : NO);
        isItTheLastInstallment.setOptions(referenceDataRepositoryService.getReferenceDataOptionsByDomainAndSelectedValue(YES_NO_DOMAIN,
                isItTheLastInstallment.getSelectedValue()));
    }

    private void evaluateInsider(final Group group, final Policy policy) {

        var insider = (SelectInputField) ChecklistUtils.getFieldInGroup(group, INSIDER);
        if (insider == null) {
            insider = SelectInputField.builder().fieldId(INSIDER).build();
            group.getFields().add(insider);
        }
        insider.setIsActive(true);
        insider.incrementOrder();
        insider.setDisplayIf("false");
        insider.setLabel("Is the person an insider to any assets invested in the policy?");

        var isInsider = policy.getThirdParties().stream().map(AbstractPerson::getSourceOfFunds).filter(Objects::nonNull)
                .map(SourceOfFunds::getInsiderFlag).filter(Objects::nonNull).anyMatch(Boolean::booleanValue);

        var forcedValue = isInsider ? YES : NO;
        insider.setSelectedValue(forcedValue);
        insider.setOptions(
                referenceDataRepositoryService.getReferenceDataOptionsByDomainAndSelectedValue(YES_NO_DOMAIN, insider.getSelectedValue()));
    }
}
