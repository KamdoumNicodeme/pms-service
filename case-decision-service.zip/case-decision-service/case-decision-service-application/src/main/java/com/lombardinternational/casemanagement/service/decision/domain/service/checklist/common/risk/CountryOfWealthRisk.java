package com.lombardinternational.casemanagement.service.decision.domain.service.checklist.common.risk;

import java.util.List;
import java.util.Map;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Field;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.transaction.BusinessTransaction;
import com.lombardinternational.casemanagement.service.decision.domain.utils.ChecklistUtils;
import com.lombardinternational.casemanagement.service.decision.domain.utils.constants.CaseRisk;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.RulesUtils.*;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ChecklistFieldConstants.*;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.RulesConstants.*;

public class CountryOfWealthRisk {

    public static CaseRisk countryOfWealth(final ScreenDescription screenDescription, final BusinessTransaction transaction,
            final Map<String,List<String>> overallCaseRisk) {

        String countryOfWealthData = getRiskFactorData(transaction, ESC_RF_001);
        String kycMandatory = ChecklistUtils.getFieldById(screenDescription, KYC_MANDATORY).map(Field::getSelectedValue).orElse(null);
        String kycObtained = ChecklistUtils.getFieldById(screenDescription, NEW_KYC_OBTAINED).map(Field::getSelectedValue).orElse(null);
        String sameOrigin = ChecklistUtils.getFieldById(screenDescription, IS_SAME_ORIGIN_PREMIUM).map(Field::getSelectedValue).orElse(null);
        String newOrigin = ChecklistUtils.getFieldById(screenDescription, NEW_ORIGIN_PREM_CLASS).map(Field::getSelectedValue).orElse(null);

        boolean trigger = (YES.equalsIgnoreCase(kycMandatory) && YES.equalsIgnoreCase(kycObtained) && YES.equalsIgnoreCase(newOrigin))
                || (((YES.equalsIgnoreCase(kycMandatory) && NO.equalsIgnoreCase(kycObtained)) || (NO.equalsIgnoreCase(kycMandatory)))
                        && (YES.equalsIgnoreCase(sameOrigin) || (NO.equalsIgnoreCase(sameOrigin) && YES.equalsIgnoreCase(newOrigin))));

        if (countryOfWealthData.toUpperCase().startsWith(MISSING.toUpperCase())) {
            overallCaseRisk.get(BLOCKED).add(countryOfWealthData);
        } else if (trigger) {
            String countryOfWealthRisk = getRiskFactorLevel(transaction, ESC_RF_001);
            if (HIGH.equalsIgnoreCase(countryOfWealthRisk) || VERY_HIGH.equalsIgnoreCase(countryOfWealthRisk)) {
                overallCaseRisk.get(HIGH).add("EBO/Originator country of wealth generation : " + countryOfWealthData);
                return CaseRisk.CASE_RISK_HIGH;
            } else if (MEDIUM.equalsIgnoreCase(countryOfWealthRisk)) {
                return CaseRisk.CASE_RISK_MEDIUM;
            }
        }
        return CaseRisk.CASE_RISK_STANDARD;

    }
}
