package com.lombardinternational.casemanagement.service.decision.domain.service.checklist.common.risk;

import java.util.List;
import java.util.Map;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Field;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.utils.ChecklistUtils;
import com.lombardinternational.casemanagement.service.decision.domain.utils.constants.CaseRisk;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.RulesUtils.*;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ChecklistFieldConstants.*;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.RulesConstants.*;

public class ThirdPartyPaymentNoEvidenceRisk {

    public static CaseRisk thirdPartyPaymentNoEvidence(final ScreenDescription screenDescription, final Map<String,List<String>> overallCaseRisk) {

        String payerTaxCountryDisplay =
                ChecklistUtils.getFieldById(screenDescription, PAYER_TAX_COUNTRY_DIFFER_PH_EBO).map(Field::getDisplayIf).orElse(null);

        boolean isPayerTaxCountryDisplay = "true".equals(payerTaxCountryDisplay);
        if (isPayerTaxCountryDisplay && evaluateFieldValue(screenDescription, PAYER_TAX_COUNTRY_DIFFER_PH_EBO, YES, null)
                && evaluateFieldValue(screenDescription, EVIDENCE_ENTITY_KNOWN, NO, null)) {
            overallCaseRisk.get(HIGH).add("3rd party payment - No evidence that the legal entity is known by tax authorities");
            return CaseRisk.CASE_RISK_HIGH;
        }
        return CaseRisk.CASE_RISK_STANDARD;

    }
}
