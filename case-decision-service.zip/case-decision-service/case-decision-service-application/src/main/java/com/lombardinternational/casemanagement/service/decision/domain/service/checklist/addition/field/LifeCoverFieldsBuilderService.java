package com.lombardinternational.casemanagement.service.decision.domain.service.checklist.addition.field;

import com.lombardinternational.casemanagement.service.decision.domain.model.policy.Policy;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.*;
import com.lombardinternational.casemanagement.service.decision.domain.model.transaction.BusinessTransaction;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.checklist.FieldBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.spi.repository.ReferenceDataRepositoryService;
import com.lombardinternational.casemanagement.service.decision.domain.utils.ChecklistUtils;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ChecklistFieldConstants.*;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ReferenceConstants.YES_NO_DOMAIN;

@Service
@AllArgsConstructor
public class LifeCoverFieldsBuilderService implements FieldBuilderService {

    private final ReferenceDataRepositoryService referenceDataRepositoryService;

    @Override
    public void buildField(WebForm webForm, ScreenDescription screenDescription, Group group, Policy policy, BusinessTransaction transaction,
            Map<String,List<String>> overallCaseRisk) {

        Field.resetFieldId();
        evaluateLifeCoverType(group);
        evaluateSAR(group);
        evaluateUnderWritings(group);
    }

    private void evaluateLifeCoverType(Group group) {

        var lifeCoverType = (SelectInputField) ChecklistUtils.getFieldInGroup(group, LIFE_COVER_TYPE);
        if (lifeCoverType == null) {
            lifeCoverType = SelectInputField.builder().fieldId(LIFE_COVER_TYPE).build();
            group.getFields().add(lifeCoverType);
        }
        lifeCoverType.setIsActive(true);
        lifeCoverType.incrementOrder();
        lifeCoverType.setLabel("Life cover type capped");
        lifeCoverType.setEnabled(true);
        lifeCoverType.setMandatory(true);
        lifeCoverType.setOptions(referenceDataRepositoryService.getReferenceDataOptionsByDomain(YES_NO_DOMAIN));
    }

    private void evaluateSAR(Group group) {

        var sar = (TextInputField) ChecklistUtils.getFieldInGroup(group, SAR);
        if (sar == null) {
            sar = TextInputField.builder().fieldId(SAR).build();
            group.getFields().add(sar);
        }
        sar.setIsActive(true);
        sar.incrementOrder();
        sar.setLabel("SAR");
        sar.setEnabled(true);
        sar.setDisplayIf("#" + LIFE_COVER_TYPE + "# == \"NO\"");
    }

    private void evaluateUnderWritings(Group group) {

        var underWritings = (SelectInputField) ChecklistUtils.getFieldInGroup(group, UNDER_WRITINGS);
        if (underWritings == null) {
            underWritings = SelectInputField.builder().fieldId(UNDER_WRITINGS).build();
            group.getFields().add(underWritings);
        }
        underWritings.setIsActive(true);
        underWritings.incrementOrder();
        underWritings.setLabel("Underwritings");
        underWritings.setEnabled(true);
        underWritings.setMandatory(true);
        underWritings.setDisplayIf("#" + LIFE_COVER_TYPE + "# == \"NO\"");
        underWritings.setOptions(referenceDataRepositoryService.getReferenceDataOptionsByDomain(UNDER_WRITINGS_OPTIONS));
    }
}
