package com.lombardinternational.casemanagement.service.decision.domain.service.checklist.common.risk;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.IntStream;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Field;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.utils.ChecklistUtils;
import com.lombardinternational.casemanagement.service.decision.domain.utils.constants.CaseRisk;

import lombok.extern.slf4j.Slf4j;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ChecklistFieldConstants.*;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.RulesConstants.*;

@Slf4j
public class PaymentOutsideTaxCountryRisk {

    public static CaseRisk paymentOutsideTaxCountry(final ScreenDescription screenDescription, final Map<String,List<String>> overallCaseRisk) {

        final var businessOrigin = ChecklistUtils.getFieldById(screenDescription, BUSINESS_ORIGIN).map(Field::getSelectedValue).orElse("");
        if (!"BE".equals(businessOrigin)) {
            return CaseRisk.CASE_RISK_STANDARD;
        }

        var numberAccount = 0;
        try {
            numberAccount = Integer.parseInt(
                    ChecklistUtils.getFieldById(screenDescription, NUMBER_OF_ORIGINATING_ACCOUNTS).map(Field::getSelectedValue).orElse("0"));
        } catch (NumberFormatException e) {
            log.error("Field '{}' cannot be parsed to integer, with error: {}", NUMBER_OF_ORIGINATING_ACCOUNTS, e.getMessage());
            return CaseRisk.CASE_RISK_STANDARD;
        }

        final var phResidenceCountries = ChecklistUtils.getFieldById(screenDescription, PH_RESIDENCE_COUNTRY).map(Field::getSelectedValue)
                .orElse("").split(ChecklistUtils.countryDelimiter);
        final var anyOriginatingCountryDiffersFromPhCountries = IntStream.range(1, numberAccount + 1).boxed()
                // Get all originating country field values
                .map(n -> ChecklistUtils.getFieldById(screenDescription, COUNTRY_OF_ORIGINATING_ACCOUNTS + "_" + n).map(Field::getSelectedValue)
                        .orElse(""))
                // Check if any of them is different from the residence country of ALL policyholders
                .anyMatch(countryOriginating -> Arrays.stream(phResidenceCountries).noneMatch(phCountry -> phCountry.equals(countryOriginating)));

        if (anyOriginatingCountryDiffersFromPhCountries) {
            overallCaseRisk.get(HIGH).add("Payment outside of the tax country");
            return CaseRisk.CASE_RISK_HIGH;
        }

        return CaseRisk.CASE_RISK_STANDARD;
    }
}
