package com.lombardinternational.casemanagement.service.decision.domain.service.checklist.rop.risk;

import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.stereotype.Service;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.transaction.BusinessTransaction;
import com.lombardinternational.casemanagement.service.decision.domain.service.checklist.RiskValueBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.checklist.common.risk.PayerPayeeBankCountryRisk;
import com.lombardinternational.casemanagement.service.decision.domain.service.checklist.common.risk.ThirdPartyPayerRisk;
import com.lombardinternational.casemanagement.service.decision.domain.utils.constants.CaseRisk;

import lombok.AllArgsConstructor;

@Service
@AllArgsConstructor
public class RiskValueRopBuilderService implements RiskValueBuilderService {

    @Override
    public String computeRiskValueRules(final ScreenDescription screenDescription, final BusinessTransaction transaction,
            final Map<String,List<String>> overallCaseRisk) {

        Set<CaseRisk> compute = new HashSet<>();

        compute.add(PayerPayeeBankCountryRisk.payerPayee(screenDescription, transaction, overallCaseRisk));
        compute.add(ThirdPartyPayerRisk.thirdPartyPayer(screenDescription, transaction, overallCaseRisk));

        // Filter by MaxValue to return highest escalation
        CaseRisk caseRisk = compute.stream().max(Comparator.comparing(CaseRisk::getOrder)).get();
        return caseRisk.getValue();
    }
}
