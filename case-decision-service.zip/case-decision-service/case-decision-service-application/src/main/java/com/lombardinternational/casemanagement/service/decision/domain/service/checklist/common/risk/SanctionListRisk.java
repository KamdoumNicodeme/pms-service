package com.lombardinternational.casemanagement.service.decision.domain.service.checklist.common.risk;

import java.util.List;
import java.util.Map;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Field;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.transaction.BusinessTransaction;
import com.lombardinternational.casemanagement.service.decision.domain.utils.ChecklistUtils;
import com.lombardinternational.casemanagement.service.decision.domain.utils.constants.CaseRisk;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.RulesUtils.*;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ChecklistFieldConstants.*;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.RulesConstants.*;

public class SanctionListRisk {

    public static CaseRisk sanctionList(final ScreenDescription screenDescription, final BusinessTransaction transaction,
            final Map<String,List<String>> overallCaseRisk) {

        String sanctionListStatusData = getRiskFactorData(transaction, INT_RF_007);
        String onSanctionList = ChecklistUtils.getFieldById(screenDescription, IS_ON_SANCTION_LIST).map(Field::getSelectedValue).orElse(null);
        String payerInSanctionList =
                ChecklistUtils.getFieldById(screenDescription, PAYER_IN_SANCTION_LIST).map(Field::getSelectedValue).orElse(null);
        String paymentToThirdParty = ChecklistUtils.getFieldById(screenDescription, PAYMENT_THIRD_PARTY).map(Field::getSelectedValue).orElse(null);

        boolean blockSendingToCompliance = onSanctionList == null || (YES.equalsIgnoreCase(paymentToThirdParty) && payerInSanctionList == null);

        if (!blockSendingToCompliance && !sanctionListStatusData.toUpperCase().contains(MISSING) && (YES.equalsIgnoreCase(onSanctionList)
                || (YES.equalsIgnoreCase(paymentToThirdParty) && YES.equalsIgnoreCase(payerInSanctionList)))) {
            overallCaseRisk.get(HIGH).add("Sanction list");
            return CaseRisk.CASE_RISK_HIGH;
        }
        return CaseRisk.CASE_RISK_STANDARD;

    }
}
