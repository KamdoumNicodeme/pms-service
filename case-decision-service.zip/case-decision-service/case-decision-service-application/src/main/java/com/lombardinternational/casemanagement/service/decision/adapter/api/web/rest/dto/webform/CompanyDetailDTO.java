package com.lombardinternational.casemanagement.service.decision.adapter.api.web.rest.dto.webform;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class CompanyDetailDTO {

    String companyId;
    String companyName;
    String partnerType;
}
