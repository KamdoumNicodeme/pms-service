package com.lombardinternational.casemanagement.service.decision.domain.service.control.addition.control;

import java.util.ArrayList;
import java.util.Collections;

import org.springframework.stereotype.Service;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ControlDefinition;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.AbstractControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.utils.Constraint;
import com.lombardinternational.casemanagement.service.decision.domain.utils.FieldConstraint;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ChecklistFieldConstants.*;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ControlConstants.*;

@Service
public class DocumentationOriginFundControlBuilderService extends AbstractControlBuilderService {

    @Override
    public ControlDefinition buildControl(final WebForm webForm, final ScreenDescription screenDescription) {

        final var constraints = new ArrayList<FieldConstraint>();
        constraints.add(FieldConstraint.builder().fieldId(PREMIUM_DIFFER_FROM_EXPECTED).constraint(Constraint.EQUALS)
                .values(Collections.singletonList(YES)).build());
        constraints.add(FieldConstraint.builder().fieldId(FUND_ORIGIN_SAME_AS_DISCLOSED).constraint(Constraint.EQUALS)
                .values(Collections.singletonList(NO)).build());
        if (constraints.stream().allMatch(constraint -> constraint.test(screenDescription))) {
            return buildControlDefinition();
        }
        return null;
    }

    @Override
    public String getControlName() {

        return DOCUMENTATION_ORIGIN_FUND_NAME;
    }

    @Override
    public String getControlType() {

        return DOCUMENTATION_ORIGIN_FUND_TYPE;
    }
}
