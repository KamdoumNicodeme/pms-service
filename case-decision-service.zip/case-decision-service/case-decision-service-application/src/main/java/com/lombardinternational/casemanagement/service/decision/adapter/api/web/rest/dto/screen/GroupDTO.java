package com.lombardinternational.casemanagement.service.decision.adapter.api.web.rest.dto.screen;

import java.util.List;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class GroupDTO {

    private String groupId;
    private String title;
    private String i18NTitleKey;
    private int order;
    private int columnsCount;
    private List<FieldDTO> fields;
    private String displayIf;
}
