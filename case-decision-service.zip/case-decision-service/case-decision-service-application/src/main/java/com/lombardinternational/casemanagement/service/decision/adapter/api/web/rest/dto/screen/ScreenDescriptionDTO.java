package com.lombardinternational.casemanagement.service.decision.adapter.api.web.rest.dto.screen;

import java.time.LocalDate;
import java.util.List;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class ScreenDescriptionDTO {

    private LocalDate loadTimeStamp;
    private String screenId;
    private ScreenDescriptionDTO inputedScreenDescription;
    private List<TabDTO> tabs;
}
