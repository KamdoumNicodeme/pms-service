package com.lombardinternational.casemanagement.service.decision.domain.service.checklist.rop.field;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.lombardinternational.casemanagement.service.decision.domain.model.policy.Policy;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Field;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Group;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.transaction.BusinessTransaction;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.checklist.FieldBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.checklist.rop.risk.RiskValueRopBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.spi.repository.ReferenceDataRepositoryService;

import lombok.AllArgsConstructor;

import static com.lombardinternational.casemanagement.service.decision.domain.service.checklist.common.field.CommonCaseRisksFieldsBuilderService.*;

@Service
@AllArgsConstructor
public class CaseRisksRopFieldsBuilderService implements FieldBuilderService {

    private final ReferenceDataRepositoryService referenceDataRepositoryService;

    private final RiskValueRopBuilderService riskValueRopBuilderService;

    @Override
    public void buildField(WebForm webForm, ScreenDescription screenDescription, Group group, Policy policy, BusinessTransaction transaction,
            Map<String,List<String>> overallCaseRisk) {

        Field.resetFieldId();
        evaluateOverallCaseRisk(group, screenDescription, transaction, overallCaseRisk, riskValueRopBuilderService);
        evaluateBlockedValue(group, overallCaseRisk);
        evaluatePCSReview(group, overallCaseRisk, referenceDataRepositoryService);
        evaluateRiskReason(group, overallCaseRisk);
    }
}
