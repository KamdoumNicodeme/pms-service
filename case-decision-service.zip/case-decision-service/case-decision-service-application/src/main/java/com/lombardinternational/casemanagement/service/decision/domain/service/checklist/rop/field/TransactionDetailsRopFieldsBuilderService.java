package com.lombardinternational.casemanagement.service.decision.domain.service.checklist.rop.field;

import com.lombardinternational.casemanagement.service.decision.domain.model.policy.Policy;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Field;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Group;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.TextInputField;
import com.lombardinternational.casemanagement.service.decision.domain.model.transaction.BusinessTransaction;
import com.lombardinternational.casemanagement.service.decision.domain.model.transaction.MoneyInPayment;
import com.lombardinternational.casemanagement.service.decision.domain.model.transaction.PaymentDetails;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.checklist.FieldBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.spi.repository.ReferenceDataRepositoryService;
import com.lombardinternational.casemanagement.service.decision.domain.utils.ChecklistUtils;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

import static com.lombardinternational.casemanagement.service.decision.domain.service.checklist.common.field.CommonTransactionDetailsFieldsBuilderService.*;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ChecklistFieldConstants.*;

@Service
@AllArgsConstructor
public class TransactionDetailsRopFieldsBuilderService implements FieldBuilderService {

    private final ReferenceDataRepositoryService referenceDataRepositoryService;

    @Override
    public void buildField(WebForm webForm, ScreenDescription screenDescription, Group group, Policy policy, BusinessTransaction transaction,
            Map<String,List<String>> overallCaseRisk) {

        Field.resetFieldId();

        evaluatePremiumWithAssets(webForm, group, referenceDataRepositoryService);
        evaluatePremiumWithUnqAssets(webForm, group, referenceDataRepositoryService);
        evaluateInvestedInIlf(group, referenceDataRepositoryService);
        evaluateIlfMnemonic(group);
        evaluatePaymentThirdParty(group, transaction, overallCaseRisk, referenceDataRepositoryService);
        evaluateRationalForInvestment(webForm, group);

        List<MoneyInPayment> payments = evaluateNumberOfOriginatingAccounts(group, transaction);
        for (int i = 1; i <= payments.size(); i++) {
            PaymentDetails details = payments.get(i - 1).getPaymentDetails();
            if (details == null || details.getPayerID() == null || details.getPayerBankName() == null || details.getPayerBankCountry() == null) {
                if (payments.get(i - 1).getExpectedPaymentDetails() != null) {
                    details = payments.get(i - 1).getExpectedPaymentDetails();
                } else {
                    details = new PaymentDetails();
                }
            }
            evaluateHolderOfOriginatingAccounts(group, details, i);
            evaluateCountryOfOriginatingAccounts(group, details, i, referenceDataRepositoryService);
            evaluateBankOfOriginatingAccounts(group, details, i);
        }

        evaluateCountryOfOriginatingAccountsRisk(group, transaction, payments.size(), overallCaseRisk);
    }

    private void evaluateIlfMnemonic(final Group group) {

        var ilfMnemonic = (TextInputField) ChecklistUtils.getFieldInGroup(group, ILF_MNEMONIC);
        if (ilfMnemonic == null) {
            ilfMnemonic = TextInputField.builder().fieldId(ILF_MNEMONIC).build();
            group.getFields().add(ilfMnemonic);
        }
        ilfMnemonic.setIsActive(true);
        ilfMnemonic.incrementOrder();
        ilfMnemonic.setLabel("ILF Mnemonic");
        ilfMnemonic.setEnabled(true);
        ilfMnemonic.setMandatory(true);
        ilfMnemonic.setDisplayIf("#" + INVESTED_IN_ILF + "# == \"YES\"");
    }
}
