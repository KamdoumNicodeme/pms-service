package com.lombardinternational.casemanagement.service.decision.adapter.api.web.rest.dto.screen;

import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.fasterxml.jackson.annotation.JsonTypeInfo;

import lombok.Data;
import lombok.RequiredArgsConstructor;
import lombok.experimental.SuperBuilder;

@JsonTypeInfo(use = JsonTypeInfo.Id.NAME, property = "type")
@JsonSubTypes({ @JsonSubTypes.Type(value = TextInputFieldDTO.class, name = "textInputField"),
        @JsonSubTypes.Type(value = NumberInputFieldDTO.class, name = "numberInputField"),
        @JsonSubTypes.Type(value = SelectInputFieldDTO.class, name = "selectInputField"),
        @JsonSubTypes.Type(value = CheckBoxFieldDTO.class, name = "checkBoxField"),
        @JsonSubTypes.Type(value = TextAreaFieldDTO.class, name = "textAreaField"), })
@Data
@SuperBuilder
@RequiredArgsConstructor
public abstract class FieldDTO {

    private String fieldId;
    private String label;
    private String i18NLabelKey;
    private int order;
    private Boolean enabled;
    private Boolean mandatory;
    private Boolean multiple;
    private Integer maxMultiple;
    private String selectedValue;
    private String displayIf;
    private String enableIf;
    private Boolean labelBold;
    private String sourceSystem;
}
