package com.lombardinternational.casemanagement.service.decision.domain.service.checklist.addition.group;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.lombardinternational.casemanagement.service.decision.domain.model.policy.Policy;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Group;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Tab;
import com.lombardinternational.casemanagement.service.decision.domain.model.transaction.BusinessTransaction;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.checklist.GroupBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.checklist.addition.field.DueDiligenceFieldsBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.utils.RulesUtils;

import lombok.AllArgsConstructor;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ChecklistFieldConstants.*;

@Service
@AllArgsConstructor
public class DueDiligenceAdditionGroupBuilderService implements GroupBuilderService {

    private final DueDiligenceFieldsBuilderService dueDiligenceFieldsBuilderService;

    @Override
    public void buildGroup(final WebForm webForm, final ScreenDescription screenDescription, final Tab parentTab, final Policy policy,
            final BusinessTransaction transaction, final Map<String,List<String>> overallCaseRisk) {

        var dueDiligence = RulesUtils.getGroupInTab(parentTab, DUE_DILIGENCE_GROUP);
        if (dueDiligence == null) {
            dueDiligence = Group.builder().groupId(DUE_DILIGENCE_GROUP).build();
            parentTab.getGroups().add(dueDiligence);
        }
        dueDiligence.setIsActive(true);
        dueDiligence.incrementOrder();
        dueDiligence.setTitle("Due diligence - EBO and related parties to the policy");
        dueDiligenceFieldsBuilderService.buildField(webForm, screenDescription, dueDiligence, policy, transaction, overallCaseRisk);
    }
}
