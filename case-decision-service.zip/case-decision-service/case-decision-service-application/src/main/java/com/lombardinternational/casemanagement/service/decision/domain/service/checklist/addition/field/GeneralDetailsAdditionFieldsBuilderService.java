package com.lombardinternational.casemanagement.service.decision.domain.service.checklist.addition.field;

import com.lombardinternational.casemanagement.service.decision.domain.model.policy.*;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.*;
import com.lombardinternational.casemanagement.service.decision.domain.model.transaction.BusinessTransaction;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.checklist.FieldBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.spi.repository.ReferenceDataRepositoryService;
import com.lombardinternational.casemanagement.service.decision.domain.utils.ChecklistUtils;
import com.lombardinternational.casemanagement.service.decision.domain.utils.RulesUtils;
import com.lombardinternational.casemanagement.service.decision.domain.utils.WebformUtils;
import com.lombardinternational.casemanagement.service.decision.domain.utils.constants.RulesConstants;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

import static com.lombardinternational.casemanagement.service.decision.domain.service.checklist.common.field.CommonGeneralDetailsFieldsBuilderService.*;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.ChecklistUtils.computeThirdPartyRoleValueAndDisplay;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.ChecklistUtils.isThirdPartyRoleAvailable;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ChecklistFieldConstants.*;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ReferenceConstants.*;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.RulesConstants.*;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.WebFormFieldConstants.IS_NIF_STILL_VALID_WF;

@Service
@AllArgsConstructor
public class GeneralDetailsAdditionFieldsBuilderService implements FieldBuilderService {

    private static final List<String> allowedReportingStatus = List.of("POLICY_FROZEN", "REPORTED_OPEN", "REPORTED_CLOSED");
    private final ReferenceDataRepositoryService referenceDataRepositoryService;

    @Override
    public void buildField(final WebForm webForm, final ScreenDescription screenDescription, final Group group, final Policy policy,
            final BusinessTransaction transaction, final Map<String,List<String>> overallCaseRisk) {

        Field.resetFieldId();
        evaluateContractType(group, policy);
        evaluatePolicyNumber(group, policy);
        evaluatePolicyCurrency(group, policy);
        evaluateIsMultiSupport(group, policy, referenceDataRepositoryService);
        evaluatePolicyNavEur(group, policy);
        evaluateAllPolicyNavEur(group, transaction);
        evaluateBePolicyNavEur(group, transaction);
        evaluateExpectedTransactionAmount(group, transaction);
        evaluateExpectedTransactionAmountEur(group, policy, transaction);
        if (WebformUtils.isV2(webForm)) {
            evaluateFiscalInformationStillValid(group, webForm);
        }
        evaluateCountryOfApplicableLaw(group, policy, referenceDataRepositoryService);
        evaluateTaxCountry(group, policy);
        evaluateBusinessOrigin(group, policy, referenceDataRepositoryService);
        evaluateRiskiestMissingCountry(group, transaction, overallCaseRisk);
        evaluatePHResidenceCountry(group, policy);
        evaluateOffShoreIndicia(group, transaction, policy);
        evaluatePhTypeAssessment(group, transaction, overallCaseRisk);
        evaluatePhLegalEntity(group, policy, transaction);
        evaluatePremiumPaidFromBeneficiary(group, policy, transaction);
        evaluateThirdPartySubTypeForPH(group, policy);
        evaluateMrlTrustee(group);
        evaluateTrust(group, policy);
        evaluateTrustCountry(group, policy);
        evaluateTrustee(group, policy);
        evaluateTrusteeCountry(group, policy);
        evaluateSettlor(group, policy);
        evaluateSettlorCountry(group, policy);
        evaluateCessionHolder(group, policy);
        evaluateCessionHolderCountry(group, policy);
        evaluateProxy(group, policy);
        evaluateProxyCountry(group, policy);
        evaluateLifeAssuredCountry(group, policy);
        evaluateSendingAddressCountry(group, policy);
        evaluateBeneficiary(group, policy);
        evaluateBeneficiaryCountry(group, policy);
        evaluateIrrevocableBeneficiary(group, policy);
        evaluateIrrevocableBeneficiaryCountry(group, policy);
        evaluateLaDifferentToPh(group, policy);
        evaluateLaDifferentToBen(group, policy);
        evaluatePhDifferentToEbo(group, policy);
        evaluateEboCountry(group, policy);
        evaluateNewUsIndicia(group);
        evaluateRequestFormReceived(group);
        evaluateFormSigner(group);
        evaluateTpBlock(group, policy);
    }

    private void evaluateAllPolicyNavEur(final Group group, final BusinessTransaction transaction) {

        var allPolicyNavEur = (NumberInputField) ChecklistUtils.getFieldInGroup(group, ALL_POLICY_NAV_EUR);
        if (allPolicyNavEur == null) {
            allPolicyNavEur = NumberInputField.builder().fieldId(ALL_POLICY_NAV_EUR).build();
            group.getFields().add(allPolicyNavEur);
        }
        allPolicyNavEur.setIsActive(true);
        allPolicyNavEur.incrementOrder();
        allPolicyNavEur.setLabel("Total policies NAV linked to the same EBO, excluding this expected premium");
        allPolicyNavEur.setSourceSystem("Policy value (in EUR) from CLASS");
        allPolicyNavEur.setDisplayIf("#" + BUSINESS_ORIGIN + "# != \"BE\"");
        allPolicyNavEur.setSelectedValue((transaction.getEboPolicyNav() != null && transaction.getEboPolicyNav().getTotalNav() != null)
                ? transaction.getEboPolicyNav().getTotalNav().toPlainString() : null);
    }

    private void evaluateFiscalInformationStillValid(final Group group, final WebForm webForm) {

        var fiscalInformationStillValid = (SelectInputField) ChecklistUtils.getFieldInGroup(group, FISCAL_INFORMATION_STILL_VALID);
        if (fiscalInformationStillValid == null) {
            fiscalInformationStillValid = SelectInputField.builder().fieldId(FISCAL_INFORMATION_STILL_VALID).build();
            group.getFields().add(fiscalInformationStillValid);
        }
        fiscalInformationStillValid.setIsActive(true);
        fiscalInformationStillValid.incrementOrder();
        fiscalInformationStillValid.setLabel("Fiscal information still valid?");
        var nifStillValidList = WebformUtils.getWebFormFieldsById(webForm, IS_NIF_STILL_VALID_WF);
        var allNifValid = nifStillValidList.stream().allMatch(field -> "true".equalsIgnoreCase(WebformUtils.getValueForWebFormField(field)));
        fiscalInformationStillValid.setSelectedValue(allNifValid ? YES : NO);
        fiscalInformationStillValid.setOptions(referenceDataRepositoryService.getReferenceDataOptionsByDomainAndSelectedValue(YES_NO_DOMAIN,
                fiscalInformationStillValid.getSelectedValue()));
    }

    private void evaluateTaxCountry(final Group group, final Policy policy) {

        var taxCountry = (SelectInputField) ChecklistUtils.getFieldInGroup(group, TAX_COUNTRY);
        if (taxCountry == null) {
            taxCountry = SelectInputField.builder().fieldId(TAX_COUNTRY).build();
            group.getFields().add(taxCountry);
        }
        taxCountry.setIsActive(true);
        taxCountry.incrementOrder();
        taxCountry.setLabel("Tax Country");
        taxCountry.setSourceSystem("Tax Country from CLASS");
        taxCountry.setSelectedValue(Optional.ofNullable(policy.getHolders()).stream().flatMap(Collection::stream).findFirst()
                .map(Holder::getTaxIsoCountryCode).orElse(null));
        taxCountry.setOptions(
                referenceDataRepositoryService.getReferenceDataOptionsByDomainAndSelectedValue(COUNTRY_DOMAIN, taxCountry.getSelectedValue()));
    }

    private void evaluateRiskiestMissingCountry(final Group group, final BusinessTransaction transaction,
            final Map<String,List<String>> overallCaseRisk) {

        var riskiestCountry = (TextAreaField) ChecklistUtils.getFieldInGroup(group, RESIDENCE_COUNTRY);
        if (riskiestCountry == null) {
            riskiestCountry = TextAreaField.builder().fieldId(RESIDENCE_COUNTRY).build();
            group.getFields().add(riskiestCountry);
        }
        riskiestCountry.setIsActive(true);
        riskiestCountry.incrementOrder();
        riskiestCountry.setLabel("Riskiest / Missing country of residence");
        riskiestCountry.setSourceSystem("From CLASS");
        riskiestCountry.setMandatory(true);
        riskiestCountry.setDisplayIf("true");
        String forcedValue = RulesUtils.getRiskFactorData(transaction, INT_RF_002);
        if (forcedValue.contains("N/A")) {
            forcedValue = Arrays.stream(forcedValue.split(";")).filter(tp -> tp.contains("N/A")).collect(Collectors.joining("\n"));
            overallCaseRisk.get(RulesConstants.BLOCKED).add("Country of residence risk factor cannot be assessed");
        }
        riskiestCountry.setSelectedValue(forcedValue);
    }

    private void evaluatePHResidenceCountry(final Group group, final Policy policy) {

        var phResidenceCountry = (TextInputField) ChecklistUtils.getFieldInGroup(group, PH_RESIDENCE_COUNTRY);
        if (phResidenceCountry == null) {
            phResidenceCountry = TextInputField.builder().fieldId(PH_RESIDENCE_COUNTRY).build();
            group.getFields().add(phResidenceCountry);
        }
        phResidenceCountry.setIsActive(true);
        phResidenceCountry.incrementOrder();
        phResidenceCountry.setLabel("PH(s) residence country");
        phResidenceCountry.setSourceSystem("From CLASS");
        computeThirdPartyRoleValueAndDisplay(phResidenceCountry, policy, List.of("HLR"));
    }

    private void evaluateOffShoreIndicia(final Group group, final BusinessTransaction transaction, final Policy policy) {

        var offShoreIndicia = (SelectInputField) ChecklistUtils.getFieldInGroup(group, OFF_SHORE_INDICIA);
        if (offShoreIndicia == null) {
            offShoreIndicia = SelectInputField.builder().fieldId(OFF_SHORE_INDICIA).build();
            group.getFields().add(offShoreIndicia);
        }
        offShoreIndicia.setIsActive(true);
        offShoreIndicia.incrementOrder();
        offShoreIndicia.setLabel("(Belgian Branch) Off-shore indicia found ?");
        offShoreIndicia.setMandatory(true);
        offShoreIndicia.setSourceSystem("From CLASS and converted");
        var forcedValue = NO;
        var forcedDisplayIf = "false";
        if ("BE".equals(ChecklistUtils.getFieldInGroup(group, BUSINESS_ORIGIN).getSelectedValue())) {
            forcedDisplayIf = "true";
            String wealthOriginatingCountryData = RulesUtils.getRiskFactorData(transaction, "ESC_RF_001");
            if (wealthOriginatingCountryData.toUpperCase().startsWith("MISSING")) {
                forcedValue = null;
            } else if (ChecklistUtils.isOffShoreIndiciaFound(transaction, policy, true)) {
                // the false boolean is to indicate if it is a MoneyIn or MoneyOut
                // In this case the boolean = true because the transaction is MoneyIn
                forcedValue = YES;
            }
        }
        offShoreIndicia.setSelectedValue(forcedValue);
        offShoreIndicia.setOptions(
                referenceDataRepositoryService.getReferenceDataOptionsByDomainAndSelectedValue(YES_NO_DOMAIN, offShoreIndicia.getSelectedValue()));
        offShoreIndicia.setDisplayIf(forcedDisplayIf);
    }

    private void evaluatePhTypeAssessment(final Group group, final BusinessTransaction transaction,
            final Map<String,List<String>> overallCaseRisk) {

        var phTypeAssessment = (TextInputField) ChecklistUtils.getFieldInGroup(group, PH_TYPE_ASSESSMENT);
        if (phTypeAssessment == null) {
            phTypeAssessment = TextInputField.builder().fieldId(PH_TYPE_ASSESSMENT).build();
            group.getFields().add(phTypeAssessment);
        }
        phTypeAssessment.setIsActive(true);
        phTypeAssessment.incrementOrder();
        phTypeAssessment.setLabel("PH type assessment");
        phTypeAssessment.setMandatory(true);
        phTypeAssessment.setSourceSystem("From Class");
        phTypeAssessment.setDisplayIf("true");
        String forcedValue = null;
        var phType = RulesUtils.getRiskFactorData(transaction, "INT_RF_014");
        if (phType.contains("N/A")) {
            overallCaseRisk.get(RulesConstants.BLOCKED).add("PH Type risk factor cannot be assessed");
        } else {
            forcedValue = phType;
        }
        phTypeAssessment.setSelectedValue(forcedValue);
    }

    private void evaluatePhLegalEntity(final Group group, final Policy policy, final BusinessTransaction transaction) {

        var phLegalEntity = (SelectInputField) ChecklistUtils.getFieldInGroup(group, PH_LEGAL_ENTITY);
        if (phLegalEntity == null) {
            phLegalEntity = SelectInputField.builder().fieldId(PH_LEGAL_ENTITY).build();
            group.getFields().add(phLegalEntity);
            phLegalEntity.setSelectedValue(null);
        }

        String forcedDisplayIf = "false";
        String PhType = RulesUtils.getRiskFactorData(transaction, INT_RF_014);
        if (!"N/A".equals(PhType) && !"PH Type=Physical".equals(PhType)) {
            List<String> listLegalForm = Arrays.asList("BM", "DEATH_EST", "FID_FR", "FIDEI", "FIDUCIARY", "FOUND", "KUOLINPESA", "PARTNRSHIP",
                    "PEN_SCHEM", "SS", "TREU", "TRUST");
            boolean isMatchLegalForm = policy.getHolders().stream().map(PolicyRole::getThirdParties).filter(Objects::nonNull)
                    .flatMap(Collection::stream).map(abstractPerson -> (MoralPerson) abstractPerson).filter(Objects::nonNull)
                    .map(MoralPerson::getCompanyLegalForm).anyMatch(listLegalForm::contains);
            if (!isMatchLegalForm) {
                forcedDisplayIf = "true";
            }
        }
        phLegalEntity.setIsActive(true);
        phLegalEntity.incrementOrder();
        phLegalEntity.setLabel(
                "Is the PH a legal entity (excluding société simple or any legal arrangement such as trust, fideicomiso, foundation or fiduciary)?");
        phLegalEntity.setMandatory(true);
        phLegalEntity.setEnabled(true);
        phLegalEntity.setDisplayIf(forcedDisplayIf);
        phLegalEntity.setOptions(referenceDataRepositoryService.getReferenceDataOptionsByDomain(YES_NO_DOMAIN));
    }

    private void evaluatePremiumPaidFromBeneficiary(final Group group, final Policy policy, final BusinessTransaction transaction) {

        var premPaidFromBen = (SelectInputField) ChecklistUtils.getFieldInGroup(group, PREM_PAID_FROM_BEN);
        if (ChecklistUtils.getFieldInGroup(group, PH_LEGAL_ENTITY) == null) {
            group.getFields().remove(premPaidFromBen);
        } else {
            if (premPaidFromBen == null) {
                premPaidFromBen = SelectInputField.builder().fieldId(PREM_PAID_FROM_BEN).build();
                group.getFields().add(premPaidFromBen);
                premPaidFromBen.setSelectedValue(null);
            }
            premPaidFromBen.setIsActive(true);
            premPaidFromBen.incrementOrder();
            premPaidFromBen.setLabel("Is the premium paid from the appointed beneficiary who is a natural person");
            premPaidFromBen.setMandatory(true);
            premPaidFromBen.setEnabled(true);
            premPaidFromBen.setOptions(referenceDataRepositoryService.getReferenceDataOptionsByDomain(YES_NO_DOMAIN));

            var forcedDisplayIf = "false";
            var PhType = RulesUtils.getRiskFactorData(transaction, INT_RF_014);

            if (!"N/A".equals(PhType) && !"PH Type=Physical".equals(PhType)) {
                List<String> listLegalForm = Arrays.asList("BM", "DEATH_EST", "FID_FR", "FIDEI", "FIDUCIARY", "FOUND", "KUOLINPESA", "PARTNRSHIP",
                        "PEN_SCHEM", "SS", "TREU", "TRUST");
                var isMatchLegalForm = policy.getHolders().stream().map(PolicyRole::getThirdParties).filter(Objects::nonNull)
                        .flatMap(Collection::stream).map(abstractPerson -> (MoralPerson) abstractPerson).filter(Objects::nonNull)
                        .map(MoralPerson::getCompanyLegalForm).anyMatch(listLegalForm::contains);
                if (!isMatchLegalForm) {
                    forcedDisplayIf = "#" + PH_LEGAL_ENTITY + "# == \"YES\"";
                }
            }
            premPaidFromBen.setDisplayIf(forcedDisplayIf);
        }
    }

    private void evaluateThirdPartySubTypeForPH(final Group group, final Policy policy) {

        var thirdPartySubTypeForPH = (TextInputField) ChecklistUtils.getFieldInGroup(group, THIRD_PARTY_SUB_TYPE_FOR_PH);
        if (thirdPartySubTypeForPH == null) {
            thirdPartySubTypeForPH = TextInputField.builder().fieldId(THIRD_PARTY_SUB_TYPE_FOR_PH).build();
            group.getFields().add(thirdPartySubTypeForPH);
        }
        thirdPartySubTypeForPH.setIsActive(true);
        thirdPartySubTypeForPH.incrementOrder();
        thirdPartySubTypeForPH.setLabel("Third party sub type for PH");
        thirdPartySubTypeForPH.setSourceSystem("From CLASS and converted");
        final var forcedValue =
                RulesUtils.getThirdPartyFromRole(policy.getHolders()).stream().findFirst().map(AbstractPerson::getSubType).orElse(null);
        thirdPartySubTypeForPH.setSelectedValue(forcedValue);
    }

    private void evaluateMrlTrustee(final Group group) {

        var mrlTrustee = (SelectInputField) ChecklistUtils.getFieldInGroup(group, MRL_TRUSTEE);
        if (mrlTrustee == null) {
            mrlTrustee = SelectInputField.builder().fieldId(MRL_TRUSTEE).build();
            group.getFields().add(mrlTrustee);
        }
        mrlTrustee.setIsActive(true);
        mrlTrustee.incrementOrder();
        mrlTrustee.setLabel("MRL Trustee in a participating juridiction");
        mrlTrustee.setEnabled(true);
        mrlTrustee.setMandatory(true);
        mrlTrustee.setDisplayIf(Boolean.toString(Optional.ofNullable(ChecklistUtils.getFieldInGroup(group, THIRD_PARTY_SUB_TYPE_FOR_PH))
                .map(Field::getSelectedValue).stream().anyMatch("Trust"::equals)));
        mrlTrustee.setOptions(referenceDataRepositoryService.getReferenceDataOptionsByDomain(YES_NO_DOMAIN));
    }

    private void evaluateTrust(final Group group, final Policy policy) {

        var trust = (SelectInputField) ChecklistUtils.getFieldInGroup(group, TRUST);
        if (trust == null) {
            trust = SelectInputField.builder().fieldId(TRUST).build();
            group.getFields().add(trust);
        }
        trust.setIsActive(true);
        trust.incrementOrder();
        trust.setLabel("Trust");
        trust.setSourceSystem("From CLASS");
        List<String> rolesAndLinks = new ArrayList<>(List.of("TRUST"));
        trust.setSelectedValue(isThirdPartyRoleAvailable(rolesAndLinks, policy) ? YES : NO);
        trust.setOptions(referenceDataRepositoryService.getReferenceDataOptionsByDomainAndSelectedValue(YES_NO_DOMAIN, trust.getSelectedValue()));
    }

    private void evaluateTrustCountry(final Group group, final Policy policy) {

        var trustCountry = (TextInputField) ChecklistUtils.getFieldInGroup(group, TRUST_COUNTRY);
        if (trustCountry == null) {
            trustCountry = TextInputField.builder().fieldId(TRUST_COUNTRY).build();
            group.getFields().add(trustCountry);
        }
        trustCountry.setIsActive(true);
        trustCountry.incrementOrder();
        trustCountry.setLabel("Trust residence country");
        trustCountry.setSourceSystem("Country of address for trusts from CLASS");
        computeThirdPartyRoleValueAndDisplay(trustCountry, policy, List.of("TRUST"));
    }

    private void evaluateTrustee(final Group group, final Policy policy) {

        var trustee = (SelectInputField) ChecklistUtils.getFieldInGroup(group, TRUSTEE);
        if (trustee == null) {
            trustee = SelectInputField.builder().fieldId(TRUSTEE).build();
            group.getFields().add(trustee);
        }
        trustee.setIsActive(true);
        trustee.incrementOrder();
        trustee.setLabel("Trustee");
        trustee.setSourceSystem("From CLASS");
        List<String> rolesAndLinks = new ArrayList<>(List.of("TRUSTEE"));
        trustee.setSelectedValue(isThirdPartyRoleAvailable(rolesAndLinks, policy) ? YES : NO);
        trustee.setOptions(
                referenceDataRepositoryService.getReferenceDataOptionsByDomainAndSelectedValue(YES_NO_DOMAIN, trustee.getSelectedValue()));

    }

    private void evaluateTrusteeCountry(final Group group, final Policy policy) {

        var trusteeCountry = (TextInputField) ChecklistUtils.getFieldInGroup(group, TRUSTEE_COUNTRY);
        if (trusteeCountry == null) {
            trusteeCountry = TextInputField.builder().fieldId(TRUSTEE_COUNTRY).build();
            group.getFields().add(trusteeCountry);
        }
        trusteeCountry.setIsActive(true);
        trusteeCountry.incrementOrder();
        trusteeCountry.setLabel("Trustee residence country");
        trusteeCountry.setSourceSystem("Country of address for trustees from CLASS compared to country rating");
        trusteeCountry.setDisplayIf(Boolean.toString(
                Optional.ofNullable(ChecklistUtils.getFieldInGroup(group, TRUSTEE)).map(Field::getSelectedValue).stream().anyMatch(YES::equals)));
        computeThirdPartyRoleValueAndDisplay(trusteeCountry, policy, List.of("TRUSTEE"));
    }

    private void evaluateSettlor(final Group group, final Policy policy) {

        var settlor = (SelectInputField) ChecklistUtils.getFieldInGroup(group, SETTLOR);
        if (settlor == null) {
            settlor = SelectInputField.builder().fieldId(SETTLOR).label("Settlor").enabled(false).mandatory(false).sourceSystem("From CLASS")
                    .build();
            group.getFields().add(settlor);
        }
        settlor.setIsActive(true);
        settlor.incrementOrder();
        List<String> rolesAndLinks = new ArrayList<>(List.of("SETTLOR"));
        settlor.setSelectedValue(isThirdPartyRoleAvailable(rolesAndLinks, policy) ? YES : NO);
        settlor.setOptions(
                referenceDataRepositoryService.getReferenceDataOptionsByDomainAndSelectedValue(YES_NO_DOMAIN, settlor.getSelectedValue()));
    }

    private void evaluateSettlorCountry(final Group group, final Policy policy) {

        var settlorCountry = (TextInputField) ChecklistUtils.getFieldInGroup(group, SETTLOR_COUNTRY);
        if (settlorCountry == null) {
            settlorCountry = TextInputField.builder().fieldId(SETTLOR_COUNTRY).build();
            group.getFields().add(settlorCountry);
        }
        settlorCountry.setIsActive(true);
        settlorCountry.incrementOrder();
        settlorCountry.setLabel("Settlor residence country");
        settlorCountry.setSourceSystem("Country of address for settlors from CLASS compared to country rating");
        settlorCountry.setDisplayIf(Boolean.toString(
                Optional.ofNullable(ChecklistUtils.getFieldInGroup(group, SETTLOR)).map(Field::getSelectedValue).stream().anyMatch(YES::equals)));
        computeThirdPartyRoleValueAndDisplay(settlorCountry, policy, List.of("SETTLOR"));
    }

    private void evaluateCessionHolder(final Group group, final Policy policy) {

        var cessionHolder = (SelectInputField) ChecklistUtils.getFieldInGroup(group, CESSION_HOLDER);
        if (cessionHolder == null) {
            cessionHolder = SelectInputField.builder().fieldId(CESSION_HOLDER).build();
            group.getFields().add(cessionHolder);
        }
        cessionHolder.setIsActive(true);
        cessionHolder.incrementOrder();
        cessionHolder.setLabel("Cession Holder");
        cessionHolder.setSourceSystem("From CLASS");
        List<String> rolesAndLinks = new ArrayList<>(List.of("CESSIONH"));
        cessionHolder.setSelectedValue(isThirdPartyRoleAvailable(rolesAndLinks, policy) ? YES : NO);
        cessionHolder.setOptions(
                referenceDataRepositoryService.getReferenceDataOptionsByDomainAndSelectedValue(YES_NO_DOMAIN, cessionHolder.getSelectedValue()));
    }

    private void evaluateCessionHolderCountry(final Group group, final Policy policy) {

        var cessionHolderCountry = (TextInputField) ChecklistUtils.getFieldInGroup(group, CESSION_HOLDER_COUNTRY);
        if (cessionHolderCountry == null) {
            cessionHolderCountry = TextInputField.builder().fieldId(CESSION_HOLDER_COUNTRY).build();
            group.getFields().add(cessionHolderCountry);
        }
        cessionHolderCountry.setIsActive(true);
        cessionHolderCountry.incrementOrder();
        cessionHolderCountry.setLabel("Cession Holder residence country");
        cessionHolderCountry.setSourceSystem("Country of address for cession holders from CLASS compared to country rating");
        computeThirdPartyRoleValueAndDisplay(cessionHolderCountry, policy, List.of("CESSIONH"));
    }

    private void evaluateProxy(final Group group, final Policy policy) {

        var proxy = (SelectInputField) ChecklistUtils.getFieldInGroup(group, PROXY);
        if (proxy == null) {
            proxy = SelectInputField.builder().fieldId(PROXY).build();
            group.getFields().add(proxy);
        }
        proxy.setIsActive(true);
        proxy.incrementOrder();
        proxy.setLabel("Proxy");
        proxy.setSourceSystem("From CLASS");
        List<String> rolesAndLinks = new ArrayList<>(List.of("PROXY"));
        proxy.setSelectedValue(isThirdPartyRoleAvailable(rolesAndLinks, policy) ? YES : NO);
        proxy.setOptions(referenceDataRepositoryService.getReferenceDataOptionsByDomainAndSelectedValue(YES_NO_DOMAIN, proxy.getSelectedValue()));
    }

    private void evaluateProxyCountry(final Group group, final Policy policy) {

        var proxyCountry = (TextInputField) ChecklistUtils.getFieldInGroup(group, PROXY_COUNTRY);
        if (proxyCountry == null) {
            proxyCountry = TextInputField.builder().fieldId(PROXY_COUNTRY).build();
            group.getFields().add(proxyCountry);
        }
        proxyCountry.setIsActive(true);
        proxyCountry.incrementOrder();
        proxyCountry.setLabel("Proxy residence country");
        proxyCountry.setSourceSystem("Country of address for proxies from CLASS compared to country rating");
        computeThirdPartyRoleValueAndDisplay(proxyCountry, policy, List.of("PROXY"));
    }

    private void evaluateLifeAssuredCountry(final Group group, final Policy policy) {

        var lifeAssuredCountry = (TextInputField) ChecklistUtils.getFieldInGroup(group, LA_RESIDENCE_COUNTRY);
        if (lifeAssuredCountry == null) {
            lifeAssuredCountry = TextInputField.builder().fieldId(LA_RESIDENCE_COUNTRY).build();
            group.getFields().add(lifeAssuredCountry);
        }
        lifeAssuredCountry.setIsActive(true);
        lifeAssuredCountry.incrementOrder();
        lifeAssuredCountry.setLabel("LA residence country");
        lifeAssuredCountry.setSourceSystem("Country of address for LA from CLASS");
        if (!CAPITALISED_POLICY.equals(policy.getPolicyType())) {
            computeThirdPartyRoleValueAndDisplay(lifeAssuredCountry, policy, List.of("LA"));
        } else {
            lifeAssuredCountry.setDisplayIf("false");
        }
    }

    private void evaluateSendingAddressCountry(final Group group, final Policy policy) {

        var sendingAddressCountry = (SelectInputField) ChecklistUtils.getFieldInGroup(group, SENDING_ADDRESS_COUNTRY);
        if (sendingAddressCountry == null) {
            sendingAddressCountry = SelectInputField.builder().fieldId(SENDING_ADDRESS_COUNTRY).build();
            group.getFields().add(sendingAddressCountry);
        }
        sendingAddressCountry.setIsActive(true);
        sendingAddressCountry.incrementOrder();
        sendingAddressCountry.setLabel("Sending Address Country");
        sendingAddressCountry.setSourceSystem("Country of sending address from CLASS");
        if (policy != null) {
            var isoCountryCode = Optional.ofNullable(policy.getHolders()).stream().flatMap(Collection::stream).findFirst().stream()
                    .map(Holder::getSendingAddress).filter(Objects::nonNull).map(Address::getCountry).filter(Objects::nonNull)
                    .map(Country::getIsoCountryCode).findAny().orElse(null);
            sendingAddressCountry.setSelectedValue(isoCountryCode);
            sendingAddressCountry.setOptions(referenceDataRepositoryService.getReferenceDataOptionsByDomainAndSelectedValue(COUNTRY_DOMAIN,
                    sendingAddressCountry.getSelectedValue()));
        }
    }

    private void evaluateBeneficiary(final Group group, final Policy policy) {

        var beneficiary = (SelectInputField) ChecklistUtils.getFieldInGroup(group, BENEFICIARY);
        if (beneficiary == null) {
            beneficiary = SelectInputField.builder().fieldId(BENEFICIARY).build();
            group.getFields().add(beneficiary);
        }
        beneficiary.setIsActive(true);
        beneficiary.incrementOrder();
        beneficiary.setLabel("Beneficiary");
        beneficiary.setSourceSystem("From CLASS");
        List<String> rolesAndLinks = new ArrayList<>(List.of("BEN"));
        beneficiary.setSelectedValue(isThirdPartyRoleAvailable(rolesAndLinks, policy) ? YES : NO);
        beneficiary.setOptions(
                referenceDataRepositoryService.getReferenceDataOptionsByDomainAndSelectedValue(YES_NO_DOMAIN, beneficiary.getSelectedValue()));
    }

    private void evaluateBeneficiaryCountry(final Group group, final Policy policy) {

        var beneficiaryCountry = (TextInputField) ChecklistUtils.getFieldInGroup(group, BENEFICIARY_COUNTRY);
        if (beneficiaryCountry == null) {
            beneficiaryCountry = TextInputField.builder().fieldId(BENEFICIARY_COUNTRY).build();
            group.getFields().add(beneficiaryCountry);
        }
        beneficiaryCountry.setIsActive(true);
        beneficiaryCountry.incrementOrder();
        beneficiaryCountry.setLabel("Beneficiary residence country");
        beneficiaryCountry.setSourceSystem("Country of address for beneficiaries from CLASS compared to country rating");
        computeThirdPartyRoleValueAndDisplay(beneficiaryCountry, policy, List.of("BEN"));
    }

    private void evaluateIrrevocableBeneficiary(final Group group, final Policy policy) {

        var irrevocableBeneficiary = (SelectInputField) ChecklistUtils.getFieldInGroup(group, IRREVOCABLE_BEN);
        if (irrevocableBeneficiary == null) {
            irrevocableBeneficiary = SelectInputField.builder().fieldId(IRREVOCABLE_BEN).build();
            group.getFields().add(irrevocableBeneficiary);
        }
        irrevocableBeneficiary.setIsActive(true);
        irrevocableBeneficiary.incrementOrder();
        irrevocableBeneficiary.setLabel("Irrevocable BEN");
        irrevocableBeneficiary.setSourceSystem("From CLASS");
        List<String> rolesAndLinks = new ArrayList<>(List.of("IB"));
        irrevocableBeneficiary.setSelectedValue(isThirdPartyRoleAvailable(rolesAndLinks, policy) ? YES : NO);
        irrevocableBeneficiary.setOptions(referenceDataRepositoryService.getReferenceDataOptionsByDomainAndSelectedValue(YES_NO_DOMAIN,
                irrevocableBeneficiary.getSelectedValue()));
    }

    private void evaluateIrrevocableBeneficiaryCountry(final Group group, final Policy policy) {

        var irrevocableBeneficiaryCountry = (TextInputField) ChecklistUtils.getFieldInGroup(group, IRREVOCABLE_BEN_COUNTRY);
        if (irrevocableBeneficiaryCountry == null) {
            irrevocableBeneficiaryCountry = TextInputField.builder().fieldId(IRREVOCABLE_BEN_COUNTRY).build();
            group.getFields().add(irrevocableBeneficiaryCountry);
        }
        irrevocableBeneficiaryCountry.setIsActive(true);
        irrevocableBeneficiaryCountry.incrementOrder();
        irrevocableBeneficiaryCountry.setLabel("Irrevocable BEN residence country");
        irrevocableBeneficiaryCountry.setSourceSystem("Country of address for irrevocable beneficiary from CLASS");
        computeThirdPartyRoleValueAndDisplay(irrevocableBeneficiaryCountry, policy, List.of("IB"));
    }

    private void evaluateLaDifferentToPh(final Group group, final Policy policy) {

        var laDifferentToPh = (SelectInputField) ChecklistUtils.getFieldInGroup(group, LA_DIFFERENT_TO_PH);
        if (laDifferentToPh == null) {
            laDifferentToPh = SelectInputField.builder().fieldId(LA_DIFFERENT_TO_PH).build();
            group.getFields().add(laDifferentToPh);
        }
        laDifferentToPh.setIsActive(true);
        laDifferentToPh.incrementOrder();
        laDifferentToPh.setLabel("LA different to PH");
        laDifferentToPh.setSourceSystem("From CLASS");

        final var forcedDisplayIf = CAPITALISED_POLICY.equals(policy.getPolicyType()) ? "false" : "true";
        final var holderDifferentLa = Optional.ofNullable(policy.getHolderAndLifeAssuredDifferent());

        laDifferentToPh.setSelectedValue(holderDifferentLa.map(aBoolean -> Boolean.TRUE.equals(aBoolean) ? YES : NO).orElse(null));
        laDifferentToPh.setDisplayIf(forcedDisplayIf);
        laDifferentToPh.setOptions(
                referenceDataRepositoryService.getReferenceDataOptionsByDomainAndSelectedValue(YES_NO_DOMAIN, laDifferentToPh.getSelectedValue()));
    }

    private void evaluateLaDifferentToBen(final Group group, final Policy policy) {

        var laDifferentToBen = (SelectInputField) ChecklistUtils.getFieldInGroup(group, LA_DIFFERENT_TO_BEN);
        if (laDifferentToBen == null) {
            laDifferentToBen = SelectInputField.builder().fieldId(LA_DIFFERENT_TO_BEN).build();
            group.getFields().add(laDifferentToBen);
        }
        laDifferentToBen.setIsActive(true);
        laDifferentToBen.incrementOrder();
        laDifferentToBen.setLabel("LA different to BEN");
        laDifferentToBen.setSourceSystem("From CLASS");

        final var forcedDisplayIf = CAPITALISED_POLICY.equals(policy.getPolicyType()) ? "false" : "true";
        final var benDifferentLa = Optional.ofNullable(policy.getBeneficiaryAndLifeAssuredDifferent());

        laDifferentToBen.setSelectedValue(benDifferentLa.map(aBoolean -> Boolean.TRUE.equals(aBoolean) ? YES : NO).orElse(null));
        laDifferentToBen.setDisplayIf(forcedDisplayIf);
        laDifferentToBen.setOptions(referenceDataRepositoryService.getReferenceDataOptionsByDomainAndSelectedValue(YES_NO_DOMAIN,
                laDifferentToBen.getSelectedValue()));

    }

    private void evaluatePhDifferentToEbo(final Group group, final Policy policy) {

        var phDifferentToEbo = (SelectInputField) ChecklistUtils.getFieldInGroup(group, PH_DIFFERENT_TO_EBO);
        if (phDifferentToEbo == null) {
            phDifferentToEbo = SelectInputField.builder().fieldId(PH_DIFFERENT_TO_EBO).build();
            group.getFields().add(phDifferentToEbo);
        }
        phDifferentToEbo.setIsActive(true);
        phDifferentToEbo.incrementOrder();
        phDifferentToEbo.setLabel("PH different to EBO");
        phDifferentToEbo.setSourceSystem("From CLASS");
        if (policy != null) {
            phDifferentToEbo.setSelectedValue(
                    Optional.ofNullable(policy.getHolderAndEBODifferent()).map(aBoolean -> Boolean.TRUE.equals(aBoolean) ? YES : NO).orElse(null));
            phDifferentToEbo.setOptions(referenceDataRepositoryService.getReferenceDataOptionsByDomainAndSelectedValue(YES_NO_DOMAIN,
                    phDifferentToEbo.getSelectedValue()));
        }
    }

    private void evaluateEboCountry(final Group group, final Policy policy) {

        var eboCountry = (TextInputField) ChecklistUtils.getFieldInGroup(group, EBO_COUNTRY);
        if (eboCountry == null) {
            eboCountry = TextInputField.builder().fieldId(EBO_COUNTRY).build();
            group.getFields().add(eboCountry);
        }
        eboCountry.setIsActive(true);
        eboCountry.incrementOrder();
        eboCountry.setLabel("EBO residence country");
        eboCountry.setSourceSystem("Country of address for EBO from CLASS compared to country rating");
        if (policy.getHolderAndEBODifferent()) {
            computeThirdPartyRoleValueAndDisplay(eboCountry, policy, List.of("EBO"));
        } else {
            eboCountry.setDisplayIf("false");
        }
    }

    private void evaluateNewUsIndicia(final Group group) {

        var newUsIndicia = (SelectInputField) ChecklistUtils.getFieldInGroup(group, NEW_US_INDICIA);
        if (newUsIndicia == null) {
            newUsIndicia = SelectInputField.builder().fieldId(NEW_US_INDICIA).build();
            group.getFields().add(newUsIndicia);
        }
        newUsIndicia.setIsActive(true);
        newUsIndicia.incrementOrder();
        newUsIndicia.setLabel("New US indicia detected");
        newUsIndicia.setEnabled(true);
        newUsIndicia.setMandatory(true);
        newUsIndicia.setOptions(referenceDataRepositoryService.getReferenceDataOptionsByDomain(YES_NO_DOMAIN));
    }

    private void evaluateRequestFormReceived(final Group group) {

        var requestFormReceived = (SelectInputField) ChecklistUtils.getFieldInGroup(group, REQUEST_FORM_RECEIVED);
        if (requestFormReceived == null) {
            requestFormReceived = SelectInputField.builder().fieldId(REQUEST_FORM_RECEIVED).build();
            group.getFields().add(requestFormReceived);
            requestFormReceived.setSelectedValue(null);
        }
        requestFormReceived.setIsActive(true);
        requestFormReceived.incrementOrder();
        requestFormReceived.setLabel("Addition request form received?");
        requestFormReceived.setMandatory(true);
        requestFormReceived.setEnabled(true);
        requestFormReceived.setOptions(referenceDataRepositoryService.getReferenceDataOptionsByDomain(YES_NO_NA_NEW_BUSINESS_VALUES_DOMAIN));
    }

    private void evaluateFormSigner(final Group group) {

        var formSigner = (SelectInputField) ChecklistUtils.getFieldInGroup(group, FORM_SIGNER);
        if (formSigner == null) {
            formSigner = SelectInputField.builder().fieldId(FORM_SIGNER).build();
            group.getFields().add(formSigner);
        }
        formSigner.setIsActive(true);
        formSigner.incrementOrder();
        formSigner.setLabel("Application form signer");
        formSigner.setEnabled(true);
        formSigner.setMandatory(true);
        formSigner.setOptions(referenceDataRepositoryService.getReferenceDataOptionsByDomain(FORM_SIGNER_DOMAIN));
    }

    private void evaluateTpBlock(final Group group, final Policy policy) {

        var tpBlock = (SelectInputField) ChecklistUtils.getFieldInGroup(group, TP_BLOCK);
        if (tpBlock == null) {
            tpBlock = SelectInputField.builder().fieldId(TP_BLOCK).build();
            group.getFields().add(tpBlock);
        }
        tpBlock.setIsActive(true);
        tpBlock.incrementOrder();
        tpBlock.setLabel("Transaction block in CLASS for compliance");
        if (policy != null) {
            final var forceValue = policy.getThirdParties().stream().map(AbstractPerson::getPersistedBlocks).filter(Objects::nonNull)
                    .flatMap(Collection::stream).filter(persistedBlock -> "STR_WATCHER".equals(persistedBlock.getBlockType().getLabel()))
                    .map(PersistedBlock::getFiuReportingStatus).map(FIUReportingStatus::getLabel).anyMatch(allowedReportingStatus::contains) ? YES
                            : NO;
            tpBlock.setSelectedValue(forceValue);
            tpBlock.setOptions(
                    referenceDataRepositoryService.getReferenceDataOptionsByDomainAndSelectedValue(YES_NO_DOMAIN, tpBlock.getSelectedValue()));
        }
    }
}
