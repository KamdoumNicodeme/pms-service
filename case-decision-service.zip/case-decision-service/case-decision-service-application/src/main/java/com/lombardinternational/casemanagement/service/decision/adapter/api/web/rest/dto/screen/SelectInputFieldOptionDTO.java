package com.lombardinternational.casemanagement.service.decision.adapter.api.web.rest.dto.screen;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class SelectInputFieldOptionDTO {

    private String key;
    private String value;
}
