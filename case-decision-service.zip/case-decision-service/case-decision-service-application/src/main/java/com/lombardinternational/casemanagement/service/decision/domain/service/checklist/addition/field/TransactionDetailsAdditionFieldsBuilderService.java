package com.lombardinternational.casemanagement.service.decision.domain.service.checklist.addition.field;

import com.lombardinternational.casemanagement.service.decision.domain.model.policy.Policy;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.*;
import com.lombardinternational.casemanagement.service.decision.domain.model.transaction.BusinessTransaction;
import com.lombardinternational.casemanagement.service.decision.domain.model.transaction.MoneyInPayment;
import com.lombardinternational.casemanagement.service.decision.domain.model.transaction.PaymentDetails;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.checklist.FieldBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.spi.repository.ReferenceDataRepositoryService;
import com.lombardinternational.casemanagement.service.decision.domain.utils.ChecklistUtils;
import com.lombardinternational.casemanagement.service.decision.domain.utils.RulesUtils;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

import static com.lombardinternational.casemanagement.service.decision.domain.service.checklist.common.field.CommonTransactionDetailsFieldsBuilderService.*;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ChecklistFieldConstants.*;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ReferenceConstants.YES_NO_DOMAIN;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.RulesConstants.INT_RF_016;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.RulesConstants.YES;

@Service
@AllArgsConstructor
public class TransactionDetailsAdditionFieldsBuilderService implements FieldBuilderService {

    private final ReferenceDataRepositoryService referenceDataRepositoryService;

    @Override
    public void buildField(WebForm webForm, ScreenDescription screenDescription, Group group, Policy policy, BusinessTransaction transaction,
            Map<String,List<String>> overallCaseRisk) {

        Field.resetFieldId();
        evaluatePremiumDifferFromExpected(group);
        evaluateFundOriginSameAsDisclosed(group);
        evaluatePremiumWithAssets(webForm, group, referenceDataRepositoryService);
        evaluatePremiumWithUnqAssets(webForm, group, referenceDataRepositoryService);
        evaluateInvestedInIlf(group, referenceDataRepositoryService);
        evaluateExistingIlf(group);
        evaluateIlfMnemonic(group);
        evaluatePaymentThirdParty(group, transaction, overallCaseRisk, referenceDataRepositoryService);
        evaluatePayerCorporateEntity(group);
        evaluatePayerCountryDifferPh(group, transaction);
        evaluateEvidenceEntityKnown(group, transaction);
        evaluateSupportingDocumentation(group);
        evaluateNegativeFindingPayers(group, screenDescription);
        evaluatePayerInSanctionList(group, transaction);
        evaluateRationalForInvestment(webForm, group);
        List<MoneyInPayment> payments = evaluateNumberOfOriginatingAccounts(group, transaction);
        for (int i = 1; i <= payments.size(); i++) {
            PaymentDetails details = payments.get(i - 1).getPaymentDetails();
            if (details == null || details.getPayerID() == null || details.getPayerBankName() == null || details.getPayerBankCountry() == null) {
                if (payments.get(i - 1).getExpectedPaymentDetails() != null) {
                    details = payments.get(i - 1).getExpectedPaymentDetails();
                } else {
                    details = new PaymentDetails();
                }
            }
            evaluateHolderOfOriginatingAccounts(group, details, i);
            evaluateCountryOfOriginatingAccounts(group, details, i, referenceDataRepositoryService);
            evaluateBankOfOriginatingAccounts(group, details, i);
        }

        evaluateCountryOfOriginatingAccountsRisk(group, transaction, payments.size(), overallCaseRisk);
        evaluateFundCountryDifferTaxCountry(group);
        evaluateEconomicJustification(group);
        evaluateEvidenceBankAccountKnown(group);
        evaluatePhRefuseToProvideEvidence(group);
    }

    private void evaluatePremiumDifferFromExpected(final Group group) {

        var premiumDifferFromExpected = (SelectInputField) ChecklistUtils.getFieldInGroup(group, PREMIUM_DIFFER_FROM_EXPECTED);
        if (premiumDifferFromExpected == null) {
            premiumDifferFromExpected = SelectInputField.builder().fieldId(PREMIUM_DIFFER_FROM_EXPECTED).build();
            group.getFields().add(premiumDifferFromExpected);
            premiumDifferFromExpected.setSelectedValue(null);
        }
        premiumDifferFromExpected.setIsActive(true);
        premiumDifferFromExpected.incrementOrder();
        premiumDifferFromExpected.setLabel("Is the premium received different than expected one (higher amount or different payment details)?");
        premiumDifferFromExpected.setMandatory(true);
        premiumDifferFromExpected.setEnabled(true);
        premiumDifferFromExpected.setOptions(referenceDataRepositoryService.getReferenceDataOptionsByDomain(YES_NO_DOMAIN));
    }

    private void evaluateFundOriginSameAsDisclosed(final Group group) {

        var fundOriginSameAsDisclosed = (SelectInputField) ChecklistUtils.getFieldInGroup(group, FUND_ORIGIN_SAME_AS_DISCLOSED);
        if (fundOriginSameAsDisclosed == null) {
            fundOriginSameAsDisclosed = SelectInputField.builder().fieldId(FUND_ORIGIN_SAME_AS_DISCLOSED).build();
            group.getFields().add(fundOriginSameAsDisclosed);
            fundOriginSameAsDisclosed.setSelectedValue(null);
        }
        fundOriginSameAsDisclosed.setIsActive(true);
        fundOriginSameAsDisclosed.incrementOrder();
        fundOriginSameAsDisclosed
                .setLabel("Is the origin of the funds or additional funds and/or the payment details the same as disclosed in the KYC form?");
        fundOriginSameAsDisclosed.setMandatory(true);
        fundOriginSameAsDisclosed.setEnabled(true);
        fundOriginSameAsDisclosed.setOptions(referenceDataRepositoryService.getReferenceDataOptionsByDomain(YES_NO_DOMAIN));
        fundOriginSameAsDisclosed.setDisplayIf("#" + PREMIUM_DIFFER_FROM_EXPECTED + "# == \"YES\"");
    }

    private void evaluateExistingIlf(final Group group) {

        var existingIlf = (SelectInputField) ChecklistUtils.getFieldInGroup(group, EXISTING_ILF);
        if (existingIlf == null) {
            existingIlf = SelectInputField.builder().fieldId(EXISTING_ILF).build();
            group.getFields().add(existingIlf);
        }
        existingIlf.setIsActive(true);
        existingIlf.incrementOrder();
        existingIlf.setLabel("Is it an existing ILF?");
        existingIlf.setEnabled(true);
        existingIlf.setOptions(referenceDataRepositoryService.getReferenceDataOptionsByDomain(YES_NO_DOMAIN));
        existingIlf.setMandatory(true);
        existingIlf.setDisplayIf("#" + INVESTED_IN_ILF + "# == \"YES\"");
    }

    private void evaluateIlfMnemonic(final Group group) {

        var ilfMnemonic = (TextInputField) ChecklistUtils.getFieldInGroup(group, ILF_MNEMONIC);
        if (ilfMnemonic == null) {
            ilfMnemonic = TextInputField.builder().fieldId(ILF_MNEMONIC).build();
            group.getFields().add(ilfMnemonic);
        }
        ilfMnemonic.setIsActive(true);
        ilfMnemonic.incrementOrder();
        ilfMnemonic.setLabel("ILF Mnemonic");
        ilfMnemonic.setEnabled(true);
        ilfMnemonic.setMandatory(true);
        ilfMnemonic.setDisplayIf("#" + EXISTING_ILF + "# == \"YES\"");
    }

    private void evaluatePayerCorporateEntity(final Group group) {

        var payerCorporateEntity = (SelectInputField) ChecklistUtils.getFieldInGroup(group, PAYER_CORPORATE_ENTITY_SHR);
        if (payerCorporateEntity == null) {
            payerCorporateEntity = SelectInputField.builder().fieldId(PAYER_CORPORATE_ENTITY_SHR).build();
            group.getFields().add(payerCorporateEntity);
        }

        payerCorporateEntity.setIsActive(true);
        payerCorporateEntity.incrementOrder();
        payerCorporateEntity.setLabel("Is the payer a Corporate entity where the PH/EBO is the sole shareholder?");
        payerCorporateEntity.setMandatory(true);
        payerCorporateEntity.setEnabled(true);
        payerCorporateEntity.setOptions(referenceDataRepositoryService.getReferenceDataOptionsByDomain(YES_NO_DOMAIN));
        payerCorporateEntity.setDisplayIf("#" + PAYMENT_THIRD_PARTY + "# == \"YES\"");
    }

    private void evaluatePayerCountryDifferPh(final Group group, final BusinessTransaction transaction) {

        var payerCountryDifferPh = (SelectInputField) ChecklistUtils.getFieldInGroup(group, PAYER_TAX_COUNTRY_DIFFER_PH_EBO);

        if (payerCountryDifferPh == null) {
            payerCountryDifferPh = SelectInputField.builder().fieldId(PAYER_TAX_COUNTRY_DIFFER_PH_EBO).build();
            group.getFields().add(payerCountryDifferPh);
            payerCountryDifferPh.setSelectedValue(null);
        }

        payerCountryDifferPh.setIsActive(true);
        payerCountryDifferPh.incrementOrder();
        payerCountryDifferPh.setLabel(
                "Is the 3rd party payer a legal entity located in a country which is not the tax country of residence or place of regular economic or professional activities/interests of the PH/EBO?");
        payerCountryDifferPh.setMandatory(true);
        payerCountryDifferPh.setEnabled(true);
        payerCountryDifferPh.setOptions(referenceDataRepositoryService.getReferenceDataOptionsByDomain(YES_NO_DOMAIN));
        payerCountryDifferPh.setDisplayIf(String.valueOf(RulesUtils.checkPaymentOriginatorPTCORSO(transaction)));
    }

    private void evaluateEvidenceEntityKnown(final Group group, final BusinessTransaction transaction) {

        var evidenceEntityKnown = (SelectInputField) ChecklistUtils.getFieldInGroup(group, EVIDENCE_ENTITY_KNOWN);
        if (evidenceEntityKnown == null) {
            evidenceEntityKnown = SelectInputField.builder().fieldId(EVIDENCE_ENTITY_KNOWN).build();
            group.getFields().add(evidenceEntityKnown);
        }
        var displayIf = "false";
        var anyPTCORSO = RulesUtils.checkPaymentOriginatorPTCORSO(transaction);
        if (anyPTCORSO) {
            displayIf = "#" + PAYER_TAX_COUNTRY_DIFFER_PH_EBO + "# == \"YES\"";
        }

        evidenceEntityKnown.setIsActive(true);
        evidenceEntityKnown.incrementOrder();
        evidenceEntityKnown.setLabel(
                "Did you collect supporting evidence that the legal entity is known by the tax authorities of the country of residence of the PH/EBO or could the legal entity  demonstrate that its establishment complies with the legal provisions of the country of residence of the PH/EBO?");
        evidenceEntityKnown.setMandatory(true);
        evidenceEntityKnown.setEnabled(true);
        evidenceEntityKnown.setDisplayIf(displayIf);
        evidenceEntityKnown.setOptions(referenceDataRepositoryService.getReferenceDataOptionsByDomain(YES_NO_DOMAIN));

    }

    private void evaluateSupportingDocumentation(final Group group) {

        var supportingDocumentation = (SelectInputField) ChecklistUtils.getFieldInGroup(group, SUPPORTING_DOCUMENTATION);
        if (supportingDocumentation == null) {
            supportingDocumentation = SelectInputField.builder().fieldId(SUPPORTING_DOCUMENTATION).build();
            group.getFields().add(supportingDocumentation);
            supportingDocumentation.setSelectedValue(null);
        }
        supportingDocumentation.setIsActive(true);
        supportingDocumentation.incrementOrder();
        supportingDocumentation.setLabel(
                "In case of any additional documentation collected to corroborate the tax conformity of the funds (e.g. annual income tax return, the regularisation documentation or memo from the tax lawyer of the PH/EBO), is this  supporting documentation issued by a person who is close to the PH/EBO and leaving room for doubt due to the potential conflict of interest?");
        supportingDocumentation.setMandatory(true);
        supportingDocumentation.setEnabled(true);
        supportingDocumentation.setOptions(referenceDataRepositoryService.getReferenceDataOptionsByDomain(YES_NO_DOMAIN));
    }

    private void evaluateNegativeFindingPayers(final Group group, final ScreenDescription screenDescription) {

        var negativeFindingPayers = (SelectInputField) ChecklistUtils.getFieldInGroup(group, NEGATIVE_FINDING_PAYERS);
        if (negativeFindingPayers == null) {
            negativeFindingPayers = SelectInputField.builder().fieldId(NEGATIVE_FINDING_PAYERS).build();
            group.getFields().add(negativeFindingPayers);
        }

        String paymentToThirdParty = ChecklistUtils.getFieldById(screenDescription, PAYMENT_THIRD_PARTY).map(Field::getSelectedValue).orElse("0");
        String displayForcedValue = YES.equals(paymentToThirdParty) ? "true" : "false";

        negativeFindingPayers.setIsActive(true);
        negativeFindingPayers.incrementOrder();
        negativeFindingPayers.setLabel("Negative press finding / Worldcheck match (on any of the payers)?");
        negativeFindingPayers.setEnabled(true);
        negativeFindingPayers.setOptions(referenceDataRepositoryService.getReferenceDataOptionsByDomain(YES_NO_DOMAIN));
        negativeFindingPayers.setMandatory(true);
        negativeFindingPayers.setDisplayIf(displayForcedValue);
    }

    private void evaluatePayerInSanctionList(final Group group, final BusinessTransaction transaction) {

        var payerInSanctionList = (SelectInputField) ChecklistUtils.getFieldInGroup(group, PAYER_IN_SANCTION_LIST);
        if (payerInSanctionList == null) {
            payerInSanctionList = SelectInputField.builder().fieldId(PAYER_IN_SANCTION_LIST).build();
            group.getFields().add(payerInSanctionList);
        }
        String paymentToThirdParty = RulesUtils.getRiskFactorData(transaction, INT_RF_016);
        String displayIf = !paymentToThirdParty.contains("N/A") && !paymentToThirdParty.contains("Policy holder") ? "true" : "false";

        payerInSanctionList.setIsActive(true);
        payerInSanctionList.incrementOrder();
        payerInSanctionList.setLabel("Is one of the payers designated on a sanctions list?");
        payerInSanctionList.setEnabled(true);
        payerInSanctionList.setMandatory(true);
        payerInSanctionList.setOptions(referenceDataRepositoryService.getReferenceDataOptionsByDomain(YES_NO_DOMAIN));
        payerInSanctionList.setDisplayIf(displayIf);
    }

    private void evaluateFundCountryDifferTaxCountry(final Group group) {

        var fundCountryDifferTaxCountry = (SelectInputField) ChecklistUtils.getFieldInGroup(group, FUND_COUNTRY_DIFFER_TAX_COUNTRY);
        if (fundCountryDifferTaxCountry == null) {
            fundCountryDifferTaxCountry = SelectInputField.builder().fieldId(FUND_COUNTRY_DIFFER_TAX_COUNTRY).build();
            group.getFields().add(fundCountryDifferTaxCountry);
            fundCountryDifferTaxCountry.setSelectedValue(null);
        }
        fundCountryDifferTaxCountry.setIsActive(true);
        fundCountryDifferTaxCountry.incrementOrder();
        fundCountryDifferTaxCountry.setLabel(
                "Are the additional funds paid from a bank account located in a country which is not the tax country of residence of the PH(s)/EBO(s)?");
        fundCountryDifferTaxCountry.setMandatory(true);
        fundCountryDifferTaxCountry.setEnabled(true);
        fundCountryDifferTaxCountry.setOptions(referenceDataRepositoryService.getReferenceDataOptionsByDomain(YES_NO_DOMAIN));
    }

    private void evaluateEconomicJustification(final Group group) {

        var economicJustification = (SelectInputField) ChecklistUtils.getFieldInGroup(group, ECONOMIC_JUSTIFICATION);
        if (economicJustification == null) {
            economicJustification = SelectInputField.builder().fieldId(ECONOMIC_JUSTIFICATION).build();
            group.getFields().add(economicJustification);
            economicJustification.setSelectedValue(null);
        }
        economicJustification.setIsActive(true);
        economicJustification.incrementOrder();
        economicJustification.setLabel(
                "Is there an obvious economic justification (e.g. the PH/EBO lived in that jurisdiction, worked and/or works in that jurisdiction, funds were generated in that jurisdiction)?");
        economicJustification.setMandatory(true);
        economicJustification.setEnabled(true);
        economicJustification.setOptions(referenceDataRepositoryService.getReferenceDataOptionsByDomain(YES_NO_DOMAIN));
        economicJustification.setDisplayIf("#" + FUND_COUNTRY_DIFFER_TAX_COUNTRY + "# == \"YES\"");
    }

    private void evaluateEvidenceBankAccountKnown(final Group group) {

        var evidenceBankAccountKnown = (SelectInputField) ChecklistUtils.getFieldInGroup(group, EVIDENCE_BANK_ACCOUNT_KNOWN);
        if (evidenceBankAccountKnown == null) {
            evidenceBankAccountKnown = SelectInputField.builder().fieldId(EVIDENCE_BANK_ACCOUNT_KNOWN).build();
            group.getFields().add(evidenceBankAccountKnown);
            evidenceBankAccountKnown.setSelectedValue(null);
        }
        evidenceBankAccountKnown.setIsActive(true);
        evidenceBankAccountKnown.incrementOrder();
        evidenceBankAccountKnown.setLabel(
                "Did you collect supporting evidence that the bank account is  known by the tax authorities of the country of residence of the PH/EBO or that the funds have been tax declared (e.g. annual income tax return, regularisation documentation)?");
        evidenceBankAccountKnown.setMandatory(true);
        evidenceBankAccountKnown.setEnabled(true);
        evidenceBankAccountKnown.setOptions(referenceDataRepositoryService.getReferenceDataOptionsByDomain(YES_NO_DOMAIN));
        evidenceBankAccountKnown
                .setDisplayIf("#" + FUND_COUNTRY_DIFFER_TAX_COUNTRY + "# == \"YES\" && #" + ECONOMIC_JUSTIFICATION + "# == \"NO\"");
    }

    private void evaluatePhRefuseToProvideEvidence(final Group group) {

        var phRefuseToProvideEvidence = (SelectInputField) ChecklistUtils.getFieldInGroup(group, PH_REFUSE_TO_PROVIDE_EVIDENCE);
        if (phRefuseToProvideEvidence == null) {
            phRefuseToProvideEvidence = SelectInputField.builder().fieldId(PH_REFUSE_TO_PROVIDE_EVIDENCE).build();
            group.getFields().add(phRefuseToProvideEvidence);
            phRefuseToProvideEvidence.setSelectedValue(null);
        }
        phRefuseToProvideEvidence.setIsActive(true);
        phRefuseToProvideEvidence.incrementOrder();
        phRefuseToProvideEvidence.setLabel("Did the PH/EBO refuse to provide this additional supporting documentation?");
        phRefuseToProvideEvidence.setMandatory(true);
        phRefuseToProvideEvidence.setEnabled(true);
        phRefuseToProvideEvidence.setOptions(referenceDataRepositoryService.getReferenceDataOptionsByDomain(YES_NO_DOMAIN));
        phRefuseToProvideEvidence.setDisplayIf("#" + FUND_COUNTRY_DIFFER_TAX_COUNTRY + "# == \"YES\" && #" + ECONOMIC_JUSTIFICATION
                + "# == \"NO\" && #" + EVIDENCE_BANK_ACCOUNT_KNOWN + "# == \"NO\"");
    }

}
