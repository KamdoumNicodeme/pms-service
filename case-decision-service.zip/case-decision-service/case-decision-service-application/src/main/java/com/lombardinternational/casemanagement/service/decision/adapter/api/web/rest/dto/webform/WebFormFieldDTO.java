package com.lombardinternational.casemanagement.service.decision.adapter.api.web.rest.dto.webform;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder
@NoArgsConstructor
public abstract class WebFormFieldDTO {

    // TODO : Add the fields needed to generate rules
    private String fieldId;
    private String label;
}
