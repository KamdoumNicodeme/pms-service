package com.lombardinternational.casemanagement.service.decision.adapter.api.web.rest.dto.webform;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class UserDetailDTO {

    private String userId;
    private String login;
    private String firstName;
    private String lastName;
    private String userRole;
    private String clientNumber;
    private Boolean authorizedSigntory;
    private String phoneNumber;
    private String email;
}
