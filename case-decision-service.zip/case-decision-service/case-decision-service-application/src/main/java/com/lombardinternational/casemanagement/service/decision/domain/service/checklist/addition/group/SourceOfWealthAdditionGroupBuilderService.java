package com.lombardinternational.casemanagement.service.decision.domain.service.checklist.addition.group;

import com.lombardinternational.casemanagement.service.decision.domain.model.policy.Policy;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Group;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Tab;
import com.lombardinternational.casemanagement.service.decision.domain.model.transaction.BusinessTransaction;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.checklist.GroupBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.checklist.addition.field.SourceOfWealthFieldsBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.utils.PolicyUtils;
import com.lombardinternational.casemanagement.service.decision.domain.utils.RulesUtils;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.stream.IntStream;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ChecklistFieldConstants.SOURCE_OF_WEALTH_GROUP;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ChecklistFieldConstants.TWENTY_PERCENT_INCOME;

@Service
@AllArgsConstructor
public class SourceOfWealthAdditionGroupBuilderService implements GroupBuilderService {

    private final SourceOfWealthFieldsBuilderService sourceOfWealthFieldsBuilderService;

    public void buildGroup(final WebForm webForm, final ScreenDescription screenDescription, final Tab parentTab, final Policy policy,
            final BusinessTransaction business, final Map<String,List<String>> overallCaseRisk) {

        final var abstractPersons = PolicyUtils.getThirdPartiesByRole(policy, Collections.singletonList("EBO"));

        IntStream.range(0, abstractPersons.size()).forEach(i -> {
            final var person = abstractPersons.get(i);
            final var clientNumber = person.getThirdPartyId();

            //Was change since in brain even if getSplitPercentage() is null we still compute the value
            final var sowList = PolicyUtils.getSourceOfWealthByPerson(person).stream()
                    .filter(sow -> sow.getOriginOfPremium() != null && sow.getOriginOfPremium())
                    .filter(sow -> sow.getDescription() != null && sow.getDescription().matches("inheri_don|divorce|gift")).toList();

            IntStream.range(0, sowList.size())
                    .filter(j -> sowList.get(j).getOriginOfPremium() != null && sowList.get(j).getOriginOfPremium()) // Filter
                    // based
                    // on
                    // `getOriginOfPremium`
                    .forEach(j -> {
                        var sourceOfWealth = RulesUtils.getGroupInTab(parentTab, SOURCE_OF_WEALTH_GROUP + "_" + (i + 1) + "_" + (j + 1));

                        if (sourceOfWealth == null) {
                            sourceOfWealth = Group.builder().groupId(SOURCE_OF_WEALTH_GROUP + "_" + (i + 1) + "_" + (j + 1)).build();
                            parentTab.getGroups().add(sourceOfWealth);
                        }
                        sourceOfWealth.setIsActive(true);
                        sourceOfWealth.incrementOrder();
                        sourceOfWealth.setTitle(
                                "Due diligence - Originator identification (Inheritance / Gift / Donation / Divorce) - " + clientNumber);
                        sourceOfWealth.setDisplayIf("#" + TWENTY_PERCENT_INCOME + "_" + (i + 1) + "# == \"YES\"");

                        var position = "_" + (i + 1) + "_" + (j + 1);
                        sourceOfWealthFieldsBuilderService.buildField(sourceOfWealth, sowList.get(j), position);
                    });
        });
    }
}
