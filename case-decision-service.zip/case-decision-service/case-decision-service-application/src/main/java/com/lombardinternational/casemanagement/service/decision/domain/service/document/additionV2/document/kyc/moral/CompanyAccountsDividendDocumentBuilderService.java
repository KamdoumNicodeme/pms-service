package com.lombardinternational.casemanagement.service.decision.domain.service.document.additionV2.document.kyc.moral;

import java.util.List;

import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Service;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.DocumentDefinition;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebFormGroup;
import com.lombardinternational.casemanagement.service.decision.domain.service.document.additionV2.document.kyc.DocumentUtilsBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.utils.WebformUtils;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.DocumentConstants.COMPANY_ACCOUNTS_DIVIDEND_FORM_DESCRIPTION;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.DocumentConstants.COMPANY_ACCOUNTS_DIVIDEND_FORM_I18N_DESCRIPTION;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.DocumentConstants.EBO_I18N_DOCUMENT_RELATED_TO;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.DocumentConstants.KYC_DOCUMENT_CMS_DOC_TYPE;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.DocumentConstants.KYC_DOCUMENT_DOC_TYPE;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.RulesConstants.DIVIDEND;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.RulesConstants.TRUE;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.WebFormFieldConstants.DETAILS_WF;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.WebFormFieldConstants.EBO_ID_WF;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.WebFormFieldConstants.HAS_OTHER_WEALTH_WF;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.WebFormFieldConstants.OTHER_WEALTH_WF;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.WebFormFieldConstants.POLICY_NUMBER_WF;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.WebFormFieldConstants.WEALTH_ENTITY_WF;

@Service
public class CompanyAccountsDividendDocumentBuilderService extends DocumentUtilsBuilderService {

    @Override
    public void buildDocument(final WebForm webForm, final ScreenDescription screenDescription, String transactionNumber,
        List<DocumentDefinition> documents) {

        for (WebFormGroup group : getEboKycs(webForm, true)) {
            var wealthEntity = WebformUtils.getFirstWebFormGroupById(webForm, WEALTH_ENTITY_WF);
            if (wealthEntity != null && CollectionUtils.isNotEmpty(wealthEntity.getGroups())) {
                var otherWealth = WebformUtils.getFirstWebFormGroupById(webForm, OTHER_WEALTH_WF);
                if (otherWealth != null && CollectionUtils.isNotEmpty(otherWealth.getGroups())) {
                    var hasOther = WebformUtils.getWebFormFieldValueById(otherWealth, HAS_OTHER_WEALTH_WF);
                    var details = WebformUtils.getWebFormFieldValueById(otherWealth, DETAILS_WF);
                    if (TRUE.equalsIgnoreCase(hasOther) && DIVIDEND.equals(details)) {
                        var eboId = WebformUtils.getWebFormFieldValueById(group, EBO_ID_WF);
                        var relatedTo = "Ebo " + eboId;
                        var relatedToPolicy = WebformUtils.getWebFormFieldValueById(webForm, POLICY_NUMBER_WF);
                        buildDocumentDefinition(relatedTo, relatedToPolicy, eboId, eboId, documents);
                    }
                }
            }
        }

    }

    @Override
    protected String getDocumentType() {

        return KYC_DOCUMENT_DOC_TYPE;
    }

    @Override
    protected String getCmsDocumentType() {

        return KYC_DOCUMENT_CMS_DOC_TYPE;
    }

    @Override
    protected String getDescription() {

        return COMPANY_ACCOUNTS_DIVIDEND_FORM_DESCRIPTION;
    }

    @Override
    protected String getI18NDescription() {

        return COMPANY_ACCOUNTS_DIVIDEND_FORM_I18N_DESCRIPTION;
    }

    @Override
    protected String getI18NDocumentRelatedTo() {

        return EBO_I18N_DOCUMENT_RELATED_TO;
    }

    @Override
    protected boolean getDocumentVisibleOnConnect() {

        return true;
    }

    @Override
    protected boolean getDocumentRequired() {

        return true;
    }
}
