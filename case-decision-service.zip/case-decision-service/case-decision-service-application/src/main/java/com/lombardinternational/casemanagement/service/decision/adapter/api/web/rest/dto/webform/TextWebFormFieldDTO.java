package com.lombardinternational.casemanagement.service.decision.adapter.api.web.rest.dto.webform;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder
@NoArgsConstructor
@EqualsAndHashCode(callSuper = true)
public class TextWebFormFieldDTO extends WebFormFieldDTO {

    private String value;
}
