package com.lombardinternational.casemanagement.service.decision.domain.service.checklist.addition.field;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.IntStream;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import com.lombardinternational.casemanagement.service.decision.domain.model.policy.AbstractPerson;
import com.lombardinternational.casemanagement.service.decision.domain.model.policy.Amount;
import com.lombardinternational.casemanagement.service.decision.domain.model.policy.EconomicBeneficiary;
import com.lombardinternational.casemanagement.service.decision.domain.model.policy.PhysicalPerson;
import com.lombardinternational.casemanagement.service.decision.domain.model.policy.Policy;
import com.lombardinternational.casemanagement.service.decision.domain.model.policy.SourceOfFunds;
import com.lombardinternational.casemanagement.service.decision.domain.model.policy.SourcesOfWealth;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Field;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Group;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.SelectInputField;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.TextAreaField;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.TextInputField;
import com.lombardinternational.casemanagement.service.decision.domain.model.transaction.BusinessTransaction;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.checklist.FieldBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.spi.repository.ReferenceDataRepositoryService;
import com.lombardinternational.casemanagement.service.decision.domain.utils.ChecklistUtils;
import com.lombardinternational.casemanagement.service.decision.domain.utils.PolicyUtils;
import com.lombardinternational.casemanagement.service.decision.domain.utils.RulesUtils;
import com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ChecklistFieldConstants;

import lombok.AllArgsConstructor;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.RulesUtils.*;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ChecklistFieldConstants.*;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ReferenceConstants.*;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.RulesConstants.*;

@Service
@AllArgsConstructor
public class DueDiligenceFieldsBuilderService implements FieldBuilderService {

    private final ReferenceDataRepositoryService referenceDataRepositoryService;

    @Override
    public void buildField(WebForm webForm, ScreenDescription screenDescription, Group group, Policy policy, BusinessTransaction transaction,
            Map<String,List<String>> overallCaseRisk) {

        Field.resetFieldId();
        if (policy.getEconomicBeneficiaries() != null) {
            IntStream.range(0, policy.getEconomicBeneficiaries().size()).forEach(i -> {
                evaluateIndustry(group, policy.getEconomicBeneficiaries().get(i), i + 1, overallCaseRisk);
                evaluatePosition(group, policy.getEconomicBeneficiaries().get(i), i + 1);
            });
        }
        evaluateBackGroundDetails(group);
        evaluateRiskAssessment(group);
        evaluatePep(group, transaction);
        evaluateOriginatorPep(group, policy);
        evaluateIsPepPayer(group, transaction);
        evaluateKycMandatory(group);
        evaluateNewKycObtained(group);
        evaluateIntroducingPartnerSigned(group);
        evaluateInfoProvidedVerified(group);
        evaluateNewKycInLine(group);
        evaluateIsSameOriginPremium(group);
        evaluateNewOriginPremClass(group);
        evaluateNegativeFinding(group, transaction, overallCaseRisk);
        evaluateNegativeFindingThirdParty(group, transaction);
        evaluateNegativeSinceTransaction(group, transaction);
        if (policy.getEconomicBeneficiaries() != null) {
            evaluateAtLeastOneSowOfKind(group, policy);
        }
        evaluateOriginatorWorldCheck(group);
        evaluateIsOnSanctionList(group, transaction, overallCaseRisk);
        evaluateInsider(group, policy);
        evaluateIsPhEboGoldenVisa(group, transaction, overallCaseRisk);

        if (policy.getEconomicBeneficiaries() != null) {
            IntStream.range(0, policy.getEconomicBeneficiaries().size())
                    .forEach(i -> evaluateAnnualIncome(group, policy.getEconomicBeneficiaries().get(i), i + 1));
        }
        if (policy.getEconomicBeneficiaries() != null) {
            evaluateSourceOfWealth(group, policy.getEconomicBeneficiaries().size());
            IntStream.range(0, policy.getEconomicBeneficiaries().size())
                    .forEach(i -> evaluateTwentyPercentIncome(group, policy.getEconomicBeneficiaries().get(i), i + 1));
        }
        evaluateSourceOfWealthEditable(group);
        evaluateWealthAllocationOk(group);
        if (policy.getEconomicBeneficiaries() != null) {
            IntStream.range(0, policy.getEconomicBeneficiaries().size()).forEach(i -> {
                evaluateWealthOriginatingCountry1Risk(group, policy.getEconomicBeneficiaries().get(i), i + 1);
                evaluateWealthOriginatingCountry2Risk(group, policy.getEconomicBeneficiaries().get(i), i + 1);
            });
        }
        evaluateWealthAllocation(group);
        if (policy.getEconomicBeneficiaries() != null) {
            IntStream.range(0, policy.getEconomicBeneficiaries().size())
                    .forEach(i -> evaluateTotalWealth(group, policy.getEconomicBeneficiaries().get(i), i + 1));
        }
    }

    private void evaluateIndustry(final Group group, final EconomicBeneficiary ebo, int index, final Map<String,List<String>> overallCaseRisk) {

        var industry = (SelectInputField) ChecklistUtils.getFieldInGroup(group, INDUSTRY + "_" + index);
        if (industry == null) {
            industry = SelectInputField.builder().fieldId(INDUSTRY + "_" + index).build();
            group.getFields().add(industry);
        }
        industry.setIsActive(true);
        industry.incrementOrder();
        industry.setLabel("Industry #" + index);
        industry.setMandatory(true);
        industry.setSourceSystem("from CLASS");
        var person = PolicyUtils.getPerson(ebo);
        if (person.isPresent() && person.get().getProfessionIndustrySector() != null) {
            industry.setSelectedValue(person.get().getProfessionIndustrySector().getExternalId());
        } else {
            industry.setSelectedValue(null);
            overallCaseRisk.get(BLOCKED).add("Missing industry sector");
        }

        industry.setOptions(referenceDataRepositoryService.getReferenceDataOptionsByDomainAndSelectedValue(INDUSTRY_SECTOR_DOMAIN,
                industry.getSelectedValue()));
    }

    private void evaluatePosition(final Group group, final EconomicBeneficiary ebo, int index) {

        var position = (SelectInputField) ChecklistUtils.getFieldInGroup(group, POSITION + "_" + index);
        if (position == null) {
            position = SelectInputField.builder().fieldId(POSITION + "_" + index).build();
            group.getFields().add(position);
        }
        position.setIsActive(true);
        position.incrementOrder();
        position.setLabel("Position #" + index);
        position.setSourceSystem("Position from CLASS");

        var person = PolicyUtils.getPerson(ebo);

        if (person.isPresent() && person.get() instanceof PhysicalPerson && ((PhysicalPerson) person.get()).getProfession() != null) {
            position.setSelectedValue(((PhysicalPerson) person.get()).getProfession().getExternalId());
        } else {
            position.setDisplayIf("false");
            position.setSelectedValue(null);
        }
        position.setOptions(
                referenceDataRepositoryService.getReferenceDataOptionsByDomainAndSelectedValue(PROFESSION_DOMAIN, position.getSelectedValue()));
    }

    private void evaluateBackGroundDetails(final Group group) {

        TextAreaField backGroundDetails = (TextAreaField) ChecklistUtils.getFieldInGroup(group, BACKGROUND_DETAILS);
        if (backGroundDetails == null) {
            backGroundDetails = TextAreaField.builder().fieldId(BACKGROUND_DETAILS).build();
            group.getFields().add(backGroundDetails);
        }
        backGroundDetails.setIsActive(true);
        backGroundDetails.incrementOrder();
        backGroundDetails.setLabel("Profession background detail");
        backGroundDetails.setEnabled(true);
    }

    private void evaluateRiskAssessment(final Group group) {

        TextAreaField riskAssessment = (TextAreaField) ChecklistUtils.getFieldInGroup(group, RISK_ASSESSMENT);
        if (riskAssessment == null) {
            riskAssessment = TextAreaField.builder().fieldId(RISK_ASSESSMENT).build();
            group.getFields().add(riskAssessment);
        }
        riskAssessment.setIsActive(true);
        riskAssessment.incrementOrder();
        riskAssessment.setLabel("Profession risk assessment");
        riskAssessment.setEnabled(true);
    }

    private void evaluatePep(final Group group, final BusinessTransaction transaction) {

        var pep = (SelectInputField) ChecklistUtils.getFieldInGroup(group, PEP);
        if (pep == null) {
            pep = SelectInputField.builder().fieldId(PEP).build();
            group.getFields().add(pep);
        }
        pep.setIsActive(true);
        pep.incrementOrder();
        pep.setLabel("Is there a PEP on the policy");
        pep.setMandatory(true);

        final var pepStatusAnswer = getRiskFactorAnswerDescription(transaction, INT_RF_005);
        final var pepStatusData = getRiskFactorData(transaction, INT_RF_005);

        if (pepStatusAnswer == null || "N/A".equals(pepStatusAnswer) || pepStatusData.toUpperCase().startsWith("MISSING")) {
            pep.setSelectedValue(null);
        } else {
            pep.setSelectedValue(pepStatusAnswer.toUpperCase());
        }

        pep.setOptions(referenceDataRepositoryService.getReferenceDataOptionsByDomainAndSelectedValue(YES_NO_DOMAIN, pep.getSelectedValue()));
    }

    private void evaluateOriginatorPep(final Group group, Policy policy) {

        boolean shouldDisplay = false;
        if (policy.getEconomicBeneficiaries() == null) {
            return;
        }
        for (EconomicBeneficiary ebo : policy.getEconomicBeneficiaries()) {
            var abstractPerson = PolicyUtils.getPerson(ebo);

            if (abstractPerson.isPresent()) {
                boolean hasAtLeastOneSowOriginPrem = hasLeastOnSowOriginPremium(abstractPerson.get());
                if (hasAtLeastOneSowOriginPrem) {
                    shouldDisplay = true;
                    break;
                }
            }
        }

        if (!shouldDisplay) {
            return;
        }

        var originatorpep = (SelectInputField) ChecklistUtils.getFieldInGroup(group, ORIGINATOR_PEP);
        if (originatorpep == null) {
            originatorpep = SelectInputField.builder().fieldId(ORIGINATOR_PEP).build();
            group.getFields().add(originatorpep);
        }

        originatorpep.setIsActive(true);
        originatorpep.setEnabled(true);
        originatorpep.incrementOrder();
        originatorpep.setLabel("Is the Originator, linked to the source of funds to be invested, a PEP?");
        originatorpep.setMandatory(true);

        originatorpep.setDisplayIf("true");
        originatorpep.setOptions(referenceDataRepositoryService.getReferenceDataOptionsByDomain(YES_NO_DOMAIN));

    }

    private void evaluateIsPepPayer(final Group group, final BusinessTransaction transaction) {

        var isPepPayer = (SelectInputField) ChecklistUtils.getFieldInGroup(group, IS_PEP_PAYER);
        if (isPepPayer == null) {
            isPepPayer = SelectInputField.builder().fieldId(IS_PEP_PAYER).build();
            group.getFields().add(isPepPayer);
        }
        isPepPayer.setIsActive(true);
        isPepPayer.incrementOrder();
        isPepPayer.setLabel("Is one of the payer a PEP?");
        isPepPayer.setEnabled(true);
        isPepPayer.setMandatory(true);

        var forcedDisplayIf = "false";
        String paymentToThirdParty = getRiskFactorData(transaction, INT_RF_016);
        if (!paymentToThirdParty.contains("N/A") && !paymentToThirdParty.contains("Policy holder")) {
            forcedDisplayIf = "true";
        }
        isPepPayer.setDisplayIf(forcedDisplayIf);
        isPepPayer.setOptions(referenceDataRepositoryService.getReferenceDataOptionsByDomain(YES_NO_DOMAIN));
    }

    private void evaluateKycMandatory(final Group group) {

        var kycMandatory = (SelectInputField) ChecklistUtils.getFieldInGroup(group, KYC_MANDATORY);
        if (kycMandatory == null) {
            kycMandatory = SelectInputField.builder().fieldId(KYC_MANDATORY).build();
            group.getFields().add(kycMandatory);
        }
        kycMandatory.setIsActive(true);
        kycMandatory.incrementOrder();
        kycMandatory.setLabel("KYC Questionnaire mandatory");
        kycMandatory.setEnabled(true);
        kycMandatory.setOptions(referenceDataRepositoryService.getReferenceDataOptionsByDomain(YES_NO_DOMAIN));
        kycMandatory.setMandatory(true);
    }

    private void evaluateNewKycObtained(final Group group) {

        var newKycObtained = (SelectInputField) ChecklistUtils.getFieldInGroup(group, NEW_KYC_OBTAINED);
        if (newKycObtained == null) {
            newKycObtained = SelectInputField.builder().fieldId(NEW_KYC_OBTAINED).build();
            group.getFields().add(newKycObtained);
        }
        newKycObtained.setIsActive(true);
        newKycObtained.incrementOrder();
        newKycObtained.setLabel("New KYC questionnaire obtained");
        newKycObtained.setEnabled(true);
        newKycObtained.setDisplayIf("#" + KYC_MANDATORY + "# == \"YES\"");
        newKycObtained.setOptions(referenceDataRepositoryService.getReferenceDataOptionsByDomain(YES_NO_DOMAIN));
        newKycObtained.setMandatory(true);
    }

    private void evaluateIntroducingPartnerSigned(final Group group) {

        var introducingPartnerSigned = (SelectInputField) ChecklistUtils.getFieldInGroup(group, INTRODUCING_PARTNER_SIGNED);
        if (introducingPartnerSigned == null) {
            introducingPartnerSigned = SelectInputField.builder().fieldId(INTRODUCING_PARTNER_SIGNED).build();
            group.getFields().add(introducingPartnerSigned);
        }
        introducingPartnerSigned.setIsActive(true);
        introducingPartnerSigned.incrementOrder();
        introducingPartnerSigned.setLabel("Introducing partner signs KYC questionnaire");
        introducingPartnerSigned.setEnabled(true);
        introducingPartnerSigned.setDisplayIf("#" + KYC_MANDATORY + "# == \"YES\" && #" + NEW_KYC_OBTAINED + "# == \"YES\"");
        introducingPartnerSigned.setOptions(referenceDataRepositoryService.getReferenceDataOptionsByDomain(YES_NO_DOMAIN));
        introducingPartnerSigned.setMandatory(true);
    }

    private void evaluateInfoProvidedVerified(final Group group) {

        var infoProvidedVerified = (SelectInputField) ChecklistUtils.getFieldInGroup(group, INFO_PROVIDED_VERIFIED);
        if (infoProvidedVerified == null) {
            infoProvidedVerified = SelectInputField.builder().fieldId(INFO_PROVIDED_VERIFIED).build();
            group.getFields().add(infoProvidedVerified);
        }
        infoProvidedVerified.setIsActive(true);
        infoProvidedVerified.incrementOrder();
        infoProvidedVerified.setLabel("Info provided on KYC questionnaire could be verified");
        infoProvidedVerified.setEnabled(true);
        infoProvidedVerified.setDisplayIf("#" + KYC_MANDATORY + "# == \"YES\" && #" + NEW_KYC_OBTAINED + "# == \"YES\"");
        infoProvidedVerified.setOptions(referenceDataRepositoryService.getReferenceDataOptionsByDomain(YES_NO_DOMAIN));
        infoProvidedVerified.setMandatory(true);
    }

    private void evaluateNewKycInLine(final Group group) {

        var newKycInLine = (SelectInputField) ChecklistUtils.getFieldInGroup(group, NEW_KYC_IN_LINE);
        if (newKycInLine == null) {
            newKycInLine = SelectInputField.builder().fieldId(NEW_KYC_IN_LINE).build();
            group.getFields().add(newKycInLine);
        }
        newKycInLine.setIsActive(true);
        newKycInLine.incrementOrder();
        newKycInLine.setLabel("New KYC questionnaire in line with previous one");
        newKycInLine.setEnabled(true);
        newKycInLine.setDisplayIf("#" + KYC_MANDATORY + "# == \"YES\" && #" + NEW_KYC_OBTAINED + "# == \"YES\"");
        newKycInLine.setOptions(referenceDataRepositoryService.getReferenceDataOptionsByDomain(YES_NO_DOMAIN));
        newKycInLine.setMandatory(true);
    }

    private void evaluateIsSameOriginPremium(final Group group) {

        var isSameOriginPremium = (SelectInputField) ChecklistUtils.getFieldInGroup(group, IS_SAME_ORIGIN_PREMIUM);
        if (isSameOriginPremium == null) {
            isSameOriginPremium = SelectInputField.builder().fieldId(IS_SAME_ORIGIN_PREMIUM).build();
            group.getFields().add(isSameOriginPremium);
        }
        isSameOriginPremium.setIsActive(true);
        isSameOriginPremium.incrementOrder();
        isSameOriginPremium.setLabel("Is the origin of premium the same as the previous Money-In?");
        isSameOriginPremium.setEnabled(true);
        isSameOriginPremium
                .setDisplayIf("#" + KYC_MANDATORY + "# == \"NO\" || (#" + KYC_MANDATORY + "# == \"YES\" && #" + NEW_KYC_OBTAINED + "# == \"NO\")");
        isSameOriginPremium.setOptions(referenceDataRepositoryService.getReferenceDataOptionsByDomain(YES_NO_DOMAIN));
        isSameOriginPremium.setMandatory(true);
    }

    private void evaluateNewOriginPremClass(final Group group) {

        var newOriginPremiumClass = (SelectInputField) ChecklistUtils.getFieldInGroup(group, NEW_ORIGIN_PREM_CLASS);
        if (newOriginPremiumClass == null) {
            newOriginPremiumClass = SelectInputField.builder().fieldId(NEW_ORIGIN_PREM_CLASS).build();
            group.getFields().add(newOriginPremiumClass);
        }
        newOriginPremiumClass.setIsActive(true);
        newOriginPremiumClass.incrementOrder();
        newOriginPremiumClass.setLabel("Has a new origin of premium been input in CLASS?");
        newOriginPremiumClass.setEnabled(true);
        newOriginPremiumClass.setDisplayIf(
                "(#" + KYC_MANDATORY + "# == \"YES\" && #" + NEW_KYC_OBTAINED + "# == \"YES\") || ((#" + KYC_MANDATORY + "# == \"NO\" || (#"
                        + KYC_MANDATORY + "# == \"YES\" && #" + NEW_KYC_OBTAINED + "# == \"NO\")) && #" + IS_SAME_ORIGIN_PREMIUM + "# == \"NO\")");
        newOriginPremiumClass.setOptions(referenceDataRepositoryService.getReferenceDataOptionsByDomain(YES_NO_DOMAIN));
        newOriginPremiumClass.setMandatory(true);
    }

    private void evaluateNegativeFinding(final Group group, final BusinessTransaction transaction,
            final Map<String,List<String>> overallCaseRisk) {

        var negativeFinding = (SelectInputField) ChecklistUtils.getFieldInGroup(group, NEGATIVE_FINDING);
        if (negativeFinding == null) {
            negativeFinding = SelectInputField.builder().fieldId(NEGATIVE_FINDING).build();
            group.getFields().add(negativeFinding);
        }
        negativeFinding.setIsActive(true);
        negativeFinding.incrementOrder();
        negativeFinding.setLabel("Negative press finding / Worldcheck match (on all roles on policy)");
        negativeFinding.setMandatory(true);
        negativeFinding.setEnabled(false);

        final var riskFactorData = getRiskFactorData(transaction, INT_RF_006);
        if (riskFactorData.toUpperCase().startsWith("MISSING")) {
            negativeFinding.setSelectedValue(null);
            overallCaseRisk.get("BLOCKED").add(riskFactorData);
        } else {
            final var riskFactorDesc = RulesUtils.getRiskFactorAnswerDescription(transaction, INT_RF_006);
            if (riskFactorDesc != null) {
                negativeFinding.setSelectedValue(riskFactorDesc.toUpperCase());
            }
            negativeFinding.setOptions(referenceDataRepositoryService.getReferenceDataOptionsByDomainAndSelectedValue(YES_NO_DOMAIN,
                    negativeFinding.getSelectedValue()));
        }
    }

    private void evaluateNegativeFindingThirdParty(final Group group, final BusinessTransaction transaction) {

        var negativeFindingThirdParty = (TextInputField) ChecklistUtils.getFieldInGroup(group, NEGATIVE_FINDING_THIRD_PARTY);
        if (negativeFindingThirdParty == null) {
            negativeFindingThirdParty = TextInputField.builder().fieldId(NEGATIVE_FINDING_THIRD_PARTY).build();
            group.getFields().add(negativeFindingThirdParty);
        }

        final var riskFactorData = getRiskFactorData(transaction, INT_RF_006);
        final var riskFactorLevel = getRiskFactorLevel(transaction, INT_RF_006);
        var displayIf = "false";
        if (!riskFactorData.toUpperCase().startsWith("MISSING") && HIGH.equalsIgnoreCase(riskFactorLevel)) {
            negativeFindingThirdParty.setSelectedValue(riskFactorData);
            displayIf = "true";
        }
        negativeFindingThirdParty.setIsActive(true);
        negativeFindingThirdParty.incrementOrder();
        negativeFindingThirdParty.setLabel("Negative press finding / Worldcheck match on following Third party(ies)");
        negativeFindingThirdParty.setDisplayIf(displayIf);
    }

    private void evaluateNegativeSinceTransaction(final Group group, final BusinessTransaction transaction) {

        var negativeSinceTransaction = (SelectInputField) ChecklistUtils.getFieldInGroup(group, NEGATIVE_SINCE_TRANSACTION);
        if (negativeSinceTransaction == null) {
            negativeSinceTransaction = SelectInputField.builder().fieldId(NEGATIVE_SINCE_TRANSACTION).build();
            group.getFields().add(negativeSinceTransaction);
        }

        var displayIf = "false";
        var riskFactorData = getRiskFactorData(transaction, INT_RF_006);
        var riskFactorAnswer = getRiskFactorAnswerDescription(transaction, INT_RF_006);
        if (!riskFactorData.toUpperCase().startsWith("MISSING") && NO.equalsIgnoreCase(riskFactorAnswer)) {
            displayIf = "true";
        }

        negativeSinceTransaction.setIsActive(true);
        negativeSinceTransaction.incrementOrder();
        negativeSinceTransaction.setLabel("Did you find any negative press since the last transaction?");
        negativeSinceTransaction.setEnabled(true);
        negativeSinceTransaction.setOptions(referenceDataRepositoryService.getReferenceDataOptionsByDomain(YES_NO_DOMAIN));
        negativeSinceTransaction.setMandatory(true);
        negativeSinceTransaction.setDisplayIf(displayIf);
    }

    private void evaluateAtLeastOneSowOfKind(final Group group, final Policy policy) {

        var atLeastOneSowOfKind = (SelectInputField) ChecklistUtils.getFieldInGroup(group, AT_LEAST_ONE_SOW_OF_KIND);
        if (atLeastOneSowOfKind == null) {
            atLeastOneSowOfKind = SelectInputField.builder().fieldId(AT_LEAST_ONE_SOW_OF_KIND).build();
            group.getFields().add(atLeastOneSowOfKind);
        }
        atLeastOneSowOfKind.setIsActive(true);
        atLeastOneSowOfKind.incrementOrder();
        atLeastOneSowOfKind.setLabel("Invisible field : used as display if condition for ORIGINATOR_WORLD_CHECK");
        atLeastOneSowOfKind.setMandatory(true);
        atLeastOneSowOfKind.setDisplayIf("false");

        var abstractPerson = PolicyUtils.getPersons(policy.getEconomicBeneficiaries());

        var hasAtLeastOneSowOfKind = abstractPerson.stream().map(AbstractPerson::getSourceOfFunds).filter(Objects::nonNull)
                .flatMap(sourceOfFunds -> sourceOfFunds.getSourcesOfWealth().stream()).filter(Objects::nonNull)
                .anyMatch(sourcesOfWealth -> sourcesOfWealth.getDescription().matches("inheri_don|divorce|gift"));

        atLeastOneSowOfKind.setSelectedValue(hasAtLeastOneSowOfKind ? YES : NO);
    }

    private void evaluateOriginatorWorldCheck(final Group group) {

        var originatorWorldCheck = (SelectInputField) ChecklistUtils.getFieldInGroup(group, ChecklistFieldConstants.ORIGINATOR_WORLD_CHECK);
        if (originatorWorldCheck == null) {
            originatorWorldCheck = SelectInputField.builder().fieldId(ChecklistFieldConstants.ORIGINATOR_WORLD_CHECK).build();
            group.getFields().add(originatorWorldCheck);
        }
        originatorWorldCheck.setIsActive(true);
        originatorWorldCheck.incrementOrder();
        originatorWorldCheck.setLabel("World check match or negative press found on originator");
        originatorWorldCheck.setMandatory(true);
        originatorWorldCheck.setEnabled(true);
        originatorWorldCheck.setOptions(referenceDataRepositoryService.getReferenceDataOptionsByDomain(YES_NO_DOMAIN));
        originatorWorldCheck.setDisplayIf(Boolean.toString(Optional.ofNullable(ChecklistUtils.getFieldInGroup(group, AT_LEAST_ONE_SOW_OF_KIND))
                .map(Field::getSelectedValue).stream().anyMatch(YES::equals)));
    }

    private void evaluateIsOnSanctionList(final Group group, final BusinessTransaction transaction,
            final Map<String,List<String>> overallCaseRisk) {

        var isOnSanctionList = (SelectInputField) ChecklistUtils.getFieldInGroup(group, IS_ON_SANCTION_LIST);
        if (isOnSanctionList == null) {
            isOnSanctionList = SelectInputField.builder().fieldId(IS_ON_SANCTION_LIST).build();
            group.getFields().add(isOnSanctionList);
        }
        isOnSanctionList.setIsActive(true);
        isOnSanctionList.incrementOrder();
        isOnSanctionList.setLabel("Is there any person designated on a sanctions list on the policy?");
        isOnSanctionList.setMandatory(true);

        final var isOnSanctionListRiskData = getRiskFactorData(transaction, INT_RF_007);
        if (StringUtils.containsIgnoreCase(isOnSanctionListRiskData, ("Missing"))) {
            isOnSanctionList.setSelectedValue(null);
            overallCaseRisk.get(BLOCKED).add(isOnSanctionListRiskData);
        } else {
            final var isOnSanctionListRiskAnswer = RulesUtils.getRiskFactorAnswerDescription(transaction, INT_RF_007);
            isOnSanctionList.setSelectedValue(isOnSanctionListRiskAnswer);
        }
        isOnSanctionList.setOptions(referenceDataRepositoryService.getReferenceDataOptionsByDomainAndSelectedValue(YES_NO_DOMAIN,
                isOnSanctionList.getSelectedValue()));
    }

    private void evaluateInsider(final Group group, final Policy policy) {

        var insider = (SelectInputField) ChecklistUtils.getFieldInGroup(group, INSIDER);
        if (insider == null) {
            insider = SelectInputField.builder().fieldId(INSIDER).build();
            group.getFields().add(insider);
        }
        insider.setIsActive(true);
        insider.incrementOrder();
        insider.setLabel("Is the person an insider to any assets invested in the policy?");

        var isInsider = policy.getThirdParties().stream().map(AbstractPerson::getSourceOfFunds).filter(Objects::nonNull)
                .map(SourceOfFunds::getInsiderFlag).filter(Objects::nonNull).anyMatch(Boolean::booleanValue);

        var forcedValue = isInsider ? YES : NO;
        insider.setSelectedValue(forcedValue);
        insider.setOptions(
                referenceDataRepositoryService.getReferenceDataOptionsByDomainAndSelectedValue(YES_NO_DOMAIN, insider.getSelectedValue()));
    }

    private void evaluateIsPhEboGoldenVisa(final Group group, BusinessTransaction transaction, final Map<String,List<String>> overallCaseRisk) {

        var phEboGoldenVisa = (SelectInputField) ChecklistUtils.getFieldInGroup(group, IS_PH_EBO_GOLDEN_VISA);
        if (phEboGoldenVisa == null) {
            phEboGoldenVisa = SelectInputField.builder().fieldId(IS_PH_EBO_GOLDEN_VISA).build();
            group.getFields().add(phEboGoldenVisa);
        }
        phEboGoldenVisa.setIsActive(true);
        phEboGoldenVisa.incrementOrder();
        phEboGoldenVisa.setLabel(
                "Is the PH / EBO a country national who applied for residence rights or citizenship in exchange of capital transfers purchase of property or government bonds or investment in corporate entities (who has a Golden Visa) or a Golden Passport");
        phEboGoldenVisa.setMandatory(true);

        var value = getRiskFactorData(transaction, INT_RF_013);
        var forcedValue = getRiskFactorAnswerDescription(transaction, INT_RF_013);
        if (value.contains("N/A")) {
            forcedValue = null;
            (overallCaseRisk.get(BLOCKED)).add("Please fill in the Golden Visa in CLASS");
        }

        phEboGoldenVisa.setSelectedValue(forcedValue);
        phEboGoldenVisa.setOptions(
                referenceDataRepositoryService.getReferenceDataOptionsByDomainAndSelectedValue(YES_NO_DOMAIN, phEboGoldenVisa.getSelectedValue()));
    }

    private void evaluateAnnualIncome(final Group group, final EconomicBeneficiary ebo, int position) {

        var annualIncome = (TextInputField) ChecklistUtils.getFieldInGroup(group, ANNUAL_INCOME + "_" + position);
        if (annualIncome == null) {
            annualIncome = TextInputField.builder().fieldId(ANNUAL_INCOME + "_" + position).build();
            group.getFields().add(annualIncome);
        }
        annualIncome.setIsActive(true);
        annualIncome.incrementOrder();
        annualIncome.setLabel("Annual income #" + position);
        annualIncome.setSourceSystem("FROM CLASS");

        var abstractPerson = PolicyUtils.getPerson(ebo);

        if (abstractPerson.isPresent() && abstractPerson.get().getSourceOfFunds() != null
                && abstractPerson.get().getSourceOfFunds().getAnnualIncome() != null) {
            annualIncome.setSelectedValue(String.valueOf(abstractPerson.get().getSourceOfFunds().getAnnualIncome().getQuantity()));
        } else {
            annualIncome.setSelectedValue("N/A");
        }

    }

    private void evaluateSourceOfWealth(final Group group, final int eboSize) {

        var sourceOfWealth = (TextInputField) ChecklistUtils.getFieldInGroup(group, SOURCE_OF_WEALTH);
        if (sourceOfWealth == null) {
            sourceOfWealth = TextInputField.builder().fieldId(SOURCE_OF_WEALTH).build();
            group.getFields().add(sourceOfWealth);
        }
        sourceOfWealth.setIsActive(false); // Not display with Brain
        sourceOfWealth.incrementOrder();
        sourceOfWealth.setLabel("Source of wealth description");
        sourceOfWealth.setEnabled(true);
        sourceOfWealth.setSourceSystem("FROM CLASS");
        sourceOfWealth.setSelectedValue(String.valueOf(eboSize));
    }

    private void evaluateTwentyPercentIncome(final Group group, final EconomicBeneficiary ebo, int position) {

        var twentyPercentIncome = (SelectInputField) ChecklistUtils.getFieldInGroup(group, TWENTY_PERCENT_INCOME + "_" + position);
        if (twentyPercentIncome == null) {
            twentyPercentIncome = SelectInputField.builder().fieldId(TWENTY_PERCENT_INCOME + "_" + position).build();
            group.getFields().add(twentyPercentIncome);
        }
        twentyPercentIncome.setIsActive(true);
        twentyPercentIncome.incrementOrder();
        twentyPercentIncome.setLabel("A portion of wealth is from inheritance / Gift / Donation / Divorce #" + position);
        twentyPercentIncome.setSourceSystem("From CLASS");

        var abstractPerson = PolicyUtils.getPerson(ebo);

        if (abstractPerson.isPresent()) {
            // Was change since in brain even if getSplitPercentage() is null we still compute the value
            boolean result = hasLeastOnSowOriginPremium(abstractPerson.get());

            twentyPercentIncome.setSelectedValue(result ? YES : NO);
        } else {
            twentyPercentIncome.setSelectedValue(NO);
        }
        twentyPercentIncome.setOptions(referenceDataRepositoryService.getReferenceDataOptionsByDomainAndSelectedValue(YES_NO_DOMAIN,
                twentyPercentIncome.getSelectedValue()));
    }

    private void evaluateSourceOfWealthEditable(final Group group) {

        TextAreaField sourceOfWealthEditable = (TextAreaField) ChecklistUtils.getFieldInGroup(group, SOURCE_OF_WEALTH_EDITABLE);
        if (sourceOfWealthEditable == null) {
            sourceOfWealthEditable = TextAreaField.builder().fieldId(SOURCE_OF_WEALTH_EDITABLE).build();
            group.getFields().add(sourceOfWealthEditable);
        }
        sourceOfWealthEditable.setIsActive(true);
        sourceOfWealthEditable.incrementOrder();
        sourceOfWealthEditable.setLabel("Additional information on source of wealth");
        sourceOfWealthEditable.setEnabled(true);
    }

    private void evaluateWealthAllocationOk(final Group group) {

        var wealthAllocationOk = (SelectInputField) ChecklistUtils.getFieldInGroup(group, WEALTH_ALLOCATION_OK);
        if (wealthAllocationOk == null) {
            wealthAllocationOk = SelectInputField.builder().fieldId(WEALTH_ALLOCATION_OK).build();
            group.getFields().add(wealthAllocationOk);
        }
        wealthAllocationOk.setIsActive(true);
        wealthAllocationOk.incrementOrder();
        wealthAllocationOk.setLabel("Wealth allocation in line with source");
        wealthAllocationOk.setEnabled(true);
        wealthAllocationOk.setOptions(referenceDataRepositoryService.getReferenceDataOptionsByDomain(YES_NO_DOMAIN));
    }

    private void evaluateWealthOriginatingCountry1Risk(final Group group, final EconomicBeneficiary ebo, int position) {

        var wealthOriginationCountry1Risk =
                (TextInputField) ChecklistUtils.getFieldInGroup(group, WEALTH_ORIGINATING_COUNTRY_1_RISK + "_" + position);
        if (wealthOriginationCountry1Risk == null) {
            wealthOriginationCountry1Risk = TextInputField.builder().fieldId(WEALTH_ORIGINATING_COUNTRY_1_RISK + "_" + position).build();
            group.getFields().add(wealthOriginationCountry1Risk);
        }
        wealthOriginationCountry1Risk.setIsActive(true);
        wealthOriginationCountry1Risk.incrementOrder();
        wealthOriginationCountry1Risk.setMandatory(true);
        wealthOriginationCountry1Risk.setLabel("Country 1 origin of premium #" + position);
        wealthOriginationCountry1Risk.setSourceSystem("From CLASS");

        var abstractPerson = PolicyUtils.getPerson(ebo);
        List<String> countries = new ArrayList<>();
        abstractPerson.ifPresent(person -> countries.addAll(
                PolicyUtils.getSourceOfWealthByPerson(person).stream().filter(sow -> sow.getOriginOfPremium() != null && sow.getOriginOfPremium())
                        .map(SourcesOfWealth::getWealthOriginatingcountry1).filter(Objects::nonNull).toList()));
        StringBuilder builder = new StringBuilder();
        if (!countries.isEmpty()) {
            builder.append(String.join(" ", countries));
        }
        wealthOriginationCountry1Risk.setSelectedValue(builder.toString());
    }

    private void evaluateWealthOriginatingCountry2Risk(final Group group, final EconomicBeneficiary ebo, int position) {

        var wealthOriginationCountry2Risk =
                (TextInputField) ChecklistUtils.getFieldInGroup(group, WEALTH_ORIGINATING_COUNTRY_2_RISK + "_" + position);
        if (wealthOriginationCountry2Risk == null) {
            wealthOriginationCountry2Risk = TextInputField.builder().fieldId(WEALTH_ORIGINATING_COUNTRY_2_RISK + "_" + position).build();
            group.getFields().add(wealthOriginationCountry2Risk);
        }
        wealthOriginationCountry2Risk.setIsActive(true);
        wealthOriginationCountry2Risk.incrementOrder();
        wealthOriginationCountry2Risk.setLabel("Country 2 origin of premium #" + position);
        wealthOriginationCountry2Risk.setSourceSystem("FROM CLASS ");

        var abstractPerson = PolicyUtils.getPerson(ebo);
        List<String> countries = new ArrayList<>();
        abstractPerson.ifPresent(person -> countries.addAll(
                PolicyUtils.getSourceOfWealthByPerson(person).stream().filter(sow -> sow.getOriginOfPremium() != null && sow.getOriginOfPremium())
                        .map(SourcesOfWealth::getWealthOriginatingcountry2).filter(Objects::nonNull).toList()));

        StringBuilder builder = new StringBuilder();
        if (!countries.isEmpty()) {
            builder.append(String.join(" ", countries));
        }
        wealthOriginationCountry2Risk.setSelectedValue(builder.toString());
    }

    private void evaluateWealthAllocation(final Group group) {

        var wealthAllocation = (TextInputField) ChecklistUtils.getFieldInGroup(group, WEALTH_ALLOCATION);
        if (wealthAllocation == null) {
            wealthAllocation = TextInputField.builder().fieldId(WEALTH_ALLOCATION).build();
            group.getFields().add(wealthAllocation);
        }
        wealthAllocation.setIsActive(true);
        wealthAllocation.incrementOrder();
        wealthAllocation.setLabel("Wealth allocation");
        wealthAllocation.setEnabled(true);
    }

    private void evaluateTotalWealth(final Group group, EconomicBeneficiary ebo, int position) {

        var totalWealth = (TextInputField) ChecklistUtils.getFieldInGroup(group, TOTAL_WEALTH + "_" + position);
        if (totalWealth == null) {
            totalWealth = TextInputField.builder().fieldId(TOTAL_WEALTH + "_" + position).build();
            group.getFields().add(totalWealth);
        }
        totalWealth.setIsActive(true);
        totalWealth.incrementOrder();
        totalWealth.setLabel("Total wealth #" + position);

        var abstractPerson = PolicyUtils.getPerson(ebo);
        String totalWealthValue = abstractPerson.map(AbstractPerson::getSourceOfFunds).map(SourceOfFunds::getTotalWealth).map(Amount::getQuantity)
                .map(Objects::toString).orElse("N/A");
        totalWealth.setSelectedValue(totalWealthValue);
    }

    private boolean hasLeastOnSowOriginPremium(AbstractPerson person) {

        return Optional.ofNullable(person).map(AbstractPerson::getSourceOfFunds).map(sof -> PolicyUtils.getSourceOfWealthByPerson(person))
                .orElseGet(Collections::emptyList).stream()
                .filter(sow -> sow.getDescription() != null && sow.getDescription().matches("inheri_don|divorce|gift"))
                .anyMatch(sow -> Boolean.TRUE.equals(sow.getOriginOfPremium()));

    }
}
