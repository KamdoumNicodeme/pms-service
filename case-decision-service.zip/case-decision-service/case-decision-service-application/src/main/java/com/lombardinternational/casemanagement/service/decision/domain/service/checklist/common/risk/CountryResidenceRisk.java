package com.lombardinternational.casemanagement.service.decision.domain.service.checklist.common.risk;

import java.util.List;
import java.util.Map;

import com.lombardinternational.casemanagement.service.decision.domain.model.transaction.BusinessTransaction;
import com.lombardinternational.casemanagement.service.decision.domain.utils.constants.CaseRisk;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.RulesUtils.*;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.RulesConstants.*;

public class CountryResidenceRisk {

    public static CaseRisk residence(final BusinessTransaction transaction, final Map<String,List<String>> overallCaseRisk) {

        String countryOfResidenceLevel = getRiskFactorLevel(transaction, INT_RF_002);
        String countryOfResidenceData = getRiskFactorData(transaction, INT_RF_002);
        if ((CaseRisk.CASE_RISK_VERY_HIGH.getValue()).equals(countryOfResidenceLevel) && !countryOfResidenceData.contains("N/A")) {
            overallCaseRisk.get(HIGH).add("High risk country of residence");
            return CaseRisk.CASE_RISK_HIGH;
        }
        return CaseRisk.CASE_RISK_STANDARD;
    }
}
