package com.lombardinternational.casemanagement.service.decision.domain.service.checklist.common.risk;

import java.util.List;
import java.util.Map;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Field;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.transaction.BusinessTransaction;
import com.lombardinternational.casemanagement.service.decision.domain.utils.ChecklistUtils;
import com.lombardinternational.casemanagement.service.decision.domain.utils.constants.CaseRisk;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.RulesUtils.*;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ChecklistFieldConstants.*;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.RulesConstants.*;

public class PremiumNaturalPersonRisk {

    public static CaseRisk premiumNaturalPerson(final ScreenDescription screenDescription, final BusinessTransaction transaction,
            final Map<String,List<String>> overallCaseRisk) {

        String PHYSICAL = "PH Type=Physical";
        String phType = getRiskFactorData(transaction, INT_RF_014);

        String phLegalEntityDisplay = ChecklistUtils.getFieldById(screenDescription, PH_LEGAL_ENTITY).map(Field::getDisplayIf).orElse(null);

        boolean isPhLegalEntityDisplay = "true".equals(phLegalEntityDisplay);
        if (isPhLegalEntityDisplay && !PHYSICAL.equals(phType) && evaluateFieldValue(screenDescription, PH_LEGAL_ENTITY, YES, null)
                && evaluateFieldValue(screenDescription, PREM_PAID_FROM_BEN, YES, null)) {
            overallCaseRisk.get(HIGH).add("Premium is paid from a natural person");
            return CaseRisk.CASE_RISK_HIGH;
        }
        return CaseRisk.CASE_RISK_STANDARD;

    }
}
