package com.lombardinternational.casemanagement.service.decision.domain.service.checklist.addition.group;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.lombardinternational.casemanagement.service.decision.domain.model.policy.Policy;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Group;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Tab;
import com.lombardinternational.casemanagement.service.decision.domain.model.transaction.BusinessTransaction;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.checklist.GroupBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.checklist.addition.field.SignoffsFieldsBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.utils.RulesUtils;

import lombok.AllArgsConstructor;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ChecklistFieldConstants.*;

@Service
@AllArgsConstructor
public class SignoffsAdditionGroupBuilderService implements GroupBuilderService {

    private final SignoffsFieldsBuilderService signoffsFieldsBuilderService;

    @Override
    public void buildGroup(final WebForm webForm, final ScreenDescription screenDescription, final Tab parentTab, final Policy policy,
            final BusinessTransaction business, final Map<String,List<String>> overallCaseRisk) {

        var signoffs = RulesUtils.getGroupInTab(parentTab, SIGNOFFS_GROUP);
        if (signoffs == null) {
            signoffs = Group.builder().groupId(SIGNOFFS_GROUP).build();
            parentTab.getGroups().add(signoffs);
        }
        signoffs.setIsActive(true);
        signoffs.incrementOrder();
        signoffs.setTitle("Sign offs");
        signoffsFieldsBuilderService.buildField(webForm, screenDescription, signoffs, policy, business, overallCaseRisk);
    }
}
