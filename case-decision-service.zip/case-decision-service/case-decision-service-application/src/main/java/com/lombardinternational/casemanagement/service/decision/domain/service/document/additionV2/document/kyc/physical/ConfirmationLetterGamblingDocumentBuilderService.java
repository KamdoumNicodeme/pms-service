package com.lombardinternational.casemanagement.service.decision.domain.service.document.additionV2.document.kyc.physical;

import java.util.List;

import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Service;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.DocumentDefinition;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebFormGroup;
import com.lombardinternational.casemanagement.service.decision.domain.service.document.additionV2.document.kyc.DocumentUtilsBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.utils.WebformUtils;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.DocumentConstants.CONFIRMATION_LETTER_GAMBLING_FORM_DESCRIPTION;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.DocumentConstants.CONFIRMATION_LETTER_GAMBLING_FORM_I18N_DESCRIPTION;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.DocumentConstants.EBO_I18N_DOCUMENT_RELATED_TO;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.DocumentConstants.KYC_DOCUMENT_CMS_DOC_TYPE;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.DocumentConstants.KYC_DOCUMENT_DOC_TYPE;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.RulesConstants.GAMBLING;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.RulesConstants.TRUE;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.WebFormFieldConstants.*;

@Service
public class ConfirmationLetterGamblingDocumentBuilderService extends DocumentUtilsBuilderService {

    @Override
    public void buildDocument(final WebForm webForm, final ScreenDescription screenDescription, String transactionNumber,
            List<DocumentDefinition> documents) {

        for (WebFormGroup group : getEboKycs(webForm, false)) {
            var beneficiaryWealth = WebformUtils.getGroupInGroup(group, BENEFICIARY_WEALTH_WF);
            if (beneficiaryWealth == null || CollectionUtils.isEmpty(beneficiaryWealth.getGroups())) {
                return;
            }
            var other = WebformUtils.getGroupInGroup(beneficiaryWealth, OTHER_WF);
            if (other == null || CollectionUtils.isEmpty(other.getGroups())) {
                return;
            }
            var hasOther = WebformUtils.getWebFormFieldValueById(other, HAS_OTHER_WF);
            var details = WebformUtils.getWebFormFieldValueById(other, DETAILS_WF);
            if (TRUE.equalsIgnoreCase(hasOther) && GAMBLING.equals(details)) {
                var eboId = WebformUtils.getWebFormFieldValueById(group, EBO_ID_WF);
                var eboName = WebformUtils.getWebFormFieldValueById(group, EBO_NAME_WF);
                var relatedTo = "Ebo " + eboName;
                var relatedToPolicy = WebformUtils.getWebFormFieldValueById(webForm, POLICY_NUMBER_WF);
                buildDocumentDefinition(relatedTo, relatedToPolicy, eboName, eboId, documents);

            }
        }
    }

    @Override
    protected String getDocumentType() {

        return KYC_DOCUMENT_DOC_TYPE;
    }

    @Override
    protected String getCmsDocumentType() {

        return KYC_DOCUMENT_CMS_DOC_TYPE;
    }

    @Override
    protected String getDescription() {

        return CONFIRMATION_LETTER_GAMBLING_FORM_DESCRIPTION;
    }

    @Override
    protected String getI18NDescription() {

        return CONFIRMATION_LETTER_GAMBLING_FORM_I18N_DESCRIPTION;
    }

    @Override
    protected String getI18NDocumentRelatedTo() {

        return EBO_I18N_DOCUMENT_RELATED_TO;
    }

    @Override
    protected boolean getDocumentVisibleOnConnect() {

        return true;
    }

    @Override
    protected boolean getDocumentRequired() {

        return true;
    }
}
