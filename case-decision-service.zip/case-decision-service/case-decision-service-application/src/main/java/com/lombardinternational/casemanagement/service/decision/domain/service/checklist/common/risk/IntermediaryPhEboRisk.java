package com.lombardinternational.casemanagement.service.decision.domain.service.checklist.common.risk;

import java.util.List;
import java.util.Map;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.utils.constants.CaseRisk;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.RulesUtils.*;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ChecklistFieldConstants.*;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.RulesConstants.*;

public class IntermediaryPhEboRisk {

    public static CaseRisk intermediaryPhEbo(final ScreenDescription screenDescription, final Map<String,List<String>> overallCaseRisk) {

        if (evaluateFieldValue(screenDescription, IS_PH_REPRESENTATIVE, YES, null)) {
            overallCaseRisk.get(HIGH).add("PH/EBO is linked to the intermediary");
            return CaseRisk.CASE_RISK_HIGH;
        }
        return CaseRisk.CASE_RISK_STANDARD;
    }

}
