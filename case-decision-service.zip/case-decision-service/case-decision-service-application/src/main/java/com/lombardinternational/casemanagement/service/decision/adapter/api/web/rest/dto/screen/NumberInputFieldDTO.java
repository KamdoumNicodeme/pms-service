package com.lombardinternational.casemanagement.service.decision.adapter.api.web.rest.dto.screen;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.RequiredArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder
@RequiredArgsConstructor
@EqualsAndHashCode(callSuper = true)
public class NumberInputFieldDTO extends FieldDTO {

    private Integer min;
    private Integer max;
    private Integer decimals;
    private Integer size;
}
