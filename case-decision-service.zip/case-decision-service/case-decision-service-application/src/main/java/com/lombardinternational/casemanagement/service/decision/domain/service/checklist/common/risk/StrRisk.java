package com.lombardinternational.casemanagement.service.decision.domain.service.checklist.common.risk;

import java.util.List;
import java.util.Map;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Field;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.utils.ChecklistUtils;
import com.lombardinternational.casemanagement.service.decision.domain.utils.constants.CaseRisk;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ChecklistFieldConstants.*;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.RulesConstants.*;

public class StrRisk {

    public static CaseRisk str(final ScreenDescription screenDescription, final Map<String,List<String>> overallCaseRisk) {

        if (YES.equals(ChecklistUtils.getFieldById(screenDescription, TP_BLOCK).map(Field::getSelectedValue).orElse(null))) {
            overallCaseRisk.get(HIGH).add("STR/SAR Block");
            return CaseRisk.CASE_RISK_HIGH;
        }
        return CaseRisk.CASE_RISK_STANDARD;

    }
}
