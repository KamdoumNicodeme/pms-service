package com.lombardinternational.casemanagement.service.decision.domain.service.checklist.common.risk;

import java.util.List;
import java.util.Map;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.transaction.BusinessTransaction;
import com.lombardinternational.casemanagement.service.decision.domain.utils.ChecklistUtils;
import com.lombardinternational.casemanagement.service.decision.domain.utils.constants.CaseRisk;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.RulesUtils.*;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ChecklistFieldConstants.*;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.RulesConstants.*;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class ThirdPartyPayerRisk {

    public static CaseRisk thirdPartyPayer(final ScreenDescription screenDescription, final BusinessTransaction transaction,
            final Map<String,List<String>> overallCaseRisk) {

        var riskField = ChecklistUtils.getFieldById(screenDescription, PAYMENT_THIRD_PARTY);

        if (riskField.isPresent() && riskField.get().getSelectedValue() != null) {
            String riskThirdPartyPayement = getRiskFactorLevel(transaction, INT_RF_016);
            return switch (riskThirdPartyPayement.toUpperCase()) {
            case HIGH -> {
                overallCaseRisk.get(HIGH).add("3rd Party Payer");
                yield CaseRisk.CASE_RISK_HIGH;
            }
            case MEDIUM -> CaseRisk.CASE_RISK_MEDIUM;
            default -> CaseRisk.CASE_RISK_STANDARD;
            };
        }
        return CaseRisk.CASE_RISK_STANDARD;
    }
}
