package com.lombardinternational.casemanagement.service.decision.domain.service.checklist.cci.field;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.lombardinternational.casemanagement.service.decision.domain.model.policy.Policy;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Field;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Group;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.TextInputField;
import com.lombardinternational.casemanagement.service.decision.domain.model.transaction.BusinessTransaction;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.checklist.FieldBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.utils.ChecklistUtils;
import com.lombardinternational.casemanagement.service.decision.domain.utils.WebformUtils;

import lombok.AllArgsConstructor;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.cci.CCIChecklistFieldConstants.*;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.cci.CCIWebFormFieldConstants.*;

@Service
@AllArgsConstructor
public class GeneralDetailsCCIFieldsBuilderService implements FieldBuilderService {

    @Override
    public void buildField(final WebForm webForm, final ScreenDescription screenDescription, final Group group, final Policy policy,
            final BusinessTransaction transaction, final Map<String,List<String>> overallCaseRisk) {

        Field.resetFieldId();
        evaluateClientName(group, webForm);
    }

    private void evaluateClientName(final Group group, final WebForm webForm) {

        var clientName = (TextInputField) ChecklistUtils.getFieldInGroup(group, CLIENT_NAME);
        if (clientName == null) {
            clientName = TextInputField.builder().fieldId(CLIENT_NAME).build();
            group.getFields().add(clientName);
        }

        var selectedValue = "N/A";

        final var clientPhysicalGroup = WebformUtils.getFirstWebFormGroupById(webForm, CLIENT_PHYSICAL);
        if (clientPhysicalGroup != null) {
            final var clientNumber = WebformUtils.getWebFormFieldValueById(clientPhysicalGroup, CLIENT_NUMBER);
            final var firstName = WebformUtils.getWebFormFieldValueById(clientPhysicalGroup, FIRST_NAME);
            final var lastName = WebformUtils.getWebFormFieldValueById(clientPhysicalGroup, LAST_NAME);
            final var birthDate = WebformUtils.getWebFormFieldValueById(clientPhysicalGroup, BIRTH_DATE);
            selectedValue = clientNumber + " - " + firstName + " " + lastName + " (" + birthDate + ")";
        } else {
            final var clientCompanyGroup = WebformUtils.getFirstWebFormGroupById(webForm, CLIENT_COMPANY);
            if (clientCompanyGroup != null) {
                final var clientNumber = WebformUtils.getWebFormFieldValueById(clientCompanyGroup, CLIENT_NUMBER);
                final var companyName = WebformUtils.getWebFormFieldValueById(clientCompanyGroup, COMPANY_NAME);
                selectedValue = clientNumber + " - " + companyName;
            }
        }
        clientName.setIsActive(true);
        clientName.incrementOrder();
        clientName.setLabel("Client name / company name");
        clientName.setSourceSystem("From Connect");
        clientName.setSelectedValue(selectedValue);
    }

}
