package com.lombardinternational.casemanagement.service.decision.domain.service.control.addition.control;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.springframework.stereotype.Service;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ControlDefinition;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.AbstractControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.utils.Constraint;
import com.lombardinternational.casemanagement.service.decision.domain.utils.FieldConstraint;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ChecklistFieldConstants.*;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ControlConstants.*;

@Service
public class ObtainWssAdviceNonCoreMarketControlBuilderService extends AbstractControlBuilderService {

    // TODO: Export this to repository service to query reference country with a filter non core market or any other filter
    private static final List<String> coreMarket = Arrays.asList("BE", "BR", "CL", "CO", "CY", "DE", "ES", "FI", "FR", "GB", "GG", "GI", "IL",
            "IT", "LU", "MT", "MX", "NO", "PE", "PT", "SE", "TR");

    @Override
    public ControlDefinition buildControl(final WebForm webForm, final ScreenDescription screenDescription) {

        final var constraints = new ArrayList<FieldConstraint>();
        constraints
                .add(FieldConstraint.builder().fieldId(BAC_APPROVAL).constraint(Constraint.EQUALS).values(Collections.singletonList(NO)).build());
        // Considering the refactor of residence country field in TCM-1855 it will be split with a space
        constraints.add(FieldConstraint.builder().fieldId(PH_RESIDENCE_COUNTRY).constraint(Constraint.DISJOINT).split(true).tokenizer(" ")
                .values(coreMarket).build());
        if (constraints.stream().allMatch(constraint -> constraint.test(screenDescription))) {
            return buildControlDefinition();
        }
        return null;
    }

    @Override
    public String getControlName() {

        return WSS_ADVICE_NAME;
    }

    @Override
    public String getControlType() {

        return WSS_ADVICE_TYPE;
    }
}
