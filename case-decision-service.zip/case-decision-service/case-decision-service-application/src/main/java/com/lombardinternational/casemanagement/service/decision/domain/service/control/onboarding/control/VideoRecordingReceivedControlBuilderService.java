package com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control;

import java.util.Collections;
import java.util.List;

import org.springframework.stereotype.Service;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ControlDefinition;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.AbstractControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.utils.Constraint;
import com.lombardinternational.casemanagement.service.decision.domain.utils.FieldConstraint;

import static com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control.common.Utils.*;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ChecklistFieldConstants.*;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ControlConstants.*;

@Service
public class VideoRecordingReceivedControlBuilderService extends AbstractControlBuilderService {

    @Override
    public ControlDefinition buildControl(WebForm webForm, ScreenDescription screenDescription) {

        List<FieldConstraint> constraints = List.of(createConstraint(VIDEO_RECEIVED, Constraint.EQUALS, Collections.singletonList(NO)),
                createConstraint(NB_INTERMEDIATED_DS, Constraint.EQUALS, Collections.singletonList(YES)));
        if (constraints.stream().allMatch(constraint -> constraint.test(screenDescription))) {
            return buildControlDefinition();
        }
        return null;
    }

    @Override
    protected String getControlName() {

        return VIDEO_RECORDING_RECEIVED_NAME;
    }

    @Override
    protected String getControlType() {

        return VIDEO_RECORDING_RECEIVED_TYPE;
    }
}
