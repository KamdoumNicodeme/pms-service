package com.lombardinternational.casemanagement.service.decision.domain.service.checklist.common.risk;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Field;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.utils.ChecklistUtils;
import com.lombardinternational.casemanagement.service.decision.domain.utils.constants.CaseRisk;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ChecklistFieldConstants.*;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.RulesConstants.*;

public class MediaCoverageRisk {

    public static CaseRisk mediaCoverage(final ScreenDescription screenDescription, final Map<String,List<String>> overallCaseRisk) {

        List<String> fieldToFinds = new ArrayList<>(List.of(NEGATIVE_FINDING, NEGATIVE_FINDING_PAYERS, NEGATIVE_SINCE_TRANSACTION,
                ORIGINATOR_WORLD_CHECK, NEGATIVE_FINDING_THIRD_PARTY));

        List<Field> fields = fieldToFinds.stream().map(fieldId -> ChecklistUtils.getFieldById(screenDescription, fieldId))
                .filter(Optional::isPresent).map(Optional::get).filter(field -> "true".equalsIgnoreCase(field.getDisplayIf())).toList();

        if (fields.stream().anyMatch(field -> field.getSelectedValue() == null || field.getSelectedValue().isEmpty())) {
            return CaseRisk.CASE_RISK_STANDARD;
        }

        boolean negativePressAnyMatch = fields.stream().anyMatch(f -> ((f.getSelectedValue()).toUpperCase()).contains(YES));
        if (negativePressAnyMatch) {
            overallCaseRisk.get(HIGH).add("Negative media coverage / World-Check match");
            return CaseRisk.CASE_RISK_HIGH;
        }

        return CaseRisk.CASE_RISK_STANDARD;
    }
}
