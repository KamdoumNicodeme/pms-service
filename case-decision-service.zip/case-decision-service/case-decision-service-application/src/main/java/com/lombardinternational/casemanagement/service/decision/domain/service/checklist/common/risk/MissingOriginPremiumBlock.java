package com.lombardinternational.casemanagement.service.decision.domain.service.checklist.common.risk;

import java.util.List;
import java.util.Map;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Field;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.utils.ChecklistUtils;
import com.lombardinternational.casemanagement.service.decision.domain.utils.constants.CaseRisk;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ChecklistFieldConstants.*;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.RulesConstants.*;

public class MissingOriginPremiumBlock {

    public static CaseRisk missingOriginPremiumBlock(final ScreenDescription screenDescription, final Map<String,List<String>> overallCaseRisk) {

        final String originPremClass =
                ChecklistUtils.getFieldById(screenDescription, NEW_ORIGIN_PREM_CLASS).map(Field::getSelectedValue).orElse(null);
        final String kycMandatory = ChecklistUtils.getFieldById(screenDescription, KYC_MANDATORY).map(Field::getSelectedValue).orElse(null);
        final String newKycObtained = ChecklistUtils.getFieldById(screenDescription, NEW_KYC_OBTAINED).map(Field::getSelectedValue).orElse(null);
        final String isSameOrigin =
                ChecklistUtils.getFieldById(screenDescription, IS_SAME_ORIGIN_PREMIUM).map(Field::getSelectedValue).orElse(null);
        if (NO.equals(originPremClass) && ((YES.equals(kycMandatory) && YES.equals(newKycObtained))
                || (NO.equals(isSameOrigin) && (NO.equals(kycMandatory) || (YES.equals(kycMandatory) && NO.equals(newKycObtained)))))) {
            overallCaseRisk.get(BLOCKED).add("Missing new origin of premium");
        }
        return CaseRisk.CASE_RISK_STANDARD;
    }
}
