package com.lombardinternational.casemanagement.service.decision.domain.service.checklist.common.field;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.*;
import com.lombardinternational.casemanagement.service.decision.domain.model.transaction.BusinessTransaction;
import com.lombardinternational.casemanagement.service.decision.domain.model.transaction.BusinessTransactionProductComponent;
import com.lombardinternational.casemanagement.service.decision.domain.model.transaction.MoneyInPayment;
import com.lombardinternational.casemanagement.service.decision.domain.model.transaction.PaymentDetails;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.spi.repository.ReferenceDataRepositoryService;
import com.lombardinternational.casemanagement.service.decision.domain.utils.ChecklistUtils;
import com.lombardinternational.casemanagement.service.decision.domain.utils.RulesUtils;
import com.lombardinternational.casemanagement.service.decision.domain.utils.WebformUtils;
import com.lombardinternational.casemanagement.service.decision.domain.utils.constants.RulesConstants;

import java.util.*;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ChecklistFieldConstants.*;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ReferenceConstants.COUNTRY_DOMAIN;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ReferenceConstants.YES_NO_DOMAIN;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.RulesConstants.*;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.WebFormFieldConstants.*;

public class CommonTransactionDetailsFieldsBuilderService {

    public static void evaluatePremiumWithAssets(final WebForm webForm, final Group group,
            final ReferenceDataRepositoryService referenceDataRepositoryService) {

        var premiumWithAssets = (SelectInputField) ChecklistUtils.getFieldInGroup(group, PREMIUM_WITH_ASSETS);
        if (premiumWithAssets == null) {
            premiumWithAssets = SelectInputField.builder().fieldId(PREMIUM_WITH_ASSETS).build();
            group.getFields().add(premiumWithAssets);
        }
        premiumWithAssets.setIsActive(true);
        premiumWithAssets.incrementOrder();
        premiumWithAssets.setLabel("Premium with assets?");
        var assetTransfer = WebformUtils.getWebFormFieldValueById(webForm, IS_ASSET_TRANSFER_WF);
        premiumWithAssets.setSelectedValue("true".equals(assetTransfer) ? "YES" : "NO");
        premiumWithAssets.setOptions(referenceDataRepositoryService.getReferenceDataOptionsByDomainAndSelectedValue(YES_NO_DOMAIN,
                premiumWithAssets.getSelectedValue()));

    }

    public static void evaluatePremiumWithUnqAssets(final WebForm webForm, final Group group,
            final ReferenceDataRepositoryService referenceDataRepositoryService) {

        var premiumWithUnqAsset = (SelectInputField) ChecklistUtils.getFieldInGroup(group, PREMIUM_WITH_UNQ_ASSETS);
        if (premiumWithUnqAsset == null) {
            premiumWithUnqAsset = SelectInputField.builder().fieldId(PREMIUM_WITH_UNQ_ASSETS).build();
            group.getFields().add(premiumWithUnqAsset);
        }
        premiumWithUnqAsset.setIsActive(true);
        premiumWithUnqAsset.incrementOrder();
        premiumWithUnqAsset.setLabel("Premium with unquoted assets?");
        var unquotedAssetTransfer = WebformUtils.getWebFormFieldValueById(webForm, HAVE_UNQUOTED_PRODUCT_WF);
        premiumWithUnqAsset.setSelectedValue("true".equals(unquotedAssetTransfer) ? "YES" : "NO");
        premiumWithUnqAsset.setOptions(referenceDataRepositoryService.getReferenceDataOptionsByDomainAndSelectedValue(YES_NO_DOMAIN,
                premiumWithUnqAsset.getSelectedValue()));

    }

    public static void evaluateInvestedInIlf(final Group group, final ReferenceDataRepositoryService referenceDataRepositoryService) {

        var investedInIlf = (SelectInputField) ChecklistUtils.getFieldInGroup(group, INVESTED_IN_ILF);
        if (investedInIlf == null) {
            investedInIlf = SelectInputField.builder().fieldId(INVESTED_IN_ILF).build();
            group.getFields().add(investedInIlf);
        }
        investedInIlf.setIsActive(true);
        investedInIlf.incrementOrder();
        investedInIlf.setLabel("Will it be reinvested in an ILF?");
        investedInIlf.setEnabled(true);
        investedInIlf.setOptions(referenceDataRepositoryService.getReferenceDataOptionsByDomain(YES_NO_DOMAIN));
        investedInIlf.setMandatory(true);
    }

    public static void evaluatePaymentThirdParty(final Group group, final BusinessTransaction transaction,
            final Map<String,List<String>> overallCaseRisk, final ReferenceDataRepositoryService referenceDataRepositoryService) {

        var paymentThirdParty = (SelectInputField) ChecklistUtils.getFieldInGroup(group, PAYMENT_THIRD_PARTY);
        if (paymentThirdParty == null) {
            paymentThirdParty = SelectInputField.builder().fieldId(PAYMENT_THIRD_PARTY).build();
            group.getFields().add(paymentThirdParty);
        }
        var paymentToThirdParty = RulesUtils.getRiskFactorData(transaction, INT_RF_016);
        if (paymentToThirdParty.contains("N/A")) {
            overallCaseRisk.get(RulesConstants.BLOCKED).add("3rd Party Payment risk factor cannot be assessed");
            paymentThirdParty.setSelectedValue(null);
        } else {
            paymentThirdParty.setSelectedValue(paymentToThirdParty.contains("Policy holder") ? NO : YES);
        }
        paymentThirdParty.setIsActive(true);
        paymentThirdParty.incrementOrder();
        paymentThirdParty.setLabel("Payment from a third party payer");
        paymentThirdParty.setEnabled(false);
        paymentThirdParty.setOptions(referenceDataRepositoryService.getReferenceDataOptionsByDomainAndSelectedValue(YES_NO_DOMAIN,
                paymentThirdParty.getSelectedValue()));
        paymentThirdParty.setMandatory(true);
        paymentThirdParty.setSourceSystem("From Class");

    }

    public static void evaluateRationalForInvestment(final WebForm webForm, final Group group) {

        var rationalForInvestment = (TextAreaField) ChecklistUtils.getFieldInGroup(group, RATIONALE_FOR_INVESTMENT);
        if (rationalForInvestment == null) {
            rationalForInvestment = TextAreaField.builder().fieldId(RATIONALE_FOR_INVESTMENT).build();
            group.getFields().add(rationalForInvestment);
        }
        rationalForInvestment.setIsActive(true);
        rationalForInvestment.incrementOrder();
        rationalForInvestment.setLabel("Rationale for investment");
        var kycIntroPurposeOfInvestment = WebformUtils.getWebFormFieldValueById(webForm, KYC_INTRO_PURPOSE_OF_INVESTMENT_WF);
        rationalForInvestment.setSelectedValue(kycIntroPurposeOfInvestment);
    }

    public static List<MoneyInPayment> evaluateNumberOfOriginatingAccounts(final Group group, final BusinessTransaction transaction) {

        var numberOfOriginatingAccounts = (SelectInputField) ChecklistUtils.getFieldInGroup(group, NUMBER_OF_ORIGINATING_ACCOUNTS);
        if (numberOfOriginatingAccounts == null) {
            numberOfOriginatingAccounts = SelectInputField.builder().fieldId(NUMBER_OF_ORIGINATING_ACCOUNTS).build();
            group.getFields().add(numberOfOriginatingAccounts);
        }
        numberOfOriginatingAccounts.setIsActive(true);
        numberOfOriginatingAccounts.incrementOrder();
        numberOfOriginatingAccounts.setLabel("Number of originating accounts");
        numberOfOriginatingAccounts.setMandatory(true);

        var elementsCount = 0;
        List<MoneyInPayment> payments = new ArrayList<>();
        List<BusinessTransactionProductComponent> productComponents = transaction.getProductComponentPayments();
        if (productComponents != null) {
            payments = productComponents.stream().map(BusinessTransactionProductComponent::getPayments).filter(Objects::nonNull)
                    .flatMap(Collection::stream).filter(MoneyInPayment.class::isInstance).map(MoneyInPayment.class::cast).toList();
            elementsCount = payments.size();
        }

        List<SelectInputFieldOption> selectInputFieldOptions = new ArrayList<>();
        selectInputFieldOptions.add(new SelectInputFieldOption(String.valueOf(elementsCount), String.valueOf(elementsCount)));
        numberOfOriginatingAccounts.setOptions(selectInputFieldOptions);
        numberOfOriginatingAccounts.setSelectedValue(Integer.toString(elementsCount));
        return payments;
    }

    public static void evaluateHolderOfOriginatingAccounts(final Group group, final PaymentDetails details, int position) {

        var holderOfOriginatingAccounts = (TextInputField) ChecklistUtils.getFieldInGroup(group, HOLDER_OF_ORIGINATING_ACCOUNTS + "_" + position);
        if (holderOfOriginatingAccounts == null) {
            holderOfOriginatingAccounts = TextInputField.builder().fieldId(HOLDER_OF_ORIGINATING_ACCOUNTS + "_" + position).build();
            group.getFields().add(holderOfOriginatingAccounts);
        }
        holderOfOriginatingAccounts.setIsActive(true);
        holderOfOriginatingAccounts.incrementOrder();
        holderOfOriginatingAccounts.setLabel("Account holder ID #" + position);
        holderOfOriginatingAccounts.setMandatory(true);

        holderOfOriginatingAccounts.setSelectedValue(details.getPayerID());
    }

    public static void evaluateCountryOfOriginatingAccounts(final Group group, final PaymentDetails details, int position,
            final ReferenceDataRepositoryService referenceDataRepositoryService) {

        var countryOfOriginatingAccounts =
                (SelectInputField) ChecklistUtils.getFieldInGroup(group, COUNTRY_OF_ORIGINATING_ACCOUNTS + "_" + position);
        if (countryOfOriginatingAccounts == null) {
            countryOfOriginatingAccounts = SelectInputField.builder().fieldId(COUNTRY_OF_ORIGINATING_ACCOUNTS + "_" + position).build();
            group.getFields().add(countryOfOriginatingAccounts);
        }
        countryOfOriginatingAccounts.setIsActive(true);
        countryOfOriginatingAccounts.incrementOrder();
        countryOfOriginatingAccounts.setLabel("Country of the originating bank #" + position);
        countryOfOriginatingAccounts.setMandatory(true);

        if (details.getPayerBankCountry() != null) {
            countryOfOriginatingAccounts.setSelectedValue(details.getPayerBankCountry().getIsoCountryCode());
        }
        countryOfOriginatingAccounts.setOptions(referenceDataRepositoryService.getReferenceDataOptionsByDomainAndSelectedValue(COUNTRY_DOMAIN,
                countryOfOriginatingAccounts.getSelectedValue()));

    }

    public static void evaluateBankOfOriginatingAccounts(final Group group, final PaymentDetails details, int position) {

        var bankOfOriginatingAccounts = (TextInputField) ChecklistUtils.getFieldInGroup(group, BANK_OF_ORIGINATING_ACCOUNTS + "_" + position);
        if (bankOfOriginatingAccounts == null) {
            bankOfOriginatingAccounts = TextInputField.builder().fieldId(BANK_OF_ORIGINATING_ACCOUNTS + "_" + position).build();
            group.getFields().add(bankOfOriginatingAccounts);
        }
        bankOfOriginatingAccounts.setIsActive(true);
        bankOfOriginatingAccounts.incrementOrder();
        bankOfOriginatingAccounts.setLabel("Name of the bank #" + position);
        bankOfOriginatingAccounts.setMandatory(true);

        bankOfOriginatingAccounts.setSelectedValue(details.getPayerBankName());

    }

    public static void evaluateCountryOfOriginatingAccountsRisk(final Group group, final BusinessTransaction transaction, final int elementCount,
            Map<String,List<String>> overallCaseRisk) {

        var countryOfOriginatingAccountsRisk = (TextInputField) ChecklistUtils.getFieldInGroup(group, COUNTRY_OF_ORIGINATING_ACCOUNTS_RISK);
        if (countryOfOriginatingAccountsRisk == null) {
            countryOfOriginatingAccountsRisk = TextInputField.builder().fieldId(COUNTRY_OF_ORIGINATING_ACCOUNTS_RISK).build();
            group.getFields().add(countryOfOriginatingAccountsRisk);
        }
        countryOfOriginatingAccountsRisk.setIsActive(true);
        countryOfOriginatingAccountsRisk.incrementOrder();
        countryOfOriginatingAccountsRisk.setLabel("Riskiest country of originating bank");
        countryOfOriginatingAccountsRisk.setMandatory(true);

        final var payerPayeeRisk = RulesUtils.getRiskFactorData(transaction, INT_RF_012);
        countryOfOriginatingAccountsRisk.setSelectedValue(payerPayeeRisk);
        if (payerPayeeRisk.contains("N/A")) {
            countryOfOriginatingAccountsRisk.setSelectedValue(null);
            overallCaseRisk.get(RulesConstants.BLOCKED).add("Missing payer/payee bank country");
        }

        countryOfOriginatingAccountsRisk.setDisplayIf(String.valueOf(elementCount > 0));
    }
}
