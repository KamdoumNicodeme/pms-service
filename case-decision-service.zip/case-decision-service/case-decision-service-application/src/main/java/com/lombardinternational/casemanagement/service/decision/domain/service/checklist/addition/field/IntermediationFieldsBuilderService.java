package com.lombardinternational.casemanagement.service.decision.domain.service.checklist.addition.field;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import org.springframework.stereotype.Service;

import com.lombardinternational.casemanagement.service.decision.domain.model.policy.AbstractPerson;
import com.lombardinternational.casemanagement.service.decision.domain.model.policy.Policy;
import com.lombardinternational.casemanagement.service.decision.domain.model.policy.SourceOfFunds;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Field;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Group;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.SelectInputField;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.TextInputField;
import com.lombardinternational.casemanagement.service.decision.domain.model.transaction.BusinessTransaction;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.checklist.FieldBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.spi.repository.ReferenceDataRepositoryService;
import com.lombardinternational.casemanagement.service.decision.domain.utils.ChecklistUtils;
import com.lombardinternational.casemanagement.service.decision.domain.utils.PolicyUtils;
import com.lombardinternational.casemanagement.service.decision.domain.utils.WebformUtils;

import lombok.AllArgsConstructor;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ChecklistFieldConstants.INTRODUCING_PARTNER_CODE;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ChecklistFieldConstants.IS_PH_REPRESENTATIVE;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ChecklistFieldConstants.NEW_INVESTMENT_PROFILE;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ChecklistFieldConstants.NEW_SUSTAINABILITY_PREFERENCE;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ChecklistFieldConstants.NO_INVESTMENT_PROFILE;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ChecklistFieldConstants.NO_SUSTAINABILITY_PREFERENCE;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ChecklistFieldConstants.PARTNER_TYPE;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ChecklistFieldConstants.PH_DIFFERENT_TO_EBO;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ChecklistFieldConstants.TCC_IN_FOLDER;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ChecklistFieldConstants.TCC_SIGNED;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ReferenceConstants.AGENT_EMPT_REFERENCE;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ReferenceConstants.AGENT_EXT_REFERENCE;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ReferenceConstants.AGENT_INT_REFERENCE;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ReferenceConstants.PARTNER_TYPE_DOMAIN;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ReferenceConstants.YES_NO_DOMAIN;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.RulesConstants.NO;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.RulesConstants.YES;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.WebFormFieldConstants.BROKER_IDENTIFIER_WF;

@Service
@AllArgsConstructor
public class IntermediationFieldsBuilderService implements FieldBuilderService {

    private final ReferenceDataRepositoryService referenceDataRepositoryService;

    @Override
    public void buildField(final WebForm webForm, final ScreenDescription screenDescription, final Group group, final Policy policy,
            final BusinessTransaction transaction, final Map<String,List<String>> overallCaseRisk) {

        Field.resetFieldId();
        evaluatePartnerCode(group, webForm);
        evaluatePartnerType(group);
        evaluatePhRepresentative(group, policy, overallCaseRisk);
        evaluateTCCSigned(group, screenDescription);
        evaluateTCCInFolder(group);
        evaluateNoInvestmentProfile(group);
        evaluateNewInvestmentProfile(group);
        evaluateNoSustainabilityPreference(group);
        evaluateNewSustainabilityPreference(group);
    }

    private void evaluatePartnerCode(final Group group, final WebForm webForm) {

        var partnerCode = (TextInputField) ChecklistUtils.getFieldInGroup(group, INTRODUCING_PARTNER_CODE);
        if (partnerCode == null) {
            partnerCode = TextInputField.builder().fieldId(INTRODUCING_PARTNER_CODE).build();
            group.getFields().add(partnerCode);
        }
        partnerCode.setIsActive(true);
        partnerCode.incrementOrder();
        partnerCode.setLabel("Introducing partner code (policy broker code)");
        partnerCode.setSelectedValue(WebformUtils.getWebFormFieldValueById(webForm, BROKER_IDENTIFIER_WF));
    }

    private void evaluatePartnerType(final Group group) {

        var partnerType = (SelectInputField) ChecklistUtils.getFieldInGroup(group, PARTNER_TYPE);
        if (partnerType == null) {
            partnerType = SelectInputField.builder().fieldId(PARTNER_TYPE).build();
            group.getFields().add(partnerType);
        }
        partnerType.setIsActive(true);
        partnerType.incrementOrder();
        partnerType.setLabel("Partner type");
        partnerType.setEnabled(true);
        partnerType.setMandatory(true);
        partnerType.setOptions(referenceDataRepositoryService.getReferenceDataOptionsByDomain(PARTNER_TYPE_DOMAIN));
    }

    private void evaluatePhRepresentative(final Group group, final Policy policy, final Map<String,List<String>> overallCaseRisk) {

        var phRepresentative = (SelectInputField) ChecklistUtils.getFieldInGroup(group, IS_PH_REPRESENTATIVE);
        if (phRepresentative == null) {
            phRepresentative = SelectInputField.builder().fieldId(IS_PH_REPRESENTATIVE).build();
            group.getFields().add(phRepresentative);
        }
        phRepresentative.setIsActive(true);
        phRepresentative.incrementOrder();
        phRepresentative.setLabel(
                "Is the PH/EBO a representative (Director/ Shareholder/ Sales Person) of the intermediary who intermediated the policy ?");
        phRepresentative.setMandatory(true);
        phRepresentative.setSourceSystem("Calculated based on Overall case risk");
        final var thirdParties = PolicyUtils.getThirdPartiesByRole(policy, Arrays.asList("HLR", "EBO"));
        final var isPhEboRepresentative = thirdParties.stream().map(AbstractPerson::getSourceOfFunds).filter(Objects::nonNull)
                .map(SourceOfFunds::getIsPHEBORepresentativeIntermediary).toList();
        var forcedValue = isPhEboRepresentative.stream().filter(Objects::nonNull).reduce(false, (a, b) -> a || b) ? YES : NO;
        final var hasEmptyRepresentative = isPhEboRepresentative.stream().anyMatch(Objects::isNull);
        if (hasEmptyRepresentative) {
            forcedValue = null;
            overallCaseRisk.get("BLOCKED").add("Please fill in the question Is the PH / EBO a representative … of the intermediary in CLASS");
        }
        phRepresentative.setSelectedValue(forcedValue);
        phRepresentative.setOptions(referenceDataRepositoryService.getReferenceDataOptionsByDomainAndSelectedValue(YES_NO_DOMAIN,
                phRepresentative.getSelectedValue()));
    }

    private void evaluateTCCSigned(final Group group, final ScreenDescription screenDescription) {

        var tccSigned = (SelectInputField) ChecklistUtils.getFieldInGroup(group, TCC_SIGNED);
        if (tccSigned == null) {
            tccSigned = SelectInputField.builder().fieldId(TCC_SIGNED).build();
            group.getFields().add(tccSigned);
        }
        tccSigned.setIsActive(true);
        tccSigned.incrementOrder();
        tccSigned.setLabel("TCC signed by PH+EBO");
        tccSigned.setEnabled(true);
        tccSigned.setMandatory(true);

        final var isPhDifferentToEbo =
                ChecklistUtils.getFieldById(screenDescription, PH_DIFFERENT_TO_EBO).map(Field::getSelectedValue).stream().anyMatch(YES::equals);
        tccSigned.setDisplayIf(Boolean.toString(isPhDifferentToEbo));
        tccSigned.setOptions(referenceDataRepositoryService.getReferenceDataOptionsByDomain(YES_NO_DOMAIN));

    }

    private void evaluateTCCInFolder(final Group group) {

        var tccInFolder = (SelectInputField) ChecklistUtils.getFieldInGroup(group, TCC_IN_FOLDER);
        if (tccInFolder == null) {
            tccInFolder = SelectInputField.builder().fieldId(TCC_IN_FOLDER).build();
            group.getFields().add(tccInFolder);
        }
        tccInFolder.setIsActive(true);
        tccInFolder.incrementOrder();
        tccInFolder.setLabel("TCC in folder from previous NB or ADD");
        tccInFolder.setEnabled(true);
        tccInFolder.setMandatory(true);
        tccInFolder.setOptions(referenceDataRepositoryService.getReferenceDataOptionsByDomain(YES_NO_DOMAIN));
    }

    private void evaluateNoInvestmentProfile(final Group group) {

        var noInvestmentProfile = (SelectInputField) ChecklistUtils.getFieldInGroup(group, NO_INVESTMENT_PROFILE);
        if (noInvestmentProfile == null) {
            noInvestmentProfile = SelectInputField.builder().fieldId(NO_INVESTMENT_PROFILE).build();
            group.getFields().add(noInvestmentProfile);
        }
        noInvestmentProfile.setIsActive(true);
        noInvestmentProfile.incrementOrder();
        noInvestmentProfile.setLabel("No investment profile or older than 2 years");
        noInvestmentProfile.setEnabled(true);
        noInvestmentProfile.setMandatory(true);
        noInvestmentProfile.setOptions(referenceDataRepositoryService.getReferenceDataOptionsByDomain(YES_NO_DOMAIN));
        noInvestmentProfile.setDisplayIf("#" + PARTNER_TYPE + "# == \"" + AGENT_EMPT_REFERENCE + "\" || #" + PARTNER_TYPE + "# == \""
                + AGENT_INT_REFERENCE + "\" || #" + PARTNER_TYPE + "# == \"" + AGENT_EXT_REFERENCE + "\"");
    }

    private void evaluateNewInvestmentProfile(final Group group) {

        var newInvestmentProfile = (SelectInputField) ChecklistUtils.getFieldInGroup(group, NEW_INVESTMENT_PROFILE);
        if (newInvestmentProfile == null) {
            newInvestmentProfile = SelectInputField.builder().fieldId(NEW_INVESTMENT_PROFILE).build();
            group.getFields().add(newInvestmentProfile);
        }
        newInvestmentProfile.setIsActive(true);
        newInvestmentProfile.incrementOrder();
        newInvestmentProfile.setLabel("New investment profile received");
        newInvestmentProfile.setEnabled(true);
        newInvestmentProfile.setMandatory(true);
        newInvestmentProfile.setOptions(referenceDataRepositoryService.getReferenceDataOptionsByDomain(YES_NO_DOMAIN));
        newInvestmentProfile.setDisplayIf("#" + PARTNER_TYPE + "# == \"" + AGENT_EMPT_REFERENCE + "\" || #" + PARTNER_TYPE + "# == \""
                + AGENT_INT_REFERENCE + "\" || #" + PARTNER_TYPE + "# == \"" + AGENT_EXT_REFERENCE + "\"");
    }

    private void evaluateNoSustainabilityPreference(final Group group) {

        var noSubPreference = (SelectInputField) ChecklistUtils.getFieldInGroup(group, NO_SUSTAINABILITY_PREFERENCE);
        if (noSubPreference == null) {
            noSubPreference = SelectInputField.builder().fieldId(NO_SUSTAINABILITY_PREFERENCE).build();
            group.getFields().add(noSubPreference);
        }
        noSubPreference.setIsActive(true);
        noSubPreference.incrementOrder();
        noSubPreference.setLabel("No ESG sustainability preference or older than 2 years");
        noSubPreference.setEnabled(true);
        noSubPreference.setMandatory(true);
        noSubPreference.setOptions(referenceDataRepositoryService.getReferenceDataOptionsByDomain(YES_NO_DOMAIN));
        noSubPreference.setDisplayIf("#" + PARTNER_TYPE + "# == \"" + AGENT_EMPT_REFERENCE + "\" || #" + PARTNER_TYPE + "# == \""
                + AGENT_INT_REFERENCE + "\" || #" + PARTNER_TYPE + "# == \"" + AGENT_EXT_REFERENCE + "\"");
    }

    private void evaluateNewSustainabilityPreference(final Group group) {

        var newSubPreference = (SelectInputField) ChecklistUtils.getFieldInGroup(group, NEW_SUSTAINABILITY_PREFERENCE);
        if (newSubPreference == null) {
            newSubPreference = SelectInputField.builder().fieldId(NEW_SUSTAINABILITY_PREFERENCE).build();
            group.getFields().add(newSubPreference);
        }
        newSubPreference.setIsActive(true);
        newSubPreference.incrementOrder();
        newSubPreference.setLabel("New ESG sustainability preference received");
        newSubPreference.setEnabled(true);
        newSubPreference.setMandatory(true);
        newSubPreference.setOptions(referenceDataRepositoryService.getReferenceDataOptionsByDomain(YES_NO_DOMAIN));
        newSubPreference.setDisplayIf("#" + PARTNER_TYPE + "# == \"" + AGENT_EMPT_REFERENCE + "\" || #" + PARTNER_TYPE + "# == \""
                + AGENT_INT_REFERENCE + "\" || #" + PARTNER_TYPE + "# == \"" + AGENT_EXT_REFERENCE + "\"");
    }
}
