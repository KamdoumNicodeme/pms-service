package com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control;

import java.util.Collections;
import java.util.List;

import org.springframework.stereotype.Service;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ControlDefinition;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.AbstractControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.utils.Constraint;
import com.lombardinternational.casemanagement.service.decision.domain.utils.FieldConstraint;

import static com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control.common.Constants.*;
import static com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control.common.Utils.*;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ChecklistFieldConstants.*;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ControlConstants.*;

@Service
public class RevertBackToCollectReasonControlBuilderService extends AbstractControlBuilderService {

    @Override
    public ControlDefinition buildControl(WebForm webForm, ScreenDescription screenDescription) {

        final List<FieldConstraint> constraints =
                List.of(createConstraintWithNegate(PH_TYPE_ASSESSMENT, Constraint.EQUALS, Collections.singletonList(PH_TYPE_PHYSIQUE), true),
                        createConstraint(PH_NON_FINANCIAL, Constraint.EQUALS, Collections.singletonList(YES)),
                        createConstraint(ENTITY_SAME_AS_FATCA, Constraint.EQUALS, Collections.singletonList(NO)));

        if (constraints.stream().allMatch(constraint -> constraint.test(screenDescription))) {
            return buildControlDefinition();
        }
        return null;
    }

    @Override
    protected String getControlName() {

        return REVERT_BACK_TO_COLLECT_REASON_NAME;
    }

    @Override
    protected String getControlType() {

        return REVERT_BACK_TO_COLLECT_REASON_TYPE;
    }
}
