package com.lombardinternational.casemanagement.service.decision.domain.service.control.addition.control;

import java.util.ArrayList;
import java.util.Collections;

import org.springframework.stereotype.Service;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ControlDefinition;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.AbstractControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.utils.Constraint;
import com.lombardinternational.casemanagement.service.decision.domain.utils.FieldConstraint;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ChecklistFieldConstants.*;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ControlConstants.*;

@Service
public class AeoiMrlControlBuilderService extends AbstractControlBuilderService {

    @Override
    public ControlDefinition buildControl(final WebForm webForm, final ScreenDescription screenDescription) {

        final var constraints = new ArrayList<FieldConstraint>();
        constraints
                .add(FieldConstraint.builder().fieldId(MRL_TRUSTEE).constraint(Constraint.EQUALS).values(Collections.singletonList(YES)).build());
        constraints.add(FieldConstraint.builder().fieldId(THIRD_PARTY_SUB_TYPE_FOR_PH).constraint(Constraint.EQUALS)
                .values(Collections.singletonList("Trust")).build());
        if (constraints.stream().allMatch(constraint -> constraint.test(screenDescription))) {
            return buildControlDefinition();
        }
        return null;
    }

    @Override
    public String getControlName() {

        return AEOI_MRL_NAME;
    }

    @Override
    public String getControlType() {

        return AEOI_MRL_TYPE;
    }
}
