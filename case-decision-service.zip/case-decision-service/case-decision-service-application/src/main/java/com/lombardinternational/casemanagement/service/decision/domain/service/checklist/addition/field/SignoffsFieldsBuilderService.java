package com.lombardinternational.casemanagement.service.decision.domain.service.checklist.addition.field;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.lombardinternational.casemanagement.service.decision.domain.model.policy.Policy;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Field;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Group;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.SelectInputField;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.TextAreaField;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.TextInputField;
import com.lombardinternational.casemanagement.service.decision.domain.model.transaction.BusinessTransaction;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.checklist.FieldBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.spi.repository.ReferenceDataRepositoryService;
import com.lombardinternational.casemanagement.service.decision.domain.utils.ChecklistUtils;

import lombok.AllArgsConstructor;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ChecklistFieldConstants.*;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ReferenceConstants.*;

@Service
@AllArgsConstructor
public class SignoffsFieldsBuilderService implements FieldBuilderService {

    private final ReferenceDataRepositoryService referenceDataRepositoryService;

    private static final DateTimeFormatter EUROPEAN_DATE_FORMATTER = DateTimeFormatter.ofPattern("dd/MM/yyyy");

    @Override
    public void buildField(final WebForm webForm, final ScreenDescription screenDescription, final Group group, final Policy policy,
            final BusinessTransaction transaction, final Map<String,List<String>> overallCaseRisk) {

        Field.resetFieldId();
        evaluateTransactionFeedback(group);
        evaluateComments(group);
        evaluateLastReviewDate(group, policy);
        evaluateBacApprovalReceivedPreviously(group);
    }

    private void evaluateTransactionFeedback(final Group group) {

        var transactionFeedback = (SelectInputField) ChecklistUtils.getFieldInGroup(group, TRANSACTION_FEEDBACK);
        if (transactionFeedback == null) {
            transactionFeedback = SelectInputField.builder().fieldId(TRANSACTION_FEEDBACK).build();
            group.getFields().add(transactionFeedback);
        }
        transactionFeedback.setIsActive(true);
        transactionFeedback.incrementOrder();
        transactionFeedback.setLabel("Transaction feedback");
        transactionFeedback.setEnabled(true);
        transactionFeedback.setMandatory(true);
        transactionFeedback.setOptions(referenceDataRepositoryService.getReferenceDataOptionsByDomain(TRANSACTION_FEEDBACK_DOMAIN));
    }

    private void evaluateComments(final Group group) {

        var comments = (TextAreaField) ChecklistUtils.getFieldInGroup(group, COMMENTS);
        if (comments == null) {
            comments = TextAreaField.builder().fieldId(COMMENTS).build();
            group.getFields().add(comments);
        }
        comments.setIsActive(true);
        comments.incrementOrder();
        comments.setLabel("Comments");
        comments.setEnabled(true);
    }

    private void evaluateLastReviewDate(final Group group, final Policy policy) {

        var lastReviewDate = (TextInputField) ChecklistUtils.getFieldInGroup(group, LAST_REVIEW_DATE);
        if (lastReviewDate == null) {
            lastReviewDate = TextInputField.builder().fieldId(LAST_REVIEW_DATE).build();
            group.getFields().add(lastReviewDate);
        }
        lastReviewDate.setIsActive(true);
        lastReviewDate.incrementOrder();
        lastReviewDate.setLabel("Last review date");

        lastReviewDate.setSelectedValue(
                policy.getLastReviewDate() != null ? LocalDate.parse(policy.getLastReviewDate()).format(EUROPEAN_DATE_FORMATTER) : "N/A");
    }

    private void evaluateBacApprovalReceivedPreviously(final Group group) {

        var bacApprovalReceivedPreviously = (SelectInputField) ChecklistUtils.getFieldInGroup(group, BAC_APPROVAL);
        if (bacApprovalReceivedPreviously == null) {
            bacApprovalReceivedPreviously = SelectInputField.builder().fieldId(BAC_APPROVAL).build();
            group.getFields().add(bacApprovalReceivedPreviously);
        }
        bacApprovalReceivedPreviously.setIsActive(true);
        bacApprovalReceivedPreviously.incrementOrder();
        bacApprovalReceivedPreviously.setLabel("BAC approval received previously");
        bacApprovalReceivedPreviously.setEnabled(true);
        bacApprovalReceivedPreviously.setMandatory(true);
        bacApprovalReceivedPreviously.setOptions(referenceDataRepositoryService.getReferenceDataOptionsByDomain(YES_NO_DOMAIN));
    }
}
