package com.lombardinternational.casemanagement.service.decision.domain.service.checklist.addition.risk;

import java.util.*;

import org.springframework.stereotype.Service;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.transaction.BusinessTransaction;
import com.lombardinternational.casemanagement.service.decision.domain.service.checklist.RiskValueBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.checklist.common.risk.*;
import com.lombardinternational.casemanagement.service.decision.domain.utils.constants.CaseRisk;

import lombok.AllArgsConstructor;

@Service
@AllArgsConstructor
public class RiskValueAdditionBuilderService implements RiskValueBuilderService {

    @Override
    public String computeRiskValueRules(final ScreenDescription screenDescription, final BusinessTransaction transaction,
            final Map<String,List<String>> overallCaseRisk) {

        Set<CaseRisk> compute = new HashSet<>();
        compute.add(PremiumThresholdRisk.premiumThreshold(screenDescription, overallCaseRisk));
        compute.add(PepRisk.pep(screenDescription, transaction, overallCaseRisk));
        compute.add(StrRisk.str(screenDescription, overallCaseRisk));
        compute.add(CountryOfWealthRisk.countryOfWealth(screenDescription, transaction, overallCaseRisk));
        compute.add(IndustrySectorRisk.industrySector(transaction, overallCaseRisk));
        compute.add(IntermediaryPhEboRisk.intermediaryPhEbo(screenDescription, overallCaseRisk));
        compute.add(OffShoreIndiciaRisk.offshoreIndicia(screenDescription, overallCaseRisk));
        compute.add(PaymentOutsideTaxCountryRisk.paymentOutsideTaxCountry(screenDescription, overallCaseRisk));
        compute.add(SanctionListRisk.sanctionList(screenDescription, transaction, overallCaseRisk));
        compute.add(PhTypeRisk.phType(screenDescription, transaction, overallCaseRisk));
        compute.add(GoldenVisaRisk.goldenVisa(screenDescription, transaction, overallCaseRisk));
        compute.add(MediaCoverageRisk.mediaCoverage(screenDescription, overallCaseRisk));
        compute.add(MissingOriginPremiumBlock.missingOriginPremiumBlock(screenDescription, overallCaseRisk));
        compute.add(DistributionRisk.distribution(transaction, overallCaseRisk));
        compute.add(PayerPayeeBankCountryRisk.payerPayee(screenDescription, transaction, overallCaseRisk));
        compute.add(CountryResidenceRisk.residence(transaction, overallCaseRisk));
        compute.add(ThirdPartyPayerRisk.thirdPartyPayer(screenDescription, transaction, overallCaseRisk));
        compute.add(PremiumNaturalPersonRisk.premiumNaturalPerson(screenDescription, transaction, overallCaseRisk));
        compute.add(ThirdPartyPaymentNoEvidenceRisk.thirdPartyPaymentNoEvidence(screenDescription, overallCaseRisk));
        // Filter by MaxValue to return highest escalation
        CaseRisk caseRisk = compute.stream().max(Comparator.comparing(CaseRisk::getOrder)).get();
        return caseRisk.getValue();
    }
}
