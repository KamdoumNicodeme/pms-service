package com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control;

import java.util.List;

import org.springframework.stereotype.Service;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ControlDefinition;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.AbstractControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.utils.Constraint;
import com.lombardinternational.casemanagement.service.decision.domain.utils.FieldConstraint;

import static com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control.common.Constants.COMPANY;
import static com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control.common.Constants.TRADING_COMPANY;
import static com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control.common.Utils.createConstraintWithMultiple;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ChecklistFieldConstants.THIRD_PARTY_SUB_TYPE_PH;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ControlConstants.COPY_ID_AUTH_SIGNATORIES_NAME_NBD;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ControlConstants.COPY_ID_AUTH_SIGNATORIES_TYPE;

@Service
public class CopyIdAuthSignatoriesControlBuilderService extends AbstractControlBuilderService {

    @Override
    public ControlDefinition buildControl(WebForm webForm, ScreenDescription screenDescription) {

        List<String> compagnyAndTradingCompagny = List.of(COMPANY, TRADING_COMPANY);
        final List<FieldConstraint> constraints = compagnyAndTradingCompagny.stream()
                .map(value -> createConstraintWithMultiple(THIRD_PARTY_SUB_TYPE_PH, Constraint.IN, Boolean.TRUE, List.of(value))).toList();

        if (constraints.stream().anyMatch(constraint -> constraint.test(screenDescription))) {
            return buildControlDefinition();
        }
        return null;
    }

    @Override
    protected String getControlName() {

        return COPY_ID_AUTH_SIGNATORIES_NAME_NBD;
    }

    @Override
    protected String getControlType() {

        return COPY_ID_AUTH_SIGNATORIES_TYPE;
    }
}
