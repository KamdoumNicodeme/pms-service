package com.lombardinternational.casemanagement.service.decision.domain.service.control.addition.control;

import org.springframework.stereotype.Service;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ControlDefinition;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.AbstractControlBuilderService;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ControlConstants.*;

@Service
public class KycSignedControlBuilderService extends AbstractControlBuilderService {

    @Override
    public ControlDefinition buildControl(WebForm webForm, ScreenDescription screenDescription) {

        return buildControlDefinition();
    }

    @Override
    protected String getControlName() {

        return KYC_SIGNED_NAME;
    }

    @Override
    protected String getControlType() {

        return KYC_SIGNED_TYPE;
    }
}
