package com.lombardinternational.casemanagement.service.decision.domain.service.checklist.common.risk;

import java.util.List;
import java.util.Map;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Field;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.transaction.BusinessTransaction;
import com.lombardinternational.casemanagement.service.decision.domain.utils.ChecklistUtils;
import com.lombardinternational.casemanagement.service.decision.domain.utils.constants.CaseRisk;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.RulesUtils.*;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ChecklistFieldConstants.*;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.RulesConstants.*;

public class PhTypeRisk {

    public static CaseRisk phType(final ScreenDescription screenDescription, final BusinessTransaction transaction,
            final Map<String,List<String>> overallCaseRisk) {

        String phTypeRiskLevel = getRiskFactorLevel(transaction, INT_RF_014);
        String phTypeAssessment = ChecklistUtils.getFieldById(screenDescription, PH_TYPE_ASSESSMENT).map(Field::getSelectedValue).orElse(null);

        if (phTypeAssessment != null && !phTypeAssessment.isBlank()) {
            if (HIGH.equalsIgnoreCase(phTypeRiskLevel)) {
                overallCaseRisk.get(HIGH).add("PH Type");
                return CaseRisk.CASE_RISK_HIGH;
            } else if (MEDIUM.equalsIgnoreCase(phTypeRiskLevel)) {
                return CaseRisk.CASE_RISK_MEDIUM;
            }
        }
        return CaseRisk.CASE_RISK_STANDARD;

    }
}
