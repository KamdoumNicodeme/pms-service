package com.lombardinternational.casemanagement.service.decision.domain.service.control.addition.control;

import java.util.List;

import org.springframework.stereotype.Service;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ControlDefinition;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.AbstractControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.utils.ControlUtils;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ControlConstants.*;

@Service
public class DeviationSuitabilityProfileControlBuilderService extends AbstractControlBuilderService {

    private static final List<String> markets = List.of("BE", "DE", "NO");

    @Override
    public ControlDefinition buildControl(WebForm webForm, ScreenDescription screenDescription) {

        final var constraints = ControlUtils.verifyPhEboLaResidenceCountryOnMarkets(markets, true);
        if (constraints.stream().anyMatch(constraint -> constraint.test(screenDescription))) {
            return buildControlDefinition();
        }
        return null;
    }

    @Override
    protected String getControlName() {

        return DEVIATION_SUITABILITY_PROFILE_NAME;
    }

    @Override
    protected String getControlType() {

        return DEVIATION_SUITABILITY_PROFILE_TYPE;
    }
}
