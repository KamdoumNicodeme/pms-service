package com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control;

import java.util.Collections;
import java.util.List;

import org.springframework.stereotype.Service;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ControlDefinition;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.AbstractControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.utils.Constraint;
import com.lombardinternational.casemanagement.service.decision.domain.utils.FieldConstraint;

import static com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control.common.Utils.createConstraintWithMultiple;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ChecklistFieldConstants.ACCOUNT_OPENED_IN_EEA;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ControlConstants.EEA_DECLARATION_RECEIVED_NAME;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ControlConstants.EEA_DECLARATION_RECEIVED_TYPE;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ControlConstants.NO;

@Service
public class EeaDeclarationReceivedControlBuilderService extends AbstractControlBuilderService {

    @Override
    public ControlDefinition buildControl(WebForm webForm, ScreenDescription screenDescription) {

        final List<FieldConstraint> constraints =
                List.of(createConstraintWithMultiple(ACCOUNT_OPENED_IN_EEA, Constraint.IN, Boolean.TRUE, Collections.singletonList(NO)));

        if (constraints.stream().allMatch(constraint -> constraint.test(screenDescription))) {
            return buildControlDefinition();
        }
        return null;
    }

    @Override
    protected String getControlName() {

        return EEA_DECLARATION_RECEIVED_NAME;
    }

    @Override
    protected String getControlType() {

        return EEA_DECLARATION_RECEIVED_TYPE;
    }
}
