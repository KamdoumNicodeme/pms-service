package com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control;

import java.util.List;

import org.springframework.stereotype.Service;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ControlDefinition;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.AbstractControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.utils.Constraint;
import com.lombardinternational.casemanagement.service.decision.domain.utils.FieldConstraint;

import static com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control.common.Utils.*;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ChecklistFieldConstants.*;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ControlConstants.*;

@Service
public class AnalysisNeedsReceivedSignedControlBuilderService extends AbstractControlBuilderService {

    private static final String AGENT_EMP = "AGENT_EMP";
    private static final String AGENT_IND = "AGENT_IND";
    private static final String AGENT_EXT = "AGENT_EXT";

    @Override
    public ControlDefinition buildControl(WebForm webForm, ScreenDescription screenDescription) {

        final List<FieldConstraint> constraints = List.of(createConstraint(PARTNER_TYPE, Constraint.IN, List.of(AGENT_EMP, AGENT_IND, AGENT_EXT)));

        if (constraints.stream().allMatch(constraint -> constraint.test(screenDescription))) {
            return buildControlDefinition();
        }
        return null;
    }

    @Override
    protected String getControlName() {

        return ANALYSIS_NEEDS_RECEIVED_SIGNED_NAME;
    }

    @Override
    protected String getControlType() {

        return ANALYSIS_NEEDS_RECEIVED_SIGNED_TYPE;
    }
}
