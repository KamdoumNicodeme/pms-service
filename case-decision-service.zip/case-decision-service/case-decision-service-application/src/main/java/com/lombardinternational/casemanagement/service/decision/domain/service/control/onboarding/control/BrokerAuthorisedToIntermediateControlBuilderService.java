package com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control;

import java.util.Collections;
import java.util.List;
import java.util.stream.Stream;

import org.springframework.stereotype.Service;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ControlDefinition;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.AbstractControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.utils.Constraint;
import com.lombardinternational.casemanagement.service.decision.domain.utils.FieldConstraint;

import static com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control.common.Utils.createConstraintWithNegate;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ChecklistFieldConstants.COUNTRY_OF_LAW;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ChecklistFieldConstants.PH_FISCAL_COUNTRY;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ControlConstants.BROKER_AUTHORISED_TO_INTERMEDIATE_NAME;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ControlConstants.BROKER_AUTHORISED_TO_INTERMEDIATE_TYPE;

@Service
public class BrokerAuthorisedToIntermediateControlBuilderService extends AbstractControlBuilderService {

    @Override
    public ControlDefinition buildControl(WebForm webForm, ScreenDescription screenDescription) {

        final List<FieldConstraint> constraints =
                List.of(createConstraintWithNegate(PH_FISCAL_COUNTRY, Constraint.CONTAINS, Collections.singletonList("UK"), false),
                        createConstraintWithNegate(COUNTRY_OF_LAW, Constraint.IN, Collections.singletonList("UK"), true));

        final List<FieldConstraint> constraints2 =
                List.of(createConstraintWithNegate(PH_FISCAL_COUNTRY, Constraint.CONTAINS, Collections.singletonList("UK"), true),
                        createConstraintWithNegate(COUNTRY_OF_LAW, Constraint.IN, Collections.singletonList("UK"), false));

        if (Stream.of(constraints, constraints2).anyMatch(group -> group.stream().allMatch(constraint -> constraint.test(screenDescription)))) {
            return buildControlDefinition();
        }
        return null;
    }

    @Override
    protected String getControlName() {

        return BROKER_AUTHORISED_TO_INTERMEDIATE_NAME;
    }

    @Override
    protected String getControlType() {

        return BROKER_AUTHORISED_TO_INTERMEDIATE_TYPE;
    }
}
