package com.lombardinternational.casemanagement.service.decision.adapter.api.web.rest.dto.webform;

import java.util.List;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class WebFormGroupDTO {

    private String groupId;
    private String title;
    private String i18NTitleKey;
    private String type;
    private List<BigDecimalWebFormFieldDTO> bigDecimalFields;
    private List<BooleanWebFormFieldDTO> booleanFields;
    private List<TextWebFormFieldDTO> textFields;
    private List<CalendarWebFormFieldDTO> calendarFields;
    private List<WebFormGroupDTO> groups;
}
