package com.lombardinternational.casemanagement.service.decision.domain.service.control.addition.control;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.springframework.stereotype.Service;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ControlDefinition;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.AbstractControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.utils.Constraint;
import com.lombardinternational.casemanagement.service.decision.domain.utils.FieldConstraint;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ChecklistFieldConstants.*;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ControlConstants.*;

@Service
public class BrokerAuthorisedInPhCountryControlBuilderService extends AbstractControlBuilderService {

    private static final List<String> markets = Arrays.asList("AT", "BE", "BG", "CY", "CZ", "DE", "DK", "EE", "ES", "FI", "FR", "GB", "GR", "HU",
            "IE", "IS", "IT", "LI", "LT", "LU", "LV", "MT", "NL", "NO", "PL", "PT", "RO", "SE", "SI", "SK");

    @Override
    public ControlDefinition buildControl(WebForm webForm, ScreenDescription screenDescription) {

        final var constraints = new ArrayList<FieldConstraint>();
        constraints.add(
                FieldConstraint.builder().fieldId(FORM_SIGNER).constraint(Constraint.EQUALS).values(Collections.singletonList("BROKER")).build());
        constraints.add(FieldConstraint.builder().fieldId(COUNTRY_OF_APPLICABLE_LAW).constraint(Constraint.IN).values(markets).build());
        if (constraints.stream().allMatch(constraint -> constraint.test(screenDescription))) {
            return buildControlDefinition();
        }
        return null;
    }

    @Override
    protected String getControlName() {

        return BROKER_AUTHORISED_IN_PH_COUNTRY_NAME;
    }

    @Override
    protected String getControlType() {

        return BROKER_AUTHORISED_IN_PH_COUNTRY_TYPE;
    }
}
