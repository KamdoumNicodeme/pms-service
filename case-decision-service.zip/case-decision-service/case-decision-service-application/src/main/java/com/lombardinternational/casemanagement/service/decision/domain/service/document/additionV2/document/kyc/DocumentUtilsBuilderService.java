package com.lombardinternational.casemanagement.service.decision.domain.service.document.additionV2.document.kyc;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Service;

import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebFormGroup;
import com.lombardinternational.casemanagement.service.decision.domain.service.document.AbstractDocumentBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.utils.WebformUtils;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.WebFormFieldConstants.DETAILS_WF;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.WebFormFieldConstants.EBO_KYCS_WF;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.WebFormFieldConstants.EBO_TYPE_ENTITY;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.WebFormFieldConstants.EBO_TYPE_GLOBAL_LIST;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.WebFormFieldConstants.EBO_TYPE_WF;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.WebFormFieldConstants.KYC_WF;

@Service
public abstract class DocumentUtilsBuilderService extends AbstractDocumentBuilderService {

    protected List<WebFormGroup> getEboKycs(WebForm webForm, boolean isEntity) {
        var groups = new ArrayList<WebFormGroup>();
        var kyc = WebformUtils.getFirstWebFormGroupById(webForm, KYC_WF);
        if (kyc == null || CollectionUtils.isEmpty(kyc.getGroups())) {
            return groups;
        }
        var details = WebformUtils.getGroupInGroup(kyc, DETAILS_WF);
        if (details != null && CollectionUtils.isNotEmpty(details.getGroups())) {
            var ebosKycs = WebformUtils.getGroupInGroup(details, EBO_KYCS_WF);
            if (ebosKycs != null && CollectionUtils.isNotEmpty(ebosKycs.getGroups())) {
                for (WebFormGroup eboKycGroup : ebosKycs.getGroups()) {
                    var eboType = WebformUtils.getWebFormFieldValueById(eboKycGroup, EBO_TYPE_WF);
                    if (isEntity && EBO_TYPE_ENTITY.equalsIgnoreCase(eboType)) {
                        groups.add(eboKycGroup);
                    } else if (!isEntity && EBO_TYPE_GLOBAL_LIST.contains(eboType)) {
                        groups.add(eboKycGroup);
                    }
                }
            }
        }
        return groups;
    }
}
