package com.lombardinternational.casemanagement.service.decision.domain.service.checklist.common.risk;

import java.util.List;
import java.util.Map;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.transaction.BusinessTransaction;
import com.lombardinternational.casemanagement.service.decision.domain.utils.ChecklistUtils;
import com.lombardinternational.casemanagement.service.decision.domain.utils.constants.CaseRisk;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.RulesUtils.*;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ChecklistFieldConstants.*;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.RulesConstants.*;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class PayerPayeeBankCountryRisk {

    public static CaseRisk payerPayee(final ScreenDescription screenDescription, final BusinessTransaction transaction,
            final Map<String,List<String>> overallCaseRisk) {

        var originatingAccountsRiskField = ChecklistUtils.getFieldById(screenDescription, COUNTRY_OF_ORIGINATING_ACCOUNTS_RISK);

        if (originatingAccountsRiskField.isPresent() && originatingAccountsRiskField.get().getSelectedValue() != null) {

            String payerRiskLevel = getRiskFactorLevel(transaction, INT_RF_012);

            return switch (payerRiskLevel.toUpperCase()) {
            case HIGH -> {
                overallCaseRisk.get(HIGH).add("Payer / Payee bank country");
                yield CaseRisk.CASE_RISK_HIGH;
            }
            case MEDIUM -> CaseRisk.CASE_RISK_MEDIUM;
            default -> CaseRisk.CASE_RISK_STANDARD;
            };
        }
        return CaseRisk.CASE_RISK_STANDARD;
    }
}
