package com.lombardinternational.casemanagement.service.decision.domain.service.checklist.common.risk;

import java.util.List;
import java.util.Map;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Field;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.transaction.BusinessTransaction;
import com.lombardinternational.casemanagement.service.decision.domain.utils.ChecklistUtils;
import com.lombardinternational.casemanagement.service.decision.domain.utils.constants.CaseRisk;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.RulesUtils.*;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ChecklistFieldConstants.*;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.RulesConstants.*;

public class PepRisk {

    public static CaseRisk pep(final ScreenDescription screenDescription, final BusinessTransaction transaction,
            final Map<String,List<String>> overallCaseRisk) {

        String pepStatusData = getRiskFactorData(transaction, INT_RF_005);
        if (YES.equals(ChecklistUtils.getFieldById(screenDescription, ORIGINATOR_PEP).map(Field::getSelectedValue).orElse(null))) {
            overallCaseRisk.get(HIGH).add("PEP");
            return CaseRisk.CASE_RISK_HIGH;
        }
        if (pepStatusData.toUpperCase().startsWith("MISSING")) {
            overallCaseRisk.get(BLOCKED).add(pepStatusData);
        } else {
            if (YES.equals(ChecklistUtils.getFieldById(screenDescription, PEP).map(Field::getSelectedValue).orElse(null))
                    || YES.equals(ChecklistUtils.getFieldById(screenDescription, IS_PEP_PAYER).map(Field::getSelectedValue).orElse(null))) {
                overallCaseRisk.get(HIGH).add("PEP");
                return CaseRisk.CASE_RISK_HIGH;
            }
        }
        return CaseRisk.CASE_RISK_STANDARD;
    }
}
