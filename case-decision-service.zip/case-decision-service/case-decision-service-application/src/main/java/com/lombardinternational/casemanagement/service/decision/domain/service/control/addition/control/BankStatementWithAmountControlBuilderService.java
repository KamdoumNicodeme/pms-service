package com.lombardinternational.casemanagement.service.decision.domain.service.control.addition.control;

import java.util.ArrayList;
import java.util.Collections;

import org.springframework.stereotype.Service;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ControlDefinition;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.AbstractControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.utils.Constraint;
import com.lombardinternational.casemanagement.service.decision.domain.utils.FieldConstraint;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ChecklistFieldConstants.LINK_THIRD_PARTY_PH;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ControlConstants.BANK_STATEMENT_WITH_AMOUNT_NAME;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ControlConstants.BANK_STATEMENT_WITH_AMOUNT_TYPE;

@Service
public class BankStatementWithAmountControlBuilderService extends AbstractControlBuilderService {

    @Override
    public ControlDefinition buildControl(final WebForm webForm, final ScreenDescription screenDescription) {

        final var constraints = new ArrayList<FieldConstraint>();
        constraints.add(FieldConstraint.builder().fieldId(LINK_THIRD_PARTY_PH).multiple(true).constraint(Constraint.EQUALS)
                .values(Collections.singletonList("transf_comp")).build());
        if (constraints.stream().allMatch(constraint -> constraint.test(screenDescription))) {
            return buildControlDefinition();
        }
        return null;
    }

    @Override
    public String getControlName() {

        return BANK_STATEMENT_WITH_AMOUNT_NAME;
    }

    @Override
    public String getControlType() {

        return BANK_STATEMENT_WITH_AMOUNT_TYPE;
    }
}
