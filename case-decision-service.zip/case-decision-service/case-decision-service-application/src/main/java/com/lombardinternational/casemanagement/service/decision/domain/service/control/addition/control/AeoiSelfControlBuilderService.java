package com.lombardinternational.casemanagement.service.decision.domain.service.control.addition.control;

import java.util.ArrayList;
import java.util.Collections;

import org.springframework.stereotype.Service;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ControlDefinition;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.AbstractControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.utils.Constraint;
import com.lombardinternational.casemanagement.service.decision.domain.utils.FieldConstraint;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ChecklistFieldConstants.MRL_TRUSTEE;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ChecklistFieldConstants.PROXY;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ChecklistFieldConstants.THIRD_PARTY_SUB_TYPE_FOR_PH;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ControlConstants.AEOI_SELF_NAME;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ControlConstants.AEOI_SELF_TYPE;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ControlConstants.YES;

@Service(value = "additionAeoiSelfControlBuilderService")
public class AeoiSelfControlBuilderService extends AbstractControlBuilderService {

    @Override
    public ControlDefinition buildControl(final WebForm webForm, final ScreenDescription screenDescription) {

        final var constraints1 = new ArrayList<FieldConstraint>();
        constraints1.add(FieldConstraint.builder().fieldId(THIRD_PARTY_SUB_TYPE_FOR_PH).constraint(Constraint.EQUALS)
                .values(Collections.singletonList("Individual")).build());

        final var constraints2 = new ArrayList<FieldConstraint>();
        constraints2
                .add(FieldConstraint.builder().fieldId(MRL_TRUSTEE).constraint(Constraint.EQUALS).values(Collections.singletonList(YES)).build());
        constraints2.add(FieldConstraint.builder().fieldId(THIRD_PARTY_SUB_TYPE_FOR_PH).constraint(Constraint.EQUALS)
                .values(Collections.singletonList("Trust")).build());

        final var constraints3 = new ArrayList<FieldConstraint>();
        constraints3.add(FieldConstraint.builder().fieldId(PROXY).constraint(Constraint.EQUALS).values(Collections.singletonList(YES)).build());
        if (constraints1.stream().allMatch(constraint -> constraint.test(screenDescription))
                || constraints2.stream().allMatch(constraint -> constraint.test(screenDescription))
                || constraints3.stream().allMatch(constraint -> constraint.test(screenDescription))) {
            return buildControlDefinition();
        }
        return null;
    }

    @Override
    public String getControlName() {

        return AEOI_SELF_NAME;
    }

    @Override
    public String getControlType() {

        return AEOI_SELF_TYPE;
    }
}
