package com.lombardinternational.casemanagement.service.decision.domain.service.control.addition.control;

import java.util.ArrayList;
import java.util.Arrays;

import org.springframework.stereotype.Service;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ControlDefinition;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.AbstractControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.utils.Constraint;
import com.lombardinternational.casemanagement.service.decision.domain.utils.FieldConstraint;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ChecklistFieldConstants.*;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ControlConstants.*;

@Service
public class RejectionProcedureControlBuilderService extends AbstractControlBuilderService {

    @Override
    public ControlDefinition buildControl(final WebForm webForm, final ScreenDescription screenDescription) {

        final var constraints = new ArrayList<FieldConstraint>();
        constraints.add(FieldConstraint.builder().fieldId(TRANSACTION_FEEDBACK).constraint(Constraint.IN)
                .values(Arrays.asList("REJECTED", "REJECTED_AML")).build());
        if (constraints.stream().allMatch(constraint -> constraint.test(screenDescription))) {
            return buildControlDefinition();
        }
        return null;
    }

    @Override
    public String getControlName() {

        return REJECTION_PROCEDURE_NAME;
    }

    @Override
    public String getControlType() {

        return REJECTION_PROCEDURE_TYPE;
    }
}
