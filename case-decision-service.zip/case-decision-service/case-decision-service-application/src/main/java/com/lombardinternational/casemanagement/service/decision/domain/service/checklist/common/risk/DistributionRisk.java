package com.lombardinternational.casemanagement.service.decision.domain.service.checklist.common.risk;

import java.util.List;
import java.util.Map;

import com.lombardinternational.casemanagement.service.decision.domain.model.transaction.BusinessTransaction;
import com.lombardinternational.casemanagement.service.decision.domain.utils.RulesUtils;
import com.lombardinternational.casemanagement.service.decision.domain.utils.constants.CaseRisk;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.RulesConstants.*;

public class DistributionRisk {

    public static CaseRisk distribution(final BusinessTransaction transaction, final Map<String,List<String>> overallCaseRisk) {

        String riskFactorLevel = RulesUtils.getRiskFactorLevel(transaction, INT_RF_010);
        if (HIGH.equalsIgnoreCase(riskFactorLevel)) {
            overallCaseRisk.get(HIGH).add("Distribution Risk");
            return CaseRisk.CASE_RISK_HIGH;
        }
        return CaseRisk.CASE_RISK_STANDARD;
    }
}
