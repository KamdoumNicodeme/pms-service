package com.lombardinternational.casemanagement.service.decision.domain.service.checklist.addition.group;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.lombardinternational.casemanagement.service.decision.domain.model.policy.Policy;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Group;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Tab;
import com.lombardinternational.casemanagement.service.decision.domain.model.transaction.BusinessTransaction;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.checklist.GroupBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.checklist.addition.field.IntermediationFieldsBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.utils.RulesUtils;

import lombok.AllArgsConstructor;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ChecklistFieldConstants.*;

@Service
@AllArgsConstructor
public class IntermediationAdditionGroupBuilderService implements GroupBuilderService {

    private final IntermediationFieldsBuilderService intermediationFieldsBuilderService;

    @Override
    public void buildGroup(final WebForm webForm, final ScreenDescription screenDescription, final Tab parentTab, final Policy policy,
            final BusinessTransaction business, final Map<String,List<String>> overallCaseRisk) {

        var intermediation = RulesUtils.getGroupInTab(parentTab, INTERMEDIATION_GROUP);
        if (intermediation == null) {
            intermediation = Group.builder().groupId(INTERMEDIATION_GROUP).build();
            parentTab.getGroups().add(intermediation);
        }
        intermediation.setIsActive(true);
        intermediation.incrementOrder();
        intermediation.setTitle("Intermediation");
        intermediationFieldsBuilderService.buildField(webForm, screenDescription, intermediation, policy, business, overallCaseRisk);
    }
}
