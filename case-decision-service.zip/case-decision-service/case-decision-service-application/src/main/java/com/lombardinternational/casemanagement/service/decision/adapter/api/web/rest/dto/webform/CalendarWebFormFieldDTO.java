package com.lombardinternational.casemanagement.service.decision.adapter.api.web.rest.dto.webform;

import java.time.LocalDate;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder
@NoArgsConstructor
@EqualsAndHashCode(callSuper = true)
public class CalendarWebFormFieldDTO extends WebFormFieldDTO {

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "[yyyy-MM-dd'T'HH:mm:ss.SSSz][yyyy-MM-dd]")
    private LocalDate value;
}
