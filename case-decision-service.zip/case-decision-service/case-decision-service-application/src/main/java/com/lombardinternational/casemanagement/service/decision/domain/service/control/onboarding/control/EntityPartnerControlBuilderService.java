package com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control;

import java.util.Collections;
import java.util.List;

import org.springframework.stereotype.Service;

import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ControlDefinition;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.control.AbstractControlBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.utils.Constraint;
import com.lombardinternational.casemanagement.service.decision.domain.utils.FieldConstraint;

import static com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control.common.Constants.BROK_ACCO;
import static com.lombardinternational.casemanagement.service.decision.domain.service.control.onboarding.control.common.Utils.createConstraintWithMultipleAndExactMatch;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ChecklistFieldConstants.LINK_THIRD_PARTY_PH;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ControlConstants.ENTITY_PARTNER_NAME;
import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ControlConstants.ENTITY_PARTNER_TYPE;

@Service(value = "onboardingEntityPartnerControlBuilderService")
public class EntityPartnerControlBuilderService extends AbstractControlBuilderService {

    @Override
    public ControlDefinition buildControl(final WebForm webForm, final ScreenDescription screenDescription) {

        final List<FieldConstraint> constraints = List.of(createConstraintWithMultipleAndExactMatch(LINK_THIRD_PARTY_PH, Constraint.IN,
                Boolean.TRUE, Boolean.FALSE, Collections.singletonList(BROK_ACCO)));

        if (constraints.stream().allMatch(constraint -> constraint.test(screenDescription))) {
            return buildControlDefinition();
        }
        return null;
    }

    @Override
    public String getControlName() {

        return ENTITY_PARTNER_NAME;
    }

    @Override
    public String getControlType() {

        return ENTITY_PARTNER_TYPE;
    }
}
