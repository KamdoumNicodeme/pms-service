package com.lombardinternational.casemanagement.service.decision.domain.service.checklist.rop.group;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.lombardinternational.casemanagement.service.decision.domain.model.policy.Policy;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Group;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.ScreenDescription;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Tab;
import com.lombardinternational.casemanagement.service.decision.domain.model.transaction.BusinessTransaction;
import com.lombardinternational.casemanagement.service.decision.domain.model.webform.WebForm;
import com.lombardinternational.casemanagement.service.decision.domain.service.checklist.GroupBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.service.checklist.rop.field.CaseRisksRopFieldsBuilderService;
import com.lombardinternational.casemanagement.service.decision.domain.utils.RulesUtils;

import lombok.AllArgsConstructor;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ChecklistFieldConstants.*;

@Service
@AllArgsConstructor
public class CaseRiskRopGroupBuilderService implements GroupBuilderService {

    private final CaseRisksRopFieldsBuilderService caseRisksRopFieldsBuilderService;

    @Override
    public void buildGroup(final WebForm webForm, final ScreenDescription screenDescription, final Tab parentTab, final Policy policy,
            final BusinessTransaction transaction, final Map<String,List<String>> overallCaseRisk) {

        var caseRisk = RulesUtils.getGroupInTab(parentTab, CASE_RISK_GROUP);
        if (caseRisk == null) {
            caseRisk = Group.builder().groupId(CASE_RISK_GROUP).build();
            parentTab.getGroups().add(caseRisk);
        }
        caseRisk.setIsActive(true);
        caseRisk.incrementOrder();
        caseRisk.setTitle("Escalation level");
        caseRisksRopFieldsBuilderService.buildField(webForm, screenDescription, caseRisk, policy, transaction, overallCaseRisk);
    }
}
