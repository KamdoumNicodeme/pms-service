package com.lombardinternational.casemanagement.service.decision.adapter.api.web.rest.dto.screen;

import java.util.List;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.RequiredArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder
@RequiredArgsConstructor
@EqualsAndHashCode(callSuper = true)
public class SelectInputFieldDTO extends FieldDTO {

    private Integer minWidthPct;
    private Integer minWidthPx;
    private List<SelectInputFieldOptionDTO> options;
}
