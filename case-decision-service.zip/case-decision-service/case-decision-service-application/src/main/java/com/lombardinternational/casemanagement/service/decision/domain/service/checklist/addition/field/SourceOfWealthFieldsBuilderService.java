package com.lombardinternational.casemanagement.service.decision.domain.service.checklist.addition.field;

import java.time.format.DateTimeFormatter;

import org.springframework.stereotype.Service;

import com.lombardinternational.casemanagement.service.decision.domain.model.policy.SourcesOfWealth;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Field;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.Group;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.SelectInputField;
import com.lombardinternational.casemanagement.service.decision.domain.model.rules.TextInputField;
import com.lombardinternational.casemanagement.service.decision.domain.spi.repository.ReferenceDataRepositoryService;
import com.lombardinternational.casemanagement.service.decision.domain.utils.ChecklistUtils;
import com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ChecklistFieldConstants;

import lombok.AllArgsConstructor;

import static com.lombardinternational.casemanagement.service.decision.domain.utils.constants.ReferenceConstants.INDUSTRY_SECTOR_DOMAIN;

@Service
@AllArgsConstructor
public class SourceOfWealthFieldsBuilderService {

    private final ReferenceDataRepositoryService referenceDataRepositoryService;

    public void buildField(Group group, SourcesOfWealth sow, String position) {

        Field.resetFieldId();
        evaluateWhenHappened(group, sow, position);
        evaluateOriginatorName(group, sow, position);
        evaluateLinkWithEbo(group, sow, position);
        evaluateCompanyName(group, sow, position);
        evaluateOriginatorIndustrySector(group, sow, position);
        evaluateOriginatorPosition(group, sow, position);
        evaluateCountryWealth1Risk(group, sow, position);
        evaluateCountryWealth2Risk(group, sow, position);
    }

    private void evaluateWhenHappened(final Group group, final SourcesOfWealth sow, final String position) {

        var whenHappened = (TextInputField) ChecklistUtils.getFieldInGroup(group, ChecklistFieldConstants.WHEN_HAPPENED + position);
        if (whenHappened == null) {
            whenHappened = TextInputField.builder().fieldId(ChecklistFieldConstants.WHEN_HAPPENED + position).build();
            group.getFields().add(whenHappened);
        }
        whenHappened.setIsActive(true);
        whenHappened.incrementOrder();
        whenHappened.setLabel("When the inheritance / Gift / Donation / Divorce happened?");
        whenHappened.setSourceSystem("From CLASS");

        var forcedValue = "N/A";
        if (sow.getTransactionDateTime() != null) {
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
            forcedValue = sow.getTransactionDateTime().format(formatter);
        }
        whenHappened.setSelectedValue(forcedValue);
    }

    private void evaluateOriginatorName(final Group group, final SourcesOfWealth sow, final String position) {

        var originatorName = (TextInputField) ChecklistUtils.getFieldInGroup(group, ChecklistFieldConstants.ORIGINATOR_NAME + position);
        if (originatorName == null) {
            originatorName = TextInputField.builder().fieldId(ChecklistFieldConstants.ORIGINATOR_NAME + position).build();
            group.getFields().add(originatorName);
        }
        originatorName.setIsActive(true);
        originatorName.incrementOrder();
        originatorName.setLabel("Originator ID");
        originatorName.setSourceSystem("From CLASS");

        originatorName.setSelectedValue(sow.getContributorName() != null ? sow.getContributorName() : "N/A");
    }

    private void evaluateLinkWithEbo(final Group group, final SourcesOfWealth sow, final String position) {

        var linkWithEbo = (SelectInputField) ChecklistUtils.getFieldInGroup(group, ChecklistFieldConstants.LINK_WITH_EBO + position);
        if (linkWithEbo == null) {
            linkWithEbo = SelectInputField.builder().fieldId(ChecklistFieldConstants.LINK_WITH_EBO + position).build();
            group.getFields().add(linkWithEbo);
        }
        linkWithEbo.setIsActive(true);
        linkWithEbo.incrementOrder();
        linkWithEbo.setLabel("Link with EBO");
        linkWithEbo.setSourceSystem("From CLASS");

        linkWithEbo.setSelectedValue(sow.getContributorLink() != null ? sow.getContributorLink() : "N/A");
        linkWithEbo.setOptions(referenceDataRepositoryService
                .getReferenceDataOptionsByDomainAndSelectedValue(ChecklistFieldConstants.CONTRIBUTOR_LINK, linkWithEbo.getSelectedValue()));
    }

    private void evaluateCompanyName(final Group group, final SourcesOfWealth sow, final String position) {

        var companyName = (TextInputField) ChecklistUtils.getFieldInGroup(group, ChecklistFieldConstants.COMPANY_NAME + position);
        if (companyName == null) {
            companyName = TextInputField.builder().fieldId(ChecklistFieldConstants.COMPANY_NAME + position).build();
            group.getFields().add(companyName);
        }
        companyName.setIsActive(true);
        companyName.incrementOrder();
        companyName.setLabel("Company name");
        companyName.setSourceSystem("From CLASS");

        companyName.setSelectedValue(sow.getCompanyName() != null ? sow.getCompanyName() : "N/A");
    }

    private void evaluateOriginatorIndustrySector(final Group group, final SourcesOfWealth sow, final String position) {

        var originatorIndustrySector =
                (SelectInputField) ChecklistUtils.getFieldInGroup(group, ChecklistFieldConstants.ORIGINATOR_INDUSTRY_SECTOR + position);
        if (originatorIndustrySector == null) {
            originatorIndustrySector = SelectInputField.builder().fieldId(ChecklistFieldConstants.ORIGINATOR_INDUSTRY_SECTOR + position).build();
            group.getFields().add(originatorIndustrySector);
        }
        originatorIndustrySector.setIsActive(true);
        originatorIndustrySector.incrementOrder();
        originatorIndustrySector.setLabel("Industry sector");
        originatorIndustrySector.setSourceSystem("From CLASS");

        originatorIndustrySector.setSelectedValue(sow.getContributorProfIndusSector() != null ? sow.getContributorProfIndusSector() : "N/A");
        originatorIndustrySector.setOptions(referenceDataRepositoryService.getReferenceDataOptionsByDomainAndSelectedValue(INDUSTRY_SECTOR_DOMAIN,
                originatorIndustrySector.getSelectedValue()));
    }

    private void evaluateOriginatorPosition(final Group group, final SourcesOfWealth sow, final String position) {

        var originatorPosition = (SelectInputField) ChecklistUtils.getFieldInGroup(group, ChecklistFieldConstants.ORIGINATOR_POSITION + position);
        if (originatorPosition == null) {
            originatorPosition = SelectInputField.builder().fieldId(ChecklistFieldConstants.ORIGINATOR_POSITION + position).build();
            group.getFields().add(originatorPosition);
        }
        originatorPosition.setIsActive(true);
        originatorPosition.incrementOrder();
        originatorPosition.setLabel("Position");
        originatorPosition.setSourceSystem("From CLASS");

        originatorPosition.setSelectedValue(sow.getContributorProfession() != null ? sow.getContributorProfession() : "N/A");
        originatorPosition.setOptions(referenceDataRepositoryService
                .getReferenceDataOptionsByDomainAndSelectedValue(ChecklistFieldConstants.PROFESSION, originatorPosition.getSelectedValue()));
    }

    private void evaluateCountryWealth1Risk(final Group group, final SourcesOfWealth sow, final String position) {

        var countryWealth1Risk = (TextInputField) ChecklistUtils.getFieldInGroup(group,
                ChecklistFieldConstants.COUNTRY_WEALTH_ + "1" + ChecklistFieldConstants._RISK + position);
        if (countryWealth1Risk == null) {
            countryWealth1Risk = TextInputField.builder()
                    .fieldId(ChecklistFieldConstants.COUNTRY_WEALTH_ + "1" + ChecklistFieldConstants._RISK + position).build();
            group.getFields().add(countryWealth1Risk);
        }
        countryWealth1Risk.setIsActive(true);
        countryWealth1Risk.incrementOrder();
        countryWealth1Risk.setLabel("Wealth originating country 1");
        countryWealth1Risk.setSourceSystem("From CLASS");

        var wealthCountry = sow.getOriginOfPremium() != null ? sow.getWealthOriginatingcountry1() : "N/A";
        countryWealth1Risk.setSelectedValue(wealthCountry);
    }

    private void evaluateCountryWealth2Risk(final Group group, final SourcesOfWealth sow, final String position) {

        var countryWealth2Risk = (TextInputField) ChecklistUtils.getFieldInGroup(group,
                ChecklistFieldConstants.COUNTRY_WEALTH_ + "2" + ChecklistFieldConstants._RISK + position);
        if (countryWealth2Risk == null) {
            countryWealth2Risk = TextInputField.builder()
                    .fieldId(ChecklistFieldConstants.COUNTRY_WEALTH_ + "2" + ChecklistFieldConstants._RISK + position).build();
            group.getFields().add(countryWealth2Risk);
        }
        countryWealth2Risk.setIsActive(true);
        countryWealth2Risk.incrementOrder();
        countryWealth2Risk.setLabel("Wealth originating country 2");
        countryWealth2Risk.setSourceSystem("From CLASS");

        var wealthCountry = sow.getOriginOfPremium() != null ? sow.getWealthOriginatingcountry2() : "N/A";
        countryWealth2Risk.setSelectedValue(wealthCountry);
    }
}
